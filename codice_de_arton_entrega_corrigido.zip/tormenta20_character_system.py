#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
SISTEMA DE CRIAÇÃO, OTIMIZAÇÃO (CSP + MCTS + DEEP RL) E ARENA JRPG — TORMENTA20
Edição Jogo do Ano (v1.3) — Versão 37.0 (Refatoração , SOLID & GoF)
================================================================================
Este arquivo atua como Ponto de Entrada (Entry Point / CLI Orchestrator) e Facade
de compatibilidade retroativa, delegando toda a lógica para os pacotes desacoplados
em `t20_clean_arch/`:

  1. `t20_clean_arch/domain/`
     - `entities.py`   : Entidades de domínio imutáveis/dataclasses, Tabelas ND e Cap. 7.
     - `interfaces.py` : Contratos abstratos segregados (ISP / DIP — SOLID).
  2. `t20_clean_arch/infrastructure/`
     - `seed_data.py`           : Semente comprimida LZMA+Base64 (339 itens, poderes, magias).
     - `sqlite_repositories.py` : Adapter, Factory Method, Singleton SQLite e Repositórios.
  3. `t20_clean_arch/application/`
     - `calculators_decorators.py` : GoF Decorators (`ModificadorRacialDecorator`, etc.) e Calculadora.
     - `csp_specifications.py`     : GoF Composite Specification + Interpreter (`IEspecificacaoCSP`) e AC-3.
     - `synergy_damage_analyzer.py`: Dano Médio `(Máx+Mín)/2`, Crítico, DPR, AoE e Sinergias.
     - `combat_simulator.py`       : Simulador Tático 2d20 (`max(d1, d2)`) e Ambiente POMDP Caixa-Preta.
     - `mcts_rl_optimizer.py`      : Rede PUCT, Estratégias por Arquétipo (GoF Strategy) e MCTS.
  4. `t20_clean_arch/presentation/` & `t20_clean_arch/frontend_spa/`
     - `styles_css.py`     : Tema visual oficial inspirado em `Ficha_T20.pdf` e HUD limpa da Arena.
     - `renderers_html.py` : Renderizadores HTML/CSS, SVG e ASCII.
     - `spa_bundler.py`    : Empacotador que une os 5 módulos JS de `frontend_spa/` no HTML único.
     - `web_facade.py`     : `Tormenta20Facade` (GoF Facade), Servidor Web e Testes de Contrato.

Referências Oficiais:
  - Livro Básico: https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
  - Base Google Sheets: https://docs.google.com/spreadsheets/d/1nOPmuca052rr1UcibWIkRMsm48T0KwzRp0zH7qOZTbg/edit
================================================================================
"""
from __future__ import annotations

import pathlib
from pathlib import Path
import sys
from typing import Dict, List

# Garante saída UTF-8 segura no terminal do Windows (PowerShell/CMD cp1252)
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

_THIS_DIR = pathlib.Path(__file__).resolve().parent
if str(_THIS_DIR) not in sys.path:
    sys.path.insert(0, str(_THIS_DIR))

from t20_clean_arch import *


def exportar_html_unificado(
    facade: Tormenta20Facade,
    caminho_saida: str = "tormenta20_mobile_app.html",
) -> str:
    """Compila os 5 módulos JS de `t20_clean_arch/frontend_spa/` + CSS + SQLite Seed em um único HTML."""
    html_out = facade.pagina_web_completa(
        "v37 (SOLID + GoF), 339 Itens/Encantos, Combos Empilháveis, Fórmulas (Máx+Mín)/2 & Arena JRPG Limpa Ativos!",
        aba_ativa="tab-ficha",
    )
    destino = Path(caminho_saida).resolve()
    destino.write_text(html_out, encoding="utf-8")
    return str(destino)


def verificar_contratos_solid_e_gof(facade: Tormenta20Facade) -> Dict[str, bool]:
    """Executa uma auditoria rápida dos contratos SOLID (ISP/DIP/LSP) e padrões GoF em tempo de execução."""
    modulos_js = listar_modulos_frontend_spa()
    resultados = {
        "SRP_Pacotes_Separados": len(modulos_js) == 5,
        "OCP_Composite_Specification_CSP": issubclass(EspecificacaoCompostaAND, IEspecificacaoCSP),
        "LSP_Decorators_Substituiveis": (
            issubclass(ModificadorRacialDecorator, IModificadorFicha)
            and issubclass(ModificadorPoderesPassivosDecorator, IModificadorFicha)
        ),
        "ISP_Interfaces_Segregadas": (
            issubclass(RenderizadorFichaHTMLCSS, IRenderizadorFicha)
            and issubclass(RenderizadorArvoreDecisaoHTMLSVG, IRenderizadorArvoreDecisao)
        ),
        "DIP_Repositorios_Abstratos": (
            issubclass(SQLiteCatalogoRepository, IRepositorioCatalogoT20)
            and issubclass(RepositorioPersonagemSQLite, IRepositorioPersonagem)
        ),
        "GoF_Strategy_MCTS": issubclass(AvaliadorArquetipoMCTS, IEstrategiaAvaliacaoMCTS),
        "GoF_Singleton_SQLite": GerenciadorBancoSQLite("tormenta20.db") is GerenciadorBancoSQLite("tormenta20.db"),
        "Catalogo_339_Itens_Carregados": len(facade.catalogo.listar_itens()) >= 339,
    }
    if not all(resultados.values()):
        falhas = [k for k, v in resultados.items() if not v]
        raise AssertionError(f"Falha na auditoria de contratos SOLID/GoF: {falhas}")
    return resultados


def main(argv: List[str] | None = None) -> int:
    """Ponto de entrada CLI unificado."""
    args = argv if argv is not None else sys.argv[1:]
    facade_main = Tormenta20Facade("tormenta20.db")
    auditoria = verificar_contratos_solid_e_gof(facade_main)
    print(f"[SOLID & GoF Audit] Todos os {len(auditoria)} contratos verificados com sucesso: {list(auditoria.keys())}")
    print(f"[Estrutura Modular] Módulos JS do Bundler SPA: {listar_modulos_frontend_spa()}")

    if "--export-html" in args:
        idx = args.index("--export-html")
        caminho = (
            args[idx + 1]
            if idx + 1 < len(args) and not args[idx + 1].startswith("--")
            else "tormenta20_mobile_app.html"
        )
        arq = exportar_html_unificado(facade_main, caminho)
        print(f"[HTML STANDALONE GERADO]: {arq} ({Path(arq).stat().st_size} bytes)")
        return 0
    if "--demo" in args:
        executar_demonstracao_e_testes()
        return 0
    if "--qt" in args:
        if not iniciar_janela_desktop_qt_qss(facade_main):
            ServidorGUIWebPython(facade_main).iniciar()
        return 0
    if "--web" in args:
        ServidorGUIWebPython(facade_main).iniciar()
        return 0

    executar_demonstracao_e_testes()
    arq = exportar_html_unificado(facade_main, "tormenta20_mobile_app.html")
    print(f"[HTML STANDALONE ATUALIZADO]: {arq}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
