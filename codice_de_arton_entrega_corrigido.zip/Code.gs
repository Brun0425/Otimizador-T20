/**
 * ==============================================================================
 * BACKEND GOOGLE APPS SCRIPT (Code.gs) — CÓDICE DE ARTON (Tormenta20 v100)
 * ==============================================================================
 * Carrega automaticamente o aplicativo `tormenta20_mobile_app_v100_raw.html`
 * direto do Google Drive (sem precisar colar 2,5 MB no index.html pelo celular!)
 * e sincroniza fichas e Mesas Online na planilha oficial do Google Sheets.
 *
 * Planilha Oficial:
 * https://docs.google.com/spreadsheets/d/1nOPmuca052rr1UcibWIkRMsm48T0KwzRp0zH7qOZTbg/edit
 */

const SPREADSHEET_ID_T20 = '1nOPmuca052rr1UcibWIkRMsm48T0KwzRp0zH7qOZTbg';
const HTML_DRIVE_FILE_ID = '13gPlfa0Jqgq5KEmO4CaQ28JSHJmzlTRC';
const ABA_FICHAS_SALVAS = 'Fichas_Salvas';
const NOME_ABA_MESAS = 'Mesas_Online';
const CABECALHO_FICHAS = [
  'ID_Ficha', 'Nome', 'Jogador', 'Raca', 'Classes_Niveis',
  'Nivel', 'Score_MCTS', 'Atualizado_Em', 'Payload_JSON'
];

/**
 * Ponto de entrada HTTP GET do Web App.
 * Lê o HTML bruto v100 direto do Google Drive (ou usa index.html se existir).
 */
function doGet(e) {
  let htmlContent = '';
  try {
    htmlContent = DriveApp.getFileById(HTML_DRIVE_FILE_ID).getBlob().getDataAsString('UTF-8');
  } catch (err) {
    return HtmlService.createHtmlOutputFromFile('index')
      .setTitle('Códice de Arton — Tormenta20 (v100)')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
      .addMetaTag('viewport', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
  }
  return HtmlService.createHtmlOutput(htmlContent)
    .setTitle('Códice de Arton — Tormenta20 (v100)')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
}

function _obterOuCriarAbaFichas_() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID_T20);
  let sheet = ss.getSheetByName(ABA_FICHAS_SALVAS);
  if (!sheet) {
    sheet = ss.insertSheet(ABA_FICHAS_SALVAS);
    sheet.getRange(1, 1, 1, CABECALHO_FICHAS.length).setValues([CABECALHO_FICHAS]);
    sheet.setFrozenRows(1);
  } else if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, CABECALHO_FICHAS.length).setValues([CABECALHO_FICHAS]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function salvarFichaNaPlanilha(fichaObj) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const sheet = _obterOuCriarAbaFichas_();
    const agora = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'America/Sao_Paulo', 'yyyy-MM-dd HH:mm:ss');
    const idFicha = String(fichaObj.id || ('T20_' + Date.now()));
    const nome = String(fichaObj.nome || 'Novo Aventureiro');
    const jogador = String(fichaObj.jogador || 'Jogador');
    const raca = String(fichaObj.racaNome || 'Humano');
    const classesNiveis = String(fichaObj.classesResumo || 'Guerreiro 1');
    const nivel = Number(fichaObj.nivel || 1);
    const score = Number(fichaObj.score || 0);
    const payloadJson = JSON.stringify(fichaObj.payload || fichaObj);

    const lastRow = sheet.getLastRow();
    let linhaAlvo = -1;
    if (lastRow >= 2) {
      const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
      for (let i = 0; i < ids.length; i++) {
        if (String(ids[i][0]) === idFicha) {
          linhaAlvo = i + 2;
          break;
        }
      }
    }

    const linhaDados = [idFicha, nome, jogador, raca, classesNiveis, nivel, score, agora, payloadJson];
    if (linhaAlvo > 0) {
      sheet.getRange(linhaAlvo, 1, 1, linhaDados.length).setValues([linhaDados]);
    } else {
      sheet.appendRow(linhaDados);
    }

    return {
      ok: true,
      id: idFicha,
      atualizadoEm: agora,
      totalFichas: Math.max(1, sheet.getLastRow() - 1)
    };
  } finally {
    lock.releaseLock();
  }
}

function listarFichasDaPlanilha() {
  const sheet = _obterOuCriarAbaFichas_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const dados = sheet.getRange(2, 1, lastRow - 1, CABECALHO_FICHAS.length).getValues();
  const resultado = [];
  for (let i = dados.length - 1; i >= 0; i--) {
    const row = dados[i];
    if (!row[0] && !row[1]) continue;
    let payload = null;
    try { payload = row[8] ? JSON.parse(String(row[8])) : null; } catch (e) { payload = null; }
    resultado.push({
      id: String(row[0]),
      nome: String(row[1]),
      jogador: String(row[2]),
      racaNome: String(row[3]),
      classesResumo: String(row[4]),
      nivel: Number(row[5] || 1),
      score: Number(row[6] || 0),
      data: String(row[7] || ''),
      payload: payload
    });
  }
  return resultado;
}

function excluirFichaDaPlanilha(idFicha) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const sheet = _obterOuCriarAbaFichas_();
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return { ok: false };
    const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    for (let i = 0; i < ids.length; i++) {
      if (String(ids[i][0]) === String(idFicha)) {
        sheet.deleteRow(i + 2);
        return { ok: true };
      }
    }
    return { ok: false };
  } finally {
    lock.releaseLock();
  }
}

function obterOuCriarAbaMesasOnline() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID_T20);
  let aba = ss.getSheetByName(NOME_ABA_MESAS);
  if (!aba) {
    aba = ss.insertSheet(NOME_ABA_MESAS);
    aba.appendRow([
      'Codigo_Sala', 'Nome_Mesa', 'Mestre_Nome', 'Chefe_Ativo',
      'Rodada_Atual', 'Qtd_Herois', 'Atualizado_Em', 'Estado_JSON'
    ]);
    aba.setFrozenRows(1);
  }
  return aba;
}

function salvarOuSincronizarMesaNaPlanilha(payloadMesa) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const aba = obterOuCriarAbaMesasOnline();
    const dados = aba.getDataRange().getValues();
    const codigo = String(payloadMesa.codigoSala || 'VALKARIA-01').trim().toUpperCase();
    const agora = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'America/Sao_Paulo', 'yyyy-MM-dd HH:mm:ss');
    payloadMesa.codigoSala = codigo;
    payloadMesa.atualizadoEm = agora;
    const jsonStr = JSON.stringify(payloadMesa);
    const nomeChefe = (payloadMesa.chefeAtivo && payloadMesa.chefeAtivo.nome) ? payloadMesa.chefeAtivo.nome : (payloadMesa.idAmeacaAtiva || 'Chefe');
    const qtdHerois = Array.isArray(payloadMesa.participantes) ? payloadMesa.participantes.length : 0;
    const linhaValores = [
      codigo,
      payloadMesa.nomeMesa || ('Mesa ' + codigo),
      payloadMesa.mestreNome || 'Mestre',
      nomeChefe,
      Number(payloadMesa.rodadaAtual || 1),
      qtdHerois,
      agora,
      jsonStr
    ];
    for (let i = 1; i < dados.length; i++) {
      if (String(dados[i][0]).toUpperCase() === codigo) {
        aba.getRange(i + 1, 1, 1, linhaValores.length).setValues([linhaValores]);
        return { ok: true, mesa: payloadMesa };
      }
    }
    aba.appendRow(linhaValores);
    return { ok: true, mesa: payloadMesa };
  } finally {
    lock.releaseLock();
  }
}

function carregarMesaDaPlanilha(codigoSala) {
  const aba = obterOuCriarAbaMesasOnline();
  const dados = aba.getDataRange().getValues();
  const codigo = String(codigoSala || '').trim().toUpperCase();
  for (let i = 1; i < dados.length; i++) {
    if (String(dados[i][0]).toUpperCase() === codigo) {
      try { return { ok: true, mesa: JSON.parse(dados[i][7]) }; }
      catch (e) { return { ok: false, erro: String(e) }; }
    }
  }
  return { ok: false, erro: 'Sala não encontrada na Planilha.' };
}

function listarMesasDaPlanilha() {
  const aba = obterOuCriarAbaMesasOnline();
  const dados = aba.getDataRange().getValues();
  const lista = [];
  for (let i = dados.length - 1; i >= 1; i--) {
    lista.push({
      codigoSala: String(dados[i][0]),
      nomeMesa: String(dados[i][1]),
      mestreNome: String(dados[i][2]),
      nomeChefe: String(dados[i][3]),
      rodadaAtual: Number(dados[i][4] || 1),
      qtdHerois: Number(dados[i][5] || 0),
      atualizadoEm: String(dados[i][6])
    });
  }
  return { ok: true, mesas: lista };
}
