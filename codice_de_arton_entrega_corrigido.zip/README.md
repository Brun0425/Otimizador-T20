# Códice de Arton — Otimizador Combinatório e Simulador RL para Tormenta20

Projeto desenvolvido na disciplina de **Inteligência Artificial I** (4º ano — Engenharia da Computação, FHO, 2026) por **Bruno Otávio Passini** e **João Victor Marquesan**.

O sistema aplica **Satisfação de Restrições (CSP com AC-3)**, **Busca em Árvore Monte Carlo (MCTS com UCT)** e **Aprendizado por Reforço** (POMDP caixa-preta na Arena 1v1 e avaliação Monte Carlo cooperativa nas Mesas 4vN) sobre as regras de *Tormenta20 — Edição Jogo do Ano (v1.3)*.

## Como executar

### Opção 1 — Abrir direto no navegador (offline)
Abra o arquivo compilado no navegador (PC ou celular):
```text
app_web/tormenta20_mobile_app.html
```

### Opção 2 — Rodar com servidor Python local + SQLite
Requer apenas Python 3 (sem dependências externas):
```bash
python3 tormenta20_character_system.py
```
O script inicializa `tormenta20.db`, recompila a aplicação web e sobe o servidor HTTP local.

## Estrutura do projeto

- `tormenta20_character_system.py` — Ponto de entrada Python, inicialização do SQLite e servidor HTTP.
- `t20_clean_arch/` — Código-fonte modular (domínio, repositórios SQLite, CSP/MCTS, simulador, CSS e 5 módulos JS em `frontend_spa/`).
- `app_web/tormenta20_mobile_app.html` — Aplicação web autônoma (funciona offline).
- `planilha/Base_Dados_Tormenta20_JdA.xlsx` e `Code.gs` — Base em planilha e script opcional para publicação no Google Apps Script.
- `schema_postgresql.sql` — Esquema DDL equivalente para PostgreSQL.
- `docs/` — Documentação técnica (`documentacao_tecnica.md`), catálogo de builds das 14 classes (`builds_por_classe.md`), dados do benchmark (`comparativo_combinatorio.csv`) e instruções do Apps Script (`publicacao_apps_script.md`).
