# -*- coding: utf-8 -*-
from .seed_data import SEMENTE_CATALOGO_LZMA_B64
from .sqlite_repositories import *
