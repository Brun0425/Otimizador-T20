# -*- coding: utf-8 -*-
from __future__ import annotations

import abc
import base64
import copy
import dataclasses
import datetime
from datetime import datetime as dt_cls
import gzip
import hashlib
import zlib
import functools
import html
import http.server
import inspect
import io
import json
import lzma
import math
import os
import pathlib
from pathlib import Path
import random
import re
import socketserver
import sqlite3
import statistics
import string
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import typing
import urllib.parse
import urllib.request
import uuid
import webbrowser
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import (
    Any, Callable, Dict, Generic, Iterable, Iterator, List,
    Literal, Mapping, NamedTuple, Optional, Protocol, Sequence,
    Set, Tuple, Type, TypeVar, Union
)

"""
Camada de Infraestrutura — Adapter, Factory Method, Singleton SQLite e Repositórios.
"""
from ..domain import *
from .seed_data import SEMENTE_CATALOGO_LZMA_B64

GOOGLE_SHEET_ID_OFICIAL = "1nOPmuca052rr1UcibWIkRMsm48T0KwzRp0zH7qOZTbg"
ABAS_OFICIAIS = (
    "Racas", "Classes", "Origens", "Deuses", "Pericias",
    "Poderes_Classe", "Poderes_Gerais", "Itens", "Magias",
    "Ameacas", "Metricas_ND"
)


class SementeEmbutidaAdapter(IFonteDadosCatalogo):
    def carregar_tabelas_brutas(self) -> Dict[str, List[List[str]]]:
        raw_bytes = base64.b64decode(SEMENTE_CATALOGO_LZMA_B64)
        dados = json.loads(lzma.decompress(raw_bytes).decode("utf-8"))
        dados["Ameacas"] = [l.split("|") for l in RAW_AMEACAS_CAP7.strip().splitlines() if l.strip()]
        metricas_rows = [[
            "ID_Ameaca", "Patamar", "ND", "Papel", "Bonus_Ataque", "Dano_Medio", "Defesa",
            "Res_Forte", "Res_Media", "Res_Fraca", "PV", "CD_Efeito", "PM_Por_ND", "Regras_Papel", "Fonte_URL"
        ]]
        for a in TABELA_AMEACAS_OFICIAL_T20:
            metricas_rows.append([
                a.id_ameaca, a.patamar, a.nd, a.papel, str(a.bonus_ataque), str(a.dano_medio),
                str(a.defesa), str(a.res_forte), str(a.res_media), str(a.res_fraca),
                str(a.pv), str(a.cd_efeito), str(a.pm_por_nd), a.regras_papel, a.fonte_url
            ])
        dados["Metricas_ND"] = metricas_rows
        if "Classes" in dados:
            for row_c in dados["Classes"][1:]:
                if len(row_c) >= 10 and str(row_c[1]).strip().lower() == "druida":
                    row_c[9] = "Devoto fiel (Allihanna, Megalokk ou Oceano: 2 poderes concedidos), Empatia selvagem, Magias divinas (1º ao 4º círculo: 2º no Nv 6, 3º no Nv 10, 4º no Nv 14 — SAB), Forma selvagem, Caminho dos ermos"
                elif len(row_c) >= 10 and str(row_c[1]).strip().lower() == "bardo":
                    row_c[9] = "Inspiração (+1 a +5 em perícias, 2 PM), Magias arcanas (1º ao 4º círculo: 2º no Nv 6, 3º no Nv 10, 4º no Nv 14 — CAR), Eclético, Golpe elemental/mágico"
        return dados


class FabricaEntidadesT20:
    @staticmethod
    def _int_seguro(valor: Any, padrao: int = 0) -> int:
        if valor is None:
            return padrao
        m = re.search(r"-?\d+", str(valor).strip().replace("+", ""))
        return int(m.group(0)) if m else padrao

    @staticmethod
    def _float_seguro(valor: Any, padrao: float = 0.0) -> float:
        if valor is None:
            return padrao
        texto = str(valor).strip().replace(",", ".")
        if "1/2" in texto:
            return 0.5
        if "1/4" in texto:
            return 0.25
        m = re.search(r"-?\d+(?:\.\d+)?", texto)
        return float(m.group(0)) if m else padrao

    @classmethod
    def criar_raca(cls, row: Dict[str, Any]) -> Raca:
        return Raca(
            id_raca=str(row["ID_Raca"]), nome=str(row["Nome"]), categoria=str(row["Categoria"]),
            mod_for=cls._int_seguro(row["Mod_FOR"]), mod_des=cls._int_seguro(row["Mod_DES"]),
            mod_con=cls._int_seguro(row["Mod_CON"]), mod_int=cls._int_seguro(row["Mod_INT"]),
            mod_sab=cls._int_seguro(row["Mod_SAB"]), mod_car=cls._int_seguro(row["Mod_CAR"]),
            mod_livre=str(row["Mod_Livre"]), tamanho=str(row["Tamanho"]),
            deslocamento_m=cls._int_seguro(row["Deslocamento_m"], 9),
            tipo_criatura=str(row["Tipo_Criatura"]), habilidades_raca=str(row["Habilidades_Raca"]),
        )

    @classmethod
    def criar_classe(cls, row: Dict[str, Any]) -> Classe:
        return Classe(
            id_classe=str(row["ID_Classe"]), nome=str(row["Nome"]),
            atributo_principal=str(row["Atributo_Principal"]),
            pv_inicial=cls._int_seguro(row["PV_Inicial"], 12),
            pv_por_nivel=cls._int_seguro(row["PV_Por_Nivel"], 3),
            pm_por_nivel=cls._int_seguro(row["PM_Por_Nivel"], 3),
            pericias_fixas=str(row["Pericias_Fixas"]),
            qtd_pericias_escolha=cls._int_seguro(row["Qtd_Pericias_Escolha"], 2),
            lista_pericias_escolha=str(row["Lista_Pericias_Escolha"]),
            proficiencias=str(row["Proficiencias"]),
            habilidades_fixas=str(row["Habilidades_Fixas"]),
        )

    @classmethod
    def criar_origem(cls, row: Dict[str, Any]) -> Origem:
        return Origem(
            id_origem=str(row["ID_Origem"]), nome=str(row["Nome"]),
            itens_iniciais=str(row["Itens_Iniciais"]),
            pericias_disponiveis=str(row["Pericias_Disponiveis"]),
            poderes_disponiveis=str(row["Poderes_Disponiveis"]),
            poder_unico=str(row["Poder_Unico"]),
            efeito_poder_unico=str(row["Efeito_Poder_unico" if "Efeito_Poder_unico" in row else "Efeito_Poder_Unico"]),
        )

    @classmethod
    def criar_deus(cls, row: Dict[str, Any]) -> Deus:
        return Deus(
            id_deus=str(row["ID_Deus"]), nome=str(row["Nome"]), titulo=str(row["Titulo"]),
            energia=str(row["Energia"]), arma_preferida=str(row["Arma_Preferida"]),
            devotos_permitidos=str(row["Devotos_Permitidos"]),
            poderes_concedidos=str(row["Poderes_Concedidos"]),
            obrigacoes_restricoes=str(row["Obrigacoes_Restricoes"]),
        )

    @classmethod
    def criar_pericia(cls, row: Dict[str, Any]) -> Pericia:
        return Pericia(
            id_pericia=str(row["ID_Pericia"]), nome=str(row["Nome"]),
            atributo_chave=str(row["Atributo_Chave"]),
            somente_treinada=str(row["Somente_Treinada"]).strip().lower().startswith("s"),
            penalidade_armadura=str(row["Penalidade_Armadura"]).strip().lower().startswith("s"),
            usos_e_regras=str(row["Usos_E_Regras"]),
        )

    @classmethod
    def criar_poder_classe(cls, row: Dict[str, Any]) -> Poder:
        return Poder(
            id_poder=str(row["ID_Poder_Classe"]), categoria_ou_classe=str(row["Classe"]),
            nome=str(row["Nome"]), pre_requisitos=str(row["Pre_Requisitos"]),
            custo_pm=str(row["Custo_PM"]), acao=str(row["Acao"]),
            efeito_resumo=str(row["Efeito_Resumo"]), eh_poder_classe=True,
        )

    @classmethod
    def criar_poder_geral(cls, row: Dict[str, Any]) -> Poder:
        return Poder(
            id_poder=str(row["ID_Poder"]), categoria_ou_classe=str(row["Categoria"]),
            nome=str(row["Nome"]), pre_requisitos=str(row["Pre_Requisitos"]),
            custo_pm=str(row["Custo_PM"]), acao=str(row["Acao"]),
            efeito_resumo=str(row["Efeito_Resumo"]), eh_poder_classe=False,
        )

    @classmethod
    def criar_item(cls, row: Dict[str, Any]) -> Item:
        return Item(
            id_item=str(row["ID_Item"]), categoria=str(row["Categoria"]),
            subcategoria=str(row["Subcategoria"]), nome=str(row["Nome"]),
            preco=str(row["Preco"]), dano_ou_defesa=str(row["Dano_Ou_Defesa"]),
            critico_ou_penalidade=str(row["Critico_Ou_Penalidade"]),
            alcance=str(row["Alcance"]), tipo_dano=str(row["Tipo_Dano"]),
            espacos=cls._float_seguro(row["Espacos"], 1.0),
            efeito_propriedades=str(row["Efeito_Propriedades"]),
        )

    @classmethod
    def criar_magia(cls, row: Dict[str, Any]) -> Magia:
        return Magia(
            id_magia=str(row["ID_Magia"]), nome=str(row["Nome"]), tipo=str(row["Tipo"]),
            circulo=cls._int_seguro(row["Circulo"], 1), escola=str(row["Escola"]),
            execucao=str(row["Execucao"]), alcance=str(row["Alcance"]),
            alvo_area_efeito=str(row["Alvo_Area_Efeito"]), duracao=str(row["Duracao"]),
            resistencia=str(row["Resistencia"]),
            efeito_e_aprimoramentos=str(row["Efeito_E_Aprimoramentos"]),
        )


class GerenciadorBancoSQLite:
    _instancias: Dict[str, GerenciadorBancoSQLite] = {}
    _lock = threading.Lock()

    def __new__(cls, caminho_db: str = "tormenta20.db") -> GerenciadorBancoSQLite:
        caminho_abs = str(Path(caminho_db).resolve())
        with cls._lock:
            if caminho_abs not in cls._instancias:
                inst = super().__new__(cls)
                inst.caminho_db = caminho_abs
                inst.conn = sqlite3.connect(caminho_abs, check_same_thread=False, timeout=15.0)
                inst.conn.row_factory = sqlite3.Row
                inst._db_lock = threading.RLock()
                inst.conn.execute("PRAGMA journal_mode=WAL;")
                inst.conn.execute("PRAGMA synchronous=NORMAL;")
                inst.conn.execute("PRAGMA foreign_keys=ON;")
                inst.conn.execute("PRAGMA busy_timeout=5000;")
                inst._inicializar_esquema()
                cls._instancias[caminho_abs] = inst
            return cls._instancias[caminho_abs]

    def _inicializar_esquema(self) -> None:
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS personagens (
                id_personagem INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                jogador TEXT NOT NULL,
                nivel INTEGER NOT NULL,
                id_raca TEXT,
                id_classe TEXT,
                id_origem TEXT,
                id_deus TEXT,
                pv_maximos INTEGER,
                pm_maximos INTEGER,
                defesa_total INTEGER,
                pontuacao_mcts REAL,
                ficha_json TEXT NOT NULL,
                criado_em TEXT NOT NULL
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS personagem_escolhas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_personagem INTEGER NOT NULL,
                tipo_escolha TEXT NOT NULL,
                codigo_referencia TEXT NOT NULL,
                nome_referencia TEXT NOT NULL,
                FOREIGN KEY(id_personagem) REFERENCES personagens(id_personagem) ON DELETE CASCADE
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS historico_combates_rl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_personagem INTEGER,
                criatura_nome TEXT NOT NULL,
                nd_criatura TEXT NOT NULL,
                venceu INTEGER NOT NULL,
                turnos INTEGER NOT NULL,
                dano_causado REAL NOT NULL DEFAULT 0,
                recompensa_q REAL NOT NULL DEFAULT 0,
                registrado_em TEXT NOT NULL,
                FOREIGN KEY(id_personagem) REFERENCES personagens(id_personagem) ON DELETE SET NULL
            )
        """)
        # Migração segura de colunas novas em bancos existentes
        cols_existentes = {row["name"] for row in cur.execute("PRAGMA table_info(personagens)").fetchall()}
        for col_nome, col_def in [("classes_niveis", "TEXT DEFAULT ''"), ("atualizado_em", "TEXT DEFAULT ''"), ("uuid_externo", "TEXT DEFAULT ''")]:
            if col_nome not in cols_existentes:
                cur.execute(f"ALTER TABLE personagens ADD COLUMN {col_nome} {col_def}")
        # Índices para performance
        cur.execute("CREATE INDEX IF NOT EXISTS idx_personagens_nome ON personagens(nome)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_personagens_nivel_score ON personagens(nivel, pontuacao_mcts DESC)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_escolhas_personagem ON personagem_escolhas(id_personagem)")
        cur.execute("""
            CREATE TABLE IF NOT EXISTS mesas_online (
                id_mesa INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo_sala TEXT NOT NULL UNIQUE,
                nome_mesa TEXT NOT NULL,
                mestre_nome TEXT NOT NULL DEFAULT 'Mestre',
                id_ameaca_ativa TEXT DEFAULT 't20_cap7_012',
                rodada_atual INTEGER NOT NULL DEFAULT 1,
                turno_indice INTEGER NOT NULL DEFAULT 0,
                estado_json TEXT NOT NULL,
                criado_em TEXT NOT NULL,
                atualizado_em TEXT NOT NULL
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS mesa_participantes (
                id_participante INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo_sala TEXT NOT NULL,
                id_heroi TEXT NOT NULL,
                nome_heroi TEXT NOT NULL,
                jogador_nome TEXT NOT NULL,
                papel_grupo TEXT NOT NULL DEFAULT 'Combatente',
                pv_atual INTEGER NOT NULL DEFAULT 20,
                pv_max INTEGER NOT NULL DEFAULT 20,
                pm_atual INTEGER NOT NULL DEFAULT 10,
                pm_max INTEGER NOT NULL DEFAULT 10,
                iniciativa_rolada INTEGER NOT NULL DEFAULT 10,
                ficha_resumo_json TEXT NOT NULL,
                atualizado_em TEXT NOT NULL,
                UNIQUE(codigo_sala, id_heroi)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS mesa_eventos_log (
                id_evento INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo_sala TEXT NOT NULL,
                autor TEXT NOT NULL,
                tipo_evento TEXT NOT NULL DEFAULT 'ACAO',
                mensagem TEXT NOT NULL,
                criado_em TEXT NOT NULL
            )
        """)
        cur.execute("CREATE INDEX IF NOT EXISTS idx_mesas_codigo ON mesas_online(codigo_sala)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_participantes_sala ON mesa_participantes(codigo_sala)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_eventos_sala ON mesa_eventos_log(codigo_sala, id_evento DESC)")
        self.conn.commit()

    def sincronizar_catalogo(self, fonte: IFonteDadosCatalogo) -> Dict[str, int]:
        tabelas = fonte.carregar_tabelas_brutas()
        contagem: Dict[str, int] = {}
        cur = self.conn.cursor()
        for nome_aba, matriz in tabelas.items():
            if not matriz or len(matriz) < 2:
                continue
            cabecalhos = [re.sub(r"[^a-zA-Z0-9_]", "_", c) for c in matriz[0] if c]
            n_cols = len(cabecalhos)
            cols_sql = ", ".join(f'"{c}" TEXT' for c in cabecalhos)
            cur.execute(f'DROP TABLE IF EXISTS "{nome_aba}"')
            cur.execute(f'CREATE TABLE "{nome_aba}" ({cols_sql})')
            placeholders = ", ".join("?" for _ in range(n_cols))
            linhas_limpas = [linha[:n_cols] for linha in matriz[1:] if any(linha[:n_cols])]
            cur.executemany(f'INSERT INTO "{nome_aba}" VALUES ({placeholders})', linhas_limpas)
            contagem[nome_aba] = len(linhas_limpas)
        # Sincroniza também o Bestiário Oficial do Capítulo 7 (65 Criaturas, págs. 282–323 Livro / 288–329 PDF)
        linhas_cap7 = [l.split("|") for l in RAW_AMEACAS_CAP7.strip().splitlines() if l.strip()]
        if len(linhas_cap7) > 1:
            cabs_c7 = [re.sub(r"[^a-zA-Z0-9_]", "_", c) for c in linhas_cap7[0]]
            cols_c7 = ", ".join(f'"{c}" TEXT' for c in cabs_c7)
            cur.execute('DROP TABLE IF EXISTS "Ameacas_Cap7"')
            cur.execute(f'CREATE TABLE "Ameacas_Cap7" ({cols_c7})')
            ph_c7 = ", ".join("?" for _ in cabs_c7)
            cur.executemany(f'INSERT INTO "Ameacas_Cap7" VALUES ({ph_c7})', [r[:len(cabs_c7)] for r in linhas_cap7[1:]])
            contagem["Ameacas_Cap7"] = len(linhas_cap7) - 1
        self.conn.commit()
        return contagem


class SQLiteCatalogoRepository(IRepositorioCatalogoT20):
    def __init__(self, db: GerenciadorBancoSQLite) -> None:
        self.db = db
        self._cache_racas = [FabricaEntidadesT20.criar_raca(r) for r in self._consultar("Racas")]
        self._cache_classes = [FabricaEntidadesT20.criar_classe(r) for r in self._consultar("Classes")]
        self._cache_origens = [FabricaEntidadesT20.criar_origem(r) for r in self._consultar("Origens")]
        self._cache_deuses = [FabricaEntidadesT20.criar_deus(r) for r in self._consultar("Deuses")]
        self._cache_pericias = [FabricaEntidadesT20.criar_pericia(r) for r in self._consultar("Pericias")]
        self._cache_poderes_classe = [FabricaEntidadesT20.criar_poder_classe(r) for r in self._consultar("Poderes_Classe")]
        self._cache_poderes_gerais = [FabricaEntidadesT20.criar_poder_geral(r) for r in self._consultar("Poderes_Gerais")]
        self._cache_itens = [FabricaEntidadesT20.criar_item(r) for r in self._consultar("Itens")]
        self._cache_magias = [FabricaEntidadesT20.criar_magia(r) for r in self._consultar("Magias")]

    def _consultar(self, tabela: str) -> List[Dict[str, Any]]:
        cur = self.db.conn.cursor()
        cur.execute(f'SELECT * FROM "{tabela}"')
        return [dict(r) for r in cur.fetchall()]

    def listar_racas(self) -> List[Raca]: return list(self._cache_racas)
    def listar_classes(self) -> List[Classe]: return list(self._cache_classes)
    def listar_origens(self) -> List[Origem]: return list(self._cache_origens)
    def listar_deuses(self) -> List[Deus]: return list(self._cache_deuses)
    def listar_pericias(self) -> List[Pericia]: return list(self._cache_pericias)

    def listar_poderes_classe(self, classe: Optional[str] = None) -> List[Poder]:
        if not classe:
            return list(self._cache_poderes_classe)
        alvo = classe.strip().lower()
        return [p for p in self._cache_poderes_classe if p.categoria_ou_classe.lower() in (alvo, "todas")]

    def listar_poderes_gerais(self, categoria: Optional[str] = None) -> List[Poder]:
        if not categoria:
            return list(self._cache_poderes_gerais)
        alvo = categoria.strip().lower()
        return [p for p in self._cache_poderes_gerais if p.categoria_ou_classe.lower() == alvo]

    def listar_itens(self, categoria: Optional[str] = None) -> List[Item]:
        if not categoria:
            return list(self._cache_itens)
        alvo = categoria.strip().lower()
        return [i for i in self._cache_itens if alvo in i.categoria.lower() or alvo in i.subcategoria.lower()]

    def listar_magias(self, circulo_max: Optional[int] = None, tipo: Optional[str] = None) -> List[Magia]:
        res = list(self._cache_magias)
        if circulo_max is not None:
            res = [m for m in res if m.circulo <= circulo_max]
        if tipo:
            t = tipo.strip().lower()
            res = [m for m in res if m.tipo.lower() in (t, "universal")]
        return res


class RepositorioPersonagemSQLite(IRepositorioPersonagem):
    def __init__(self, db: GerenciadorBancoSQLite) -> None:
        self.db = db

    def salvar(self, ficha: FichaPersonagem) -> int:
        agora = datetime.datetime.now().isoformat(timespec="seconds")
        payload = {
            "nome": ficha.nome,
            "jogador": ficha.jogador,
            "nivel": ficha.nivel,
            "atributos_base": ficha.atributos_base.para_dict(),
            "atributos_finais": ficha.atributos_finais.para_dict(),
            "escolhas_atributos_livres": ficha.escolhas_atributos_livres,
            "raca": asdict(ficha.raca) if ficha.raca else None,
            "classe": asdict(ficha.classe) if ficha.classe else None,
            "origem": asdict(ficha.origem) if ficha.origem else None,
            "deus": asdict(ficha.deus) if ficha.deus else None,
            "pericias_treinadas": ficha.pericias_treinadas,
            "poderes_classe": [asdict(p) for p in ficha.poderes_classe],
            "poderes_gerais": [asdict(p) for p in ficha.poderes_gerais],
            "itens_inventario": [asdict(i) for i in ficha.itens_inventario],
            "arma_equipada": asdict(ficha.arma_equipada) if ficha.arma_equipada else None,
            "armadura_equipada": asdict(ficha.armadura_equipada) if ficha.armadura_equipada else None,
            "escudo_equipado": asdict(ficha.escudo_equipado) if ficha.escudo_equipado else None,
            "magias_conhecidas": [asdict(m) for m in ficha.magias_conhecidas],
            "pv_maximos": ficha.pv_maximos,
            "pm_maximos": ficha.pm_maximos,
            "defesa_total": ficha.defesa_total,
            "deslocamento_final": ficha.deslocamento_final,
            "carga_atual": ficha.carga_atual,
            "carga_maxima": ficha.carga_maxima,
            "cd_magias": ficha.cd_magias,
            "bonus_pericias": ficha.bonus_pericias,
            "validacoes_csp": ficha.validacoes_csp,
            "pontuacao_mcts": ficha.pontuacao_mcts,
            "relatorio_ia": asdict(ficha.relatorio_ia),
        }
        cur = self.db.conn.cursor()
        cur.execute("""
            INSERT INTO personagens (
                nome, jogador, nivel, id_raca, id_classe, id_origem, id_deus,
                pv_maximos, pm_maximos, defesa_total, pontuacao_mcts, ficha_json, criado_em
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            ficha.nome, ficha.jogador, ficha.nivel,
            ficha.raca.nome if ficha.raca else None,
            ficha.classe.nome if ficha.classe else None,
            ficha.origem.nome if ficha.origem else None,
            ficha.deus.nome if ficha.deus else None,
            ficha.pv_maximos, ficha.pm_maximos, ficha.defesa_total,
            ficha.pontuacao_mcts, json.dumps(payload, ensure_ascii=False), agora,
        ))
        id_gerado = int(cur.lastrowid)
        ficha.id_personagem = id_gerado

        escolhas_rows = []
        for per in ficha.pericias_treinadas:
            escolhas_rows.append((id_gerado, "PERICIA", per, per))
        for pod in ficha.poderes_classe:
            escolhas_rows.append((id_gerado, "PODER_CLASSE", pod.id_poder, pod.nome))
        for pod in ficha.poderes_gerais:
            escolhas_rows.append((id_gerado, "PODER_GERAL", pod.id_poder, pod.nome))
        for it in ficha.itens_inventario:
            escolhas_rows.append((id_gerado, "ITEM", it.id_item, it.nome))
        for mag in ficha.magias_conhecidas:
            escolhas_rows.append((id_gerado, "MAGIA", mag.id_magia, mag.nome))

        cur.executemany("""
            INSERT INTO personagem_escolhas (id_personagem, tipo_escolha, codigo_referencia, nome_referencia)
            VALUES (?, ?, ?, ?)
        """, escolhas_rows)
        self.db.conn.commit()
        return id_gerado

    def carregar(self, id_personagem: int) -> Optional[FichaPersonagem]:
        cur = self.db.conn.cursor()
        cur.execute("SELECT * FROM personagens WHERE id_personagem = ?", (id_personagem,))
        row = cur.fetchone()
        if not row:
            return None
        d = json.loads(row["ficha_json"])
        rel_raw = d.get("relatorio_ia", {})
        passos_obj = []
        for p_dict in rel_raw.get("passos_arvore", []):
            alts = [RamoAlternativoArvore(**a) for a in p_dict.get("alternativas_avaliadas", [])]
            p_copy = dict(p_dict)
            p_copy["alternativas_avaliadas"] = alts
            passos_obj.append(PassoCaminhoArvore(**p_copy))
        rel_copy = dict(rel_raw)
        if "passos_arvore" in rel_copy:
            rel_copy["passos_arvore"] = passos_obj
        if "simulacao_combate" in rel_copy and isinstance(rel_copy["simulacao_combate"], dict):
            rel_copy["simulacao_combate"] = RelatorioSimulacaoCombate(**rel_copy["simulacao_combate"])
        if "metricas_ml" in rel_copy and isinstance(rel_copy["metricas_ml"], dict):
            m_dict = dict(rel_copy["metricas_ml"])
            if "top_priors_politica" in m_dict:
                m_dict["top_priors_politica"] = [tuple(x) for x in m_dict["top_priors_politica"]]
            rel_copy["metricas_ml"] = MetricasTreinoML(**m_dict)
        rel_obj = RelatorioOtimizacaoIA(**rel_copy) if rel_copy else RelatorioOtimizacaoIA()

        return FichaPersonagem(
            id_personagem=row["id_personagem"],
            nome=d["nome"],
            jogador=d["jogador"],
            nivel=d["nivel"],
            atributos_base=Atributos(**d["atributos_base"]),
            atributos_finais=Atributos(**d["atributos_finais"]),
            escolhas_atributos_livres=d.get("escolhas_atributos_livres", []),
            raca=Raca(**d["raca"]) if d.get("raca") else None,
            classe=Classe(**d["classe"]) if d.get("classe") else None,
            origem=Origem(**d["origem"]) if d.get("origem") else None,
            deus=Deus(**d["deus"]) if d.get("deus") else None,
            pericias_treinadas=d.get("pericias_treinadas", []),
            poderes_classe=[Poder(**p) for p in d.get("poderes_classe", [])],
            poderes_gerais=[Poder(**p) for p in d.get("poderes_gerais", [])],
            itens_inventario=[Item(**i) for i in d.get("itens_inventario", [])],
            arma_equipada=Item(**d["arma_equipada"]) if d.get("arma_equipada") else None,
            armadura_equipada=Item(**d["armadura_equipada"]) if d.get("armadura_equipada") else None,
            escudo_equipado=Item(**d["escudo_equipado"]) if d.get("escudo_equipado") else None,
            magias_conhecidas=[Magia(**m) for m in d.get("magias_conhecidas", [])],
            pv_maximos=d["pv_maximos"],
            pm_maximos=d["pm_maximos"],
            defesa_total=d["defesa_total"],
            deslocamento_final=d["deslocamento_final"],
            carga_atual=d["carga_atual"],
            carga_maxima=d["carga_maxima"],
            cd_magias=d["cd_magias"],
            bonus_pericias=d["bonus_pericias"],
            validacoes_csp=d.get("validacoes_csp", []),
            pontuacao_mcts=d.get("pontuacao_mcts", 0.0),
            relatorio_ia=rel_obj,
        )

    def listar_resumo(self) -> List[Dict[str, Any]]:
        cur = self.db.conn.cursor()
        cur.execute("""
            SELECT id_personagem, nome, jogador, nivel, id_raca, id_classe,
                   pv_maximos, pm_maximos, defesa_total, pontuacao_mcts, criado_em
            FROM personagens ORDER BY id_personagem DESC
        """)
        return [dict(r) for r in cur.fetchall()]



    def salvar_payload_json_externo(self, registro: Dict[str, Any]) -> int:
        """Persiste ou atualiza um registro JSON vindo da API REST (/api/fichas) com Lock transacional."""
        agora = datetime.datetime.now().isoformat(timespec="seconds")
        uuid_ext = str(registro.get("id") or f"T20_{int(time.time() * 1000)}")
        nome = str(registro.get("nome") or "Novo Aventureiro")
        jogador = str(registro.get("jogador") or "Jogador")
        nivel = int(registro.get("nivel") or 1)
        classes_nv = str(registro.get("classesResumo") or f"Guerreiro {nivel}")
        score = float(registro.get("score") or 0.0)
        payload_str = json.dumps(registro.get("payload") or registro, ensure_ascii=False)
        lock = getattr(self.db, "_db_lock", threading.RLock())
        with lock:
            cur = self.db.conn.cursor()
            row_ex = cur.execute("SELECT id_personagem FROM personagens WHERE uuid_externo = ?", (uuid_ext,)).fetchone()
            if row_ex:
                id_p = int(row_ex["id_personagem"])
                cur.execute("""
                    UPDATE personagens
                    SET nome=?, jogador=?, nivel=?, classes_niveis=?, pontuacao_mcts=?, ficha_json=?, atualizado_em=?
                    WHERE id_personagem=?
                """, (nome, jogador, nivel, classes_nv, score, payload_str, agora, id_p))
            else:
                cur.execute("""
                    INSERT INTO personagens (uuid_externo, nome, jogador, nivel, classes_niveis, pontuacao_mcts, ficha_json, criado_em, atualizado_em)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (uuid_ext, nome, jogador, nivel, classes_nv, score, payload_str, agora, agora))
                id_p = int(cur.lastrowid)
            self.db.conn.commit()
            return id_p

    def listar_para_api_rest(self) -> List[Dict[str, Any]]:
        """Retorna todas as fichas salvas formatadas para consumo da API REST (/api/fichas)."""
        lock = getattr(self.db, "_db_lock", threading.RLock())
        with lock:
            rows = self.db.conn.execute("""
                SELECT id_personagem, uuid_externo, nome, jogador, nivel, classes_niveis, pontuacao_mcts, ficha_json, criado_em, atualizado_em
                FROM personagens ORDER BY id_personagem DESC
            """).fetchall()
        res: List[Dict[str, Any]] = []
        for r in rows:
            try:
                payload = json.loads(r["ficha_json"])
            except Exception:
                payload = None
            raca_nm = ""
            if isinstance(payload, dict) and isinstance(payload.get("raca"), dict):
                raca_nm = payload["raca"].get("nome", "")
            res.append({
                "id": r["uuid_externo"] or str(r["id_personagem"]),
                "id_sql": int(r["id_personagem"]),
                "nome": r["nome"],
                "jogador": r["jogador"],
                "racaNome": raca_nm or "Humano",
                "classesResumo": r["classes_niveis"] or f"Nv {r['nivel']}",
                "nivel": int(r["nivel"]),
                "score": float(r["pontuacao_mcts"] or 0.0),
                "data": r["atualizado_em"] or r["criado_em"],
                "payload": payload,
            })
        return res

    def excluir_por_id(self, id_ou_uuid: str) -> bool:
        lock = getattr(self.db, "_db_lock", threading.RLock())
        with lock:
            cur = self.db.conn.cursor()
            if str(id_ou_uuid).isdigit():
                cur.execute("DELETE FROM personagens WHERE id_personagem = ? OR uuid_externo = ?", (int(id_ou_uuid), str(id_ou_uuid)))
            else:
                cur.execute("DELETE FROM personagens WHERE uuid_externo = ?", (str(id_ou_uuid),))
            self.db.conn.commit()
            return cur.rowcount > 0

    # =========================================================================
    # MÉTODOS DE MESAS ONLINE MULTIPLAYER (GRUPO & CO-OP BOSS) - v43
    # =========================================================================
    def salvar_ou_atualizar_mesa_online(self, payload_mesa: Dict[str, Any]) -> Dict[str, Any]:
        """Persiste ou sincroniza o estado completo de uma Mesa Online em transação ACID."""
        lock = getattr(self.db, "_db_lock", threading.RLock())
        with lock:
            cur = self.db.conn.cursor()
            agora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            codigo = str(payload_mesa.get("codigoSala") or "VALKARIA-01").strip().upper()
            nome_mesa = str(payload_mesa.get("nomeMesa") or f"Mesa {codigo}").strip()
            mestre = str(payload_mesa.get("mestreNome") or "Mestre").strip()
            id_ameaca = str(payload_mesa.get("idAmeacaAtiva") or "t20_cap7_012")
            rodada = int(payload_mesa.get("rodadaAtual") or 1)
            turno_idx = int(payload_mesa.get("turnoIndice") or 0)
            payload_mesa["codigoSala"] = codigo
            payload_mesa["atualizadoEm"] = agora
            estado_str = json.dumps(payload_mesa, ensure_ascii=False)

            row_exist = cur.execute(
                "SELECT id_mesa FROM mesas_online WHERE codigo_sala = ?", (codigo,)
            ).fetchone()
            if row_exist:
                cur.execute("""
                    UPDATE mesas_online
                    SET nome_mesa = ?, mestre_nome = ?, id_ameaca_ativa = ?,
                        rodada_atual = ?, turno_indice = ?, estado_json = ?, atualizado_em = ?
                    WHERE codigo_sala = ?
                """, (nome_mesa, mestre, id_ameaca, rodada, turno_idx, estado_str, agora, codigo))
            else:
                cur.execute("""
                    INSERT INTO mesas_online (codigo_sala, nome_mesa, mestre_nome, id_ameaca_ativa, rodada_atual, turno_indice, estado_json, criado_em, atualizado_em)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (codigo, nome_mesa, mestre, id_ameaca, rodada, turno_idx, estado_str, agora, agora))

            # Sincroniza participantes na tabela relacional
            participantes = payload_mesa.get("participantes") or []
            if isinstance(participantes, list):
                cur.execute("DELETE FROM mesa_participantes WHERE codigo_sala = ?", (codigo,))
                for p in participantes:
                    if not isinstance(p, dict):
                        continue
                    cur.execute("""
                        INSERT INTO mesa_participantes (
                            codigo_sala, id_heroi, nome_heroi, jogador_nome, papel_grupo,
                            pv_atual, pv_max, pm_atual, pm_max, iniciativa_rolada, ficha_resumo_json, atualizado_em
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        codigo,
                        str(p.get("idHeroi") or uuid.uuid4().hex[:8]),
                        str(p.get("nome") or "Herói"),
                        str(p.get("jogador") or "Jogador"),
                        str(p.get("papel") or "Combatente"),
                        int(p.get("pvAtual") or 20),
                        int(p.get("pvMax") or 20),
                        int(p.get("pmAtual") or 10),
                        int(p.get("pmMax") or 10),
                        int(p.get("iniciativaRolada") or 10),
                        json.dumps(p, ensure_ascii=False),
                        agora
                    ))

            # Registra último evento se enviado
            ult_ev = payload_mesa.get("ultimoEvento")
            if isinstance(ult_ev, dict) and ult_ev.get("mensagem"):
                cur.execute("""
                    INSERT INTO mesa_eventos_log (codigo_sala, autor, tipo_evento, mensagem, criado_em)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    codigo,
                    str(ult_ev.get("autor") or "Sistema"),
                    str(ult_ev.get("tipo") or "ACAO"),
                    str(ult_ev.get("mensagem")),
                    agora
                ))

            self.db.conn.commit()
            return payload_mesa

    def obter_mesa_online(self, codigo_sala: str) -> Optional[Dict[str, Any]]:
        """Carrega o estado completo de uma Mesa Online pelo código da sala."""
        lock = getattr(self.db, "_db_lock", threading.RLock())
        codigo = str(codigo_sala or "").strip().upper()
        with lock:
            row = self.db.conn.execute(
                "SELECT estado_json, atualizado_em FROM mesas_online WHERE codigo_sala = ?",
                (codigo,)
            ).fetchone()
        if not row:
            return None
        try:
            st = json.loads(row["estado_json"])
            st["atualizadoEm"] = row["atualizado_em"]
            return st
        except Exception:
            return None

    def listar_mesas_online(self) -> List[Dict[str, Any]]:
        """Lista todas as Mesas Online ativas para o Lobby."""
        lock = getattr(self.db, "_db_lock", threading.RLock())
        with lock:
            rows = self.db.conn.execute("""
                SELECT codigo_sala, nome_mesa, mestre_nome, id_ameaca_ativa, rodada_atual, estado_json, atualizado_em
                FROM mesas_online ORDER BY atualizado_em DESC LIMIT 50
            """).fetchall()
        res: List[Dict[str, Any]] = []
        for r in rows:
            qtd_herois = 0
            nome_chefe = r["id_ameaca_ativa"]
            try:
                st = json.loads(r["estado_json"])
                qtd_herois = len(st.get("participantes") or [])
                if st.get("chefeAtivo") and isinstance(st["chefeAtivo"], dict):
                    nome_chefe = st["chefeAtivo"].get("nome") or nome_chefe
            except Exception:
                pass
            res.append({
                "codigoSala": r["codigo_sala"],
                "nomeMesa": r["nome_mesa"],
                "mestreNome": r["mestre_nome"],
                "nomeChefe": nome_chefe,
                "rodadaAtual": int(r["rodada_atual"] or 1),
                "qtdHerois": qtd_herois,
                "atualizadoEm": r["atualizado_em"],
            })
        return res

    def excluir_mesa_online(self, codigo_sala: str) -> bool:
        lock = getattr(self.db, "_db_lock", threading.RLock())
        codigo = str(codigo_sala or "").strip().upper()
        with lock:
            cur = self.db.conn.cursor()
            cur.execute("DELETE FROM mesa_participantes WHERE codigo_sala = ?", (codigo,))
            cur.execute("DELETE FROM mesa_eventos_log WHERE codigo_sala = ?", (codigo,))
            cur.execute("DELETE FROM mesas_online WHERE codigo_sala = ?", (codigo,))
            self.db.conn.commit()
            return cur.rowcount > 0

