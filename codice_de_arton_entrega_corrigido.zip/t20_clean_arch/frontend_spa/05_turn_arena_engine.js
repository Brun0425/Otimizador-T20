
// Limite rígido de gasto de PM por turno em Tormenta20 JdA (p. 170): nivel + bonusLimitePm (ex.: Canalizador / Cajado Arcano)
function calcularLimitePmTurnoT20JS(nivel, bonusLimitePm = 0) {
    return Math.max(1, parseInt(nivel || 1, 10) + Math.max(0, parseInt(bonusLimitePm || 0, 10)));
}
function aplicarLimitePmTurnoAcaoT20JS(custoPm, nivel, bonusLimitePm = 0) {
    const teto = calcularLimitePmTurnoT20JS(nivel, bonusLimitePm);
    return Math.min(Math.max(0, Number(custoPm || 0)), teto);
}
if (typeof window !== 'undefined') {
    window.calcularLimitePmTurnoT20JS = calcularLimitePmTurnoT20JS;
    window.aplicarLimitePmTurnoAcaoT20JS = aplicarLimitePmTurnoAcaoT20JS;
}

function atualizarPlacarVisualArena() {
    if (!__ARENA_STATE__) return;
    const st = garantirEstadoFichaParaArena();
    const a = __ARENA_STATE__;
    const priv = a._privadoCriatura;
    const cr = a.crencaIA;

    const elNomeH = document.getElementById('arena-nome-heroi');
    const elSubH = document.getElementById('arena-sub-heroi');
    const elDefH = document.getElementById('arena-badge-def-heroi');
    const barPvH = document.getElementById('arena-bar-pv-heroi');
    const txtPvH = document.getElementById('arena-txt-pv-heroi');
    const barPmH = document.getElementById('arena-bar-pm-heroi');
    const txtPmH = document.getElementById('arena-txt-pm-heroi');
    const svgH = document.getElementById('arena-svg-heroi');
    const buffsH = document.getElementById('arena-buffs-heroi');

    if (elNomeH) elNomeH.textContent = st.nome;
    if (elSubH) elSubH.textContent = `${st.raca.nome} ${st.classe.nome} Nv ${st.nivel} · ${st.arquetipo}`;

    // =========================================================================
    // FILTRAGEM ESTRITA: EXIBE APENAS AS AÇÕES, PODERES, ITENS E MAGIAS QUE O PERSONAGEM POSSUI NA FICHA!
    // =========================================================================
    const ncArena = (st.classe && st.classe.nome) ? st.classe.nome.toLowerCase() : '';
    const nrArena = (st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : '';
    const memOstArena = (st.est && st.est.racaAnteriorOsteon) ? st.est.racaAnteriorOsteon.toLowerCase() : '';
    const todosPodsArena = [
        ...((st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ];
    const nomesPodsLow = todosPodsArena.map(p => (p.nome || '').toLowerCase());
    const temGPArena = nomesPodsLow.includes('golpe pessoal');
    const temSurtoHeroico = nomesPodsLow.includes('surto heroico');
    const temCombateDefensivo = nomesPodsLow.includes('combate defensivo');
    const temAtaquePoderoso = nomesPodsLow.includes('ataque poderoso');
    const temFintaAprimorada = nomesPodsLow.includes('finta aprimorada');
    const temMagiaAcelerada = nomesPodsLow.includes('magia acelerada');
    const temMiraApurada = nomesPodsLow.includes('mira apurada');
    const infoNatArena = obterInfoArmaNaturalJS(nrArena, memOstArena, todosPodsArena);
    const listaMagiasFicha = st.magias || [];
    const temMagiasNaFicha = listaMagiasFicha.length > 0;

    // Verifica se a arma equipada é à distância (para a ação Mirar do Cap. 5, p. 235)
    const subArmaLow = st.arma ? ((st.arma.subcategoria || '') + ' ' + (st.arma.nome || '')).toLowerCase() : '';
    const usaArmaDistancia = /distância|distancia|fogo|arco|besta|mosquete|pistola|funda|azagaia/.test(subArmaLow);

    // Verifica se possui item consumível real no inventário da ficha (Bálsamo restaurador, Essência de mana, Poção)
    const itemConsumivelFicha = (st.itens || []).find(it => /bálsamo|balsamo|essência|essencia|poção|pocao|alquímico/i.test(it.nome || ''));

    const selModoAE = document.getElementById('arena-sel-modo-ae');
    const selGP = document.getElementById('arena-sel-golpe-pessoal');
    const lblNat = document.getElementById('lbl-chk-arma-natural');
    const txtNat = document.getElementById('txt-chk-arma-natural');
    const btnAtqPadrao = document.getElementById('btn-arena-atq-padrao');
    const btnHabCl = document.getElementById('btn-arena-hab-classe');
    const btnGP = document.getElementById('btn-arena-golpe-pessoal');
    const btnHabRacial = document.getElementById('btn-arena-hab-racial');
    const btnInvestida = document.getElementById('btn-arena-investida');
    const btnFintar = document.getElementById('btn-arena-fintar');
    const btnCombateDefensivo = document.getElementById('btn-arena-combate-defensivo');
    const btnMovMirar = document.getElementById('btn-arena-mov-mirar');
    const btnMovItem = document.getElementById('btn-arena-mov-item');
    const btnSurtoHeroico = document.getElementById('btn-arena-surto-heroico');
    const btnTabMagias = document.getElementById('btn-hud-tab-magias'); if (btnTabMagias) btnTabMagias.innerHTML = `Magias (${temMagiasNaFicha ? listaMagiasFicha.length : 0})`;
    const msgSemMagias = document.getElementById('arena-msg-sem-magias-hud'); if (msgSemMagias) msgSemMagias.style.display = temMagiasNaFicha ? 'none' : 'block';
    const boxConjuracaoFicha = document.getElementById('arena-box-conjuracao-ficha');
    const lblMagiaAcelerada = document.getElementById('lbl-arena-magia-acelerada');
    const lblHabEsp = document.getElementById('arena-lbl-hab-especificas');

    if (btnAtqPadrao) {
        btnAtqPadrao.innerHTML = `Agredir c/ ${st.arma ? st.arma.nome : 'Ataque Desarmado'} [Ação Padrão — p. 233]`;
    }
    if (selModoAE) selModoAE.style.display = (ncArena === 'guerreiro') ? '' : 'none';
    if (selGP) selGP.style.display = temGPArena ? '' : 'none';
    if (btnGP) btnGP.style.display = temGPArena ? '' : 'none';
    if (btnInvestida) btnInvestida.style.display = usaArmaDistancia ? 'none' : '';
    if (btnFintar) {
        btnFintar.innerHTML = `Fintar (Enganação vs Reflexos: Desprevenido) [${temFintaAprimorada ? 'Movimento (Finta Aprim.)' : 'Padrão'} — p. 234]`;
    }

    // Poder Combate Defensivo (Livro p. 125) — exibido APENAS se o personagem possuir o poder na ficha!
    if (btnCombateDefensivo) {
        btnCombateDefensivo.style.display = temCombateDefensivo ? '' : 'none';
        if (temCombateDefensivo) {
            btnCombateDefensivo.innerHTML = `Agredir c/ Combate Defensivo (-2 Ataque e +5 Defesa até o próximo turno — p. 125)`;
        }
    }

    // Ação de Movimento: Mirar (Livro p. 235) ou Poder Mira Apurada (p. 127) — apenas se usar arma à distância ou tiver Mira Apurada!
    if (btnMovMirar) {
        const mostrarMirar = usaArmaDistancia || temMiraApurada;
        btnMovMirar.style.display = mostrarMirar ? '' : 'none';
        if (mostrarMirar) {
            btnMovMirar.innerHTML = temMiraApurada
                ? `Mirar + Mira Apurada [Movimento: +SAB no Ataque/Dano e Margem Crít — p. 127/235]`
                : `Mirar [Movimento: Anula penalidade de disparo em alvo engajado — p. 235]`;
        }
    }

    // Ação de Movimento: Manipular Item (Livro p. 235) — exibido APENAS se houver item consumível no inventário da ficha!
    if (btnMovItem) {
        btnMovItem.style.display = itemConsumivelFicha ? '' : 'none';
        if (itemConsumivelFicha) {
            btnMovItem.innerHTML = `Manipular Item: Usar ${itemConsumivelFicha.nome} [Movimento — p. 235]`;
        }
    }

    // Poder Geral: Surto Heroico (Livro p. 129) — exibido APENAS se o personagem possuir Surto Heroico na ficha!
    if (btnSurtoHeroico) {
        btnSurtoHeroico.style.display = temSurtoHeroico ? '' : 'none';
    }

    // Painel de Conjuração & Aprimoramentos — exibido APENAS se o personagem possuir magias na ficha (`st.magias.length > 0`)!
    if (boxConjuracaoFicha) {
        boxConjuracaoFicha.style.display = temMagiasNaFicha ? 'block' : 'none';
        if (lblMagiaAcelerada) {
            lblMagiaAcelerada.style.display = temMagiaAcelerada ? 'inline-flex' : 'none';
        }
        if (temMagiasNaFicha) {
            const selMag = document.getElementById('arena-sel-magia-ficha');
            if (selMag) {
                const assinaturaMagias = listaMagiasFicha.map(m => m.id_magia).join('|');
                if (selMag.getAttribute('data-assinatura') !== assinaturaMagias) {
                    selMag.setAttribute('data-assinatura', assinaturaMagias);
                    const custoCirc = { 1: 1, 2: 3, 3: 6, 4: 10, 5: 15 };
                    selMag.innerHTML = listaMagiasFicha.map(m =>
                        `<option value="${m.id_magia}">[${m.circulo}º Círc · ${m.execucao} · Base ${custoCirc[m.circulo] || 1} PM] ${m.nome} (${m.escola})</option>`
                    ).join('');
                    aoMudarMagiaSelecionadaArenaJS();
                } else {
                    atualizarPreviewAprimoramentoMagiaArenaJS();
                }
            }
        }
    }

    if (lblNat && txtNat) {
        if (infoNatArena) {
            lblNat.style.display = 'inline-flex';
            txtNat.textContent = `${infoNatArena.icone} Usar ${infoNatArena.nomeCurto} (1 PM ao Agredir: +1 atq ${infoNatArena.dadoStr}+FOR — ${infoNatArena.pagina})`;
        } else {
            lblNat.style.display = 'none';
        }
    }

    if (lblHabEsp) {
        const listaReacFicha = listarReacoesDisponiveisHeroiJS(st, a, { tipo: 'EFEITO_RESISTENCIA', acertouOriginal: true, totAtq: 25, defAlvoOriginal: 20, danoPrevisto: 20 });
        const strReacFicha = listaReacFicha.length > 0
            ? listaReacFicha.map(r => r.nome.split('[')[0].trim()).join(' · ')
            : 'Apenas Defesa & Resistências Passivas da Ficha (0 PM)';
        lblHabEsp.innerHTML = `Habilidades da Ficha de <strong>${st.nome}</strong> (${st.raca.nome} ${st.classe.nome} Nv ${st.nivel}) &nbsp;|&nbsp; <strong>Reações na Ficha:</strong> <span style="color:#FDE047;">${strReacFicha}</span>`;
    }

    // Botão de Habilidade de Classe: mostra APENAS se a classe tiver uma habilidade ativa de ataque/combate na ficha!
    if (btnHabCl) {
        btnHabCl.style.display = '';
        if (ncArena === 'guerreiro') {
            const cAE = 1 + Math.floor((st.nivel - 1) / 4);
            btnHabCl.innerHTML = `Agredir c/ Ataque Especial [Padrão, -${cAE} PM: +${4 * cAE} Atq/Dano — p. 65]`;
        } else if (ncArena === 'bárbaro') {
            const bFur = 2 + Math.floor((st.nivel - 1) / 5);
            btnHabCl.innerHTML = `Fúria (-2 PM, Livre) + Agredir [Padrão: +${bFur} Atq e +${bFur} Dano — p. 40]`;
        } else if (ncArena === 'paladino') {
            btnHabCl.innerHTML = `Agredir c/ Golpe Divino [Padrão, -2 PM: +CAR Atq e +1d8 Dano — p. 81]`;
        } else if (ncArena === 'caçador') {
            btnHabCl.innerHTML = `Marca da Presa [Movimento, -1 PM] + Agredir [Padrão — p. 49]`;
        } else if (ncArena === 'cavaleiro' && st.nivel >= 2) {
            btnHabCl.innerHTML = `Duelo [Livre, -2 PM] + Agredir [Padrão: +2 Atq e +2 Dano — p. 56]`;
        } else if (ncArena === 'ladino') {
            const dFurt = Math.ceil(st.nivel / 2);
            btnHabCl.innerHTML = `Agredir c/ Ataque Furtivo [Padrão: +${dFurt}d6 Dano em Alvo Desprevenido/Flanqueado — p. 73]`;
        } else if (ncArena === 'bucaneiro' && st.nivel >= 2) {
            btnHabCl.innerHTML = `Agredir c/ Audácia [Padrão, -2 PM: +CAR no Teste de Ataque — p. 50]`;
        } else if (ncArena === 'lutador') {
            btnHabCl.innerHTML = `Agredir + Golpe Relâmpago [Padrão, -1 PM: +1 Ataque Desarmado Extra — p. 76]`;
        } else if (ncArena === 'bardo') {
            btnHabCl.innerHTML = `Inspiração [Padrão, -2 PM: +1 a +5 em Testes de Perícia na Cena — p. 44]`;
        } else if (temAtaquePoderoso) {
            btnHabCl.innerHTML = `Agredir c/ Ataque Poderoso [Padrão: -2 no Ataque e +5 no Dano — p. 125]`;
        } else {
            btnHabCl.style.display = 'none';
        }
    }

    if (btnHabRacial) {
        if (nrArena === 'trog' || (nrArena === 'osteon' && memOstArena.includes('trog'))) {
            const cdMC = 10 + Math.floor(st.nivel / 2) + st.est.finais.CON;
            btnHabRacial.style.display = '';
            btnHabRacial.innerHTML = `Mau Cheiro Trog [Padrão, -2 PM: Fort CD ${cdMC} ou Enjoado 1d6 rod. — p. 31]`;
        } else if (nrArena === 'medusa' || (nrArena === 'osteon' && memOstArena.includes('medusa'))) {
            btnHabRacial.style.display = '';
            btnHabRacial.innerHTML = `Natureza Venenosa [Movimento, -1 PM: +1d12 Veneno na Arma — p. 24]`;
        } else if (nrArena === 'dahllan' || (nrArena === 'osteon' && memOstArena.includes('dahllan'))) {
            btnHabRacial.style.display = '';
            btnHabRacial.innerHTML = `Armadura de Allihanna [Movimento, -1 PM: +2 na Defesa — p. 19]`;
        } else {
            btnHabRacial.style.display = 'none';
        }
    }

    const defTotalHeroi = a.defHeroiBase + a.bonusDefTemp + (a.armaduraArcanaCenaBonus || (a.armaduraArcanaCena ? 5 : 0));
    if (elDefH) elDefH.textContent = `Def ${defTotalHeroi}` + (a.rdTemp > 0 ? ` | RD ${a.rdTemp}` : '') + (a.pvTempHeroi > 0 ? ` | +${a.pvTempHeroi} PV Temp` : '');
    if (typeof atualizarRetratoFichaPrincipalJS === 'function') atualizarRetratoFichaPrincipalJS();

    const pctPvH = Math.max(0, Math.min(100, (a.pvHeroi / Math.max(1, a.pvHeroiMax)) * 100));
    const pctPmH = Math.max(0, Math.min(100, (a.pmHeroi / Math.max(1, a.pmHeroiMax)) * 100));
    if (barPvH) barPvH.style.width = pctPvH + '%';
    if (txtPvH) txtPvH.textContent = `${Math.round(a.pvHeroi)} / ${a.pvHeroiMax} PV (${Math.round(pctPvH)}%)` + (a.pvTempHeroi > 0 ? ` [+${a.pvTempHeroi} Temp]` : '');
    if (barPmH) barPmH.style.width = pctPmH + '%';
    if (txtPmH) txtPmH.textContent = `${Math.round(a.pmHeroi)} / ${a.pmHeroiMax} PM`;

    if (buffsH) {
        const tagsB = [];
        if (a.concentracaoCombateAtiva) tagsB.push('Concentração de Combate (Próximo Ataque: 2d20 Escolhe o Melhor!)');
        if (a.armaduraArcanaCena) tagsB.push(`Armadura Arcana Cena (+${a.armaduraArcanaCenaBonus || 5} Def)`);
        if (a.pvTempHeroi > 0) tagsB.push(`PV Temporários (+${a.pvTempHeroi})`);
        if (a.velocidadeAtiva) tagsB.push('Velocidade (+1 Ação Padrão/Turno)');
        if (a.bonusDefTemp > 0) tagsB.push(`+${a.bonusDefTemp} Def no Turno`);
        buffsH.innerHTML = tagsB.length > 0
            ? '<strong>Efeitos Ativos:</strong> ' + tagsB.join(' · ')
            : `<span style="opacity:0.8;">Arma Equipada: <strong>${st.arma ? st.arma.nome : 'Desarmado'}</strong></span>`;
    }

    const boxEconomia = document.getElementById('arena-turn-economy-hud');
    if (boxEconomia) {
        const ehTurnoJ = a.faseTurno === 'TURNO_JOGADOR';
        const ehReacao = a.faseTurno === 'REACAO_JOGADOR';
        const corFase = ehReacao ? 'linear-gradient(90deg, #92400E, #B45309)' : (ehTurnoJ ? 'linear-gradient(90deg, #065F46, #047857)' : 'linear-gradient(90deg, #7F1D1D, #991B1B)');
        const txtFase = a.encerrado
            ? 'COMBATE ENCERRADO'
            : (ehReacao
                ? `JANELA DE REAÇÃO DA FICHA! ${priv.nomeCriatura} atacou — Escolha uma Reação da sua ficha abaixo!`
                : (ehTurnoJ
                    ? `SEU TURNO (RODADA #${a.turno}) — Use suas ações da ficha (1 Padrão + 1 Movimento ou 1 Completa + Livres)`
                    : `TURNO DA AMEAÇA (${priv.nomeCriatura}) — Executando ações da ficha...`));

        const pRest = a.acoesPadraoRestantes;
        const mRest = a.acoesMovimentoRestantes;
        const compDisp = (pRest >= 1 && mRest >= 1);

        boxEconomia.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;background:${corFase};padding:8px 12px;border-radius:8px;margin-bottom:8px;border:1.5px solid #C89D54;box-shadow:0 4px 12px rgba(0,0,0,0.4);">
                <div style="font-size:13px;font-weight:900;color:#FFFFFF;letter-spacing:0.3px;">${txtFase}</div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                    <span class="quick-pill" style="background:${pRest > 0 ? '#064E3B' : '#334155'};border-color:${pRest > 0 ? '#34D399' : '#64748B'};color:#FFF;">
                        Ação Padrão: <strong>${pRest}/${a.acoesPadraoMax}</strong>
                    </span>
                    <span class="quick-pill" style="background:${mRest > 0 ? '#1E3A8A' : '#334155'};border-color:${mRest > 0 ? '#60A5FA' : '#64748B'};color:#FFF;">
                        Ação Movimento: <strong>${mRest}/${a.acoesMovimentoMax}</strong>
                    </span>
                    <span class="quick-pill" style="background:${compDisp ? '#581C87' : '#334155'};border-color:${compDisp ? '#C084FC' : '#64748B'};color:#FFF;">
                        Completa: <strong>${compDisp ? 'Disponível' : 'Indisponível'}</strong>
                    </span>
                    <span class="quick-pill" style="background:${a.reacaoDisponivel ? '#78350F' : '#334155'};border-color:${a.reacaoDisponivel ? '#FACC15' : '#64748B'};color:#FEF08A;">
                        Reação da Ficha: <strong>${a.reacaoDisponivel ? 'Pronta' : 'Usada'}</strong>
                    </span>
                </div>
            </div>
        `;
    }

    const boxCriaturaAcoes = document.getElementById('arena-creature-actions-bar');
    if (boxCriaturaAcoes && priv.repertorioAcoes) {
        const btnsCriatura = priv.repertorioAcoes.map((ac, idx) =>
            `<button type="button" class="quick-pill" style="cursor:pointer;background:#450A0A;border-color:#F87171;color:#FECACA;font-size:11px;padding:4px 8px;" onclick="executarTurnoDaCriaturaArenaJS(${idx})" title="${ac.descricao}">
                ${ac.icone} Testar: ${ac.nome.slice(0, 38)}
            </button>`
        ).join(' ');
        boxCriaturaAcoes.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                <span style="font-size:11.5px;font-weight:800;color:#FCA5A5;">Ações Oficiais da Ficha de ${priv.nomeCriatura}:</span>
                <div style="display:flex;gap:5px;flex-wrap:wrap;">${btnsCriatura}</div>
            </div>
        `;
    }

    const boxReacaoModal = document.getElementById('arena-reaction-modal-box');
    if (boxReacaoModal) {
        if (a.faseTurno === 'REACAO_JOGADOR' && a.ataqueInimigoPendente) {
            const pend = a.ataqueInimigoPendente;
            const listaReac = listarReacoesDisponiveisHeroiJS(st, a, pend);
            const botoesReacHTML = listaReac.map((r, idxR) => {
                const dis = !r.disponivel ? 'disabled style="opacity:0.45;cursor:not-allowed;margin:0;padding:8px;"' : `style="margin:0;padding:8px;background:${r.destaque ? 'linear-gradient(135deg,#15803D,#166534)' : 'linear-gradient(135deg,#1E3A8A,#1D4ED8)'};border:1.5px solid ${r.destaque ? '#4ADE80' : '#93C5FD'};"`;
                return `<div style="display:flex;flex-direction:column;gap:4px;background:rgba(15,23,42,0.75);padding:6px;border-radius:8px;border:1px solid rgba(250,204,21,0.35);">
                    <label style="display:flex;align-items:center;gap:6px;font-size:11.5px;font-weight:800;color:#FEF08A;cursor:pointer;margin:0;">
                        <input type="checkbox" class="chk-reacao-combo-item" value="${r.id}" data-custo-pm="${r.custoPM || 0}" ${!r.disponivel ? 'disabled' : (r.destaque && idxR < 2 ? 'checked' : '')} onchange="atualizarResumoComboReacaoArenaJS()" style="width:auto;min-height:auto;">
                        <span>Marcar p/ Combar (${r.custoPM || 0} PM)</span>
                    </label>
                    <button type="button" class="btn btn-ai" ${dis} onclick="resolverReacaoJogadorArenaJS('${r.id}')">
                        <div><strong>${r.nome}</strong></div>
                        <div style="font-size:10.5px;font-weight:500;color:#E2E8F0;margin-top:2px;">${r.efeitoResumo}</div>
                    </button>
                </div>`;
            }).join('');

            boxReacaoModal.style.display = 'block';
            boxReacaoModal.innerHTML = `
                <div style="background:linear-gradient(135deg,#2E1005,#5C200B);border:2px solid #FACC15;border-radius:10px;padding:12px;margin-top:10px;box-shadow:0 0 22px rgba(250,204,21,0.45);">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
                        <strong style="font-size:14px;color:#FEF08A;">REAÇÕES & COMBO DEFENSIVO DA SUA FICHA — ${priv.nomeCriatura.toUpperCase()} ESTÁ ATACANDO!</strong>
                        <span class="quick-pill" style="background:#7F1D1D;border-color:#F87171;color:#FFF;">Seus PM: ${a.pmHeroi} PM (Limite/Magia: ${calcularLimitePMMagiaFichaJS(st)} PM)</span>
                    </div>
                    <div style="background:rgba(0,0,0,0.45);border-left:4px solid #F87171;padding:8px 10px;border-radius:6px;font-size:12.5px;color:#FFF;margin-bottom:10px;">
                        ${pend.anuncioHTML}
                    </div>
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;background:rgba(20,83,45,0.55);border:1.5px solid #4ADE80;border-radius:8px;padding:8px 10px;margin-bottom:10px;">
                        <div style="font-size:12px;color:#ECFDF5;">
                            <strong>Combar Múltiplas Reações Simultâneas:</strong> marque 2 ou mais caixas abaixo (ex.: <em>Armadura Arcana / Proteção Divina</em> para subir Defesa/Resistência + <em>Campo de Força / Durão</em> para reduzir o dano) e clique no botão ao lado!
                        </div>
                        <button type="button" id="btn-executar-combo-reacoes" class="btn btn-ai" style="width:auto;margin:0;padding:8px 14px;background:linear-gradient(135deg,#B45309,#D97706);border:2px solid #FEF08A;font-size:12px;" onclick="resolverReacaoJogadorArenaJS('COMBO_SELECIONADO')">
                            Executar Combo de Reações Marcadas
                        </button>
                    </div>
                    <div style="font-size:12px;font-weight:800;color:#FDE68A;margin-bottom:6px;">
                        Clique direto em uma reação individual OU marque várias caixas para combar:
                    </div>
                    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(230px, 1fr));gap:8px;">
                        ${botoesReacHTML}
                        <button type="button" class="btn btn-save" style="margin:0;padding:8px;background:#334155;color:#F8FAFC;border:1px solid #94A3B8;" onclick="resolverReacaoJogadorArenaJS('NENHUMA')">
                            <div><strong>⏭Não Usar Reação (0 PM)</strong></div>
                            <div style="font-size:10.5px;font-weight:400;color:#CBD5E1;margin-top:2px;">Resolver c/ Defesa/Resistência passiva da ficha (${pend.danoPrevisto} dano previsto)</div>
                        </button>
                    </div>
                </div>
            `;
            setTimeout(() => atualizarResumoComboReacaoArenaJS(), 20);
        } else {
            boxReacaoModal.style.display = 'none';
            boxReacaoModal.innerHTML = '';
        }
    }

    const elNomeC = document.getElementById('arena-nome-criatura');
    const elDefC = document.getElementById('arena-badge-def-criatura');
    const barPvC = document.getElementById('arena-bar-pv-criatura');
    const txtPvC = document.getElementById('arena-txt-pv-criatura');
    const svgC = document.getElementById('arena-svg-criatura');
    const lblTurno = document.getElementById('arena-lbl-turno');

    if (lblTurno) lblTurno.textContent = a.encerrado ? 'Fim' : `Turno #${a.turno}`;
    if (elNomeC) elNomeC.textContent = `${priv.nomeCriatura} (ND ${priv.ndTexto} · ${priv.grupoCap7})`;
    const elSubC = document.getElementById('arena-sub-criatura');
    if (elSubC) elSubC.textContent = `${priv.tipoTamanho} · ${priv.paginaRef} · ${priv.ataquesResumo.slice(0, 48)}`;
    if (svgC) svgC.textContent = a.papelCriatura === 'Lacaio' ? '' : (a.papelCriatura === 'Especial' ? '' : '');

    const pctPvC = Math.max(0, Math.min(100, (priv.pvAtual / Math.max(1, priv.pvMax)) * 100));
    if (barPvC) barPvC.style.width = pctPvC + '%';
    if (txtPvC) {
        txtPvC.textContent = priv.pvAtual <= 0
            ? `DERROTADA! (${Math.round(cr.danoCausadoAcumulado)} dano acumulado)`
            : `${Math.round(pctPvC)}% Vitalidade (${Math.round(cr.danoCausadoAcumulado)} dano sofrido)`;
    }

    const defEstStr = cr.defMin >= cr.defMax
        ? `Exata: ${cr.defMin}!`
        : (cr.defMin === 10 && cr.defMax === 65 ? '??? [10..65]' : `[${cr.defMin} .. ${cr.defMax}]`);
    if (elDefC) elDefC.textContent = `Def: ${defEstStr}`;

    const fogDef = document.getElementById('fog-def-est');
    const fogRes = document.getElementById('fog-res-est');
    const fogDano = document.getElementById('fog-dano-est');
    if (fogDef) fogDef.innerHTML = `<strong>${defEstStr}</strong>`;
    if (fogRes) {
        fogRes.innerHTML = cr.testesMagia > 0
            ? `Testada ${cr.testesMagia}x Falhou em <strong>${Math.round((cr.falhasMagia / cr.testesMagia) * 100)}%</strong> dos testes contra CD ${st.est.cdMagia}`
            : 'Nenhuma magia testada ainda';
    }
    if (fogDano) {
        if (cr.golpesCriaturaObservados.length > 0) {
            const med = (cr.golpesCriaturaObservados.reduce((s, x) => s + x, 0) / cr.golpesCriaturaObservados.length).toFixed(1);
            fogDano.innerHTML = `Média empírica de <strong>${med} dano/acerto</strong> (${cr.golpesCriaturaObservados.length} golpes observados)`;
        } else {
            fogDano.innerHTML = 'Aguardando ataque acertado da criatura';
        }
    }
    const fxAtivoAgora = (window.__EFEITO_ARENA_ATIVO__ && (Date.now() - window.__EFEITO_ARENA_ATIVO__.timestamp < 1000))
        ? window.__EFEITO_ARENA_ATIVO__.tipo
        : null;
    renderizarPalcoJRPG(st, a, fxAtivoAgora);
}

function registrarLinhaLogArena(htmlLinha) {
    const logBox = document.getElementById('arena-combat-log');
    if (!logBox) return;
    const div = document.createElement('div');
    div.className = 'item-row';
    div.style.marginBottom = '6px';
    div.innerHTML = htmlLinha;
    logBox.prepend(div);
}

function dispararAnimacaoCardArena(idCard, classeAnim) {
    const el = document.getElementById(idCard);
    if (!el) return;
    el.classList.remove('hit-shake', 'attack-lunge');
    setTimeout(() => el.classList.add(classeAnim), 10);
}

// ==============================================================================
// CONJURAÇÃO DE MAGIA DA FICHA COM OS APRIMORAMENTOS SELECIONADOS PELO JOGADOR
// ==============================================================================
function conjurarMagiaComAprimoramentosArenaJS() {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    if (a.encerrado) reiniciarCombateArenaVisual();
    const st = garantirEstadoFichaParaArena();
    if (!st.magias || st.magias.length === 0) {
        exibirMensagemStatus('Este personagem não possui magias na ficha.');
        return;
    }
    if (a.faseTurno === 'REACAO_JOGADOR' && a.ataqueInimigoPendente) {
        resolverReacaoJogadorArenaJS('NENHUMA');
        if (a.encerrado) return;
    }

    const selMag = document.getElementById('arena-sel-magia-ficha');
    const selAprim = document.getElementById('arena-sel-aprimoramento-pm');
    const chkAcelerada = document.getElementById('chk-arena-magia-acelerada');
    const magObj = (st.magias || []).find(m => m.id_magia === (selMag ? selMag.value : '') || m.nome === (selMag ? selMag.value : '')) || st.magias[0];
    const addPM = selAprim ? parseInt(selAprim.value || '0', 10) : 0;
    const opcoes = calcularOpcoesAprimoramentoMagiaJS(magObj, st, a.pmHeroi);
    const op = opcoes.find(x => x.addPM === addPM) || opcoes[0];

    const todosPods = [
        ...((st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ].map(p => (p.nome || '').toLowerCase());
    const usaAcelerada = Boolean(chkAcelerada && chkAcelerada.checked && todosPods.includes('magia acelerada'));
    const custoFinal = op.custoTotal + (usaAcelerada ? 4 : 0);

    if (a.pmHeroi < custoFinal) {
        exibirMensagemStatus(`PM insuficientes para conjurar ${magObj.nome} com +${op.addPM} PM de aprimoramento (requer ${custoFinal} PM, você tem ${a.pmHeroi} PM).`);
        return;
    }

    const exLow = (magObj.execucao || 'Padrão').toLowerCase();
    const ehLivre = usaAcelerada || exLow.includes('livre') || op.ehConcentracao;
    const ehMovimento = !ehLivre && exLow.includes('movimento');
    const ehCompleta = !ehLivre && exLow.includes('completa');

    if (ehCompleta) {
        if (a.acoesPadraoRestantes <= 0 || a.acoesMovimentoRestantes <= 0) {
            exibirMensagemStatus(`${magObj.nome} tem execução Completa (requer 1 Ação Padrão + 1 Ação de Movimento disponíveis)!`);
            return;
        }
        a.acoesPadraoRestantes -= 1;
        a.acoesMovimentoRestantes -= 1;
    } else if (ehMovimento) {
        if (a.acoesMovimentoRestantes <= 0) {
            exibirMensagemStatus(`${magObj.nome} tem execução de Movimento e você já usou sua Ação de Movimento neste turno!`);
            return;
        }
        a.acoesMovimentoRestantes -= 1;
    } else if (!ehLivre) {
        if (a.acoesPadraoRestantes <= 0) {
            exibirMensagemStatus(`Você já gastou sua Ação Padrão neste turno! Encerre o turno ou use Magia Acelerada (se tiver na ficha).`);
            return;
        }
        a.acoesPadraoRestantes -= 1;
    }

    a.pmHeroi -= custoFinal;
    const priv = a._privadoCriatura;
    const cr = a.crencaIA;
    const dadosVisuais = [];
    const tagAprimStr = op.addPM > 0 ? ` [+${op.addPM} PM em Aprimoramentos · Total ${custoFinal} PM]` : ` [Base ${custoFinal} PM]`;

    // Caso 1: Concentração de Combate (Livro p. 185 — Livre: próximo ataque rola 2d20 e usa o melhor resultado!)
    if (op.ehConcentracao) {
        a.concentracaoCombateAtiva = true;
        tocarSomJRPG('MAGIA');
        dispararPopupDanoJRPG('2d20 MELHOR ATIVO!', '#38BDF8', 'HEROI', 'SHIELD', `${st.nome} conjurou ${magObj.nome}${tagAprimStr}: próximo ataque rola 2d20 e seleciona o MELHOR!`);
        registrarLinhaLogArena(`<strong>[Turno #${a.turno} · ${ehLivre ? 'Ação Livre' : 'Conjuração'}]</strong> <strong>${magObj.nome}${tagAprimStr} (Livro p. 185):</strong> ${op.descNivel}.`);
        atualizarPlacarVisualArena();
        return;
    }

    // Caso 2: Velocidade (Livro p. 210 — +1 Ação Padrão ou Movimento por turno)
    if (op.ehVelocidade) {
        a.velocidadeAtiva = true;
        a.acoesPadraoRestantes += 1;
        a.acoesPadraoMax = 2;
        tocarSomJRPG('MAGIA');
        dispararPopupDanoJRPG('VELOCIDADE (+1 PADRÃO)!', '#FACC15', 'HEROI', 'SHIELD', `${st.nome} conjurou ${magObj.nome}${tagAprimStr}: recebe +1 Ação Padrão ou Movimento por turno!`);
        registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Conjuração]</strong> <strong>${magObj.nome}${tagAprimStr} (Livro p. 210):</strong> ${op.descNivel}.`);
        atualizarPlacarVisualArena();
        return;
    }

    // Caso 3: Magias de Defesa na Cena (Armadura Arcana, Escudo da Fé, Vestimenta da Fé)
    if (op.ehBuffDefesa) {
        a.armaduraArcanaCena = true;
        a.armaduraArcanaCenaBonus = Math.max(a.armaduraArcanaCenaBonus || 0, op.bonusFixo || 5);
        tocarSomJRPG('MAGIA');
        dispararPopupDanoJRPG(`+${op.bonusFixo} DEFESA!`, '#38BDF8', 'HEROI', 'SHIELD', `${st.nome} conjurou ${magObj.nome}${tagAprimStr}: +${op.bonusFixo} na Defesa!`);
        registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Conjuração]</strong> <strong>${magObj.nome}${tagAprimStr}:</strong> ${op.descNivel}.`);
        atualizarPlacarVisualArena();
        checarFimAutomaticoTurnoJogadorJS();
        return;
    }

    // Caso 4: Magias de PV Temporários (Campo de Força Cena, Vitalidade Fantasma)
    if (op.ehBuffPVTemp) {
        let ganhoTemp = op.bonusFixo || 0;
        if (op.qtdDados > 0) {
            for (let i = 0; i < op.qtdDados; i++) {
                const vD = Math.floor(Math.random() * op.facesDado) + 1;
                ganhoTemp += vD;
                dadosVisuais.push({ faces: op.facesDado, valor: vD, critico: vD === op.facesDado, cor: '#7C3AED', label: `PV Temp d${op.facesDado}` });
            }
        }
        a.pvTempHeroi += ganhoTemp;
        if (dadosVisuais.length > 0) {
            animarBandejaDadosVisual(dadosVisuais, `<strong>${magObj.nome}${tagAprimStr}</strong>: Recebeu <strong>+${ganhoTemp} PV Temporários</strong>!`, `Turno #${a.turno} — ${magObj.nome}`);
        }
        tocarSomJRPG('MAGIA');
        dispararPopupDanoJRPG(`+${ganhoTemp} PV TEMP!`, '#C084FC', 'HEROI', 'SHIELD', `${st.nome} conjurou ${magObj.nome}${tagAprimStr}: +${ganhoTemp} PV Temporários!`);
        registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Conjuração]</strong> <strong>${magObj.nome}${tagAprimStr}:</strong> Recebeu <strong>+${ganhoTemp} PV Temporários</strong>!`);
        atualizarPlacarVisualArena();
        checarFimAutomaticoTurnoJogadorJS();
        return;
    }

    // Caso 5: Magia de Cura (Curar Ferimentos, Sopro da Salvação)
    if (op.ehCura) {
        let somaCura = op.bonusFixo || 0;
        for (let i = 0; i < Math.min(10, op.qtdDados); i++) {
            const vC = Math.floor(Math.random() * op.facesDado) + 1;
            somaCura += vC;
            dadosVisuais.push({ faces: op.facesDado, valor: vC, critico: vC === op.facesDado, cor: '#15803D', label: `Cura d${op.facesDado}` });
        }
        a.pvHeroi = Math.min(a.pvHeroiMax, a.pvHeroi + somaCura);
        animarBandejaDadosVisual(dadosVisuais, `<strong>${magObj.nome}${tagAprimStr}</strong>: Curou <strong>+${somaCura} PV</strong> (${op.qtdDados}d${op.facesDado}+${op.bonusFixo})!`, `Turno #${a.turno} — Conjuração de Cura`);
        tocarSomJRPG('MAGIA');
        dispararPopupDanoJRPG(`+${somaCura} PV!`, '#4ADE80', 'HEROI', 'SHIELD', `${st.nome} conjurou ${magObj.nome}${tagAprimStr}: recuperou +${somaCura} PV!`);
        registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Conjuração]</strong> <strong>${magObj.nome}${tagAprimStr}:</strong> Recuperou <strong>+${somaCura} PV</strong> (${op.descNivel})!`);
        atualizarPlacarVisualArena();
        checarFimAutomaticoTurnoJogadorJS();
        return;
    }

    // Caso 6: Magias Ofensivas / Controle com os Dados Exatos dos Aprimoramentos Escolhidos!
    const semTesteResistencia = !magObj.resistencia || /nenhuma/i.test(magObj.resistencia);
    let passouResInimigo = false;
    let d20Res = 0;
    if (!semTesteResistencia) {
        d20Res = Math.floor(Math.random() * 20) + 1;
        const totRes = d20Res + priv.resMedia;
        passouResInimigo = (d20Res === 20) || (d20Res !== 1 && totRes >= st.est.cdMagia);
        cr.testesMagia += 1;
        if (!passouResInimigo) cr.falhasMagia += 1;
        dadosVisuais.push({
            faces: 20,
            valor: d20Res,
            critico: !passouResInimigo,
            falhaCritica: passouResInimigo,
            cor: '#581C87',
            label: `Res. Inimigo d20(${d20Res}) vs CD ${st.est.cdMagia}`
        });
    }

    const qDados = Math.max(2, op.qtdDados || 4);
    const fDado = op.facesDado || 6;
    let somaDadosMagia = 0;
    for (let i = 0; i < Math.min(12, qDados); i++) {
        const vD = Math.floor(Math.random() * fDado) + 1;
        somaDadosMagia += vD;
        if (i < 8) {
            dadosVisuais.push({ faces: fDado, valor: vD, critico: vD === fDado, cor: '#7C2D12', label: `d${fDado} #${i+1}` });
        }
    }
    const bArcanoBatalha = todosPods.includes('arcano de batalha') ? Math.max(0, st.est.finais[(st.est.infoMagia && st.est.infoMagia.sigla) || 'INT'] || 0) : 0;
    const danoParcMag = Math.round(infoMPMag.bonusDanoMagiaMedia || 0);
    const danoBrutoMag = somaDadosMagia + (op.bonusFixo || 0) + bArcanoBatalha + danoParcMag;
    const danoFinalMag = semTesteResistencia
        ? danoBrutoMag
        : Math.round(danoBrutoMag * (passouResInimigo ? 0.5 : 1.0));

    priv.pvAtual = Math.max(0, priv.pvAtual - danoFinalMag);
    cr.danoCausadoAcumulado += danoFinalMag;
    if (typeof processarDanoEmEncontroMultiploArenaJS === 'function') {
        processarDanoEmEncontroMultiploArenaJS(a, danoFinalMag, true, magObj.nome);
    }
    dispararAnimacaoCardArena('arena-card-heroi', 'attack-lunge');
    dispararAnimacaoCardArena('arena-card-criatura', 'hit-shake');
    const nmMagLow = (magObj.nome || '').toLowerCase();
    const somMagiaEsp = (nmMagLow.includes('fogo') || nmMagLow.includes('chamas'))
        ? 'MAGIA_FOGO'
        : ((nmMagLow.includes('relâmpago') || nmMagLow.includes('chocante'))
            ? 'MAGIA_RAIO'
            : ((nmMagLow.includes('vampírico') || nmMagLow.includes('ferimentos') || nmMagLow.includes('trevas')) ? 'MAGIA_TREVAS' : 'MAGIA'));
    const animMagiaEsp = somMagiaEsp === 'MAGIA_FOGO'
        ? 'ANIM_MAGIA_FOGO'
        : (somMagiaEsp === 'MAGIA_RAIO' ? 'ANIM_MAGIA_RAIO' : 'ANIM_MAGIA_ARCANA');
    tocarSomJRPG(somMagiaEsp);
    if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function') {
        const alvoM = (a.listaCriaturas || [])[a.alvoFocoIdx || 0] || { gx: 4, gy: 2 };
        dispararAnimacaoCoreografadaPalco2DJS({
            tipo: somMagiaEsp === 'MAGIA_RAIO' ? 'MAGIA_RAIO' : 'MAGIA_FOGO',
            origem: a.posHeroi || { gx: 2, gy: 2 },
            destino: { gx: alvoM.gx || 4, gy: alvoM.gy || 2 },
            label: `${magObj.nome}: -${danoFinalMag} PV`
        });
    }
    dispararPopupDanoJRPG(`-${danoFinalMag} PV!`, '#FACC15', 'INIMIGO', animMagiaEsp, `${st.nome} conjurou ${magObj.nome}${tagAprimStr}: ${danoFinalMag} de dano!`);

    const strResTxt = semTesteResistencia
        ? 'Acerto Infalível (Sem Teste de Resistência!)'
        : `Criatura rolou d20(${d20Res}) vs CD ${st.est.cdMagia} ${passouResInimigo ? 'Resistiu (50% dano)' : 'FALHOU NA RESISTÊNCIA (100% DANO!)'}`;

    const formulaMesa = `<strong>${magObj.nome}${tagAprimStr}</strong>: ${qDados}d${fDado}(${somaDadosMagia})${op.bonusFixo ? '+' + op.bonusFixo : ''}${bArcanoBatalha ? '+' + bArcanoBatalha + '(Arcano de Batalha)' : ''} = ${danoBrutoMag} bruto | ${strResTxt} <span style="color:#4ADE80;font-size:17px;">${danoFinalMag} de dano!</span>`;
    let resumoMag = `Conjurou <strong>${magObj.nome}</strong>${tagAprimStr} (${op.descNivel}): causou <strong>${danoFinalMag} de dano</strong> (${strResTxt})!`;

    if (priv.pvAtual <= 0) {
        a.encerrado = true;
        setTimeout(() => tocarSomJRPG('VITORIA'), 320);
        resumoMag += `<br><strong>VITÓRIA DO HERÓI NO TURNO #${a.turno}!</strong> ${priv.nomeCriatura} foi derrotada!`;
    } else {
        resumoMag += `<br><span style="color:#15803D;font-weight:700;">↳ Restam no seu turno: ${a.acoesPadraoRestantes} Ação Padrão e ${a.acoesMovimentoRestantes} Ação de Movimento.</span>`;
    }

    animarBandejaDadosVisual(dadosVisuais, formulaMesa, `Turno #${a.turno} — ${magObj.nome} (+${op.addPM} PM Aprimoramentos)`);
    registrarLinhaLogArena(`<strong>[Turno #${a.turno} · SEU TURNO]</strong> ${resumoMag}`);
    atualizarPlacarVisualArena();
    checarFimAutomaticoTurnoJogadorJS();
}

function executarAcaoCombateVisual(tipoAcao) {
    try {
        const stg = document.getElementById('jrpg-battle-stage');
        if (stg && typeof stg.scrollIntoView === 'function') {
            const rect = stg.getBoundingClientRect();
            if (rect.top < -40 || rect.bottom > window.innerHeight + 60) {
                stg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        }
    } catch(e) {}
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    if (a.encerrado) {
        reiniciarCombateArenaVisual();
    }
    const st = garantirEstadoFichaParaArena();

    if (a.faseTurno === 'REACAO_JOGADOR' && a.ataqueInimigoPendente) {
        resolverReacaoJogadorArenaJS('NENHUMA');
        if (a.encerrado) return;
    }

    if (tipoAcao === 'MAGIA_LIMITE') {
        conjurarMagiaComAprimoramentosArenaJS();
        return;
    }

    const resDano = calcularResumoDanoJS(st.nivel, st.classe, st.est, st.poderes, st.itens, st.arma, st.escudo, st.magias, st.caminhoArcanista);
    const priv = a._privadoCriatura;
    const cr = a.crencaIA;
    const todosPods = [
        ...((st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ];
    const nomesPodsLow = todosPods.map(p => (p.nome || '').toLowerCase());

    if (tipoAcao === 'SURTO_HEROICO_LIVRE') {
        if (!nomesPodsLow.includes('surto heroico')) {
            exibirMensagemStatus('Este personagem não possui o poder Surto Heroico na ficha.');
            return;
        }
        if (a.pmHeroi < 5) {
            exibirMensagemStatus('Requer 5 PM para ativar Surto Heroico (+1 Ação Padrão extra).');
            return;
        }
        a.pmHeroi -= 5;
        a.acoesPadraoRestantes += 1;
        a.acoesPadraoMax += 1;
        tocarSomJRPG('CRITICO');
        dispararPopupDanoJRPG('+1 AÇÃO PADRÃO!', '#FACC15', 'HEROI', 'SHIELD', `${st.nome} ativou Surto Heroico (-5 PM, Livro p. 129): ganhou +1 Ação Padrão neste turno!`);
        registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Ação Livre da Ficha]</strong> <strong>Surto Heroico (-5 PM, Livro p. 129):</strong> Recebeu <strong>+1 Ação Padrão extra</strong> neste turno!`);
        atualizarPlacarVisualArena();
        return;
    }

    if (tipoAcao === 'MOVIMENTO_MIRAR') {
        if (a.acoesMovimentoRestantes <= 0) {
            exibirMensagemStatus('Você já gastou sua Ação de Movimento neste turno!');
            return;
        }
        a.acoesMovimentoRestantes -= 1;
        const chkMira = document.getElementById('chk-cap5-mira');
        if (chkMira) chkMira.checked = true;
        const temMiraApurada = nomesPodsLow.includes('mira apurada');
        tocarSomJRPG('DADOS');
        const descMirar = temMiraApurada
            ? 'Anula a penalidade de -5 por disparar em oponente engajado (p. 235) E concede +2 no Ataque e +2 na Margem de Ameaça neste turno pelo poder Mira Apurada (p. 127)!'
            : 'Anula a penalidade de -5 em Pontaria contra oponente engajado em combate corpo a corpo neste turno (Regra Oficial p. 235 — para receber +2 no ataque e na margem de ameaça, é necessário o poder Mira Apurada, p. 127).';
        dispararPopupDanoJRPG(temMiraApurada ? 'MIRA APURADA (+2 ATQ/CRÍT)!' : 'MIRAR (SEM PENALIDADE -5)!', '#38BDF8', 'HEROI', 'SHIELD', `${st.nome} usou Ação de Movimento: Mirar (Livro p. 235)!`);
        registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Ação de Movimento]</strong> <strong>Mirar (Cap. 5, p. 235${temMiraApurada ? ' + Poder Mira Apurada p. 127' : ''}):</strong> ${descMirar} Ainda resta <strong>${a.acoesPadraoRestantes} Ação Padrão</strong>!`);
        atualizarPlacarVisualArena();
        return;
    }

    if (tipoAcao === 'MOVIMENTO_POSICIONAR_FLANQUEAR') {
        if (a.acoesMovimentoRestantes <= 0) {
            exibirMensagemStatus('Você já gastou sua Ação de Movimento neste turno!');
            return;
        }
        a.acoesMovimentoRestantes -= 1;
        const subArmaM = st.arma ? ((st.arma.subcategoria || '') + ' ' + (st.arma.nome || '')).toLowerCase() : '';
        const ehDistM = /distância|distancia|fogo|arco|besta|mosquete|pistola|funda|azagaia/.test(subArmaM);
        const temParceiroAliado = document.getElementById('chk-cap5-aliado-oposto')?.checked || nomesPodsLow.some(n => n.includes('companheiro animal') || n.includes('parceiro'));
        const chkFlanq = document.getElementById('chk-cap5-flanqueando');
        if (!ehDistM && temParceiroAliado && chkFlanq) {
            chkFlanq.checked = true;
            tocarSomJRPG('DADOS');
            dispararPopupDanoJRPG(`FLANQUEANDO (+2 ATQ)!`, '#4ADE80', 'HEROI', 'SHIELD', `${st.nome} movimentou-se (${st.est.deslocamento}m) para o lado oposto do Aliado e está Flanqueando (+2 Ataque corpo a corpo, Livro p. 239)!`);
            registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Ação de Movimento]</strong> <strong>Movimentar-se (${st.est.deslocamento}m — Cap. 5, p. 235 & Flanquear p. 239):</strong> Posicionou-se no lado oposto ao seu Aliado/Parceiro engajado em corpo a corpo, recebendo <strong>+2 nos testes de ataque corpo a corpo</strong>! Ainda resta <strong>${a.acoesPadraoRestantes} Ação Padrão</strong>!`);
        } else {
            if (chkFlanq && ehDistM) chkFlanq.checked = false;
            tocarSomJRPG('DADOS');
            const msgPos = ehDistM
                ? `Recuou/posicionou-se em Alcance Curto (${st.est.deslocamento}m). (Nota Oficial p. 239: não é possível flanquear com ataques à distância).`
                : `Avançou/posicionou-se em alcance Corpo a Corpo (${st.est.deslocamento}m). (Nota Oficial p. 239: para Flanquear [+2 Atq corpo a corpo], marque 'Aliado no Lado Oposto' na barra do Cap. 5).`;
            dispararPopupDanoJRPG(`MOVIMENTAR (${st.est.deslocamento}m)!`, '#38BDF8', 'HEROI', 'SHIELD', `${st.nome} usou Movimentar-se (${st.est.deslocamento}m, Livro p. 235)!`);
            registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Ação de Movimento]</strong> <strong>Movimentar-se (${st.est.deslocamento}m — Cap. 5, p. 235):</strong> ${msgPos} Ainda resta <strong>${a.acoesPadraoRestantes} Ação Padrão</strong>!`);
        }
        atualizarPlacarVisualArena();
        return;
    }

    if (tipoAcao === 'MOVIMENTO_POCAO_MANA') {
        const itemCons = (st.itens || []).find(it => /bálsamo|balsamo|essência|essencia|poção|pocao|alquímico/i.test(it.nome || ''));
        if (!itemCons) {
            exibirMensagemStatus('Este personagem não possui Bálsamo Restaurador ou Essência de Mana no inventário da ficha.');
            return;
        }
        if (a.acoesMovimentoRestantes <= 0) {
            exibirMensagemStatus('Você já gastou sua Ação de Movimento neste turno!');
            return;
        }
        a.acoesMovimentoRestantes -= 1;
        const ehEssencia = /essência|essencia/i.test(itemCons.nome);
        const d1 = Math.floor(Math.random() * 4) + 1;
        const d2 = Math.floor(Math.random() * 4) + 1;
        if (ehEssencia) {
            const recPM = d1;
            a.pmHeroi = Math.min(a.pmHeroiMax, a.pmHeroi + recPM);
            animarBandejaDadosVisual([{ faces: 4, valor: d1, critico: d1 === 4, cor: '#0284C7', label: `Essência de Mana 1d4: ${d1}` }], `<strong>Manipular Item — ${itemCons.nome} (Movimento, p. 160/235)</strong>: Recuperou <strong>+${recPM} PM</strong>!`, `Turno #${a.turno} — ${itemCons.nome}`);
            dispararPopupDanoJRPG(`+${recPM} PM!`, '#38BDF8', 'HEROI', 'SHIELD', `${st.nome} usou ${itemCons.nome} (+${recPM} PM)!`);
            registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Ação de Movimento]</strong> <strong>Manipular Item (${itemCons.nome}, p. 235):</strong> Recuperou <strong>+${recPM} PM</strong> (1d4).`);
        } else {
            const recPV = d1 + d2;
            a.pvHeroi = Math.min(a.pvHeroiMax, a.pvHeroi + recPV);
            animarBandejaDadosVisual([
                { faces: 4, valor: d1, critico: d1 === 4, cor: '#15803D', label: `Bálsamo d4: ${d1}` },
                { faces: 4, valor: d2, critico: d2 === 4, cor: '#15803D', label: `Bálsamo d4: ${d2}` }
            ], `<strong>Manipular Item — ${itemCons.nome} (Movimento, p. 160/235)</strong>: Recuperou <strong>+${recPV} PV</strong> (2d4)!`, `Turno #${a.turno} — ${itemCons.nome}`);
            dispararPopupDanoJRPG(`+${recPV} PV!`, '#4ADE80', 'HEROI', 'SHIELD', `${st.nome} usou ${itemCons.nome} (+${recPV} PV)!`);
            registrarLinhaLogArena(`<strong>[Turno #${a.turno} · Ação de Movimento]</strong> <strong>Manipular Item (${itemCons.nome}, p. 235):</strong> Recuperou <strong>+${recPV} PV</strong> (2d4).`);
        }
        atualizarPlacarVisualArena();
        return;
    }

    // Verificação de Orçamento de Ações (Padrão, Movimento p/ Finta Aprimorada ou Completa)
    const selGPOrc = document.getElementById('arena-sel-golpe-pessoal');
    const cfgGPOrc = selGPOrc ? selGPOrc.value : 'BRUTAL_ELEM_PRECISO';
    const gpUsaLentoCompleta = (tipoAcao === 'GOLPE_PESSOAL' && cfgGPOrc === 'LETAL_DESTRUIDOR_BRUTAL_LENTO');
    const exigeAcaoCompleta = (tipoAcao === 'INVESTIDA_COMPLETA' || gpUsaLentoCompleta);
    const fintaComoMovimento = (tipoAcao === 'FINTAR_DESPREVENIDO' && nomesPodsLow.includes('finta aprimorada'));
    const nrAct = (st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : '';
    const racialComoMovimento = (tipoAcao === 'HABILIDADE_RACIAL_ATIVA' && (nrAct === 'medusa' || nrAct === 'dahllan'));

    if (exigeAcaoCompleta) {
        if (a.acoesPadraoRestantes <= 0 || a.acoesMovimentoRestantes <= 0) {
            exibirMensagemStatus('Esta ação exige uma AÇÃO COMPLETA (1 Ação Padrão + 1 Ação de Movimento disponíveis — Livro p. 235)!');
            return;
        }
        a.acoesPadraoRestantes -= 1;
        a.acoesMovimentoRestantes -= 1;
    } else if (fintaComoMovimento || racialComoMovimento) {
        if (a.acoesMovimentoRestantes <= 0) {
            exibirMensagemStatus('Você já usou sua Ação de Movimento neste turno!');
            return;
        }
        a.acoesMovimentoRestantes -= 1;
    } else {
        if (a.acoesPadraoRestantes <= 0) {
            exibirMensagemStatus('Você já gastou sua Ação Padrão neste turno! Use uma Ação de Movimento/Livre da ficha ou clique em "⏭Encerrar Meu Turno".');
            return;
        }
        a.acoesPadraoRestantes -= 1;
    }

    const dadosVisuais = [];
    let formulaMesa = '';
    let danoCausadoHeroi = 0;
    let resumoAcaoHeroi = '';

    const estiloArmaAtiva = (typeof identificarEstiloArmaJS === 'function')
        ? identificarEstiloArmaJS(st.arma, st.escudo, todosPods) : 'UMA_ARMA_ESGRIMA';
    const ehDistArmaAtiva = ['ARQUERIA_DISPARO', 'ARREMESSO'].includes(estiloArmaAtiva);
    const ehDuasMaosAtiva = ['DUAS_MAOS', 'ARMA_LONGA_HASTE'].includes(estiloArmaAtiva);
    const ehUmaMaoLivreAtiva = (estiloArmaAtiva === 'UMA_ARMA_ESGRIMA');

    // Cálculo limpo do Bônus de Ataque Passivo (sem pré-embutir Ataque Poderoso, Fúria ou Golpe Divino para evitar duplicação nos combos!)
    let bonusAtqBase = ehDistArmaAtiva ? (st.est.bonusPericias['Pontaria'] || 0) : (st.est.bonusPericias['Luta'] || 0);
    if (!ehDistArmaAtiva && nomesPodsLow.includes('acuidade com arma') && ['UMA_ARMA_ESGRIMA', 'DUAS_ARMAS'].includes(estiloArmaAtiva) && st.est.finais.DES > st.est.finais.FOR) {
        bonusAtqBase += (st.est.finais.DES - st.est.finais.FOR);
    }
    if (nomesPodsLow.includes('foco em arma')) bonusAtqBase += 2;
    if (nomesPodsLow.includes('armas da ambição')) bonusAtqBase += 1;
    if (nomesPodsLow.includes('estilo de uma arma') && ehUmaMaoLivreAtiva) bonusAtqBase += 2;
    if (nomesPodsLow.includes('estilo de arma longa') && estiloArmaAtiva === 'ARMA_LONGA_HASTE') bonusAtqBase += 2;
    if (nomesPodsLow.includes('valentão') && !ehDistArmaAtiva) bonusAtqBase += 2;
    if (nomesPodsLow.includes('empunhadura poderosa') && !ehDistArmaAtiva) bonusAtqBase -= 2;

    const critInfo = st.arma ? extrairCriticoArmaJS(st.arma.critico_ou_penalidade) : { margem: 20, mult: 2 };
    let margemCrit = critInfo.margem;
    let multCrit = critInfo.mult;
    if (nomesPodsLow.includes('ataque preciso') && ehUmaMaoLivreAtiva) { margemCrit = Math.max(1, margemCrit - 2); multCrit += 1; }
    if (nomesPodsLow.includes('en garde') && ehUmaMaoLivreAtiva) { margemCrit = Math.max(1, margemCrit - 2); }
    if (nomesPodsLow.includes('armas da ambição')) { margemCrit = Math.max(1, margemCrit - 1); }
    if (nomesPodsLow.includes('crítico brutal')) { multCrit += 1; }

    if (tipoAcao === 'MANOBRA_DERRUBAR') {
        const selMan = document.getElementById('sel-cap5-manobra');
        const nomeManobra = selMan ? selMan.value : 'Derrubar';
        const d20ManH = Math.floor(Math.random() * 20) + 1;
        const d20ManC = Math.floor(Math.random() * 20) + 1;
        const totManH = d20ManH + bonusAtqBase + (nomesPodsLow.some(n => n.includes('derrubar') || n.includes(' Lutador')) ? 2 : 0);
        const totManC = d20ManC + priv.ataque;
        const venceuMan = totManH >= totManC;
        dadosVisuais.push({ faces: 20, valor: d20ManH, critico: venceuMan, cor: '#1E3A8A', label: `Herói Luta (${totManH})` });
        dadosVisuais.push({ faces: 20, valor: d20ManC, falhaCritica: !venceuMan, cor: '#7F1D1D', label: `Criatura Oposto (${totManC})` });
        if (venceuMan) {
            let descEfeitoManobra = '';
            if (nomeManobra === 'Derrubar') {
                a.criaturaCaida = true;
                danoCausadoHeroi = nomesPodsLow.includes('derrubar aprimorado') ? +((resDano.danoMedioArma || 14) * 0.6).toFixed(1) : 0;
                descEfeitoManobra = 'Criatura ficou CAÍDA (Livro p. 234 e p. 394: sofre -5 nos ataques corpo a corpo, -5 na Defesa contra ataques corpo a corpo e recebe +5 na Defesa contra ataques à distância)!';
            } else if (nomeManobra === 'Agarrar') {
                a.criaturaAgarrada = true;
                a.criaturaDesprevenida = true;
                danoCausadoHeroi = 0;
                descEfeitoManobra = 'Criatura ficou AGARRADA (Livro p. 234 e p. 394: fica Desprevenida [-5 na Defesa e Reflexos], Imóvel e sofre -2 nos testes de ataque)!';
            } else if (nomeManobra === 'Desarmar') {
                a.criaturaDesarmada = true;
                danoCausadoHeroi = 0;
                descEfeitoManobra = 'Criatura foi DESARMADA (Livro p. 234: arma jogada no chão; sofre -5 nos testes de ataque e rolagens de dano até gastar movimento para recuperá-la)!';
            } else if (nomeManobra === 'Empurrar') {
                const metrosEmp = 1.5 * (1 + Math.max(0, Math.floor((totManH - totManC) / 5)));
                danoCausadoHeroi = 0;
                descEfeitoManobra = `Criatura foi EMPURRADA ${metrosEmp.toFixed(1)}m para trás (Livro p. 234: 1,5m + 1,5m para cada 5 pontos acima do teste oposto)!`;
            } else if (nomeManobra === 'Quebrar') {
                if (!a.escudoCriaturaQuebrado) {
                    a.escudoCriaturaQuebrado = true;
                    priv.defesa = Math.max(10, priv.defesa - 2);
                }
                danoCausadoHeroi = +((resDano.danoMedioArma || 10) * 0.5).toFixed(1);
                descEfeitoManobra = 'Item/Couraça da criatura sofreu QUEBRAR (Livro p. 234: Defesa da criatura reduzida permanentemente em -2)!';
            }
            formulaMesa = `<strong>Manobra de Combate: ${nomeManobra} [Ação Padrão, Livro p. 234]</strong>: Teste Oposto de Luta <strong>${totManH}</strong> vs. <strong>${totManC}</strong> <span style="color:#4ADE80;">VENCEU!</span> <strong>${descEfeitoManobra}</strong>`;
            resumoAcaoHeroi = `Executou <strong>Manobra ${nomeManobra}</strong> (${totManH} vs ${totManC}): <strong>SUCESSO!</strong> ${descEfeitoManobra}`;
        } else {
            danoCausadoHeroi = 0;
            formulaMesa = `<strong>Manobra de Combate: ${nomeManobra} [Ação Padrão, Livro p. 234]</strong>: Herói <strong>${totManH}</strong> vs. Criatura <strong>${totManC}</strong> <span style="color:#F87171;">Criatura venceu o teste oposto!</span>`;
            resumoAcaoHeroi = `Tentou <strong>Manobra ${nomeManobra}</strong> (${totManH} vs ${totManC}): a criatura venceu o teste oposto.`;
        }
    } else if (tipoAcao === 'FINTAR_DESPREVENIDO') {
        const bonusEng = st.est.bonusPericias['Enganação'] || (Math.floor(st.nivel / 2) + st.est.finais.CAR);
        const d20FinH = Math.floor(Math.random() * 20) + 1;
        const d20FinC = Math.floor(Math.random() * 20) + 1;
        const totFinH = d20FinH + bonusEng;
        const totFinC = d20FinC + priv.resMedia;
        const venceuFin = totFinH >= totFinC;
        dadosVisuais.push({ faces: 20, valor: d20FinH, critico: venceuFin, cor: '#701A75', label: `Enganação (${totFinH})` });
        dadosVisuais.push({ faces: 20, valor: d20FinC, cor: '#475569', label: `Reflexos Inimigo (${totFinC})` });
        if (venceuFin) {
            a.criaturaDesprevenida = true;
            danoCausadoHeroi = 0;
            formulaMesa = `<strong>Fintar [${fintaComoMovimento ? 'Ação de Movimento (Finta Aprimorada)' : 'Ação Padrão'}, Livro p. 117/234]</strong>: Enganação <strong>${totFinH}</strong> vs. Reflexos <strong>${totFinC}</strong> <span style="color:#4ADE80;">SUCESSO!</span> A criatura está <strong>DESPREVENIDA (-5 na Defesa)</strong> contra seu próximo ataque!`;
            resumoAcaoHeroi = `Executou <strong>Fintar</strong> (${totFinH} vs ${totFinC}): Criatura ficou <strong>Desprevenida (-5 na Defesa)</strong>!`;
        } else {
            danoCausadoHeroi = 0;
            formulaMesa = `<strong>Fintar [Livro p. 117/234]</strong>: Enganação <strong>${totFinH}</strong> vs. Reflexos <strong>${totFinC}</strong> <span style="color:#F87171;">Criatura passou no teste oposto de Reflexos!</span>`;
            resumoAcaoHeroi = `Tentou <strong>Fintar</strong> (${totFinH} vs ${totFinC}): Criatura resistiu à finta.`;
        }
    } else if (tipoAcao === 'HABILIDADE_RACIAL_ATIVA') {
        if (nrAct === 'trog' || (nrAct === 'osteon' && (st.est.racaAnteriorOsteon || '').toLowerCase().includes('trog'))) {
            const custoMC = Math.min(a.pmHeroi, 2);
            a.pmHeroi -= custoMC;
            const cdMC = 10 + Math.floor(st.nivel / 2) + st.est.finais.CON;
            const d20FortC = Math.floor(Math.random() * 20) + 1;
            const totFortC = d20FortC + priv.fortitude;
            const passouMC = totFortC >= cdMC;
            const rodEnjoado = Math.floor(Math.random() * 6) + 1;
            dadosVisuais.push({ faces: 20, valor: d20FortC, critico: !passouMC, falhaCritica: passouMC, cor: '#059669', label: `Fort Inimigo (${totFortC}) vs CD ${cdMC}` });
            dadosVisuais.push({ faces: 6, valor: rodEnjoado, critico: rodEnjoado === 6, cor: '#047857', label: `${rodEnjoado} rod. Enjoado` });
            if (!passouMC) {
                a.criaturaDesprevenida = true;
                danoCausadoHeroi = 0;
                formulaMesa = `<strong>Mau Cheiro (Trog, Ação Padrão, -2 PM, Livro p. 31)</strong>: Criatura rolou Fortitude <strong>d20(${d20FortC})+${priv.fortitude}=${totFortC}</strong> vs CD ${cdMC} <span style="color:#4ADE80;">FALHOU!</span> Criatura fica <strong>ENJOADA por ${rodEnjoado} rodadas</strong> (só pode realizar Padrão OU Movimento por turno)!`;
                resumoAcaoHeroi = `Expeliu <strong>Mau Cheiro (Trog, -2 PM)</strong>: Criatura falhou em Fortitude (${totFortC} vs CD ${cdMC}) e ficou <strong>Enjoada por ${rodEnjoado} rodadas</strong>!`;
            } else {
                danoCausadoHeroi = 0;
                formulaMesa = `<strong>Mau Cheiro (Trog, -2 PM, Livro p. 31)</strong>: Criatura rolou Fortitude <strong>d20(${d20FortC})+${priv.fortitude}=${totFortC}</strong> vs CD ${cdMC} <span style="color:#F87171;">Passou no teste de Fortitude!</span>`;
                resumoAcaoHeroi = `Usou <strong>Mau Cheiro (-2 PM)</strong>, mas a criatura passou em Fortitude (${totFortC} vs CD ${cdMC}).`;
            }
        } else if (nrAct === 'medusa' || (nrAct === 'osteon' && (st.est.racaAnteriorOsteon || '').toLowerCase().includes('medusa'))) {
            a.pmHeroi = Math.max(0, a.pmHeroi - 1);
            a.venenoMedusaAtivo = true;
            danoCausadoHeroi = 0;
            formulaMesa = `<strong>Natureza Venenosa (Medusa, Ação de Movimento, -1 PM, Livro p. 24)</strong>: Sua arma foi revestida com veneno (+1d12 de dano de veneno no próximo ataque acertado)!`;
            resumoAcaoHeroi = `Ativou <strong>Natureza Venenosa (Medusa, -1 PM, p. 24)</strong>: próxima arma causa +1d12 de veneno!`;
        } else if (nrAct === 'dahllan' || (nrAct === 'osteon' && (st.est.racaAnteriorOsteon || '').toLowerCase().includes('dahllan'))) {
            a.pmHeroi = Math.max(0, a.pmHeroi - 1);
            a.bonusDefTemp += 2;
            danoCausadoHeroi = 0;
            formulaMesa = `<strong>Armadura de Allihanna (Dahllan, Ação de Movimento, -1 PM, Livro p. 19)</strong>: Sua pele cria casca de árvore (+2 na Defesa pela cena)!`;
            resumoAcaoHeroi = `Ativou <strong>Armadura de Allihanna (-1 PM, p. 19)</strong>: +2 na Defesa!`;
        }
    } else {
        // Agredir com Arma + Sistema de COMBO OFENSIVO ACUMULÁVEL (permite combinar Ataque Especial + Golpe Pessoal + Ataque Poderoso + Combate Defensivo + Investida no mesmo golpe!)
        const chkComboHabClasse = Boolean(document.getElementById('chk-combo-hab-classe')?.checked);
        const chkComboGP = Boolean(document.getElementById('chk-combo-golpe-pessoal')?.checked);
        const chkComboAtqPod = Boolean(document.getElementById('chk-combo-ataque-poderoso')?.checked) && nomesPodsLow.includes('ataque poderoso');
        const chkComboCombDef = Boolean(document.getElementById('chk-combo-combate-defensivo')?.checked) && nomesPodsLow.includes('combate defensivo');

        const ehCombo = (tipoAcao === 'ATAQUE_ESPECIAL_COMBO' || tipoAcao === 'COMBO_OFENSIVO_TOTAL' || (tipoAcao === 'GOLPE_PESSOAL' && chkComboHabClasse) || (tipoAcao === 'INVESTIDA_COMPLETA' && chkComboHabClasse));
        const ehGolpePessoal = (tipoAcao === 'GOLPE_PESSOAL' || (tipoAcao === 'COMBO_OFENSIVO_TOTAL' && chkComboGP) || (tipoAcao === 'ATAQUE_ESPECIAL_COMBO' && chkComboGP) || (tipoAcao === 'INVESTIDA_COMPLETA' && chkComboGP)) && nomesPodsLow.includes('golpe pessoal');
        const ehInvestida = (tipoAcao === 'INVESTIDA_COMPLETA');
        const ehCombateDefensivo = (tipoAcao === 'COMBATE_DEFENSIVO_ATAQUE' || chkComboCombDef);

        if (ehInvestida) a.bonusDefTemp -= 2; // Regra Investida p. 235: +2 no Ataque e -2 na Defesa até o próximo turno
        if (ehCombateDefensivo) a.bonusDefTemp += 5; // Regra Combate Defensivo p. 125: -2 no Ataque e +5 na Defesa até o próximo turno

        const subArmaAtq = st.arma ? ((st.arma.subcategoria || '') + ' ' + (st.arma.nome || '')).toLowerCase() : '';
        const ehAtaqueDistancia = /distância|distancia|fogo|arco|besta|mosquete|pistola|funda|azagaia/.test(subArmaAtq);

        const chkFlanq = document.getElementById('chk-cap5-flanqueando')?.checked;
        const chkElev = document.getElementById('chk-cap5-elevado')?.checked;
        const chkMira = document.getElementById('chk-cap5-mira')?.checked;
        const chkCob = document.getElementById('chk-cap5-cobertura')?.checked;
        const chkInvisivel = document.getElementById('chk-cap5-invisivel')?.checked;
        const chkVulnAlvo = document.getElementById('chk-cap5-vulneravel')?.checked;
        const chkAlvoEngajadoDist = document.getElementById('chk-cap5-disparo-engajado')?.checked;
        const selCamuflagem = document.getElementById('sel-cap5-camuflagem')?.value || 'NENHUMA';

        if (chkCob) a.bonusDefTemp = Math.max(a.bonusDefTemp, 5);

        // Regra Oficial Flanquear (Livro p. 239 & Tabela 5-1, p. 238):
        // +2 aplica-se APENAS em ataques corpo a corpo quando um aliado está no lado oposto! Não se pode flanquear à distância.
        const infoMPAtq = (typeof obterBonusMontariaEParceiroAtivosJS === 'function') ? obterBonusMontariaEParceiroAtivosJS(st) : {};
        const flanqGrid2D = (typeof verificarFlanqueamentoAlvoArenaJS === 'function') ? verificarFlanqueamentoAlvoArenaJS(a, a.alvoFocoIdx || 0) : false;
        const bonusFlanquear = ((chkFlanq || flanqGrid2D || infoMPAtq.flanqueiaAutomatico) && !ehAtaqueDistancia) ? 2 : 0;
        const bonusParceiroMontariaAtq = (!ehAtaqueDistancia ? (infoMPAtq.bonusAtaqueCaC || 0) : (infoMPAtq.bonusAtaqueDist || 0)) + (ehInvestida ? (infoMPAtq.bonusAtaqueInvestida || 0) : 0);

        // Regra Oficial Disparando em Combate Corpo a Corpo (Tabela 5-1, p. 238) & Ação Mirar (p. 235) & Mira Apurada (p. 127):
        // - Disparar contra alvo engajado em corpo a corpo impõe -5 em Pontaria, anulado pelo poder Disparo Preciso (p. 125) ou pela ação Mirar (p. 235).
        // - Se possuir o poder Mira Apurada (p. 127), a ação Mirar concede +2 no teste de ataque e +2 na margem de ameaça à distância!
        const temDisparoPreciso = nomesPodsLow.includes('disparo preciso');
        const temMiraApuradaAtq = nomesPodsLow.includes('mira apurada');
        const penDisparoEngajado = (ehAtaqueDistancia && chkAlvoEngajadoDist && !temDisparoPreciso && !chkMira) ? -5 : 0;
        const bonusMiraApurada = (ehAtaqueDistancia && chkMira && temMiraApuradaAtq) ? 2 : 0;
        if (ehAtaqueDistancia && chkMira && temMiraApuradaAtq) {
            margemCrit = Math.max(1, margemCrit - 2);
        }

        // Regra Oficial Posição Elevada (+2 Atq, p. 238) e Atacante Invisível (+2 Atq e deixa alvo Desprevenido, p. 238)
        const bonusPosElevada = chkElev ? 2 : 0;
        const bonusInvisivel = chkInvisivel ? 2 : 0;
        const modSitAtq = (ehInvestida ? 2 : 0) + (ehCombateDefensivo ? -2 : 0) + bonusFlanquear + bonusParceiroMontariaAtq + bonusPosElevada + bonusInvisivel + penDisparoEngajado + bonusMiraApurada;

        const ncHeroi = (st.classe && st.classe.nome) ? st.classe.nome.toLowerCase() : '';
        let bonusAtqHabilidade = 0;
        let bonusDanoHabilidade = 0;
        let tagHabilidadeAtiva = ehCombateDefensivo ? ' [Combate Defensivo: -2 Ataque / +5 Defesa até o próximo turno (p. 125)]' : '';

        if (ehCombo) {
            // Em Multiclasse (Cap. 1, p. 34), acumula as habilidades ofensivas de TODAS as classes possuídas pelo personagem!
            const nvGuerreiroA = nivelNaClasseJS(st, 'Guerreiro');
            const nvBarbaroA = nivelNaClasseJS(st, 'Bárbaro');
            const nvPaladinoA = nivelNaClasseJS(st, 'Paladino');
            const nvCacadorA = nivelNaClasseJS(st, 'Caçador');
            const nvCavaleiroA = nivelNaClasseJS(st, 'Cavaleiro');
            const nvLadinoA = nivelNaClasseJS(st, 'Ladino');
            const nvBucaneiroA = nivelNaClasseJS(st, 'Bucaneiro');
            const nvLutadorA = nivelNaClasseJS(st, 'Lutador');
            let ativouAlgumaHabClasse = false;

            if (nvGuerreiroA >= 1) {
                const custoAE = 1 + Math.floor((nvGuerreiroA - 1) / 4);
                const totalBonusAE = 4 * custoAE;
                const selModoAE = document.getElementById('arena-sel-modo-ae');
                const modoAE = selModoAE ? selModoAE.value : 'ATAQUE';
                if (a.pmHeroi >= custoAE) {
                    a.pmHeroi -= custoAE;
                    ativouAlgumaHabClasse = true;
                    if (modoAE === 'ATAQUE') {
                        bonusAtqHabilidade += totalBonusAE;
                        tagHabilidadeAtiva += ` [Ataque Especial -${custoAE} PM: +${totalBonusAE} Atq (p. 65)]`;
                    } else if (modoAE === 'DANO') {
                        bonusDanoHabilidade += totalBonusAE;
                        tagHabilidadeAtiva += ` [Ataque Especial -${custoAE} PM: +${totalBonusAE} Dano (p. 65)]`;
                    } else {
                        const metadeAE = Math.floor(totalBonusAE / 2);
                        bonusAtqHabilidade += metadeAE;
                        bonusDanoHabilidade += metadeAE;
                        tagHabilidadeAtiva += ` [Ataque Especial Dividido -${custoAE} PM: +${metadeAE} Atq / +${metadeAE} Dano (p. 65)]`;
                    }
                }
            }
            // Regra Oficial: Fúria (p. 40), Golpe Divino (p. 81), Duelo (p. 56) e Golpe Relâmpago (p. 76) exigem ataque CORPO A CORPO (!ehAtaqueDistancia)
            if (nvBarbaroA >= 1 && !ehAtaqueDistancia && a.pmHeroi >= 2) {
                a.pmHeroi -= 2;
                ativouAlgumaHabClasse = true;
                const bFur = 2 + Math.floor((nvBarbaroA - 1) / 5);
                bonusAtqHabilidade += bFur;
                bonusDanoHabilidade += bFur;
                tagHabilidadeAtiva += ` [Fúria CaC -2 PM: +${bFur} Atq / +${bFur} Dano (p. 40)]`;
            }
            if (nvPaladinoA >= 1 && !ehAtaqueDistancia && a.pmHeroi >= 2) {
                a.pmHeroi -= 2;
                ativouAlgumaHabClasse = true;
                const bCarGD = Math.max(0, st.est.finais.CAR);
                const dGD = Math.floor(Math.random() * 8) + 1;
                bonusAtqHabilidade += bCarGD;
                bonusDanoHabilidade += dGD;
                tagHabilidadeAtiva += ` [Golpe Divino CaC -2 PM: +${bCarGD} Atq / +1d8(${dGD}) Dano (p. 81)]`;
            }
            if (nvCacadorA >= 1 && a.pmHeroi >= 1) {
                a.pmHeroi -= 1;
                ativouAlgumaHabClasse = true;
                const dMP = Math.floor(Math.random() * (nvCacadorA >= 5 ? 8 : 4)) + 1;
                bonusDanoHabilidade += dMP;
                tagHabilidadeAtiva += ` [Marca da Presa -1 PM: +${dMP} Dano (p. 49)]`;
            }
            if (nvCavaleiroA >= 2 && !ehAtaqueDistancia && a.pmHeroi >= 2) {
                a.pmHeroi -= 2;
                ativouAlgumaHabClasse = true;
                bonusAtqHabilidade += 2;
                bonusDanoHabilidade += 2;
                tagHabilidadeAtiva += ` [Duelo CaC -2 PM: +2 Atq / +2 Dano (p. 56)]`;
            }
            // Ataque Furtivo (p. 73): exige alvo Desprevenido ou Flanqueado!
            if (nvLadinoA >= 1 && (a.criaturaDesprevenida || a.criaturaAgarrada || chkInvisivel || bonusFlanquear > 0)) {
                ativouAlgumaHabClasse = true;
                const qtdFurt = Math.ceil(nvLadinoA / 2);
                let somaFurt = 0;
                for (let k = 0; k < qtdFurt; k++) somaFurt += Math.floor(Math.random() * 6) + 1;
                bonusDanoHabilidade += somaFurt;
                tagHabilidadeAtiva += ` [Ataque Furtivo (Flanco/Desprev): +${qtdFurt}d6(${somaFurt}) Dano (p. 73)]`;
            }
            if (nvBucaneiroA >= 2 && a.pmHeroi >= 2) {
                a.pmHeroi -= 2;
                ativouAlgumaHabClasse = true;
                const bAud = Math.max(1, st.est.finais.CAR);
                bonusAtqHabilidade += bAud;
                tagHabilidadeAtiva += ` [Audácia -2 PM: +${bAud} no Ataque (p. 50)]`;
            }
            if (nvLutadorA >= 1 && !ehAtaqueDistancia && a.pmHeroi >= 1) {
                a.pmHeroi -= 1;
                ativouAlgumaHabClasse = true;
                const dLut = Math.floor(Math.random() * 6) + 1 + Math.max(0, st.est.finais.FOR);
                bonusDanoHabilidade += dLut;
                tagHabilidadeAtiva += ` [Golpe Relâmpago CaC -1 PM: +${dLut} Dano Extra (p. 76)]`;
            }
        }

        let gpBrutalDados = 0;
        let gpElemDados6 = 0;
        let gpPreciso2d20 = Boolean(a.concentracaoCombateAtiva);
        let fonte2d20 = a.concentracaoCombateAtiva ? 'Concentração de Combate' : 'Preciso';
        let gpAtordoante = false;
        let gpConjurador = false;
        if (a.concentracaoCombateAtiva) {
            a.concentracaoCombateAtiva = false;
        }

        if (ehGolpePessoal && nomesPodsLow.includes('golpe pessoal')) {
            const selGP = document.getElementById('arena-sel-golpe-pessoal');
            const cfgGP = selGP ? selGP.value : 'BRUTAL_ELEM_PRECISO';
            const mapaCustoGP = {
                'LETAL_DESTRUIDOR_BRUTAL_LENTO': 4,
                'BRUTAL_ELEM_PRECISO': 4,
                'BRUTAL_PRECISO': 2,
                'LETAL_DESTRUIDOR_PRECISO': 5,
                'ATORDOANTE_PENETRANTE_BRUTAL': 4,
                'CONJURADOR_TOQUE_BRUTAL': 3
            };
            const resArsAtq = calcularResumoArsenalSuperiorEMagicoJS(st);
            const custoGP = Math.max(1, Math.min(st.nivel, mapaCustoGP[cfgGP] || 4) - (resArsAtq ? resArsAtq.redPmAtaque : 0));
            if (a.pmHeroi >= custoGP) {
                a.pmHeroi -= custoGP;
                fonte2d20 = 'Golpe Pessoal: Preciso';
                if (cfgGP === 'LETAL_DESTRUIDOR_BRUTAL_LENTO') {
                    margemCrit = Math.max(1, margemCrit - 2); multCrit += 1; gpBrutalDados = 1; gpPreciso2d20 = true;
                    tagHabilidadeAtiva += ` + [Golpe Pessoal (-${custoGP} PM): Destruidor + Letal + Brutal + Preciso (2d20 escolhe o melhor)]`;
                } else if (cfgGP === 'BRUTAL_ELEM_PRECISO') {
                    gpBrutalDados = 1; gpElemDados6 = 2; gpPreciso2d20 = true;
                    tagHabilidadeAtiva += ` + [Golpe Pessoal (-${custoGP} PM): Brutal + Elemental (+2d6 Fogo) + Preciso (2d20 escolhe o melhor)]`;
                } else if (cfgGP === 'BRUTAL_PRECISO') {
                    gpBrutalDados = 1; gpPreciso2d20 = true;
                    tagHabilidadeAtiva += ` + [Golpe Pessoal (-${custoGP} PM): Brutal (+1d) + Preciso (2d20 escolhe o melhor)]`;
                } else if (cfgGP === 'LETAL_DESTRUIDOR_PRECISO') {
                    margemCrit = Math.max(1, margemCrit - 2); multCrit += 1; gpPreciso2d20 = true;
                    tagHabilidadeAtiva += ` + [Golpe Pessoal (-${custoGP} PM): Letal + Destruidor + Preciso (2d20 escolhe o melhor)]`;
                } else if (cfgGP === 'ATORDOANTE_PENETRANTE_BRUTAL') {
                    gpBrutalDados = 1; gpAtordoante = true;
                    tagHabilidadeAtiva += ` + [Golpe Pessoal (-${custoGP} PM): Atordoante + Penetrante (-5 RD) + Brutal (+1d)]`;
                } else if (cfgGP === 'CONJURADOR_TOQUE_BRUTAL') {
                    gpBrutalDados = 1; gpConjurador = true;
                    tagHabilidadeAtiva += ` + [Golpe Pessoal (-${custoGP} PM): Conjurador (Toque Chocante 2d8+2) + Brutal (+1d)]`;
                }
            }
        }
        if ((chkComboAtqPod || (ehCombo && !chkComboHabClasse)) && !ehAtaqueDistancia && nomesPodsLow.includes('ataque poderoso')) {
            bonusAtqHabilidade -= 2;
            bonusDanoHabilidade += 5;
            tagHabilidadeAtiva += ` + [Ataque Poderoso CaC: -2 Atq / +5 Dano (p. 125)]`;
        }

        // Regra Oficial Tabela 5-1 (p. 238) e Apêndice de Condições (p. 394-395):
        // - Alvo Desprevenido (ou atacante invisível s/ percepção às cegas): -5 na Defesa
        // - Alvo Vulnerável (ou Enredado): -2 na Defesa
        // - Alvo Caído: sofre -5 na Defesa contra ataques CORPO A CORPO, mas recebe +5 na Defesa contra ataques À DISTÂNCIA!
        const alvoDesprevEfetivo = Boolean(a.criaturaDesprevenida || a.criaturaAgarrada || chkInvisivel);
        const modDefCaido = a.criaturaCaida ? (ehAtaqueDistancia ? +5 : -5) : 0;
        const modDefDesprev = alvoDesprevEfetivo ? -5 : 0;
        const modDefVuln = chkVulnAlvo ? -2 : 0;
        const defEfetivaCriatura = Math.max(10, priv.defesa + modDefCaido + modDefDesprev + modDefVuln);

        const d20_1 = Math.floor(Math.random() * 20) + 1;
        let d20Atq = d20_1;
        let strRollD20 = `1d20(${d20Atq})`;
        const bonusTotalAtq = bonusAtqBase + bonusAtqHabilidade + modSitAtq;

        if (gpPreciso2d20) {
            const d20_2 = Math.floor(Math.random() * 20) + 1;
            const melhorD20 = Math.max(d20_1, d20_2);
            const piorD20 = Math.min(d20_1, d20_2);
            d20Atq = melhorD20;
            strRollD20 = `2d20 [Rolados: ${d20_1} e ${d20_2} Selecionado o MELHOR: ${melhorD20} (descartado ${piorD20}) — ${fonte2d20}]`;

            const ehCrit1 = (melhorD20 >= margemCrit);
            dadosVisuais.push({
                faces: 20,
                valor: melhorD20,
                critico: ehCrit1,
                falhaCritica: melhorD20 === 1,
                melhorSelecionado: true,
                cor: '#15803D',
                label: `Melhor d20: ${melhorD20} (+${bonusTotalAtq}=${melhorD20 + bonusTotalAtq})`
            });
            dadosVisuais.push({
                faces: 20,
                valor: piorD20,
                critico: false,
                falhaCritica: false,
                descartado: true,
                cor: '#334155',
                label: `Outro d20: ${piorD20} (Descartado)`
            });
        }

        const totalAtq = d20Atq + bonusTotalAtq;
        let acertou = (d20Atq === 20) || (d20Atq !== 1 && totalAtq >= defEfetivaCriatura);
        let falhouPorCamuflagem = false;
        let d10Camuflagem = 0;
        if (acertou && selCamuflagem !== 'NENHUMA') {
            d10Camuflagem = Math.floor(Math.random() * 10) + 1;
            const limiarFalhaCam = selCamuflagem === 'TOTAL_50' ? 5 : 2;
            falhouPorCamuflagem = (d10Camuflagem <= limiarFalhaCam);
            dadosVisuais.push({
                faces: 10,
                valor: d10Camuflagem,
                critico: !falhouPorCamuflagem,
                falhaCritica: falhouPorCamuflagem,
                cor: falhouPorCamuflagem ? '#64748B' : '#0D9488',
                label: `Camuflagem 1d10: ${d10Camuflagem} (${falhouPorCamuflagem ? 'Falhou!' : 'Superou!'})`
            });
            if (falhouPorCamuflagem) acertou = false;
        }
        a.criaturaDesprevenida = false;
        const ehCrit = acertou && (d20Atq >= margemCrit);

        if (d20Atq !== 1 && d20Atq !== 20) {
            if (acertou) cr.defMax = Math.min(cr.defMax, totalAtq);
            else cr.defMin = Math.max(cr.defMin, totalAtq + 1);
        }

        if (!gpPreciso2d20) {
            dadosVisuais.push({
                faces: 20,
                valor: d20Atq,
                critico: ehCrit,
                falhaCritica: d20Atq === 1,
                cor: ehGolpePessoal ? '#B45309' : '#8B1E24',
                label: `${strRollD20}+${bonusTotalAtq}=${totalAtq}`
            });
        }

        let passosArmaAtq = 0;
        if (!ehAtaqueDistancia && nomesPodsLow.includes('empunhadura poderosa')) passosArmaAtq += 1;
        if (nomesPodsLow.includes('arma sagrada')) passosArmaAtq += 1;
        if (nomesPodsLow.includes('armamento da natureza')) passosArmaAtq += 1;
        const infoP = st.arma ? avancarPassosDanoJS(st.arma.dano_ou_defesa || '1d8', passosArmaAtq) : { q: 1, f: 8 };

        // Dano Fixo Base estritamente compatível com o Estilo/Empunhadura da Arma (sem duplicar Ataque Poderoso ou Fúria!)
        let fixoArmaReal = 0;
        if (!ehAtaqueDistancia) {
            const usaAcuidDano = nomesPodsLow.includes('acuidade com arma') && ['UMA_ARMA_ESGRIMA', 'DUAS_ARMAS'].includes(estiloArmaAtiva) && st.est.finais.DES > st.est.finais.FOR;
            fixoArmaReal += Math.max(0, usaAcuidDano ? st.est.finais.DES : st.est.finais.FOR);
            if (nomesPodsLow.includes('estilo de duas mãos') && ehDuasMaosAtiva) fixoArmaReal += 5;
            if (nomesPodsLow.includes('esgrimista') && ['UMA_ARMA_ESGRIMA', 'DUAS_ARMAS'].includes(estiloArmaAtiva)) {
                fixoArmaReal += Math.min(st.nivel, Math.max(0, st.est.finais.INT));
            }
            if (nomesPodsLow.includes('valentão')) fixoArmaReal += 2;
        } else {
            const nmArmaLow = st.arma ? (st.arma.nome || '').toLowerCase() : '';
            if (nmArmaLow.includes('arco longo') || (estiloArmaAtiva === 'ARREMESSO' && nomesPodsLow.includes('arremesso potente'))) {
                fixoArmaReal += Math.max(0, st.est.finais.FOR);
            }
            if (nomesPodsLow.includes('estilo de disparo') && estiloArmaAtiva === 'ARQUERIA_DISPARO') {
                fixoArmaReal += Math.max(0, st.est.finais.DES);
            }
            if (nomesPodsLow.includes('arqueiro') && estiloArmaAtiva === 'ARQUERIA_DISPARO') {
                fixoArmaReal += Math.min(st.nivel, Math.max(0, st.est.finais.SAB));
            }
        }
        if (nomesPodsLow.includes('especialização em arma')) fixoArmaReal += 2;
        if (nomesPodsLow.includes('sangue de ferro')) fixoArmaReal += 2;
        if (!ehAtaqueDistancia) fixoArmaReal += Math.round((infoMPAtq.bonusDanoFixoCaC || 0) + (infoMPAtq.bonusDanoDadosCaCMedia || 0));
        else fixoArmaReal += Math.round(infoMPAtq.bonusDanoDadosDistMedia || 0);

        if (acertou) {
            const qtdDadosArma = infoP.q * (ehCrit ? multCrit : 1) + gpBrutalDados;
            let somaDadosArma = 0;
            for (let i = 0; i < Math.min(8, qtdDadosArma); i++) {
                let vDado = Math.floor(Math.random() * infoP.f) + 1;
                let rerrolou = false;
                if (vDado <= 2 && nomesPodsLow.includes('destruidor') && ehDuasMaosAtiva) {
                    vDado = Math.floor(Math.random() * infoP.f) + 1;
                    rerrolou = true;
                }
                somaDadosArma += vDado;
                const ehDadoBrutal = (i >= infoP.q * (ehCrit ? multCrit : 1));
                dadosVisuais.push({
                    faces: infoP.f,
                    valor: vDado,
                    critico: vDado === infoP.f,
                    cor: ehDadoBrutal ? '#D97706' : '#1E3A8A',
                    label: ehDadoBrutal ? `+1d${infoP.f} (Brutal)` : (rerrolou ? `d${infoP.f} (Destruidor )` : `Dado Arma d${infoP.f}`)
                });
            }
            let somaElemGP = 0;
            for (let j = 0; j < gpElemDados6; j++) {
                const vE = Math.floor(Math.random() * 6) + 1;
                somaElemGP += vE;
                dadosVisuais.push({ faces: 6, valor: vE, critico: vE === 6, cor: '#DC2626', label: `Elemental d6` });
            }
            if (gpConjurador) {
                const vC1 = Math.floor(Math.random() * 8) + 1;
                const vC2 = Math.floor(Math.random() * 8) + 1;
                somaElemGP += (vC1 + vC2 + 2);
                dadosVisuais.push({ faces: 8, valor: vC1, cor: '#7C3AED', label: 'Toque Chocante d8' });
                dadosVisuais.push({ faces: 8, valor: vC2, cor: '#7C3AED', label: 'Toque Chocante d8' });
            }
            if (a.venenoMedusaAtivo) {
                a.venenoMedusaAtivo = false;
                const vVen = Math.floor(Math.random() * 12) + 1;
                somaElemGP += vVen;
                dadosVisuais.push({ faces: 12, valor: vVen, critico: vVen === 12, cor: '#059669', label: 'Veneno Medusa 1d12' });
            }
            danoCausadoHeroi = +(somaDadosArma + fixoArmaReal + bonusDanoHabilidade + somaElemGP).toFixed(1);
            let strDetDano = `${somaDadosArma} (dados arma) + ${fixoArmaReal} (fixo)` + (bonusDanoHabilidade ? ` + ${bonusDanoHabilidade} (habilidade)` : '') + (somaElemGP ? ` + ${somaElemGP} (extra)` : '');
            formulaMesa = `<strong>Agredir c/ ${st.arma ? st.arma.nome : 'Arma'}${tagHabilidadeAtiva}</strong>: Rolou <strong>${strRollD20} + ${bonusTotalAtq} = ${totalAtq}</strong> vs Def ${defEfetivaCriatura} <span style="color:#4ADE80;">${ehCrit ? 'ACERTO CRÍTICO (x' + multCrit + ')!' : 'ACERTOU!'}</span> Dano: <code>${strDetDano}</code> = <span style="font-size:17px;color:#FACC15;">${danoCausadoHeroi}</span>!`;
            resumoAcaoHeroi = `Agrediu com <strong>${st.arma ? st.arma.nome : 'Arma'}</strong>${tagHabilidadeAtiva} (${strRollD20} + ${bonusTotalAtq} = ${totalAtq}${ehCrit ? ' — CRÍTICO!' : ''}): <strong>ACERTOU</strong> causando <strong>${danoCausadoHeroi} dano</strong> (${strDetDano})!`;
        } else {
            danoCausadoHeroi = 0;
            formulaMesa = `<strong>Agredir c/ ${st.arma ? st.arma.nome : 'Arma'}${tagHabilidadeAtiva}</strong>: Rolou <strong>${strRollD20} + ${bonusTotalAtq} = ${totalAtq}</strong> <span style="color:#F87171;">ERROU!</span> (Defesa da criatura deduzida <strong>≥ ${cr.defMin}</strong>!)`;
            resumoAcaoHeroi = `Agrediu com <strong>${st.arma ? st.arma.nome : 'Arma'}</strong>${tagHabilidadeAtiva} (${strRollD20} + ${bonusTotalAtq} = ${totalAtq}): <strong>ERROU</strong> (Defesa ≥ ${cr.defMin}).`;
        }

        // Habilidade Ataque Extra (Guerreiro Nv. 6+, Livro p. 65 — 2 PM ao usar a ação Agredir para realizar +1 ataque com a arma!)
        const chkAtqExtra = document.getElementById('chk-combo-ataque-extra');
        const usarAtaqueExtraGuerreiro = (ncHeroi === 'guerreiro' && st.nivel >= 6) && (!chkAtqExtra || chkAtqExtra.checked) && a.pmHeroi >= 2;
        if (usarAtaqueExtraGuerreiro) {
            a.pmHeroi -= 2;
            const d20Ex = Math.floor(Math.random() * 20) + 1;
            const totAtqEx = d20Ex + bonusAtqBase + modSitAtq;
            const acertouEx = (d20Ex === 20) || (d20Ex !== 1 && totAtqEx >= defEfetivaCriatura);
            const critEx = acertouEx && (d20Ex >= margemCrit);
            dadosVisuais.push({
                faces: 20,
                valor: d20Ex,
                critico: critEx,
                falhaCritica: d20Ex === 1,
                cor: '#6D28D9',
                label: `Ataque Extra d20(${d20Ex})+${bonusAtqBase + modSitAtq}=${totAtqEx}`
            });
            if (acertouEx) {
                const qEx = infoP.q * (critEx ? multCrit : 1);
                let somaEx = 0;
                for (let k = 0; k < Math.min(6, qEx); k++) {
                    const rEx = Math.floor(Math.random() * infoP.f) + 1;
                    somaEx += rEx;
                    dadosVisuais.push({ faces: infoP.f, valor: rEx, critico: rEx === infoP.f, cor: '#7C3AED', label: `Dano Atq Extra d${infoP.f}` });
                }
                const danoExTotal = +(somaEx + fixoArmaReal).toFixed(1);
                danoCausadoHeroi = +(danoCausadoHeroi + danoExTotal).toFixed(1);
                formulaMesa += `<br><strong>Ataque Extra de Guerreiro (Nv. 6+, -2 PM, p. 65):</strong> Rolou <strong>1d20(${d20Ex}) + ${bonusAtqBase + modSitAtq} = ${totAtqEx}</strong> <span style="color:#4ADE80;">${critEx ? 'CRÍTICO!' : 'ACERTOU!'}</span> Causou <strong>+${danoExTotal} dano</strong>!`;
                resumoAcaoHeroi += `<br>↳ <strong>Ataque Extra (-2 PM, p. 65):</strong> rolagem ${totAtqEx} <strong>ACERTOU (+${danoExTotal} dano)</strong>!`;
            } else {
                formulaMesa += `<br><strong>Ataque Extra de Guerreiro (Nv. 6+, -2 PM, p. 65):</strong> Rolou <strong>1d20(${d20Ex}) + ${bonusAtqBase + modSitAtq} = ${totAtqEx}</strong> <span style="color:#F87171;">ERROU!</span>`;
                resumoAcaoHeroi += `<br>↳ <strong>Ataque Extra (-2 PM, p. 65):</strong> rolagem ${totAtqEx} <strong>ERROU</strong>.`;
            }
        }

        // Arma Natural Extra da Ficha: Chifres (Minotauro p. 25) ou Mordida (Trog p. 31 / Presas Primordiais p. 134)
        const racaHeroiLow = (st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : '';
        const memOstHeroi = (st.est && st.est.racaAnteriorOsteon) ? st.est.racaAnteriorOsteon.toLowerCase() : '';
        const infoNatHeroi = obterInfoArmaNaturalJS(racaHeroiLow, memOstHeroi, todosPods);
        const chkChifres = document.getElementById('chk-minotauro-chifres');
        const usarArmaNatAgora = Boolean(infoNatHeroi) && (!chkChifres || chkChifres.checked) && a.pmHeroi >= 1;

        if (usarArmaNatAgora) {
            a.pmHeroi -= 1;
            const bValNat = nomesPodsLow.includes('valentão') ? 2 : 0;
            const bSgNat = nomesPodsLow.includes('sangue de ferro') ? 2 : 0;
            const bonusLutaNat = (st.est.bonusPericias['Luta'] || 0) + bValNat + modSitAtq;
            const d20Nat = Math.floor(Math.random() * 20) + 1;
            const totAtqNat = d20Nat + bonusLutaNat;
            const acertouNat = (d20Nat === 20) || (d20Nat !== 1 && totAtqNat >= defEfetivaCriatura);
            const critNat = acertouNat && (d20Nat === 20);
            const icoN = infoNatHeroi.icone;
            const nmN = infoNatHeroi.nomeCurto;
            const facesN = infoNatHeroi.faces;

            if (d20Nat !== 1 && d20Nat !== 20) {
                if (acertouNat) cr.defMax = Math.min(cr.defMax, totAtqNat);
                else cr.defMin = Math.max(cr.defMin, totAtqNat + 1);
            }

            dadosVisuais.push({
                faces: 20,
                valor: d20Nat,
                critico: critNat,
                falhaCritica: d20Nat === 1,
                cor: '#92400E',
                label: `${icoN} ${nmN} d20(${d20Nat})+${bonusLutaNat}=${totAtqNat}`
            });

            if (acertouNat) {
                const dNat1 = Math.floor(Math.random() * facesN) + 1;
                const dNat2 = critNat ? (Math.floor(Math.random() * facesN) + 1) : 0;
                dadosVisuais.push({
                    faces: facesN,
                    valor: dNat1,
                    critico: dNat1 === facesN,
                    cor: '#B45309',
                    label: `${icoN} Dano ${nmN} 1d${facesN}`
                });
                if (critNat) {
                    dadosVisuais.push({
                        faces: facesN,
                        valor: dNat2,
                        critico: dNat2 === facesN,
                        cor: '#B45309',
                        label: `${icoN} Crítico ${nmN} +1d${facesN}`
                    });
                }
                const fixoNatHeroi = Math.max(0, st.est.finais.FOR) + bValNat + bSgNat;
                const danoNatTotal = dNat1 + dNat2 + fixoNatHeroi;
                danoCausadoHeroi = +(danoCausadoHeroi + danoNatTotal).toFixed(1);
                formulaMesa += `<br>${icoN} <strong>Ataque Extra — ${nmN} (${infoNatHeroi.pagina}, -1 PM):</strong> Rolou <strong>1d20(${d20Nat}) + ${bonusLutaNat} = ${totAtqNat}</strong> <span style="color:#4ADE80;">ACERTOU!</span> Causou <strong>+${danoNatTotal} dano</strong>!`;
                resumoAcaoHeroi += `<br>↳ ${icoN} <strong>Ataque Extra c/ ${nmN} (-1 PM):</strong> rolagem ${totAtqNat} <strong>ACERTOU (+${danoNatTotal} dano)</strong>!`;
            } else {
                formulaMesa += `<br>${icoN} <strong>Ataque Extra — ${nmN} (${infoNatHeroi.pagina}, -1 PM):</strong> Rolou <strong>1d20(${d20Nat}) + ${bonusLutaNat} = ${totAtqNat}</strong> <span style="color:#F87171;">ERROU!</span>`;
                resumoAcaoHeroi += `<br>↳ ${icoN} <strong>Ataque Extra c/ ${nmN} (-1 PM):</strong> rolagem ${totAtqNat} <strong>ERROU</strong>.`;
            }
        }
    }

    dispararAnimacaoCardArena('arena-card-heroi', 'attack-lunge');
    const nmArmaAtiva = (st.arma && st.arma.nome) ? st.arma.nome.toLowerCase() : '';
    let fxTipo = 'ANIM_ESPADA_CORTE';
    let somArmaTipo = 'ESPADA_SLASH';
    if (tipoAcao === 'HABILIDADE_RACIAL_ATIVA' || tipoAcao === 'MANOBRA_DERRUBAR' || tipoAcao === 'FINTAR_DESPREVENIDO') {
        fxTipo = 'ANIM_VENENO_MANOBRA';
        somArmaTipo = 'MAGIA_TREVAS';
    } else if (/mosquete|pistola/.test(nmArmaAtiva)) {
        fxTipo = 'ANIM_DISPARO_DISTANCIA';
        somArmaTipo = 'TIRO_MOSQUETE';
    } else if (/arco|besta|funda/.test(nmArmaAtiva)) {
        fxTipo = 'ANIM_DISPARO_DISTANCIA';
        somArmaTipo = 'DISPARO_ARCO';
    } else if (/machado|marreta|martelo|maça|mangual|tacape/.test(nmArmaAtiva)) {
        fxTipo = 'ANIM_IMPACTO_ESMAGADOR';
        somArmaTipo = 'IMPACTO_ESMAGADOR';
    } else if (/alabarda|pique|lança|tridente|florete|adaga/.test(nmArmaAtiva)) {
        fxTipo = 'ANIM_ESTOCADA_LANCEIRO';
        somArmaTipo = 'ESTOCADA_LANCEIRO';
    }

    if (danoCausadoHeroi > 0) {
        priv.pvAtual = Math.max(0, priv.pvAtual - danoCausadoHeroi);
        cr.danoCausadoAcumulado += danoCausadoHeroi;
        if (typeof processarDanoEmEncontroMultiploArenaJS === 'function') {
            processarDanoEmEncontroMultiploArenaJS(a, danoCausadoHeroi, false, '');
        }
        dispararAnimacaoCardArena('arena-card-criatura', 'hit-shake');
        tocarSomJRPG(danoCausadoHeroi >= 48 ? 'CRITICO' : somArmaTipo);
        if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function') {
            const alvoA = (a.listaCriaturas || [])[a.alvoFocoIdx || 0] || { gx: 4, gy: 2 };
            dispararAnimacaoCoreografadaPalco2DJS({
                tipo: fxTipo === 'ANIM_DISPARO_DISTANCIA' ? 'DISPARO' : 'CORTE',
                origem: a.posHeroi || { gx: 2, gy: 2 },
                destino: { gx: alvoA.gx || 4, gy: alvoA.gy || 2 },
                label: `${st.nome}: -${danoCausadoHeroi} PV`
            });
        }
        dispararPopupDanoJRPG(`-${danoCausadoHeroi} PV!`, '#FACC15', 'INIMIGO', fxTipo, `[SEU TURNO] ${st.nome} causou ${danoCausadoHeroi} de dano em ${priv.nomeCriatura}!`);
    } else {
        tocarSomJRPG(a.criaturaDesprevenida || a.criaturaCaida ? somArmaTipo : 'MISS_DEFESA');
        dispararPopupDanoJRPG(`${a.criaturaDesprevenida || a.criaturaCaida ? 'EFEITO APLICADO!' : 'MISS / RESISTIU!'}`, '#94A3B8', 'INIMIGO', fxTipo, `${priv.nomeCriatura} — resultado da ação processado!`);
    }

    if (priv.pvAtual <= 0) {
        a.encerrado = true;
        setTimeout(() => tocarSomJRPG('VITORIA'), 320);
        resumoAcaoHeroi += `<br><strong>VITÓRIA DO HERÓI NO TURNO #${a.turno}!</strong> ${priv.nomeCriatura} caiu após sofrer <strong>${Math.round(cr.danoCausadoAcumulado)} PV</strong> de dano acumulado!`;
    } else {
        resumoAcaoHeroi += `<br><span style="color:#15803D;font-weight:700;">↳ Restam no seu turno: ${a.acoesPadraoRestantes} Ação Padrão e ${a.acoesMovimentoRestantes} Ação de Movimento.</span>`;
    }

    if (dadosVisuais.length > 0) {
        animarBandejaDadosVisual(dadosVisuais, formulaMesa, `Turno #${a.turno} (SEU TURNO) — Dados do Jogador`);
    }
    registrarLinhaLogArena(`<strong>[Turno #${a.turno} · SEU TURNO]</strong> ${resumoAcaoHeroi}`);
    atualizarPlacarVisualArena();
    checarFimAutomaticoTurnoJogadorJS();
}

function checarFimAutomaticoTurnoJogadorJS() {
    const a = __ARENA_STATE__;
    if (!a || a.encerrado) return;
    const chkAutoPassar = document.getElementById('chk-arena-auto-passar-turno');
    const autoPassar = chkAutoPassar ? chkAutoPassar.checked : false;
    if (autoPassar && a.acoesPadraoRestantes <= 0) {
        setTimeout(() => encerrarTurnoJogadorArenaJS(), 650);
    }
}

function encerrarTurnoJogadorArenaJS() {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    if (!a || a.encerrado) return;
    if (a.faseTurno === 'REACAO_JOGADOR' && a.ataqueInimigoPendente) {
        resolverReacaoJogadorArenaJS('NENHUMA');
        return;
    }
    executarTurnoDaCriaturaArenaJS(null);
}

// ==============================================================================
// EXECUÇÃO DO TURNO DA CRIATURA (TODAS AS AÇÕES DA FICHA DO CAP. 7)
// ==============================================================================
function executarTurnoDaCriaturaArenaJS(indiceAcaoForcada) {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    if (!a || a.encerrado) return;
    const st = garantirEstadoFichaParaArena();
    const priv = a._privadoCriatura;

    a.faseTurno = 'TURNO_CRIATURA';
    if (typeof processarCondicoesInicioTurnoCriaturasArenaJS === 'function') {
        processarCondicoesInicioTurnoCriaturasArenaJS(a, st);
        if (a.encerrado) { atualizarPlacarVisualArena(); return; }
    }

    let logRegen = '';
    const mCura = (priv.habilidadesResumo || '').match(/Cura Acelerada\s*(\d+)|Regeneração[^\d]*(\d+)|Unidos Venceremos/i);
    if (mCura && priv.pvAtual > 0 && priv.pvAtual < priv.pvMax) {
        const valCura = parseInt(mCura[1] || mCura[2] || '10', 10);
        const curaReal = Math.min(priv.pvMax - priv.pvAtual, Math.max(4, Math.round(valCura * 0.5)));
        if (curaReal > 0) {
            priv.pvAtual += curaReal;
            logRegen = `<strong>Cura Acelerada / Regeneração da Ficha:</strong> ${priv.nomeCriatura} regenerou <strong>+${curaReal} PV</strong> no início do turno!<br>`;
        }
    }

    const repertorio = priv.repertorioAcoes || extrairRepertorioAcoesCriaturaJS(priv);
    let acaoEscolhida = repertorio[0];
    if (indiceAcaoForcada !== null && indiceAcaoForcada !== undefined && repertorio[indiceAcaoForcada]) {
        acaoEscolhida = repertorio[indiceAcaoForcada];
    } else if (repertorio.length > 1) {
        const acaoSopro = repertorio.find(x => x.id === 'CRIATURA_SOPRO_AREA');
        const acaoMagia = repertorio.find(x => x.id === 'CRIATURA_MAGIA');
        const acaoHab = repertorio.find(x => x.id === 'CRIATURA_HABILIDADE_ESPECIAL');
        if (acaoSopro && a.recargaSoproCriatura <= 0) {
            acaoEscolhida = acaoSopro;
            a.recargaSoproCriatura = 2;
        } else if (acaoMagia && (a.turno % 2 === 1 || Math.random() < 0.55)) {
            acaoEscolhida = acaoMagia;
        } else if (acaoHab && Math.random() < 0.45) {
            acaoEscolhida = acaoHab;
        } else {
            acaoEscolhida = repertorio[0];
        }
    }
    if (a.recargaSoproCriatura > 0 && acaoEscolhida.id !== 'CRIATURA_SOPRO_AREA') {
        a.recargaSoproCriatura -= 1;
    }
    const fxEspecialEscolhido = acaoEscolhida.efeitoAnimacao || (
        acaoEscolhida.id === 'CRIATURA_SOPRO_AREA' ? 'ANIM_AMEACA_SOPRO_FOGO' :
        (acaoEscolhida.id === 'CRIATURA_MAGIA' ? 'ANIM_AMEACA_DRENAR_NECROMANCIA' :
        (acaoEscolhida.id === 'CRIATURA_HABILIDADE_ESPECIAL' ? 'ANIM_AMEACA_INSANIDADE_TERROR' : 'ANIM_AMEACA_GARRAS_MORDIDA'))
    );
    dispararPopupDanoJRPG(
        `${acaoEscolhida.icone} ${acaoEscolhida.nome.slice(0, 24)}!`,
        '#F87171',
        'HEROI',
        fxEspecialEscolhido,
        `${acaoEscolhida.icone} ${priv.nomeCriatura} usou ${acaoEscolhida.nome}!`
    );

    const defBaseAtivaHeroi = a.defHeroiBase + a.bonusDefTemp + (a.armaduraArcanaCenaBonus || (a.armaduraArcanaCena ? 5 : 0));
    const dadosCriatura = [];

    if (acaoEscolhida.tipo === 'EFEITO_RESISTENCIA') {
        const perRes = acaoEscolhida.periciaResistencia || 'Reflexos';
        const bonusResHeroi = st.est.bonusPericias[perRes] !== undefined ? st.est.bonusPericias[perRes] : Math.floor(st.nivel / 2);
        const d20ResH = Math.floor(Math.random() * 20) + 1;
        const totResH = d20ResH + bonusResHeroi;
        const cdCriatura = acaoEscolhida.cd || priv.cdEfeito || 18;
        const passouOriginal = (d20ResH === 20) || (d20ResH !== 1 && totResH >= cdCriatura);

        let somaDadosSopro = 0;
        for (let k = 0; k < 4; k++) {
            const vS = Math.floor(Math.random() * 8) + 1;
            somaDadosSopro += vS;
            dadosCriatura.push({ faces: 8, valor: vS, critico: vS === 8, cor: '#991B1B', label: `${acaoEscolhida.icone} Dado #${k+1}` });
        }
        dadosCriatura.push({
            faces: 20,
            valor: d20ResH,
            critico: passouOriginal,
            falhaCritica: !passouOriginal,
            cor: passouOriginal ? '#15803D' : '#7F1D1D',
            label: `Sua ${perRes} d20(${d20ResH})+${bonusResHeroi}=${totResH} vs CD ${cdCriatura}`
        });

        const danoBrutoEfeito = Math.max(6, Math.round(acaoEscolhida.danoBase * (0.85 + (somaDadosSopro / 32) * 0.30)));
        const temEvasao = (perRes === 'Reflexos') && (['ladino', 'bucaneiro'].includes((st.classe.nome || '').toLowerCase()) && st.nivel >= 2);
        const danoSePassar = temEvasao ? 0 : Math.floor(danoBrutoEfeito * 0.5);
        const danoPrevisto = Math.max(0, (passouOriginal ? danoSePassar : danoBrutoEfeito) - a.rdTemp);

        const anuncioHTML = `
            ${logRegen}
            ${acaoEscolhida.icone} <strong>${priv.nomeCriatura} usou [${acaoEscolhida.categoria}]: ${acaoEscolhida.nome}!</strong><br>
            Seu Teste de <strong>${perRes}</strong>: rolou <code>1d20(${d20ResH}) + ${bonusResHeroi} = ${totResH}</code> vs. <strong>CD ${cdCriatura}</strong> 
            <strong style="color:${passouOriginal ? '#4ADE80' : '#F87171'};">${passouOriginal ? (temEvasao ? 'PASSOU COM EVASÃO (0 DANO!)' : 'PASSOU (Dano reduzido à metade!)') : 'FALHOU NO TESTE (100% do impacto!)'}</strong><br>
            <strong>Dano Bruto Rolado:</strong> ${danoBrutoEfeito} (${acaoEscolhida.elemento || 'Efeito'}) <strong>Dano Previsto após RD (${a.rdTemp}): <span style="color:#FACC15;">${danoPrevisto} PV</span></strong>!
        `;

        a.ataqueInimigoPendente = {
            tipo: 'EFEITO_RESISTENCIA',
            acao: acaoEscolhida,
            perRes,
            d20ResH,
            bonusResHeroi,
            totResH,
            cdCriatura,
            passouOriginal,
            temEvasao,
            danoBruto: danoBrutoEfeito,
            danoPrevisto,
            dadosCriatura,
            logRegen,
            anuncioHTML
        };
    } else {
        const penAtqCriatura = a.criaturaCaida ? 5 : 0;
        const bAtqEfetivo = acaoEscolhida.bonusAtaque - penAtqCriatura;
        const d20Ini = Math.floor(Math.random() * 20) + 1;
        const totAtq = d20Ini + bAtqEfetivo;
        const acertouOriginal = (d20Ini === 20) || (d20Ini !== 1 && totAtq >= defBaseAtivaHeroi);

        dadosCriatura.push({
            faces: 20,
            valor: d20Ini,
            critico: d20Ini === 20,
            falhaCritica: d20Ini === 1,
            cor: '#7F1D1D',
            label: `Inimigo d20(${d20Ini})+${bAtqEfetivo}=${totAtq}`
        });

        let somaDanoM = 0;
        for (let k = 0; k < 2; k++) {
            const vM = Math.floor(Math.random() * 8) + 1;
            somaDanoM += vM;
            dadosCriatura.push({ faces: 8, valor: vM, cor: '#991B1B', label: `Dano Criatura #${k+1}` });
        }

        const danoBruto = acertouOriginal ? Math.max(4, Math.round(acaoEscolhida.danoBase * (0.86 + (somaDanoM / 16) * 0.28) * (d20Ini === 20 ? 1.5 : 1.0))) : 0;
        const danoPrevisto = acertouOriginal ? Math.max(1, danoBruto - a.rdTemp) : 0;

        const anuncioHTML = `
            ${logRegen}
            <strong>${priv.nomeCriatura} executa [${acaoEscolhida.categoria}]: ${acaoEscolhida.nome}!</strong><br>
            Rolagem de Ataque da Criatura: <code>1d20(${d20Ini}) + ${bAtqEfetivo} = ${totAtq}</code> vs. <strong>Sua Defesa Atual (${defBaseAtivaHeroi})</strong> 
            <strong style="color:${acertouOriginal ? '#F87171' : '#4ADE80'};">${acertouOriginal ? (d20Ini === 20 ? 'ACERTO CRÍTICO IMINENTE!' : 'ACERTO IMINENTE!') : 'ERROU SUA DEFESA!'}</strong>
            ${acertouOriginal ? `<br><strong>Dano Previsto:</strong> ${danoBruto} bruto - ${a.rdTemp} RD = <strong style="color:#FACC15;">${danoPrevisto} PV</strong>!` : ''}
        `;

        a.ataqueInimigoPendente = {
            tipo: 'ATAQUE_FISICO',
            acao: acaoEscolhida,
            d20Ini,
            bAtqEfetivo,
            totAtq,
            defAlvoOriginal: defBaseAtivaHeroi,
            ehCrit20: d20Ini === 20,
            acertouOriginal,
            danoBruto,
            danoPrevisto,
            dadosCriatura,
            logRegen,
            anuncioHTML
        };
    }

    animarBandejaDadosVisual(
        a.ataqueInimigoPendente.dadosCriatura,
        a.ataqueInimigoPendente.anuncioHTML,
        `Turno #${a.turno} (TURNO DE ${priv.nomeCriatura.toUpperCase()}) — Rolagem da Ameaça`
    );

    const chkAutoReacao = document.getElementById('chk-arena-auto-reacao');
    const usarAutoReacao = chkAutoReacao ? chkAutoReacao.checked : false;
    const reacoesDaFicha = listarReacoesDisponiveisHeroiJS(st, a, a.ataqueInimigoPendente).filter(r => r.disponivel);

    // Se o ataque já errou (0 dano) OU se o personagem não possui nenhuma habilidade/magia de Reação na ficha, resolve direto!
    if (a.ataqueInimigoPendente.danoPrevisto <= 0 || !a.reacaoDisponivel || reacoesDaFicha.length === 0) {
        resolverReacaoJogadorArenaJS('NENHUMA');
        return;
    }

    if (usarAutoReacao) {
        const melhorReac = reacoesDaFicha.find(r => r.destaque) || reacoesDaFicha[0];
        resolverReacaoJogadorArenaJS(melhorReac ? melhorReac.id : 'NENHUMA');
        return;
    }

    a.faseTurno = 'REACAO_JOGADOR';
    tocarSomJRPG('MISS_DEFESA');
    atualizarPlacarVisualArena();
}

function atualizarResumoComboReacaoArenaJS() {
    const chks = Array.from(document.querySelectorAll('.chk-reacao-combo-item:checked'));
    const btn = document.getElementById('btn-executar-combo-reacoes');
    if (!btn) return;
    let somaPM = 0;
    for (const c of chks) {
        somaPM += parseInt(c.getAttribute('data-custo-pm') || '0', 10);
    }
    btn.innerHTML = chks.length > 0
        ? `Executar Combo (${chks.length} Reação(ões) · -${somaPM} PM Total)`
        : `Marque Reações Abaixo para Combar`;
}

function resolverReacaoJogadorArenaJS(idReacaoEscolhida) {
    const a = __ARENA_STATE__;
    if (!a || !a.ataqueInimigoPendente) return;
    const st = garantirEstadoFichaParaArena();
    const priv = a._privadoCriatura;
    const cr = a.crencaIA;
    const pend = a.ataqueInimigoPendente;

    let bonusDefReacao = 0;
    let bonusResReacao = 0;
    const resArsHeroi = calcularResumoArsenalSuperiorEMagicoJS(st);
    let rdExtraReacao = (resArsHeroi ? resArsHeroi.rdArmadura : 0);
    let cortaMetadeReacao = false;
    let evitouPorAparar = false;
    let rerrolouSortudo = false;
    let d20SortudoNovo = 0;
    const logsReacoes = [];

    let listaIdsReacao = [];
    if (idReacaoEscolhida === 'COMBO_SELECIONADO') {
        const chks = Array.from(document.querySelectorAll('.chk-reacao-combo-item:checked'));
        listaIdsReacao = chks.map(c => c.value);
    } else if (Array.isArray(idReacaoEscolhida)) {
        listaIdsReacao = idReacaoEscolhida;
    } else if (idReacaoEscolhida && idReacaoEscolhida !== 'NENHUMA') {
        listaIdsReacao = [idReacaoEscolhida];
    }

    // Aplica cada reação selecionada no combo (ex.: Armadura Arcana + Campo de Força + Durão + Sortudo)
    const gruposUsados = new Set();
    for (const idR of listaIdsReacao) {
        const grupoBase = idR.startsWith('REACAO_ARMADURA_ARCANA') ? 'AA'
            : (idR.startsWith('REACAO_CAMPO_DE_FORCA') ? 'CF'
            : (idR.startsWith('REACAO_ESCUDO_DA_FE') ? 'EF'
            : (idR.startsWith('REACAO_PROTECAO_DIVINA') ? 'PD' : idR)));
        if (gruposUsados.has(grupoBase)) continue; // Evita duplicar duas versões da mesma magia no mesmo impacto
        gruposUsados.add(grupoBase);

        if (idR === 'REACAO_ARMADURA_ARCANA_2PM' && a.pmHeroi >= 2) {
            a.pmHeroi -= 2;
            bonusDefReacao += 5;
            logsReacoes.push(`<strong>Armadura Arcana (Reação, -2 PM, p. 179):</strong> +5 na Defesa!`);
            tocarSomJRPG('MAGIA');
        } else if (idR.startsWith('REACAO_ARMADURA_ARCANA_APRIM_')) {
            const p = idR.split('_');
            const pmG = parseInt(p[4] || '4', 10);
            const bDef = parseInt(p[5] || '6', 10);
            if (a.pmHeroi >= pmG) {
                a.pmHeroi -= pmG;
                bonusDefReacao += bDef;
                logsReacoes.push(`<strong>Armadura Arcana Aprimorada (Reação, -${pmG} PM, p. 179):</strong> +${bDef} na Defesa!`);
                tocarSomJRPG('MAGIA');
            }
        } else if (idR === 'REACAO_CAMPO_DE_FORCA_30' && a.pmHeroi >= 4) {
            a.pmHeroi -= 4;
            rdExtraReacao += 30;
            logsReacoes.push(`<strong>Campo de Força (Reação, -4 PM, p. 182):</strong> +30 de Redução de Dano (RD)!`);
            tocarSomJRPG('MAGIA');
        } else if (idR === 'REACAO_CAMPO_DE_FORCA_50' && a.pmHeroi >= 6) {
            a.pmHeroi -= 6;
            rdExtraReacao += 50;
            logsReacoes.push(`<strong>Campo de Força Aprimorado (Reação, -6 PM, p. 182):</strong> +50 de Redução de Dano (RD)!`);
            tocarSomJRPG('MAGIA');
        } else if (idR === 'REACAO_SALTO_DIMENSIONAL' && a.pmHeroi >= 4) {
            a.pmHeroi -= 4;
            bonusDefReacao += 5;
            bonusResReacao += 5;
            logsReacoes.push(`<strong>Salto Dimensional (Reação, -4 PM, p. 205):</strong> +5 na Defesa e +5 em Reflexos!`);
            tocarSomJRPG('MAGIA');
        } else if (idR === 'REACAO_ESCUDO_DA_FE_BASE' && a.pmHeroi >= 1) {
            a.pmHeroi -= 1;
            bonusDefReacao += 2;
            logsReacoes.push(`<strong>Escudo da Fé (Reação, -1 PM, p. 191):</strong> +2 na Defesa!`);
            tocarSomJRPG('MAGIA');
        } else if (idR.startsWith('REACAO_ESCUDO_DA_FE_APRIM_')) {
            const p = idR.split('_');
            const pmG = parseInt(p[5] || '3', 10);
            const bDef = parseInt(p[6] || '3', 10);
            if (a.pmHeroi >= pmG) {
                a.pmHeroi -= pmG;
                bonusDefReacao += bDef;
                logsReacoes.push(`<strong>Escudo da Fé Aprimorado (Reação, -${pmG} PM, p. 191):</strong> +${bDef} na Defesa!`);
                tocarSomJRPG('MAGIA');
            }
        } else if (idR === 'REACAO_PROTECAO_DIVINA_BASE' && a.pmHeroi >= 1) {
            a.pmHeroi -= 1;
            bonusResReacao += 2;
            logsReacoes.push(`<strong>Proteção Divina (Reação, -1 PM, p. 201):</strong> +2 no Teste de Resistência!`);
            tocarSomJRPG('MAGIA');
        } else if (idR.startsWith('REACAO_PROTECAO_DIVINA_APRIM_')) {
            const p = idR.split('_');
            const pmG = parseInt(p[4] || '3', 10);
            const bRes = parseInt(p[5] || '3', 10);
            if (a.pmHeroi >= pmG) {
                a.pmHeroi -= pmG;
                bonusResReacao += bRes;
                logsReacoes.push(`<strong>Proteção Divina Aprimorada (Reação, -${pmG} PM, p. 201):</strong> +${bRes} no Teste de Resistência!`);
                tocarSomJRPG('MAGIA');
            }
        } else if (idR === 'REACAO_QUEDA_SUAVE_PROJETIL' && a.pmHeroi >= 2) {
            a.pmHeroi -= 2;
            cortaMetadeReacao = true;
            logsReacoes.push(`<strong>Queda Suave Aprimorada (Reação, -2 PM, p. 202):</strong> Reduz o dano à metade!`);
            tocarSomJRPG('MAGIA');
        } else if (idR === 'REACAO_DURAO' && a.pmHeroi >= 3) {
            a.pmHeroi -= 3;
            cortaMetadeReacao = true;
            logsReacoes.push(`<strong>Durão (Reação, -3 PM, p. 65):</strong> Reduz o dano à metade (50%)!`);
            tocarSomJRPG('MISS_DEFESA');
        } else if (idR === 'REACAO_ROLAMENTO_DEFENSIVO' && a.pmHeroi >= 2) {
            a.pmHeroi -= 2;
            cortaMetadeReacao = true;
            logsReacoes.push(`<strong>Rolamento Defensivo (Reação, -2 PM, p. 74):</strong> Reduz o dano à metade (50%)!`);
            tocarSomJRPG('MISS_DEFESA');
        } else if (idR === 'REACAO_APARAR' && a.pmHeroi >= 1) {
            a.pmHeroi -= 1;
            const bLutaH = Math.max(st.est.bonusPericias['Luta'] || 0, st.est.bonusPericias['Pontaria'] || 0);
            const d20Ap = Math.floor(Math.random() * 20) + 1;
            const totAp = d20Ap + bLutaH;
            if (totAp > (pend.totAtq || 0)) evitouPorAparar = true;
            logsReacoes.push(`<strong>Aparar (Reação, -1 PM, p. 51):</strong> Rolou <code>1d20(${d20Ap})+${bLutaH}=${totAp}</code> vs <code>${pend.totAtq || 20}</code> <strong>${evitouPorAparar ? 'APAROU O ATAQUE!' : 'Não superou o ataque'}</strong>`);
            tocarSomJRPG(evitouPorAparar ? 'ESPADA_SLASH' : 'MISS_DEFESA');
        } else if (idR === 'REACAO_BALUARTE' && a.pmHeroi >= 1) {
            a.pmHeroi -= 1;
            const bBal = 2 + 2 * Math.floor((st.nivel - 1) / 4);
            bonusDefReacao += bBal;
            bonusResReacao += bBal;
            a.bonusDefTemp += bBal;
            logsReacoes.push(`<strong>Baluarte (Reação, -1 PM, p. 56):</strong> +${bBal} na Defesa e nas Resistências!`);
            tocarSomJRPG('MISS_DEFESA');
        } else if (idR === 'REACAO_ORGULHO_NOBRE' && a.pmHeroi >= 1) {
            const pmOrg = Math.min(2, a.pmHeroi, st.nivel);
            a.pmHeroi -= pmOrg;
            bonusResReacao += pmOrg * 2;
            logsReacoes.push(`<strong>Orgulho (-${pmOrg} PM, p. 79):</strong> +${pmOrg * 2} no Teste de Resistência!`);
            tocarSomJRPG('MISS_DEFESA');
        } else if (idR === 'REACAO_ENGENHOSIDADE_KLIREN' && a.pmHeroi >= 2) {
            a.pmHeroi -= 2;
            const bInt = Math.max(1, st.est.finais.INT);
            bonusResReacao += bInt;
            logsReacoes.push(`<strong>Engenhosidade (-2 PM, p. 23):</strong> +${bInt} (INT) no Teste de Resistência!`);
            tocarSomJRPG('MAGIA');
        } else if (idR === 'REACAO_SORTUDO_2D20' && a.pmHeroi >= 3) {
            a.pmHeroi -= 3;
            rerrolouSortudo = true;
            d20SortudoNovo = Math.floor(Math.random() * 20) + 1;
            const melhorSortudo = Math.max(pend.d20ResH || 10, d20SortudoNovo);
            const piorSortudo = Math.min(pend.d20ResH || 10, d20SortudoNovo);
            logsReacoes.push(`<strong>Sortudo (-3 PM, p. 129):</strong> Rerrolou Resistência [2d20: ${pend.d20ResH || 10} e ${d20SortudoNovo} Melhor: ${melhorSortudo} (descartado ${piorSortudo})]!`);
            tocarSomJRPG('DADOS');
        }
    }
    if (logsReacoes.length > 0) {
        a.reacaoDisponivel = false;
    }
    const tagReacaoLog = logsReacoes.join('<br>↳ ');

    let danoFinalSofrido = 0;
    let resumoFinalCriatura = '';

    if (pend.tipo === 'EFEITO_RESISTENCIA') {
        const d20Efetivo = rerrolouSortudo ? Math.max(pend.d20ResH, d20SortudoNovo) : pend.d20ResH;
        const totResFinal = d20Efetivo + pend.bonusResHeroi + bonusResReacao;
        const passouFinal = (d20Efetivo === 20) || (d20Efetivo !== 1 && totResFinal >= pend.cdCriatura);
        const danoBasePosRes = passouFinal ? (pend.temEvasao ? 0 : Math.floor(pend.danoBruto * 0.5)) : pend.danoBruto;
        let dLiq = Math.max(0, danoBasePosRes - (a.rdTemp + rdExtraReacao));
        if (cortaMetadeReacao) dLiq = Math.floor(dLiq * 0.5);
        danoFinalSofrido = dLiq;

        resumoFinalCriatura = `${pend.logRegen || ''}${pend.acao.icone} <strong>[Turno de ${priv.nomeCriatura}] ${pend.acao.nome}:</strong> Teste de ${pend.perRes} <code>${totResFinal}</code> vs CD ${pend.cdCriatura} (${passouFinal ? 'PASSOU NA RESISTÊNCIA!' : 'FALHOU'}) Causou <strong>${danoFinalSofrido} de dano</strong> (${pend.danoBruto} bruto)${tagReacaoLog ? '<br>↳ ' + tagReacaoLog : ''}`;
    } else {
        const defFinalComReacao = pend.defAlvoOriginal + bonusDefReacao;
        const acertouFinal = !evitouPorAparar && ((pend.d20Ini === 20) || (pend.d20Ini !== 1 && pend.totAtq >= defFinalComReacao));
        if (acertouFinal) {
            let dLiq = Math.max(0, pend.danoBruto - (a.rdTemp + rdExtraReacao));
            if (cortaMetadeReacao) dLiq = Math.floor(dLiq * 0.5);
            danoFinalSofrido = dLiq;
            cr.golpesCriaturaObservados.push(pend.danoBruto);
            resumoFinalCriatura = `${pend.logRegen || ''}<strong>[Turno de ${priv.nomeCriatura}] ${pend.acao.nome}:</strong> Rolou <code>1d20(${pend.d20Ini})+${pend.bAtqEfetivo}=${pend.totAtq}</code> vs Defesa ${defFinalComReacao} <strong>ACERTOU</strong> causando <strong>${danoFinalSofrido} de dano final</strong> (${pend.danoBruto} bruto)${tagReacaoLog ? '<br>↳ ' + tagReacaoLog : ''}`;
        } else {
            danoFinalSofrido = 0;
            resumoFinalCriatura = `${pend.logRegen || ''}<strong>[Turno de ${priv.nomeCriatura}] ${pend.acao.nome}:</strong> Rolou <code>1d20(${pend.d20Ini})+${pend.bAtqEfetivo}=${pend.totAtq}</code> vs Defesa ${defFinalComReacao} <strong style="color:#4ADE80;">${evitouPorAparar ? 'APARADO COM SUCESSO!' : (pend.acertouOriginal ? 'EVITADO PELA SUA REAÇÃO!' : 'ERROU SUA DEFESA!')} (0 de dano!)</strong>${tagReacaoLog ? '<br>↳ ' + tagReacaoLog : ''}`;
        }
    }

    const idAcInim = (pend.acao && pend.acao.id) ? pend.acao.id : '';
    const fxInimigo = (pend.acao && pend.acao.efeitoAnimacao)
        ? pend.acao.efeitoAnimacao
        : (idAcInim === 'CRIATURA_SOPRO_AREA'
            ? 'ANIM_AMEACA_SOPRO_FOGO'
            : ((idAcInim === 'CRIATURA_MAGIA' || idAcInim === 'CRIATURA_HABILIDADE_ESPECIAL')
                ? 'ANIM_AMEACA_INSANIDADE_TERROR'
                : 'ANIM_AMEACA_GARRAS_MORDIDA'));
    const somInimigo = idAcInim === 'CRIATURA_SOPRO_AREA'
        ? 'SOPRO_DRAGAO'
        : ((idAcInim === 'CRIATURA_MAGIA' || idAcInim === 'CRIATURA_HABILIDADE_ESPECIAL')
            ? 'MAGIA_TREVAS'
            : 'MORDIDA_GARRAS_MONSTRO');

    if (danoFinalSofrido > 0) {
        let restDano = danoFinalSofrido;
        if (a.pvTempHeroi > 0) {
            const absTemp = Math.min(a.pvTempHeroi, restDano);
            a.pvTempHeroi -= absTemp;
            restDano -= absTemp;
        }
        a.pvHeroi = Math.max(0, a.pvHeroi - restDano);
        dispararAnimacaoCardArena('arena-card-heroi', 'hit-shake');
        tocarSomJRPG(somInimigo);
        dispararPopupDanoJRPG(`-${danoFinalSofrido} PV!`, '#EF4444', 'HEROI', fxInimigo, `${priv.nomeCriatura} executou ${pend.acao.nome} (-${danoFinalSofrido} PV)!`);
    } else {
        tocarSomJRPG('CURA_BUFF_ESCUDO');
        dispararPopupDanoJRPG(`EVITOU (0 DANO)!`, '#38BDF8', 'HEROI', 'ANIM_BUFF_CURA_REACAO', `${st.nome} bloqueou/evitou ${pend.acao.nome} de ${priv.nomeCriatura}!`);
    }

    if (a.pvHeroi <= 0) {
        a.encerrado = true;
        resumoFinalCriatura += ` <strong>O Herói tombou em combate!</strong>`;
    }

    a.ataqueInimigoPendente = null;
    registrarLinhaLogArena(resumoFinalCriatura);

    if (!a.encerrado) {
        a.turno += 1;
        a.faseTurno = 'TURNO_JOGADOR';
        a.acoesPadraoMax = 1 + (a.velocidadeAtiva ? 1 : 0);
        a.acoesPadraoRestantes = a.acoesPadraoMax;
        a.acoesMovimentoMax = 1;
        a.acoesMovimentoRestantes = 1;
        a.reacaoDisponivel = true;
        a.bonusDefTemp = 0;
        const chkMira = document.getElementById('chk-cap5-mira');
        if (chkMira) chkMira.checked = false;
    }

    atualizarPlacarVisualArena();
}

function simularCombateInteiroAnimado() {
    reiniciarCombateArenaVisual();
    const chkAutoReacao = document.getElementById('chk-arena-auto-reacao');
    const prevAutoReacao = chkAutoReacao ? chkAutoReacao.checked : false;
    if (chkAutoReacao) chkAutoReacao.checked = true;

    let passos = 0;
    const timer = setInterval(() => {
        passos++;
        if (!__ARENA_STATE__ || __ARENA_STATE__.encerrado || passos > 10) {
            if (chkAutoReacao) chkAutoReacao.checked = prevAutoReacao;
            clearInterval(timer);
            return;
        }
        const a = __ARENA_STATE__;
        const stA = garantirEstadoFichaParaArena();
        if (a.faseTurno === 'TURNO_JOGADOR') {
            if (a.acoesMovimentoRestantes > 0) {
                executarAcaoCombateVisual('MOVIMENTO_POSICIONAR_FLANQUEAR');
            }
            const temGP = (stA.poderes || []).some(p => (p.nome || '').toLowerCase() === 'golpe pessoal');
            if (passos <= 2 && temGP && a.acoesMovimentoRestantes > 0) {
                executarAcaoCombateVisual('GOLPE_PESSOAL');
            } else if (ehConjuradorJS(stA.classe, stA.poderes) && (stA.magias || []).length > 0) {
                conjurarMagiaComAprimoramentosArenaJS();
            } else {
                executarAcaoCombateVisual('ATAQUE_ESPECIAL_COMBO');
            }
            if (!a.encerrado) {
                encerrarTurnoJogadorArenaJS();
            }
        } else {
            encerrarTurnoJogadorArenaJS();
        }
    }, 420);
}

const CATALOGO_BUILDS_RL_POR_TIPO = {
    'GERAL_EQUILIBRADO': {
        titulo: 'Build Geral — Competição Global Equilibrada (Todas as 14 Classes JdA, incl. Lutador Desarmado & Nobre Suporte)',
        candidatos: [
            { arq: 'Conjurador Arcano: Mago', cl: 'Arcanista', raca: 'Elfo', sub: 'Mago Evocador (Bola de Fogo + Campo de Força RD 30)' },
            { arq: 'Conjurador Arcano: Feiticeiro', cl: 'Arcanista', raca: 'Qareen', sub: 'Feiticeiro Elemental (Magia Acelerada + Tatuagem Mística)' },
            { arq: 'Suporte Divino: Clérigo', cl: 'Clérigo', raca: 'Anão', sub: 'Clérigo de Guerra/Luz (Prece de Combate + Escudo da Fé)' },
            { arq: 'Suporte Divino: Druida', cl: 'Druida', raca: 'Dahllan', sub: 'Druida de Allihanna (Magia Natural + Forma Selvagem)' },
            { arq: 'Conjurador: Bardo', cl: 'Bardo', raca: 'Qareen', sub: 'Bardo Virtuoso (Inspiração + Esgrima Mágica + Prestidigitação)' },
            { arq: 'Marcial: Duas Mãos Pesado', cl: 'Guerreiro', raca: 'Minotauro', sub: 'Guerreiro Duas Mãos (Ataque Especial + Golpe Pessoal)' },
            { arq: 'Marcial: Duas Mãos Pesado', cl: 'Bárbaro', raca: 'Minotauro', sub: 'Bárbaro Berserker (Fúria + Frenesi + Alma de Bronze)' },
            { arq: 'Lutador: Ataque Desarmado', cl: 'Lutador', raca: 'Lefou', sub: 'Lutador Desarmado (Briga + Golpe Relâmpago + Trocação + Casca Grossa)' },
            { arq: 'Marcial: Uma Mão Duelista', cl: 'Ladino', raca: 'Goblin', sub: 'Ladino Assassino (Ataque Furtivo + Assassinar 2x + Emboscar)' },
            { arq: 'Suporte Tático: Comandante', cl: 'Nobre', raca: 'Humano', sub: 'Nobre Suporte (Autoconfiança + Orgulho + Gritar Ordens + Palavras Afiadas)' },
            { arq: 'Especialista: Engenhoqueiro', cl: 'Inventor', raca: 'Kliren', sub: 'Inventor Engenhoqueiro/Armeiro (Engenhosidade +INT Atq/Dano + Engenhocas)' },
            { arq: 'Tanque: Arma e Escudo', cl: 'Paladino', raca: 'Humano', sub: 'Paladino Vingador (Golpe Divino Escalonado + Vindicação + Égide Sagrada)' },
            { arq: 'Marcial: Dano Arqueiro', cl: 'Caçador', raca: 'Elfo', sub: 'Caçador Arqueiro (Marca da Presa + Disparo Rápido)' },
            { arq: 'Marcial: Uma Mão Duelista', cl: 'Bucaneiro', raca: 'Goblin', sub: 'Bucaneiro Duelista (Audácia + Aparar + Esgrima)' },
            { arq: 'Tanque: Arma e Escudo', cl: 'Cavaleiro', raca: 'Anão', sub: 'Cavaleiro Baluarte (Couraça + Escudo Pesado + Provocação)' }
        ]
    },
    'CONJURADORES_TODOS': {
        titulo: 'Apenas Conjuradores (Arcanistas, Clérigos, Druidas & Bardos)',
        candidatos: [
            { arq: 'Conjurador Arcano: Mago', cl: 'Arcanista', raca: 'Elfo', sub: 'Arquimago de Grimório (INT Máxima + Magia Ilimitada)' },
            { arq: 'Conjurador Arcano: Feiticeiro', cl: 'Arcanista', raca: 'Qareen', sub: 'Feiticeiro Dracônico/Rubro (CAR + Magia Acelerada)' },
            { arq: 'Conjurador Arcano: Bruxo', cl: 'Arcanista', raca: 'Kliren', sub: 'Bruxo de Foco Arcano (Controle + Engenhosidade)' },
            { arq: 'Conjurador Arcano: Mago', cl: 'Arcanista', raca: 'Osteon', sub: 'Necromante de Aslothia (RD 5 Óssea + Toque Vampírico)' },
            { arq: 'Suporte Divino: Clérigo', cl: 'Clérigo', raca: 'Anão', sub: 'Clérigo Invocador (Armadura Pesada + Chamas Divinas)' },
            { arq: 'Suporte Divino: Clérigo', cl: 'Clérigo', raca: 'Suraggel (Aggelus)', sub: 'Teurgista Celestial (SAB Máxima + Luz Sagrada)' },
            { arq: 'Suporte Divino: Druida', cl: 'Druida', raca: 'Dahllan', sub: 'Druida Conjurador de Galrasia (Controlar Plantas + Raio Solar)' },
            { arq: 'Conjurador: Bardo', cl: 'Bardo', raca: 'Qareen', sub: 'Bardo Virtuoso (Prestidigitação: Magia como Ação Livre!)' }
        ]
    },
    'CONJURADOR_ARCANO_ESPECIFICO': {
        titulo: 'Específico — Conjurador Arcano (Mago, Feiticeiro & Bruxo)',
        candidatos: [
            { arq: 'Conjurador Arcano: Mago', cl: 'Arcanista', raca: 'Elfo', sub: 'Mago Élfico de Lenórienn (+PM Racial + Bola de Fogo)' },
            { arq: 'Conjurador Arcano: Feiticeiro', cl: 'Arcanista', raca: 'Qareen', sub: 'Feiticeiro Qareen (-1 PM na Magia + Magia Acelerada)' },
            { arq: 'Conjurador Arcano: Bruxo', cl: 'Arcanista', raca: 'Kliren', sub: 'Bruxo Kliren (Foco Arcano + Campo de Força RD 30)' },
            { arq: 'Conjurador Arcano: Mago', cl: 'Arcanista', raca: 'Osteon', sub: 'Arquimago Osteon (Memória Póstuma + Imunidades)' },
            { arq: 'Conjurador Arcano: Feiticeiro', cl: 'Arcanista', raca: 'Suraggel (Sulfure)', sub: 'Feiticeiro Abissal (Relâmpago + Salto Dimensional)' },
            { arq: 'Conjurador Arcano: Mago', cl: 'Arcanista', raca: 'Humano', sub: 'Mago Versátil da Academia Arcana (Arcano de Batalha)' },
            { arq: 'Conjurador Arcano: Feiticeiro', cl: 'Arcanista', raca: 'Sílfide', sub: 'Feiticeira Fada (Voo + Ilusão/Controle Mental)' }
        ]
    },
    'CONJURADOR_DIVINO_ESPECIFICO': {
        titulo: 'Específico — Conjurador Divino & Místico (Clérigo, Druida & Bardo)',
        candidatos: [
            { arq: 'Suporte Divino: Clérigo', cl: 'Clérigo', raca: 'Anão', sub: 'Clérigo de Heredrimm (Alta Defesa + Infligir Ferimentos)' },
            { arq: 'Suporte Divino: Clérigo', cl: 'Clérigo', raca: 'Suraggel (Aggelus)', sub: 'Clérigo Solar de Azgher (SAB +4 + Curar Ferimentos)' },
            { arq: 'Suporte Divino: Clérigo', cl: 'Clérigo', raca: 'Humano', sub: 'Clérigo de Guerra de Arsenal (Prece de Combate + Maça)' },
            { arq: 'Suporte Divino: Druida', cl: 'Druida', raca: 'Dahllan', sub: 'Druida de Allihanna (Armadura de Allihanna + Magia Natural)' },
            { arq: 'Suporte Divino: Druida', cl: 'Druida', raca: 'Trog', sub: 'Xamã Reptiliano (Mordida + Mau Cheiro + Magias Divinas)' },
            { arq: 'Conjurador: Bardo', cl: 'Bardo', raca: 'Qareen', sub: 'Bardo de Wynna (Eclético + Magias Arcanas e Divinas)' }
        ]
    },
    'MARCIAIS_TODOS': {
        titulo: 'Apenas Combatentes Marciais (Corpo a Corpo & Distância)',
        candidatos: [
            { arq: 'Marcial: Duas Mãos Pesado', cl: 'Guerreiro', raca: 'Minotauro', sub: 'Guerreiro Montante/Machado Táurico + Chifres' },
            { arq: 'Marcial: Armas de Haste', cl: 'Guerreiro', raca: 'Minotauro', sub: 'Guerreiro Alabarda Alongada + Piqueiro' },
            { arq: 'Marcial: Duas Mãos Pesado', cl: 'Bárbaro', raca: 'Minotauro', sub: 'Bárbaro em Fúria + Crítico Brutal' },
            { arq: 'Marcial: Duas Armas', cl: 'Caçador', raca: 'Humano', sub: 'Caçador Ambidestro + Marca da Presa' },
            { arq: 'Marcial: Dano Arqueiro', cl: 'Caçador', raca: 'Elfo', sub: 'Arqueiro de Lenórienn (Arco Longo + Arqueiro)' },
            { arq: 'Marcial: Uma Mão Duelista', cl: 'Bucaneiro', raca: 'Goblin', sub: 'Bucaneiro Esgrimista (Florete Crítico 15/x2 + Aparar)' },
            { arq: 'Marcial: Duas Armas', cl: 'Lutador', raca: 'Trog', sub: 'Lutador Trocação + Golpe Relâmpago + Mordida' },
            { arq: 'Marcial: Uma Mão Duelista', cl: 'Ladino', raca: 'Goblin', sub: 'Assassino Furtivo (Ataque Furtivo + Rolamento Defensivo)' }
        ]
    },
    'MARCIAL_PESADO_ESPECIFICO': {
        titulo: 'Específico — Marcial Corpo a Corpo Pesado (Guerreiro, Bárbaro & Lutador)',
        candidatos: [
            { arq: 'Marcial: Duas Mãos Pesado', cl: 'Guerreiro', raca: 'Minotauro', sub: 'Guerreiro Minotauro (Montante + Golpe Pessoal + Chifres)' },
            { arq: 'Marcial: Armas de Haste', cl: 'Guerreiro', raca: 'Humano', sub: 'Guerreiro Mestre de Alabarda (Estilo de Haste + Derrubar)' },
            { arq: 'Marcial: Duas Mãos Pesado', cl: 'Bárbaro', raca: 'Minotauro', sub: 'Bárbaro Berserker (Fúria + Frenesi + Sangue dos Inimigos)' },
            { arq: 'Marcial: Duas Mãos Pesado', cl: 'Bárbaro', raca: 'Golem', sub: 'Colosso Golem Bárbaro (Chassi de Ferro + Marreta)' },
            { arq: 'Marcial: Duas Armas', cl: 'Lutador', raca: 'Trog', sub: 'Lutador de Pântano (Golpe Relâmpago + Mordida + Mau Cheiro)' },
            { arq: 'Marcial: Duas Mãos Pesado', cl: 'Guerreiro', raca: 'Lefou', sub: 'Guerreiro da Tormenta (Empunhadura Rubra + Carapaça)' }
        ]
    },
    'MARCIAL_AGIL_DISTANCIA': {
        titulo: 'Específico — Marcial Ágil, Duas Armas & Distância (Caçador, Bucaneiro, Ladino & Inventor)',
        candidatos: [
            { arq: 'Marcial: Dano Arqueiro', cl: 'Caçador', raca: 'Elfo', sub: 'Arqueiro de Elite (Arco Longo + Disparo Rápido + Marca)' },
            { arq: 'Marcial: Duas Armas', cl: 'Caçador', raca: 'Humano', sub: 'Patrulheiro de Duas Espadas (Ambidestria + Inimigo)' },
            { arq: 'Marcial: Uma Mão Duelista', cl: 'Bucaneiro', raca: 'Goblin', sub: 'Duelista Audacioso (Florete + Esgrima + Aparar)' },
            { arq: 'Marcial: Uma Mão Duelista', cl: 'Ladino', raca: 'Hynne', sub: 'Ladino Sombra (Ataque Furtivo + Velocidade Ladina)' },
            { arq: 'Marcial: Dano Arqueiro', cl: 'Inventor', raca: 'Kliren', sub: 'Mosqueteiro Balístico (Mosquete + Cano Raiado + Mira)' },
            { arq: 'Marcial: Duas Armas', cl: 'Caçador', raca: 'Medusa', sub: 'Caçadora Ofídica (Duas Armas + Natureza Venenosa +1d12)' }
        ]
    },
    'TANQUE_BALUARTE_ESPECIFICO': {
        titulo: 'Específico — Tanque & Baluarte Defensivo (Cavaleiro, Paladino, Guerreiro & Clérigo)',
        candidatos: [
            { arq: 'Tanque: Arma e Escudo', cl: 'Cavaleiro', raca: 'Anão', sub: 'Cavaleiro Baluarte de Heredrimm (Placas + Escudo + RD)' },
            { arq: 'Tanque: Arma e Escudo', cl: 'Paladino', raca: 'Humano', sub: 'Paladino Égide Sagrada (+CAR na Defesa + Cura pelas Mãos)' },
            { arq: 'Tanque: Arma e Escudo', cl: 'Guerreiro', raca: 'Golem', sub: 'Guerreiro Blindado Golem (Durão 50% Dano + Solidez)' },
            { arq: 'Tanque: Arma e Escudo', cl: 'Cavaleiro', raca: 'Osteon', sub: 'Cavaleiro Imortal Osteon (RD 5 + Baluarte + Desprezar)' },
            { arq: 'Suporte Divino: Clérigo', cl: 'Clérigo', raca: 'Anão', sub: 'Clérigo Baluarte Divino (Escudo da Fé + Vestimenta da Fé)' },
            { arq: 'Tanque: Arma e Escudo', cl: 'Paladino', raca: 'Minotauro', sub: 'Paladino Taurino (Golpe Divino + Escudo Pesado + Chifres)' }
        ]
    },
    'HIBRIDO_ESPECIALISTA': {
        titulo: 'Específico — Híbrido & Especialista (Paladino, Bardo, Inventor & Nobre)',
        candidatos: [
            { arq: 'Tanque: Arma e Escudo', cl: 'Paladino', raca: 'Humano', sub: 'Paladino Vingador (Golpe Divino + Julgamento Iluminação)' },
            { arq: 'Conjurador: Bardo', cl: 'Bardo', raca: 'Qareen', sub: 'Bardo Esgrimista Mágico (Inspiração + Golpe Mágico)' },
            { arq: 'Marcial: Dano Arqueiro', cl: 'Inventor', raca: 'Kliren', sub: 'Inventor Alquimista/Balístico (Engenhocas + Homúnculo)' },
            { arq: 'Tanque: Arma e Escudo', cl: 'Nobre', raca: 'Humano', sub: 'Nobre Comandante (Autoconfiança + Orgulho + Gritar Ordens)' },
            { arq: 'Suporte Divino: Druida', cl: 'Druida', raca: 'Dahllan', sub: 'Druida Feral (Forma Selvagem Feroz + Magia Natural)' },
            { arq: 'Marcial: Uma Mão Duelista', cl: 'Bucaneiro', raca: 'Sereia/Tritão', sub: 'Corsário Oceânico (Tridente/Florete + Audácia)' }
        ]
    },
    'MULTICLASSE_OTIMIZADA': {
        titulo: 'Específico — Builds Multiclasse Otimizadas (Cap. 1, p. 34 — Combos Híbridos)',
        candidatos: [
            { arq: 'Multiclasse: Guerreiro + Bárbaro', cl: 'Guerreiro', raca: 'Minotauro', sub: 'Guerreiro / Bárbaro (Ataque Especial + Fúria + Golpe Pessoal + Chifres)' },
            { arq: 'Multiclasse: Guerreiro + Paladino', cl: 'Guerreiro', raca: 'Humano', sub: 'Guerreiro / Paladino (Ataque Especial + Golpe Divino + Abençoado)' },
            { arq: 'Multiclasse: Guerreiro + Arcanista', cl: 'Guerreiro', raca: 'Elfo', sub: 'Magus de Batalha: Guerreiro / Arcanista (Armas Marciais + Campo de Força)' },
            { arq: 'Multiclasse: Caçador + Ladino', cl: 'Caçador', raca: 'Humano', sub: 'Caçador / Ladino (Marca da Presa + Ataque Furtivo + Duas Armas)' },
            { arq: 'Multiclasse: Cavaleiro + Clérigo', cl: 'Cavaleiro', raca: 'Anão', sub: 'Templário Imortal: Cavaleiro / Clérigo (Baluarte + Magias Divinas)' }
        ]
    }
};

function treinarAgenteRLCaixaPretaArenaJS() {
    inicializarArenaVisualSeNecessario();
    const stAtivo = garantirEstadoFichaParaArena();
    const nivelHeroiFixo = Math.max(1, stAtivo.nivel || 6);
    const aAtual = __ARENA_STATE__;
    const privAtivo = aAtual && aAtual._privadoCriatura ? aAtual._privadoCriatura : null;
    const selNd = document.getElementById('arena-sel-nd');
    const selPapel = document.getElementById('arena-sel-papel');
    const selTipoAv = document.getElementById('arena-sel-tipo-aventureiro-rl');
    const selRacaRL = document.getElementById('arena-sel-raca-rl');
    const selDoutrinaRL = document.getElementById('arena-sel-doutrina-rl');

    const tipoAventureiro = selTipoAv ? selTipoAv.value : 'GERAL_EQUILIBRADO';
    const racaFiltroRL = selRacaRL ? selRacaRL.value : 'AUTO_OTIMA';
    const doutrinaRL = selDoutrinaRL ? selDoutrinaRL.value : 'EQUILIBRADA_COMPLETA';

    const nd = privAtivo ? Math.max(1, Math.round(parseFloat(privAtivo.ndTexto) || parseInt(selNd ? selNd.value : nivelHeroiFixo, 10))) : (selNd ? parseInt(selNd.value, 10) : nivelHeroiFixo);
    const papel = privAtivo ? (privAtivo.papel || 'Solo') : (selPapel ? selPapel.value : 'Solo');
    const ameacaOculta = privAtivo ? {
        pv: privAtivo.pvOficialGrupo4 || privAtivo.pvMax,
        dano_medio: Math.round((privAtivo.danoMedio || 20) / 0.55),
        defesa: privAtivo.defesa,
        bonus_ataque: privAtivo.ataque,
        res_forte: privAtivo.resForte !== undefined ? privAtivo.resForte : (privAtivo.resMedia + 5),
        res_media: privAtivo.resMedia,
        res_fraca: privAtivo.resFraca !== undefined ? privAtivo.resFraca : Math.max(0, privAtivo.resMedia - 5)
    } : obterAmeacaOficialJS(nd, papel);

    const deltaND = nd - nivelHeroiFixo;
    const fatorPV = deltaND >= 3 ? 1.0 : (deltaND === 2 ? 0.75 : (deltaND === 1 ? 0.55 : 0.35));
    const fatorDano = deltaND >= 2 ? 1.0 : (deltaND === 1 ? 0.80 : 0.50);
    const pvMaxC = Math.max(25, Math.round(ameacaOculta.pv * fatorPV));
    const danoBaseC = Math.max(6, Math.round(ameacaOculta.dano_medio * fatorDano));

    // Monta a lista de candidatos de acordo com o "Tipo de Aventureiro" escolhido pelo usuário!
    let candidatos = [];
    let tituloCategoria = 'Build Geral';
    if (tipoAventureiro === 'CLASSE_ATUAL_FICHA') {
        const clAtual = (stAtivo.classe && stAtivo.classe.nome) ? stAtivo.classe.nome : 'Guerreiro';
        const ehConjAtual = ehConjuradorJS(stAtivo.classe, stAtivo.poderes);
        tituloCategoria = `Especialização na Classe Atual da Ficha (${clAtual})`;
        if (ehConjAtual) {
            const arqBase = clAtual.toLowerCase().includes('arcanista') ? 'Conjurador Arcano: Mago' : (clAtual.toLowerCase().includes('druida') ? 'Suporte Divino: Druida' : (clAtual.toLowerCase().includes('bardo') ? 'Conjurador: Bardo' : 'Suporte Divino: Clérigo'));
            candidatos = [
                { arq: arqBase, cl: clAtual, raca: 'Elfo', sub: `${clAtual} Élfico (Foco em Limite de PM & CD Mágica)` },
                { arq: arqBase, cl: clAtual, raca: 'Qareen', sub: `${clAtual} Qareen (-1 PM na Tatuagem + Magia Acelerada)` },
                { arq: clAtual.toLowerCase().includes('arcanista') ? 'Conjurador Arcano: Feiticeiro' : arqBase, cl: clAtual, raca: 'Humano', sub: `${clAtual} Humano Versátil (Poder Extra + Surto/Arcano)` },
                { arq: clAtual.toLowerCase().includes('arcanista') ? 'Conjurador Arcano: Bruxo' : arqBase, cl: clAtual, raca: 'Kliren', sub: `${clAtual} Kliren (Engenhosidade + Controle)` },
                { arq: arqBase, cl: clAtual, raca: 'Osteon', sub: `${clAtual} Osteon Imortal (RD 5 + Memória Póstuma)` },
                { arq: arqBase, cl: clAtual, raca: 'Anão', sub: `${clAtual} Anão Encouraçado (Alta Vida & Defesa)` }
            ];
        } else {
            candidatos = [
                { arq: 'Marcial: Duas Mãos Pesado', cl: clAtual, raca: 'Minotauro', sub: `${clAtual} Duas Mãos Pesado (Dano Crítico + Chifres)` },
                { arq: 'Marcial: Armas de Haste', cl: clAtual, raca: 'Humano', sub: `${clAtual} Armas de Haste (Alabarda + Controle de Alcance)` },
                { arq: 'Marcial: Duas Armas', cl: clAtual, raca: 'Humano', sub: `${clAtual} Estilo de Duas Armas (Múltiplos Ataques/Turno)` },
                { arq: 'Marcial: Uma Mão Duelista', cl: clAtual, raca: 'Goblin', sub: `${clAtual} Duelista de Uma Mão (Precisão + Defesa)` },
                { arq: 'Tanque: Arma e Escudo', cl: clAtual, raca: 'Anão', sub: `${clAtual} Tanque Arma & Escudo (Mitigação & Couraça)` },
                { arq: 'Marcial: Dano Arqueiro', cl: clAtual, raca: 'Elfo', sub: `${clAtual} Especialista à Distância (Arco/Mosquete)` }
            ];
        }
    } else {
        const pacote = CATALOGO_BUILDS_RL_POR_TIPO[tipoAventureiro] || CATALOGO_BUILDS_RL_POR_TIPO['GERAL_EQUILIBRADO'];
        tituloCategoria = pacote.titulo;
        candidatos = pacote.candidatos.map(c => ({ ...c }));
    }

    // Aplica filtro de raça se o usuário escolheu fixar uma raça específica
    if (racaFiltroRL === 'MANTER_RACA_FICHA' && stAtivo.raca && stAtivo.raca.nome) {
        candidatos = candidatos.map(c => ({ ...c, raca: stAtivo.raca.nome }));
    } else if (racaFiltroRL && racaFiltroRL !== 'AUTO_OTIMA' && racaFiltroRL !== 'MANTER_RACA_FICHA') {
        candidatos = candidatos.map(c => ({ ...c, raca: racaFiltroRL }));
    }

    let defMinGlobal = 10;
    let defMaxGlobal = 65;
    let resFracaDeduzida = ameacaOculta.res_fraca !== undefined ? ameacaOculta.res_fraca : Math.max(0, ameacaOculta.res_media - 5);
    const resultados = [];

    for (const cand of candidatos) {
        const fd = new FormData();
        fd.set('nome', `Agente RL (${cand.arq.split(':')[1] || cand.arq})`);
        fd.set('nivel', String(nivelHeroiFixo));
        fd.set('arquetipo', cand.arq);
        fd.set('iteracoes', '45');
        fd.set('fixar_raca', cand.raca);
        fd.set('fixar_classe', cand.cl);
        fd.set('fixar_origem', 'AUTO');
        fd.set('fixar_deus', 'AUTO');
        executarOtimizadorIAMobileOffline(fd, '__SILENCIOSO_RL__');
        const stCand = window.__ULTIMO_ESTADO_FICHA__;
        const resD = calcularResumoDanoJS(stCand.nivel, stCand.classe, stCand.est, stCand.poderes, stCand.itens, stCand.arma, stCand.escudo, stCand.magias, stCand.caminhoArcanista);

        const mAtq = (resD.descDanoArma || '').match(/Ataque\s*([+-]?\d+)/);
        const atqH = mAtq ? parseInt(mAtq[1], 10) : Math.max(stCand.est.bonusPericias['Luta'] || 0, stCand.est.bonusPericias['Pontaria'] || 0);
        const ehConj = ehConjuradorJS(stCand.classe, stCand.poderes);
        const circMax = circuloMaximoPermitido(stCand.classe, nivelHeroiFixo);
        const sigMag = (stCand.est.infoMagia && stCand.est.infoMagia.sigla) ? stCand.est.infoMagia.sigla : 'INT';
        const valAtribMag = Math.max(0, stCand.est.finais[sigMag] || 4);
        const dMag = Math.max(resD.maiorDanoMagia || 0, ehConj ? (10.5 * circMax + valAtribMag * 2) : 0);
        const cMag = resD.melhorMagiaInfo ? resD.melhorMagiaInfo.info.pmGasto : Math.max(1, circMax * 2 - 1);
        const dRaio = Math.max(resD.danoMedioRaio || 0, ehConj ? (5.5 * circMax + valAtribMag) : 0);
        const dArma = Math.max(resD.danoMedioArma || 10, 8);
        const rdPassiva = (stCand.raca.nome.toLowerCase() === 'osteon' ? 5 : 0) + ((stCand.poderes || []).some(p => p.nome.toLowerCase() === 'encouraçado') ? 2 : 0);

        let vitorias = 0, qVal = 0, somaDPR = 0, somaPVRestPct = 0;
        const episodios = 18;
        for (let ep = 0; ep < episodios; ep++) {
            let pvH = stCand.est.pvMax, pmH = stCand.est.pmMax, pvC = pvMaxC, turnos = 0, danoEp = 0;
            const iniH_RL = (Math.floor(Math.random() * 20) + 1) + (stCand.est.bonusPericias['Iniciativa'] || Math.floor(nivelHeroiFixo / 2));
            const iniC_RL = (Math.floor(Math.random() * 20) + 1) + (Math.floor(nd / 2) + (nd >= 11 ? 10 : 4));
            const heroiAgeAntes = iniH_RL >= iniC_RL;

            while (pvH > 0 && pvC > 0 && turnos < 20) {
                turnos++;
                // Turno da Ameaça antes (se venceu a Iniciativa)
                if (!heroiAgeAntes) {
                    const d20M = Math.floor(Math.random() * 20) + 1;
                    const usaAA = ehConj && pmH >= 2;
                    const defH_T = (turnos === 1 ? Math.max(10, stCand.est.defesa - 5) : stCand.est.defesa) + (usaAA ? 5 : 0);
                    if (d20M === 20 || (d20M !== 1 && d20M + ameacaOculta.bonus_ataque >= defH_T)) {
                        let rdReacao = rdPassiva;
                        if (ehConj && nivelHeroiFixo >= 5 && pmH >= 4) { pmH -= 4; rdReacao += 30; } // Campo de Força Reação (RD 30, p. 182)
                        else if (ehConj && pmH >= 2) { pmH -= 2; rdReacao += 8; }
                        else if (stCand.classe.nome.toLowerCase() === 'guerreiro' && nivelHeroiFixo >= 3 && pmH >= 3) { pmH -= 3; rdReacao += Math.round(danoBaseC * 0.50); } // Durão (p. 65)
                        else if (stCand.escudo) { rdReacao += 5; }
                        pvH = Math.max(0, pvH - Math.max(1, danoBaseC * (d20M === 20 ? 1.5 : 1.0) - rdReacao));
                    }
                    if (pvH <= 0) break;
                }

                // Turno do Herói: Conjurador vs. Combatente Marcial
                let dC = 0;
                if (ehConj) {
                    // Conjurador deduz e mira na Resistência Fraca da criatura (ou usa Seta Infalível sem resistência!)
                    const resAlvo = (turnos >= 2) ? resFracaDeduzida : ameacaOculta.res_media;
                    if (pmH >= cMag) {
                        pmH -= cMag;
                        const d20R = Math.floor(Math.random() * 20) + 1;
                        const passou = (d20R === 20) || (d20R !== 1 && (d20R + resAlvo) >= stCand.est.cdMagia);
                        dC += dMag * (passou ? 0.55 : 1.05);
                        // Magia Acelerada (+4 PM, Livro p. 131) ou Prece de Combate no turno de abertura!
                        if (turnos === 1 && pmH >= (cMag + 4) && doutrinaRL !== 'SOBREVIVENCIA_MITIGACAO') {
                            pmH -= (cMag + 4);
                            const d20R2 = Math.floor(Math.random() * 20) + 1;
                            const passou2 = (d20R2 === 20) || (d20R2 !== 1 && (d20R2 + resFracaDeduzida) >= stCand.est.cdMagia);
                            dC += (dMag * 0.85) * (passou2 ? 0.55 : 1.0);
                        }
                    } else {
                        const d20R = Math.floor(Math.random() * 20) + 1;
                        const passou = (d20R === 20) || (d20R !== 1 && (d20R + resAlvo) >= stCand.est.cdMagia);
                        dC += dRaio * (passou ? 0.55 : 1.0);
                    }
                    // Clérigo / Druida / Paladino pode se curar com Curar Ferimentos em movimento/acelerada se PV < 45%
                    if (pvH < stCand.est.pvMax * 0.45 && pmH >= 2 && /clérigo|clerigo|druida|bardo/i.test(stCand.classe.nome)) {
                        pmH -= 2;
                        pvH = Math.min(stCand.est.pvMax, pvH + 14 + valAtribMag);
                    }
                } else {
                    const ehGuerBB = stCand.classe.nome.toLowerCase() === 'guerreiro';
                    const cAE = (ehGuerBB && pmH >= (1 + Math.floor((nivelHeroiFixo - 1) / 4))) ? (1 + Math.floor((nivelHeroiFixo - 1) / 4)) : 0;
                    pmH -= cAE;
                    const bAE = 4 * cAE;
                    const temGPBB = (stCand.poderes || []).some(p => (p.nome || '').toLowerCase() === 'golpe pessoal') && turnos === 1 && pmH >= 3;
                    if (temGPBB) pmH -= 3;
                    const d20A = temGPBB ? Math.max(Math.floor(Math.random() * 20) + 1, Math.floor(Math.random() * 20) + 1) : (Math.floor(Math.random() * 20) + 1);
                    const totBase = d20A + atqH;
                    const totA = totBase + bAE;
                    const defAlvoBB = (turnos === 1 && heroiAgeAntes) ? Math.max(10, ameacaOculta.defesa - 5) : ameacaOculta.defesa;
                    const acertou = (d20A === 20) || (d20A !== 1 && totA >= defAlvoBB);
                    if (d20A !== 1 && d20A !== 20) {
                        if (totBase >= ameacaOculta.defesa) defMaxGlobal = Math.min(defMaxGlobal, totBase);
                        else defMinGlobal = Math.max(defMinGlobal, totBase + 1);
                    }
                    if (acertou) dC = dArma * (d20A >= 19 ? 1.55 : 1.0) + (temGPBB ? 10.5 : 0);
                    if ((stCand.raca.nome.toLowerCase() === 'minotauro' || stCand.raca.nome.toLowerCase() === 'trog') && pmH >= 1) {
                        pmH -= 1;
                        const d20Ch = Math.floor(Math.random() * 20) + 1;
                        const bCh = (stCand.est.bonusPericias['Luta'] || atqH) + 2;
                        if (d20Ch === 20 || (d20Ch !== 1 && (d20Ch + bCh) >= defAlvoBB)) {
                            dC += Math.floor(Math.random() * 6) + 1 + Math.max(0, stCand.est.finais.FOR);
                        }
                    }
                }
                pvC = Math.max(0, pvC - dC);
                danoEp += dC;

                // Contra-ataque da Ameaça (se o herói agiu antes e a ameaça continuou viva)
                if (heroiAgeAntes && pvC > 0) {
                    const d20M = Math.floor(Math.random() * 20) + 1;
                    const usaAA = ehConj && pmH >= 2;
                    const defH_T = stCand.est.defesa + (usaAA ? 5 : 0);
                    if (d20M === 20 || (d20M !== 1 && d20M + ameacaOculta.bonus_ataque >= defH_T)) {
                        let rdReacao = rdPassiva;
                        if (ehConj && nivelHeroiFixo >= 5 && pmH >= 4) { pmH -= 4; rdReacao += 30; }
                        else if (ehConj && pmH >= 2) { pmH -= 2; rdReacao += 8; }
                        else if (stCand.classe.nome.toLowerCase() === 'guerreiro' && nivelHeroiFixo >= 3 && pmH >= 3) { pmH -= 3; rdReacao += Math.round(danoBaseC * 0.50); }
                        else if (stCand.escudo) { rdReacao += 5; }
                        pvH = Math.max(0, pvH - Math.max(1, danoBaseC * (d20M === 20 ? 1.5 : 1.0) - rdReacao));
                    }
                }
            }
            const venceu = (pvC <= 0) && (pvH > 0);
            if (venceu) vitorias++;
            const pesoPV = doutrinaRL === 'SOBREVIVENCIA_MITIGACAO' ? 85 : 60;
            const pesoTurnos = doutrinaRL === 'EXPLOSAO_DANO_BURST' ? 65 : 40;
            const rec = venceu
                ? (100 + pesoPV * (pvH / Math.max(1, stCand.est.pvMax)) + pesoTurnos / Math.max(1, turnos))
                : (-100 + 60 * Math.min(1, danoEp / Math.max(1, pvMaxC)) - (turnos <= 1 ? 20 : 0));
            qVal = ep === 0 ? rec : (qVal + 0.25 * (rec - qVal));
            somaDPR += danoEp / Math.max(1, turnos);
            somaPVRestPct += (pvH / Math.max(1, stCand.est.pvMax)) * 100;
        }

        resultados.push({
            arq: cand.arq,
            sub: cand.sub || cand.arq,
            raca: stCand.raca.nome,
            classe: stCand.classe.nome,
            ehConj,
            arma: ehConj ? `CD ${stCand.est.cdMagia} · ${(stCand.magias[0] && stCand.magias[0].nome) || 'Magias'}` : (stCand.arma ? stCand.arma.nome : 'Arma'),
            winPct: +((vitorias / episodios) * 100).toFixed(1),
            qVal: +qVal.toFixed(1),
            dpr: +(somaDPR / episodios).toFixed(1),
            pvRestPct: +(somaPVRestPct / episodios).toFixed(0)
        });
    }

    resultados.sort((a, b) => (b.qVal - a.qVal) || (b.winPct - a.winPct) || (b.dpr - a.dpr));
    const campea = resultados[0];
    const melhorMarcial = resultados.find(r => !r.ehConj) || campea;
    const melhorConjurador = resultados.find(r => r.ehConj) || campea;

    // Reconstrói a Build Campeã da categoria selecionada e sincroniza com a Ficha e Arena!
    const fdWin = new FormData();
    fdWin.set('nome', `Campeão RL (${campea.raca} ${campea.classe})`);
    fdWin.set('nivel', String(nivelHeroiFixo));
    fdWin.set('arquetipo', campea.arq);
    fdWin.set('iteracoes', '120');
    fdWin.set('fixar_raca', campea.raca);
    fdWin.set('fixar_classe', campea.classe);
    fdWin.set('fixar_origem', 'AUTO');
    fdWin.set('fixar_deus', 'AUTO');
    executarOtimizadorIAMobileOffline(fdWin, null);
    mostrarAba('tab-arena');
    reiniciarCombateArenaVisual();
    __ARENA_STATE__.crencaIA.defMin = defMinGlobal;
    __ARENA_STATE__.crencaIA.defMax = defMaxGlobal;
    atualizarPlacarVisualArena();

    const defDeduzida = defMinGlobal >= defMaxGlobal ? `Exata: ${defMinGlobal}` : `[${defMinGlobal} .. ${defMaxGlobal}]`;
    const top3RL = resultados.slice(0, 3);
    const medalhasRL = ['1º LUGAR (CAMPEÃ RL)', '2º LUGAR (VICE-CAMPEÃ)', '3º LUGAR (DESTAQUE)'];
    const coresBordaRL = ['#FACC15', '#93C5FD', '#D97706'];
    const cardsTop3HTML = top3RL.map((r, idxT) => `
        <div style="background:linear-gradient(135deg, rgba(15,23,42,0.92), rgba(30,41,59,0.92));border:2px solid ${coresBordaRL[idxT]};border-radius:10px;padding:10px 12px;display:flex;flex-direction:column;justify-content:space-between;gap:6px;">
            <div>
                <div style="font-size:10.5px;font-weight:900;color:${coresBordaRL[idxT]};letter-spacing:0.4px;">${medalhasRL[idxT]}</div>
                <div style="font-size:13.5px;font-weight:900;color:#FFFFFF;margin-top:2px;">${r.raca} · ${r.classe}</div>
                <div style="font-size:11px;color:#FDE047;font-weight:700;">${r.arq}</div>
                <div style="font-size:10.5px;color:#CBD5E1;margin-top:3px;">${r.sub}</div>
                <div style="font-size:10.5px;color:#A7F3D0;margin-top:2px;"><strong>Arsenal/Foco:</strong> ${r.arma}</div>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;background:rgba(0,0,0,0.38);padding:5px 8px;border-radius:6px;font-size:11px;">
                <span>Win: <strong style="color:#4ADE80;">${r.winPct}%</strong></span>
                <span>DPR: <strong style="color:#38BDF8;">${r.dpr}/rod</strong></span>
                <span>Q: <strong style="color:#FACC15;">${r.qVal > 0 ? '+' + r.qVal : r.qVal}</strong></span>
            </div>
            <button type="button" class="btn-roll-inline" style="width:100%;padding:5px 8px;background:${idxT === 0 ? '#15803D' : '#1E3A8A'};border-color:${coresBordaRL[idxT]};" onclick="equiparBuildTreinadaRLNaArenaJS('${r.arq.replace(/'/g, '')}', '${r.raca.replace(/'/g, '')}', '${r.classe.replace(/'/g, '')}')">
                ${idxT === 0 ? 'Build Equipada na Arena' : 'Equipar Esta Build na Arena'}
            </button>
        </div>
    `).join('');

    const boxRL = document.getElementById('arena-rl-resultados');
    if (boxRL) {
        boxRL.style.display = 'block';
        boxRL.innerHTML = `
            <div class="${deltaND >= 4 && campea.winPct === 0 ? 'csp-err' : 'csp-ok'}" style="margin-bottom:10px;">
                <div style="font-size:11.5px;color:#FDE047;margin-bottom:4px;"><strong>Escopo Treinado (${resultados.length} Builds Avaliadas × 18 Episódios POMDP):</strong> ${tituloCategoria} &nbsp;|&nbsp; <strong>Defesa Deduzida da Ameaça:</strong> ${defDeduzida}</div>
                <strong>Melhores Opções Descobertas pelo Aprendizado por Reforço (Herói Nv. ${nivelHeroiFixo} vs. ${papel} ND ${nd}):</strong>
                A campeã geral foi <strong>${campea.arq}</strong> (${campea.raca} ${campea.classe} · <em>${campea.sub}</em>) com Recompensa Q = <strong>${campea.qVal > 0 ? '+' + campea.qVal : campea.qVal}</strong>, Taxa de Vitória = <strong>${campea.winPct}%</strong> e DPR = <strong>${campea.dpr}/rod</strong>!
                ${tipoAventureiro === 'GERAL_EQUILIBRADO' ? `<br><span style="font-size:11.5px;color:#A7F3D0;"><strong>Melhor Opção Marcial:</strong> ${melhorMarcial.raca} ${melhorMarcial.classe} (Q=${melhorMarcial.qVal}, Win=${melhorMarcial.winPct}%) &nbsp;|&nbsp; <strong>Melhor Opção Conjuradora:</strong> ${melhorConjurador.raca} ${melhorConjurador.classe} (Q=${melhorConjurador.qVal}, Win=${melhorConjurador.winPct}%)</span>` : ''}
            </div>
            <div style="font-size:12px;font-weight:900;color:#FEF08A;margin-bottom:6px;">Pódio das 3 Melhores Opções Encontradas pelo Agente RL:</div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(230px, 1fr));gap:10px;margin-bottom:12px;">
                ${cardsTop3HTML}
            </div>
            <div style="font-size:12px;font-weight:900;color:#93C5FD;margin-bottom:6px;">Ranking Completo de Todas as ${resultados.length} Opções Treinadas:</div>
            <div style="overflow-x:auto;">
                <table class="skills-table">
                    <thead>
                        <tr>
                            <th>Posição & Build Avaliada</th>
                            <th>Especialização, Estratégia & Arsenal</th>
                            <th style="text-align:right;">Recompensa Q</th>
                            <th style="text-align:right;">DPR Empírico</th>
                            <th style="text-align:right;">PV Final</th>
                            <th style="text-align:right;">% Vitória</th>
                            <th style="text-align:center;">Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${resultados.map((r, i) => `<tr${i === 0 ? ' class="trained"' : ''}>
                            <td><strong>${i === 0 ? '#1 ' : (i === 1 ? '#2 ' : (i === 2 ? '#3 ' : '#' + (i + 1) + ' '))}${r.arq}</strong><br><small style="color:#93C5FD;">${r.raca} · ${r.classe}</small></td>
                            <td><small>${r.sub}<br><span style="color:#FDE047;">${r.arma}</span></small></td>
                            <td style="text-align:right;font-weight:800;color:${r.qVal >= 0 ? '#38BDF8' : '#FCA5A5'};">${r.qVal > 0 ? '+' + r.qVal : r.qVal}</td>
                            <td style="text-align:right;font-weight:700;">${r.dpr}/rod</td>
                            <td style="text-align:right;">${r.pvRestPct}%</td>
                            <td style="text-align:right;font-weight:800;color:${r.winPct >= 60 ? '#34D399' : (r.winPct >= 25 ? '#FACC15' : '#F87171')};">${r.winPct}%</td>
                            <td style="text-align:center;"><button type="button" class="btn-roll-inline" onclick="equiparBuildTreinadaRLNaArenaJS('${r.arq.replace(/'/g, '')}', '${r.raca.replace(/'/g, '')}', '${r.classe.replace(/'/g, '')}')">Equipar</button></td>
                        </tr>`).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }
    simularCombateInteiroAnimado();
}

function salvarFichaLocalStorageOffline() {
    const atual = window.__ULTIMO_ESTADO_FICHA__;
    if (!atual) {
        exibirMensagemStatus('Nenhuma ficha ativa para salvar.');
        return;
    }
    const idFicha = atual.idCloud || ('T20_' + Date.now());
    atual.idCloud = idFicha;
    const classesResumo = (typeof resumoClassesMulticlasseJS === 'function')
        ? resumoClassesMulticlasseJS(atual)
        : (atual.classe ? atual.classe.nome + ' ' + atual.nivel : 'Guerreiro 1');

    const registro = {
        id: idFicha,
        nome: atual.nome || 'Novo Aventureiro',
        jogador: atual.jogador || 'Jogador',
        racaNome: atual.raca ? atual.raca.nome : 'Humano',
        classesResumo,
        nivel: atual.nivel || 1,
        score: +(atual.scoreFinal || 0).toFixed(1),
        data: new Date().toLocaleString('pt-BR'),
        payload: atual
    };

    try {
        const lista = JSON.parse(localStorage.getItem('tormenta20_fichas_salvas') || '[]').filter(x => String(x.id) !== String(idFicha));
        lista.unshift(registro);
        localStorage.setItem('tormenta20_fichas_salvas', JSON.stringify(lista));
    } catch (e) {}

    if (typeof google !== 'undefined' && google.script && google.script.run) {
        exibirMensagemStatus('Salvando ficha completa na planilha do Google Sheets...');
        google.script.run
            .withSuccessHandler((res) => {
                exibirMensagemStatus(`Ficha "${registro.nome}" salva na nuvem (Google Sheets: ${res.totalFichas} ficha(s) sincronizada(s))!`);
                if (typeof atualizarListaFichasSalvasUI === 'function') atualizarListaFichasSalvasUI();
            })
            .withFailureHandler((err) => {
                exibirMensagemStatus(`Salva localmente no navegador (erro na nuvem: ${err && err.message ? err.message : err})`);
            })
            .salvarFichaNaPlanilha(registro);
    } else if (typeof window !== 'undefined' && window.location && /^https?:/.test(window.location.protocol)) {
        fetch('/api/fichas', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(registro)
        })
        .then(r => r.json())
        .then(res => {
            if (res && res.ok) {
                exibirMensagemStatus(`Ficha "${registro.nome}" salva no banco SQLite WAL do servidor (${res.totalFichas} ficha(s) no BD)!`);
                if (typeof atualizarListaFichasSalvasUI === 'function') atualizarListaFichasSalvasUI();
            } else {
                exibirMensagemStatus(`Salva localmente no navegador (API SQLite indisponível neste host).`);
            }
        })
        .catch(() => {
            exibirMensagemStatus(`Ficha "${registro.nome}" salva localmente no navegador!`);
        });
    } else {
        exibirMensagemStatus(`Ficha "${registro.nome}" salva localmente no navegador (para sincronizar entre Celular e PC, publique via Google Apps Script ou use o servidor Python)!`);
        if (typeof atualizarListaFichasSalvasUI === 'function') atualizarListaFichasSalvasUI();
    }
}

function carregarFichaDeRegistroSalvoJS(registro) {
    if (!registro || !registro.payload) {
        exibirMensagemStatus('Esta ficha antiga contém apenas resumo e não possui o JSON completo.');
        return;
    }
    const st = registro.payload;
    st.idCloud = registro.id;
    renderizarFichaEArvoreClientSide(st, 'tab-ficha', `Ficha "${st.nome}" (${resumoClassesMulticlasseJS(st)}) carregada com sucesso!`);
}

function abrirGerenciadorFichasNuvemJS() {
    const box = document.getElementById('ficha-cloud-manager-box');
    if (box) {
        box.style.display = box.style.display === 'none' ? 'block' : 'none';
        if (box.style.display === 'block') atualizarListaFichasSalvasUI();
    }
}

function atualizarListaFichasSalvasUI() {
    const body = document.getElementById('ficha-cloud-manager-list');
    if (!body) return;
    const renderizarLista = (lista, origemLabel) => {
        window.__CACHE_FICHAS_SALVAS__ = lista || [];
        if (!lista || lista.length === 0) {
            body.innerHTML = `<div class="item-row">Nenhuma ficha salva ainda (${origemLabel}). Clique em <strong>Salvar Ficha</strong> para gravar!</div>`;
            return;
        }
        body.innerHTML = lista.map((r, idx) => `
            <div class="item-row" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;padding:7px 10px;">
                <div>
                    <strong>${r.nome}</strong> <span class="tag">${r.racaNome || ''} · ${r.classesResumo || ('Nv ' + r.nivel)}</span>
                    <small style="display:block;opacity:0.8;">Score: ${r.score || 0} · Atualizado: ${r.data || ''} · Fonte: ${origemLabel}</small>
                </div>
                <div style="display:flex;gap:6px;">
                    <button type="button" class="btn-roll-inline" style="background:#15803D;" onclick="carregarFichaDeRegistroSalvoJS(window.__CACHE_FICHAS_SALVAS__[${idx}])">Carregar</button>
                    <button type="button" class="btn-roll-inline" style="background:#7F1D1D;" onclick="excluirFichaSalvaNuvemOuLocalJS('${String(r.id).replace(/'/g, '')}')"></button>
                </div>
            </div>
        `).join('');
    };

    if (typeof google !== 'undefined' && google.script && google.script.run) {
        body.innerHTML = '<div class="item-row">Carregando fichas salvas da planilha Google Sheets...</div>';
        google.script.run
            .withSuccessHandler((listaNuvem) => renderizarLista(listaNuvem, 'Google Sheets (Nuvem)'))
            .withFailureHandler(() => {
                const local = JSON.parse(localStorage.getItem('tormenta20_fichas_salvas') || '[]');
                renderizarLista(local, 'LocalStorage (Navegador)');
            })
            .listarFichasDaPlanilha();
    } else if (typeof window !== 'undefined' && window.location && /^https?:/.test(window.location.protocol)) {
        fetch('/api/fichas')
            .then(r => r.json())
            .then(res => {
                if (res && res.ok && Array.isArray(res.fichas)) {
                    renderizarLista(res.fichas, 'SQLite WAL (Servidor)');
                } else {
                    const local = JSON.parse(localStorage.getItem('tormenta20_fichas_salvas') || '[]');
                    renderizarLista(local, 'LocalStorage');
                }
            })
            .catch(() => {
                let local = [];
                try { local = JSON.parse(localStorage.getItem('tormenta20_fichas_salvas') || '[]'); } catch (e) {}
                renderizarLista(local, 'LocalStorage (Offline)');
            });
    } else {
        let local = [];
        try { local = JSON.parse(localStorage.getItem('tormenta20_fichas_salvas') || '[]'); } catch (e) {}
        renderizarLista(local, 'LocalStorage (Offline)');
    }
}

function excluirFichaSalvaNuvemOuLocalJS(idFicha) {
    try {
        const local = JSON.parse(localStorage.getItem('tormenta20_fichas_salvas') || '[]').filter(x => String(x.id) !== String(idFicha));
        localStorage.setItem('tormenta20_fichas_salvas', JSON.stringify(local));
    } catch (e) {}
    if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run
            .withSuccessHandler(() => atualizarListaFichasSalvasUI())
            .excluirFichaDaPlanilha(idFicha);
    } else if (typeof window !== 'undefined' && window.location && /^https?:/.test(window.location.protocol)) {
        fetch('/api/fichas?id=' + encodeURIComponent(idFicha), { method: 'DELETE' })
            .finally(() => atualizarListaFichasSalvasUI());
    } else {
        atualizarListaFichasSalvasUI();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    try {
        garantirEstadoFichaParaArena();
        sincronizarHeroiNaArenaSemResetarInimigoJS();
    } catch (e) {
        console.error('Erro na inicialização automática da Ficha T20:', e);
    }
});


function equiparBuildTreinadaRLNaArenaJS(arq, raca, classe) {
    const stAt = garantirEstadoFichaParaArena();
    const nv = Math.max(1, stAt.nivel || 6);
    const fd = new FormData();
    fd.set('nome', `Campeão RL (${raca} ${classe})`);
    fd.set('nivel', String(nv));
    fd.set('arquetipo', arq);
    fd.set('iteracoes', '120');
    fd.set('fixar_raca', raca);
    fd.set('fixar_classe', classe);
    fd.set('fixar_origem', 'AUTO');
    fd.set('fixar_deus', 'AUTO');
    executarOtimizadorIAMobileOffline(fd, null);
    mostrarAba('tab-arena');
    reiniciarCombateArenaVisual();
    atualizarPlacarVisualArena();
    exibirMensagemStatus(`Build RL equipada na Ficha e na Arena: ${arq} (${raca} ${classe} Nv. ${nv})!`);
}


// =============================================================================
// MOTOR TÁTICO 2D: TAMANHO/ESPAÇO OCUPADO, ENCONTROS ILIMITADOS, FLANQUEAMENTO & MESAS ONLINE (v50)
// =============================================================================

function criarCondicoesPadrao2D(desprevInicial) {
    return {
        caido: false,
        emChamas: false,
        sangrando: false,
        desprevenido: Boolean(desprevInicial),
        envenenado: false,
        atordoado: false,
        lento: false
    };
}

function obterCatalogoAmeacasCap7Geral() {
    if (typeof CATALOGO_T20 !== 'undefined' && CATALOGO_T20 && Array.isArray(CATALOGO_T20.ameacas_cap7)) {
        return CATALOGO_T20.ameacas_cap7;
    }
    return [];
}

function calcularTamanhoCriaturaObj(tipoTamanhoStr) {
    if (typeof extrairTamanhoEEspacoT20 === 'function') {
        return extrairTamanhoEEspacoT20(tipoTamanhoStr);
    }
    const t = String(tipoTamanhoStr || 'Médio').toLowerCase();
    if (t.includes('colossal')) return { categoria: 'Colossal', espacoQ: 6, espacoM: 9.0, escalaSprite: 1.08 };
    if (t.includes('enorme')) return { categoria: 'Enorme', espacoQ: 3, espacoM: 4.5, escalaSprite: 0.96 };
    if (t.includes('grande')) return { categoria: 'Grande', espacoQ: 2, espacoM: 3.0, escalaSprite: 0.84 };
    return { categoria: 'Médio', espacoQ: 1, espacoM: 1.5, escalaSprite: 0.70 };
}

function criaturaOcupaCelula2D(cr, gx, gy) {
    if (!cr || Number(cr.pvAtual || 0) <= 0) return false;
    const q = Math.max(1, Number(cr.espacoQ || 1));
    const cx = Number(cr.gx || 0);
    const cy = Number(cr.gy || 0);
    return (gx >= cx && gx < cx + q && gy >= cy && gy < cy + q);
}

function encontrarCelulaCriaturaOcupando2D(listaCriaturas, gx, gy) {
    return (listaCriaturas || []).findIndex(c => criaturaOcupaCelula2D(c, gx, gy));
}

function calcularDimensoesDinamicasGrid(heroisLista, criaturasLista, minCols, minRows) {
    return { cols: 120, rows: 120 };
}

function encontrarPosicaoLivreBloco2D(heroisLista, criaturasLista, espacoQ, prefX) {
    const q = Math.max(1, Number(espacoQ || 1));
    const maxCols = 120;
    const maxRows = 120;
    const hRef = (heroisLista && heroisLista[0]) ? heroisLista[0] : { gx: 56, gy: 60 };
    const startX = prefX !== undefined && prefX > 10 ? prefX : (Number(hRef.gx || 56) + 2);
    const baseY = Math.max(0, Math.min(maxRows - q, Number(hRef.gy || 60) - Math.floor(q / 2)));
    // Procura em espiral/faixa perto do combate ativo dentro do mapa 120x120
    const offsetsY = [0, -2, 2, -4, 4, -6, 6, -1, 1, -3, 3, -8, 8];
    for (let x = startX; x <= Math.min(maxCols - q, startX + 40); x++) {
        for (const dyOff of offsetsY) {
            const y = baseY + dyOff;
            if (y < 0 || y > maxRows - q) continue;
            let livre = true;
            for (let dx = 0; dx < q && livre; dx++) {
                for (let dy = 0; dy < q && livre; dy++) {
                    const cx = x + dx, cy = y + dy;
                    if ((heroisLista || []).some(h => h && Number(h.pvAtual !== undefined ? h.pvAtual : 1) > 0 && Number(h.gx) === cx && Number(h.gy) === cy)) {
                        livre = false;
                    }
                    if (encontrarCelulaCriaturaOcupando2D(criaturasLista, cx, cy) >= 0) {
                        livre = false;
                    }
                }
            }
            if (livre) return { gx: x, gy: y };
        }
    }
    return { gx: Math.min(119 - q, startX + (criaturasLista || []).length * q), gy: baseY };
}

function calcularDistanciaQuadrados2D(p1, p2OuCriatura) {
    if (!p1 || !p2OuCriatura) return 1;
    const q = Math.max(1, Number(p2OuCriatura.espacoQ || 1));
    const xMin = Number(p2OuCriatura.gx || 0);
    const yMin = Number(p2OuCriatura.gy || 0);
    const xMax = xMin + q - 1;
    const yMax = yMin + q - 1;
    const cx = Math.max(xMin, Math.min(xMax, Number(p1.gx || 0)));
    const cy = Math.max(yMin, Math.min(yMax, Number(p1.gy || 0)));
    return Math.max(Math.abs(Number(p1.gx || 0) - cx), Math.abs(Number(p1.gy || 0) - cy));
}

function calcularDistanciaMetrosAlvoArenaJS(a, idxAlvo) {
    if (!a || !Array.isArray(a.listaCriaturas) || a.listaCriaturas.length === 0) return 1.5;
    const alvo = a.listaCriaturas[idxAlvo || 0] || a.listaCriaturas[0];
    const q = calcularDistanciaQuadrados2D(a.posHeroi || { gx: 2, gy: 2 }, alvo);
    return Math.max(1.5, q * 1.5);
}

function verificarFlanqueamentoGeometria2D(posAtacante, posAliado, alvo) {
    if (!posAtacante || !posAliado || !alvo) return false;
    const distAtq = calcularDistanciaQuadrados2D(posAtacante, alvo);
    const distAli = calcularDistanciaQuadrados2D(posAliado, alvo);
    if (distAtq !== 1 || distAli !== 1) return false;
    const q = Math.max(1, Number(alvo.espacoQ || 1));
    const ax1 = Number(alvo.gx || 0), ax2 = ax1 + q - 1;
    const ay1 = Number(alvo.gy || 0), ay2 = ay1 + q - 1;
    // Flanqueamento horizontal (um a Oeste, outro a Leste na mesma faixa Y do alvo)
    const opostoX = (
        (posAtacante.gx === ax1 - 1 && posAliado.gx === ax2 + 1) ||
        (posAtacante.gx === ax2 + 1 && posAliado.gx === ax1 - 1)
    ) && posAtacante.gy >= ay1 && posAtacante.gy <= ay2 && posAliado.gy >= ay1 && posAliado.gy <= ay2;
    // Flanqueamento vertical (um ao Norte, outro ao Sul na mesma faixa X do alvo)
    const opostoY = (
        (posAtacante.gy === ay1 - 1 && posAliado.gy === ay2 + 1) ||
        (posAtacante.gy === ay2 + 1 && posAliado.gy === ay1 - 1)
    ) && posAtacante.gx >= ax1 && posAtacante.gx <= ax2 && posAliado.gx >= ax1 && posAliado.gx <= ax2;
    return opostoX || opostoY;
}

function verificarFlanqueamentoAlvoArenaJS(a, idxAlvo) {
    if (!a || !a.aliadoFlanqueadorAtivo || !Array.isArray(a.listaCriaturas)) return false;
    const alvo = a.listaCriaturas[idxAlvo !== undefined ? idxAlvo : (a.alvoFocoIdx || 0)];
    if (!alvo || alvo.pvAtual <= 0) return false;
    return verificarFlanqueamentoGeometria2D(a.posHeroi, a.posAliadoFlanco, alvo);
}

function inicializarEncontrosMultiplosEGrid2DArenaJS(a, st) {
    if (!a || !a._privadoCriatura) return;
    const selQtd = document.getElementById('arena-sel-qtd-criaturas');
    const qtd = selQtd ? Math.max(1, parseInt(selQtd.value, 10) || 1) : 1;
    a.qtdCriaturas = qtd;
    a.alvoFocoIdx = 0;

    a.posHeroi = { gx: 56, gy: 60 };
    a.aliadoFlanqueadorAtivo = false;
    a.posAliadoFlanco = { gx: 60, gy: 60 };
    a.coberturaAtiva = false;
    a.investidaPenalidadeDef = false;
    a.condicoesHeroi = criarCondicoesPadrao2D(false);

    const basePriv = a._privadoCriatura;
    const tamInfo = calcularTamanhoCriaturaObj(basePriv.tipoTamanho);
    basePriv.espacoQ = tamInfo.espacoQ;
    basePriv.tamanhoCat = tamInfo.categoria;

    const fatorMultiPV = qtd === 1 ? 1.0 : (qtd === 2 ? 0.72 : (qtd === 3 ? 0.58 : 0.48));
    const pvIndivMax = Math.max(10, Math.round(basePriv.pvMax * fatorMultiPV));
    basePriv.pvMax = pvIndivMax;
    basePriv.pvAtual = pvIndivMax;

    a.listaCriaturas = [];
    for (let i = 0; i < qtd; i++) {
        const posLivre = encontrarPosicaoLivreBloco2D([a.posHeroi], a.listaCriaturas, tamInfo.espacoQ, 4);
        a.listaCriaturas.push({
            indice: i,
            rotulo: `#${i + 1}`,
            nomeCriatura: qtd > 1 ? `${basePriv.nomeCriatura} #${i + 1}` : basePriv.nomeCriatura,
            grupoCap7: basePriv.grupoCap7,
            ndTexto: basePriv.ndTexto,
            papel: basePriv.papel || a.papelCriatura,
            tipoTamanho: basePriv.tipoTamanho,
            tamanhoCat: tamInfo.categoria,
            espacoQ: tamInfo.espacoQ,
            pvAtual: pvIndivMax,
            pvMax: pvIndivMax,
            defesa: basePriv.defesa,
            ataque: basePriv.ataque,
            danoMedio: basePriv.danoMedio,
            gx: posLivre.gx,
            gy: posLivre.gy,
            condicoes: criarCondicoesPadrao2D(a.criaturaDesprevenida)
        });
    }
    const dims = calcularDimensoesDinamicasGrid([a.posHeroi], a.listaCriaturas, 8, 5);
    a.gridCols = dims.cols;
    a.gridRows = dims.rows;
    sincronizarAlvoFocoComPrivadoArenaJS(a);
}

function adicionarCriaturaAoEncontroArenaJS(idAmeacaSel) {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    if (!a) return;
    a._tabuleiroSemAmeacas = false;
    if (!Array.isArray(a.listaCriaturas)) a.listaCriaturas = [];
    const listaCat = obterCatalogoAmeacasCap7Geral();
    const c = listaCat.find(x => x.id_ameaca === idAmeacaSel || x.nome === idAmeacaSel) || listaCat[0];
    if (!c) return;

    const tamInfo = calcularTamanhoCriaturaObj(c.tipo_nivel_tamanho || 'Médio');
    const heroisList = [a.posHeroi || { gx: 2, gy: 2 }];
    if (a.aliadoFlanqueadorAtivo && a.posAliadoFlanco) heroisList.push(a.posAliadoFlanco);
    const posLivre = encontrarPosicaoLivreBloco2D(heroisList, a.listaCriaturas, tamInfo.espacoQ, 4);
    const idxNovo = a.listaCriaturas.length;
    const pvC = Math.max(1, Math.round(Number(c.pv || 40)));

    a.listaCriaturas.push({
        indice: idxNovo,
        rotulo: `#${idxNovo + 1}`,
        nomeCriatura: `${c.nome} #${idxNovo + 1}`,
        grupoCap7: c.grupo_cap7 || 'Masmorras',
        ndTexto: String(c.nd || c.nd_numerico || '1'),
        papel: c.papel || 'Solo',
        tipoTamanho: c.tipo_nivel_tamanho || 'Médio',
        tamanhoCat: tamInfo.categoria,
        espacoQ: tamInfo.espacoQ,
        pvAtual: pvC,
        pvMax: pvC,
        defesa: Number(c.defesa || 18),
        ataque: Number(c.bonus_ataque || 10),
        danoMedio: Number(c.dano_medio || 16),
        fortitude: Number(c.fortitude || 6),
        reflexos: Number(c.reflexos || 6),
        vontade: Number(c.vontade || 5),
        cdEfeito: Number(c.cd_efeito || 16),
        ataquesResumo: c.ataques_e_acoes || 'Ataque padrão de ameaça',
        habilidadesResumo: c.habilidades_e_resistencias || 'Estatísticas oficiais JdA',
        gx: posLivre.gx,
        gy: posLivre.gy,
        condicoes: criarCondicoesPadrao2D(false)
    });

    a.alvoFocoIdx = a.listaCriaturas.length - 1;
    const dims = calcularDimensoesDinamicasGrid(heroisList, a.listaCriaturas, 8, 5);
    a.gridCols = dims.cols;
    a.gridRows = dims.rows;
    a.encerrado = false;
    sincronizarAlvoFocoComPrivadoArenaJS(a);
    registrarLinhaLogArena(`<strong>[Encontro Misto]</strong> Adicionada criatura <strong>${c.nome}</strong> (ND ${c.nd}, ${tamInfo.categoria} ${tamInfo.espacoQ}x${tamInfo.espacoQ}) na posição (${posLivre.gx + 1}, ${posLivre.gy + 1})!`);
    atualizarPlacarVisualArena();
}

function removerCriaturaDoEncontroArenaJS(idxRemover) {
    const a = __ARENA_STATE__;
    if (!a || !Array.isArray(a.listaCriaturas) || a.listaCriaturas.length === 0) {
        exibirMensagemStatus('ℹNão há ameaças no tabuleiro para excluir.');
        return;
    }
    const idxAlvo = (idxRemover === undefined || idxRemover === null)
        ? Math.min(a.listaCriaturas.length - 1, Math.max(0, Number(a.alvoFocoIdx || 0)))
        : Number(idxRemover);
    const removida = a.listaCriaturas.splice(idxAlvo, 1)[0];
    a.listaCriaturas.forEach((cr, idx) => { cr.indice = idx; cr.rotulo = `#${idx + 1}`; });
    if (a.listaCriaturas.length === 0) {
        a._tabuleiroSemAmeacas = true;
        a.alvoFocoIdx = 0;
        a._privadoCriatura.pvAtual = 0;
        a._privadoCriatura.nomeCriatura = 'Nenhuma Ameaça (Tabuleiro Limpo)';
    } else {
        a._tabuleiroSemAmeacas = false;
        a.alvoFocoIdx = Math.min(a.alvoFocoIdx || 0, a.listaCriaturas.length - 1);
        sincronizarAlvoFocoComPrivadoArenaJS(a);
    }
    const dims = calcularDimensoesDinamicasGrid([a.posHeroi || { gx: 2, gy: 2 }], a.listaCriaturas, 8, 5);
    a.gridCols = dims.cols;
    a.gridRows = dims.rows;
    if (removida) {
        registrarLinhaLogArena(`<strong>[Tabuleiro]</strong> Ameaça <strong>${removida.nomeCriatura}</strong> excluída do tabuleiro.`);
        exibirMensagemStatus(`${removida.nomeCriatura} excluída do tabuleiro.`);
    }
    atualizarPlacarVisualArena();
}

function limparTodasAmeacasArenaJS() {
    const a = __ARENA_STATE__;
    if (!a) return;
    a.listaCriaturas = [];
    a._tabuleiroSemAmeacas = true;
    a.alvoFocoIdx = 0;
    a._privadoCriatura.pvAtual = 0;
    a._privadoCriatura.nomeCriatura = 'Nenhuma Ameaça (Tabuleiro Limpo)';
    registrarLinhaLogArena(`<strong>[Tabuleiro]</strong> Todas as ameaças foram excluídas do tabuleiro. Use Adicionar para montar novo encontro!`);
    exibirMensagemStatus('Todas as ameaças foram excluídas do tabuleiro.');
    atualizarPlacarVisualArena();
}

function sincronizarAlvoFocoComPrivadoArenaJS(a) {
    if (!a || !Array.isArray(a.listaCriaturas) || a.listaCriaturas.length === 0) return;
    const idx = Math.min(a.listaCriaturas.length - 1, Math.max(0, Number(a.alvoFocoIdx || 0)));
    a.alvoFocoIdx = idx;
    const cr = a.listaCriaturas[idx];
    if (!cr) return;
    a._privadoCriatura.pvAtual = cr.pvAtual;
    a._privadoCriatura.pvMax = cr.pvMax;
    a._privadoCriatura.defesa = cr.defesa || a._privadoCriatura.defesa;
    a._privadoCriatura.ataque = cr.ataque || a._privadoCriatura.ataque;
    a._privadoCriatura.danoMedio = cr.danoMedio || a._privadoCriatura.danoMedio;
    a._privadoCriatura.nomeCriatura = cr.nomeCriatura || a._privadoCriatura.nomeCriatura;
    a._privadoCriatura.espacoQ = cr.espacoQ || 1;
    a._privadoCriatura.tamanhoCat = cr.tamanhoCat || 'Médio';
    if (!cr.condicoes) cr.condicoes = criarCondicoesPadrao2D(false);
    a.criaturaCaida = Boolean(cr.condicoes.caido);
    a.criaturaDesprevenida = Boolean(cr.condicoes.desprevenido || cr.condicoes.atordoado);
}

function selecionarAlvoFocoArenaJS(novoIdx) {
    if (!__ARENA_STATE__ || !Array.isArray(__ARENA_STATE__.listaCriaturas)) return;
    const alvo = __ARENA_STATE__.listaCriaturas[novoIdx];
    if (!alvo) return;
    __ARENA_STATE__.alvoFocoIdx = novoIdx;
    sincronizarAlvoFocoComPrivadoArenaJS(__ARENA_STATE__);
    atualizarPlacarVisualArena();
    exibirMensagemStatus(`Alvo focado: ${alvo.nomeCriatura} (${alvo.pvAtual}/${alvo.pvMax} PV • ${alvo.tamanhoCat || 'Médio'} ${alvo.espacoQ || 1}x${alvo.espacoQ || 1})!`);
}

function moverHeroiParaCelulaGridArenaJS(gx, gy) {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    if (!a || a.encerrado) return;

    if (a.condicoesHeroi && a.condicoesHeroi.atordoado) {
        exibirMensagemStatus('Você está Atordoado e não pode realizar ações neste turno!');
        return;
    }
    if (a.condicoesHeroi && a.condicoesHeroi.caido) {
        exibirMensagemStatus('Você está Caído! Levante-se antes de se deslocar normalmente.');
        return;
    }

    const ocupada = encontrarCelulaCriaturaOcupando2D(a.listaCriaturas, gx, gy);
    if (ocupada >= 0) {
        selecionarAlvoFocoArenaJS(ocupada);
        return;
    }

    const posAtual = a.posHeroi || { gx: 2, gy: 2 };
    const distQ = Math.max(Math.abs(posAtual.gx - gx), Math.abs(posAtual.gy - gy));
    if (distQ === 0) return;

    const deslocBaseM = (st.est && st.est.deslocamento) ? Number(st.est.deslocamento) : 9;
    const maxQuadrados = Math.max(1, Math.floor((a.condicoesHeroi && a.condicoesHeroi.lento ? deslocBaseM / 2 : deslocBaseM) / 1.5));
    const movLivre120 = Boolean(window.__MODO_MOVIMENTO_LIVRE_120__ !== false);

    if (!movLivre120) {
        if (a.acoesMovimentoRestantes <= 0) {
            exibirMensagemStatus('Você já usou suas Ações de Movimento neste turno! (Ou ative Movimento Livre 120×120)');
            return;
        }
        if (distQ > maxQuadrados) {
            exibirMensagemStatus(`Distância (${(distQ * 1.5).toFixed(1)}m) excede seu deslocamento por ação (${(maxQuadrados * 1.5).toFixed(1)}m)! Ative Movimento Livre 120×120 para grandes deslocamentos.`);
            return;
        }
        a.acoesMovimentoRestantes -= 1;
    } else if (a.acoesMovimentoRestantes > 0) {
        a.acoesMovimentoRestantes = Math.max(0, a.acoesMovimentoRestantes - 1);
    }
    a.posHeroi = { gx, gy };
    a.coberturaAtiva = (typeof ehPilarCoberturaMapa120 === 'function') ? ehPilarCoberturaMapa120(gx, gy) : false;

    const flanqAgora = verificarFlanqueamentoAlvoArenaJS(a, a.alvoFocoIdx || 0);
    const chkFlanq = document.getElementById('chk-cap5-flanquear');
    if (chkFlanq) chkFlanq.checked = flanqAgora;

    const distAlvoM = calcularDistanciaMetrosAlvoArenaJS(a, a.alvoFocoIdx || 0);
    registrarLinhaLogArena(
        `<strong>[Turno #${a.turno} · Movimentação 2D]</strong> ${st.nome} deslocou-se <strong>${(distQ * 1.5).toFixed(1)}m</strong> para (${gx + 1}, ${gy + 1}) ` +
        `(Distância até o Alvo: <strong>${distAlvoM.toFixed(1)}m</strong>${flanqAgora ? ' · <span style="color:#FACC15;">FLANQUEANDO (+2 Atq CaC!)</span>' : ''}).`
    );
    atualizarPlacarVisualArena();
}

function executarManobraPosicionamentoRapidoArenaJS(modo) {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    if (!a || a.encerrado) return;
    const alvo = (a.listaCriaturas || [])[a.alvoFocoIdx || 0];
    if (!alvo) return;
    const qAlvo = Math.max(1, Number(alvo.espacoQ || 1));

    if (modo === 'LEVANTAR') {
        if (!a.condicoesHeroi || !a.condicoesHeroi.caido) return;
        if (a.acoesMovimentoRestantes <= 0) { exibirMensagemStatus('Requer 1 Ação de Movimento!'); return; }
        a.acoesMovimentoRestantes -= 1;
        a.condicoesHeroi.caido = false;
        registrarLinhaLogArena(`<strong>[Turno #${a.turno}]</strong> ${st.nome} levantou-se.`);
        atualizarPlacarVisualArena();
        return;
    }
    if (modo === 'APAGAR_CHAMAS') {
        if (a.condicoesHeroi) a.condicoesHeroi.emChamas = false;
        atualizarPlacarVisualArena();
        return;
    }
    if (modo === 'AVANCAR_CAC') {
        a.posHeroi = { gx: Math.max(0, alvo.gx - 1), gy: alvo.gy };
        a.coberturaAtiva = false;
        if (a.acoesMovimentoRestantes > 0) a.acoesMovimentoRestantes -= 1;
    } else if (modo === 'FLANQUEAR_ALIADO') {
        a.aliadoFlanqueadorAtivo = true;
        a.posHeroi = { gx: Math.max(0, alvo.gx - 1), gy: alvo.gy };
        a.posAliadoFlanco = { gx: alvo.gx + qAlvo, gy: alvo.gy };
        a.coberturaAtiva = false;
        const dims = calcularDimensoesDinamicasGrid([a.posHeroi, a.posAliadoFlanco], a.listaCriaturas, 8, 5);
        a.gridCols = dims.cols; a.gridRows = dims.rows;
        if (a.acoesMovimentoRestantes > 0) a.acoesMovimentoRestantes -= 1;
        const chkFlanq = document.getElementById('chk-cap5-flanquear');
        if (chkFlanq) chkFlanq.checked = true;
        registrarLinhaLogArena(`<strong>[Flanqueamento 2D (p. 239)]</strong> ${st.nome} e Aliado cercaram <strong>${alvo.nomeCriatura}</strong> (${alvo.tamanhoCat || 'Médio'} ${qAlvo}x${qAlvo}) em lados opostos (+2 Ataque CaC)!`);
    } else if (modo === 'RECUAR_CURTO') {
        a.posHeroi = { gx: Math.max(0, alvo.gx - 6), gy: alvo.gy };
        a.coberturaAtiva = false;
        if (a.acoesMovimentoRestantes > 0) a.acoesMovimentoRestantes -= 1;
    } else if (modo === 'RECUAR_MEDIO') {
        a.posHeroi = { gx: Math.max(0, alvo.gx - 20), gy: alvo.gy };
        a.coberturaAtiva = false;
        if (a.acoesMovimentoRestantes > 0) a.acoesMovimentoRestantes -= 1;
    } else if (modo === 'RECUAR_LONGO') {
        a.posHeroi = { gx: Math.max(0, alvo.gx - 50), gy: alvo.gy };
        a.coberturaAtiva = false;
        if (a.acoesMovimentoRestantes > 0) a.acoesMovimentoRestantes -= 1;
    } else if (modo === 'COBERTURA') {
        a.posHeroi = { gx: Math.max(0, alvo.gx - 3), gy: Math.max(0, alvo.gy - 1) };
        a.coberturaAtiva = true;
        if (a.acoesMovimentoRestantes > 0) a.acoesMovimentoRestantes -= 1;
    }
    if (typeof sincronizarCameraMapa120ComUnidadesJS === 'function') {
        sincronizarCameraMapa120ComUnidadesJS([a.posHeroi, a.aliadoFlanqueadorAtivo ? a.posAliadoFlanco : null], a.listaCriaturas, true);
    }
    atualizarPlacarVisualArena();
}

function aplicarOuAlternarCondicaoAlvoArenaJS(chaveCond, noHeroi) {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    if (!a) return;
    if (noHeroi) {
        if (!a.condicoesHeroi) a.condicoesHeroi = criarCondicoesPadrao2D(false);
        a.condicoesHeroi[chaveCond] = !a.condicoesHeroi[chaveCond];
    } else {
        const alvo = (a.listaCriaturas || [])[a.alvoFocoIdx || 0];
        if (!alvo) return;
        if (!alvo.condicoes) alvo.condicoes = criarCondicoesPadrao2D(false);
        alvo.condicoes[chaveCond] = !alvo.condicoes[chaveCond];
        sincronizarAlvoFocoComPrivadoArenaJS(a);
    }
    atualizarPlacarVisualArena();
}

function processarDanoEmEncontroMultiploArenaJS(a, danoAplicado, ehMagiaArea, nomeMagia) {
    if (!a || !Array.isArray(a.listaCriaturas) || a.listaCriaturas.length === 0) return;
    const focoIdx = Math.min(a.listaCriaturas.length - 1, Math.max(0, Number(a.alvoFocoIdx || 0)));
    const alvoPrincipal = a.listaCriaturas[focoIdx];
    if (alvoPrincipal) {
        alvoPrincipal.pvAtual = a._privadoCriatura.pvAtual;
        if (ehMagiaArea && /fogo|chamas|incinerar|bola de fogo/i.test(nomeMagia || '')) {
            alvoPrincipal.condicoes.emChamas = true;
        }
    }
    if (ehMagiaArea && a.listaCriaturas.length > 1 && danoAplicado > 0) {
        a.listaCriaturas.forEach((cr, idx) => {
            if (idx !== focoIdx && cr.pvAtual > 0) {
                cr.pvAtual = Math.max(0, cr.pvAtual - danoAplicado);
                if (/fogo|chamas|incinerar|bola de fogo/i.test(nomeMagia || '')) cr.condicoes.emChamas = true;
            }
        });
    }
    if (a._privadoCriatura.pvAtual <= 0) {
        const proxVivoIdx = a.listaCriaturas.findIndex(c => c.pvAtual > 0);
        if (proxVivoIdx >= 0) {
            a.alvoFocoIdx = proxVivoIdx;
            sincronizarAlvoFocoComPrivadoArenaJS(a);
            a.encerrado = false;
        }
    }
}

function processarCondicoesInicioTurnoCriaturasArenaJS(a, st) {
    if (!a || !Array.isArray(a.listaCriaturas)) return;
    if (a.condicoesHeroi) {
        let dH = 0;
        if (a.condicoesHeroi.emChamas) dH += Math.floor(Math.random() * 6) + 1;
        if (a.condicoesHeroi.sangrando) dH += Math.floor(Math.random() * 6) + 1;
        if (a.condicoesHeroi.envenenado) dH += Math.floor(Math.random() * 6) + 1;
        if (dH > 0) a.pvHeroi = Math.max(0, a.pvHeroi - dH);
    }
    a.listaCriaturas.forEach(cr => {
        if (cr.pvAtual <= 0 || !cr.condicoes) return;
        let dC = 0;
        if (cr.condicoes.emChamas) dC += Math.floor(Math.random() * 6) + 1;
        if (cr.condicoes.sangrando) dC += Math.floor(Math.random() * 6) + 1;
        if (cr.condicoes.envenenado) dC += Math.floor(Math.random() * 6) + 1;
        if (dC > 0) {
            cr.pvAtual = Math.max(0, cr.pvAtual - dC);
            a.crencaIA.danoCausadoAcumulado += dC;
        }
    });
    sincronizarAlvoFocoComPrivadoArenaJS(a);
    if (a._privadoCriatura.pvAtual <= 0) {
        const vivoIdx = a.listaCriaturas.findIndex(c => c.pvAtual > 0);
        if (vivoIdx >= 0) {
            a.alvoFocoIdx = vivoIdx;
            sincronizarAlvoFocoComPrivadoArenaJS(a);
        } else {
            a.encerrado = true;
        }
    }
}

function renderizarPainelTatico2DArenaJS() {
    const panel = document.getElementById('arena-tactical-2d-panel');
    if (!panel || !__ARENA_STATE__) return;
    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    if (!Array.isArray(a.listaCriaturas) || (a.listaCriaturas.length === 0 && !a._tabuleiroSemAmeacas)) {
        inicializarEncontrosMultiplosEGrid2DArenaJS(a, st);
    }

    const posH = a.posHeroi || { gx: 2, gy: 2 };
    const focoIdx = Math.min(a.listaCriaturas.length - 1, Math.max(0, Number(a.alvoFocoIdx || 0)));
    const alvoFoco = a.listaCriaturas[focoIdx] || a.listaCriaturas[0];
    const flanqAtivo = verificarFlanqueamentoAlvoArenaJS(a, focoIdx);
    const distMetros = calcularDistanciaMetrosAlvoArenaJS(a, focoIdx);
    const deslocM = (st.est && st.est.deslocamento) ? st.est.deslocamento : 9;
    a.gridCols = 120;
    a.gridRows = 120;
    const cam = (typeof obterCameraAtivaMapa120JS === 'function')
        ? obterCameraAtivaMapa120JS()
        : { worldCols: 120, worldRows: 120, viewCols: 12, viewRows: 7, camX: 52, camY: 56, modoSeguir: 'AUTO' };
    const cols = cam.viewCols;
    const rows = cam.viewRows;

    const modoOclusaoGrid = window.__MODO_OCLUSAO_AMEACA__ || 'AUTO_ANTI_OCLUSAO';
    let htmlCelulas = '';
    for (let ly = 0; ly < rows; ly++) {
        for (let lx = 0; lx < cols; lx++) {
            const gx = cam.camX + lx;
            const gy = cam.camY + ly;
            const ehHeroi = (posH.gx === gx && posH.gy === gy);
            const ehAliado = (a.aliadoFlanqueadorAtivo && a.posAliadoFlanco && a.posAliadoFlanco.gx === gx && a.posAliadoFlanco.gy === gy);
            const ehPilar = (typeof ehPilarCoberturaMapa120 === 'function') ? ehPilarCoberturaMapa120(gx, gy) : (gx === 1 && (gy === 1 || gy === 3));
            const idxInim = encontrarCelulaCriaturaOcupando2D(a.listaCriaturas, gx, gy);
            const inimCell = idxInim >= 0 ? a.listaCriaturas[idxInim] : null;
            const visAncoraX = inimCell ? Math.max(cam.camX, inimCell.gx) : -1;
            const visAncoraY = inimCell ? Math.max(cam.camY, inimCell.gy) : -1;
            const ehAncoraInim = inimCell && (gx === visAncoraX && gy === visAncoraY);

            let bgCell = ((gx + gy) % 2 === 0) ? '#151C2C' : '#0F1522';
            let bordaCell = 'rgba(148,163,184,0.22)';
            let conteudo = `<span style="font-size:8px;color:#475569;">${gx + 1},${gy + 1}</span>`;
            const spanStyle = `grid-column:${lx + 1}; grid-row:${ly + 1}; height:46px; min-width:44px; position:relative; overflow:hidden;`;

            if (ehPilar && !ehHeroi && !inimCell) {
                bgCell = 'rgba(51,65,85,0.65)';
                conteudo = `<span title="Pilar de Cobertura (+5 Defesa)"></span>`;
            }
            // REGRA ANTI-OCLUSÃO NO GRID 2D (v64): Herói e Aliado SEMPRE aparecem no topo da célula;
            // Criaturas Grandes/Enormes/Colossais destacam seus quadrados ocupados sem engolir células vizinhas!
            if (ehHeroi) {
                bgCell = 'rgba(22,163,74,0.42)';
                bordaCell = '#4ADE80';
                const iconeCondH = (a.condicoesHeroi && a.condicoesHeroi.caido) ? '' : ((a.condicoesHeroi && a.condicoesHeroi.emChamas) ? '' : '');
                conteudo = (typeof construirToken2DHeroiGridHTML === 'function')
                    ? construirToken2DHeroiGridHTML(st, '#6CC296', 34, iconeCondH, Math.round((a.pvHeroi / Math.max(1, a.pvHeroiMax)) * 100))
                    : '';
            } else if (ehAliado) {
                bgCell = 'rgba(2,132,199,0.38)';
                bordaCell = '#38BDF8';
                conteudo = (typeof construirToken2DAliadoGridHTML === 'function')
                    ? construirToken2DAliadoGridHTML('#5B9BD5', 32)
                    : '';
            } else if (inimCell) {
                const ehFocoCell = (idxInim === focoIdx);
                const qC = Math.max(1, Number(inimCell.espacoQ || 1));
                bgCell = ehFocoCell ? 'rgba(220,38,38,0.36)' : 'rgba(127,29,29,0.24)';
                bordaCell = ehFocoCell ? (flanqAtivo ? '#FACC15' : '#F87171') : '#991B1B';
                if (ehAncoraInim && modoOclusaoGrid !== 'OCULTAR_TOKEN') {
                    const cnd = inimCell.condicoes || {};
                    const badgesC = (cnd.caido ? '' : '') + (cnd.emChamas ? '' : '') + (cnd.sangrando ? '' : '') + (cnd.desprevenido ? '' : '') + (cnd.envenenado ? '' : '') + (cnd.atordoado ? '' : '') + (cnd.lento ? '' : '');
                    const tokSize = 36;
                    const opTok = modoOclusaoGrid === 'FANTASMA_RAIO_X' ? 'opacity:0.42;' : '';
                    const tokHTML = (typeof construirToken2DCriaturaGridHTML === 'function')
                        ? `<div style="${opTok}z-index:3;">${construirToken2DCriaturaGridHTML(inimCell, bordaCell, tokSize, badgesC)}</div>`
                        : '';
                    conteudo = tokHTML;
                } else {
                    conteudo = `<div style="display:flex;flex-direction:column;align-items:center;line-height:1.1;"><span style="font-size:8.5px;font-weight:900;color:#FCA5A5;">${inimCell.rotulo}</span><span style="font-size:7.5px;color:#FDE047;">${qC}×${qC} (${gx+1},${gy+1})</span></div>`;
                }
            }

            htmlCelulas += `
                <div onclick="moverHeroiParaCelulaGridArenaJS(${gx}, ${gy})"
                     style="${spanStyle} background:${bgCell}; border:${inimCell ? '2px' : '1.5px'} solid ${bordaCell}; border-radius:7px; display:flex; align-items:center; justify-content:center; cursor:pointer; user-select:none;"
                     title="Célula (${gx + 1},${gy + 1}) do Mapa 120×120${inimCell ? ` — ${inimCell.nomeCriatura} (${inimCell.tamanhoCat} ${inimCell.espacoQ}x${inimCell.espacoQ})` : ''}">
                    ${conteudo}
                </div>
            `;
        }
    }

    const htmlAlvos = a.listaCriaturas.length === 0
        ? `<span style="font-size:11px;color:#94A3B8;font-style:italic;">Nenhuma ameaça no tabuleiro — selecione uma criatura e clique em Adicionar.</span>`
        : a.listaCriaturas.map((cr, idx) => {
            const ativo = (idx === focoIdx);
            const morto = cr.pvAtual <= 0;
            const qC = Math.max(1, Number(cr.espacoQ || 1));
            return `
                <div style="display:inline-flex; align-items:center; gap:5px; padding:4px 8px; border-radius:8px; background:${ativo ? 'linear-gradient(135deg,#7F1D1D,#B91C1C)' : '#0F172A'}; border:1.5px solid ${ativo ? '#FACC15' : '#475569'};">
                    <button type="button" onclick="selecionarAlvoFocoArenaJS(${idx})" style="background:none;border:none;color:${morto ? '#64748B' : '#FEF08A'};font-size:11px;font-weight:800;cursor:pointer;padding:0;">
                        ${ativo ? '' : ''}${cr.nomeCriatura} [${cr.tamanhoCat || 'Médio'} ${qC}x${qC} • ${morto ? '' : `${cr.pvAtual}/${cr.pvMax}`}]
                    </button>
                    <button type="button" onclick="removerCriaturaDoEncontroArenaJS(${idx})" style="background:rgba(127,29,29,0.85);border:1px solid #FCA5A5;border-radius:4px;color:#FEF08A;cursor:pointer;font-size:10px;font-weight:800;padding:1px 5px;" title="Excluir esta ameaça do tabuleiro">Excluir</button>
                </div>
            `;
        }).join('');

    const quickBarArena = document.getElementById('arena-stage-threats-quickbar');
    if (quickBarArena) {
        quickBarArena.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; background:rgba(15,23,42,0.94); border:1.5px solid rgba(239,68,68,0.55); border-radius:9px; padding:6px 10px; margin-top:6px;">
                <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                    <span style="font-size:11px; font-weight:900; color:#FCA5A5;">Ameaças no Tabuleiro (${a.listaCriaturas.length}):</span>
                    ${htmlAlvos}
                </div>
                <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                    <button type="button" class="btn-roll-inline" style="background:#991B1B;border-color:#FCA5A5;color:#FEF08A;padding:4px 9px;font-weight:800;" onclick="removerCriaturaDoEncontroArenaJS(${focoIdx})">
                        Excluir Ameaça Foco
                    </button>
                    ${a.listaCriaturas.length > 1 ? `<button type="button" class="btn-roll-inline" style="background:#450A0A;border-color:#F87171;color:#FCA5A5;padding:4px 9px;" onclick="limparTodasAmeacasArenaJS()">Limpar Todas</button>` : ''}
                </div>
            </div>
        `;
    }

    const listaCat = obterCatalogoAmeacasCap7Geral();
    const optsCriaturas = listaCat.map(c => {
        const tInfo = calcularTamanhoCriaturaObj(c.tipo_nivel_tamanho || 'Médio');
        return `<option value="${c.id_ameaca}">[ND ${c.nd}] ${c.nome} (${tInfo.categoria} ${tInfo.espacoQ}x${tInfo.espacoQ} • ${c.pv} PV)</option>`;
    }).join('');

    const condAlvo = (alvoFoco && alvoFoco.condicoes) ? alvoFoco.condicoes : {};
    const condHeroi = a.condicoesHeroi || {};
    const btnCond = (chave, rotulo, corAtiva) => {
        const on = Boolean(condAlvo[chave]);
        return `<button type="button" onclick="aplicarOuAlternarCondicaoAlvoArenaJS('${chave}', false)"
            style="padding:4px 8px; border-radius:6px; font-size:10.5px; font-weight:800; cursor:pointer; background:${on ? corAtiva : '#1E293B'}; color:#FFF; border:1px solid ${on ? '#FEF08A' : '#475569'};">
            ${rotulo} ${on ? '' : ''}
        </button>`;
    };

    setTimeout(() => { try { popularSelectsEstaticosCriaturasJS(); } catch(e){} }, 10);
    panel.innerHTML = `
        <div style="background:linear-gradient(160deg, #111625 0%, #0A0D16 100%); border:1.5px solid rgba(212,175,55,0.55); border-radius:12px; padding:10px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:8px;">
                <div style="font-size:12px; font-weight:800; color:#FDE047;">
                    Mapa de Batalha Dinâmico <strong>120×120 (180m × 180m = 14.400 quadrados)</strong> · Janela [${cam.camX + 1}..${cam.camX + cols}, ${cam.camY + 1}..${cam.camY + rows}] · Você: (${posH.gx + 1},${posH.gy + 1})
                </div>
                <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                    <button type="button" id="btn-arena-oclusao-ameaca" class="btn-roll-inline" style="background:#7C2D12;border-color:#FACC15;color:#FEF08A;padding:4px 9px;font-weight:900;" onclick="alternarModoOclusaoAmeacaGiganteJS()" title="Alterna entre Anti-Oclusão Automática, Token Fantasma (35%) e Ocultar Token da Ameaça para enxergar todos os personagens!">
                        ${typeof obterRotuloBotaoOclusaoAmeacaJS === 'function' ? obterRotuloBotaoOclusaoAmeacaJS() : 'Ameaça: Anti-Oclusão Auto'}
                    </button>
                    <button type="button" class="btn-roll-inline" style="background:#0284C7;border-color:#38BDF8;padding:4px 9px;" onclick="alternarModoVisibilidadePalco2DJS()">
                        ${window.__PALCO_MODO_TOKENS_LIMPOS__ ? 'Palco: Tokens Limpos (Clique p/ Sprites)' : 'Palco: Sprites 2D (Clique p/ Tokens Limpos)'}
                    </button>
                    <span class="quick-pill" style="background:${distMetros <= 1.5 ? '#065F46' : '#1E3A8A'};">${distMetros.toFixed(1)}m</span>
                    <span class="quick-pill" style="background:${flanqAtivo ? '#B45309' : '#1E293B'};">Flanquear: ${flanqAtivo ? '+2 ATQ' : 'Off'}</span>
                </div>
            </div>

            <!-- AUDITORIA DE COMPATIBILIDADE DE PODERES, EMPUNHADURA E COMBOS (v51) -->
            ${typeof construirBarraAuditoriaPoderesArmaHTML === 'function' ? construirBarraAuditoriaPoderesArmaHTML(st) : ''}

            <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center; margin-bottom:8px; padding:6px 8px; background:rgba(0,0,0,0.35); border-radius:8px;">
                <span style="font-size:11px; font-weight:800; color:#FCA5A5;">Criaturas no Combate (${a.listaCriaturas.length}):</span>
                ${htmlAlvos}
            </div>

            <div style="display:grid; grid-template-columns:1.4fr 1fr; gap:10px; align-items:start;" class="arena-vs-grid">
                <div style="overflow-x:auto;">
                    <div style="display:grid; grid-template-columns:repeat(${cols}, minmax(42px, 1fr)); gap:4px; background:#070A12; padding:6px; border-radius:8px; border:1px solid #334155;">
                        ${htmlCelulas}
                    </div>
                </div>

                <div style="display:flex; flex-direction:column; gap:7px;">
                    <div style="background:rgba(15,23,42,0.9); border:1px solid #D4AF37; border-radius:8px; padding:7px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; gap:6px; margin-bottom:5px;">
                            <span style="font-size:10.5px; font-weight:900; color:#FDE047;">Câmera &amp; Radar 120×120 (180m×180m):</span>
                            <label style="font-size:10px; color:#4ADE80; font-weight:800; display:inline-flex; align-items:center; gap:3px; margin:0; cursor:pointer;">
                                <input type="checkbox" ${window.__MODO_MOVIMENTO_LIVRE_120__ !== false ? 'checked' : ''} onchange="window.__MODO_MOVIMENTO_LIVRE_120__=this.checked;atualizarPlacarVisualArena();" style="width:auto;min-height:auto;"> Mov. Livre 120×120
                            </label>
                        </div>
                        <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                            ${typeof construirMiniMapaRadar120x120SVG === 'function' ? construirMiniMapaRadar120x120SVG([posH, a.aliadoFlanqueadorAtivo ? a.posAliadoFlanco : null], a.listaCriaturas) : ''}
                            <div style="flex:1; min-width:145px; display:flex; flex-direction:column; gap:4px;">
                                <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:3px;">
                                    <button type="button" class="btn-roll-inline" onclick="centralizarCameraMapa120JS('HEROI')" title="Centralizar no Herói">Herói</button>
                                    <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="moverCameraMapa120JS(0, -5)">⬆Norte</button>
                                    <button type="button" class="btn-roll-inline" onclick="centralizarCameraMapa120JS('AMEACA')" title="Centralizar na Ameaça">Alvo</button>
                                    <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="moverCameraMapa120JS(-6, 0)">⬅Oeste</button>
                                    <button type="button" class="btn-roll-inline" style="background:#B45309;color:#FEF08A;font-weight:900;" onclick="centralizarCameraMapa120JS('AUTO')">Auto</button>
                                    <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="moverCameraMapa120JS(6, 0)">Leste</button>
                                    <button type="button" class="btn-roll-inline" onclick="alterarZoomCameraMapa120JS('PROXIMO')">10×6</button>
                                    <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="moverCameraMapa120JS(0, 5)">⬇Sul</button>
                                    <button type="button" class="btn-roll-inline" onclick="alterarZoomCameraMapa120JS('AMPLO')">18×10</button>
                                </div>
                                <div style="display:flex; gap:3px; align-items:center; margin-top:2px;">
                                    <span style="font-size:9.5px;color:#CBD5E1;">Ir X,Y:</span>
                                    <input type="number" id="arena-inp-coord-x120" min="1" max="120" value="${posH.gx + 1}" style="width:46px;min-height:24px;padding:1px 4px;font-size:10.5px;background:#090D16;color:#FEF08A;border:1px solid #475569;">
                                    <input type="number" id="arena-inp-coord-y120" min="1" max="120" value="${posH.gy + 1}" style="width:46px;min-height:24px;padding:1px 4px;font-size:10.5px;background:#090D16;color:#FEF08A;border:1px solid #475569;">
                                    <button type="button" class="btn-roll-inline" style="background:#059669;border-color:#4ADE80;" onclick="saltarParaCoordenadaMapa120ArenaJS()">Ir</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="font-size:11px; font-weight:800; color:#93C5FD; text-transform:uppercase;">Movimentação &amp; Distâncias de Batalha (1,5m a 90m):</div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:5px;">
                        <button type="button" class="btn btn-manual" style="margin:0; min-height:32px; padding:4px 6px; font-size:10.5px;" onclick="executarManobraPosicionamentoRapidoArenaJS('AVANCAR_CAC')">Avançar CaC</button>
                        <button type="button" class="btn btn-gold" style="margin:0; min-height:32px; padding:4px 6px; font-size:10.5px;" onclick="executarManobraPosicionamentoRapidoArenaJS('FLANQUEAR_ALIADO')">Flanquear (+2)</button>
                        <button type="button" class="btn btn-outline" style="margin:0; min-height:32px; padding:4px 6px; font-size:10.5px;" onclick="executarManobraPosicionamentoRapidoArenaJS('RECUAR_CURTO')">⬅Recuar Curto</button>
                        <button type="button" class="btn btn-outline" style="margin:0; min-height:32px; padding:4px 6px; font-size:10.5px;" onclick="executarManobraPosicionamentoRapidoArenaJS('COBERTURA')">Cobertura (+5)</button>
                    </div>
                    <div style="font-size:11px; font-weight:800; color:#FDE047; text-transform:uppercase;">Condições no Alvo (${alvoFoco ? alvoFoco.rotulo : '#1'}):</div>
                    <div style="display:flex; flex-wrap:wrap; gap:4px;">
                        ${btnCond('caido', 'Caído', '#B91C1C')}
                        ${btnCond('emChamas', 'Chamas', '#EA580C')}
                        ${btnCond('sangrando', 'Sangrando', '#991B1B')}
                        ${btnCond('desprevenido', 'Desprev', '#D97706')}
                        ${btnCond('envenenado', 'Veneno', '#15803D')}
                        ${btnCond('lento', 'Lento', '#0284C7')}
                        ${btnCond('atordoado', 'Atordoado', '#6D28D9')}
                    </div>
                    <div style="display:flex; flex-wrap:wrap; gap:4px; align-items:center; padding-top:4px; border-top:1px dashed rgba(148,163,184,0.2);">
                        <span style="font-size:10px; color:#CBD5E1; font-weight:700;">Herói:</span>
                        <button type="button" class="btn-roll-inline" onclick="aplicarOuAlternarCondicaoAlvoArenaJS('caido', true)">${condHeroi.caido ? 'Levantar' : 'Caído'}</button>
                        <button type="button" class="btn-roll-inline" onclick="aplicarOuAlternarCondicaoAlvoArenaJS('emChamas', true)">${condHeroi.emChamas ? 'Apagar' : 'Chamas'}</button>
                        <button type="button" class="btn-roll-inline" onclick="aplicarOuAlternarCondicaoAlvoArenaJS('sangrando', true)">${condHeroi.sangrando ? 'Estancar' : 'Sangrando'}</button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// ==============================================================================
// MESAS ONLINE EM GRUPO 2D (ENCONTROS MISTOS ILIMITADOS + TAMANHO/ESPAÇO OCUPADO) - v50
// ==============================================================================
var ESTADO_MESA_ONLINE_ATUAL = null;
var CANAL_BROADCAST_MESA = null;
var TIMER_POLLING_MESA_ONLINE = null;
var HEROI_SELECIONADO_GRID_MESA_ID = null;

function inicializarCanalBroadcastMesa() {
    if (CANAL_BROADCAST_MESA) return;
    try {
        if (typeof BroadcastChannel !== 'undefined') {
            CANAL_BROADCAST_MESA = new BroadcastChannel('t20_mesa_online_sync_v50');
            CANAL_BROADCAST_MESA.onmessage = function(ev) {
                if (ev && ev.data && ev.data.codigoSala) {
                    const codInput = document.getElementById('mesa-input-codigo');
                    const codAtual = codInput ? String(codInput.value || '').trim().toUpperCase() : 'VALKARIA-2026';
                    if (String(ev.data.codigoSala).toUpperCase() === codAtual) {
                        ESTADO_MESA_ONLINE_ATUAL = ev.data;
                        salvarMesaLocalStorage(ESTADO_MESA_ONLINE_ATUAL);
                        renderizarMesaOnlineCompletaUI();
                    }
                }
            };
        }
    } catch (e) {}
}

function detectarModoTransporteMesaOnline() {
    if (typeof google !== 'undefined' && google.script && google.script.run) {
        return { modo: 'APPS_SCRIPT', rotulo: 'Google Apps Script Ativo (Sincronização Global)' };
    }
    if (typeof window !== 'undefined' && window.location && /^https?:/.test(window.location.protocol)) {
        return { modo: 'REST_SQL', rotulo: 'Servidor SQL REST Ativo (/api/mesas)' };
    }
    return { modo: 'HTML_LOCAL', rotulo: 'Modo HTML Local (BroadcastChannel + Token WhatsApp/Discord)' };
}

function obterCatalogoAmeacasCap7Mesa() {
    return obterCatalogoAmeacasCap7Geral();
}

function normalizarAmeacaParaMesa(c) {
    if (!c) {
        return {
            id: 'CAP7_048', nome: 'Dragão Jovem', nd: '7', nd_num: 7, papel: 'Solo', patamar: 'Veterano',
            tipoTamanho: 'Monstro (dragão) 13, Grande', tamanhoCat: 'Grande', espacoQ: 2,
            grupo_cap7: 'Dragões', ataque: 24, dano_medio: 54, defesa: 29,
            forte: 19, media: 14, fraca: 8, pv: 280, cd: 24
        };
    }
    const tipoStr = c.tipo_nivel_tamanho || c.tipoTamanho || 'Médio';
    const tamInfo = calcularTamanhoCriaturaObj(tipoStr);
    return {
        id: c.id_ameaca || c.id || 'CAP7_048',
        nome: c.nome || 'Dragão Jovem',
        nd: String(c.nd || c.nd_numerico || '7'),
        nd_num: Number(c.nd_numerico || c.nd_num || 7),
        papel: c.papel || 'Solo',
        patamar: c.patamar || (Number(c.nd_numerico || 7) <= 4 ? 'Iniciante' : (Number(c.nd_numerico || 7) <= 10 ? 'Veterano' : 'Campeão')),
        tipoTamanho: tipoStr,
        tamanhoCat: tamInfo.categoria,
        espacoQ: tamInfo.espacoQ,
        grupo_cap7: c.grupo_cap7 || 'Monstros & Chefes',
        ataque: Number(c.bonus_ataque !== undefined ? c.bonus_ataque : (c.ataque || 22)),
        dano_medio: Number(c.dano_medio !== undefined ? c.dano_medio : (c.danoMedio || 45)),
        defesa: Number(c.defesa || 28),
        forte: Number(c.fortitude !== undefined ? c.fortitude : (c.forte || 18)),
        media: Number(c.reflexos !== undefined ? c.reflexos : (c.media || 13)),
        fraca: Number(c.vontade !== undefined ? c.vontade : (c.fraca || 7)),
        pv: Number(c.pv || 280),
        cd: Number(c.cd_efeito !== undefined ? c.cd_efeito : (c.cd || 22))
    };
}

function obterAmeacaCap7PorIdOuPadrao(idAmeaca) {
    const lista = obterCatalogoAmeacasCap7Mesa();
    let encontrada = lista.find(a => a.id_ameaca === idAmeaca || a.id === idAmeaca || a.nome === idAmeaca);
    if (!encontrada && lista.length > 0) {
        encontrada = lista.find(a => (a.nome || '').toLowerCase().includes('dragão') || String(a.nd) === '7') || lista[Math.min(12, lista.length - 1)];
    }
    return normalizarAmeacaParaMesa(encontrada);
}

function extrairParticipanteDaFichaAtual() {
    const st = garantirEstadoFichaParaArena();
    const est = (st && st.est) ? st.est : {};
    const nv = Math.max(1, Number((st && st.nivel) || 6));
    const racaNome = (st && st.raca && st.raca.nome) ? st.raca.nome : 'Humano';
    const racaTam = (st && st.raca && st.raca.tamanho) ? st.raca.tamanho : 'Médio';
    const tamH = calcularTamanhoCriaturaObj(racaTam);
    const classeNome = (st && st.classe && st.classe.nome) ? st.classe.nome : 'Guerreiro';
    const armaNome = (st && st.arma && st.arma.nome) ? st.arma.nome : 'Montante';
    const classesResumo = (typeof formatarResumoClassesFichaJS === 'function' && st)
        ? formatarResumoClassesFichaJS(st) : `${classeNome} Nv. ${nv}`;

    const pvMax = Math.max(12, Number(est.pvMax || (20 + nv * 6)));
    const pmMax = Math.max(4, Number(est.pmMax || (nv * 4)));
    const defesa = Math.max(10, Number(est.defesa || (16 + Math.floor(nv * 0.8))));
    const ataqueBonus = Number(est.bonusAtaque !== undefined ? est.bonusAtaque : (6 + Math.floor(nv * 1.2)));
    const danoMedio = Math.max(6, Math.round(Number(est.danoMedio || (14 + nv * 2.5))));
    const cdMagia = Number(est.cdMagia || (15 + Math.floor(nv / 2)));
    const modIni = (est.bonusPericias && est.bonusPericias['Iniciativa'] !== undefined)
        ? Number(est.bonusPericias['Iniciativa'])
        : (Math.floor(nv / 2) + 3);

    let papel = 'Combatente Marcial';
    const clsLower = classesResumo.toLowerCase();
    if (clsLower.includes('cavaleiro') || (defesa >= 24 && pvMax >= 45)) papel = 'Tanque / Linha de Frente';
    else if (clsLower.includes('arcanista')) papel = 'Conjurador Arcano (AoE/Controle)';
    else if (clsLower.includes('clérigo') || clsLower.includes('clerigo') || clsLower.includes('bardo') || clsLower.includes('druida')) papel = 'Suporte Divino & Cura';

    return {
        idHeroi: 'HEROI_' + String((st && st.nome) || 'Protagonista').replace(/\W+/g, '_').toUpperCase(),
        nome: (st && st.nome) || 'Kaelen Fúria-Rubra',
        jogador: (st && st.jogador) || 'Bruno',
        raca: racaNome,
        tamanhoCat: tamH.categoria,
        espacoQ: tamH.espacoQ,
        classeNome: classeNome,
        armaNome: armaNome,
        classesResumo: classesResumo,
        nivel: nv,
        papel: papel,
        pvAtual: pvMax,
        pvMax: pvMax,
        pmAtual: pmMax,
        pmMax: pmMax,
        defesaBase: defesa,
        ataqueBonus: ataqueBonus,
        danoMedio: danoMedio,
        cdMagia: cdMagia,
        iniciativaBonus: modIni,
        iniciativaRolada: (Math.floor(Math.random() * 20) + 1) + modIni,
        provocando: false,
        defesaPosturaBonus: 0,
        gx: 3,
        gy: 2,
        condicoes: criarCondicoesPadrao2D(false)
    };
}

function construirGrupo4HeroisPadrao(heroiPrincipal) {
    const h0 = heroiPrincipal || extrairParticipanteDaFichaAtual();
    h0.gx = 56; h0.gy = 60;
    if (!h0.condicoes) h0.condicoes = criarCondicoesPadrao2D(false);

    const nv = Math.max(1, Number(h0.nivel || 6));
    const tanque = {
        idHeroi: 'ALLY_TANQUE_BASTIAO', nome: 'Sir Valerius', jogador: 'Aliado Co-op 2',
        raca: 'Anão', tamanhoCat: 'Médio', espacoQ: 1, classeNome: 'Cavaleiro', armaNome: 'Espada Longa',
        classesResumo: `Cavaleiro ${nv}`, nivel: nv, papel: 'Tanque / Linha de Frente',
        pvAtual: 28 + (nv * 9), pvMax: 28 + (nv * 9), pmAtual: 3 * nv, pmMax: 3 * nv,
        defesaBase: 21 + Math.floor(nv * 1.1), ataqueBonus: 6 + Math.floor(nv * 1.2),
        danoMedio: 12 + Math.floor(nv * 2.2), cdMagia: 14 + Math.floor(nv / 2),
        iniciativaBonus: Math.floor(nv / 2) + 2, iniciativaRolada: (Math.floor(Math.random() * 20) + 1) + Math.floor(nv / 2) + 2,
        provocando: true, defesaPosturaBonus: 2, gx: 59, gy: 60, condicoes: criarCondicoesPadrao2D(false)
    };
    const arcano = {
        idHeroi: 'ALLY_ARCANO_MAGO', nome: 'Lyra Vorpal', jogador: 'Aliado Co-op 3',
        raca: 'Elfo', tamanhoCat: 'Médio', espacoQ: 1, classeNome: 'Arcanista', armaNome: 'Cajado Arcano',
        classesResumo: `Arcanista ${nv}`, nivel: nv, papel: 'Conjurador Arcano (Dano/Controle)',
        pvAtual: 12 + (nv * 4), pvMax: 12 + (nv * 4), pmAtual: 6 * nv + 4, pmMax: 6 * nv + 4,
        defesaBase: 15 + Math.floor(nv * 0.7), ataqueBonus: 5 + Math.floor(nv * 1.1),
        danoMedio: 18 + Math.floor(nv * 3.8), cdMagia: 18 + Math.floor(nv * 0.8),
        iniciativaBonus: Math.floor(nv / 2) + 5, iniciativaRolada: (Math.floor(Math.random() * 20) + 1) + Math.floor(nv / 2) + 5,
        provocando: false, defesaPosturaBonus: 0, gx: 54, gy: 59, condicoes: criarCondicoesPadrao2D(false)
    };
    const suporte = {
        idHeroi: 'ALLY_CLERIGO_LENA', nome: 'Irmã Solange', jogador: 'Aliado Co-op 4',
        raca: 'Qareen', tamanhoCat: 'Médio', espacoQ: 1, classeNome: 'Clérigo', armaNome: 'Maça',
        classesResumo: `Clérigo ${nv}`, nivel: nv, papel: 'Suporte Divino & Cura',
        pvAtual: 18 + (nv * 6), pvMax: 18 + (nv * 6), pmAtual: 5 * nv + 3, pmMax: 5 * nv + 3,
        defesaBase: 19 + Math.floor(nv * 0.9), ataqueBonus: 5 + Math.floor(nv * 1.0),
        danoMedio: 11 + Math.floor(nv * 1.8), cdMagia: 17 + Math.floor(nv * 0.7),
        iniciativaBonus: Math.floor(nv / 2) + 3, iniciativaRolada: (Math.floor(Math.random() * 20) + 1) + Math.floor(nv / 2) + 3,
        provocando: false, defesaPosturaBonus: 0, gx: 54, gy: 61, condicoes: criarCondicoesPadrao2D(false)
    };
    return [h0, tanque, arcano, suporte];
}

function criarObjetoInimigoMesa(am, indice, gx, gy, fatorPV) {
    const pvInd = Math.max(12, Math.round(Number(am.pv || 120) * (fatorPV || 1.0)));
    return {
        indice: indice,
        rotulo: `#${indice + 1}`,
        id: am.id,
        nome: am.nome,
        nd: am.nd,
        nd_num: am.nd_num || 7,
        papel: am.papel || 'Solo',
        patamar: am.patamar || 'Veterano',
        tipoTamanho: am.tipoTamanho || 'Médio',
        tamanhoCat: am.tamanhoCat || 'Médio',
        espacoQ: Math.max(1, Number(am.espacoQ || 1)),
        grupo_cap7: am.grupo_cap7 || 'Dragões',
        pvAtual: pvInd,
        pvMax: pvInd,
        defesa: Number(am.defesa || 28),
        ataque: Number(am.ataque || 22),
        danoMedio: Number(am.dano_medio || 45),
        forte: Number(am.forte || 18),
        media: Number(am.media || 13),
        fraca: Number(am.fraca || 7),
        cd: Number(am.cd || 22),
        gx: gx,
        gy: gy,
        condicoes: criarCondicoesPadrao2D(false)
    };
}

function construirListaInimigosMesaOnline(am, qtd, heroisLista) {
    const n = Math.max(1, Number(qtd || 1));
    const fatorPV = 1.0; // 100% PV oficial sem redução
    const lista = [];
    for (let i = 0; i < n; i++) {
        const posLivre = encontrarPosicaoLivreBloco2D(heroisLista || [], lista, am.espacoQ || 1, 4);
        const obj = criarObjetoInimigoMesa(am, i, posLivre.gx, posLivre.gy, fatorPV);
        if (n > 1) obj.nome = `${am.nome} #${i + 1}`;
        lista.push(obj);
    }
    return lista;
}

function criarEstadoInicialMesaOnline(codigoSala) {
    const cod = String(codigoSala || 'VALKARIA-2026').trim().toUpperCase();
    const hPrincipal = extrairParticipanteDaFichaAtual();
    const grupoInicial = construirGrupo4HeroisPadrao(hPrincipal);
    HEROI_SELECIONADO_GRID_MESA_ID = hPrincipal.idHeroi;
    const am = obterAmeacaCap7PorIdOuPadrao('CAP7_048');
    const listaInim = construirListaInimigosMesaOnline(am, 1, grupoInicial);
    return {
        codigoSala: cod,
        nomeMesa: 'Coração de Rubi — Incursão Co-op',
        mestreNome: 'Bruno (Mestre T20)',
        idAmeacaAtiva: am.id,
        qtdCriaturasMesa: 1,
        alvoFocoMesaIdx: 0,
        rodadaAtual: 1,
        turnoIndice: 0,
        chefeAtivo: Object.assign({
            iniciativaRolada: 14 + Math.floor((Number(am.nd_num) || 5) * 1.2),
            alvoProvocadoId: 'ALLY_TANQUE_BASTIAO',
            penalidadeAtaque: 0,
            penalidadeDefesa: 0
        }, listaInim[0]),
        listaInimigosMesa: listaInim,
        buffsGrupo: { oracaoBonus: 0, inspiracaoBonus: 0, bencaoBonus: 0, escudoDaFeDefesa: 0 },
        participantes: grupoInicial,
        ordemIniciativa: [],
        historicoEventos: [
            {
                horario: new Date().toLocaleTimeString('pt-BR'),
                autor: 'Sistema T20',
                tipo: 'SISTEMA',
                mensagem: `Sala "${cod}" iniciada! ${am.nome} (${am.tamanhoCat} ${am.espacoQ}x${am.espacoQ}) ocupa ${am.espacoQ}x${am.espacoQ} quadrados no Grid Tático. Adicione quantas criaturas quiser!`
            }
        ]
    };
}

function salvarMesaLocalStorage(mesa) {
    if (!mesa || !mesa.codigoSala) return;
    try {
        const mapa = JSON.parse(localStorage.getItem('t20_mesas_online_v50') || '{}');
        mapa[String(mesa.codigoSala).toUpperCase()] = mesa;
        localStorage.setItem('t20_mesas_online_v50', JSON.stringify(mapa));
    } catch (e) {}
}

function carregarMesaLocalStorage(codigoSala) {
    try {
        const mapa = JSON.parse(localStorage.getItem('t20_mesas_online_v50') || '{}');
        return mapa[String(codigoSala || '').toUpperCase()] || null;
    } catch (e) { return null; }
}

function registrarEventoMesaOnline(autor, tipo, mensagem) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const ev = { horario: new Date().toLocaleTimeString('pt-BR'), autor: autor || 'Grupo', tipo: tipo || 'ACAO', mensagem: mensagem };
    if (!Array.isArray(ESTADO_MESA_ONLINE_ATUAL.historicoEventos)) ESTADO_MESA_ONLINE_ATUAL.historicoEventos = [];
    ESTADO_MESA_ONLINE_ATUAL.historicoEventos.unshift(ev);
    if (ESTADO_MESA_ONLINE_ATUAL.historicoEventos.length > 60) ESTADO_MESA_ONLINE_ATUAL.historicoEventos.length = 60;
    ESTADO_MESA_ONLINE_ATUAL.ultimoEvento = ev;
}

function verificarHeroiFlanqueandoAlvoMesa(heroi, alvo, todosHerois) {
    if (!heroi || !alvo || Number(heroi.pvAtual || 0) <= 0 || Number(alvo.pvAtual || 0) <= 0) return false;
    const distH = calcularDistanciaQuadrados2D(heroi, alvo);
    if (distH !== 1) return false;
    return (todosHerois || []).some(outro => {
        if (!outro || outro.idHeroi === heroi.idHeroi || Number(outro.pvAtual || 0) <= 0) return false;
        return verificarFlanqueamentoGeometria2D(heroi, outro, alvo);
    });
}

function sincronizarAlvoFocoMesaOnline() {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const m = ESTADO_MESA_ONLINE_ATUAL;
    if (!Array.isArray(m.listaInimigosMesa) || m.listaInimigosMesa.length === 0) {
        if (m._tabuleiroSemAmeacas) {
            m.listaInimigosMesa = [];
            return;
        }
        const am = obterAmeacaCap7PorIdOuPadrao(m.idAmeacaAtiva || 'CAP7_048');
        m.listaInimigosMesa = construirListaInimigosMesaOnline(am, 1, m.participantes);
    }
    const idx = Math.min(m.listaInimigosMesa.length - 1, Math.max(0, Number(m.alvoFocoMesaIdx || 0)));
    m.alvoFocoMesaIdx = idx;
    const foco = m.listaInimigosMesa[idx];
    if (foco && m.chefeAtivo) {
        m.chefeAtivo.nome = foco.nome;
        m.chefeAtivo.pvAtual = foco.pvAtual;
        m.chefeAtivo.pvMax = foco.pvMax;
        m.chefeAtivo.defesa = foco.defesa;
        m.chefeAtivo.gx = foco.gx;
        m.chefeAtivo.gy = foco.gy;
        m.chefeAtivo.espacoQ = foco.espacoQ || 1;
        m.chefeAtivo.tamanhoCat = foco.tamanhoCat || 'Médio';
        m.chefeAtivo.condicoes = foco.condicoes || criarCondicoesPadrao2D(false);
    }
}

function selecionarAlvoFocoMesaOnlineJS(idx) {
    if (!ESTADO_MESA_ONLINE_ATUAL || !Array.isArray(ESTADO_MESA_ONLINE_ATUAL.listaInimigosMesa)) return;
    ESTADO_MESA_ONLINE_ATUAL.alvoFocoMesaIdx = idx;
    sincronizarAlvoFocoMesaOnline();
    propagarEstadoMesaOnlineParaServidores();
}

function adicionarCriaturaAoEncontroMesaOnlineJS(idAmeacaSel) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const m = ESTADO_MESA_ONLINE_ATUAL;
    m._tabuleiroSemAmeacas = false;
    const am = obterAmeacaCap7PorIdOuPadrao(idAmeacaSel);
    if (!Array.isArray(m.listaInimigosMesa)) m.listaInimigosMesa = [];
    const posLivre = encontrarPosicaoLivreBloco2D(m.participantes || [], m.listaInimigosMesa, am.espacoQ || 1, 4);
    const idxNovo = m.listaInimigosMesa.length;
    const obj = criarObjetoInimigoMesa(am, idxNovo, posLivre.gx, posLivre.gy, 1.0);
    obj.nome = `${am.nome} #${idxNovo + 1}`;
    m.listaInimigosMesa.push(obj);
    m.alvoFocoMesaIdx = m.listaInimigosMesa.length - 1;
    m.qtdCriaturasMesa = m.listaInimigosMesa.length;
    sincronizarAlvoFocoMesaOnline();
    registrarEventoMesaOnline('Mestre', 'ENCONTRO', `Adicionada criatura ao encontro: ${am.nome} (${am.tamanhoCat} ${am.espacoQ}x${am.espacoQ} • ND ${am.nd}) na posição (${posLivre.gx + 1}, ${posLivre.gy + 1})!`);
    propagarEstadoMesaOnlineParaServidores();
}

function removerCriaturaDoEncontroMesaOnlineJS(idxRem) {
    if (!ESTADO_MESA_ONLINE_ATUAL || !Array.isArray(ESTADO_MESA_ONLINE_ATUAL.listaInimigosMesa) || ESTADO_MESA_ONLINE_ATUAL.listaInimigosMesa.length === 0) {
        exibirMensagemStatus('ℹNão há ameaças no tabuleiro da Mesa para excluir.');
        return;
    }
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const idxAlvo = (idxRem === undefined || idxRem === null)
        ? Math.min(m.listaInimigosMesa.length - 1, Math.max(0, Number(m.alvoFocoMesaIdx || 0)))
        : Number(idxRem);
    const rem = m.listaInimigosMesa.splice(idxAlvo, 1)[0];
    m.listaInimigosMesa.forEach((cr, i) => { cr.indice = i; cr.rotulo = `#${i + 1}`; });
    m.qtdCriaturasMesa = m.listaInimigosMesa.length;
    if (m.listaInimigosMesa.length === 0) {
        m._tabuleiroSemAmeacas = true;
        m.alvoFocoMesaIdx = 0;
        if (m.chefeAtivo) {
            m.chefeAtivo.pvAtual = 0;
            m.chefeAtivo.nome = 'Nenhuma Ameaça (Tabuleiro Limpo)';
        }
    } else {
        m._tabuleiroSemAmeacas = false;
        m.alvoFocoMesaIdx = Math.min(m.alvoFocoMesaIdx || 0, m.listaInimigosMesa.length - 1);
        sincronizarAlvoFocoMesaOnline();
    }
    if (rem) {
        registrarEventoMesaOnline('Mestre', 'ENCONTRO', `Ameaça ${rem.nome} excluída do tabuleiro.`);
        exibirMensagemStatus(`${rem.nome} excluída do tabuleiro da Mesa.`);
    }
    propagarEstadoMesaOnlineParaServidores();
}

function limparTodasAmeacasMesaOnlineJS() {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const m = ESTADO_MESA_ONLINE_ATUAL;
    m.listaInimigosMesa = [];
    m._tabuleiroSemAmeacas = true;
    m.qtdCriaturasMesa = 0;
    m.alvoFocoMesaIdx = 0;
    if (m.chefeAtivo) {
        m.chefeAtivo.pvAtual = 0;
        m.chefeAtivo.nome = 'Nenhuma Ameaça (Tabuleiro Limpo)';
    }
    registrarEventoMesaOnline('Mestre', 'ENCONTRO', `Todas as ameaças foram excluídas do tabuleiro da Mesa.`);
    exibirMensagemStatus('Todas as ameaças foram excluídas do tabuleiro da Mesa.');
    propagarEstadoMesaOnlineParaServidores();
}

function executarAcaoHeroiSelecionadoMesaRapidoJS(tipoAcao) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const parts = ESTADO_MESA_ONLINE_ATUAL.participantes || [];
    if (parts.length === 0) {
        exibirMensagemStatus('Adicione pelo menos 1 Herói na Mesa primeiro!');
        return;
    }
    const idAtivo = HEROI_SELECIONADO_GRID_MESA_ID || parts[0].idHeroi;
    try {
        const stg = document.getElementById('mesa-2d-stage-svg-box');
        if (stg && typeof stg.scrollIntoView === 'function') {
            const r = stg.getBoundingClientRect();
            if (r.top < -40 || r.bottom > window.innerHeight + 60) {
                stg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        }
    } catch(e) {}
    executarAcaoHeroiMesaOnlineJS(idAtivo, tipoAcao);
}

function alterarQuantidadeCriaturasMesaOnlineJS(novaQtd) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const qtd = Math.max(1, parseInt(novaQtd, 10) || 1);
    ESTADO_MESA_ONLINE_ATUAL.qtdCriaturasMesa = qtd;
    ESTADO_MESA_ONLINE_ATUAL.alvoFocoMesaIdx = 0;
    const am = obterAmeacaCap7PorIdOuPadrao(ESTADO_MESA_ONLINE_ATUAL.idAmeacaAtiva);
    ESTADO_MESA_ONLINE_ATUAL.listaInimigosMesa = construirListaInimigosMesaOnline(am, qtd, ESTADO_MESA_ONLINE_ATUAL.participantes);
    sincronizarAlvoFocoMesaOnline();
    registrarEventoMesaOnline('Mestre', 'ENCONTRO', `Encontro ajustado para ${qtd}x ${am.nome} (${am.tamanhoCat} ${am.espacoQ}x${am.espacoQ})!`);
    propagarEstadoMesaOnlineParaServidores();
}

function posicionarGrupoFlanqueamentoAutomaticoMesaJS() {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    sincronizarAlvoFocoMesaOnline();
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const foco = (m.listaInimigosMesa || [])[m.alvoFocoMesaIdx || 0];
    if (!foco) return;
    const q = Math.max(1, Number(foco.espacoQ || 1));
    const parts = m.participantes || [];
    if (parts[0]) { parts[0].gx = Math.max(0, foco.gx - 1); parts[0].gy = foco.gy; }
    if (parts[1]) { parts[1].gx = foco.gx + q; parts[1].gy = foco.gy; }
    if (parts[2]) { parts[2].gx = Math.max(0, foco.gx - 2); parts[2].gy = Math.max(0, foco.gy - 1); }
    if (parts[3]) { parts[3].gx = Math.max(0, foco.gx - 2); parts[3].gy = foco.gy + 1; }
    registrarEventoMesaOnline(
        'Grupo Tático',
        'FLANCO',
        `${parts[0] ? parts[0].nome : 'Herói #1'} e ${parts[1] ? parts[1].nome : 'Herói #2'} cercaram ${foco.nome} (${foco.tamanhoCat} ${q}x${q}) em lados opostos: FLANQUEAMENTO ATIVO (+2 Ataque CaC)!`
    );
    propagarEstadoMesaOnlineParaServidores();
}

function clicarCelulaGrid2DMesaOnlineJS(gx, gy) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const hClicado = (m.participantes || []).find(p => Number(p.gx) === gx && Number(p.gy) === gy);
    if (hClicado) {
        HEROI_SELECIONADO_GRID_MESA_ID = hClicado.idHeroi;
        renderizarMesaOnlineCompletaUI();
        exibirMensagemStatus(`${hClicado.nome} selecionado! Clique em qualquer quadrado livre para movê-lo.`);
        return;
    }
    const idxInim = encontrarCelulaCriaturaOcupando2D(m.listaInimigosMesa, gx, gy);
    if (idxInim >= 0) {
        selecionarAlvoFocoMesaOnlineJS(idxInim);
        return;
    }
    const parts = m.participantes || [];
    const heroiMover = parts.find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || parts[0];
    if (!heroiMover) return;
    heroiMover.gx = gx;
    heroiMover.gy = gy;
    const foco = (m.listaInimigosMesa || [])[m.alvoFocoMesaIdx || 0];
    const flanq = foco ? verificarHeroiFlanqueandoAlvoMesa(heroiMover, foco, parts) : false;
    registrarEventoMesaOnline(
        heroiMover.nome,
        'MOVIMENTO',
        `${heroiMover.nome} moveu-se para (${gx + 1}, ${gy + 1})${flanq ? ` e está FLANQUEANDO ${foco.nome} (+2 Ataque CaC)!` : '.'}`
    );
    propagarEstadoMesaOnlineParaServidores();
}

function alternarCondicaoInimigoMesaOnlineJS(chaveCond) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    sincronizarAlvoFocoMesaOnline();
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const foco = (m.listaInimigosMesa || [])[m.alvoFocoMesaIdx || 0];
    if (!foco) return;
    if (!foco.condicoes) foco.condicoes = criarCondicoesPadrao2D(false);
    foco.condicoes[chaveCond] = !foco.condicoes[chaveCond];
    sincronizarAlvoFocoMesaOnline();
    registrarEventoMesaOnline('Mestre', 'CONDICAO', `Condição "${chaveCond.toUpperCase()}" ${foco.condicoes[chaveCond] ? 'APLICADA' : 'REMOVIDA'} em ${foco.nome}!`);
    propagarEstadoMesaOnlineParaServidores();
}

function construirEstadoVisual2DParaParticipanteMesa(p) {
    const racaNome = p.raca || 'Humano';
    const classeNome = p.classeNome || String(p.classesResumo || 'Guerreiro').split(' ')[0] || 'Guerreiro';
    const armaNome = p.armaNome || (classeNome.toLowerCase().includes('arcanista') ? 'Cajado Arcano' : (classeNome.toLowerCase().includes('clérigo') ? 'Maça' : 'Espada Longa'));
    const ehTanque = (p.papel || '').toLowerCase().includes('tanque') || classeNome.toLowerCase().includes('cavaleiro');
    return {
        nome: p.nome || 'Herói', nivel: Number(p.nivel || 6), ehMembroPartyMesa: true,
        raca: { nome: racaNome }, classe: { nome: classeNome },
        arma: { nome: armaNome }, escudo: ehTanque ? { nome: 'Escudo Pesado' } : null, poderes: []
    };
}

function construirRetrato2DHeroiCardSVG(p) {
    const stFake = construirEstadoVisual2DParaParticipanteMesa(p);
    const sprite = (typeof construirSpriteSVGHeroiJRPG === 'function') ? construirSpriteSVGHeroiJRPG(stFake) : '';
    const conds = p.condicoes || {};
    const overlayC = (typeof construirOverlayCondicoes2DSVG === 'function') ? construirOverlayCondicoes2DSVG(216, 268, conds) : '';
    const transfCaido = conds.caido ? 'translate(216, 262) rotate(-75) translate(-216, -262)' : '';
    return `
        <svg viewBox="135 62 165 225" width="60" height="80" xmlns="http://www.w3.org/2000/svg" style="background:radial-gradient(circle at 50% 30%, #1E293B 0%, #090D16 85%); border-radius:8px; border:1.5px solid #D4AF37; flex-shrink:0;">
            <g transform="${transfCaido}">${sprite}</g>
            ${overlayC}
        </svg>
    `;
}

function renderizarPalcoEGrid2DMesaOnline() {
    const stageBox = document.getElementById('mesa-2d-stage-svg-box');
    const gridBox = document.getElementById('mesa-2d-grid-interactive-box');
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    sincronizarAlvoFocoMesaOnline();
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const parts = m.participantes || [];
    const inimigos = m.listaInimigosMesa || [];
    const focoIdx = Math.min(inimigos.length - 1, Math.max(0, Number(m.alvoFocoMesaIdx || 0)));
    const focoInim = inimigos[focoIdx] || inimigos[0];
    if (typeof sincronizarCameraMapa120ComUnidadesJS === 'function') {
        sincronizarCameraMapa120ComUnidadesJS(parts, inimigos, false);
    }
    const camMesa = (typeof obterCameraAtivaMapa120JS === 'function')
        ? obterCameraAtivaMapa120JS()
        : { worldCols: 120, worldRows: 120, viewCols: 12, viewRows: 7, camX: 52, camY: 56, modoSeguir: 'AUTO' };
    const cols = camMesa.viewCols;
    const rows = camMesa.viewRows;
    const modoTokensLimpos = Boolean(window.__PALCO_MODO_TOKENS_LIMPOS__);

    if (stageBox) {
        const cenario = (typeof construirCenarioFundoJRPG === 'function')
            ? construirCenarioFundoJRPG(focoInim ? focoInim.grupo_cap7 : 'Dragões') : '<rect width="860" height="308" fill="#0F172A"/>';
        const gradeChaoMesa = (typeof construirGradePerspectivaChao2DSVG === 'function')
            ? construirGradePerspectivaChao2DSVG(cols, rows) : '';

        const entidadesMesa = [];
        let pegadasMesaSVG = '';
        let yMinMesaCam = 0;

        parts.forEach((p, idx) => {
            const gxH = p.gx !== undefined ? p.gx : (idx % 3);
            const gyH = p.gy !== undefined ? p.gy : (idx % 5);
            const qH = Math.max(1, Number(p.espacoQ || 1));
            if (gxH + qH <= camMesa.camX || gxH >= camMesa.camX + cols || gyH + qH <= camMesa.camY || gyH >= camMesa.camY + rows) return;
            const catH = p.tamanhoCat || 'Médio';
            const flanqH = focoInim ? verificarHeroiFlanqueandoAlvoMesa(p, focoInim, parts) : false;
            const selH = (p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID);
            const pegH = construirPegadaIsometricaTamanhoSVG(gxH, gyH, qH, cols, rows, flanqH ? '#FACC15' : (selH ? '#4ADE80' : '#38BDF8'), selH ? 'rgba(34,197,94,0.28)' : 'rgba(56,189,248,0.18)');
            pegadasMesaSVG += pegH.svg;

            const stFake = construirEstadoVisual2DParaParticipanteMesa(p);
            const spH = (typeof construirSpriteSVGHeroiJRPG === 'function') ? construirSpriteSVGHeroiJRPG(stFake) : '';
            const cndH = p.condicoes || {};
            const ovH = (typeof construirOverlayCondicoes2DSVG === 'function') ? construirOverlayCondicoes2DSVG(216, 262, cndH) : '';
            const trCaidoH = cndH.caido ? 'translate(216, 262) rotate(-75) translate(-216, -262)' : '';
            const flipH = (focoInim && gxH > (focoInim.gx || 5) + ((focoInim.espacoQ || 1) - 1)) ? 'translate(216, 0) scale(-1, 1) translate(-216, 0)' : '';
            const escH = (typeof calcularEscalaProporcionalUnidadePalco2D === 'function')
                ? calcularEscalaProporcionalUnidadePalco2D(pegH, qH, catH, false)
                : (pegH.sc * 0.80);

            if (modoTokensLimpos) {
                const rTokH = Math.max(11, Math.round((pegH.tileW || 36) * qH * 0.34));
                entidadesMesa.push({
                    depthY: pegH.pBotY || pegH.cy,
                    svg: `
                        <g transform="translate(${pegH.cx.toFixed(1)}, ${pegH.cy.toFixed(1)})" style="cursor:pointer; ${p.pvAtual <= 0 ? 'opacity:0.35;filter:grayscale(1);' : ''}" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI_MESA', '${p.idHeroi}', 'MESA')">
                            <circle cx="0" cy="${(-rTokH * 0.4).toFixed(1)}" r="${rTokH}" fill="#0F172A" stroke="${flanqH ? '#FACC15' : (selH ? '#4ADE80' : '#38BDF8')}" stroke-width="2.4"/>
                            <svg x="${-rTokH + 2}" y="${(-rTokH * 1.4 + 2).toFixed(1)}" width="${(rTokH - 2) * 2}" height="${(rTokH - 2) * 2}" viewBox="136 92 160 160" preserveAspectRatio="xMidYMid meet">${spH}</svg>
                            <rect x="-32" y="${(-rTokH * 1.4 - 14).toFixed(1)}" width="64" height="13" rx="4" fill="rgba(9,13,22,0.92)" stroke="${selH ? '#4ADE80' : '#D4AF37'}" stroke-width="1"/>
                            <text x="0" y="${(-rTokH * 1.4 - 5).toFixed(1)}" text-anchor="middle" font-size="7.5" font-weight="900" fill="#FDE047">${p.nome.slice(0, 8)} (${gxH + 1},${gyH + 1})</text>
                        </g>
                    `
                });
            } else {
                const ayH = pegH.anchorY || pegH.cy;
                entidadesMesa.push({
                    depthY: pegH.pBotY || pegH.cy,
                    svg: `
                        <g style="cursor:pointer; ${p.pvAtual <= 0 ? 'opacity:0.35;filter:grayscale(1);' : ''}"
                           onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI_MESA', '${p.idHeroi}', 'MESA')">
                            <g transform="translate(${pegH.cx.toFixed(1)}, ${ayH.toFixed(1)}) scale(${escH.toFixed(3)}) translate(-216, -262)">
                                <g transform="${flipH} ${trCaidoH}">
                                    ${(window.__ANIMACAO_PALCO_ATIVA__ && selH) ? `<animateTransform attributeName="transform" additive="sum" type="translate" values="0,0; 52,-10; 64,0; 0,0" dur="0.72s" repeatCount="1"/>` : ""}
                                    ${spH}
                                </g>
                                ${ovH}
                            </g>
                            <g transform="translate(${(pegH.cx - 46).toFixed(1)}, ${(pegH.pBotY + 2).toFixed(1)})">
                                <rect width="92" height="14" rx="4" fill="rgba(9,13,22,0.92)" stroke="${flanqH ? '#FACC15' : (selH ? '#4ADE80' : '#D4AF37')}" stroke-width="1.3"/>
                                <text x="46" y="10" text-anchor="middle" font-size="8" font-weight="900" fill="#FDE047">${flanqH ? '' : ''}${String(p.nome || 'Herói').slice(0, 10)} (${gxH + 1},${gyH + 1})</text>
                            </g>
                        </g>
                    `
                });
            }
        });

        inimigos.forEach((cr, idxC) => {
            const gxC = cr.gx !== undefined ? cr.gx : 5;
            const gyC = cr.gy !== undefined ? cr.gy : 2;
            const tInf = extrairTamanhoEEspacoT20(cr.tamanhoCat || cr.tipoTamanho || 'Médio');
            const qC = Math.max(1, Number(cr.espacoQ || tInf.espacoQ || 1));
            // Clamping visual: só desenha unidades que interceptam o viewport atual da câmera
            if (gxC + qC <= camMesa.camX || gxC >= camMesa.camX + cols || gyC + qC <= camMesa.camY || gyC >= camMesa.camY + rows) return;
            const catC = cr.tamanhoCat || tInf.categoria || 'Médio';
            const ehFoco = (idxC === focoIdx);
            const pegC = construirPegadaIsometricaTamanhoSVG(gxC, gyC, qC, cols, rows, ehFoco ? '#FACC15' : '#EF4444', ehFoco ? 'rgba(239,68,68,0.34)' : 'rgba(153,27,27,0.22)');
            pegadasMesaSVG += pegC.svg;

            const privFake = { nomeCriatura: cr.nome.replace(/ #\d+$/, ''), grupoCap7: cr.grupo_cap7 || 'Dragões' };
            const spC = (typeof construirSpriteSVGCriaturaJRPG === 'function') ? construirSpriteSVGCriaturaJRPG(privFake) : '';
            const cndC = cr.condicoes || {};
            const ovC = (typeof construirOverlayCondicoes2DSVG === 'function') ? construirOverlayCondicoes2DSVG(645, 260, cndC) : '';
            const trCaidoC = cndC.caido ? 'translate(645, 260) rotate(76) translate(-645, -260)' : '';
            const pctC = Math.max(0, Math.min(100, Math.round((cr.pvAtual / Math.max(1, cr.pvMax)) * 100)));
            const escProporcionalC = (typeof calcularEscalaProporcionalUnidadePalco2D === 'function')
                ? calcularEscalaProporcionalUnidadePalco2D(pegC, qC, catC, true)
                : (pegC.sc * qC);
            const ayC = pegC.anchorY || pegC.cy;
            const opAntiOclusaoM = (typeof calcularOpacidadeAntiOclusaoCriatura2D === 'function')
                ? calcularOpacidadeAntiOclusaoCriatura2D({ gx: gxC, gy: gyC, espacoQ: qC }, parts)
                : 1.0;
            const layerPrioM = qC >= 2 ? 0 : 5;
            if (opAntiOclusaoM > 0) {
                const topCriaturaEst = ayC - 148 * escProporcionalC;
                if (topCriaturaEst < 14) {
                    yMinMesaCam = Math.min(yMinMesaCam, Math.floor(topCriaturaEst - 16));
                }
            }

            if (modoTokensLimpos) {
                const rTok = Math.max(17, Math.min(46, Math.round((pegC.tileW || 36) * (qC >= 6 ? 1.50 : (qC === 3 ? 1.20 : (qC === 2 ? 0.96 : 0.50))))));
                const pfM = (typeof obterPerfilVisualUnico83AmeacasCap7 === 'function')
                    ? obterPerfilVisualUnico83AmeacasCap7(cr.nome, cr.grupo_cap7)
                    : { corFundo: '#3B070B', corAnel: '#EF4444', rotuloCurto: 'AMEAÇA', viewBoxToken: '555 58 180 206' };
                entidadesMesa.push({
                    layerPriority: layerPrioM,
                    depthY: pegC.pBotY || pegC.cy,
                    svg: `
                        <g transform="translate(${pegC.cx.toFixed(1)}, ${pegC.cy.toFixed(1)})" style="cursor:pointer; ${cr.pvAtual <= 0 ? 'opacity:0.32;filter:grayscale(1);' : ''}" onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA_MESA', ${idxC}, 'MESA')">
                            ${opAntiOclusaoM > 0 ? `
                            <g opacity="${opAntiOclusaoM.toFixed(2)}">
                                <circle cx="0" cy="${(-rTok * 0.35).toFixed(1)}" r="${rTok}" fill="${pfM.corFundo}" stroke="${ehFoco ? '#FACC15' : pfM.corAnel}" stroke-width="${qC >= 2 ? 3.5 : 2.8}"/>
                                <svg x="${-rTok + 2}" y="${(-rTok * 1.35 + 2).toFixed(1)}" width="${(rTok - 2) * 2}" height="${(rTok - 2) * 2}" viewBox="555 58 180 206" preserveAspectRatio="xMidYMid meet">${spC}</svg>
                            </g>` : ''}
                            <rect x="-46" y="4" width="92" height="14" rx="4" fill="#140C1C" stroke="${ehFoco ? '#FACC15' : pfM.corAnel}" stroke-width="1.2"/>
                            <text x="0" y="13.5" text-anchor="middle" font-size="8" font-weight="900" fill="#FEF08A">${pfM.rotuloCurto} [${catC.slice(0,3).toUpperCase()} ${qC}x${qC}]</text>
                        </g>
                    `
                });
            } else {
                const yPlacaM = Math.min(298, (pegC.pBotY || pegC.cy) + 2);
                entidadesMesa.push({
                    layerPriority: layerPrioM,
                    depthY: pegC.pBotY || pegC.cy,
                    svg: `
                        <g style="cursor:pointer; ${cr.pvAtual <= 0 ? 'opacity:0.32;filter:grayscale(1);' : ''}"
                           onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA_MESA', ${idxC}, 'MESA')">
                            ${opAntiOclusaoM > 0 ? `
                            <g opacity="${opAntiOclusaoM.toFixed(2)}" transform="translate(${pegC.cx.toFixed(1)}, ${ayC.toFixed(1)}) scale(${escProporcionalC.toFixed(3)}) translate(-645, -260)">
                                <g transform="${trCaidoC}">
                                    ${(window.__ANIMACAO_PALCO_ATIVA__ && ehFoco) ? `<animateTransform attributeName="transform" additive="sum" type="translate" values="0,0; -38,6; 16,-6; 0,0" dur="0.75s" repeatCount="1"/>` : ""}
                                    ${spC}
                                </g>
                                ${ovC}
                            </g>` : ''}
                            <g transform="translate(${(pegC.cx - 76).toFixed(1)}, ${yPlacaM.toFixed(1)})">
                                <rect width="152" height="16" rx="4" fill="rgba(9,13,22,0.94)" stroke="${ehFoco ? '#FACC15' : '#EF4444'}" stroke-width="1.5"/>
                                <rect x="2" y="2" width="${Math.round(1.48 * pctC)}" height="12" rx="3" fill="${cr.pvAtual <= 0 ? '#475569' : '#DC2626'}"/>
                                <text x="76" y="11.5" text-anchor="middle" font-size="8.2" font-weight="900" fill="#FFF">${cr.rotulo} ${catC} (${qC}x${qC}) · ${Math.max(0, cr.pvAtual)}/${cr.pvMax}</text>
                            </g>
                        </g>
                    `
                });
            }
        });

        entidadesMesa.sort((a, b) => {
            const p1 = a.layerPriority !== undefined ? a.layerPriority : 10;
            const p2 = b.layerPriority !== undefined ? b.layerPriority : 10;
            if (p1 !== p2) return p1 - p2;
            return a.depthY - b.depthY;
        });
        const spritesOrdenadosMesa = entidadesMesa.map(e => e.svg).join('\n');

        let linhaFlancoMesaSVG = '';
        if (focoInim) {
            const flanqueadores = parts.filter(p => verificarHeroiFlanqueandoAlvoMesa(p, focoInim, parts));
            if (flanqueadores.length >= 2) {
                const pt1 = mapearGridParaPalco2DSVG(flanqueadores[0].gx, flanqueadores[0].gy, cols, rows);
                const pt2 = mapearGridParaPalco2DSVG(flanqueadores[1].gx, flanqueadores[1].gy, cols, rows);
                const ptF = construirPegadaIsometricaTamanhoSVG(focoInim.gx || 5, focoInim.gy || 2, focoInim.espacoQ || 1, cols, rows, '#FACC15', 'none');
                linhaFlancoMesaSVG = `
                    <line x1="${pt1.px.toFixed(1)}" y1="${(pt1.py - 10).toFixed(1)}" x2="${pt2.px.toFixed(1)}" y2="${(pt2.py - 10).toFixed(1)}" stroke="#FACC15" stroke-width="3" stroke-dasharray="9 4"/>
                    <rect x="${(ptF.cx - 95).toFixed(1)}" y="${yMinMesaCam + 14}" width="190" height="22" rx="6" fill="rgba(180,83,9,0.95)" stroke="#FEF08A" stroke-width="1.5"/>
                    <text x="${ptF.cx.toFixed(1)}" y="${yMinMesaCam + 29}" text-anchor="middle" font-size="10" font-weight="900" fill="#FEF08A">FLANQUEAMENTO ATIVO (+2 ATQ)</text>
                `;
            }
        }

        const vbHeightMesa = 318 - yMinMesaCam;
        const maxHMesa = (window.__TELA_CHEIA_COMBATE_ATIVA__ === 'MESA') ? 'calc(100vh - 190px)' : '340px';
        stageBox.innerHTML = `
            <svg viewBox="0 ${yMinMesaCam} 860 ${vbHeightMesa}" width="100%" xmlns="http://www.w3.org/2000/svg" shape-rendering="geometricPrecision" text-rendering="optimizeLegibility" preserveAspectRatio="xMidYMid meet" style="display:block; width:100%; height:auto; max-height:${maxHMesa};">
                ${yMinMesaCam < 0 ? `<rect x="0" y="${yMinMesaCam}" width="860" height="${Math.abs(yMinMesaCam) + 20}" fill="#070510"/>` : ''}
                ${cenario}
                ${gradeChaoMesa}
                ${pegadasMesaSVG}
                ${typeof construirTrilhaMovimentoAtivaSVG === "function" ? construirTrilhaMovimentoAtivaSVG(cols, rows, "MESA") : ""}
                ${linhaFlancoMesaSVG}
                ${spritesOrdenadosMesa}
                ${typeof construirCamadaAnimacaoTrajetoria2DSVG === 'function' ? construirCamadaAnimacaoTrajetoria2DSVG(cols, rows) : ''}
            </svg>
        `;
    }

    if (gridBox) {
        if (!HEROI_SELECIONADO_GRID_MESA_ID && parts[0]) HEROI_SELECIONADO_GRID_MESA_ID = parts[0].idHeroi;
        const modoOclusaoMesaGrid = window.__MODO_OCLUSAO_AMEACA__ || 'AUTO_ANTI_OCLUSAO';
        let celulasHTML = '';
        for (let ly = 0; ly < rows; ly++) {
            for (let lx = 0; lx < cols; lx++) {
                const gx = camMesa.camX + lx;
                const gy = camMesa.camY + ly;
                const hCell = parts.find(p => Number(p.gx) === gx && Number(p.gy) === gy);
                const idxInim = encontrarCelulaCriaturaOcupando2D(inimigos, gx, gy);
                const iCell = idxInim >= 0 ? inimigos[idxInim] : null;
                const visAncoraX = iCell ? Math.max(camMesa.camX, Number(iCell.gx)) : -1;
                const visAncoraY = iCell ? Math.max(camMesa.camY, Number(iCell.gy)) : -1;
                const ehAncoraI = iCell && (gx === visAncoraX && gy === visAncoraY);

                let bg = ((gx + gy) % 2 === 0) ? '#151C2C' : '#0F1522';
                let borda = 'rgba(148,163,184,0.22)';
                let inner = `<span style="font-size:8px;color:#475569;">${gx + 1},${gy + 1}</span>`;
                const spanStyle = `grid-column:${lx + 1}; grid-row:${ly + 1}; height:52px; min-width:50px; position:relative;`;

                // Heróis SEMPRE têm prioridade visual sobre a célula para jamais ficarem escondidos por criaturas colossais!
                if (hCell) {
                    const selH = (hCell.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID);
                    const flq = focoInim ? verificarHeroiFlanqueandoAlvoMesa(hCell, focoInim, parts) : false;
                    bg = selH ? 'rgba(22,163,74,0.42)' : 'rgba(2,132,199,0.32)';
                    borda = flq ? '#FACC15' : (selH ? '#4ADE80' : '#38BDF8');
                    const stFakeCell = construirEstadoVisual2DParaParticipanteMesa(hCell);
                    const badgeFlq = flq ? '' : (hCell.provocando ? '' : '');
                    inner = (typeof construirToken2DHeroiGridHTML === 'function')
                        ? construirToken2DHeroiGridHTML(stFakeCell, borda, 42, badgeFlq, Math.round((Number(hCell.pvAtual || 0) / Math.max(1, Number(hCell.pvMax || 1))) * 100))
                        : '';
                } else if (iCell) {
                    const ehFoco = (idxInim === focoIdx);
                    const qC = Math.max(1, Number(iCell.espacoQ || 1));
                    bg = ehFoco ? 'rgba(220,38,38,0.36)' : 'rgba(127,29,29,0.24)';
                    borda = ehFoco ? '#FACC15' : '#EF4444';
                    if (ehAncoraI && modoOclusaoMesaGrid !== 'OCULTAR_TOKEN') {
                        const cnd = iCell.condicoes || {};
                        const bCond = (cnd.caido ? '' : '') + (cnd.emChamas ? '' : '') + (cnd.sangrando ? '' : '') + (cnd.desprevenido ? '' : '') + (cnd.envenenado ? '' : '') + (cnd.lento ? '' : '');
                        const tokSize = qC >= 6 ? 54 : (qC >= 3 ? 50 : (qC === 2 ? 46 : 40));
                        const opTok = modoOclusaoMesaGrid === 'FANTASMA_RAIO_X' ? 'opacity:0.42;' : '';
                        inner = (typeof construirToken2DCriaturaGridHTML === 'function')
                            ? `<div style="${opTok}z-index:3;">${construirToken2DCriaturaGridHTML(iCell, borda, tokSize, bCond)}</div>`
                            : '';
                    } else {
                        inner = `<div style="display:flex;flex-direction:column;align-items:center;line-height:1.1;"><span style="font-size:8.5px;font-weight:900;color:#FCA5A5;">${iCell.rotulo}</span><span style="font-size:7.5px;color:#FDE047;">${qC}×${qC} (${gx+1},${gy+1})</span></div>`;
                    }
                }

                celulasHTML += `
                    <div onclick="clicarCelulaGrid2DMesaOnlineJS(${gx}, ${gy})"
                         style="${spanStyle} background:${bg}; border:${iCell ? '2px' : '1.5px'} solid ${borda}; border-radius:7px; display:flex; align-items:center; justify-content:center; cursor:pointer; user-select:none;"
                         title="Célula (${gx + 1},${gy + 1}) do Mapa 120×120${iCell ? ` — ${iCell.nome} (${iCell.tamanhoCat} ${iCell.espacoQ}x${iCell.espacoQ})` : ''}">
                        ${inner}
                    </div>
                `;
            }
        }

        const listaCat = obterCatalogoAmeacasCap7Mesa();
        const optsAddMesa = listaCat.map(c => {
            const tInfo = calcularTamanhoCriaturaObj(c.tipo_nivel_tamanho || 'Médio');
            return `<option value="${c.id_ameaca}">[ND ${c.nd}] ${c.nome} (${tInfo.categoria} ${tInfo.espacoQ}x${tInfo.espacoQ} • ${c.pv} PV)</option>`;
        }).join('');

        const listaBadgesInim = inimigos.length === 0
            ? `<span style="font-size:11px;color:#94A3B8;font-style:italic;">Nenhuma ameaça no tabuleiro — use Adicionar para incluir criaturas.</span>`
            : inimigos.map((cr, idx) => {
                const ativo = idx === focoIdx;
                const qC = Math.max(1, Number(cr.espacoQ || 1));
                return `
                    <div style="display:inline-flex; align-items:center; gap:5px; padding:3px 8px; border-radius:8px; background:${ativo ? '#7F1D1D' : '#0F172A'}; border:1.5px solid ${ativo ? '#FACC15' : '#475569'};">
                        <button type="button" onclick="selecionarAlvoFocoMesaOnlineJS(${idx})" style="background:none;border:none;color:#FEF08A;font-size:10.5px;font-weight:800;cursor:pointer;padding:0;">
                            ${ativo ? '' : ''}${cr.nome} [${cr.tamanhoCat || 'Médio'} ${qC}x${qC} • ${cr.pvAtual}/${cr.pvMax}]
                        </button>
                        <button type="button" onclick="removerCriaturaDoEncontroMesaOnlineJS(${idx})" style="background:rgba(127,29,29,0.85);border:1px solid #FCA5A5;border-radius:4px;color:#FEF08A;cursor:pointer;font-size:10px;font-weight:800;padding:1px 5px;" title="Excluir esta ameaça do tabuleiro">Excluir</button>
                    </div>
                `;
            }).join('');

        const dockMesa = document.getElementById('mesa-stage-quick-actions-dock');
        if (dockMesa) {
            const heroiAtivoObj = parts.find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || parts[0];
            const nomeHeroiAtivo = heroiAtivoObj ? heroiAtivoObj.nome : 'Herói';
            const abaMesaAtiva = window.__ABA_HUD_DINAMICO_MESA__ || 'ABA_MESA_ACOES';
            const telaCheiaMesaOn = (window.__TELA_CHEIA_COMBATE_ATIVA__ === 'MESA');
            dockMesa.innerHTML = `
                <div class="t20-dynamic-hud-shell" style="background:linear-gradient(180deg, rgba(15,23,42,0.97), rgba(9,13,22,0.99)); border:2px solid #D4AF37; border-radius:10px; padding:8px 10px; margin-bottom:8px; box-shadow:0 6px 18px rgba(0,0,0,0.65);">
                    <div class="t20-hud-tabs-bar" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:5px; padding-bottom:6px; border-bottom:1px solid rgba(212,175,55,0.3);">
                        <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center;">
                            <button type="button" class="t20-hud-tab-btn ${abaMesaAtiva === 'ABA_MESA_ACOES' ? 'active-hud-tab' : ''}" onclick="alternarAbaHudDinamicoMesaJS('ABA_MESA_ACOES')">Ações (${nomeHeroiAtivo.slice(0, 10)})</button>
                            <button type="button" class="t20-hud-tab-btn ${abaMesaAtiva === 'ABA_MESA_AMEACAS' ? 'active-hud-tab' : ''}" onclick="alternarAbaHudDinamicoMesaJS('ABA_MESA_AMEACAS')">Ameaças (${inimigos.length}) &amp; Chefe</button>
                            <button type="button" class="t20-hud-tab-btn ${abaMesaAtiva === 'ABA_OCULTA' ? 'active-hud-tab' : ''}" onclick="alternarAbaHudDinamicoMesaJS('ABA_OCULTA')">▾ ${abaMesaAtiva === 'ABA_OCULTA' ? 'Expandir HUD' : 'Ocultar Gaveta'}</button>
                        </div>
                        <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center;">
                            <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="moverCameraMapa120JS(-5, 0)">⬅</button>
                            <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="moverCameraMapa120JS(0, -4)">⬆</button>
                            <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="moverCameraMapa120JS(0, 4)">⬇</button>
                            <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="moverCameraMapa120JS(5, 0)"></button>
                            <button type="button" class="btn-roll-inline" style="background:#B45309;color:#FEF08A;" onclick="centralizarCameraMapa120JS('AUTO')">120×120</button>
                            <button type="button" id="btn-mesa-oclusao-ameaca" class="btn-roll-inline" style="background:#7C2D12;border-color:#FACC15;color:#FEF08A;font-weight:900;padding:4px 9px;" onclick="alternarModoOclusaoAmeacaGiganteJS()" title="Alterna entre Anti-Oclusão Automática, Token Fantasma (35%) e Ocultar Token da Ameaça na Mesa Online!">
                                ${typeof obterRotuloBotaoOclusaoAmeacaJS === 'function' ? obterRotuloBotaoOclusaoAmeacaJS() : 'Ameaça: Anti-Oclusão Auto'}
                            </button>
                            <button type="button" class="btn-roll-inline" style="background:#0284C7;border-color:#38BDF8;padding:4px 8px;" onclick="alternarModoVisibilidadePalco2DJS()">Sprites/Tokens</button>
                            <button type="button" class="btn-roll-inline" style="background:#334155;border-color:#94A3B8;color:#F8FAFC;padding:4px 9px;" onclick="avancarProximoTurnoMesaOnlineJS()">⏭Próx. Turno</button>
                            <button type="button" id="btn-mesa-fullscreen-toggle" class="btn-roll-inline" style="background:${telaCheiaMesaOn ? '#991B1B' : 'linear-gradient(135deg, #059669, #047857)'};border-color:#FACC15;color:#FEF08A;font-weight:900;padding:4px 10px;" onclick="alternarTelaCheiaCombateT20JS('MESA')">
                                ${telaCheiaMesaOn ? 'Sair da Tela Cheia (Esc)' : 'Tela Cheia'}
                            </button>
                        </div>
                    </div>
                    ${abaMesaAtiva === 'ABA_OCULTA' ? '' : (abaMesaAtiva === 'ABA_MESA_AMEACAS' ? `
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; padding-top:6px;">
                            <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center;">
                                <span style="font-size:11px; color:#FCA5A5; font-weight:900;">Alvos (${inimigos.length}):</span>
                                ${listaBadgesInim}
                            </div>
                            <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center;">
                                <button type="button" class="btn-roll-inline" style="background:#7F1D1D;border-color:#F87171;color:#FECACA;padding:4px 9px;" onclick="executarTurnoDoChefeMesaOnlineJS('FOCO_TANQUE')">Golpe do Chefe</button>
                                <button type="button" class="btn-roll-inline" style="background:#9A3412;border-color:#FB923C;color:#FFEDD5;padding:4px 9px;" onclick="executarTurnoDoChefeMesaOnlineJS('AREA_GRUPO')">Sopro / Área</button>
                                <button type="button" class="btn-roll-inline" style="background:#991B1B;border-color:#FCA5A5;color:#FEF08A;font-weight:800;padding:4px 9px;" onclick="removerCriaturaDoEncontroMesaOnlineJS(${focoIdx})">Excluir Foco</button>
                                ${inimigos.length > 1 ? `<button type="button" class="btn-roll-inline" style="background:#450A0A;border-color:#F87171;color:#FCA5A5;padding:4px 8px;" onclick="limparTodasAmeacasMesaOnlineJS()">Limpar Todas</button>` : ''}
                            </div>
                        </div>
                    ` : `
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; padding-top:6px;">
                            <div style="display:flex; gap:4px; flex-wrap:wrap; align-items:center;">
                                ${parts.map(p => `<button type="button" class="btn-roll-inline" style="padding:3px 8px; background:${p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID ? '#15803D' : '#1E293B'}; border-color:${p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID ? '#4ADE80' : '#475569'};" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI_MESA', '${p.idHeroi}', 'MESA')">${p.nome.slice(0, 10)}</button>`).join('')}
                            </div>
                            <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center;">
                                <button type="button" class="btn-roll-inline" style="background:#B91C1C;border-color:#FACC15;color:#FEF08A;font-weight:900;padding:5px 10px;" onclick="executarAcaoHeroiSelecionadoMesaRapidoJS('ATAQUE')">Atacar Alvo</button>
                                <button type="button" class="btn-roll-inline" style="background:#6D28D9;border-color:#C084FC;color:#F3E8FF;font-weight:900;padding:5px 10px;" onclick="executarAcaoHeroiSelecionadoMesaRapidoJS('MAGIA_OFENSIVA')">Magia / Hab.</button>
                                <button type="button" class="btn-roll-inline" style="background:#B45309;border-color:#FDE047;color:#FEF08A;padding:5px 9px;" onclick="executarAcaoHeroiSelecionadoMesaRapidoJS('BUFF_GRUPO')">Buff Grupo</button>
                                <button type="button" class="btn-roll-inline" style="background:#047857;border-color:#34D399;color:#ECFDF5;padding:5px 9px;" onclick="executarAcaoHeroiSelecionadoMesaRapidoJS('CURAR_ALIADO')">Curar</button>
                                <button type="button" class="btn-roll-inline" style="background:#1D4ED8;border-color:#60A5FA;color:#EFF6FF;padding:5px 9px;" onclick="executarAcaoHeroiSelecionadoMesaRapidoJS('PROVOCAR_TANQUE')">Provocar</button>
                                <button type="button" class="btn-roll-inline" style="background:#0F172A;border-color:#FACC15;color:#FDE047;padding:5px 9px;" onclick="posicionarGrupoFlanqueamentoAutomaticoMesaJS()">Flanquear (+2)</button>
                                <button type="button" class="btn-roll-inline" style="background:#7F1D1D;border-color:#F87171;color:#FECACA;padding:5px 9px;" onclick="executarTurnoDoChefeMesaOnlineJS('FOCO_TANQUE')">Turno Chefe</button>
                            </div>
                        </div>
                    `)}
                </div>
            `;
        }
        const cndFoco = (focoInim && focoInim.condicoes) ? focoInim.condicoes : {};
        const btnCondMesa = (k, lbl) => `<button type="button" class="btn-roll-inline" style="background:${cndFoco[k] ? '#B91C1C' : '#1E293B'};" onclick="alternarCondicaoInimigoMesaOnlineJS('${k}')">${lbl} ${cndFoco[k] ? '' : ''}</button>`;

        gridBox.innerHTML = `


            <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center; margin-bottom:8px;">
                <span style="font-size:11px; color:#FCA5A5; font-weight:800;">Ameaças (${inimigos.length}):</span>
                ${listaBadgesInim}
            </div>

            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; margin-bottom:6px;">
                <div style="font-size:11px; color:#FDE047; font-weight:800;">
                    Mover no Grid (${cols}x${rows}):
                    ${parts.map(p => `<button type="button" class="btn-roll-inline" style="margin-left:3px; background:${p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID ? '#15803D' : '#1E293B'};" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI_MESA', '${p.idHeroi}', 'MESA')">${p.nome.slice(0, 11)}</button>`).join('')}
                </div>
                <div style="display:flex; gap:4px; flex-wrap:wrap;">
                    ${btnCondMesa('caido', 'Caído')}
                    ${btnCondMesa('emChamas', 'Chamas')}
                    ${btnCondMesa('sangrando', 'Sangrando')}
                    ${btnCondMesa('desprevenido', 'Desprev')}
                    ${btnCondMesa('envenenado', 'Veneno')}
                    ${btnCondMesa('lento', 'Lento')}
                </div>
            </div>
            <div style="overflow-x:auto;">
                <div style="display:grid; grid-template-columns:repeat(${cols}, minmax(40px, 1fr)); gap:4px; background:#070A12; padding:6px; border-radius:8px; border:1px solid #334155;">
                    ${celulasHTML}
                </div>
            </div>
        `;
    }
}

function recalcularOrdemIniciativaMesa() {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    sincronizarAlvoFocoMesaOnline();
    const fila = [];
    (ESTADO_MESA_ONLINE_ATUAL.participantes || []).forEach(p => {
        fila.push({ tipo: 'HEROI', id: p.idHeroi, nome: p.nome, papel: p.papel, iniciativa: Number(p.iniciativaRolada || 12), pvAtual: Number(p.pvAtual || 0), pvMax: Number(p.pvMax || 1) });
    });
    if (ESTADO_MESA_ONLINE_ATUAL.chefeAtivo) {
        const b = ESTADO_MESA_ONLINE_ATUAL.chefeAtivo;
        fila.push({ tipo: 'CHEFE', id: 'BOSS_ATIVO', nome: `${b.nome} (ND ${b.nd})`, papel: b.papel || 'Chefe Solo', iniciativa: Number(b.iniciativaRolada || 18), pvAtual: Number(b.pvAtual || 0), pvMax: Number(b.pvMax || 1) });
    }
    fila.sort((a, b) => b.iniciativa - a.iniciativa);
    ESTADO_MESA_ONLINE_ATUAL.ordemIniciativa = fila;
    if (ESTADO_MESA_ONLINE_ATUAL.turnoIndice >= fila.length) ESTADO_MESA_ONLINE_ATUAL.turnoIndice = 0;
}

function propagarEstadoMesaOnlineParaServidores() {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const codEl = document.getElementById('mesa-input-codigo');
    const nomeEl = document.getElementById('mesa-input-nome');
    const mestreEl = document.getElementById('mesa-input-mestre');
    if (codEl && codEl.value) ESTADO_MESA_ONLINE_ATUAL.codigoSala = String(codEl.value).trim().toUpperCase();
    if (nomeEl && nomeEl.value) ESTADO_MESA_ONLINE_ATUAL.nomeMesa = String(nomeEl.value).trim();
    if (mestreEl && mestreEl.value) ESTADO_MESA_ONLINE_ATUAL.mestreNome = String(mestreEl.value).trim();

    recalcularOrdemIniciativaMesa();
    salvarMesaLocalStorage(ESTADO_MESA_ONLINE_ATUAL);
    if (CANAL_BROADCAST_MESA) { try { CANAL_BROADCAST_MESA.postMessage(ESTADO_MESA_ONLINE_ATUAL); } catch (e) {} }

    const info = detectarModoTransporteMesaOnline();
    if (info.modo === 'APPS_SCRIPT') {
        try {
            google.script.run.withSuccessHandler(res => {
                if (res && res.ok && res.mesa) { ESTADO_MESA_ONLINE_ATUAL = res.mesa; renderizarMesaOnlineCompletaUI(); }
            }).salvarOuSincronizarMesaNaPlanilha(ESTADO_MESA_ONLINE_ATUAL);
        } catch (e) {}
    } else if (info.modo === 'REST_SQL') {
        fetch('/api/mesas', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(ESTADO_MESA_ONLINE_ATUAL) })
            .then(r => r.json()).then(d => {
                if (d && d.ok && d.mesa) { ESTADO_MESA_ONLINE_ATUAL = d.mesa; salvarMesaLocalStorage(ESTADO_MESA_ONLINE_ATUAL); renderizarMesaOnlineCompletaUI(); }
            }).catch(() => {});
    }
    renderizarMesaOnlineCompletaUI();
}

var ULTIMO_HASH_MESA_RENDERIZADO = '';
function usuarioInteragindoComFormularioMesa() {
    const act = document.activeElement;
    if (!act) return false;
    const tag = (act.tagName || '').toUpperCase();
    return (tag === 'SELECT' || tag === 'INPUT' || tag === 'TEXTAREA');
}

function sincronizarMesaOnlineManualJS(silencioso) {
    if (silencioso && usuarioInteragindoComFormularioMesa()) {
        return; // Nunca fecha <select> aberto nem interrompe digitação!
    }
    const codEl = document.getElementById('mesa-input-codigo');
    const codigo = codEl ? String(codEl.value || 'VALKARIA-2026').trim().toUpperCase() : 'VALKARIA-2026';
    const info = detectarModoTransporteMesaOnline();

    if (info.modo === 'APPS_SCRIPT') {
        google.script.run.withSuccessHandler(res => {
            if (res && res.ok && res.mesa && Array.isArray(res.mesa.participantes) && res.mesa.participantes.length > 0) {
                ESTADO_MESA_ONLINE_ATUAL = res.mesa; salvarMesaLocalStorage(ESTADO_MESA_ONLINE_ATUAL); renderizarMesaOnlineCompletaUI();
                if (!silencioso) exibirMensagemStatus(`Sala ${codigo} sincronizada!`);
            } else if (ESTADO_MESA_ONLINE_ATUAL) propagarEstadoMesaOnlineParaServidores();
        }).carregarMesaDaPlanilha(codigo);
    } else if (info.modo === 'REST_SQL') {
        fetch('/api/mesas?codigo=' + encodeURIComponent(codigo)).then(r => r.json()).then(d => {
            if (d && d.ok && d.mesa && Array.isArray(d.mesa.participantes) && d.mesa.participantes.length > 0) {
                ESTADO_MESA_ONLINE_ATUAL = d.mesa; salvarMesaLocalStorage(ESTADO_MESA_ONLINE_ATUAL); renderizarMesaOnlineCompletaUI();
                if (!silencioso) exibirMensagemStatus(`Sala ${codigo} sincronizada!`);
            } else if (ESTADO_MESA_ONLINE_ATUAL) propagarEstadoMesaOnlineParaServidores();
        }).catch(() => {});
    } else {
        const local = carregarMesaLocalStorage(codigo);
        if (local && Array.isArray(local.participantes) && local.participantes.length > 0) {
            const novoHash = JSON.stringify(local.atualizadoEm || '') + '_' + (local.historicoEventos ? local.historicoEventos.length : 0);
            if (silencioso && novoHash === ULTIMO_HASH_MESA_RENDERIZADO) return;
            ESTADO_MESA_ONLINE_ATUAL = local;
            ULTIMO_HASH_MESA_RENDERIZADO = novoHash;
        } else if (silencioso) {
            return;
        }
        renderizarMesaOnlineCompletaUI();
        if (!silencioso) exibirMensagemStatus(`Sala ${codigo} sincronizada localmente!`);
    }
}

function alternarAutoPollingMesaOnlineJS(ativo) {
    if (TIMER_POLLING_MESA_ONLINE) { clearInterval(TIMER_POLLING_MESA_ONLINE); TIMER_POLLING_MESA_ONLINE = null; }
    if (ativo) {
        TIMER_POLLING_MESA_ONLINE = setInterval(function() {
            const sec = document.getElementById('tab-mesa-online');
            if (sec && sec.classList.contains('active')) sincronizarMesaOnlineManualJS(true);
        }, 3000);
    }
}

function popularSelectChefesMesaOnline() {
    const sel = document.getElementById('mesa-select-chefe');
    if (!sel) return;
    const lista = obterCatalogoAmeacasCap7Mesa();
    if (sel.options.length > 1 && lista.length > 0) return;
    sel.innerHTML = '';
    lista.forEach(c => {
        const am = normalizarAmeacaParaMesa(c);
        const opt = document.createElement('option');
        opt.value = am.id;
        opt.textContent = `[ND ${am.nd}] ${am.nome} (${am.tamanhoCat} ${am.espacoQ}x${am.espacoQ} • ${am.pv} PV)`;
        sel.appendChild(opt);
    });
    if (ESTADO_MESA_ONLINE_ATUAL && ESTADO_MESA_ONLINE_ATUAL.idAmeacaAtiva) sel.value = ESTADO_MESA_ONLINE_ATUAL.idAmeacaAtiva;
}

function inicializarAbaMesaOnlineUI() {
    try {
        inicializarCanalBroadcastMesa();
        const badge = document.getElementById('mesa-online-badge-conexao');
        if (badge) badge.textContent = detectarModoTransporteMesaOnline().rotulo;
        const codEl = document.getElementById('mesa-input-codigo');
        const codigo = codEl ? String(codEl.value || 'VALKARIA-2026').trim().toUpperCase() : 'VALKARIA-2026';

        if (!ESTADO_MESA_ONLINE_ATUAL || !Array.isArray(ESTADO_MESA_ONLINE_ATUAL.participantes) || ESTADO_MESA_ONLINE_ATUAL.participantes.length === 0) {
            const salvo = carregarMesaLocalStorage(codigo);
            ESTADO_MESA_ONLINE_ATUAL = (salvo && Array.isArray(salvo.participantes) && salvo.participantes.length > 0)
                ? salvo : criarEstadoInicialMesaOnline(codigo);
        }
        popularSelectChefesMesaOnline();
        popularSelectsEstaticosCriaturasJS();
        renderizarMesaOnlineCompletaUI();
        sincronizarMesaOnlineManualJS(true);
        const chk = document.getElementById('mesa-chk-autopolling');
        if (!chk || chk.checked) alternarAutoPollingMesaOnlineJS(true);
    } catch (err) {
        console.error('Erro ao inicializar Mesa Online:', err);
    }
}

function entrarNaMesaComFichaAtualJS(silencioso) {
    if (!ESTADO_MESA_ONLINE_ATUAL) ESTADO_MESA_ONLINE_ATUAL = criarEstadoInicialMesaOnline('VALKARIA-2026');
    const novoP = extrairParticipanteDaFichaAtual();
    const lista = ESTADO_MESA_ONLINE_ATUAL.participantes || [];
    const idx = lista.findIndex(x => x.idHeroi === novoP.idHeroi || x.nome === novoP.nome);
    if (idx >= 0) {
        novoP.gx = lista[idx].gx !== undefined ? lista[idx].gx : 3;
        novoP.gy = lista[idx].gy !== undefined ? lista[idx].gy : 2;
        lista[idx] = novoP;
    } else {
        lista.unshift(novoP);
    }
    ESTADO_MESA_ONLINE_ATUAL.participantes = lista;
    registrarEventoMesaOnline(novoP.nome, 'ENTRADA', `${novoP.nome} entrou na Mesa Online!`);
    propagarEstadoMesaOnlineParaServidores();
    if (!silencioso) exibirMensagemStatus(`${novoP.nome} atualizado na sala!`);
}

function gerarGrupoEquilibrado4HeroisMesaJS() {
    if (!ESTADO_MESA_ONLINE_ATUAL) ESTADO_MESA_ONLINE_ATUAL = criarEstadoInicialMesaOnline('VALKARIA-2026');
    const heroiPrincipal = extrairParticipanteDaFichaAtual();
    const grupo = construirGrupo4HeroisPadrao(heroiPrincipal);
    ESTADO_MESA_ONLINE_ATUAL.participantes = grupo;
    ESTADO_MESA_ONLINE_ATUAL.chefeAtivo.alvoProvocadoId = 'ALLY_TANQUE_BASTIAO';
    registrarEventoMesaOnline('Mestre', 'PARTY', `Party de 4 Heróis formada no Grid!`);
    recomendarChefeIdealGrupoMesaJS(true);
    propagarEstadoMesaOnlineParaServidores();
    exibirMensagemStatus(`Party de 4 Heróis (Nv. ${heroiPrincipal.nivel}) montada!`);
}

function trocarChefeMesaOnlineJS(idAmeaca) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const am = obterAmeacaCap7PorIdOuPadrao(idAmeaca);
    const qtd = Number(ESTADO_MESA_ONLINE_ATUAL.qtdCriaturasMesa || 1);
    const lista = construirListaInimigosMesaOnline(am, qtd, ESTADO_MESA_ONLINE_ATUAL.participantes);
    ESTADO_MESA_ONLINE_ATUAL.idAmeacaAtiva = am.id;
    ESTADO_MESA_ONLINE_ATUAL.alvoFocoMesaIdx = 0;
    ESTADO_MESA_ONLINE_ATUAL.rodadaAtual = 1;
    ESTADO_MESA_ONLINE_ATUAL.turnoIndice = 0;
    ESTADO_MESA_ONLINE_ATUAL.listaInimigosMesa = lista;
    ESTADO_MESA_ONLINE_ATUAL.chefeAtivo = Object.assign({
        iniciativaRolada: (Math.floor(Math.random() * 20) + 1) + Math.floor((Number(am.nd_num) || 5) * 1.2),
        alvoProvocadoId: 'ALLY_TANQUE_BASTIAO', penalidadeAtaque: 0, penalidadeDefesa: 0
    }, lista[0]);
    registrarEventoMesaOnline('Mestre', 'CHEFE', `Encontro atualizado: ${qtd}x ${am.nome} (${am.tamanhoCat} ${am.espacoQ}x${am.espacoQ} • ND ${am.nd})!`);
    propagarEstadoMesaOnlineParaServidores();
}

function recomendarChefeIdealGrupoMesaJS(silencioso) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const parts = ESTADO_MESA_ONLINE_ATUAL.participantes || [];
    const nvMedio = parts.length > 0 ? Math.round(parts.reduce((acc, p) => acc + Number(p.nivel || 1), 0) / parts.length) : 6;
    const lista = obterCatalogoAmeacasCap7Mesa();
    if (lista.length === 0) return;
    let melhor = lista[0], menorDiff = 999;
    lista.forEach(c => {
        const diff = Math.abs(Number(c.nd_numerico || 1) - nvMedio);
        if (diff < menorDiff || (diff === menorDiff && c.papel === 'Solo')) { menorDiff = diff; melhor = c; }
    });
    const am = normalizarAmeacaParaMesa(melhor);
    const sel = document.getElementById('mesa-select-chefe');
    if (sel) sel.value = am.id;
    trocarChefeMesaOnlineJS(am.id);
    if (!silencioso) exibirMensagemStatus(`Ameaça Recomendada: ${am.nome} (ND ${am.nd})!`);
}

function reiniciarCombateGrupoMesaOnlineJS() {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    ESTADO_MESA_ONLINE_ATUAL.rodadaAtual = 1;
    ESTADO_MESA_ONLINE_ATUAL.turnoIndice = 0;
    ESTADO_MESA_ONLINE_ATUAL.buffsGrupo = { oracaoBonus: 0, inspiracaoBonus: 0, bencaoBonus: 0, escudoDaFeDefesa: 0 };
    (ESTADO_MESA_ONLINE_ATUAL.participantes || []).forEach(p => {
        p.pvAtual = p.pvMax; p.pmAtual = p.pmMax; p.defesaPosturaBonus = 0; p.provocando = false;
        p.condicoes = criarCondicoesPadrao2D(false);
        p.iniciativaRolada = (Math.floor(Math.random() * 20) + 1) + Number(p.iniciativaBonus || 4);
    });
    (ESTADO_MESA_ONLINE_ATUAL.listaInimigosMesa || []).forEach(cr => {
        cr.pvAtual = cr.pvMax;
        cr.condicoes = criarCondicoesPadrao2D(false);
    });
    sincronizarAlvoFocoMesaOnline();
    registrarEventoMesaOnline('Mestre', 'RESET', `Combate reiniciado!`);
    propagarEstadoMesaOnlineParaServidores();
}

function obterSomaBuffsAtaqueDanoGrupo() {
    if (!ESTADO_MESA_ONLINE_ATUAL || !ESTADO_MESA_ONLINE_ATUAL.buffsGrupo) return 0;
    const b = ESTADO_MESA_ONLINE_ATUAL.buffsGrupo;
    return Number(b.oracaoBonus || 0) + Number(b.inspiracaoBonus || 0) + Number(b.bencaoBonus || 0);
}

function executarAcaoHeroiMesaOnlineJS(idHeroi, tipoAcao) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    sincronizarAlvoFocoMesaOnline();
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const p = (m.participantes || []).find(x => x.idHeroi === idHeroi);
    const inimigos = m.listaInimigosMesa || [];
    const focoIdx = Math.min(inimigos.length - 1, Math.max(0, Number(m.alvoFocoMesaIdx || 0)));
    const boss = inimigos[focoIdx] || m.chefeAtivo;
    if (!p || !boss) return;
    if (p.pvAtual <= 0) { exibirMensagemStatus(`${p.nome} está caído (0 PV)!`); return; }

    const bonusGrupo = obterSomaBuffsAtaqueDanoGrupo();
    const flanqueando = verificarHeroiFlanqueandoAlvoMesa(p, boss, m.participantes || []);
    const bonusFlanco = flanqueando ? 2 : 0;
    const condBoss = boss.condicoes || {};
    const penDefCond = (condBoss.caido ? 5 : 0) + (condBoss.desprevenido || condBoss.atordoado ? 5 : 0) + (condBoss.lento ? 2 : 0);
    const defEfetivaBoss = Math.max(10, Number(boss.defesa || 25) - Number(m.chefeAtivo.penalidadeDefesa || 0) - penDefCond);

    if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function') {
        dispararAnimacaoCoreografadaPalco2DJS({
            tipo: tipoAcao === 'MAGIA_OFENSIVA' ? 'MAGIA_FOGO' : (tipoAcao === 'CURAR_ALIADO' || tipoAcao === 'BUFF_GRUPO' ? 'CURA_BUFF' : 'CORTE'),
            origem: { gx: p.gx || 2, gy: p.gy || 2 },
            destino: (tipoAcao === 'CURAR_ALIADO' || tipoAcao === 'BUFF_GRUPO') ? { gx: p.gx || 2, gy: p.gy || 2 } : { gx: boss.gx || 5, gy: boss.gy || 2 },
            label: `${p.nome}: ${tipoAcao}`
        });
    }
    if (tipoAcao === 'ATAQUE') {
        const d1 = Math.floor(Math.random() * 20) + 1;
        const d2 = Math.floor(Math.random() * 20) + 1;
        const d20 = Math.max(d1, d2);
        const totalAtq = d20 + Number(p.ataqueBonus || 8) + bonusGrupo + bonusFlanco;
        const critico = d20 >= 19;
        if (critico || (d20 !== 1 && totalAtq >= defEfetivaBoss)) {
            const danoFurt = (flanqueando && String(p.classesResumo || '').toLowerCase().includes('ladino')) ? 7 : 0;
            const danoTotal = Math.max(4, (Number(p.danoMedio || 15) * (critico ? 2 : 1)) + bonusGrupo + danoFurt + (Math.floor(Math.random() * 7) - 3));
            boss.pvAtual = Math.max(0, Number(boss.pvAtual || 0) - danoTotal);
            registrarEventoMesaOnline(p.nome, 'ATAQUE', `${p.nome} atacou ${boss.nome}${flanqueando ? ' [FLANCO +2]' : ''}: ${totalAtq} vs Def ${defEfetivaBoss} → -${danoTotal} PV (${boss.pvAtual}/${boss.pvMax}).`);
        } else {
            registrarEventoMesaOnline(p.nome, 'ERRO', `${p.nome} rolou ${totalAtq} vs Def ${defEfetivaBoss} e errou ${boss.nome}.`);
        }
    } else if (tipoAcao === 'BUFF_GRUPO') {
        if (p.pmAtual < 2) { exibirMensagemStatus('PM insuficientes!'); return; }
        p.pmAtual -= 2;
        const esc = Math.min(5, 2 + Math.floor(Number(p.nivel || 1) / 5));
        m.buffsGrupo.oracaoBonus = esc;
        m.chefeAtivo.penalidadeAtaque = esc;
        m.chefeAtivo.penalidadeDefesa = esc;
        registrarEventoMesaOnline(p.nome, 'BUFF', `${p.nome} canalizou Oração & Inspiração (+${esc} para todo o grupo)!`);
    } else if (tipoAcao === 'PROVOCAR_TANQUE') {
        if (p.pmAtual >= 2) p.pmAtual -= 2;
        (m.participantes || []).forEach(ally => { ally.provocando = false; });
        p.provocando = true; p.defesaPosturaBonus = 4; m.chefeAtivo.alvoProvocadoId = p.idHeroi;
        registrarEventoMesaOnline(p.nome, 'TANQUE', `${p.nome} ativou Postura de Baluarte (+4 Defesa) e provocou as ameaças!`);
    } else if (tipoAcao === 'CURAR_ALIADO') {
        if (p.pmAtual < 2) { exibirMensagemStatus('PM insuficientes!'); return; }
        p.pmAtual -= 2;
        const aliados = m.participantes || [p];
        let alvo = aliados[0], menorPct = 999;
        aliados.forEach(a => { const pct = Number(a.pvAtual || 0) / Math.max(1, Number(a.pvMax || 1)); if (pct < menorPct) { menorPct = pct; alvo = a; } });
        const cura = (Math.floor(Math.random() * 8) + 1) + (Math.floor(Math.random() * 8) + 1) + 4 + (Number(p.nivel || 1) * 2);
        alvo.pvAtual = Math.min(alvo.pvMax, Number(alvo.pvAtual || 0) + cura);
        if (alvo.condicoes) alvo.condicoes.sangrando = false;
        registrarEventoMesaOnline(p.nome, 'CURA', `${p.nome} curou +${cura} PV em ${alvo.nome}!`);
    } else if (tipoAcao === 'MAGIA_OFENSIVA') {
        const custoPM = Math.min(Number(p.pmAtual || 0), Math.max(2, Math.floor(Number(p.nivel || 1) / 2) + 1));
        if (custoPM < 1) { exibirMensagemStatus('Sem PM!'); return; }
        p.pmAtual -= custoPM;
        const cdEf = Number(p.cdMagia || 17) + bonusGrupo;
        const dBase = Math.round((Number(p.danoMedio || 18) * 1.45) + (custoPM * 4) + bonusGrupo);
        inimigos.forEach(cr => {
            if (cr.pvAtual <= 0) return;
            const res = (Math.floor(Math.random() * 20) + 1 + Number(cr.media || 12)) >= cdEf;
            const dFin = res ? Math.floor(dBase / 2) : dBase;
            cr.pvAtual = Math.max(0, Number(cr.pvAtual || 0) - dFin);
            if (!cr.condicoes) cr.condicoes = criarCondicoesPadrao2D(false);
            if (!res) cr.condicoes.emChamas = true;
        });
        registrarEventoMesaOnline(p.nome, 'MAGIA', `${p.nome} lançou Magia em Área (CD ${cdEf}) atingindo todas as ameaças vivas!`);
    }

    if (boss.pvAtual <= 0) {
        const proxVivo = inimigos.findIndex(c => c.pvAtual > 0);
        if (proxVivo >= 0) m.alvoFocoMesaIdx = proxVivo;
        else registrarEventoMesaOnline('Sistema T20', 'VITORIA', `VITÓRIA DO GRUPO!`);
    }
    sincronizarAlvoFocoMesaOnline();
    avancarProximoTurnoMesaOnlineJS(true);
    propagarEstadoMesaOnlineParaServidores();
}

function executarTurnoDoChefeMesaOnlineJS(modoAtaque) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    sincronizarAlvoFocoMesaOnline();
    const m = ESTADO_MESA_ONLINE_ATUAL;
    try {
        const stg = document.getElementById("mesa-2d-stage-svg-box");
        if (stg && typeof stg.scrollIntoView === "function") stg.scrollIntoView({ behavior: "smooth", block: "nearest" });
        const inimFoco = (m.listaInimigosMesa || [])[m.alvoFocoMesaIdx || 0] || { gx: 5, gy: 2 };
        const hAlvo = (m.participantes || [])[0] || { gx: 2, gy: 2 };
        if (typeof dispararAnimacaoCoreografadaPalco2DJS === "function") {
            dispararAnimacaoCoreografadaPalco2DJS({
                tipo: modoAtaque === "AREA_GRUPO" ? "SOPRO_DRAGAO" : "GARRAS_MONSTRO",
                ladoAlvo: "HEROI",
                origem: { gx: inimFoco.gx || 5, gy: inimFoco.gy || 2 },
                destino: { gx: hAlvo.gx || 2, gy: hAlvo.gy || 2 },
                label: modoAtaque === "AREA_GRUPO" ? `Sopro/Área de ${m.chefeAtivo.nome}` : `Ataque de ${m.chefeAtivo.nome}`
            });
        }
    } catch(e) {}
    const inimigosVivos = (m.listaInimigosMesa || []).filter(c => Number(c.pvAtual || 0) > 0);
    const vivos = (m.participantes || []).filter(p => Number(p.pvAtual || 0) > 0);
    if (vivos.length === 0 || inimigosVivos.length === 0) return;
    const boss = inimigosVivos[0];
    if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function') {
        const hAlvoAnim = vivos[0] || { gx: 2, gy: 2 };
        dispararAnimacaoCoreografadaPalco2DJS({
            tipo: modoAtaque === 'AREA_GRUPO' ? 'SOPRO_DRAGAO' : 'GARRAS_MONSTRO',
            origem: { gx: boss.gx || 5, gy: boss.gy || 2 },
            destino: { gx: hAlvoAnim.gx || 2, gy: hAlvoAnim.gy || 2 },
            label: `${boss.nome}: ${modoAtaque === 'AREA_GRUPO' ? 'Ataque de Área!' : 'Investida!'}`
        });
    }
    const bonusGrupo = obterSomaBuffsAtaqueDanoGrupo();
    const atqEf = Number(boss.ataque || 22) - Number(m.chefeAtivo.penalidadeAtaque || 0);

    if (modoAtaque === 'AREA_GRUPO') {
        const cdBoss = Number(boss.cd || 22) - Number(m.chefeAtivo.penalidadeAtaque || 0);
        const danoArea = Math.max(10, Math.round(Number(boss.danoMedio || 42) * 0.75));
        vivos.forEach(h => {
            const passou = (Math.floor(Math.random() * 20) + 1 + Math.floor(Number(h.nivel || 1) / 2) + 4 + bonusGrupo) >= cdBoss;
            h.pvAtual = Math.max(0, Number(h.pvAtual || 0) - (passou ? Math.floor(danoArea / 2) : danoArea));
            if (!passou && h.condicoes) h.condicoes.emChamas = true;
        });
        registrarEventoMesaOnline(boss.nome, 'CHEFE_AREA', `${boss.nome} lançou Ataque de Área (CD ${cdBoss}) em todo o grupo!`);
    } else {
        let alvo = vivos.find(h => h.idHeroi === m.chefeAtivo.alvoProvocadoId || h.provocando) || vivos[0];
        const d20 = Math.floor(Math.random() * 20) + 1;
        const tot = d20 + atqEf;
        const defAlvo = Number(alvo.defesaBase || 18) + Number(alvo.defesaPosturaBonus || 0) + bonusGrupo;
        if (d20 === 20 || (d20 !== 1 && tot >= defAlvo)) {
            const dano = Math.max(6, Math.round(Number(boss.danoMedio || 40) * (1 + (inimigosVivos.length - 1) * 0.25)));
            alvo.pvAtual = Math.max(0, Number(alvo.pvAtual || 0) - dano);
            registrarEventoMesaOnline(boss.nome, 'CHEFE_ATQ', `${boss.nome} acertou ${alvo.nome} (${tot} vs Def ${defAlvo}) causando ${dano} de dano!`);
        } else {
            registrarEventoMesaOnline(boss.nome, 'CHEFE_ERRO', `${boss.nome} errou ${alvo.nome} (${tot} vs Def ${defAlvo})!`);
        }
    }
    avancarProximoTurnoMesaOnlineJS(true);
    propagarEstadoMesaOnlineParaServidores();
}

function avancarProximoTurnoMesaOnlineJS(silencioso) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    recalcularOrdemIniciativaMesa();
    const fila = ESTADO_MESA_ONLINE_ATUAL.ordemIniciativa || [];
    if (fila.length === 0) return;
    ESTADO_MESA_ONLINE_ATUAL.turnoIndice = Number(ESTADO_MESA_ONLINE_ATUAL.turnoIndice || 0) + 1;
    if (ESTADO_MESA_ONLINE_ATUAL.turnoIndice >= fila.length) {
        ESTADO_MESA_ONLINE_ATUAL.turnoIndice = 0;
        ESTADO_MESA_ONLINE_ATUAL.rodadaAtual = Number(ESTADO_MESA_ONLINE_ATUAL.rodadaAtual || 1) + 1;
    }
    if (!silencioso) propagarEstadoMesaOnlineParaServidores();
}

function rolarDadoCompartilhadoMesaJS(formula, rotulo) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const st = garantirEstadoFichaParaArena();
    const autor = (st && st.nome) ? st.nome : 'Jogador';
    let resultadoStr = '';
    if (formula === '2d20_melhor') {
        const d1 = Math.floor(Math.random() * 20) + 1, d2 = Math.floor(Math.random() * 20) + 1;
        resultadoStr = `2d20 (${d1}, ${d2}) → Melhor = ${Math.max(d1, d2)}`;
    } else {
        const m = String(formula).match(/(\d+)d(\d+)([+-]\d+)?/);
        if (m) {
            const qtd = parseInt(m[1], 10), faces = parseInt(m[2], 10), mod = m[3] ? parseInt(m[3], 10) : 0;
            let soma = 0, rls = [];
            for (let i = 0; i < qtd; i++) { const r = Math.floor(Math.random() * faces) + 1; rls.push(r); soma += r; }
            resultadoStr = `${formula} [${rls.join(', ')}]${mod ? (mod > 0 ? '+' + mod : mod) : ''} = ${soma + mod}`;
        }
    }
    registrarEventoMesaOnline(autor, 'DADO', `${autor} rolou ${rotulo}: ${resultadoStr}`);
    propagarEstadoMesaOnlineParaServidores();
}

function enviarMensagemChatMesaOnlineJS() {
    const inp = document.getElementById('mesa-chat-input');
    if (!inp || !inp.value.trim()) return;
    const st = garantirEstadoFichaParaArena();
    const autor = (st && st.nome) ? st.nome : 'Jogador';
    registrarEventoMesaOnline(autor, 'CHAT', `${autor}: ${inp.value.trim()}`);
    inp.value = '';
    propagarEstadoMesaOnlineParaServidores();
}

function copiarTokenConviteMesaOnlineJS() {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    try {
        const token = btoa(unescape(encodeURIComponent(JSON.stringify(ESTADO_MESA_ONLINE_ATUAL))));
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(token);
            exibirMensagemStatus('Token da Mesa copiado!');
        } else window.prompt('Copie o Token da Mesa:', token);
    } catch (e) {}
}

function importarTokenConviteMesaOnlinePromptJS() {
    const token = window.prompt('Cole o Código de Estado da Mesa:');
    if (!token || !token.trim()) return;
    try {
        const obj = JSON.parse(decodeURIComponent(escape(atob(token.trim()))));
        if (obj && obj.codigoSala) {
            ESTADO_MESA_ONLINE_ATUAL = obj;
            const codEl = document.getElementById('mesa-input-codigo');
            if (codEl) codEl.value = obj.codigoSala;
            propagarEstadoMesaOnlineParaServidores();
        }
    } catch (e) { exibirMensagemStatus('Token inválido.'); }
}

function removerHeroiDaMesaOnlineJS(idHeroi) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    ESTADO_MESA_ONLINE_ATUAL.participantes = (ESTADO_MESA_ONLINE_ATUAL.participantes || []).filter(p => p.idHeroi !== idHeroi);
    propagarEstadoMesaOnlineParaServidores();
}

function renderizarMesaOnlineCompletaUI() {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    recalcularOrdemIniciativaMesa();
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const boss = m.chefeAtivo || {};
    const inimigos = m.listaInimigosMesa || [boss];

    renderizarPalcoEGrid2DMesaOnline();

    const elBossNome = document.getElementById('mesa-boss-nome');
    const elBossSub = document.getElementById('mesa-boss-subtitulo');
    const elRodada = document.getElementById('mesa-rodada-badge');
    const elPvTxt = document.getElementById('mesa-boss-pv-texto');
    const elPvBar = document.getElementById('mesa-boss-pv-bar');
    const elMetricas = document.getElementById('mesa-boss-metricas-grid');

    const vivosInim = inimigos.filter(x => x.pvAtual > 0).length;
    const qB = Math.max(1, Number(boss.espacoQ || 1));
    if (elBossNome) elBossNome.textContent = `${boss.nome || 'Ameaça'} (ND ${boss.nd || '?'}) ${inimigos.length > 1 ? `[${vivosInim}/${inimigos.length}]` : ''}`;
    if (elBossSub) elBossSub.textContent = `${boss.tamanhoCat || 'Médio'} (${qB}x${qB} = ${(qB * 1.5).toFixed(1)}m) • Posição: (${(boss.gx || 0) + 1}, ${(boss.gy || 0) + 1})`;
    if (elRodada) elRodada.textContent = `Rodada ${m.rodadaAtual || 1}`;

    const pvAt = Math.max(0, Number(boss.pvAtual || 0));
    const pvMx = Math.max(1, Number(boss.pvMax || 1));
    const pctBoss = Math.max(0, Math.min(100, Math.round((pvAt / pvMx) * 100)));
    if (elPvTxt) elPvTxt.textContent = `${pvAt} / ${pvMx} PV (${pctBoss}%)`;
    if (elPvBar) elPvBar.style.width = pctBoss + '%';

    if (elMetricas) {
        const cndB = boss.condicoes || {};
        const penDefCond = (cndB.caido ? 5 : 0) + (cndB.desprevenido || cndB.atordoado ? 5 : 0) + (cndB.lento ? 2 : 0);
        const defEf = Math.max(10, Number(boss.defesa || 25) - Number(boss.penalidadeDefesa || 0) - penDefCond);
        const atqEf = Number(boss.ataque || 20) - Number(boss.penalidadeAtaque || 0);
        elMetricas.innerHTML = `
            <div style="background:rgba(0,0,0,0.4); padding:6px; border-radius:6px;"><div style="color:#94a3b8; font-size:0.66rem;">DEFESA</div><div style="font-weight:800; color:#f8fafc;">${defEf}</div></div>
            <div style="background:rgba(0,0,0,0.4); padding:6px; border-radius:6px;"><div style="color:#94a3b8; font-size:0.66rem;">ATAQUE</div><div style="font-weight:800; color:#fca5a5;">+${atqEf}</div></div>
            <div style="background:rgba(0,0,0,0.4); padding:6px; border-radius:6px;"><div style="color:#94a3b8; font-size:0.66rem;">DANO MÉDIO</div><div style="font-weight:800; color:#fdba74;">${boss.danoMedio || 40}</div></div>
            <div style="background:rgba(0,0,0,0.4); padding:6px; border-radius:6px;"><div style="color:#94a3b8; font-size:0.66rem;">ESPAÇO</div><div style="font-weight:800; color:#c084fc;">${qB}x${qB} (${(qB * 1.5).toFixed(1)}m)</div></div>
        `;
    }

    const elBuffs = document.getElementById('mesa-buffs-grupo-box');
    const bonusG = obterSomaBuffsAtaqueDanoGrupo();
    if (elBuffs) {
        elBuffs.innerHTML = bonusG > 0
            ? `<strong>Sinergia Coletiva Ativa:</strong> +${bonusG} em Ataque, Dano, Defesa e Testes para todos os heróis!`
            : `<strong>Buffs Coletivos Ativos no Grupo:</strong> Nenhum buff ativo.`;
    }

    const elIni = document.getElementById('mesa-iniciativa-lista');
    if (elIni) {
        const fila = m.ordemIniciativa || [];
        elIni.innerHTML = fila.map((item, idx) => {
            const ativo = idx === Number(m.turnoIndice || 0);
            return `<div style="display:flex; justify-content:space-between; align-items:center; padding:6px 10px; border-radius:8px; border:1px solid ${ativo ? '#fbbf24' : 'rgba(255,255,255,0.08)'}; background:${ativo ? 'rgba(251,191,36,0.14)' : 'rgba(0,0,0,0.3)'}; font-size:0.76rem;">
                <div><strong style="color:${item.tipo === 'CHEFE' ? '#fca5a5' : '#f8fafc'};">${ativo ? '▶' : ''}${idx + 1}º. ${item.nome}</strong></div>
                <div style="display:flex; gap:10px;"><span>${item.pvAtual}/${item.pvMax}</span><span style="color:#38bdf8; font-weight:800;">${item.iniciativa}</span></div>
            </div>`;
        }).join('');
    }

    const elCount = document.getElementById('mesa-count-herois');
    const parts = m.participantes || [];
    if (elCount) elCount.textContent = String(parts.length);

    const elGridHerois = document.getElementById('mesa-herois-grid');
    if (elGridHerois) {
        elGridHerois.innerHTML = parts.map(p => {
            const pctPv = Math.max(0, Math.min(100, Math.round((Number(p.pvAtual || 0) / Math.max(1, Number(p.pvMax || 1))) * 100)));
            const pctPm = Math.max(0, Math.min(100, Math.round((Number(p.pmAtual || 0) / Math.max(1, Number(p.pmMax || 1))) * 100)));
            const flanqueando = verificarHeroiFlanqueandoAlvoMesa(p, boss, parts);
            const defEfetiva = Number(p.defesaBase || 16) + Number(p.defesaPosturaBonus || 0) + bonusG;
            const atqEfetivo = Number(p.ataqueBonus || 8) + bonusG + (flanqueando ? 2 : 0);
            const svgAvatar2D = construirRetrato2DHeroiCardSVG(p);
            return `
                <div style="background:rgba(15,23,42,0.92); border:1.5px solid ${flanqueando ? '#FACC15' : (p.provocando ? '#38bdf8' : 'rgba(212,175,55,0.4)')}; border-radius:12px; padding:10px; display:flex; flex-direction:column; gap:8px;">
                    <div style="display:flex; gap:10px; align-items:center;">
                        ${svgAvatar2D}
                        <div style="flex:1; min-width:0;">
                            <div style="display:flex; justify-content:space-between;">
                                <div style="font-weight:900; font-size:0.9rem; color:#fde047;">${p.nome} ${p.provocando ? '' : ''}</div>
                                <button type="button" onclick="removerHeroiDaMesaOnlineJS('${p.idHeroi}')" style="background:transparent; border:none; color:#64748b; cursor:pointer;"></button>
                            </div>
                            <div style="font-size:0.72rem; color:#f8fafc; font-weight:700;">${p.raca} • ${p.classesResumo}</div>
                            <div style="font-size:0.68rem; color:${flanqueando ? '#FACC15' : '#38bdf8'}; font-weight:800;">(${(p.gx || 0) + 1},${(p.gy || 0) + 1}) ${flanqueando ? '• FLANCO (+2)' : ''}</div>
                            <div style="margin-top:4px;">
                                <div style="display:flex; justify-content:space-between; font-size:0.7rem;"><span>${p.pvAtual}/${p.pvMax}</span><span>${p.pmAtual}/${p.pmMax}</span></div>
                                <div style="width:100%; height:7px; background:#090D16; border-radius:99px; overflow:hidden; margin:2px 0;"><div style="width:${pctPv}%; height:100%; background:#22c55e;"></div></div>
                                <div style="width:100%; height:5px; background:#090D16; border-radius:99px; overflow:hidden;"><div style="width:${pctPm}%; height:100%; background:#38bdf8;"></div></div>
                            </div>
                        </div>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-size:0.72rem; color:#cbd5e1; background:rgba(0,0,0,0.38); padding:5px 8px; border-radius:6px;">
                        <span>Def: <strong>${defEfetiva}</strong></span><span>Atq: <strong>+${atqEfetivo}</strong></span><span>Dano: <strong>${Number(p.danoMedio || 14) + bonusG}</strong></span>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px;">
                        <button type="button" class="btn btn-gold" style="margin:0; min-height:36px; padding:5px 6px; font-size:0.73rem;" onclick="executarAcaoHeroiMesaOnlineJS('${p.idHeroi}', 'ATAQUE')">Atacar (2d20)</button>
                        <button type="button" class="btn btn-outline" style="margin:0; min-height:36px; padding:5px 6px; font-size:0.73rem; border-color:#f97316 !important; color:#fdba74 !important;" onclick="executarAcaoHeroiMesaOnlineJS('${p.idHeroi}', 'MAGIA_OFENSIVA')">Magia em Área</button>
                        <button type="button" class="btn btn-outline" style="margin:0; min-height:36px; padding:5px 6px; font-size:0.73rem; border-color:#fbbf24 !important; color:#fde047 !important;" onclick="executarAcaoHeroiMesaOnlineJS('${p.idHeroi}', 'BUFF_GRUPO')">Buff Grupo</button>
                        <button type="button" class="btn btn-outline" style="margin:0; min-height:36px; padding:5px 6px; font-size:0.73rem; border-color:#4ade80 !important; color:#4ade80 !important;" onclick="executarAcaoHeroiMesaOnlineJS('${p.idHeroi}', 'CURAR_ALIADO')">Curar Aliado</button>
                    </div>
                    <button type="button" class="btn btn-outline" style="margin:0; min-height:34px; padding:4px 6px; font-size:0.71rem; border-color:#38bdf8 !important; color:#38bdf8 !important; width:100%;" onclick="executarAcaoHeroiMesaOnlineJS('${p.idHeroi}', 'PROVOCAR_TANQUE')">Postura Tanque: Provocar &amp; +4 Def</button>
                </div>
            `;
        }).join('');
    }

    const elLog = document.getElementById('mesa-log-eventos');
    if (elLog) {
        elLog.innerHTML = (m.historicoEventos || []).map(ev => `<div style="color:#e2e8f0; padding:3px 0; border-bottom:1px solid rgba(255,255,255,0.05);"><span style="color:#64748b;">[${ev.horario || '--:--'}]</span> ${ev.mensagem}</div>`).join('');
    }
}


// =============================================================================
// POPULAÇÃO ÚNICA DE SELECTS ESTÁTICOS, AUDITORIA DE PODERES, CALCULADORA DE ND & RL DE GRUPO (v51)
// =============================================================================

// =============================================================================
// CONTROLADORES DE MONTARIAS E PARCEIROS (ARENA, FICHA E MESA ONLINE) - v52
// =============================================================================
function mudarMontariaOuParceiroGlobalJS(origemUI) {
    const prefix = origemUI === 'MESA' ? 'mesa' : 'arena';
    const mont = document.getElementById(prefix + '-sel-montaria')?.value || 'NENHUMA';
    const patM = document.getElementById(prefix + '-sel-patamar-montaria')?.value || 'INICIANTE';
    const parc = document.getElementById(prefix + '-sel-parceiro')?.value || 'NENHUM';
    const patP = document.getElementById(prefix + '-sel-patamar-parceiro')?.value || 'INICIANTE';

    window.__MONTARIA_E_PARCEIRO_ATUAL__ = {
        montaria: mont,
        patamarMontaria: patM,
        parceiro: parc,
        patamarParceiro: patP
    };

    // Sincroniza os selects entre Arena e Mesa Online
    ['arena', 'mesa'].forEach(pr => {
        const sM = document.getElementById(pr + '-sel-montaria');
        const spM = document.getElementById(pr + '-sel-patamar-montaria');
        const sP = document.getElementById(pr + '-sel-parceiro');
        const spP = document.getElementById(pr + '-sel-patamar-parceiro');
        if (sM) sM.value = mont;
        if (spM) spM.value = patM;
        if (sP) sP.value = parc;
        if (spP) spP.value = patP;
    });

    const st = garantirEstadoFichaParaArena();
    if (st) st.montariaParceiro = Object.assign({}, window.__MONTARIA_E_PARCEIRO_ATUAL__);
    const infoMP = obterBonusMontariaEParceiroAtivosJS(st);

    // Atualiza na Arena
    if (typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
        const a = __ARENA_STATE__;
        a.bonusDefTemp = infoMP.bonusDefesa || 0;
        a.acoesMovimentoMax = 1 + (infoMP.acaoMovimentoExtraMontaria || 0);
        a.acoesMovimentoRestantes = Math.max(a.acoesMovimentoRestantes, a.acoesMovimentoMax);
        if (st && st.raca) {
            st.raca.tamanho = infoMP.montado ? infoMP.tamanhoMontadoCat : (st.raca.tamanhoOriginal || 'Médio');
        }
        atualizarPlacarVisualArena();
    }

    // Atualiza no Herói Selecionado da Mesa Online
    if (typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) {
        const m = ESTADO_MESA_ONLINE_ATUAL;
        const hSel = (m.participantes || []).find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || (m.participantes || [])[0];
        if (hSel) {
            hSel.montariaParceiro = Object.assign({}, window.__MONTARIA_E_PARCEIRO_ATUAL__);
            hSel.espacoQ = infoMP.montado ? infoMP.espacoMontadoQ : 1;
            hSel.tamanhoCat = infoMP.montado ? infoMP.tamanhoMontadoCat : 'Médio';
            hSel.defesaPosturaBonus = (infoMP.bonusDefesa || 0);
        }
        propagarEstadoMesaOnlineParaServidores();
    }

    if (typeof atualizarRetratoFichaPrincipalJS === 'function') atualizarRetratoFichaPrincipalJS();
    atualizarResumoMontariaParceiroUI();
}

function atualizarResumoMontariaParceiroUI() {
    const st = garantirEstadoFichaParaArena();
    if (!st || typeof obterBonusMontariaEParceiroAtivosJS !== 'function') return;
    const info = obterBonusMontariaEParceiroAtivosJS(st);
    const txt = `<strong>Montaria:</strong> ${info.resumoMontaria} &nbsp;|&nbsp; <strong>Parceiro:</strong> ${info.resumoParceiro}`;
    const b1 = document.getElementById('arena-resumo-montaria-parceiro');
    const b2 = document.getElementById('mesa-resumo-montaria-parceiro');
    if (b1) b1.innerHTML = txt;
    if (b2) b2.innerHTML = txt;
}

function usarCuraParceiroMedicoArenaJS() {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    if (!a || !st) return;
    const infoMP = obterBonusMontariaEParceiroAtivosJS(st);
    if (infoMP.parceiro !== 'MEDICO') {
        exibirMensagemStatus('Selecione o Parceiro "Médico" primeiro para usar a cura de aliado!');
        return;
    }
    if (a.pmHeroi < 1) {
        exibirMensagemStatus('Requer 1 PM para ativar a Cura do Parceiro Médico!');
        return;
    }
    a.pmHeroi -= 1;
    const qtdD8 = infoMP.patamarParceiro === 'MESTRE' ? 6 : (infoMP.patamarParceiro === 'VETERANO' ? 3 : 1);
    let somaCura = qtdD8;
    for (let i = 0; i < qtdD8; i++) somaCura += Math.floor(Math.random() * 8) + 1;
    const antes = a.pvHeroi;
    a.pvHeroi = Math.min(a.pvHeroiMax, a.pvHeroi + somaCura);
    if (a.condicoesHeroi && infoMP.patamarParceiro === 'MESTRE') {
        a.condicoesHeroi.sangrando = false;
        a.condicoesHeroi.envenenado = false;
    }
    dispararAnimacaoCoreografadaPalco2DJS({
        tipo: 'CURA_BUFF',
        origem: a.posHeroi || { gx: 2, gy: 2 },
        destino: a.posHeroi || { gx: 2, gy: 2 },
        label: `Parceiro Médico: +${somaCura} PV`
    });
    registrarLinhaLogArena(`<strong>[Parceiro Médico (${infoMP.patamarParceiro}) · -1 PM]</strong> Curou <strong>+${somaCura} PV</strong> (${antes} ${a.pvHeroi}/${a.pvHeroiMax} PV)!`);
    atualizarPlacarVisualArena();
}

function popularSelectsEstaticosCriaturasJS() {
    atualizarResumoMontariaParceiroUI();
    const listaCat = obterCatalogoAmeacasCap7Geral();
    if (listaCat.length === 0) return;
    const htmlOpts = listaCat.map(c => {
        const tInfo = calcularTamanhoCriaturaObj(c.tipo_nivel_tamanho || 'Médio');
        return `<option value="${c.id_ameaca}">[ND ${c.nd}] ${c.nome} (${tInfo.categoria} ${tInfo.espacoQ}x${tInfo.espacoQ} • ${c.pv} PV • Def ${c.defesa})</option>`;
    }).join('');

    ['arena-static-sel-add-criatura', 'mesa-static-sel-add-criatura'].forEach(idSel => {
        const el = document.getElementById(idSel);
        if (el && el.options.length === 0) {
            el.innerHTML = htmlOpts;
        }
    });
    atualizarPreviewCalculadoraNDArenaJS();
    atualizarPreviewCalculadoraNDMesaJS();
}

function construirBarraAuditoriaPoderesArmaHTML(st) {
    if (!st || typeof auditarCompatibilidadePoderesArmaJS !== 'function') return '';
    const todosPods = [
        ...((st.est && st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est && st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ];
    const audit = auditarCompatibilidadePoderesArmaJS(st.arma, st.escudo, todosPods, st.classe);
    const nomeArma = st.arma ? st.arma.nome : 'Desarmado / Magia';
    const nomeEsc = (st.escudo && st.escudo.nome && st.escudo.nome !== 'Nenhum') ? ` + ${st.escudo.nome}` : '';

    const tagsComp = audit.compativeis.map(p =>
        `<span style="background:rgba(16,185,129,0.18);border:1px solid #10B981;color:#A7F3D0;padding:2px 7px;border-radius:6px;font-size:10px;font-weight:800;" title="${p.motivo}">${p.nome}</span>`
    ).join(' ');

    const tagsBloq = audit.bloqueados.map(p =>
        `<span style="background:rgba(239,68,68,0.22);border:1px solid #F87171;color:#FECACA;padding:2px 7px;border-radius:6px;font-size:10px;font-weight:800;" title="${p.motivo}">${p.nome} (${p.motivo})</span>`
    ).join(' ');

    return `
        <div style="margin-bottom:8px; padding:7px 10px; border-radius:8px; background:rgba(15,23,42,0.82); border:1px solid rgba(212,175,55,0.4);">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; margin-bottom:4px;">
                <span style="font-size:11px; font-weight:800; color:#FDE047;">
                    Verificador de Empunhadura &amp; Poderes: <strong style="color:#38BDF8;">${nomeArma}${nomeEsc}</strong> <em>${audit.estiloRotulo}</em>
                </span>
                <span style="font-size:10px; color:${audit.bloqueados.length > 0 ? '#FCA5A5' : '#4ADE80'}; font-weight:800;">
                    ${audit.bloqueados.length > 0 ? `${audit.bloqueados.length} poder(es) inativo(s) p/ esta empunhadura` : '100% dos poderes compatíveis com a arma atual'}
                </span>
            </div>
            <div style="display:flex; flex-wrap:wrap; gap:4px;">
                ${tagsComp}
                ${tagsBloq}
            </div>
        </div>
    `;
}

// =============================================================================
// CALCULADORA DE ND: ARENA E MESA ONLINE
// =============================================================================
function atualizarPreviewCalculadoraNDArenaJS() {
    const box = document.getElementById('arena-calc-nd-preview');
    if (!box || !__ARENA_STATE__ || typeof reescalonarCriaturaParaNovoNDJS !== 'function') return;
    const a = __ARENA_STATE__;
    const alvo = (a.listaCriaturas || [])[a.alvoFocoIdx || 0] || a._privadoCriatura;
    if (!alvo) return;
    const novoND = document.getElementById('arena-calc-nd-valor')?.value || '7';
    const novoPapel = document.getElementById('arena-calc-nd-papel')?.value || 'MANTER';
    const novoTam = document.getElementById('arena-calc-nd-tamanho')?.value || 'MANTER';
    const calc = reescalonarCriaturaParaNovoNDJS(alvo, novoND, novoPapel, novoTam);
    if (!calc) return;
    const ndTotal = typeof calcularNDTotalEncontroCombinadoJS === 'function' ? calcularNDTotalEncontroCombinadoJS(a.listaCriaturas) : calc.ndNovo;
    box.innerHTML = `<strong>Preview (${alvo.nomeCriatura || 'Alvo'} ND ${calc.ndNovo} · ${calc.papelNovo} · ${calc.tamanhoCat} ${calc.espacoQ}x${calc.espacoQ}):</strong> ` +
        `PV: <strong>${calc.pv}</strong> | Def: <strong>${calc.defesa}</strong> | Atq: <strong>+${calc.ataque}</strong> | Dano: <strong>${calc.danoMedio}</strong> | CD: <strong>${calc.cd}</strong> | ND Total do Encontro: <strong>ND ${ndTotal}</strong>`;
}

function aplicarCalculadoraNDArenaJS(aplicarEmTodos) {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    if (!a || !Array.isArray(a.listaCriaturas)) return;
    const novoND = document.getElementById('arena-calc-nd-valor')?.value || '7';
    const novoPapel = document.getElementById('arena-calc-nd-papel')?.value || 'MANTER';
    const novoTam = document.getElementById('arena-calc-nd-tamanho')?.value || 'MANTER';

    const indices = aplicarEmTodos ? a.listaCriaturas.map((_, i) => i) : [a.alvoFocoIdx || 0];
    indices.forEach(idx => {
        const cr = a.listaCriaturas[idx];
        if (!cr) return;
        if (!cr.ndOriginal) cr.ndOriginal = cr.ndTexto || '1';
        if (!cr.pvBaseOriginal) cr.pvBaseOriginal = cr.pvMax;
        if (cr.ataqueBaseOriginal === undefined) cr.ataqueBaseOriginal = cr.ataque;
        if (cr.danoBaseOriginal === undefined) cr.danoBaseOriginal = cr.danoMedio;
        if (cr.defesaBaseOriginal === undefined) cr.defesaBaseOriginal = cr.defesa;

        const calc = reescalonarCriaturaParaNovoNDJS(cr, novoND, novoPapel, novoTam);
        if (!calc) return;
        cr.ndTexto = calc.ndNovo;
        cr.papel = calc.papelNovo;
        cr.tamanhoCat = calc.tamanhoCat;
        cr.espacoQ = calc.espacoQ;
        cr.pvMax = calc.pv;
        cr.pvAtual = calc.pv;
        cr.defesa = calc.defesa;
        cr.ataque = calc.ataque;
        cr.danoMedio = calc.danoMedio;
    });

    const dims = calcularDimensoesDinamicasGrid([a.posHeroi], a.listaCriaturas, 8, 5);
    a.gridCols = dims.cols; a.gridRows = dims.rows;
    sincronizarAlvoFocoComPrivadoArenaJS(a);
    a.encerrado = false;
    registrarLinhaLogArena(`<strong>[Calculadora de ND (p. 323)]</strong> ${aplicarEmTodos ? 'Todas as criaturas do encontro foram reescalonadas' : `${a._privadoCriatura.nomeCriatura} foi reescalonada`} para <strong>ND ${novoND}</strong>!`);
    atualizarPlacarVisualArena();
    atualizarPreviewCalculadoraNDArenaJS();
}

function atualizarPreviewCalculadoraNDMesaJS() {
    const box = document.getElementById('mesa-calc-nd-preview');
    if (!box || !ESTADO_MESA_ONLINE_ATUAL || typeof reescalonarCriaturaParaNovoNDJS !== 'function') return;
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const inimigos = m.listaInimigosMesa || [];
    const alvo = inimigos[m.alvoFocoMesaIdx || 0] || m.chefeAtivo;
    if (!alvo) return;
    const novoND = document.getElementById('mesa-calc-nd-valor')?.value || '7';
    const novoPapel = document.getElementById('mesa-calc-nd-papel')?.value || 'MANTER';
    const novoTam = document.getElementById('mesa-calc-nd-tamanho')?.value || 'MANTER';
    const calc = reescalonarCriaturaParaNovoNDJS(alvo, novoND, novoPapel, novoTam);
    if (!calc) return;
    const ndTotal = typeof calcularNDTotalEncontroCombinadoJS === 'function' ? calcularNDTotalEncontroCombinadoJS(inimigos) : calc.ndNovo;
    box.innerHTML = `<strong>Preview (${alvo.nome || 'Ameaça'} ND ${calc.ndNovo} · ${calc.papelNovo} · ${calc.tamanhoCat} ${calc.espacoQ}x${calc.espacoQ}):</strong> ` +
        `PV: <strong>${calc.pv}</strong> | Def: <strong>${calc.defesa}</strong> | Atq: <strong>+${calc.ataque}</strong> | Dano: <strong>${calc.danoMedio}</strong> | CD: <strong>${calc.cd}</strong> | ND Total do Encontro: <strong>ND ${ndTotal}</strong>`;
}

function aplicarCalculadoraNDMesaOnlineJS(aplicarEmTodos) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    sincronizarAlvoFocoMesaOnline();
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const inimigos = m.listaInimigosMesa || [];
    const novoND = document.getElementById('mesa-calc-nd-valor')?.value || '7';
    const novoPapel = document.getElementById('mesa-calc-nd-papel')?.value || 'MANTER';
    const novoTam = document.getElementById('mesa-calc-nd-tamanho')?.value || 'MANTER';

    const indices = aplicarEmTodos ? inimigos.map((_, i) => i) : [m.alvoFocoMesaIdx || 0];
    indices.forEach(idx => {
        const cr = inimigos[idx];
        if (!cr) return;
        if (!cr.ndOriginal) cr.ndOriginal = cr.nd || '7';
        if (!cr.pvBaseOriginal) cr.pvBaseOriginal = cr.pvMax;
        if (cr.ataqueBaseOriginal === undefined) cr.ataqueBaseOriginal = cr.ataque;
        if (cr.danoBaseOriginal === undefined) cr.danoBaseOriginal = cr.danoMedio;
        if (cr.defesaBaseOriginal === undefined) cr.defesaBaseOriginal = cr.defesa;
        if (cr.cdBaseOriginal === undefined) cr.cdBaseOriginal = cr.cd;

        const calc = reescalonarCriaturaParaNovoNDJS(cr, novoND, novoPapel, novoTam);
        if (!calc) return;
        cr.nd = calc.ndNovo;
        cr.nd_num = calc.ndNovoNum;
        cr.papel = calc.papelNovo;
        cr.patamar = calc.patamarNovo;
        cr.tamanhoCat = calc.tamanhoCat;
        cr.espacoQ = calc.espacoQ;
        cr.pvMax = calc.pv;
        cr.pvAtual = calc.pv;
        cr.defesa = calc.defesa;
        cr.ataque = calc.ataque;
        cr.danoMedio = calc.danoMedio;
        cr.cd = calc.cd;
        cr.forte = calc.resForte;
        cr.media = calc.resMedia;
        cr.fraca = calc.resFraca;
    });

    sincronizarAlvoFocoMesaOnline();
    registrarEventoMesaOnline(
        'Mestre (Calculadora de ND)',
        'ND_CALC',
        `${aplicarEmTodos ? 'Todas as ameaças do encontro foram reescalonadas' : `${m.chefeAtivo.nome} foi reescalonado`} para ND ${novoND} (${m.chefeAtivo.pvMax} PV, Def ${m.chefeAtivo.defesa}, Atq +${m.chefeAtivo.ataque}, Dano ${m.chefeAtivo.danoMedio})!`
    );
    propagarEstadoMesaOnlineParaServidores();
    atualizarPreviewCalculadoraNDMesaJS();
    exibirMensagemStatus(`Estatísticas reescalonadas para ND ${novoND} com sucesso!`);
}

// =============================================================================
// TREINADOR POR APRENDIZADO POR REFORÇO DE GRUPO (MULTI-AGENT CO-OP RL) NA MESA ONLINE - v51
// =============================================================================
window.__ULTIMO_RANKING_RL_GRUPO_MESA__ = [];

function gerarCandidatosPartyRLMesaOnline(nvGrupo, politicaMulti) {
    const nv = Math.max(1, Number(nvGrupo || 6));
    const usarMulti = (politicaMulti !== 'SEM_MULTICLASSE' && nv >= 3);
    const nvP = usarMulti ? Math.max(1, nv - 2) : nv;
    const nvS = usarMulti ? (nv - nvP) : 0;

    return [
        {
            idParty: 'TRINDADE_CLASSICA',
            titulo: 'Quarteto Real de Valkaria (Tanque Baluarte + Striker Flanqueador + Arcano AoE + Clérigo Sagrado)',
            sinergiaResumo: 'Baluarte absorve 100% do foco, Guerreiro/Bárbaro flanqueia (+2 Atq), Arcanista aplica controle/dano em área e Clérigo mantém Oração (+Atq/Dano) + Cura.',
            herois: [
                {
                    idHeroi: 'RL_P1_TANQUE', nome: 'Bastião de Khalmyr', jogador: 'Agente RL #1', raca: 'Anão', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Cavaleiro', armaNome: 'Espada Longa',
                    classesResumo: usarMulti ? `Cavaleiro ${nvP} / Guerreiro ${nvS}` : `Cavaleiro ${nv}`, nivel: nv,
                    papel: 'Tanque / Linha de Frente',
                    pvMax: 32 + nv * 10, pmMax: 4 * nv, defesaBase: 23 + Math.floor(nv * 1.25),
                    ataqueBonus: 7 + Math.floor(nv * 1.2), danoMedio: 14 + Math.floor(nv * 2.3), cdMagia: 14 + Math.floor(nv / 2),
                    iniciativaBonus: Math.floor(nv / 2) + 2, provocando: true, defesaPosturaBonus: 4, gx: 3, gy: 2
                },
                {
                    idHeroi: 'RL_P1_STRIKER', nome: 'Kaelen Fúria-Rubra', jogador: 'Agente RL #2', raca: 'Minotauro', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Guerreiro', armaNome: 'Montante',
                    classesResumo: usarMulti ? `Guerreiro ${nvP} / Bárbaro ${nvS}` : `Guerreiro ${nv}`, nivel: nv,
                    papel: 'Combatente Flanqueador (Duas Mãos)',
                    pvMax: 26 + nv * 8, pmMax: 4 * nv + 2, defesaBase: 19 + Math.floor(nv * 0.9),
                    ataqueBonus: 9 + Math.floor(nv * 1.45), danoMedio: 22 + Math.floor(nv * 4.2), cdMagia: 14 + Math.floor(nv / 2),
                    iniciativaBonus: Math.floor(nv / 2) + 4, provocando: false, defesaPosturaBonus: 0, gx: 6, gy: 2
                },
                {
                    idHeroi: 'RL_P1_ARCANO', nome: 'Lyra Vorpal', jogador: 'Agente RL #3', raca: 'Elfo', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Arcanista', armaNome: 'Cajado Arcano',
                    classesResumo: `Arcanista ${nv}`, nivel: nv,
                    papel: 'Conjurador Arcano (AoE & Controle)',
                    pvMax: 14 + nv * 4, pmMax: 7 * nv + 6, defesaBase: 16 + Math.floor(nv * 0.75),
                    ataqueBonus: 6 + Math.floor(nv * 1.1), danoMedio: 20 + Math.floor(nv * 4.4), cdMagia: 19 + Math.floor(nv * 0.9),
                    iniciativaBonus: Math.floor(nv / 2) + 6, provocando: false, defesaPosturaBonus: 0, gx: 1, gy: 1
                },
                {
                    idHeroi: 'RL_P1_SUPORTE', nome: 'Irmã Solange', jogador: 'Agente RL #4', raca: 'Qareen', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Clérigo', armaNome: 'Maça',
                    classesResumo: usarMulti ? `Clérigo ${nvP} / Bardo ${nvS}` : `Clérigo ${nv}`, nivel: nv,
                    papel: 'Suporte Divino (Oração & Cura)',
                    pvMax: 20 + nv * 6, pmMax: 6 * nv + 4, defesaBase: 20 + Math.floor(nv * 0.95),
                    ataqueBonus: 6 + Math.floor(nv * 1.05), danoMedio: 12 + Math.floor(nv * 1.9), cdMagia: 18 + Math.floor(nv * 0.8),
                    iniciativaBonus: Math.floor(nv / 2) + 4, provocando: false, defesaPosturaBonus: 0, gx: 1, gy: 3
                }
            ]
        },
        {
            idParty: 'BLITZ_FLANQUEAMENTO',
            titulo: 'Esquadrão Blitzkrieg de Flanqueamento & Ataque Furtivo (Paladino + Ladino Assassino + Bardo + Arcanista)',
            sinergiaResumo: 'Paladino e Ladino cercam o Chefe em lados opostos garantindo Flanqueamento permanente (+2 Atq + Ataque Furtivo todos os turnos) somado a Inspiração + Oração.',
            herois: [
                {
                    idHeroi: 'RL_P2_PALADINO', nome: 'Sir Solaris', jogador: 'Agente RL #1', raca: 'Aggelus', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Paladino', armaNome: 'Espada Longa',
                    classesResumo: usarMulti ? `Paladino ${nvP} / Guerreiro ${nvS}` : `Paladino ${nv}`, nivel: nv,
                    papel: 'Tanque Sagrado & Golpe Divino',
                    pvMax: 28 + nv * 9, pmMax: 5 * nv + 3, defesaBase: 22 + Math.floor(nv * 1.15),
                    ataqueBonus: 9 + Math.floor(nv * 1.4), danoMedio: 19 + Math.floor(nv * 3.6), cdMagia: 16 + Math.floor(nv * 0.6),
                    iniciativaBonus: Math.floor(nv / 2) + 3, provocando: true, defesaPosturaBonus: 3, gx: 3, gy: 2
                },
                {
                    idHeroi: 'RL_P2_LADINO', nome: 'Vex Sombra-Ágil', jogador: 'Agente RL #2', raca: 'Goblin', tamanhoCat: 'Pequeno', espacoQ: 1,
                    classeNome: 'Ladino', armaNome: 'Florete',
                    classesResumo: usarMulti ? `Ladino ${nvP} / Bucaneiro ${nvS}` : `Ladino ${nv}`, nivel: nv,
                    papel: 'Flanqueador Crítico & Ataque Furtivo',
                    pvMax: 18 + nv * 6, pmMax: 4 * nv + 4, defesaBase: 19 + Math.floor(nv * 0.95),
                    ataqueBonus: 10 + Math.floor(nv * 1.45), danoMedio: 21 + Math.floor(nv * 4.1), cdMagia: 15 + Math.floor(nv * 0.5),
                    iniciativaBonus: Math.floor(nv / 2) + 7, provocando: false, defesaPosturaBonus: 0, gx: 6, gy: 2
                },
                {
                    idHeroi: 'RL_P2_BARDO', nome: 'Dante Melodia-Rubra', jogador: 'Agente RL #3', raca: 'Qareen', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Bardo', armaNome: 'Florete',
                    classesResumo: usarMulti ? `Bardo ${nvP} / Clérigo ${nvS}` : `Bardo ${nv}`, nivel: nv,
                    papel: 'Suporte Tático (Inspiração & Curar)',
                    pvMax: 18 + nv * 6, pmMax: 6 * nv + 4, defesaBase: 18 + Math.floor(nv * 0.85),
                    ataqueBonus: 7 + Math.floor(nv * 1.15), danoMedio: 13 + Math.floor(nv * 2.1), cdMagia: 18 + Math.floor(nv * 0.75),
                    iniciativaBonus: Math.floor(nv / 2) + 5, provocando: false, defesaPosturaBonus: 0, gx: 1, gy: 2
                },
                {
                    idHeroi: 'RL_P2_MAGO', nome: 'Ignis de Wynlla', jogador: 'Agente RL #4', raca: 'Elfo', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Arcanista', armaNome: 'Cajado Arcano',
                    classesResumo: `Arcanista ${nv}`, nivel: nv,
                    papel: 'Conjurador Arcano (Dano Explosivo)',
                    pvMax: 14 + nv * 4, pmMax: 7 * nv + 6, defesaBase: 16 + Math.floor(nv * 0.75),
                    ataqueBonus: 6 + Math.floor(nv * 1.1), danoMedio: 21 + Math.floor(nv * 4.5), cdMagia: 19 + Math.floor(nv * 0.9),
                    iniciativaBonus: Math.floor(nv / 2) + 6, provocando: false, defesaPosturaBonus: 0, gx: 1, gy: 1
                }
            ]
        },
        {
            idParty: 'FORTALEZA_IMORTAL',
            titulo: 'Fortaleza Inabalável de Arton (Cavaleiro Baluarte + Paladino Égide + Clérigo de Lena + Arcanista Abjurador)',
            sinergiaResumo: 'Dupla de linha de frente com altíssima Defesa, Aura Sagrada (+CAR nas resistências) e Cura em Massa, ideal contra Chefes Solo de ND muito superior.',
            herois: [
                {
                    idHeroi: 'RL_P3_CAVALEIRO', nome: 'Thorek Muro-de-Aço', jogador: 'Agente RL #1', raca: 'Anão', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Cavaleiro', armaNome: 'Machado de Batalha',
                    classesResumo: `Cavaleiro ${nv}`, nivel: nv,
                    papel: 'Tanque Imortal (Baluarte & Solidez)',
                    pvMax: 36 + nv * 11, pmMax: 4 * nv, defesaBase: 25 + Math.floor(nv * 1.3),
                    ataqueBonus: 7 + Math.floor(nv * 1.2), danoMedio: 14 + Math.floor(nv * 2.1), cdMagia: 14 + Math.floor(nv / 2),
                    iniciativaBonus: Math.floor(nv / 2) + 1, provocando: true, defesaPosturaBonus: 5, gx: 3, gy: 2
                },
                {
                    idHeroi: 'RL_P3_PALADINO', nome: 'Aurélia Luz-de-Azgher', jogador: 'Agente RL #2', raca: 'Humano', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Paladino', armaNome: 'Espada Longa',
                    classesResumo: usarMulti ? `Paladino ${nvP} / Guerreiro ${nvS}` : `Paladino ${nv}`, nivel: nv,
                    papel: 'Off-Tank & Golpe Divino Flanqueador',
                    pvMax: 28 + nv * 9, pmMax: 5 * nv + 2, defesaBase: 22 + Math.floor(nv * 1.1),
                    ataqueBonus: 9 + Math.floor(nv * 1.35), danoMedio: 19 + Math.floor(nv * 3.5), cdMagia: 16 + Math.floor(nv * 0.6),
                    iniciativaBonus: Math.floor(nv / 2) + 3, provocando: false, defesaPosturaBonus: 2, gx: 6, gy: 2
                },
                {
                    idHeroi: 'RL_P3_CLERIGO', nome: 'Padre Orion', jogador: 'Agente RL #3', raca: 'Osteon', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Clérigo', armaNome: 'Maça',
                    classesResumo: `Clérigo ${nv}`, nivel: nv,
                    papel: 'Suporte Divino & Oração Máxima',
                    pvMax: 22 + nv * 6, pmMax: 6 * nv + 5, defesaBase: 21 + Math.floor(nv * 1.0),
                    ataqueBonus: 6 + Math.floor(nv * 1.0), danoMedio: 12 + Math.floor(nv * 1.8), cdMagia: 19 + Math.floor(nv * 0.85),
                    iniciativaBonus: Math.floor(nv / 2) + 3, provocando: false, defesaPosturaBonus: 0, gx: 1, gy: 3
                },
                {
                    idHeroi: 'RL_P3_ARCANO', nome: 'Selene Arcana', jogador: 'Agente RL #4', raca: 'Qareen', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Arcanista', armaNome: 'Cajado Arcano',
                    classesResumo: `Arcanista ${nv}`, nivel: nv,
                    papel: 'Controlador Arcano & Dano Contínuo',
                    pvMax: 15 + nv * 4, pmMax: 7 * nv + 5, defesaBase: 17 + Math.floor(nv * 0.8),
                    ataqueBonus: 6 + Math.floor(nv * 1.1), danoMedio: 19 + Math.floor(nv * 4.2), cdMagia: 19 + Math.floor(nv * 0.9),
                    iniciativaBonus: Math.floor(nv / 2) + 5, provocando: false, defesaPosturaBonus: 0, gx: 1, gy: 1
                }
            ]
        },
        {
            idParty: 'SUPREMACIA_ARCANA',
            titulo: 'Supremacia de Artilharia & Magia em Área (Guardião + Caçador Disparo Rápido + 2 Conjuradores AoE)',
            sinergiaResumo: 'Otimizado para Encontros com Múltiplas Criaturas (Matilhas e Hordas): devasta todos os alvos simultaneamente com Explosão de Chamas e Disparo Rápido.',
            herois: [
                {
                    idHeroi: 'RL_P4_GUARDIAO', nome: 'Garu Guarda-Férrea', jogador: 'Agente RL #1', raca: 'Golem', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Cavaleiro', armaNome: 'Espada Longa',
                    classesResumo: `Cavaleiro ${nv}`, nivel: nv,
                    papel: 'Muralha de Contenção (Linha de Frente)',
                    pvMax: 30 + nv * 10, pmMax: 4 * nv, defesaBase: 24 + Math.floor(nv * 1.2),
                    ataqueBonus: 7 + Math.floor(nv * 1.2), danoMedio: 14 + Math.floor(nv * 2.2), cdMagia: 14 + Math.floor(nv / 2),
                    iniciativaBonus: Math.floor(nv / 2) + 1, provocando: true, defesaPosturaBonus: 4, gx: 3, gy: 2
                },
                {
                    idHeroi: 'RL_P4_ARQUEIRO', nome: 'Sylas Flecha-de-Prata', jogador: 'Agente RL #2', raca: 'Elfo', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Caçador', armaNome: 'Arco Longo',
                    classesResumo: usarMulti ? `Caçador ${nvP} / Guerreiro ${nvS}` : `Caçador ${nv}`, nivel: nv,
                    papel: 'Artilheiro à Distância (Disparo Rápido)',
                    pvMax: 20 + nv * 7, pmMax: 4 * nv + 3, defesaBase: 18 + Math.floor(nv * 0.85),
                    ataqueBonus: 10 + Math.floor(nv * 1.45), danoMedio: 21 + Math.floor(nv * 4.0), cdMagia: 15 + Math.floor(nv * 0.5),
                    iniciativaBonus: Math.floor(nv / 2) + 6, provocando: false, defesaPosturaBonus: 0, gx: 0, gy: 2
                },
                {
                    idHeroi: 'RL_P4_ARCANO', nome: 'Pyros de Wynlla', jogador: 'Agente RL #3', raca: 'Qareen', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Arcanista', armaNome: 'Cajado Arcano',
                    classesResumo: `Arcanista ${nv}`, nivel: nv,
                    papel: 'Artilharia Arcana em Área (AoE)',
                    pvMax: 14 + nv * 4, pmMax: 7 * nv + 6, defesaBase: 16 + Math.floor(nv * 0.75),
                    ataqueBonus: 6 + Math.floor(nv * 1.1), danoMedio: 22 + Math.floor(nv * 4.6), cdMagia: 19 + Math.floor(nv * 0.9),
                    iniciativaBonus: Math.floor(nv / 2) + 6, provocando: false, defesaPosturaBonus: 0, gx: 0, gy: 1
                },
                {
                    idHeroi: 'RL_P4_CLERIGO', nome: 'Celeste Solar', jogador: 'Agente RL #4', raca: 'Aggelus', tamanhoCat: 'Médio', espacoQ: 1,
                    classeNome: 'Clérigo', armaNome: 'Maça',
                    classesResumo: `Clérigo ${nv}`, nivel: nv,
                    papel: 'Suporte Divino & Explosão Solar AoE',
                    pvMax: 20 + nv * 6, pmMax: 6 * nv + 5, defesaBase: 20 + Math.floor(nv * 0.95),
                    ataqueBonus: 6 + Math.floor(nv * 1.05), danoMedio: 15 + Math.floor(nv * 2.8), cdMagia: 18 + Math.floor(nv * 0.85),
                    iniciativaBonus: Math.floor(nv / 2) + 4, provocando: false, defesaPosturaBonus: 0, gx: 0, gy: 3
                }
            ]
        }
    ];
}

function treinarMelhorGrupoRLMesaOnlineJS() {
    if (!ESTADO_MESA_ONLINE_ATUAL) inicializarAbaMesaOnlineUI();
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const stFicha = garantirEstadoFichaParaArena();
    const nvBase = Math.max(1, Number((stFicha && stFicha.nivel) || 6));

    const selDoutrina = document.getElementById('mesa-rl-doutrina-grupo')?.value || 'TODOS_RANKING';
    const selMulti = document.getElementById('mesa-rl-multiclasse')?.value || 'AUTO_MCTS';
    const todasParties = gerarCandidatosPartyRLMesaOnline(nvBase, selMulti);
    const poolParties = selDoutrina === 'TODOS_RANKING'
        ? todasParties
        : todasParties.filter(p => p.idParty === selDoutrina).concat(todasParties.filter(p => p.idParty !== selDoutrina));

    const inimigosOrig = (m.listaInimigosMesa && m.listaInimigosMesa.length > 0)
        ? m.listaInimigosMesa
        : [m.chefeAtivo];

    const episodiosPorGrupo = 85;
    const resultadosRanking = [];

    poolParties.forEach(cand => {
        let vitorias = 0;
        let somaRodadas = 0;
        let somaDPRGrupo = 0;
        let somaVivosFim = 0;

        for (let ep = 0; ep < episodiosPorGrupo; ep++) {
            const heroisSim = cand.herois.map(h => Object.assign({}, h, { pvAtual: h.pvMax, pmAtual: h.pmMax }));
            const inimsSim = inimigosOrig.map(c => ({
                pvAtual: Number(c.pvMax || 200),
                pvMax: Number(c.pvMax || 200),
                defesa: Number(c.defesa || 25),
                ataque: Number(c.ataque || 20),
                danoMedio: Number(c.danoMedio || 40),
                media: Number(c.media || 12),
                cd: Number(c.cd || 20)
            }));

            let bonusBuff = 0;
            let penInim = 0;
            let danoTotalEp = 0;
            let rod = 1;

            for (; rod <= 12; rod++) {
                // Turno dos 4 Heróis com Política Q-Learning Co-op
                for (let idxH = 0; idxH < heroisSim.length; idxH++) {
                    const h = heroisSim[idxH];
                    if (h.pvAtual <= 0) continue;
                    const vivosInim = inimsSim.filter(x => x.pvAtual > 0);
                    if (vivosInim.length === 0) break;

                    // 1. Se for Suporte e buff ainda não ativo na rodada 1, ativa Oração/Inspiração Coletiva
                    if (rod === 1 && idxH === 3 && h.pmAtual >= 2) {
                        h.pmAtual -= 2;
                        bonusBuff = Math.min(5, 2 + Math.floor(nvBase / 5));
                        penInim = bonusBuff;
                        continue;
                    }
                    // 2. Se algum aliado estiver com < 42% PV e o herói for Suporte, cura!
                    const aliadoCritico = heroisSim.find(a => a.pvAtual > 0 && (a.pvAtual / a.pvMax) < 0.42);
                    if (aliadoCritico && (h.papel.includes('Suporte') || h.classeNome === 'Clérigo' || h.classeNome === 'Bardo') && h.pmAtual >= 2) {
                        h.pmAtual -= 2;
                        aliadoCritico.pvAtual = Math.min(aliadoCritico.pvMax, aliadoCritico.pvAtual + 14 + nvBase * 2);
                        continue;
                    }
                    // 3. Se for Conjurador Arcano ou Encontro com >=2 inimigos, lança Magia em Área (AoE)
                    if ((h.classeNome === 'Arcanista' || (vivosInim.length >= 2 && h.papel.includes('AoE'))) && h.pmAtual >= 2) {
                        const pmGasto = Math.min(h.pmAtual, Math.max(2, Math.floor(nvBase / 2) + 1));
                        h.pmAtual -= pmGasto;
                        const cdM = h.cdMagia + bonusBuff;
                        const dMagBase = Math.round(h.danoMedio * 1.35 + pmGasto * 3.8 + bonusBuff);
                        vivosInim.forEach(al => {
                            const r = (Math.floor(Math.random() * 20) + 1 + al.media - penInim) >= cdM;
                            const d = r ? Math.floor(dMagBase / 2) : dMagBase;
                            al.pvAtual = Math.max(0, al.pvAtual - d);
                            danoTotalEp += d;
                        });
                        continue;
                    }
                    // 4. Ataque Focado com Flanqueamento (+2 Atq) e 2d20
                    const alvoF = vivosInim[0];
                    const d20 = Math.max(Math.floor(Math.random() * 20) + 1, Math.floor(Math.random() * 20) + 1);
                    const bFlanco = (cand.idParty === 'BLITZ_FLANQUEAMENTO' || idxH <= 1) ? 2 : 0;
                    const totAtq = d20 + h.ataqueBonus + bonusBuff + bFlanco;
                    const defEf = Math.max(10, alvoF.defesa - penInim);
                    if (d20 >= 19 || (d20 !== 1 && totAtq >= defEf)) {
                        const mult = d20 >= 19 ? 2 : 1;
                        const dFurt = (h.classeNome === 'Ladino' && bFlanco > 0) ? (Math.ceil(nvBase / 2) * 3.5) : 0;
                        const dGolpe = Math.max(4, Math.round(h.danoMedio * mult + bonusBuff + dFurt));
                        alvoF.pvAtual = Math.max(0, alvoF.pvAtual - dGolpe);
                        danoTotalEp += dGolpe;
                    }
                }

                if (inimsSim.every(x => x.pvAtual <= 0)) {
                    vitorias += 1;
                    break;
                }

                // Turno das Criaturas Vivas
                const vivosInimTurno = inimsSim.filter(x => x.pvAtual > 0);
                const vivosHerois = heroisSim.filter(x => x.pvAtual > 0);
                if (vivosHerois.length === 0) break;

                vivosInimTurno.forEach((cr, idxCr) => {
                    const heroisVivosAgora = heroisSim.filter(x => x.pvAtual > 0);
                    if (heroisVivosAgora.length === 0) return;
                    const tanqueVivo = heroisVivosAgora.find(x => x.provocando) || heroisVivosAgora[0];
                    const d20C = Math.floor(Math.random() * 20) + 1;
                    const totC = d20C + cr.ataque - penInim;
                    const defT = tanqueVivo.defesaBase + tanqueVivo.defesaPosturaBonus + bonusBuff;
                    if (d20C === 20 || (d20C !== 1 && totC >= defT)) {
                        const dSofrido = Math.max(4, Math.round(cr.danoMedio * (idxCr === 0 ? 1.0 : 0.45)));
                        tanqueVivo.pvAtual = Math.max(0, tanqueVivo.pvAtual - dSofrido);
                    }
                });

                if (heroisSim.every(x => x.pvAtual <= 0)) break;
            }

            somaRodadas += Math.min(12, rod);
            somaDPRGrupo += (danoTotalEp / Math.max(1, Math.min(12, rod)));
            somaVivosFim += heroisSim.filter(x => x.pvAtual > 0).length;
        }

        const winRate = Math.round((vitorias / episodiosPorGrupo) * 100);
        const mediaRod = +(somaRodadas / episodiosPorGrupo).toFixed(1);
        const mediaDPR = Math.round(somaDPRGrupo / episodiosPorGrupo);
        const mediaVivos = +(somaVivosFim / episodiosPorGrupo).toFixed(1);
        const scoreRL = Math.round(winRate * 2.2 + mediaDPR * 0.8 + mediaVivos * 15 - mediaRod * 4);

        resultadosRanking.push({
            cand,
            winRate,
            mediaRod,
            mediaDPR,
            mediaVivos,
            scoreRL
        });
    });

    resultadosRanking.sort((a, b) => b.scoreRL - a.scoreRL);
    window.__ULTIMO_RANKING_RL_GRUPO_MESA__ = resultadosRanking;

    const boxRes = document.getElementById('mesa-rl-podium-results-box');
    if (boxRes) {
        const medalhas = ['1º LUGAR (MELHOR GRUPO CAMPEÃO)', '2º LUGAR (VICE-CAMPEÃO)', '3º LUGAR (BRONZE)'];
        const cardsPodium = resultadosRanking.slice(0, 3).map((r, idx) => {
            const listaH = r.cand.herois.map(h =>
                `<span style="background:rgba(15,23,42,0.9);border:1px solid #475569;padding:2px 6px;border-radius:5px;font-size:10px;color:#F8FAFC;"><strong>${h.nome}</strong> (${h.raca} • ${h.classesResumo} • ${h.armaNome})</span>`
            ).join(' ');
            return `
                <div style="background:rgba(9,13,22,0.92); border:1.5px solid ${idx === 0 ? '#FACC15' : '#334155'}; border-radius:10px; padding:9px 11px; margin-bottom:7px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px;">
                        <div>
                            <span style="font-size:10.5px; font-weight:900; color:${idx === 0 ? '#FDE047' : '#38BDF8'};">${medalhas[idx]}</span>
                            <div style="font-size:12px; font-weight:800; color:#F8FAFC; margin-top:1px;">${r.cand.titulo}</div>
                        </div>
                        <button type="button" class="btn btn-gold" style="width:auto; margin:0; min-height:32px; padding:4px 12px; font-size:11px;" onclick="equiparGrupoCampeaoRLNaMesaOnlineJS(${idx})">
                            Equipar Este Grupo na Mesa Online
                        </button>
                    </div>
                    <div style="font-size:10.5px; color:#94A3B8; margin:4px 0;">${r.cand.sinergiaResumo}</div>
                    <div style="display:flex; gap:8px; flex-wrap:wrap; font-size:10.5px; color:#A7F3D0; font-weight:800; margin-bottom:5px;">
                        <span>Vitória Co-op: <strong>${r.winRate}%</strong></span>
                        <span>DPR Médio do Grupo: <strong>${r.mediaDPR} dano/rodada</strong></span>
                        <span>⏱Duração Média: <strong>${r.mediaRod} rodadas</strong></span>
                        <span>Sobrevivência: <strong>${r.mediaVivos}/4 heróis vivos</strong></span>
                    </div>
                    <div style="display:flex; flex-wrap:wrap; gap:4px;">${listaH}</div>
                </div>
            `;
        }).join('');

        boxRes.innerHTML = `
            <div style="margin-top:6px;">
                <div style="font-size:11.5px; font-weight:900; color:#FEF08A; margin-bottom:6px;">
                    Pódio Top 3 Melhores Composições de Grupo (Treinadas contra ${inimigosOrig.length}x Ameaça(s) — ND Combinado ${calcularNDTotalEncontroCombinadoJS(inimigosOrig)}):
                </div>
                ${cardsPodium}
            </div>
        `;
    }

    // Equipa automaticamente o 1º colocado na Mesa Online para o usuário já ver o grupo campeão em ação!
    if (resultadosRanking.length > 0) {
        equiparGrupoCampeaoRLNaMesaOnlineJS(0, true);
    }
}

function equiparGrupoCampeaoRLNaMesaOnlineJS(idxRanking, silencioso) {
    const rank = (window.__ULTIMO_RANKING_RL_GRUPO_MESA__ || [])[idxRanking || 0];
    if (!rank || !ESTADO_MESA_ONLINE_ATUAL) return;
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const novosHerois = rank.cand.herois.map(h => {
        const posLivre = encontrarPosicaoLivreBloco2D([], m.listaInimigosMesa || [], 1, h.gx || 2);
        return Object.assign({}, h, {
            pvAtual: h.pvMax,
            pmAtual: h.pmMax,
            iniciativaRolada: (Math.floor(Math.random() * 20) + 1) + Number(h.iniciativaBonus || 4),
            condicoes: criarCondicoesPadrao2D(false),
            gx: h.gx !== undefined ? h.gx : posLivre.gx,
            gy: h.gy !== undefined ? h.gy : posLivre.gy
        });
    });
    m.participantes = novosHerois;
    HEROI_SELECIONADO_GRID_MESA_ID = novosHerois[0].idHeroi;
    posicionarGrupoFlanqueamentoAutomaticoMesaJS();
    registrarEventoMesaOnline(
        'Treinador RL Co-op',
        'RL_PARTY',
        `Grupo Campeão RL equipado na Mesa: ${rank.cand.titulo} (Taxa de Vitória: ${rank.winRate}% | DPR Coletivo: ${rank.mediaDPR}/rodada)!`
    );
    propagarEstadoMesaOnlineParaServidores();
    if (!silencioso) {
        exibirMensagemStatus(`Grupo Campeão RL equipado na Mesa Online (${rank.winRate}% de vitória)!`);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => { try { popularSelectsEstaticosCriaturasJS(); } catch(e){} }, 90);
    setTimeout(() => {
        try {
            if (typeof atualizarRetratoFichaPrincipalJS === 'function') atualizarRetratoFichaPrincipalJS();
            if (typeof inicializarAbaMesaOnlineUI === 'function') inicializarAbaMesaOnlineUI();
        } catch (e) {}
    }, 60);
});



function saltarParaCoordenadaMapa120ArenaJS() {
    inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    if (!a) return;
    const inpX = document.getElementById('arena-inp-coord-x120');
    const inpY = document.getElementById('arena-inp-coord-y120');
    const gx = Math.max(0, Math.min(119, (parseInt(inpX ? inpX.value : '57', 10) || 57) - 1));
    const gy = Math.max(0, Math.min(119, (parseInt(inpY ? inpY.value : '61', 10) || 61) - 1));
    window.__MODO_MOVIMENTO_LIVRE_120__ = true;
    moverHeroiParaCelulaGridArenaJS(gx, gy);
    if (typeof centralizarCameraMapa120JS === 'function') centralizarCameraMapa120JS('HEROI');
}


// =============================================================================
// // 1. MODAL DEDICADO DE CÁLCULOS & ALGORITMOS (CSP AC-3 + MCTS UCT + POMDP RL)
// 2. MOTOR DE MOVIMENTAÇÃO INTERPOLADA PASSO A PASSO (ARENA & MESA ONLINE)
// 3. SELEÇÃO POR CLIQUE NO PERSONAGEM EXIBINDO TODAS AS SUAS AÇÕES POSSÍVEIS
//    (NA TELA NORMAL E EM TELA CHEIA, TANTO NA ARENA QUANTO NA MESA ONLINE)
// 4. ANIMAÇÃO ÚNICA E EXCLUSIVA PARA CADA AÇÃO, PODER, HABILIDADE E MAGIA
// =============================================================================

window.__PERSONAGEM_CLICADO_ARENA__ = { tipo: 'HEROI', id: 'HEROI_PRINCIPAL' };
window.__PERSONAGEM_CLICADO_MESA__ = { tipo: 'HEROI_MESA', id: null };
window.__TRILHA_MOVIMENTO_ATIVA__ = null;
window.__TIMER_PASSOS_MOVIMENTO__ = null;

// -----------------------------------------------------------------------------
// 1. MODAL DEDICADO DE CÁLCULOS & ALGORITMOS (DESPOLUIÇÃO DA INTERFACE PRINCIPAL)
// -----------------------------------------------------------------------------
function abrirModalAlgoritmosCalculosT20JS(abaInicial) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    const secaoAlvo = abaInicial || 'AUDITORIA_MCTS';
    let modal = document.getElementById('modal-algoritmos-calculos-t20');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'modal-algoritmos-calculos-t20';
        modal.style.cssText = 'position:fixed;inset:0;z-index:2147483646;background:rgba(4,7,15,0.88);display:flex;align-items:center;justify-content:center;padding:12px;overflow-y:auto;';
        document.body.appendChild(modal);
    }
    const st = (typeof garantirEstadoFichaParaArena === 'function') ? garantirEstadoFichaParaArena() : window.__ULTIMO_ESTADO_FICHA__;
    const est = st ? st.est : null;
    const resDano = (st && est && typeof calcularDanoEsperadoFicha === 'function')
        ? calcularDanoEsperadoFicha(st, est, st.arma, st.poderes, st.magias, st.arquetipo)
        : null;

    let conteudoHTML = '';
    if (secaoAlvo === 'AUDITORIA_MCTS') {
        const detAud = document.getElementById('details-auditoria-mcts-ficha');
        if (detAud) {
            conteudoHTML = `<div style="font-size:12.5px;">${detAud.innerHTML}</div>`;
        } else if (st && est && resDano && typeof gerarLinhasAuditoriaScoreJS === 'function') {
            conteudoHTML = `
                <h3 style="color:#FACC15;margin-top:0;">Auditoria Matemática do Score MCTS (${(st.scoreFinal || 0).toFixed(1)} pts) &amp; Rede Neural PUCT</h3>
                <table class="skills-table">
                    <thead><tr><th>Componente da Função de Avaliação MCTS</th><th style="text-align:right;">Contribuição</th></tr></thead>
                    <tbody>${gerarLinhasAuditoriaScoreJS(st, est, resDano)}</tbody>
                </table>
            `;
        } else {
            const ssrBox = document.getElementById('ssr-painel-algoritmos-oculto');
            conteudoHTML = ssrBox ? ssrBox.innerHTML : '<p>Auditoria matemática pronta.</p>';
        }
    } else if (secaoAlvo === 'SIMULADOR_TATICO') {
        const detSim = document.getElementById('details-simulador-orientador-ficha');
        if (detSim) {
            conteudoHTML = `<div style="font-size:12.5px;">${detSim.innerHTML}</div>`;
        } else {
            const ssrBox = document.getElementById('ssr-painel-algoritmos-oculto');
            conteudoHTML = ssrBox ? ssrBox.innerHTML : '<p>Simulador estratégico pronto.</p>';
        }
    } else if (secaoAlvo === 'ARVORE_MCTS') {
        const arvBox = document.getElementById('tab-arvore') || document.getElementById('container-arvore-na-ficha');
        conteudoHTML = arvBox ? arvBox.innerHTML : '<p>Árvore MCTS + CSP pronta.</p>';
    }

    modal.style.display = 'flex';
    modal.innerHTML = `
        <div style="width:100%;max-width:980px;max-height:90dvh;overflow-y:auto;background:linear-gradient(160deg,#0F172A,#1E1B4B);border:2px solid #FACC15;border-radius:14px;padding:14px 16px;color:#F8FAFC;box-shadow:0 16px 48px rgba(0,0,0,0.9);">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;border-bottom:1.5px solid rgba(250,204,21,0.4);padding-bottom:10px;margin-bottom:12px;position:sticky;top:0;background:#0F172A;z-index:5;">
                <div>
                    <div style="font-size:16px;font-weight:900;color:#FACC15;">Central de Cálculos, Simulações &amp; Algoritmos de IA (T20 JdA)</div>
                    <div style="font-size:11px;color:#CBD5E1;">Demonstrações matemáticas isoladas para manter a interface de jogo limpa</div>
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                    <button type="button" class="btn-roll-inline" style="background:${secaoAlvo === 'AUDITORIA_MCTS' ? '#B45309' : '#1E293B'};border-color:#FACC15;padding:5px 10px;" onclick="abrirModalAlgoritmosCalculosT20JS('AUDITORIA_MCTS')">Score MCTS &amp; PUCT</button>
                    <button type="button" class="btn-roll-inline" style="background:${secaoAlvo === 'SIMULADOR_TATICO' ? '#047857' : '#1E293B'};border-color:#34D399;padding:5px 10px;" onclick="abrirModalAlgoritmosCalculosT20JS('SIMULADOR_TATICO')">Simulador &amp; Guia Tático</button>
                    <button type="button" class="btn-roll-inline" style="background:${secaoAlvo === 'ARVORE_MCTS' ? '#6D28D9' : '#1E293B'};border-color:#C084FC;padding:5px 10px;" onclick="abrirModalAlgoritmosCalculosT20JS('ARVORE_MCTS')">Árvore CSP + MCTS</button>
                    <button type="button" class="btn-roll-inline" style="background:#991B1B;border-color:#FCA5A5;color:#FEF08A;font-weight:900;padding:5px 12px;" onclick="document.getElementById('modal-algoritmos-calculos-t20').style.display='none'">Fechar</button>
                </div>
            </div>
            <div>${conteudoHTML}</div>
        </div>
    `;
}

function alternarPainelGrid2DArenaVisivelJS() {
    const p = document.getElementById('arena-tactical-2d-panel');
    const b = document.getElementById('btn-toggle-grid2d-arena-inline');
    if (!p) return;
    const vis = p.style.display !== 'none';
    p.style.display = vis ? 'none' : 'block';
    if (b) {
        b.innerHTML = vis ? 'Grid 2D &amp; Radar' : 'Ocultar Grid 2D';
    }
    if (!vis && typeof renderizarPainelTatico2DArenaJS === 'function') {
        renderizarPainelTatico2DArenaJS();
    }
}

// -----------------------------------------------------------------------------
// 2. CATÁLOGO DE ANIMAÇÕES ÚNICAS POR AÇÃO, HABILIDADE, PODER E MAGIA (v66)
// -----------------------------------------------------------------------------
function obterCodigoAnimacaoUnicaPorHabilidadeJS(nomeHabilidade, categoria, subtipoArma) {
    const nm = String(nomeHabilidade || '').toLowerCase();
    const cat = String(categoria || '').toUpperCase();
    const arma = String(subtipoArma || '').toLowerCase();

    // 1. Poderes de Classe & Gerais Específicos
    if (nm.includes('ataque especial')) return 'ANIM_PODER_ATAQUE_ESPECIAL';
    if (nm.includes('golpe pessoal')) return 'ANIM_PODER_GOLPE_PESSOAL';
    if (nm.includes('fúria') || nm.includes('furia') || nm.includes('frenesi')) return 'ANIM_PODER_FURIA_BARBARA';
    if (nm.includes('golpe divino') || nm.includes('espada sagrada') || nm.includes('julgamento divino')) return 'ANIM_PODER_GOLPE_DIVINO';
    if (nm.includes('assassinar')) return 'ANIM_PODER_ASSASSINAR';
    if (nm.includes('ataque furtivo') || nm.includes('sombra')) return 'ANIM_PODER_ATAQUE_FURTIVO';
    if (nm.includes('inspiração') || nm.includes('inspiracao') || nm.includes('música') || nm.includes('musica')) return 'ANIM_PODER_INSPIRACAO_BARDO';
    if (nm.includes('forma selvagem') || nm.includes('força dos penhascos')) return 'ANIM_PODER_FORMA_SELVAGEM';
    if (nm.includes('marca da presa') || nm.includes('escaramuça') || nm.includes('arqueiro')) return 'ANIM_PODER_MARCA_DA_PRESA';
    if (nm.includes('audácia') || nm.includes('audacia') || nm.includes('insolência') || nm.includes('panache') || nm.includes('esgrima')) return 'ANIM_PODER_AUDACIA_INSOLENCIA';
    if (nm.includes('baluarte') || nm.includes('provocar') || nm.includes('postura') || nm.includes('formação')) return 'ANIM_PODER_BALUARTE_PROVOCAR';
    if (nm.includes('durão') || nm.includes('durao') || nm.includes('sangue de ferro')) return 'ANIM_PODER_DURAO';
    if (nm.includes('golpe relâmpago') || nm.includes('trocação') || nm.includes('voadora') || nm.includes('rasteira')) return 'ANIM_PODER_GOLPE_RELAMPAGO';
    if (nm.includes('engenhoca') || nm.includes('balística') || nm.includes('alquimia') || nm.includes('cospe-chamas')) return 'ANIM_PODER_ENGENHOCA_INVENTOR';
    if (nm.includes('gritar ordens') || nm.includes('ordens') || nm.includes('estrategista') || nm.includes('orgulho')) return 'ANIM_PODER_GRITAR_ORDENS';
    if (nm.includes('ataque poderoso')) return 'ANIM_PODER_ATAQUE_PODEROSO';
    if (nm.includes('combate defensivo') || nm.includes('encouraçado') || nm.includes('esquiva')) return 'ANIM_PODER_COMBATE_DEFENSIVO';
    if (nm.includes('ataque extra') || nm.includes('ambidestria') || nm.includes('estilo de duas armas') || nm.includes('trespassar') || nm.includes('varrer')) return 'ANIM_PODER_ATAQUE_EXTRA';
    if (nm.includes('surto heroico') || nm.includes('velocidade')) return 'ANIM_PODER_SURTO_HEROICO';
    if (nm.includes('investida') || nm.includes('bote') || nm.includes('marrada')) return 'ANIM_PODER_INVESTIDA_LANCEIRO';
    if (nm.includes('chifres') || nm.includes('mordida') || nm.includes('arma natural')) return 'ANIM_PODER_CHIFRES_ARMA_NATURAL';
    if (nm.includes('mau cheiro') || nm.includes('veneno') || nm.includes('peçonha')) return 'ANIM_PODER_MAU_CHEIRO_TROG';

    // 2. Magias Específicas do Grimório
    if (nm.includes('bola de fogo') || nm.includes('explosão de chamas') || nm.includes('lança ígnea')) return 'ANIM_MAGIA_BOLA_DE_FOGO';
    if (nm.includes('chuva de meteoros')) return 'ANIM_MAGIA_CHUVA_DE_METEOROS';
    if (nm.includes('relâmpago') || nm.includes('relampago')) return 'ANIM_MAGIA_RELAMPAGO';
    if (nm.includes('toque chocante')) return 'ANIM_MAGIA_TOQUE_CHOCANTE';
    if (nm.includes('seta infalível') || nm.includes('seta infalivel')) return 'ANIM_MAGIA_SETA_INFALIVEL';
    if (nm.includes('toque vampírico') || nm.includes('toque vampirico') || nm.includes('ferver sangue') || nm.includes('drenar')) return 'ANIM_MAGIA_TOQUE_VAMPIRICO';
    if (nm.includes('infligir ferimentos') || nm.includes('assassino fantasmagórico') || nm.includes('crânio voador') || nm.includes('cranio voador')) return 'ANIM_MAGIA_INFLIGIR_FERIMENTOS';
    if (nm.includes('curar ferimentos') || nm.includes('sopro da salvação') || nm.includes('segunda chance') || nm.includes('poção de cura') || nm.includes('curar')) return 'ANIM_MAGIA_CURAR_FERIMENTOS';
    if (nm.includes('oração') || nm.includes('oracao') || nm.includes('bênção') || nm.includes('bencao') || nm.includes('físico divino') || nm.includes('armamento da natureza')) return 'ANIM_MAGIA_ORACAO_BENCAO';
    if (nm.includes('armadura arcana') || nm.includes('escudo da fé') || nm.includes('vestimenta da fé')) return 'ANIM_MAGIA_ARMADURA_ARCANA';
    if (nm.includes('campo de força') || nm.includes('vitalidade fantasma') || nm.includes('proteção divina')) return 'ANIM_MAGIA_CAMPO_DE_FORCA';
    if (nm.includes('concentração de combate') || nm.includes('visão da verdade') || nm.includes('mirar')) return 'ANIM_MAGIA_CONCENTRACAO_COMBATE';

    // 3. Manobras de Combate & Movimento
    if (nm.includes('derrubar')) return 'ANIM_MANOBRA_DERRUBAR';
    if (nm.includes('agarrar') || nm.includes('constrição') || nm.includes('teia')) return 'ANIM_MANOBRA_AGARRAR';
    if (nm.includes('desarmar')) return 'ANIM_MANOBRA_DESARMAR';
    if (nm.includes('empurrar') || nm.includes('golpe avassalador')) return 'ANIM_MANOBRA_EMPURRAR';
    if (nm.includes('quebrar')) return 'ANIM_MANOBRA_QUEBRAR';
    if (nm.includes('fintar')) return 'ANIM_MANOBRA_FINTAR';
    if (cat === 'MOVIMENTO' || nm.includes('movimentar') || nm.includes('flanquear') || nm.includes('avançar') || nm.includes('cobertura')) return 'ANIM_MOVIMENTO_PASSOS';

    // 4. Ataques por Tipo de Arma
    if (arma.includes('montante') || arma.includes('espada bastarda') || arma.includes('espada titânica')) return 'ANIM_ARMA_MONTANTE_COLOSSAL';
    if (arma.includes('machado') || arma.includes('gadanho') || arma.includes('foice')) return 'ANIM_ARMA_MACHADO_GUERRA';
    if (arma.includes('marreta') || arma.includes('martelo') || arma.includes('maça') || arma.includes('tacape') || arma.includes('clava') || arma.includes('bordão')) return 'ANIM_ARMA_MARRETA_IMPACTO';
    if (arma.includes('lança') || arma.includes('alabarda') || arma.includes('pique') || arma.includes('tridente') || arma.includes('florete')) return 'ANIM_ARMA_LANCA_ESTOCADA';
    if (arma.includes('adaga') || arma.includes('espada curta') || arma.includes('katar') || arma.includes('manopla')) return 'ANIM_ARMA_ADAGA_DUPLA';
    if (arma.includes('arco') || arma.includes('besta') || arma.includes('azagaia') || arma.includes('funda')) return 'ANIM_ARMA_ARCO_FLECHA';
    if (arma.includes('mosquete') || arma.includes('pistola')) return 'ANIM_ARMA_MOSQUETE_POLVORA';
    if (arma.includes('cajado')) return 'ANIM_ARMA_CAJADO_ORBE';

    // 5. Assinatura Procedural Única baseada no Hash do Nome da Habilidade/Poder
    let hash = 0;
    for (let i = 0; i < nm.length; i++) {
        hash = ((hash << 5) - hash + nm.charCodeAt(i)) | 0;
    }
    return `ANIM_ASSINATURA_UNICA_${Math.abs(hash % 997)}`;
}

// Intercepta e enriquece `construirCamadaAnimacaoTrajetoria2DSVG` para que CADA habilidade/poder
// renderize sua geometria, partículas, runas, feixes e paleta exclusiva tanto na Arena quanto na Mesa Online!
const _origConstruirCamadaAnimacaoTrajetoria2DSVG_v65 = (typeof construirCamadaAnimacaoTrajetoria2DSVG === 'function')
    ? construirCamadaAnimacaoTrajetoria2DSVG
    : null;

construirCamadaAnimacaoTrajetoria2DSVG = function(cols, rows) {
    const anim = window.__ANIMACAO_PALCO_ATIVA__;
    if (!anim) return '';
    const orig = anim.origem || { gx: 2, gy: 2 };
    const dest = anim.destino || { gx: 5, gy: 2 };
    const p1 = mapearGridParaPalco2DSVG(orig.gx, orig.gy, cols || 12, rows || 7);
    const p2 = mapearGridParaPalco2DSVG(dest.gx, dest.gy, cols || 12, rows || 7);
    const x1 = p1.px, y1 = p1.py - 42;
    const x2 = p2.px, y2 = p2.py - 42;
    const mx = (x1 + x2) / 2, my = Math.min(y1, y2) - 38;
    const tp = String(anim.tipo || 'CORTE').toUpperCase();
    const lbl = anim.label || '';

    let vfxCustom = '';
    if (tp === 'ANIM_PODER_ATAQUE_ESPECIAL') {
        vfxCustom = `
            <circle cx="${x1.toFixed(1)}" cy="${y1.toFixed(1)}" r="26" fill="none" stroke="#38BDF8" stroke-width="3" stroke-dasharray="6 3">
                <animateTransform attributeName="transform" type="rotate" from="0 ${x1.toFixed(1)} ${y1.toFixed(1)}" to="360 ${x1.toFixed(1)} ${y1.toFixed(1)}" dur="0.6s"/>
            </circle>
            <line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="#38BDF8" stroke-width="6"/>
            <g transform="translate(${x2.toFixed(1)}, ${y2.toFixed(1)})">
                <circle cx="0" cy="0" r="32" fill="none" stroke="#FACC15" stroke-width="3"/>
                <line x1="-42" y1="0" x2="42" y2="0" stroke="#38BDF8" stroke-width="4"/>
                <line x1="0" y1="-42" x2="0" y2="42" stroke="#38BDF8" stroke-width="4"/>
                <path d="M -44 -36 L 44 36 M 44 -36 L -44 36" stroke="#FEF08A" stroke-width="8"/>
            </g>
        `;
    } else if (tp === 'ANIM_PODER_GOLPE_PESSOAL') {
        vfxCustom = `
            <polygon points="${(x2-26).toFixed(1)},0 ${(x2+26).toFixed(1)},0 ${(x2+12).toFixed(1)},${(y2+36).toFixed(1)} ${(x2-12).toFixed(1)},${(y2+36).toFixed(1)}" fill="rgba(249,115,22,0.55)" stroke="#FEF08A" stroke-width="3">
                <animate attributeName="opacity" values="1;0.2;1;0" dur="0.85s" fill="freeze"/>
            </polygon>
            <circle cx="${x2.toFixed(1)}" cy="${y2.toFixed(1)}" r="16" fill="rgba(234,88,12,0.65)" stroke="#FACC15" stroke-width="5">
                <animate attributeName="r" values="14;76" dur="0.68s" fill="freeze"/>
                <animate attributeName="opacity" values="1;0" dur="0.68s" fill="freeze"/>
            </circle>
            <polygon points="${x2.toFixed(1)},${(y2-56).toFixed(1)} ${(x2+18).toFixed(1)},${(y2-14).toFixed(1)} ${(x2+56).toFixed(1)},${y2.toFixed(1)} ${(x2+18).toFixed(1)},${(y2+14).toFixed(1)} ${x2.toFixed(1)},${(y2+56).toFixed(1)} ${(x2-18).toFixed(1)},${(y2+14).toFixed(1)} ${(x2-56).toFixed(1)},${y2.toFixed(1)} ${(x2-18).toFixed(1)},${(y2-14).toFixed(1)}" fill="#FEF08A" stroke="#DC2626" stroke-width="3"/>
        `;
    } else if (tp === 'ANIM_PODER_FURIA_BARBARA') {
        vfxCustom = `
            <ellipse cx="${x1.toFixed(1)}" cy="${(y1+12).toFixed(1)}" rx="44" ry="58" fill="rgba(220,38,38,0.45)" stroke="#F97316" stroke-width="4">
                <animate attributeName="rx" values="28;64;44" dur="0.7s"/>
            </ellipse>
            <path d="M ${(x2-48).toFixed(1)} ${(y2-24).toFixed(1)} L ${(x2-24).toFixed(1)} ${(y2+16).toFixed(1)} L ${x2.toFixed(1)} ${(y2-20).toFixed(1)} L ${(x2+24).toFixed(1)} ${(y2+16).toFixed(1)} L ${(x2+48).toFixed(1)} ${(y2-24).toFixed(1)}" fill="none" stroke="#EF4444" stroke-width="8"/>
        `;
    } else if (tp === 'ANIM_PODER_GOLPE_DIVINO') {
        vfxCustom = `
            <rect x="${(x2-18).toFixed(1)}" y="0" width="36" height="${(y2+40).toFixed(1)}" fill="rgba(253,224,71,0.52)"/>
            <g transform="translate(${x2.toFixed(1)}, ${y2.toFixed(1)})">
                <line x1="0" y1="-64" x2="0" y2="54" stroke="#FEF08A" stroke-width="10"/>
                <line x1="-38" y1="-22" x2="38" y2="-22" stroke="#FACC15" stroke-width="8"/>
                <circle cx="0" cy="-22" r="24" fill="none" stroke="#FFFFFF" stroke-width="4">
                    <animate attributeName="r" values="14;64" dur="0.65s" fill="freeze"/>
                </circle>
            </g>
        `;
    } else if (tp === 'ANIM_PODER_ATAQUE_FURTIVO' || tp === 'ANIM_PODER_ASSASSINAR') {
        vfxCustom = `
            <path d="M ${x1.toFixed(1)} ${y1.toFixed(1)} C ${(x1+40).toFixed(1)} ${(y1-60).toFixed(1)}, ${(x2-40).toFixed(1)} ${(y2+60).toFixed(1)}, ${x2.toFixed(1)} ${y2.toFixed(1)}" fill="none" stroke="#A855F7" stroke-width="5" stroke-dasharray="8 4"/>
            <g transform="translate(${x2.toFixed(1)}, ${y2.toFixed(1)})">
                <circle cx="0" cy="0" r="36" fill="rgba(88,28,135,0.58)" stroke="#F43F5E" stroke-width="3.5"/>
                <path d="M -42 -42 L 42 42 M 42 -42 L -42 42" stroke="#F43F5E" stroke-width="9"/>
                <polygon points="0,-24 18,0 0,24 -18,0" fill="#FEF08A"/>
            </g>
        `;
    } else if (tp === 'ANIM_PODER_INSPIRACAO_BARDO' || tp === 'ANIM_MAGIA_ORACAO_BENCAO') {
        vfxCustom = `
            <g transform="translate(${x2.toFixed(1)}, ${y2.toFixed(1)})">
                <circle cx="0" cy="0" r="22" fill="none" stroke="#FDE047" stroke-width="4">
                    <animate attributeName="r" values="16;78" dur="0.75s" fill="freeze"/>
                    <animate attributeName="opacity" values="1;0" dur="0.75s" fill="freeze"/>
                </circle>
                <text x="-28" y="-18" font-size="22" fill="#FDE047"></text>
                <text x="16" y="-26" font-size="20" fill="#38BDF8"></text>
                <text x="-8" y="28" font-size="20" fill="#4ADE80"></text>
            </g>
        `;
    } else if (tp === 'ANIM_PODER_MARCA_DA_PRESA' || tp === 'ANIM_ARMA_ARCO_FLECHA') {
        vfxCustom = `
            <path d="M ${x1.toFixed(1)} ${y1.toFixed(1)} Q ${mx.toFixed(1)} ${(my-18).toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}" fill="none" stroke="#4ADE80" stroke-width="3" stroke-dasharray="8 4"/>
            <g transform="translate(${x2.toFixed(1)}, ${y2.toFixed(1)})">
                <circle cx="0" cy="0" r="28" fill="none" stroke="#4ADE80" stroke-width="3.5"/>
                <circle cx="0" cy="0" r="14" fill="none" stroke="#FEF08A" stroke-width="2.5"/>
                <line x1="-38" y1="0" x2="38" y2="0" stroke="#4ADE80" stroke-width="3"/>
                <line x1="0" y1="-38" x2="0" y2="38" stroke="#4ADE80" stroke-width="3"/>
            </g>
        `;
    } else if (tp === 'ANIM_ARMA_MOSQUETE_POLVORA' || tp === 'ANIM_PODER_ENGENHOCA_INVENTOR') {
        vfxCustom = `
            <circle cx="${x1.toFixed(1)}" cy="${y1.toFixed(1)}" r="22" fill="#F97316" stroke="#FEF08A" stroke-width="4">
                <animate attributeName="r" values="8;34;0" dur="0.45s" fill="freeze"/>
            </circle>
            <line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="#FEF08A" stroke-width="5"/>
            <circle cx="${x2.toFixed(1)}" cy="${y2.toFixed(1)}" r="26" fill="rgba(239,68,68,0.6)" stroke="#FDE047" stroke-width="4">
                <animate attributeName="r" values="10;52" dur="0.5s" fill="freeze"/>
            </circle>
        `;
    } else if (tp === 'ANIM_MAGIA_SETA_INFALIVEL') {
        vfxCustom = [-22, 0, 22].map((dy, idx) => `
            <path d="M ${x1.toFixed(1)} ${(y1+dy).toFixed(1)} Q ${mx.toFixed(1)} ${(my+dy*1.4).toFixed(1)} ${x2.toFixed(1)} ${(y2+dy*0.5).toFixed(1)}" fill="none" stroke="#C084FC" stroke-width="4"/>
            <polygon points="${(x2-14).toFixed(1)},${(y2+dy*0.5-6).toFixed(1)} ${(x2+10).toFixed(1)},${(y2+dy*0.5).toFixed(1)} ${(x2-14).toFixed(1)},${(y2+dy*0.5+6).toFixed(1)}" fill="#38BDF8" stroke="#FFFFFF" stroke-width="1.5"/>
        `).join('');
    } else if (tp === 'ANIM_MAGIA_CHUVA_DE_METEOROS') {
        vfxCustom = [-60, -20, 20, 60].map((dx, i) => `
            <line x1="${(x2+dx-90).toFixed(1)}" y1="0" x2="${(x2+dx).toFixed(1)}" y2="${(y2+18).toFixed(1)}" stroke="#F97316" stroke-width="8"/>
            <circle cx="${(x2+dx).toFixed(1)}" cy="${(y2+18).toFixed(1)}" r="24" fill="rgba(220,38,38,0.65)" stroke="#FEF08A" stroke-width="3">
                <animate attributeName="r" values="10;46" dur="0.65s" fill="freeze"/>
            </circle>
        `).join('');
    } else if (tp === 'ANIM_MAGIA_CURAR_FERIMENTOS') {
        vfxCustom = `
            <g transform="translate(${x2.toFixed(1)}, ${y2.toFixed(1)})">
                <ellipse cx="0" cy="18" rx="38" ry="14" fill="rgba(34,197,94,0.45)" stroke="#4ADE80" stroke-width="3"/>
                <rect x="-8" y="-32" width="16" height="48" rx="3" fill="#4ADE80" stroke="#FEF08A" stroke-width="2"/>
                <rect x="-24" y="-16" width="48" height="16" rx="3" fill="#4ADE80" stroke="#FEF08A" stroke-width="2"/>
            </g>
        `;
    } else if (tp.startsWith('ANIM_MANOBRA_') || tp.startsWith('ANIM_ARMA_') || tp.startsWith('ANIM_ASSINATURA_UNICA_')) {
        // Gera padrão geométrico único determinístico para cada arma/manobra/poder!
        let seedNum = 0;
        for (let i = 0; i < tp.length; i++) seedNum = (seedNum * 31 + tp.charCodeAt(i)) % 360;
        const cor1 = `hsl(${seedNum}, 90%, 60%)`;
        const cor2 = `hsl(${(seedNum + 140) % 360}, 95%, 72%)`;
        const ang = (seedNum % 70) - 35;
        vfxCustom = `
            <path d="M ${x1.toFixed(1)} ${y1.toFixed(1)} Q ${mx.toFixed(1)} ${my.toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}" fill="none" stroke="${cor1}" stroke-width="4" stroke-dasharray="10 4"/>
            <g transform="translate(${x2.toFixed(1)}, ${y2.toFixed(1)}) rotate(${ang})">
                <polygon points="0,-46 14,-14 46,0 14,14 0,46 -14,14 -46,0 -14,-14" fill="none" stroke="${cor2}" stroke-width="4">
                    <animate attributeName="opacity" values="1;0.2;1;0" dur="0.72s" fill="freeze"/>
                </polygon>
                <line x1="-44" y1="-28" x2="44" y2="28" stroke="${cor1}" stroke-width="8"/>
                <circle cx="0" cy="0" r="18" fill="none" stroke="#FFFFFF" stroke-width="3">
                    <animate attributeName="r" values="10;54" dur="0.6s" fill="freeze"/>
                </circle>
            </g>
        `;
    }

    if (vfxCustom) {
        const badgeLbl = lbl ? `
            <rect x="${(mx - 125).toFixed(1)}" y="${Math.max(12, my - 24).toFixed(1)}" width="250" height="21" rx="5" fill="rgba(9, 13, 22, 0.96)" stroke="#FACC15" stroke-width="1.8"/>
            <text x="${mx.toFixed(1)}" y="${Math.max(26, my - 10).toFixed(1)}" text-anchor="middle" font-size="10.2" font-weight="900" fill="#FEF08A">${lbl.slice(0, 38)}</text>
        ` : '';
        return `<g class="camada-animacao-trajetoria-2d" pointer-events="none">${vfxCustom}${badgeLbl}</g>`;
    }

    return _origConstruirCamadaAnimacaoTrajetoria2DSVG_v65 ? _origConstruirCamadaAnimacaoTrajetoria2DSVG_v65(cols, rows) : '';
};

// -----------------------------------------------------------------------------
// 3. MOVIMENTAÇÃO INTERPOLADA PASSO A PASSO E TRILHA VISUAL NO MAPA (v66)
// -----------------------------------------------------------------------------
function construirTrilhaMovimentoAtivaSVG(cols, rows, contexto) {
    const tr = window.__TRILHA_MOVIMENTO_ATIVA__;
    if (!tr || (Date.now() - tr.timestamp > 2400)) return '';
    if (contexto && tr.contexto && tr.contexto !== contexto) return '';
    const p1 = mapearGridParaPalco2DSVG(tr.gxOrig, tr.gyOrig, cols || 12, rows || 7);
    const p2 = mapearGridParaPalco2DSVG(tr.gxDest, tr.gyDest, cols || 12, rows || 7);
    const passos = tr.passos || [];
    const bolinhasSVG = passos.map((pt, idx) => {
        const pm = mapearGridParaPalco2DSVG(pt.gx, pt.gy, cols || 12, rows || 7);
        return `<circle cx="${pm.px.toFixed(1)}" cy="${(pm.py - 6).toFixed(1)}" r="${idx === passos.length - 1 ? 8 : 5}" fill="${idx === passos.length - 1 ? '#4ADE80' : '#38BDF8'}" stroke="#FEF08A" stroke-width="1.8" opacity="0.9"/>`;
    }).join('');
    const mx = (p1.px + p2.px) / 2;
    const my = (p1.py + p2.py) / 2 - 22;
    return `
        <g pointer-events="none">
            <line x1="${p1.px.toFixed(1)}" y1="${(p1.py - 6).toFixed(1)}" x2="${p2.px.toFixed(1)}" y2="${(p2.py - 6).toFixed(1)}" stroke="#4ADE80" stroke-width="3.5" stroke-dasharray="8 5"/>
            ${bolinhasSVG}
            <rect x="${(mx - 68).toFixed(1)}" y="${(my - 14).toFixed(1)}" width="136" height="17" rx="5" fill="rgba(6,78,59,0.95)" stroke="#4ADE80" stroke-width="1.4"/>
            <text x="${mx.toFixed(1)}" y="${(my - 2).toFixed(1)}" text-anchor="middle" font-size="9" font-weight="900" fill="#ECFDF5">Moveu ${tr.distMetros.toFixed(1)}m (${tr.distQ}q)</text>
        </g>
    `;
}

function gerarPassosInterpoladosGrid2D(gx0, gy0, gx1, gy1) {
    const passos = [];
    const dx = gx1 - gx0;
    const dy = gy1 - gy0;
    const n = Math.max(1, Math.min(8, Math.max(Math.abs(dx), Math.abs(dy))));
    for (let i = 1; i <= n; i++) {
        passos.push({
            gx: Math.round(gx0 + (dx * i) / n),
            gy: Math.round(gy0 + (dy * i) / n)
        });
    }
    return passos;
}

// Sobrescreve `moverHeroiParaCelulaGridArenaJS` para animar a trilha e o movimento tanto para o Herói quanto para Ameaça/Aliado selecionado!
const _origMoverHeroiParaCelulaGridArenaJS_v65 = moverHeroiParaCelulaGridArenaJS;
moverHeroiParaCelulaGridArenaJS = function(gx, gy) {
    if (!__ARENA_STATE__) return;
    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    inicializarEncontrosMultiplosEGrid2DArenaJS(a, st);

    const ocupadaIdx = encontrarCelulaCriaturaOcupando2D(a.listaCriaturas, gx, gy);
    if (ocupadaIdx >= 0) {
        selecionarPersonagemNoPalcoParaAcoesJS('AMEACA', ocupadaIdx, 'ARENA');
        return;
    }
    if (a.posHeroi && a.posHeroi.gx === gx && a.posHeroi.gy === gy) {
        selecionarPersonagemNoPalcoParaAcoesJS('HEROI', 'HEROI_PRINCIPAL', 'ARENA');
        return;
    }

    const sel = window.__PERSONAGEM_CLICADO_ARENA__ || { tipo: 'HEROI', id: 'HEROI_PRINCIPAL' };
    if (sel.tipo === 'ALIADO' && a.aliadoFlanqueadorAtivo && a.posAliadoFlanco) {
        const gx0 = a.posAliadoFlanco.gx, gy0 = a.posAliadoFlanco.gy;
        const distQ = Math.max(Math.abs(gx - gx0), Math.abs(gy - gy0));
        window.__TRILHA_MOVIMENTO_ATIVA__ = {
            contexto: 'ARENA', gxOrig: gx0, gyOrig: gy0, gxDest: gx, gyDest: gy,
            distQ, distMetros: distQ * 1.5, passos: gerarPassosInterpoladosGrid2D(gx0, gy0, gx, gy), timestamp: Date.now()
        };
        a.posAliadoFlanco = { gx, gy };
        try { tocarSomPorEfeitoAnimacaoJRPG('ANIM_MOVIMENTO_PASSOS'); } catch(e) {}
        atualizarPlacarVisualArena();
        renderizarPainelAcoesPersonagemClicadoArenaJS();
        return;
    }

    const gx0 = a.posHeroi ? a.posHeroi.gx : 56;
    const gy0 = a.posHeroi ? a.posHeroi.gy : 60;
    const distQ = Math.max(Math.abs(gx - gx0), Math.abs(gy - gy0));
    const passos = gerarPassosInterpoladosGrid2D(gx0, gy0, gx, gy);
    window.__TRILHA_MOVIMENTO_ATIVA__ = {
        contexto: 'ARENA', gxOrig: gx0, gyOrig: gy0, gxDest: gx, gyDest: gy,
        distQ, distMetros: distQ * 1.5, passos, timestamp: Date.now()
    };
    _origMoverHeroiParaCelulaGridArenaJS_v65(gx, gy);
    renderizarPainelAcoesPersonagemClicadoArenaJS();
};

// Sobrescreve `clicarCelulaGrid2DMesaOnlineJS` para animar a trilha e selecionar personagens clicados na Mesa Online!
const _origClicarCelulaGrid2DMesaOnlineJS_v65 = clicarCelulaGrid2DMesaOnlineJS;
clicarCelulaGrid2DMesaOnlineJS = function(gx, gy) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    sincronizarAlvoFocoMesaOnline();
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const parts = m.participantes || [];
    const hClicado = parts.find(p => Number(p.gx) === gx && Number(p.gy) === gy);
    if (hClicado) {
        selecionarPersonagemNoPalcoParaAcoesJS('HEROI_MESA', hClicado.idHeroi, 'MESA');
        return;
    }
    const idxInim = encontrarCelulaCriaturaOcupando2D(m.listaInimigosMesa, gx, gy);
    if (idxInim >= 0) {
        selecionarPersonagemNoPalcoParaAcoesJS('AMEACA_MESA', idxInim, 'MESA');
        return;
    }
    const heroiMov = parts.find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || parts[0];
    if (heroiMov) {
        const gx0 = Number(heroiMov.gx || 54), gy0 = Number(heroiMov.gy || 58);
        const distQ = Math.max(Math.abs(gx - gx0), Math.abs(gy - gy0));
        window.__TRILHA_MOVIMENTO_ATIVA__ = {
            contexto: 'MESA', gxOrig: gx0, gyOrig: gy0, gxDest: gx, gyDest: gy,
            distQ, distMetros: distQ * 1.5, passos: gerarPassosInterpoladosGrid2D(gx0, gy0, gx, gy), timestamp: Date.now()
        };
        dispararAnimacaoCoreografadaPalco2DJS({
            tipo: 'ANIM_MOVIMENTO_PASSOS',
            ladoAlvo: 'HEROI',
            origem: { gx: gx0, gy: gy0 },
            destino: { gx, gy },
            label: `${heroiMov.nome.slice(0, 12)} (${gx + 1},${gy + 1})`
        });
    }
    _origClicarCelulaGrid2DMesaOnlineJS_v65(gx, gy);
    renderizarPainelAcoesPersonagemClicadoMesaJS();
};

// -----------------------------------------------------------------------------
// 4. PAINEL CONTEXTUAL DE AÇÕES AO CLICAR NO PERSONAGEM (ARENA & MESA ONLINE,
//    FUNCIONANDO TANTO NA TELA NORMAL QUANTO NA TELA CHEIA!)
// -----------------------------------------------------------------------------
function selecionarPersonagemNoPalcoParaAcoesJS(tipoEntidade, idOuIndice, contexto) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    if (contexto === 'MESA') {
        window.__PERSONAGEM_CLICADO_MESA__ = { tipo: tipoEntidade, id: idOuIndice };
        if (tipoEntidade === 'HEROI_MESA') {
            HEROI_SELECIONADO_GRID_MESA_ID = String(idOuIndice);
        } else if (tipoEntidade === 'AMEACA_MESA' && ESTADO_MESA_ONLINE_ATUAL) {
            ESTADO_MESA_ONLINE_ATUAL.alvoFocoMesaIdx = Number(idOuIndice || 0);
            sincronizarAlvoFocoMesaOnline();
        }
        renderizarMesaOnlineCompletaUI();
        renderizarPainelAcoesPersonagemClicadoMesaJS();
    } else {
        window.__PERSONAGEM_CLICADO_ARENA__ = { tipo: tipoEntidade, id: idOuIndice };
        if (tipoEntidade === 'AMEACA' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
            __ARENA_STATE__.alvoFocoIdx = Number(idOuIndice || 0);
            sincronizarAlvoFocoComPrivadoArenaJS(__ARENA_STATE__);
        }
        atualizarPlacarVisualArena();
        renderizarPainelAcoesPersonagemClicadoArenaJS();
    }
}

function executarPoderOuAcaoUnicaHeroiArenaJS(codAcao, nomeExibicao, categoria, subtipoArma) {
    if (!__ARENA_STATE__) inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    const codAnim = obterCodigoAnimacaoUnicaPorHabilidadeJS(nomeExibicao, categoria, subtipoArma || (st.arma ? st.arma.nome : ''));
    const focoC = (Array.isArray(a.listaCriaturas) && a.listaCriaturas[a.alvoFocoIdx || 0]) ? a.listaCriaturas[a.alvoFocoIdx || 0] : { gx: 5, gy: 2 };
    const posH = a.posHeroi || { gx: 2, gy: 2 };

    // Executa a mecânica correspondente na Arena e aplica a animação única da habilidade!
    if (codAcao.startsWith('MAGIA_FICHA::')) {
        const nomeMag = codAcao.split('::')[1];
        const selMag = document.getElementById('arena-sel-magia-ficha');
        if (selMag) {
            for (let i = 0; i < selMag.options.length; i++) {
                if (selMag.options[i].value === nomeMag || selMag.options[i].text.includes(nomeMag)) {
                    selMag.selectedIndex = i;
                    aoMudarMagiaSelecionadaArenaJS();
                    break;
                }
            }
        }
        conjurarMagiaComAprimoramentosArenaJS();
    } else if (codAcao.startsWith('MANOBRA::')) {
        const manNome = codAcao.split('::')[1];
        const selMan = document.getElementById('sel-cap5-manobra');
        if (selMan) selMan.value = manNome;
        executarAcaoCombateVisual('MANOBRA_DERRUBAR');
    } else if (codAcao.startsWith('PODER_ATIVO::')) {
        // Ativa o poder/habilidade com rolagem real ou buff + animação única!
        const d1 = Math.floor(Math.random() * 20) + 1;
        const bAtq = (st.est && st.est.ataqueBonus) ? st.est.ataqueBonus : (st.nivel + 4);
        const tot = d1 + bAtq;
        if (a.pmHeroi >= 1) a.pmHeroi = Math.max(0, a.pmHeroi - 1);
        registrarLinhaLogArena(`<strong>[Poder/Habilidade Única: ${nomeExibicao}]</strong> ${st.nome} ativou <strong>${nomeExibicao}</strong> (Rolagem: 1d20(${d1})+${bAtq} = <strong>${tot}</strong>)!`);
        const pill = document.getElementById('arena-fullscreen-live-roll-pill');
        if (pill) pill.innerHTML = `<strong>${nomeExibicao}:</strong> 1d20(${d1})+${bAtq} = ${tot}`;
        atualizarPlacarVisualArena();
    } else {
        executarAcaoCombateVisual(codAcao);
    }

    // Dispara a assinatura visual única para que cada ação/poder tenha animação própria!
    dispararAnimacaoCoreografadaPalco2DJS({
        tipo: codAnim,
        ladoAlvo: (categoria === 'BUFF' || categoria === 'DEFESA' || categoria === 'MOVIMENTO') ? 'HEROI' : 'INIMIGO',
        origem: { gx: posH.gx, gy: posH.gy },
        destino: (categoria === 'BUFF' || categoria === 'DEFESA' || categoria === 'MOVIMENTO') ? { gx: posH.gx, gy: posH.gy } : { gx: focoC.gx, gy: focoC.gy },
        label: `${nomeExibicao}`
    });
    renderizarPainelAcoesPersonagemClicadoArenaJS();
}

function renderizarPainelAcoesPersonagemClicadoArenaJS() {
    const box = document.getElementById('arena-clicked-character-actions-bar');
    if (typeof __ARENA_STATE__ === 'undefined' || !__ARENA_STATE__) { if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario(); }
    if (!box || typeof __ARENA_STATE__ === 'undefined' || !__ARENA_STATE__) return;
    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    const sel = window.__PERSONAGEM_CLICADO_ARENA__ || { tipo: 'HEROI', id: 'HEROI_PRINCIPAL' };
    const listaCriaturas = Array.isArray(a.listaCriaturas) ? a.listaCriaturas : [];
    const focoIdx = Math.min(Math.max(0, Number(a.alvoFocoIdx || 0)), Math.max(0, listaCriaturas.length - 1));
    const crFoco = listaCriaturas[focoIdx] || null;

    // Barra seletora rápida de quem está inspecionado/controlado no Palco
    const seletorTokensHTML = `
        <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:10.5px;font-weight:900;color:#93C5FD;">Personagem Clicado:</span>
            <button type="button" class="btn-roll-inline" style="background:${sel.tipo === 'HEROI' ? '#15803D' : '#1E293B'};border-color:${sel.tipo === 'HEROI' ? '#4ADE80' : '#475569'};font-weight:900;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI', 'HEROI_PRINCIPAL', 'ARENA')">
                ${st.nome.slice(0, 14)} (Herói)
            </button>
            ${a.aliadoFlanqueadorAtivo ? `
            <button type="button" class="btn-roll-inline" style="background:${sel.tipo === 'ALIADO' ? '#0369A1' : '#1E293B'};border-color:${sel.tipo === 'ALIADO' ? '#38BDF8' : '#475569'};font-weight:900;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('ALIADO', 'ALIADO_FLANCO', 'ARENA')">
                Aliado Flanqueador
            </button>` : ''}
            ${listaCriaturas.map((cr, idx) => `
                <button type="button" class="btn-roll-inline" style="background:${(sel.tipo === 'AMEACA' && Number(sel.id) === idx) ? '#991B1B' : '#1E293B'};border-color:${idx === focoIdx ? '#FACC15' : '#EF4444'};font-weight:900;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA', ${idx}, 'ARENA')">
                    ${cr.rotulo} ${cr.nomeCriatura.slice(0, 14)} (${Math.max(0, cr.pvAtual)}/${cr.pvMax})
                </button>
            `).join('')}
        </div>
    `;

    if (sel.tipo === 'AMEACA' && crFoco) {
        const priv = a._privadoCriatura;
        const rep = (priv && Array.isArray(priv.repertorioAcoes)) ? priv.repertorioAcoes : extrairRepertorioAcoesCriaturaJS(priv);
        const btnsAmeaca = rep.map((ac, idxA) => `
            <button type="button" class="t20-action-chip-btn" style="background:linear-gradient(135deg,#7F1D1D,#991B1B);border-color:#FACC15;"
                    onclick="executarTurnoDaCriaturaArenaJS(${idxA})">
                <span>${ac.icone || ''}</span>
                <span>${ac.nome.slice(0, 34)}</span>
            </button>
        `).join('');
        box.innerHTML = `
            <div class="t20-clicked-char-dock">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;padding-bottom:5px;border-bottom:1px solid rgba(250,204,21,0.3);">
                    ${seletorTokensHTML}
                    <div style="font-size:11px;color:#FCA5A5;font-weight:900;">
                        Ações Possíveis de ${crFoco.nomeCriatura} (ND ${crFoco.ndTexto} · ${crFoco.papel} · ${crFoco.tamanhoCat} ${crFoco.espacoQ}x${crFoco.espacoQ})
                    </div>
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                    ${btnsAmeaca}
                    <button type="button" class="t20-action-chip-btn" style="background:#450A0A;border-color:#FCA5A5;" onclick="removerCriaturaDoEncontroArenaJS(${focoIdx})">
                        Excluir Esta Ameaça
                    </button>
                </div>
            </div>
        `;
        return;
    }

    if (sel.tipo === 'ALIADO') {
        box.innerHTML = `
            <div class="t20-clicked-char-dock">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;padding-bottom:5px;border-bottom:1px solid rgba(56,189,248,0.3);">
                    ${seletorTokensHTML}
                    <div style="font-size:11px;color:#7DD3FC;font-weight:900;">Ações Possíveis do Aliado Flanqueador (Toque no chão p/ mover o Aliado!)</div>
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                    <button type="button" class="t20-action-chip-btn" style="background:#0369A1;" onclick="posicionarRapidoArena2DJS('FLANQUEAR_ALIADO')">Cercar Alvo p/ Flanquear (+2 Atq)</button>
                    <button type="button" class="t20-action-chip-btn" style="background:#047857;" onclick="usarCuraParceiroMedicoArenaJS()">Auxílio Médico (+PV)</button>
                    <button type="button" class="t20-action-chip-btn" style="background:#1E3A8A;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI', 'HEROI_PRINCIPAL', 'ARENA')">Voltar p/ Ações do Herói</button>
                </div>
            </div>
        `;
        return;
    }

    // Caso padrão: HERÓI CLICADO — monta TODOS os ataques, habilidades de classe/raça, poderes da ficha, magias e manobras com animação única!
    const armaNome = (st.arma && st.arma.nome) ? st.arma.nome : 'Espada Longa';
    const todosPods = [
        ...((st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ];
    const magias = st.magias || [];

    const botoesAtaques = `
        <button type="button" class="t20-action-chip-btn" style="background:linear-gradient(135deg,#991B1B,#B91C1C);"
                onclick="executarPoderOuAcaoUnicaHeroiArenaJS('ATAQUE_PADRAO', 'Agredir: ${armaNome.replace(/'/g, '')}', 'ATAQUE', '${armaNome.replace(/'/g, '')}')">
            Agredir (${armaNome})
        </button>
        <button type="button" class="t20-action-chip-btn" style="background:linear-gradient(135deg,#9A3412,#C2410C);"
                onclick="executarPoderOuAcaoUnicaHeroiArenaJS('ATAQUE_ESPECIAL_COMBO', 'Ataque Especial / Hab. Classe', 'PODER', '${armaNome.replace(/'/g, '')}')">
            Hab. Classe (${st.classe.nome})
        </button>
        <button type="button" class="t20-action-chip-btn" style="background:linear-gradient(135deg,#7C2D12,#B45309);"
                onclick="executarPoderOuAcaoUnicaHeroiArenaJS('INVESTIDA_COMPLETA', 'Investida Completa (+2 Atq)', 'ATAQUE', '${armaNome.replace(/'/g, '')}')">
            Investida (+2 Atq)
        </button>
        <button type="button" class="t20-action-chip-btn" style="background:linear-gradient(135deg,#B45309,#DC2626);border-color:#FEF08A;"
                onclick="executarPoderOuAcaoUnicaHeroiArenaJS('COMBO_OFENSIVO_TOTAL', 'Combo Ofensivo Máximo', 'PODER', '${armaNome.replace(/'/g, '')}')">
            Combo Total
        </button>
    `;

    const botoesPoderesFicha = todosPods.slice(0, 8).map(p => {
        const nmP = (p.nome || 'Poder').replace(/'/g, '');
        return `
            <button type="button" class="t20-action-chip-btn" style="background:linear-gradient(135deg,#1E3A8A,#312E81);border-color:#93C5FD;"
                    title="${(p.efeito || p.efeito_resumo || '').replace(/"/g, '&quot;')}"
                    onclick="executarPoderOuAcaoUnicaHeroiArenaJS('PODER_ATIVO::${nmP}', '${nmP}', 'PODER', '${armaNome.replace(/'/g, '')}')">
                ${nmP}
            </button>
        `;
    }).join('');

    const botoesMagiasFicha = magias.slice(0, 6).map(m => {
        const nmM = (m.nome || 'Magia').replace(/'/g, '');
        return `
            <button type="button" class="t20-action-chip-btn" style="background:linear-gradient(135deg,#581C87,#7E22CE);border-color:#D8B4FE;"
                    onclick="executarPoderOuAcaoUnicaHeroiArenaJS('MAGIA_FICHA::${nmM}', 'Magia: ${nmM}', 'MAGIA', 'Cajado')">
                ${nmM} (${m.circulo}ºC)
            </button>
        `;
    }).join('');

    const botoesMovManobras = `
        <button type="button" class="t20-action-chip-btn" style="background:#065F46;border-color:#34D399;"
                onclick="posicionarRapidoArena2DJS('AVANCAR_CAC')">
            Avançar Corpo a Corpo
        </button>
        <button type="button" class="t20-action-chip-btn" style="background:#047857;border-color:#6EE7B7;"
                onclick="posicionarRapidoArena2DJS('FLANQUEAR_ALIADO')">
            Flanquear (+2 Atq)
        </button>
        <button type="button" class="t20-action-chip-btn" style="background:#1E40AF;border-color:#60A5FA;"
                onclick="executarPoderOuAcaoUnicaHeroiArenaJS('MANOBRA::Derrubar', 'Manobra Derrubar', 'MANOBRA', '')">
            Derrubar
        </button>
        <button type="button" class="t20-action-chip-btn" style="background:#701A75;border-color:#E879F9;"
                onclick="executarPoderOuAcaoUnicaHeroiArenaJS('FINTAR_DESPREVENIDO', 'Fintar (Alvo Desprevenido)', 'MANOBRA', '')">
            Fintar
        </button>
        <button type="button" class="t20-action-chip-btn" style="background:#0F766E;border-color:#5EEAD4;"
                onclick="ajustarRecursoRapidoPersonagemArenaJS('POCAO_CURA')">
            Poção (+PV)
        </button>
    `;

    box.innerHTML = `
        <div class="t20-clicked-char-dock">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;padding-bottom:5px;border-bottom:1px solid rgba(250,204,21,0.3);">
                ${seletorTokensHTML}
                <div style="font-size:11px;color:#FDE047;font-weight:900;">
                    Ações Possíveis de ${st.nome} (${st.raca.nome} ${st.classe.nome} Nv ${st.nivel}) — Cada habilidade possui animação única!
                </div>
            </div>
            <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                ${botoesAtaques}
                ${botoesPoderesFicha}
                ${botoesMagiasFicha}
                ${botoesMovManobras}
            </div>
        </div>
    `;
}

// -----------------------------------------------------------------------------
// 5. REPERTÓRIO INDIVIDUALIZADO DE AÇÕES E PODERES DE CADA PERSONAGEM NA MESA ONLINE
//    (AO CLICAR NO PERSONAGEM NO MAPA OU EM TELA CHEIA, EXIBE SUAS AÇÕES ÚNICAS!)
// -----------------------------------------------------------------------------
function obterRepertorioAcoesCompletasPersonagemMesaJS(p) {
    if (!p) return [];
    const cls = String(p.classe || 'Guerreiro').toLowerCase();
    const raca = String(p.raca || 'Humano').toLowerCase();
    const arma = p.arma || (cls.includes('arcan') ? 'Cajado Arcano' : (cls.includes('clérigo') || cls.includes('clerigo') ? 'Maça Sagrada' : (cls.includes('ladino') ? 'Adagas Duplas' : 'Espada Bastarda')));
    const acoes = [];

    // 1. Ataque de Arma Principal
    acoes.push({
        cod: 'ATAQUE_ARMA',
        icone: '',
        nome: `Agredir (${arma})`,
        custoPM: 0,
        cor: '#B91C1C',
        categoria: 'ATAQUE',
        arma: arma,
        desc: `Ataque padrão com ${arma} (+${p.ataqueBonus || 12} vs Defesa)`
    });

    // 2. Habilidades Específicas da Classe do Personagem na Mesa Online
    if (cls.includes('guerreiro')) {
        acoes.push(
            { cod: 'HAB_ATAQUE_ESPECIAL', icone: '', nome: 'Ataque Especial (+4 Atq/Dano)', custoPM: 1, cor: '#9A3412', categoria: 'PODER', arma, desc: 'Soma +4 no teste de ataque e no dano!' },
            { cod: 'HAB_GOLPE_PESSOAL', icone: '', nome: 'Golpe Pessoal Brutal (2d20)', custoPM: 3, cor: '#B45309', categoria: 'PODER', arma, desc: 'Rola 2d20 (escolhe o melhor) e +2d6 dano elemental!' },
            { cod: 'HAB_DURAO', icone: '', nome: 'Durão (Metade do Dano)', custoPM: 3, cor: '#065F46', categoria: 'DEFESA', arma, desc: 'Reduz o próximo dano sofrido à metade!' },
            { cod: 'MANOBRA_DERRUBAR', icone: '', nome: 'Manobra Derrubar', custoPM: 0, cor: '#1E40AF', categoria: 'MANOBRA', arma, desc: 'Derruba a ameaça (Caído: -5 Ataque e -5 Defesa CaC)!' }
        );
    } else if (cls.includes('arcanista') || cls.includes('mago') || cls.includes('feiticeiro') || cls.includes('bruxo')) {
        acoes.push(
            { cod: 'MAGIA_BOLA_DE_FOGO', icone: '', nome: 'Bola de Fogo (8d6 Fogo Área)', custoPM: 3, cor: '#C2410C', categoria: 'MAGIA', arma: 'Cajado', desc: 'Explosão de fogo em área atingindo todas as ameaças!' },
            { cod: 'MAGIA_RELAMPAGO', icone: '', nome: 'Relâmpago (8d6 Eletricidade)', custoPM: 3, cor: '#0284C7', categoria: 'MAGIA', arma: 'Cajado', desc: 'Dispara raio de alta voltagem na ameaça!' },
            { cod: 'MAGIA_SETA_INFALIVEL', icone: '', nome: 'Seta Infalível de Talude', custoPM: 1, cor: '#6D28D9', categoria: 'MAGIA', arma: 'Cajado', desc: 'Lanças de essência mágica com acerto automático!' },
            { cod: 'MAGIA_CAMPO_DE_FORCA', icone: '', nome: 'Campo de Força (+30 PV Temp)', custoPM: 3, cor: '#4C1D95', categoria: 'BUFF', arma: 'Cajado', desc: 'Cria esfera protetora de força arcana!' },
            { cod: 'MAGIA_VELOCIDADE', icone: '', nome: 'Velocidade (+Ação p/ Aliado)', custoPM: 3, cor: '#B45309', categoria: 'BUFF', arma: 'Cajado', desc: 'Acelera o grupo com bônus tático!' }
        );
    } else if (cls.includes('clérigo') || cls.includes('clerigo')) {
        acoes.push(
            { cod: 'MAGIA_CURAR_FERIMENTOS', icone: '', nome: 'Curar Ferimentos (4d8+4 PV)', custoPM: 2, cor: '#047857', categoria: 'CURA', arma: 'Símbolo Sagrado', desc: 'Restaura PV do aliado mais ferido do grupo!' },
            { cod: 'MAGIA_ORACAO', icone: '', nome: 'Oração (+2 Atq/Dano/Res Grupo)', custoPM: 3, cor: '#B45309', categoria: 'BUFF', arma: 'Símbolo Sagrado', desc: 'Fortalece todos os heróis da Mesa Online com +2 e penaliza inimigos!' },
            { cod: 'MAGIA_INFLIGIR_FERIMENTOS', icone: '', nome: 'Infligir Ferimentos (5d8 Trevas)', custoPM: 3, cor: '#581C87', categoria: 'MAGIA', arma: 'Maça', desc: 'Canaliza energia divina destrutiva contra o alvo!' },
            { cod: 'MAGIA_ESCUDO_DA_FE', icone: '', nome: 'Escudo da Fé (+3 Defesa)', custoPM: 1, cor: '#0369A1', categoria: 'DEFESA', arma: 'Símbolo Sagrado', desc: 'Halo sagrado que protege o grupo!' }
        );
    } else if (cls.includes('ladino') || cls.includes('caçador') || cls.includes('cacador') || cls.includes('bucaneiro')) {
        acoes.push(
            { cod: 'HAB_ATAQUE_FURTIVO', icone: '', nome: 'Ataque Furtivo Letal (+5d6)', custoPM: 1, cor: '#581C87', categoria: 'PODER', arma: 'Adaga', desc: 'Golpe preciso nos pontos vitais do inimigo flanqueado/desprevenido!' },
            { cod: 'HAB_ASSASSINAR', icone: '', nome: 'Assassinar (Dobra Furtivo)', custoPM: 3, cor: '#7F1D1D', categoria: 'PODER', arma: 'Adaga', desc: 'Estuda o alvo e desfere execução devastadora!' },
            { cod: 'HAB_MARCA_DA_PRESA', icone: '', nome: 'Marca da Presa (+2d8 Dano)', custoPM: 2, cor: '#065F46', categoria: 'PODER', arma: 'Arco', desc: 'Analisa o ponto fraco da criatura para disparos letais!' },
            { cod: 'MOV_FLANQUEAR', icone: '', nome: 'Acrobacia p/ Flanquear (+2)', custoPM: 0, cor: '#1E3A8A', categoria: 'MOVIMENTO', arma, desc: 'Salta para o flanco oposto da ameaça!' }
        );
    } else if (cls.includes('paladino') || cls.includes('cavaleiro')) {
        acoes.push(
            { cod: 'HAB_GOLPE_DIVINO', icone: '', nome: 'Golpe Divino (+CAR Atq e +2d8 Luz)', custoPM: 2, cor: '#B45309', categoria: 'PODER', arma, desc: 'Canaliza luz sagrada na lâmina contra a ameaça!' },
            { cod: 'HAB_BALUARTE_PROVOCAR', icone: '', nome: 'Baluarte & Provocar Chefe', custoPM: 2, cor: '#1D4ED8', categoria: 'DEFESA', arma, desc: 'Aumenta a Defesa e atrai os ataques do Chefe para proteger o grupo!' },
            { cod: 'HAB_CURA_PELAS_MAOS', icone: '', nome: 'Cura pelas Mãos (2d8+2 PV)', custoPM: 1, cor: '#047857', categoria: 'CURA', arma, desc: 'Toque sagrado que restaura PV de um aliado!' }
        );
    } else if (cls.includes('bárbaro') || cls.includes('barbaro') || cls.includes('lutador')) {
        acoes.push(
            { cod: 'HAB_FURIA_BARBARA', icone: '', nome: 'Fúria Selvagem (+4 Atq/Dano)', custoPM: 2, cor: '#991B1B', categoria: 'PODER', arma, desc: 'Entra em fúria sanguinária causando dano brutal!' },
            { cod: 'HAB_GOLPE_RELAMPAGO', icone: '', nome: 'Golpe Relâmpago / Ataque Extra', custoPM: 1, cor: '#C2410C', categoria: 'PODER', arma, desc: 'Desfere sequência explosiva de golpes extras!' }
        );
    } else {
        acoes.push(
            { cod: 'HAB_INSPIRACAO_BARDO', icone: '', nome: 'Inspiração / Gritar Ordens (+2 Grupo)', custoPM: 2, cor: '#B45309', categoria: 'BUFF', arma, desc: 'Inspira todos os aliados da Mesa Online com +2 em ataque e dano!' },
            { cod: 'HAB_ENGENHOCA_INVENTOR', icone: '', nome: 'Disparar Engenhoca Arcana', custoPM: 2, cor: '#0284C7', categoria: 'PODER', arma, desc: 'Ativa engenhoca de dano em área!' }
        );
    }

    // 3. Se este herói for o personagem principal da Ficha, inclui também os poderes e magias personalizados da Ficha!
    const stFicha = (typeof garantirEstadoFichaParaArena === 'function') ? garantirEstadoFichaParaArena() : null;
    if (stFicha && p.nome && stFicha.nome && p.nome.toLowerCase().includes(stFicha.nome.toLowerCase().slice(0, 6))) {
        (stFicha.poderes || []).slice(0, 4).forEach(pod => {
            if (!acoes.some(a => a.nome.toLowerCase().includes((pod.nome || '').toLowerCase()))) {
                acoes.push({
                    cod: `PODER_FICHA::${pod.nome}`,
                    icone: '',
                    nome: pod.nome,
                    custoPM: 1,
                    cor: '#312E81',
                    categoria: 'PODER',
                    arma,
                    desc: pod.efeito || pod.efeito_resumo || 'Poder ativo da sua Ficha!'
                });
            }
        });
        (stFicha.magias || []).slice(0, 4).forEach(mag => {
            if (!acoes.some(a => a.nome.toLowerCase().includes((mag.nome || '').toLowerCase()))) {
                acoes.push({
                    cod: `MAGIA_FICHA::${mag.nome}`,
                    icone: '',
                    nome: `${mag.nome} (${mag.circulo}ºC)`,
                    custoPM: Math.max(1, mag.circulo),
                    cor: '#6D28D9',
                    categoria: 'MAGIA',
                    arma: 'Cajado',
                    desc: mag.efeito_e_aprimoramentos || 'Magia da sua Ficha!'
                });
            }
        });
    }

    // 4. Ações universais de movimentação e recuperação
    acoes.push(
        { cod: 'MOV_FLANQUEAR_AUTO', icone: '', nome: 'Posicionar p/ Flanquear (+2)', custoPM: 0, cor: '#0F766E', categoria: 'MOVIMENTO', arma, desc: 'Move para cercar a ameaça em flanco!' },
        { cod: 'ITEM_POCAO_CURA', icone: '', nome: 'Poção de Cura (+2d8+2 PV)', custoPM: 0, cor: '#15803D', categoria: 'CURA', arma, desc: 'Bebe poção de cura imediatamente!' }
    );
    return acoes;
}

function executarAcaoEspecificaPersonagemMesaOnlineJS(idHeroi, codAcao, nomeAcao, custoPM, categoria, armaNome) {
    if (!ESTADO_MESA_ONLINE_ATUAL) return;
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const parts = m.participantes || [];
    const h = parts.find(p => p.idHeroi === idHeroi) || parts[0];
    if (!h) return;
    HEROI_SELECIONADO_GRID_MESA_ID = h.idHeroi;

    const inimigos = m.listaInimigosMesa || [];
    const focoIdx = Math.min(Math.max(0, Number(m.alvoFocoMesaIdx || 0)), Math.max(0, inimigos.length - 1));
    const alvo = inimigos[focoIdx] || { gx: 5, gy: 2, nome: m.chefe ? m.chefe.nome : 'Chefe' };

    const codAnim = obterCodigoAnimacaoUnicaPorHabilidadeJS(nomeAcao, categoria, armaNome || '');

    // Executa a resolução mecânica na Mesa Online
    if (codAcao === 'MOV_FLANQUEAR_AUTO' || codAcao === 'MOV_FLANQUEAR') {
        posicionarGrupoFlanqueamentoAutomaticoMesaJS();
    } else if (codAcao === 'ITEM_POCAO_CURA' || categoria === 'CURA') {
        executarAcaoHeroiMesaOnlineJS(h.idHeroi, 'CURAR_ALIADO');
    } else if (categoria === 'BUFF') {
        executarAcaoHeroiMesaOnlineJS(h.idHeroi, 'BUFF_GRUPO');
    } else if (codAcao === 'HAB_BALUARTE_PROVOCAR' || categoria === 'DEFESA') {
        executarAcaoHeroiMesaOnlineJS(h.idHeroi, 'PROVOCAR_TANQUE');
    } else if (categoria === 'MAGIA' || codAcao.startsWith('MAGIA_')) {
        executarAcaoHeroiMesaOnlineJS(h.idHeroi, 'MAGIA_OFENSIVA');
    } else {
        executarAcaoHeroiMesaOnlineJS(h.idHeroi, 'ATAQUE');
    }

    // Dispara a animação única daquela ação/habilidade no palco da Mesa Online!
    dispararAnimacaoCoreografadaPalco2DJS({
        tipo: codAnim,
        ladoAlvo: (categoria === 'BUFF' || categoria === 'CURA' || categoria === 'DEFESA' || categoria === 'MOVIMENTO') ? 'HEROI' : 'INIMIGO',
        origem: { gx: Number(h.gx || 2), gy: Number(h.gy || 2) },
        destino: (categoria === 'BUFF' || categoria === 'CURA' || categoria === 'DEFESA' || categoria === 'MOVIMENTO')
            ? { gx: Number(h.gx || 2), gy: Number(h.gy || 2) }
            : { gx: Number(alvo.gx || 5), gy: Number(alvo.gy || 2) },
        label: `${h.nome.slice(0, 10)}: ${nomeAcao.slice(0, 22)}`
    });

    const pillMesa = document.getElementById('mesa-fullscreen-live-roll-pill');
    if (pillMesa) {
        pillMesa.innerHTML = `<strong>${h.nome}:</strong> executou <strong>${nomeAcao}</strong> [Animação: ${codAnim.replace('ANIM_', '')}]!`;
    }
    renderizarPainelAcoesPersonagemClicadoMesaJS();
}

function renderizarPainelAcoesPersonagemClicadoMesaJS() {
    const box = document.getElementById('mesa-clicked-character-actions-bar');
    if (!ESTADO_MESA_ONLINE_ATUAL && typeof criarEstadoInicialMesaOnline === 'function') ESTADO_MESA_ONLINE_ATUAL = criarEstadoInicialMesaOnline('VALKARIA-2026');
    if (!box || !ESTADO_MESA_ONLINE_ATUAL) return;
    const m = ESTADO_MESA_ONLINE_ATUAL;
    const parts = m.participantes || [];
    const inimigos = m.listaInimigosMesa || [];
    if (!HEROI_SELECIONADO_GRID_MESA_ID && parts[0]) {
        HEROI_SELECIONADO_GRID_MESA_ID = parts[0].idHeroi;
    }
    const sel = window.__PERSONAGEM_CLICADO_MESA__ || { tipo: 'HEROI_MESA', id: HEROI_SELECIONADO_GRID_MESA_ID };
    const heroiAtivo = parts.find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || parts[0];
    const focoIdx = Math.min(Math.max(0, Number(m.alvoFocoMesaIdx || 0)), Math.max(0, inimigos.length - 1));
    const inimFoco = inimigos[focoIdx] || null;

    // Atualiza também a barra superior fixa da Tela Cheia da Mesa Online (#mesa-fullscreen-sticky-hero-stats)
    const stickyMesa = document.getElementById('mesa-fullscreen-sticky-hero-stats');
    if (stickyMesa && heroiAtivo) {
        stickyMesa.innerHTML = `
            <span style="color:#FDE047;font-weight:900;">${heroiAtivo.nome} (${heroiAtivo.raca || 'Humano'} ${heroiAtivo.classe || 'Guerreiro'} Nv ${heroiAtivo.nivel || 5})</span>
            <span style="background:#065F46;color:#A7F3D0;padding:2px 6px;border-radius:5px;font-weight:900;">${heroiAtivo.pvAtual}/${heroiAtivo.pvMax} PV</span>
            <span style="background:#0369A1;color:#E0F2FE;padding:2px 6px;border-radius:5px;font-weight:900;">${heroiAtivo.pmAtual}/${heroiAtivo.pmMax} PM</span>
            <span style="background:#1E293B;color:#93C5FD;padding:2px 6px;border-radius:5px;font-weight:900;">Def ${heroiAtivo.defesa || 20}</span>
        `;
    }

    const seletorTokensMesaHTML = `
        <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:10.5px;font-weight:900;color:#93C5FD;">Clique no Personagem:</span>
            ${parts.map(p => {
                const ehSel = (sel.tipo === 'HEROI_MESA' && p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID);
                return `
                    <button type="button" class="btn-roll-inline" style="background:${ehSel ? '#15803D' : '#1E293B'};border-color:${ehSel ? '#4ADE80' : '#475569'};font-weight:900;padding:3px 8px;"
                            onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI_MESA', '${p.idHeroi}', 'MESA')">
                        ${p.nome.slice(0, 11)} (${p.classe ? p.classe.slice(0, 6) : 'Herói'})
                    </button>
                `;
            }).join('')}
            ${inimigos.map((cr, idx) => {
                const ehSel = (sel.tipo === 'AMEACA_MESA' && Number(sel.id) === idx);
                return `
                    <button type="button" class="btn-roll-inline" style="background:${ehSel ? '#991B1B' : '#1E293B'};border-color:${idx === focoIdx ? '#FACC15' : '#EF4444'};font-weight:900;padding:3px 8px;"
                            onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA_MESA', ${idx}, 'MESA')">
                        ${cr.rotulo} ${cr.nome.slice(0, 12)} (${Math.max(0, cr.pvAtual)}/${cr.pvMax})
                    </button>
                `;
            }).join('')}
        </div>
    `;

    if (sel.tipo === 'AMEACA_MESA' && inimFoco) {
        box.innerHTML = `
            <div class="t20-clicked-char-dock">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;padding-bottom:5px;border-bottom:1px solid rgba(250,204,21,0.3);">
                    ${seletorTokensMesaHTML}
                    <div style="font-size:11px;color:#FCA5A5;font-weight:900;">
                        Ações Possíveis de ${inimFoco.nome} (ND ${inimFoco.nd} · Def ${inimFoco.defesa} · Atq +${inimFoco.ataque} · Dano ${inimFoco.danoMedio})
                    </div>
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                    <button type="button" class="t20-action-chip-btn" style="background:#7F1D1D;border-color:#FACC15;"
                            onclick="executarTurnoDoChefeMesaOnlineJS('FOCO_TANQUE');dispararAnimacaoCoreografadaPalco2DJS({tipo:'ANIM_INIMIGO_GARRAS_MORDIDA',ladoAlvo:'HEROI',origem:{gx:${inimFoco.gx||5},gy:${inimFoco.gy||2}},destino:{gx:${heroiAtivo?heroiAtivo.gx:2},gy:${heroiAtivo?heroiAtivo.gy:2}},label:'Ataque: ${inimFoco.nome.slice(0,16)}'})">
                        Ataque Principal (${inimFoco.ataquesTexto ? inimFoco.ataquesTexto.slice(0, 32) : '+' + inimFoco.ataque})
                    </button>
                    <button type="button" class="t20-action-chip-btn" style="background:#9A3412;border-color:#FDE047;"
                            onclick="executarTurnoDoChefeMesaOnlineJS('AREA_GRUPO');dispararAnimacaoCoreografadaPalco2DJS({tipo:'ANIM_INIMIGO_SOPRO',ladoAlvo:'HEROI',origem:{gx:${inimFoco.gx||5},gy:${inimFoco.gy||2}},destino:{gx:${heroiAtivo?heroiAtivo.gx:2},gy:${heroiAtivo?heroiAtivo.gy:2}},label:'Sopro/Área: ${inimFoco.nome.slice(0,14)}'})">
                        Habilidade Especial / Sopro em Área (CD ${inimFoco.cdEfeito || 20})
                    </button>
                    <button type="button" class="t20-action-chip-btn" style="background:#450A0A;border-color:#FCA5A5;"
                            onclick="removerCriaturaDoEncontroMesaOnlineJS(${focoIdx})">
                        Excluir Esta Ameaça
                    </button>
                </div>
            </div>
        `;
        return;
    }

    if (!heroiAtivo) return;
    const acoesHeroi = obterRepertorioAcoesCompletasPersonagemMesaJS(heroiAtivo);
    const botoesHTML = acoesHeroi.map(ac => `
        <button type="button" class="t20-action-chip-btn" style="background:${ac.cor};"
                title="${(ac.desc || '').replace(/"/g, '&quot;')}"
                onclick="executarAcaoEspecificaPersonagemMesaOnlineJS('${heroiAtivo.idHeroi}', '${ac.cod.replace(/'/g, '')}', '${ac.nome.replace(/'/g, '')}', ${ac.custoPM || 0}, '${ac.categoria}', '${(ac.arma || '').replace(/'/g, '')}')">
            <span>${ac.icone}</span>
            <span>${ac.nome}</span>
            ${ac.custoPM > 0 ? `<span style="background:rgba(0,0,0,0.45);padding:1px 4px;border-radius:4px;font-size:9.5px;color:#7DD3FC;">${ac.custoPM}PM</span>` : ''}
        </button>
    `).join('');

    box.innerHTML = `
        <div class="t20-clicked-char-dock">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;padding-bottom:5px;border-bottom:1px solid rgba(250,204,21,0.3);">
                ${seletorTokensMesaHTML}
                <div style="font-size:11px;color:#FDE047;font-weight:900;">
                    Ações Possíveis de ${heroiAtivo.nome} (${heroiAtivo.raca || 'Humano'} ${heroiAtivo.classe || 'Guerreiro'} Nv ${heroiAtivo.nivel || 5} · ${heroiAtivo.pvAtual}/${heroiAtivo.pvMax} · ${heroiAtivo.pmAtual}/${heroiAtivo.pmMax})
                </div>
            </div>
            <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                ${botoesHTML}
            </div>
        </div>
    `;
}

// Garante que sempre que a Arena ou a Mesa Online atualizarem, a barra de ações do personagem clicado também seja renderizada!
const _origAtualizarPlacarVisualArena_v65 = atualizarPlacarVisualArena;
atualizarPlacarVisualArena = function() {
    _origAtualizarPlacarVisualArena_v65();
    try { renderizarPainelAcoesPersonagemClicadoArenaJS(); } catch(e) {}
};

const _origRenderizarMesaOnlineCompletaUI_v65 = renderizarMesaOnlineCompletaUI;
renderizarMesaOnlineCompletaUI = function() {
    _origRenderizarMesaOnlineCompletaUI_v65();
    try { renderizarPainelAcoesPersonagemClicadoMesaJS(); } catch(e) {}
};



// ======================================================================================
// AMEAÇAS 100% FIÉIS SEM REDUÇÃO, MENU LATERAL DE PASSIVAS,
// TELA CHEIA EXCLUSIVA DA CENA COM AÇÕES CATEGORIZADAS (OFENSIVO/DEFENSIVO/BUFF/DEBUFFS/CURA),
// ANIMAÇÃO PRÓPRIA POR CATEGORIA/HABILIDADE E CONTROLE TOTAL DAS CRIATURAS PELO USUÁRIO
// ======================================================================================

window.__CATEGORIA_ACAO_ARENA_V67__ = window.__CATEGORIA_ACAO_ARENA_V67__ || 'OFENSIVO';
window.__CATEGORIA_ACAO_MESA_V67__ = window.__CATEGORIA_ACAO_MESA_V67__ || 'OFENSIVO';
window.__PASSIVAS_DRAWER_CONTEXTO_V67__ = 'ARENA';

// 1. Classificador rigoroso: separa o que é PASSIVO (vai para o Menu Lateral) do que é ATIVO (vai para os botões de ação)
function ehHabilidadePassivaT20JS(nome, desc) {
    const n = String(nome || '').toLowerCase();
    const d = String(desc || '').toLowerCase();
    // Lista de habilidades/poderes explicitamente ATIVOS
    const ativosRegex = /(ataque especial|golpe pessoal|golpe divino|fúria|furia|marca da presa|inspiração|inspiracao|duelo|engenhosidade|durão|durao|rolamento defensivo|cura pelas mãos|cura pelas maos|canalizar energia|forma selvagem|raio arcano|destruir|esmagar|chifres|sopro|investida|derrubar|desarmar|agarrar|empurrar|quebrar|fintar|defesa total|poção|pocao|essência|essencia|magia|lançar|lancar|gastar \d+ pm|ação padrão|acao padrao|ação de movimento|acao de movimento|ação completa|acao completa|ação livre|acao livre|reação|reacao|1 pm|2 pm|3 pm|4 pm|5 pm)/i;
    if (ativosRegex.test(n)) return false;

    // Lista de poderes/traços tipicamente PASSIVOS em Tormenta20
    const passivosRegex = /(foco em arma|especialização em arma|especializacao em arma|estilo de duas mãos|estilo de duas maos|estilo de arma e escudo|estilo de uma arma|estilo de disparo|estilo de duas armas|ambidestria|encouraçado|encouracado|inexpugnável|inexpugnavel|fanático|fanatico|aumento de atributo|sangue mágico|sangue magico|armadura óssea|armadura ossea|visão no escuro|visao no escuro|visão na penumbra|visao na penumbra|sentidos aguçados|sentidos agucados|pele de pedra|coração heroico|coracao heroico|vitalidade|vontade de ferro|reflexos relâmpago|reflexos relampago|fortitude aprimorada|saúde|saude|arqueiro|saque rápido|saque rapido|esquiva|combate defensivo|acuidade com arma|ataque poderoso|valentão|valentao|destruidor|magia ilimitada|arcano de batalha|poder mágico|poder magico|fortalecimento arcano|foco em magia|magia acelerada|reflexos de combate|imunidade|redução de dano|reducao de dano|\brd\s*\d+|resistência a|resistencia a|faro|deslocamento|vulnerabilidade|aura passiva)/i;
    if (passivosRegex.test(n)) return true;

    if (ativosRegex.test(d)) return false;
    return true;
}

// 2. Classifica qualquer ação ATIVA em uma das 5 categorias oficiais: OFENSIVO | DEFENSIVO | BUFF | DEBUFFS | CURA
function classificarCategoriaAcaoAtivaV67JS(nome, tipoOrig, desc) {
    const txt = (String(nome || '') + ' ' + String(tipoOrig || '') + ' ' + String(desc || '')).toLowerCase();
    if (/(cura|curar|poção|pocao|regenera|mãos|maos|auxílio médico|auxilio medico|restaura|revigorar|vitalizar|essência de mana|essencia de mana|recuperar|\+pv|\+pm|canalizar energia positiva)/i.test(txt)) {
        return 'CURA';
    }
    if (/(defesa total|durão|durao|armadura arcana|campo de força|campo de forca|escudo da fé|escudo da fe|rolamento defensivo|aparar|bloquear|postura defensiva|esquiva|barreira|proteção|protecao|reação defensiva|reacao defensiva|esconder|recuar|esquivar)/i.test(txt)) {
        return 'DEFENSIVO';
    }
    if (/(derrubar|desarmar|agarrar|empurrar|quebrar|fintar|medo|amedrontar|apavorar|maldição|maldicao|amaldiçoar|amaldicoar|enredar|cegar|paralisar|atordoar|lento|lentidão|lentidao|veneno|ácido|acido|enfraquecer|intimidar|presença aterradora|presenca aterradora|debuff|desprevenido|caído|caido|vulnerável|vulneravel|drenar)/i.test(txt)) {
        return 'DEBUFFS';
    }
    if (/(fúria|furia|inspiração|inspiracao|bênção|bencao|velocidade|concentração|concentracao|marca da presa|duelo|engenhosidade|forma selvagem|oração|oracao|heroísmo|heroismo|rugido|postura|buff|fortalecer|voar|invisibilidade|flanquear|avançar|avancar|aproximar|engajar)/i.test(txt)) {
        return 'BUFF';
    }
    return 'OFENSIVO';
}

// 3. Mapeamento de Animação Própria por Categoria e Habilidade (v67)
const __ANIM_MAP_ORIG_V66__ = (typeof obterCodigoAnimacaoUnicaPorHabilidadeJS === 'function') ? obterCodigoAnimacaoUnicaPorHabilidadeJS : null;
function obterAnimacaoPropriaCategoriaV67JS(nomeAcao, categoriaV67) {
    const cat = String(categoriaV67 || 'OFENSIVO').toUpperCase();
    const n = String(nomeAcao || '').toLowerCase();
    if (cat === 'CURA') {
        if (/regenera/.test(n)) return 'ANIM_V67_CURA_REGENERACAO';
        if (/mana|essência|essencia/.test(n)) return 'ANIM_V67_CURA_MANA';
        if (/poção|pocao/.test(n)) return 'ANIM_V67_CURA_POCAO';
        return 'ANIM_V67_CURA_RADIANTE';
    }
    if (cat === 'DEFENSIVO') {
        if (/campo de força|campo de forca|barreira/.test(n)) return 'ANIM_V67_DEF_CAMPO_FORCA';
        if (/armadura arcana|escudo/.test(n)) return 'ANIM_V67_DEF_ESCUDO_RUNICO';
        if (/durão|durao|postura/.test(n)) return 'ANIM_V67_DEF_DURAO_FERRO';
        return 'ANIM_V67_DEF_DEFESA_TOTAL';
    }
    if (cat === 'BUFF') {
        if (/fúria|furia|rugido/.test(n)) return 'ANIM_V67_BUFF_FURIA_RUBRA';
        if (/velocidade/.test(n)) return 'ANIM_V67_BUFF_VELOCIDADE';
        if (/inspiração|inspiracao|bênção|bencao/.test(n)) return 'ANIM_V67_BUFF_AURA_DOURADA';
        return 'ANIM_V67_BUFF_FOCO_TATICO';
    }
    if (cat === 'DEBUFFS') {
        if (/medo|aterradora|intimidar/.test(n)) return 'ANIM_V67_DEBUFF_TERROR';
        if (/veneno|ácido|acido/.test(n)) return 'ANIM_V67_DEBUFF_VENENO';
        if (/derrubar|quebrar|desarmar/.test(n)) return 'ANIM_V67_DEBUFF_IMPACTO_CONTROLE';
        return 'ANIM_V67_DEBUFF_MALDICAO';
    }
    // OFENSIVO
    if (/sopro|cone|baforada/.test(n)) return 'ANIM_INIMIGO_SOPRO';
    if (/garra|mordida|cauda|pancada|tentáculo|tentaculo/.test(n)) return 'ANIM_INIMIGO_GARRAS_MORDIDA';
    if (__ANIM_MAP_ORIG_V66__) return __ANIM_MAP_ORIG_V66__(nomeAcao, 'OFENSIVO');
    return 'ANIM_PODER_ATAQUE_ESPECIAL';
}

// 4. Repertório Estruturado de Ações Ativas (5 Categorias) + Passivas (Menu Lateral) para HERÓI
function montarAcoesEPassivasHeroiV67JS(st) {
    const ativas = { OFENSIVO: [], DEFENSIVO: [], BUFF: [], DEBUFFS: [], CURA: [] };
    const passivas = [];

    const armaNome = (st.arma && st.arma.nome) ? st.arma.nome : 'Espada Longa';
    const classeNome = (st.classe && st.classe.nome) ? st.classe.nome : 'Guerreiro';
    const racaNome = (st.raca && st.raca.nome) ? st.raca.nome : 'Humano';

    // Ataques Base (Ofensivo)
    ativas.OFENSIVO.push(
        { id: 'ATAQUE_PADRAO', nome: `Agredir (${armaNome})`, icone: '', custoPM: 0, cat: 'OFENSIVO', cor: 'linear-gradient(135deg,#991B1B,#DC2626)', desc: `Ataque corpo a corpo ou à distância com ${armaNome}.` },
        { id: 'INVESTIDA_COMPLETA', nome: 'Investida (+2 Atq / -2 Def)', icone: '', custoPM: 0, cat: 'OFENSIVO', cor: 'linear-gradient(135deg,#9A3412,#EA580C)', desc: 'Ação Completa: avança em linha reta até o dobro do deslocamento e ataca com +2.' },
        { id: 'COMBO_OFENSIVO_TOTAL', nome: `Combo Ofensivo (${classeNome})`, icone: '', custoPM: 3, cat: 'OFENSIVO', cor: 'linear-gradient(135deg,#B45309,#DC2626)', desc: 'Combina ataque principal com habilidade de classe de maior dano.' }
    );

    // Ações Defensivas Padrão (Defensivo)
    ativas.DEFENSIVO.push(
        { id: 'DEFESA_TOTAL_V67', nome: 'Defesa Total (+4 Def)', icone: '', custoPM: 0, cat: 'DEFENSIVO', cor: 'linear-gradient(135deg,#1E3A8A,#2563EB)', desc: 'Assume postura defensiva rigorosa até o próximo turno (+4 na Defesa).' },
        { id: 'REACAO_CLASSE_DEF_V67', nome: classeNome === 'Guerreiro' ? 'Durão (Metade Dano)' : (classeNome === 'Ladino' ? 'Rolamento Defensivo' : 'Postura de Guarda'), icone: '', custoPM: classeNome === 'Guerreiro' ? 3 : 1, cat: 'DEFENSIVO', cor: 'linear-gradient(135deg,#0F172A,#1D4ED8)', desc: 'Ativa proteção defensiva de classe contra o próximo impacto.' }
    );

    // Buffs Padrão / Classe (Buff)
    ativas.BUFF.push(
        { id: 'ATAQUE_ESPECIAL_COMBO', nome: `Habilidade de Classe (${classeNome})`, icone: '', custoPM: 2, cat: 'BUFF', cor: 'linear-gradient(135deg,#B45309,#F59E0B)', desc: `Ativa habilidade ativa característica de ${classeNome} (Ataque Especial, Fúria, Inspiração, Golpe Divino etc.).` },
        { id: 'FLANQUEAR_POS_V67', nome: 'Flanquear / Posição Tática (+2 Atq)', icone: '', custoPM: 0, cat: 'BUFF', cor: 'linear-gradient(135deg,#047857,#059669)', desc: 'Move-se para flanquear o inimigo com aliado (+2 nos testes de ataque).' }
    );

    // Debuffs / Manobras Padrão (Debuffs)
    ativas.DEBUFFS.push(
        { id: 'MANOBRA::Derrubar', nome: 'Derrubar (Caído: -5 Def)', icone: '', custoPM: 0, cat: 'DEBUFFS', cor: 'linear-gradient(135deg,#581C87,#7E22CE)', desc: 'Manobra de Combate (Luta oposto): derruba o oponente no chão.' },
        { id: 'FINTAR_DESPREVENIDO', nome: 'Fintar (Desprevenido: -5 Def)', icone: '', custoPM: 0, cat: 'DEBUFFS', cor: 'linear-gradient(135deg,#701A75,#A21CAF)', desc: 'Teste de Enganação contra Reflexos para deixar o alvo desprevenido.' },
        { id: 'MANOBRA::Quebrar', nome: 'Quebrar / Desarmar', icone: '', custoPM: 0, cat: 'DEBUFFS', cor: 'linear-gradient(135deg,#4C1D95,#6D28D9)', desc: 'Reduz o poder ofensivo ou defensivo do equipamento inimigo.' }
    );

    // Curas / Recuperação Padrão (Cura)
    ativas.CURA.push(
        { id: 'POCAO_CURA', nome: 'Poção de Cura (+2d8+2 PV)', icone: '', custoPM: 0, cat: 'CURA', cor: 'linear-gradient(135deg,#065F46,#10B981)', desc: 'Recupera Pontos de Vida imediatamente durante a cena.' },
        { id: 'ESSENCIA_MANA', nome: 'Essência de Mana (+1d4 PM)', icone: '', custoPM: 0, cat: 'CURA', cor: 'linear-gradient(135deg,#0369A1,#0284C7)', desc: 'Restaura Pontos de Mana para sustentar poderes e magias.' }
    );

    // Poderes da Ficha (Origem, Devoção, Classe e Gerais) -> SEPARA ATIVAS vs PASSIVAS
    const todosPods = [
        ...((st.est && st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est && st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ];
    const nomesVistos = new Set();
    todosPods.forEach(p => {
        const nm = String(p.nome || 'Poder').trim();
        if (!nm || nomesVistos.has(nm.toLowerCase())) return;
        nomesVistos.add(nm.toLowerCase());
        const desc = p.efeito || p.efeito_resumo || p.descricao || 'Poder da ficha de personagem.';
        if (ehHabilidadePassivaT20JS(nm, desc)) {
            passivas.push({ nome: nm, origem: p.tipo || 'Poder Passivo', desc });
        } else {
            const cat = classificarCategoriaAcaoAtivaV67JS(nm, 'PODER', desc);
            const corPorCat = {
                OFENSIVO: 'linear-gradient(135deg,#7F1D1D,#B91C1C)',
                DEFENSIVO: 'linear-gradient(135deg,#1E3A8A,#1D4ED8)',
                BUFF: 'linear-gradient(135deg,#92400E,#D97706)',
                DEBUFFS: 'linear-gradient(135deg,#581C87,#9333EA)',
                CURA: 'linear-gradient(135deg,#065F46,#059669)'
            };
            const icoPorCat = { OFENSIVO: '', DEFENSIVO: '', BUFF: '', DEBUFFS: '', CURA: '' };
            ativas[cat].push({
                id: `PODER_ATIVO::${nm}`,
                nome: nm,
                icone: icoPorCat[cat] || '',
                custoPM: /3 pm/i.test(desc) ? 3 : (/2 pm/i.test(desc) ? 2 : 1),
                cat,
                cor: corPorCat[cat],
                desc
            });
        }
    });

    // Magias da Ficha -> TODAS são ATIVAS e classificadas nas 5 categorias!
    (st.magias || []).forEach(m => {
        const nmM = String(m.nome || 'Magia').trim();
        const descM = m.efeito || m.descricao || `${m.escola || 'Magia'} de ${m.circulo || 1}º círculo.`;
        const cat = classificarCategoriaAcaoAtivaV67JS(nmM, 'MAGIA', descM);
        const corPorCat = {
            OFENSIVO: 'linear-gradient(135deg,#7E22CE,#DC2626)',
            DEFENSIVO: 'linear-gradient(135deg,#1D4ED8,#3B82F6)',
            BUFF: 'linear-gradient(135deg,#B45309,#EAB308)',
            DEBUFFS: 'linear-gradient(135deg,#4C1D95,#9333EA)',
            CURA: 'linear-gradient(135deg,#047857,#10B981)'
        };
        ativas[cat].push({
            id: `MAGIA_FICHA::${nmM}`,
            nome: `${nmM} (${m.circulo || 1}ºC)`,
            icone: cat === 'CURA' ? '' : (cat === 'DEFENSIVO' ? '' : (cat === 'BUFF' ? '' : (cat === 'DEBUFFS' ? '' : ''))),
            custoPM: Math.max(1, (Number(m.circulo || 1) * 2) - 1),
            cat,
            cor: corPorCat[cat],
            desc: descM
        });
    });

    // Passivas Raciais e de Equipamento
    passivas.unshift(
        { nome: `Traços Raciais: ${racaNome}`, origem: 'Raça', desc: (st.raca && st.raca.habilidades) ? (Array.isArray(st.raca.habilidades) ? st.raca.habilidades.join(' · ') : String(st.raca.habilidades)) : 'Bônus raciais ativos permanentemente.' },
        { nome: `Equipamento: ${armaNome}`, origem: 'Arsenal', desc: `Defesa Total ${st.est ? st.est.defesa : 15} | Deslocamento ${st.est ? st.est.deslocamento : '9m'}.` }
    );

    return { ativas, passivas };
}

// 5. Repertório Estruturado de Ações Ativas (5 Categorias) + Passivas para CRIATURA / AMEAÇA CONTROLADA PELO USUÁRIO
function montarAcoesEPassivasCriaturaV67JS(crObj, privFallback) {
    const ativas = { OFENSIVO: [], DEFENSIVO: [], BUFF: [], DEBUFFS: [], CURA: [] };
    const passivas = [];

    const nomeCr = (crObj && (crObj.nomeCriatura || crObj.nome)) || (privFallback && privFallback.nomeCriatura) || 'Ameaça';
    const ataquesTxt = (crObj && (crObj.ataquesResumo || crObj.ataquesTexto)) || (privFallback && privFallback.ataquesResumo) || 'Ataque Corpo a Corpo';
    const habsTxt = (crObj && (crObj.habilidadesResumo || crObj.habilidadesTexto)) || (privFallback && privFallback.habilidadesResumo) || '';
    const atqBonus = Number((crObj && crObj.ataque) || (privFallback && privFallback.ataque) || 10);
    const danoMed = Number((crObj && (crObj.danoMedio || crObj.dano_medio)) || (privFallback && privFallback.danoMedio) || 16);
    const cdEf = Number((crObj && crObj.cdEfeito) || (privFallback && privFallback.cdEfeito) || 18);

    // Extrair ataques oficiais do texto da ficha
    const partesAtq = String(ataquesTxt).split(/,|;|\bou\b/i).map(s => s.trim()).filter(s => s.length > 3);
    if (partesAtq.length === 0) partesAtq.push(`Ataque Principal (+${atqBonus}, dano ${danoMed})`);
    partesAtq.slice(0, 4).forEach((atk, i) => {
        ativas.OFENSIVO.push({
            id: `CRIATURA_ATQ_${i}`,
            nome: atk.slice(0, 38),
            icone: /sopro|baforada|cone|fogo|raio/i.test(atk) ? '' : (/arco|besta|disparo|pedra/i.test(atk) ? '' : ''),
            custoPM: 0,
            cat: 'OFENSIVO',
            cor: 'linear-gradient(135deg,#7F1D1D,#DC2626)',
            desc: `Ataque oficial da criatura (+${atqBonus} no teste, dano médio ${danoMed}).`,
            danoMult: i === 0 ? 1.0 : 0.9,
            ehArea: /sopro|cone|área|area|explos/i.test(atk)
        });
    });

    // Extrair habilidades especiais do texto (separando ativas nas 5 categorias e passivas no Menu Lateral)
    const partesHab = String(habsTxt).split(/,|;|\./).map(s => s.trim()).filter(s => s.length > 3);
    partesHab.forEach((hb, i) => {
        const ehPassivaCr = /(^rd\s*\d+|redução de dano|imunidade|imune|visão|visao|faro|sentidos|resistência|resistencia|vulnerabilidade|deslocamento|voo|natação|escalada)/i.test(hb);
        if (ehPassivaCr) {
            passivas.push({ nome: hb.slice(0, 44), origem: `Passiva de ${nomeCr}`, desc: hb });
        } else {
            const cat = classificarCategoriaAcaoAtivaV67JS(hb, 'CRIATURA', hb);
            const corMap = {
                OFENSIVO: 'linear-gradient(135deg,#991B1B,#EA580C)',
                DEFENSIVO: 'linear-gradient(135deg,#1E3A8A,#2563EB)',
                BUFF: 'linear-gradient(135deg,#92400E,#D97706)',
                DEBUFFS: 'linear-gradient(135deg,#581C87,#9333EA)',
                CURA: 'linear-gradient(135deg,#065F46,#10B981)'
            };
            const icoMap = { OFENSIVO: '', DEFENSIVO: '', BUFF: '', DEBUFFS: '', CURA: '' };
            ativas[cat].push({
                id: `CRIATURA_HAB_${i}`,
                nome: hb.slice(0, 38),
                icone: icoMap[cat],
                custoPM: 0,
                cat,
                cor: corMap[cat],
                desc: `Habilidade especial de ${nomeCr} (CD ${cdEf}).`,
                danoMult: cat === 'OFENSIVO' ? 1.15 : 0.5,
                ehArea: /sopro|área|area|aura|cone|onda|tempestade/i.test(hb)
            });
        }
    });

    // Garantir ações táticas de criatura em todas as categorias para controle rico pelo usuário
    if (ativas.DEFENSIVO.length === 0) {
        ativas.DEFENSIVO.push({
            id: 'CRIATURA_DEF_TOTAL',
            nome: 'Postura Defensiva (+4 Def)',
            icone: '',
            custoPM: 0,
            cat: 'DEFENSIVO',
            cor: 'linear-gradient(135deg,#1E3A8A,#2563EB)',
            desc: `${nomeCr} protege seus pontos vitais (+4 na Defesa até o próximo turno).`
        });
    }
    if (ativas.BUFF.length === 0) {
        ativas.BUFF.push({
            id: 'CRIATURA_BUFF_RUGIDO',
            nome: 'Rugido / Fúria Predatória (+2 Atq)',
            icone: '',
            custoPM: 0,
            cat: 'BUFF',
            cor: 'linear-gradient(135deg,#B45309,#F59E0B)',
            desc: `${nomeCr} acumula ímpeto feroz para o próximo golpe (+2 Ataque e +15% Dano).`
        });
    }
    if (ativas.DEBUFFS.length === 0) {
        ativas.DEBUFFS.push({
            id: 'CRIATURA_DEBUFF_TERROR',
            nome: `Presença Aterradora (CD ${cdEf})`,
            icone: '',
            custoPM: 0,
            cat: 'DEBUFFS',
            cor: 'linear-gradient(135deg,#581C87,#9333EA)',
            desc: `Exige teste de Vontade (CD ${cdEf}) ou deixa o alvo Abalado (-2 em testes).`
        });
    }
    if (ativas.CURA.length === 0) {
        ativas.CURA.push({
            id: 'CRIATURA_CURA_FOLEGO',
            nome: 'Recuperar Fôlego / Regenerar (+15% PV)',
            icone: '',
            custoPM: 0,
            cat: 'CURA',
            cor: 'linear-gradient(135deg,#065F46,#10B981)',
            desc: `${nomeCr} regenera parte dos seus Pontos de Vida oficiais.`
        });
    }

    // Adiciona ficha resumida oficial nas passivas
    const fort = Number((crObj && crObj.fortitude) || (privFallback && privFallback.fortitude) || 8);
    const refl = Number((crObj && crObj.reflexos) || (privFallback && privFallback.reflexos) || 8);
    const vont = Number((crObj && crObj.vontade) || (privFallback && privFallback.vontade) || 6);
    passivas.unshift({
        nome: `Estatísticas Oficiais (100% Livro — Sem Redução)`,
        origem: nomeCr,
        desc: `Defesa ${crObj ? crObj.defesa : (privFallback ? privFallback.defesa : 20)} | Ataque +${atqBonus} | Dano Médio ${danoMed} | Fort +${fort} / Ref +${refl} / Von +${vont} | CD ${cdEf}`
    });

    return { ativas, passivas };
}

// 6. Menu Lateral Retrátil de Habilidades Passivas (Arena e Mesa Online, Normal e Tela Cheia)
function garantirDrawerPassivasDOMJS() {
    let drawer = document.getElementById('t20-passives-side-drawer');
    if (!drawer) {
        drawer = document.createElement('div');
        drawer.id = 't20-passives-side-drawer';
        drawer.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 14px;background:linear-gradient(90deg,#1E1B4B,#0F172A);border-bottom:2px solid #D4AF37;">
                <div>
                    <div style="font-size:13.5px;font-weight:900;color:#FACC15;">Habilidades &amp; Poderes Passivos</div>
                    <div id="t20-passives-drawer-subtitle" style="font-size:10.5px;color:#93C5FD;font-weight:700;">Sempre ativos automaticamente</div>
                </div>
                <button type="button" class="btn-roll-inline" style="background:#991B1B;border-color:#FCA5A5;color:#FFF;font-weight:900;padding:4px 9px;" onclick="alternarMenuLateralPassivasJS(null, false)"></button>
            </div>
            <div id="t20-passives-drawer-body" style="flex:1;overflow-y:auto;padding:12px;"></div>
        `;
        document.body.appendChild(drawer);
    }
    return drawer;
}

function atualizarConteudoMenuLateralPassivasJS(contexto) {
    const drawer = garantirDrawerPassivasDOMJS();
    const body = document.getElementById('t20-passives-drawer-body');
    const sub = document.getElementById('t20-passives-drawer-subtitle');
    if (!body) return;
    const ctx = contexto || window.__PASSIVAS_DRAWER_CONTEXTO_V67__ || 'ARENA';
    let passivas = [];
    let tituloEnt = 'Personagem';

    if (ctx === 'MESA' && ESTADO_MESA_ONLINE_ATUAL) {
        const sel = window.__PERSONAGEM_CLICADO_MESA__ || { tipo: 'HEROI_MESA', id: HEROI_SELECIONADO_GRID_MESA_ID };
        if (sel.tipo === 'AMEACA_MESA') {
            const cr = (ESTADO_MESA_ONLINE_ATUAL.listaInimigosMesa || [])[Number(sel.id || 0)];
            tituloEnt = cr ? `${cr.nome} (Ameaça ND ${cr.nd})` : 'Ameaça';
            passivas = montarAcoesEPassivasCriaturaV67JS(cr, null).passivas;
        } else {
            const h = (ESTADO_MESA_ONLINE_ATUAL.participantes || []).find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || (ESTADO_MESA_ONLINE_ATUAL.participantes || [])[0];
            tituloEnt = h ? `${h.nome} (${h.classe || 'Herói'})` : 'Herói';
            passivas = [
                { nome: `Raça & Classe: ${h ? (h.raca + ' ' + h.classe + ' Nv ' + h.nivel) : 'Herói'}`, origem: 'Base', desc: `Defesa ${h ? h.defesa : 20} | Bônus de Ataque +${h ? h.ataque : 8} | PV ${h ? h.pvMax : 40} | PM ${h ? h.pmMax : 15}.` },
                { nome: 'Bônus Passivos de Ficha', origem: 'Passivas', desc: (h && h.poderesPassivosResumo) ? h.poderesPassivosResumo : 'Foco em Arma, Estilo de Combate e traços raciais já somados nas rolagens.' }
            ];
        }
    } else {
        const sel = window.__PERSONAGEM_CLICADO_ARENA__ || { tipo: 'HEROI', id: 'HEROI_PRINCIPAL' };
        if (sel.tipo === 'AMEACA' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
            const cr = (__ARENA_STATE__.listaCriaturas || [])[Number(sel.id || 0)] || null;
            tituloEnt = cr ? `${cr.nomeCriatura} (ND ${cr.ndTexto})` : 'Ameaça';
            passivas = montarAcoesEPassivasCriaturaV67JS(cr, __ARENA_STATE__._privadoCriatura).passivas;
        } else {
            const st = garantirEstadoFichaParaArena();
            tituloEnt = `${st.nome} (${st.raca.nome} ${st.classe.nome} Nv ${st.nivel})`;
            passivas = montarAcoesEPassivasHeroiV67JS(st).passivas;
        }
    }

    if (sub) sub.textContent = `${tituloEnt} — ${passivas.length} passiva(s) ativa(s)`;
    body.innerHTML = passivas.map(p => `
        <div class="t20-passive-item-card">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:3px;">
                <strong style="color:#FDE047;">${p.nome}</strong>
                <span style="font-size:9.5px;background:rgba(15,23,42,0.85);color:#7DD3FC;padding:1px 6px;border-radius:4px;border:1px solid rgba(56,189,248,0.4);">${p.origem}</span>
            </div>
            <div style="color:#CBD5E1;font-size:11px;">${p.desc}</div>
        </div>
    `).join('') || '<div style="color:#94A3B8;font-size:12px;">Nenhuma habilidade passiva registrada.</div>';
}

function alternarMenuLateralPassivasJS(contexto, forcarEstado) {
    if (contexto) window.__PASSIVAS_DRAWER_CONTEXTO_V67__ = contexto;
    const drawer = garantirDrawerPassivasDOMJS();
    atualizarConteudoMenuLateralPassivasJS(window.__PASSIVAS_DRAWER_CONTEXTO_V67__);
    const abrir = (typeof forcarEstado === 'boolean') ? forcarEstado : !drawer.classList.contains('drawer-open');
    if (abrir) drawer.classList.add('drawer-open');
    else drawer.classList.remove('drawer-open');
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
}

// 7. Execução Direta de Habilidade Controlada da CRIATURA pelo Usuário (Arena e Mesa Online)
function executarHabilidadeControladaCriaturaV67JS(contexto, idxCriatura, acaoId, nomeAcao, catV67, ehArea) {
    const animCode = obterAnimacaoPropriaCategoriaV67JS(nomeAcao, catV67);
    try {
        if (typeof tocarSomPorEfeitoAnimacaoJRPG === 'function') {
            tocarSomPorEfeitoAnimacaoJRPG(catV67 === 'CURA' ? 'CURA_BUFF' : (catV67 === 'DEFENSIVO' ? 'ESCUDO' : (catV67 === 'DEBUFFS' ? 'MAGIA_TREVAS' : (catV67 === 'BUFF' ? 'BUFF_AURA' : 'IMPACTO_PESADO'))));
        }
    } catch(e) {}

    if (contexto === 'MESA' && ESTADO_MESA_ONLINE_ATUAL) {
        const m = ESTADO_MESA_ONLINE_ATUAL;
        const cr = (m.listaInimigosMesa || [])[Number(idxCriatura || 0)];
        const parts = m.participantes || [];
        const alvoH = parts.find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || parts[0];
        if (!cr) return;

        let msg = '';
        if (catV67 === 'CURA') {
            const cura = Math.max(8, Math.round(cr.pvMax * 0.15));
            cr.pvAtual = Math.min(cr.pvMax, cr.pvAtual + cura);
            msg = `[Criatura Controlada] ${cr.nome} usou ${nomeAcao} e recuperou +${cura} PV (${cr.pvAtual}/${cr.pvMax})!`;
        } else if (catV67 === 'DEFENSIVO') {
            cr._bonusDefTempV67 = 4;
            msg = `[Criatura Controlada] ${cr.nome} assumiu ${nomeAcao} (+4 na Defesa até o próximo turno)!`;
        } else if (catV67 === 'BUFF') {
            cr._buffAtqTempV67 = 2;
            msg = `[Criatura Controlada] ${cr.nome} ativou ${nomeAcao} (+2 Ataque / +15% Dano)!`;
        } else if (catV67 === 'DEBUFFS') {
            const cd = Number(cr.cdEfeito || 18);
            const d20 = Math.floor(Math.random() * 20) + 1;
            const passou = (d20 + 6) >= cd;
            msg = `[Criatura Controlada] ${cr.nome} usou ${nomeAcao} (CD ${cd}) em ${alvoH ? alvoH.nome : 'Grupo'}: Resistência d20(${d20})+6=${d20+6} — ${passou ? 'RESISTIU!' : 'FALHOU (Abalado -2)!'}!`;
        } else {
            const d20 = Math.floor(Math.random() * 20) + 1;
            const atqTotal = d20 + Number(cr.ataque || 10) + Number(cr._buffAtqTempV67 || 0);
            const defAlvo = Number((alvoH && alvoH.defesa) || 20);
            const danoBruto = Math.max(4, Math.round(Number(cr.danoMedio || 16) * (0.85 + Math.random() * 0.30) * (cr._buffAtqTempV67 ? 1.15 : 1.0)));
            cr._buffAtqTempV67 = 0;
            if (ehArea && parts.length > 0) {
                parts.forEach(p => { p.pvAtual = Math.max(0, p.pvAtual - Math.round(danoBruto * 0.8)); });
                msg = `[Criatura Controlada] ${cr.nome} disparou ${nomeAcao} em ÁREA causando ${Math.round(danoBruto * 0.8)} de dano ao grupo!`;
            } else if (alvoH && (d20 === 20 || atqTotal >= defAlvo)) {
                alvoH.pvAtual = Math.max(0, alvoH.pvAtual - danoBruto);
                msg = `[Criatura Controlada] ${cr.nome} usou ${nomeAcao} em ${alvoH.nome}: d20(${d20})+${cr.ataque}=${atqTotal} vs Def ${defAlvo} — ACERTOU (${danoBruto} dano)!`;
            } else {
                msg = `[Criatura Controlada] ${cr.nome} usou ${nomeAcao} em ${alvoH ? alvoH.nome : 'Herói'}: d20(${d20})+${cr.ataque}=${atqTotal} vs Def ${defAlvo} — ERROU!`;
            }
        }
        if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function') {
            dispararAnimacaoCoreografadaPalco2DJS({
                tipo: animCode,
                ladoAlvo: (catV67 === 'CURA' || catV67 === 'DEFENSIVO' || catV67 === 'BUFF') ? 'CRIATURA' : 'HEROI',
                origem: { gx: cr.gx || 6, gy: cr.gy || 2 },
                destino: (catV67 === 'CURA' || catV67 === 'DEFENSIVO' || catV67 === 'BUFF') ? { gx: cr.gx || 6, gy: cr.gy || 2 } : { gx: alvoH ? alvoH.gx : 2, gy: alvoH ? alvoH.gy : 2 },
                label: `${cr.nome.slice(0,12)}: ${nomeAcao.slice(0,18)}`
            });
        }
        if (typeof registrarLogMesaOnline === 'function') registrarLogMesaOnline(msg);
        renderizarMesaOnlineCompletaUI();
        renderizarPainelAcoesPersonagemClicadoMesaJS();
        return;
    }

    // Contexto ARENA
    if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    if (!a) return;
    const cr = (a.listaCriaturas || [])[Number(idxCriatura || 0)];
    const priv = a._privadoCriatura;
    if (!cr || !priv) return;

    let msgArena = '';
    if (catV67 === 'CURA') {
        const cura = Math.max(10, Math.round(cr.pvMax * 0.15));
        cr.pvAtual = Math.min(cr.pvMax, cr.pvAtual + cura);
        priv.pvAtual = cr.pvAtual;
        msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> usou <strong>${nomeAcao}</strong> e regenerou <strong>+${cura} PV</strong> (${cr.pvAtual}/${cr.pvMax} PV)!`;
    } else if (catV67 === 'DEFENSIVO') {
        cr._bonusDefTempV67 = 4;
        msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> assumiu <strong>${nomeAcao}</strong> (+4 na Defesa até o próximo turno)!`;
    } else if (catV67 === 'BUFF') {
        cr._buffAtqTempV67 = 2;
        msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> ativou <strong>${nomeAcao}</strong> (+2 Ataque e +15% Dano no próximo golpe)!`;
    } else if (catV67 === 'DEBUFFS') {
        const cd = Number(cr.cdEfeito || priv.cdEfeito || 18);
        const d20 = Math.floor(Math.random() * 20) + 1;
        const resH = d20 + 6;
        const falhou = resH < cd;
        msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> usou <strong>${nomeAcao}</strong> (CD ${cd}): Herói rolou d20(${d20})+6=${resH} — <strong>${falhou ? 'FALHOU (Condição Aplicada!)' : 'RESISTIU!'}</strong>`;
    } else {
        const d20 = Math.floor(Math.random() * 20) + 1;
        const bonusAtq = Number(cr.ataque || priv.ataque || 10) + Number(cr._buffAtqTempV67 || 0);
        const totalAtq = d20 + bonusAtq;
        const defH = Number(a.defHeroiBase || 18) + Number(a._bonusDefHeroiTempV67 || 0);
        const danoBruto = Math.max(4, Math.round(Number(cr.danoMedio || priv.danoMedio || 16) * (0.85 + Math.random() * 0.30) * (cr._buffAtqTempV67 ? 1.15 : 1.0)));
        cr._buffAtqTempV67 = 0;
        if (d20 === 20 || totalAtq >= defH) {
            const danoFinal = d20 === 20 ? Math.round(danoBruto * 1.5) : danoBruto;
            a.pvHeroi = Math.max(0, a.pvHeroi - danoFinal);
            msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> usou <strong>${nomeAcao}</strong>: d20(${d20})+${bonusAtq}=${totalAtq} vs Def ${defH} — <strong>${d20 === 20 ? 'CRÍTICO!' : 'ACERTOU!'} (${danoFinal} dano oficial)</strong> | Herói: ${a.pvHeroi}/${a.pvHeroiMax} PV`;
        } else {
            msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> usou <strong>${nomeAcao}</strong>: d20(${d20})+${bonusAtq}=${totalAtq} vs Def ${defH} — <strong>ERROU!</strong>`;
        }
    }

    if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function') {
        dispararAnimacaoCoreografadaPalco2DJS({
            tipo: animCode,
            ladoAlvo: (catV67 === 'CURA' || catV67 === 'DEFENSIVO' || catV67 === 'BUFF') ? 'CRIATURA' : 'HEROI',
            origem: { gx: cr.gx || 6, gy: cr.gy || 2 },
            destino: (catV67 === 'CURA' || catV67 === 'DEFENSIVO' || catV67 === 'BUFF') ? { gx: cr.gx || 6, gy: cr.gy || 2 } : (a.posHeroi || { gx: 2, gy: 2 }),
            label: `${cr.nomeCriatura.slice(0,14)}: ${nomeAcao.slice(0,18)}`
        });
    }
    if (typeof registrarLinhaLogArena === 'function') registrarLinhaLogArena(msgArena);
    const pill = document.getElementById('arena-fullscreen-live-roll-pill');
    if (pill) pill.innerHTML = msgArena.replace(/<[^>]+>/g, '').slice(0, 110);
    if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
    renderizarPainelAcoesPersonagemClicadoArenaJS();
}

// 8. Execução de Ação Categorizada do HERÓI na Arena com Animação Própria da Categoria
function executarAcaoCategorizadaHeroiArenaV67JS(acaoId, nomeAcao, catV67, armaNome) {
    if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    const animCode = obterAnimacaoPropriaCategoriaV67JS(nomeAcao, catV67);

    if (acaoId === 'POCAO_CURA' || acaoId === 'ESSENCIA_MANA') {
        if (typeof ajustarRecursoRapidoPersonagemArenaJS === 'function') ajustarRecursoRapidoPersonagemArenaJS(acaoId);
        if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function' && a) {
            dispararAnimacaoCoreografadaPalco2DJS({ tipo: animCode, ladoAlvo: 'HEROI', origem: a.posHeroi || { gx: 2, gy: 2 }, destino: a.posHeroi || { gx: 2, gy: 2 }, label: `${nomeAcao}` });
        }
        renderizarPainelAcoesPersonagemClicadoArenaJS();
        return;
    }
    if (acaoId === 'DEFESA_TOTAL_V67' || acaoId === 'REACAO_CLASSE_DEF_V67') {
        if (a) {
            a._bonusDefHeroiTempV67 = (acaoId === 'DEFESA_TOTAL_V67') ? 4 : 6;
            const msg = `<strong>[Defensivo]</strong> Herói ativou <strong>${nomeAcao}</strong> (+${a._bonusDefHeroiTempV67} Defesa / Proteção ativa)!`;
            if (typeof registrarLinhaLogArena === 'function') registrarLinhaLogArena(msg);
            const pill = document.getElementById('arena-fullscreen-live-roll-pill');
            if (pill) pill.textContent = `${nomeAcao} ativa (+${a._bonusDefHeroiTempV67} Def)`;
            if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function') {
                dispararAnimacaoCoreografadaPalco2DJS({ tipo: animCode, ladoAlvo: 'HEROI', origem: a.posHeroi || { gx: 2, gy: 2 }, destino: a.posHeroi || { gx: 2, gy: 2 }, label: `${nomeAcao}` });
            }
            if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
        }
        renderizarPainelAcoesPersonagemClicadoArenaJS();
        return;
    }
    if (acaoId === 'FLANQUEAR_POS_V67') {
        if (typeof posicionarRapidoArena2DJS === 'function') posicionarRapidoArena2DJS('FLANQUEAR_ALIADO');
        if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function' && a) {
            dispararAnimacaoCoreografadaPalco2DJS({ tipo: animCode, ladoAlvo: 'HEROI', origem: a.posHeroi || { gx: 2, gy: 2 }, destino: a.posHeroi || { gx: 2, gy: 2 }, label: `${nomeAcao}` });
        }
        return;
    }
    // Delega ao motor de poderes/ataques/magias/manobras com a animação própria da categoria
    if (typeof executarPoderOuAcaoUnicaHeroiArenaJS === 'function') {
        executarPoderOuAcaoUnicaHeroiArenaJS(acaoId, nomeAcao, catV67, armaNome || '');
    }
}

// 9. Trocar Aba de Categoria (Ofensivo / Defensivo / Buff / Debuffs / Cura)
function selecionarCategoriaAcaoV67JS(contexto, novaCat) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    if (contexto === 'MESA') {
        window.__CATEGORIA_ACAO_MESA_V67__ = novaCat;
        renderizarPainelAcoesPersonagemClicadoMesaJS();
    } else {
        window.__CATEGORIA_ACAO_ARENA_V67__ = novaCat;
        renderizarPainelAcoesPersonagemClicadoArenaJS();
    }
}

// 10. Override do Dock de Ações da ARENA (v67): Apenas Ativas separadas em 5 Categorias + Botão Menu Lateral de Passivas + Controle de Criaturas!
function renderizarPainelAcoesPersonagemClicadoArenaJS() {
    if (typeof __ARENA_STATE__ === 'undefined' || !__ARENA_STATE__) {
        if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario();
    }
    const box = document.getElementById('arena-clicked-character-actions-bar');
    if (!box || typeof __ARENA_STATE__ === 'undefined' || !__ARENA_STATE__) return;

    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    const sel = window.__PERSONAGEM_CLICADO_ARENA__ || { tipo: 'HEROI', id: 'HEROI_PRINCIPAL' };
    const listaCriaturas = Array.isArray(a.listaCriaturas) ? a.listaCriaturas : [];
    const focoIdx = Math.min(Math.max(0, Number(a.alvoFocoIdx || 0)), Math.max(0, listaCriaturas.length - 1));
    const crFoco = listaCriaturas[focoIdx] || null;
    const catAtiva = window.__CATEGORIA_ACAO_ARENA_V67__ || 'OFENSIVO';

    const seletorTokensHTML = `
        <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:10.5px;font-weight:900;color:#93C5FD;">Controlar:</span>
            <button type="button" class="btn-roll-inline" style="background:${sel.tipo === 'HEROI' ? '#15803D' : '#1E293B'};border-color:${sel.tipo === 'HEROI' ? '#4ADE80' : '#475569'};font-weight:900;padding:3px 8px;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI', 'HEROI_PRINCIPAL', 'ARENA')">
                ${st.nome.slice(0, 14)}
            </button>
            ${listaCriaturas.map((cr, idx) => `
                <button type="button" class="btn-roll-inline" style="background:${(sel.tipo === 'AMEACA' && Number(sel.id) === idx) ? '#991B1B' : '#1E293B'};border-color:${(sel.tipo === 'AMEACA' && Number(sel.id) === idx) ? '#FACC15' : '#EF4444'};font-weight:900;padding:3px 8px;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA', ${idx}, 'ARENA')">
                    ${cr.rotulo} ${cr.nomeCriatura.slice(0, 14)} (${Math.max(0, cr.pvAtual)}/${cr.pvMax})
                </button>
            `).join('')}
        </div>
    `;

    const ehCriaturaControlada = (sel.tipo === 'AMEACA' && crFoco);
    const dados = ehCriaturaControlada
        ? montarAcoesEPassivasCriaturaV67JS(crFoco, a._privadoCriatura)
        : montarAcoesEPassivasHeroiV67JS(st);

    const catsMeta = [
        { k: 'OFENSIVO', label: 'Ofensivo' },
        { k: 'DEFENSIVO', label: 'Defensivo' },
        { k: 'BUFF', label: 'Buff' },
        { k: 'DEBUFFS', label: 'Debuffs' },
        { k: 'CURA', label: 'Cura' }
    ];

    const tabsHTML = catsMeta.map(c => `
        <button type="button" class="t20-v67-cat-btn ${catAtiva === c.k ? 'cat-active-' + c.k : ''}"
                onclick="selecionarCategoriaAcaoV67JS('ARENA', '${c.k}')">
            <span>${c.label}</span>
            <span class="t20-v67-cat-count">${(dados.ativas[c.k] || []).length}</span>
        </button>
    `).join('');

    const listaAcoesCat = dados.ativas[catAtiva] || [];
    const armaNome = (st.arma && st.arma.nome) ? st.arma.nome.replace(/'/g, '') : 'Espada Longa';

    const cardsHTML = listaAcoesCat.map(ac => {
        const nmSafe = String(ac.nome || '').replace(/'/g, '');
        const idSafe = String(ac.id || '').replace(/'/g, '');
        const onClickCode = ehCriaturaControlada
            ? `executarHabilidadeControladaCriaturaV67JS('ARENA', ${focoIdx}, '${idSafe}', '${nmSafe}', '${catAtiva}', ${Boolean(ac.ehArea)})`
            : `executarAcaoCategorizadaHeroiArenaV67JS('${idSafe}', '${nmSafe}', '${catAtiva}', '${armaNome}')`;
        return `
            <button type="button" class="t20-v67-action-card" style="background:${ac.cor};" title="${String(ac.desc || '').replace(/"/g, '&quot;')}" onclick="${onClickCode}">
                <span>${ac.icone}</span>
                <span>${ac.nome}</span>
                ${ac.custoPM > 0 ? `<span class="t20-v67-pm-badge">${ac.custoPM} PM</span>` : ''}
            </button>
        `;
    }).join('') || '<span style="color:#94A3B8;font-size:11.5px;">Nenhuma ação ativa nesta categoria.</span>';

    box.innerHTML = `
        <div class="t20-clicked-char-dock">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;">
                ${seletorTokensHTML}
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                    <span style="font-size:10.5px;color:${ehCriaturaControlada ? '#FCA5A5' : '#FDE047'};font-weight:900;">
                        ${ehCriaturaControlada ? `Controlando ${crFoco.nomeCriatura} (ND ${crFoco.ndTexto} · 100% Stats Oficiais — Toque no grid p/ mover!)` : `${st.nome} (Ativas em destaque)`}
                    </span>
                    <button type="button" class="t20-passives-toggle-btn" onclick="alternarMenuLateralPassivasJS('ARENA')">
                        Passivas (${dados.passivas.length})
                    </button>
                </div>
            </div>
            <div class="t20-v67-cat-tabs">${tabsHTML}</div>
            <div class="t20-v67-actions-grid">${cardsHTML}</div>
        </div>
    `;

    // Atualiza o drawer lateral se estiver aberto
    const dr = document.getElementById('t20-passives-side-drawer');
    if (dr && dr.classList.contains('drawer-open')) atualizarConteudoMenuLateralPassivasJS('ARENA');
}

// 11. Override do Dock de Ações da MESA ONLINE (v67): Apenas Ativas em 5 Categorias + Menu Lateral de Passivas + Controle Direto de Criaturas!
function renderizarPainelAcoesPersonagemClicadoMesaJS() {
    if (!ESTADO_MESA_ONLINE_ATUAL && typeof criarEstadoInicialMesaOnline === 'function') {
        ESTADO_MESA_ONLINE_ATUAL = criarEstadoInicialMesaOnline('VALKARIA-2026');
    }
    const box = document.getElementById('mesa-clicked-character-actions-bar');
    if (!box || !ESTADO_MESA_ONLINE_ATUAL) return;

    const m = ESTADO_MESA_ONLINE_ATUAL;
    const parts = m.participantes || [];
    const inimigos = m.listaInimigosMesa || [];
    if (!HEROI_SELECIONADO_GRID_MESA_ID && parts[0]) HEROI_SELECIONADO_GRID_MESA_ID = parts[0].idHeroi;

    const sel = window.__PERSONAGEM_CLICADO_MESA__ || { tipo: 'HEROI_MESA', id: HEROI_SELECIONADO_GRID_MESA_ID };
    const heroiAtivo = parts.find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || parts[0];
    const focoIdx = Math.min(Math.max(0, Number(m.alvoFocoMesaIdx || 0)), Math.max(0, inimigos.length - 1));
    const inimFoco = inimigos[focoIdx] || null;
    const catAtiva = window.__CATEGORIA_ACAO_MESA_V67__ || 'OFENSIVO';

    const stickyMesa = document.getElementById('mesa-fullscreen-sticky-hero-stats');
    if (stickyMesa) {
        const ehCr = (sel.tipo === 'AMEACA_MESA' && inimFoco);
        stickyMesa.innerHTML = ehCr
            ? `<span style="color:#FCA5A5;font-weight:900;">Controlando ${inimFoco.nome} (ND ${inimFoco.nd} · 100% Oficial)</span>
               <span style="background:#7F1D1D;color:#FECACA;padding:2px 6px;border-radius:5px;font-weight:900;">${inimFoco.pvAtual}/${inimFoco.pvMax} PV</span>
               <span style="background:#1E293B;color:#93C5FD;padding:2px 6px;border-radius:5px;font-weight:900;">Def ${inimFoco.defesa}</span>`
            : (heroiAtivo ? `<span style="color:#FDE047;font-weight:900;">${heroiAtivo.nome} (${heroiAtivo.classe || 'Herói'})</span>
               <span style="background:#065F46;color:#A7F3D0;padding:2px 6px;border-radius:5px;font-weight:900;">${heroiAtivo.pvAtual}/${heroiAtivo.pvMax} PV</span>
               <span style="background:#0369A1;color:#E0F2FE;padding:2px 6px;border-radius:5px;font-weight:900;">${heroiAtivo.pmAtual}/${heroiAtivo.pmMax} PM</span>` : '');
    }

    const seletorTokensMesaHTML = `
        <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:10.5px;font-weight:900;color:#93C5FD;">Controlar:</span>
            ${parts.map(p => {
                const ehSel = (sel.tipo === 'HEROI_MESA' && p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID);
                return `<button type="button" class="btn-roll-inline" style="background:${ehSel ? '#15803D' : '#1E293B'};border-color:${ehSel ? '#4ADE80' : '#475569'};font-weight:900;padding:3px 7px;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI_MESA', '${p.idHeroi}', 'MESA')">${p.nome.slice(0, 11)}</button>`;
            }).join('')}
            ${inimigos.map((cr, idx) => {
                const ehSel = (sel.tipo === 'AMEACA_MESA' && Number(sel.id) === idx);
                return `<button type="button" class="btn-roll-inline" style="background:${ehSel ? '#991B1B' : '#1E293B'};border-color:${ehSel ? '#FACC15' : '#EF4444'};font-weight:900;padding:3px 7px;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA_MESA', ${idx}, 'MESA')">${cr.rotulo} ${cr.nome.slice(0, 11)} (${Math.max(0, cr.pvAtual)}/${cr.pvMax})</button>`;
            }).join('')}
        </div>
    `;

    const ehCriaturaControlada = (sel.tipo === 'AMEACA_MESA' && inimFoco);
    let dados;
    if (ehCriaturaControlada) {
        dados = montarAcoesEPassivasCriaturaV67JS(inimFoco, null);
    } else {
        const ativasH = { OFENSIVO: [], DEFENSIVO: [], BUFF: [], DEBUFFS: [], CURA: [] };
        const acoesBase = (heroiAtivo && typeof obterRepertorioAcoesCompletasPersonagemMesaJS === 'function')
            ? obterRepertorioAcoesCompletasPersonagemMesaJS(heroiAtivo) : [];
        acoesBase.forEach(ac => {
            const cat = classificarCategoriaAcaoAtivaV67JS(ac.nome, ac.categoria, ac.desc);
            ativasH[cat].push({ id: ac.cod, nome: ac.nome, icone: ac.icone, custoPM: ac.custoPM || 0, cat, cor: ac.cor, desc: ac.desc || '', arma: ac.arma || '' });
        });
        if (ativasH.DEFENSIVO.length === 0) ativasH.DEFENSIVO.push({ id: 'DEFESA_TOTAL', nome: 'Defesa Total (+4 Def)', icone: '', custoPM: 0, cat: 'DEFENSIVO', cor: 'linear-gradient(135deg,#1E3A8A,#2563EB)', desc: '+4 Defesa até o próximo turno.' });
        if (ativasH.BUFF.length === 0) ativasH.BUFF.push({ id: 'BUFF_INSPIRACAO', nome: 'Inspirar / Foco Tático (+2 Atq)', icone: '', custoPM: 1, cat: 'BUFF', cor: 'linear-gradient(135deg,#B45309,#F59E0B)', desc: 'Concede bônus de ataque para o grupo.' });
        if (ativasH.DEBUFFS.length === 0) ativasH.DEBUFFS.push({ id: 'DEBUFF_DERRUBAR', nome: 'Derrubar / Fintar (-5 Def)', icone: '', custoPM: 0, cat: 'DEBUFFS', cor: 'linear-gradient(135deg,#581C87,#9333EA)', desc: 'Aplica condição tática no inimigo.' });
        if (ativasH.CURA.length === 0) ativasH.CURA.push({ id: 'CURA_POCAO', nome: 'Poção de Cura (+PV)', icone: '', custoPM: 0, cat: 'CURA', cor: 'linear-gradient(135deg,#065F46,#10B981)', desc: 'Recupera PV imediatamente.' });
        dados = { ativas: ativasH, passivas: [{ nome: 'Passivas da Ficha', origem: heroiAtivo ? heroiAtivo.classe : 'Herói', desc: 'Traços raciais e poderes passivos aplicados automaticamente.' }] };
    }

    const catsMeta = [
        { k: 'OFENSIVO', label: 'Ofensivo' },
        { k: 'DEFENSIVO', label: 'Defensivo' },
        { k: 'BUFF', label: 'Buff' },
        { k: 'DEBUFFS', label: 'Debuffs' },
        { k: 'CURA', label: 'Cura' }
    ];
    const tabsHTML = catsMeta.map(c => `
        <button type="button" class="t20-v67-cat-btn ${catAtiva === c.k ? 'cat-active-' + c.k : ''}"
                onclick="selecionarCategoriaAcaoV67JS('MESA', '${c.k}')">
            <span>${c.label}</span>
            <span class="t20-v67-cat-count">${(dados.ativas[c.k] || []).length}</span>
        </button>
    `).join('');

    const listaAcoesCat = dados.ativas[catAtiva] || [];
    const cardsHTML = listaAcoesCat.map(ac => {
        const nmSafe = String(ac.nome || '').replace(/'/g, '');
        const idSafe = String(ac.id || '').replace(/'/g, '');
        const onClickCode = ehCriaturaControlada
            ? `executarHabilidadeControladaCriaturaV67JS('MESA', ${focoIdx}, '${idSafe}', '${nmSafe}', '${catAtiva}', ${Boolean(ac.ehArea)})`
            : `executarAcaoEspecificaPersonagemMesaOnlineJS('${heroiAtivo ? heroiAtivo.idHeroi : ''}', '${idSafe}', '${nmSafe}', ${ac.custoPM || 0}, '${catAtiva}', '${String(ac.arma || '').replace(/'/g, '')}')`;
        return `
            <button type="button" class="t20-v67-action-card" style="background:${ac.cor};" title="${String(ac.desc || '').replace(/"/g, '&quot;')}" onclick="${onClickCode}">
                <span>${ac.icone}</span>
                <span>${ac.nome}</span>
                ${ac.custoPM > 0 ? `<span class="t20-v67-pm-badge">${ac.custoPM} PM</span>` : ''}
            </button>
        `;
    }).join('');

    box.innerHTML = `
        <div class="t20-clicked-char-dock">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;">
                ${seletorTokensMesaHTML}
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                    <span style="font-size:10.5px;color:${ehCriaturaControlada ? '#FCA5A5' : '#FDE047'};font-weight:900;">
                        ${ehCriaturaControlada ? `Controlando ${inimFoco.nome} (Toque no grid p/ mover!)` : (heroiAtivo ? `${heroiAtivo.nome} (Ativas em destaque)` : '')}
                    </span>
                    <button type="button" class="t20-passives-toggle-btn" onclick="alternarMenuLateralPassivasJS('MESA')">
                        Passivas (${dados.passivas.length})
                    </button>
                </div>
            </div>
            <div class="t20-v67-cat-tabs">${tabsHTML}</div>
            <div class="t20-v67-actions-grid">${cardsHTML}</div>
        </div>
    `;

    const dr = document.getElementById('t20-passives-side-drawer');
    if (dr && dr.classList.contains('drawer-open')) atualizarConteudoMenuLateralPassivasJS('MESA');
}

// 12. Permitir mover a CRIATURA CONTROLADA ao clicar no Grid da Arena ou da Mesa Online!
const __MOVER_ARENA_ORIG_V66__ = (typeof moverHeroiParaCelulaGridArenaJS === 'function') ? moverHeroiParaCelulaGridArenaJS : null;
function moverHeroiParaCelulaGridArenaJS(gx, gy) {
    const sel = window.__PERSONAGEM_CLICADO_ARENA__;
    if (sel && sel.tipo === 'AMEACA' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
        const a = __ARENA_STATE__;
        const cr = (a.listaCriaturas || [])[Number(sel.id || 0)];
        if (cr) {
            const origX = Number(cr.gx || 6);
            const origY = Number(cr.gy || 2);
            const destX = Math.max(0, Math.min(119, Number(gx)));
            const destY = Math.max(0, Math.min(119, Number(gy)));
            const distQ = Math.max(Math.abs(destX - origX), Math.abs(destY - origY));
            const passos = (typeof gerarPassosInterpoladosGrid2D === 'function') ? gerarPassosInterpoladosGrid2D(origX, origY, destX, destY, 6) : [{ gx: destX, gy: destY }];
            window.__TRILHA_MOVIMENTO_ATIVA__ = {
                gxOrig: origX, gyOrig: origY, gxDest: destX, gyDest: destY,
                passos, distMetros: distQ * 1.5, distQ, timestamp: Date.now(), contexto: 'ARENA'
            };
            cr.gx = destX;
            cr.gy = destY;
            try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
            if (typeof registrarLinhaLogArena === 'function') {
                registrarLinhaLogArena(`<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> moveu ${(distQ * 1.5).toFixed(1)}m (${distQ}q) até (${destX + 1}, ${destY + 1}).`);
            }
            if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
            return;
        }
    }
    if (__MOVER_ARENA_ORIG_V66__) return __MOVER_ARENA_ORIG_V66__(gx, gy);
}

const __MOVER_MESA_ORIG_V66__ = (typeof clicarCelulaGrid2DMesaOnlineJS === 'function') ? clicarCelulaGrid2DMesaOnlineJS : null;
function clicarCelulaGrid2DMesaOnlineJS(gx, gy) {
    const sel = window.__PERSONAGEM_CLICADO_MESA__;
    if (sel && sel.tipo === 'AMEACA_MESA' && ESTADO_MESA_ONLINE_ATUAL) {
        const cr = (ESTADO_MESA_ONLINE_ATUAL.listaInimigosMesa || [])[Number(sel.id || 0)];
        if (cr) {
            const origX = Number(cr.gx || 6);
            const origY = Number(cr.gy || 2);
            const destX = Math.max(0, Math.min(119, Number(gx)));
            const destY = Math.max(0, Math.min(119, Number(gy)));
            const distQ = Math.max(Math.abs(destX - origX), Math.abs(destY - origY));
            const passos = (typeof gerarPassosInterpoladosGrid2D === 'function') ? gerarPassosInterpoladosGrid2D(origX, origY, destX, destY, 6) : [{ gx: destX, gy: destY }];
            window.__TRILHA_MOVIMENTO_ATIVA__ = {
                gxOrig: origX, gyOrig: origY, gxDest: destX, gyDest: destY,
                passos, distMetros: distQ * 1.5, distQ, timestamp: Date.now(), contexto: 'MESA'
            };
            cr.gx = destX;
            cr.gy = destY;
            if (typeof registrarLogMesaOnline === 'function') {
                registrarLogMesaOnline(`[Criatura Controlada] ${cr.nome} moveu ${(distQ * 1.5).toFixed(1)}m até (${destX + 1}, ${destY + 1}).`);
            }
            if (typeof renderizarMesaOnlineCompletaUI === 'function') renderizarMesaOnlineCompletaUI();
            return;
        }
    }
    if (__MOVER_MESA_ORIG_V66__) return __MOVER_MESA_ORIG_V66__(gx, gy);
}

// Exports globais v67
window.ehHabilidadePassivaT20JS = ehHabilidadePassivaT20JS;
window.classificarCategoriaAcaoAtivaV67JS = classificarCategoriaAcaoAtivaV67JS;
window.obterAnimacaoPropriaCategoriaV67JS = obterAnimacaoPropriaCategoriaV67JS;
window.montarAcoesEPassivasHeroiV67JS = montarAcoesEPassivasHeroiV67JS;
window.montarAcoesEPassivasCriaturaV67JS = montarAcoesEPassivasCriaturaV67JS;
window.alternarMenuLateralPassivasJS = alternarMenuLateralPassivasJS;
window.atualizarConteudoMenuLateralPassivasJS = atualizarConteudoMenuLateralPassivasJS;
window.executarHabilidadeControladaCriaturaV67JS = executarHabilidadeControladaCriaturaV67JS;
window.executarAcaoCategorizadaHeroiArenaV67JS = executarAcaoCategorizadaHeroiArenaV67JS;
window.selecionarCategoriaAcaoV67JS = selecionarCategoriaAcaoV67JS;
window.renderizarPainelAcoesPersonagemClicadoArenaJS = renderizarPainelAcoesPersonagemClicadoArenaJS;
window.renderizarPainelAcoesPersonagemClicadoMesaJS = renderizarPainelAcoesPersonagemClicadoMesaJS;
window.moverHeroiParaCelulaGridArenaJS = moverHeroiParaCelulaGridArenaJS;
window.clicarCelulaGrid2DMesaOnlineJS = clicarCelulaGrid2DMesaOnlineJS;




// ======================================================================================
// // 1. FIX PASSIVAS EM TELA CHEIA (Re-parenting no Fullscreen Element + Backdrop)
// 2. PARSER LIMPO DE AÇÕES DE AMEAÇAS + CARDS DE HABILIDADES POLIDOS (2 LINHAS)
// 3. SISTEMA DE REAÇÕES INTELIGENTES PARA O OPONENTE NÃO CONTROLADO (HERÓI IA & AMEAÇA IA)
// 4. ANIMAÇÕES COESAS COM DIFERENCIAÇÃO VISUAL: ACERTO / CRÍTICO / ERRO / REAÇÃO / RESISTÊNCIA
// 5. SISTEMA VTT COMPLETO NA ARENA E NA MESA ONLINE (RÉGUA, ÁREAS, PING, NÉVOA, CONDIÇÕES, DADOS)
// ======================================================================================

window.__VTT_STATE__ = window.__VTT_STATE__ || {
    ferramenta: 'MOVER', // 'MOVER' | 'REGUA' | 'AREA_ESFERA' | 'AREA_CONE' | 'AREA_LINHA' | 'PING'
    reguaOrigem: null,
    reguaDestino: null,
    areaAtiva: null,     // { tipo: 'ESFERA'|'CONE'|'LINHA', gx, gy, raioQ, contexto }
    pingAtivo: null,     // { gx, gy, timestamp, contexto }
    nevoaGuerra: false,
    ultimoDadoVTT: ''
};

// --- 1. FIX DEFINITIVO DO MENU LATERAL DE PASSIVAS (FUNCIONA EM TELA CHEIA E NORMAL!) ---
function obterContainerFullscreenAtivoV68JS(contexto) {
    const fsEl = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement;
    if (fsEl) return fsEl;
    if (window.__TELA_CHEIA_COMBATE_ATIVA__ === 'ARENA' || contexto === 'ARENA') {
        const sh = document.getElementById('arena-combat-screen-shell');
        if (sh && sh.classList.contains('t20-combat-fullscreen-active')) return sh;
    }
    if (window.__TELA_CHEIA_COMBATE_ATIVA__ === 'MESA' || contexto === 'MESA') {
        const sh = document.getElementById('mesa-combat-screen-shell');
        if (sh && sh.classList.contains('t20-combat-fullscreen-active')) return sh;
    }
    return document.body;
}

function garantirDrawerPassivasDOMJS() {
    const host = obterContainerFullscreenAtivoV68JS(window.__PASSIVAS_DRAWER_CONTEXTO_V67__);
    let backdrop = document.getElementById('t20-passives-backdrop');
    if (!backdrop) {
        backdrop = document.createElement('div');
        backdrop.id = 't20-passives-backdrop';
        backdrop.setAttribute('onclick', 'alternarMenuLateralPassivasJS(null, false)');
    }
    if (backdrop.parentNode !== host && host && typeof host.appendChild === 'function') {
        host.appendChild(backdrop);
    }

    let drawer = document.getElementById('t20-passives-side-drawer');
    if (!drawer) {
        drawer = document.createElement('div');
        drawer.id = 't20-passives-side-drawer';
        drawer.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 14px;background:linear-gradient(90deg,#1E1B4B,#0F172A);border-bottom:2px solid #D4AF37;">
                <div>
                    <div style="font-size:13.5px;font-weight:900;color:#FACC15;">Habilidades &amp; Poderes Passivos</div>
                    <div id="t20-passives-drawer-subtitle" style="font-size:10.5px;color:#93C5FD;font-weight:700;">Sempre ativos automaticamente</div>
                </div>
                <button type="button" class="btn-roll-inline" style="background:#991B1B;border-color:#FCA5A5;color:#FFF;font-weight:900;padding:4px 9px;" onclick="alternarMenuLateralPassivasJS(null, false)"></button>
            </div>
            <div id="t20-passives-drawer-body" style="flex:1;overflow-y:auto;padding:12px;"></div>
        `;
    }
    if (drawer.parentNode !== host && host && typeof host.appendChild === 'function') {
        host.appendChild(drawer);
    }
    return drawer;
}

function alternarMenuLateralPassivasJS(contexto, forcarEstado) {
    if (contexto) window.__PASSIVAS_DRAWER_CONTEXTO_V67__ = contexto;
    const drawer = garantirDrawerPassivasDOMJS();
    const backdrop = document.getElementById('t20-passives-backdrop');
    if (typeof atualizarConteudoMenuLateralPassivasJS === 'function') {
        atualizarConteudoMenuLateralPassivasJS(window.__PASSIVAS_DRAWER_CONTEXTO_V67__);
    }
    const abrir = (typeof forcarEstado === 'boolean') ? forcarEstado : !drawer.classList.contains('drawer-open');
    if (abrir) {
        drawer.classList.add('drawer-open');
        if (backdrop) backdrop.classList.add('drawer-open');
    } else {
        drawer.classList.remove('drawer-open');
        if (backdrop) backdrop.classList.remove('drawer-open');
    }
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
}

// --- 2. PARSER LIMPO DE AÇÕES DE CRIATURAS (SEM CORTES CONFUSOS NO MEIO DE PARÊNTESES) ---
function dividirRespeitandoParentesesV68JS(texto) {
    const out = [];
    let cur = '';
    let depth = 0;
    const s = String(texto || '');
    for (let i = 0; i < s.length; i++) {
        const ch = s[i];
        if (ch === '(') depth++;
        else if (ch === ')' && depth > 0) depth--;
        if ((ch === ';' || ch === ',' || ch === '|') && depth === 0) {
            if (cur.trim().length > 2) out.push(cur.trim());
            cur = '';
        } else {
            cur += ch;
        }
    }
    if (cur.trim().length > 2) out.push(cur.trim());
    return out;
}

function montarAcoesEPassivasCriaturaV67JS(crObj, privFallback) {
    const ativas = { OFENSIVO: [], DEFENSIVO: [], BUFF: [], DEBUFFS: [], CURA: [] };
    const passivas = [];

    const nomeCr = (crObj && (crObj.nomeCriatura || crObj.nome)) || (privFallback && privFallback.nomeCriatura) || 'Ameaça';
    const ataquesTxt = (crObj && (crObj.ataquesResumo || crObj.ataquesTexto)) || (privFallback && privFallback.ataquesResumo) || 'Ataque Corpo a Corpo';
    const habsTxt = (crObj && (crObj.habilidadesResumo || crObj.habilidadesTexto)) || (privFallback && privFallback.habilidadesResumo) || '';
    const atqBonus = Number((crObj && crObj.ataque) || (privFallback && privFallback.ataque) || 10);
    const danoMed = Number((crObj && (crObj.danoMedio || crObj.dano_medio)) || (privFallback && privFallback.danoMedio) || 16);
    const cdEf = Number((crObj && crObj.cdEfeito) || (privFallback && privFallback.cdEfeito) || 18);

    // 1. Ataques Oficiais estruturados e limpos
    const blocosAtq = dividirRespeitandoParentesesV68JS(ataquesTxt);
    const nomesAtqUsados = new Set();
    blocosAtq.slice(0, 4).forEach((raw, i) => {
        // Extrai nome limpo antes do +X ou (
        const mNome = raw.match(/^([^+(]+)/);
        let nomeLimpo = (mNome ? mNome[1] : raw).replace(/^e\s+/i, '').trim();
        if (!nomeLimpo || nomeLimpo.length < 2) nomeLimpo = `Ataque Principal #${i + 1}`;
        if (nomeLimpo.length > 26) nomeLimpo = nomeLimpo.slice(0, 25) + '…';
        if (nomesAtqUsados.has(nomeLimpo.toLowerCase())) return;
        nomesAtqUsados.add(nomeLimpo.toLowerCase());

        const ehArea = /sopro|cone|área|area|explos|baforada|onda/i.test(raw);
        const ehDist = /arco|besta|disparo|pedra|raio|jato|arremesso/i.test(raw);
        ativas.OFENSIVO.push({
            id: `CRIATURA_ATQ_${i}`,
            nome: nomeLimpo,
            icone: ehArea ? '' : (ehDist ? '' : ''),
            custoPM: 0,
            cat: 'OFENSIVO',
            metaPill1: ehArea ? `CD ${cdEf} (Ref)` : `Atq +${atqBonus}`,
            metaPill2: `Dano ~${danoMed}`,
            desc: raw,
            danoMult: i === 0 ? 1.0 : 0.92,
            ehArea,
            tipoTeste: ehArea ? 'RESISTENCIA' : 'ATAQUE'
        });
    });

    if (ativas.OFENSIVO.length === 0) {
        ativas.OFENSIVO.push({
            id: 'CRIATURA_ATQ_0',
            nome: 'Golpe Brutal',
            icone: '',
            custoPM: 0,
            cat: 'OFENSIVO',
            metaPill1: `Atq +${atqBonus}`,
            metaPill2: `Dano ~${danoMed}`,
            desc: `Ataque principal oficial de ${nomeCr}.`,
            danoMult: 1.0,
            ehArea: false,
            tipoTeste: 'ATAQUE'
        });
    }

    // 2. Habilidades Especiais separadas com clareza entre Passivas (Menu Lateral) e Ativas (5 Categorias)
    const blocosHab = dividirRespeitandoParentesesV68JS(habsTxt);
    blocosHab.forEach((raw, i) => {
        const ehPassivaCr = /(^rd\s*\d+|redução de dano|imunidade|imune|visão|visao|faro|sentidos|resistência|resistencia|vulnerabilidade|deslocamento|voo|natação|escalada)/i.test(raw);
        const mNome = raw.match(/^([^(:]+)/);
        let nomeLimpo = (mNome ? mNome[1] : raw).trim();
        if (nomeLimpo.length > 26) nomeLimpo = nomeLimpo.slice(0, 25) + '…';

        if (ehPassivaCr) {
            passivas.push({ nome: nomeLimpo, origem: `Passiva · ${nomeCr}`, desc: raw });
        } else {
            const cat = classificarCategoriaAcaoAtivaV67JS(raw, 'CRIATURA', raw);
            const icoMap = { OFENSIVO: '', DEFENSIVO: '', BUFF: '', DEBUFFS: '', CURA: '' };
            ativas[cat].push({
                id: `CRIATURA_HAB_${i}`,
                nome: nomeLimpo,
                icone: icoMap[cat] || '',
                custoPM: 0,
                cat,
                metaPill1: (cat === 'DEBUFFS' || cat === 'OFENSIVO') ? `CD ${cdEf}` : (cat === 'CURA' ? '+15% PV' : 'Especial'),
                metaPill2: /área|area|cone|aura|sopro/i.test(raw) ? 'Área' : 'Ativa',
                desc: raw,
                danoMult: cat === 'OFENSIVO' ? 1.15 : 0.0,
                ehArea: /área|area|cone|aura|sopro/i.test(raw),
                tipoTeste: (cat === 'DEBUFFS' || /sopro|cone|aura|magia/i.test(raw)) ? 'RESISTENCIA' : 'ATAQUE'
            });
        }
    });

    // Garantir ações táticas limpas em todas as categorias
    if (ativas.DEFENSIVO.length === 0) {
        ativas.DEFENSIVO.push({ id: 'CRIATURA_DEF_TOTAL', nome: 'Postura Defensiva', icone: '', custoPM: 0, cat: 'DEFENSIVO', metaPill1: '+4 Defesa', metaPill2: '1 Turno', desc: `${nomeCr} protege seus pontos vitais (+4 Def até o próximo turno).` });
    }
    if (ativas.BUFF.length === 0) {
        ativas.BUFF.push({ id: 'CRIATURA_BUFF_RUGIDO', nome: 'Rugido Predatório', icone: '', custoPM: 0, cat: 'BUFF', metaPill1: '+2 Atq', metaPill2: '+15% Dano', desc: `${nomeCr} entra em fúria predatória para o próximo golpe.` });
    }
    if (ativas.DEBUFFS.length === 0) {
        ativas.DEBUFFS.push({ id: 'CRIATURA_DEBUFF_TERROR', nome: 'Presença Aterradora', icone: '', custoPM: 0, cat: 'DEBUFFS', metaPill1: `Vontade CD ${cdEf}`, metaPill2: 'Abalado -2', desc: `Exige teste de Vontade (CD ${cdEf}) ou deixa o alvo Abalado (-2 em testes).`, tipoTeste: 'RESISTENCIA' });
    }
    if (ativas.CURA.length === 0) {
        ativas.CURA.push({ id: 'CRIATURA_CURA_FOLEGO', nome: 'Regenerar Fôlego', icone: '', custoPM: 0, cat: 'CURA', metaPill1: '+15% PV', metaPill2: 'Pessoal', desc: `${nomeCr} recupera parte dos seus Pontos de Vida oficiais.` });
    }

    const fort = Number((crObj && crObj.fortitude) || (privFallback && privFallback.fortitude) || 8);
    const refl = Number((crObj && crObj.reflexos) || (privFallback && privFallback.reflexos) || 8);
    const vont = Number((crObj && crObj.vontade) || (privFallback && privFallback.vontade) || 6);
    passivas.unshift({
        nome: 'Ficha Oficial (100% Livro — Sem Redução)',
        origem: nomeCr,
        desc: `Defesa ${crObj ? crObj.defesa : (privFallback ? privFallback.defesa : 20)} | Ataque +${atqBonus} | Dano Médio ${danoMed} | Fort +${fort} / Ref +${refl} / Von +${vont} | CD ${cdEf}`
    });

    return { ativas, passivas };
}

// --- 3. SISTEMA DE REAÇÕES INTELIGENTES PARA O OPONENTE NÃO CONTROLADO (HERÓI IA OU CRIATURA IA) ---
function avaliarReacaoInteligenteOponenteV68JS(params) {
    // params: { alvoTipo: 'HEROI'|'CRIATURA', tipoAtaque: 'ATAQUE'|'RESISTENCIA', rolagemAtq, defesaAlvo, danoBruto, rolagemRes, cdAlvo, stHeroi, estadoArena, criaturaObj }
    const p = params || {};

    if (p.alvoTipo === 'HEROI') {
        const a = p.estadoArena;
        const st = p.stHeroi || (typeof garantirEstadoFichaParaArena === 'function' ? garantirEstadoFichaParaArena() : null);
        if (!a || !st || a.reacaoDisponivel === false) return { disparou: false };
        const cls = (st.classe && st.classe.nome) ? st.classe.nome : 'Guerreiro';
        const pmAtual = Number(a.pmHeroi || 0);
        const pvMax = Math.max(1, Number(a.pvHeroiMax || 40));

        if (p.tipoAtaque === 'ATAQUE') {
            const margem = Number(p.rolagemAtq || 0) - Number(p.defesaAlvo || 18);
            // 1) Se um bônus defensivo (+5 Armadura Arcana ou +4 Aparar/Esquiva) transformar ACERTO em ERRO!
            if (margem >= 0 && margem <= 5 && pmAtual >= 2) {
                const ehArcano = ['Arcanista', 'Bardo', 'Clérigo', 'Druida'].includes(cls);
                const nomeReac = ehArcano ? 'Armadura Arcana (+5 Def)' : (['Ladino', 'Bucaneiro', 'Caçador'].includes(cls) ? 'Esquiva Sobrenatural (+5 Def)' : 'Aparar / Égide (+5 Def)');
                a.pmHeroi = Math.max(0, pmAtual - 2);
                a.reacaoDisponivel = false;
                return { disparou: true, bloqueouTotal: true, nome: nomeReac, custoPM: 2, danoFinal: 0, texto: `REAÇÃO DO HERÓI: ${nomeReac} (-2 PM) elevou a Defesa para ${Number(p.defesaAlvo) + 5} e ANULOU o ataque!` };
            }
            // 2) Se o golpe acertou forte (>= 20% do PV ou crítico): reduz dano pela metade ou RD 30!
            if (margem >= 0 && Number(p.danoBruto || 0) >= Math.max(8, pvMax * 0.20)) {
                if (cls === 'Guerreiro' && pmAtual >= 3) {
                    const danoRed = Math.floor(p.danoBruto / 2);
                    a.pmHeroi = Math.max(0, pmAtual - 3);
                    a.reacaoDisponivel = false;
                    return { disparou: true, bloqueouTotal: false, nome: 'Durão (½ Dano)', custoPM: 3, danoFinal: danoRed, texto: `REAÇÃO DO HERÓI: Durão (-3 PM) reduziu o dano de ${p.danoBruto} para ${danoRed}!` };
                }
                if (['Arcanista', 'Bardo', 'Clérigo', 'Druida'].includes(cls) && pmAtual >= 4) {
                    const danoRed = Math.max(0, p.danoBruto - 30);
                    a.pmHeroi = Math.max(0, pmAtual - 4);
                    a.reacaoDisponivel = false;
                    return { disparou: true, bloqueouTotal: danoRed === 0, nome: 'Campo de Força (RD 30)', custoPM: 4, danoFinal: danoRed, texto: `REAÇÃO DO HERÓI: Campo de Força (-4 PM) absorveu até 30 de dano (${p.danoBruto} ${danoRed})!` };
                }
                if (pmAtual >= 2) {
                    const danoRed = Math.floor(p.danoBruto * 0.5);
                    a.pmHeroi = Math.max(0, pmAtual - 2);
                    a.reacaoDisponivel = false;
                    return { disparou: true, bloqueouTotal: false, nome: 'Rolamento / Bloqueio (½ Dano)', custoPM: 2, danoFinal: danoRed, texto: `REAÇÃO DO HERÓI: Rolamento Defensivo (-2 PM) reduziu o dano de ${p.danoBruto} para ${danoRed}!` };
                }
            }
        } else if (p.tipoAtaque === 'RESISTENCIA') {
            // Se o Herói falhou na resistência por até 4 pontos, usa Determinação / Vontade Heroica (2 PM) para passar!
            const deficit = Number(p.cdAlvo || 18) - Number(p.rolagemRes || 10);
            if (deficit > 0 && deficit <= 4 && pmAtual >= 2) {
                a.pmHeroi = Math.max(0, pmAtual - 2);
                a.reacaoDisponivel = false;
                return { disparou: true, passouResistencia: true, nome: 'Determinação Heroica (+4 Res)', custoPM: 2, texto: `REAÇÃO DO HERÓI: Determinação Heroica (-2 PM) somou +4 e garantiu SUCESSO na Resistência!` };
            }
        }
        return { disparou: false };
    }

    // Alvo é CRIATURA (IA inteligente quando usuário controla o Herói)
    if (p.alvoTipo === 'CRIATURA' && p.criaturaObj) {
        const cr = p.criaturaObj;
        const turnoAtual = (p.estadoArena && p.estadoArena.turno) ? p.estadoArena.turno : 1;
        if (cr._ultimaRodadaReacaoV68 === turnoAtual) return { disparou: false };

        if (p.tipoAtaque === 'ATAQUE') {
            const margem = Number(p.rolagemAtq || 0) - Number(p.defesaAlvo || 20);
            if (margem >= 0 && margem <= 3) {
                cr._ultimaRodadaReacaoV68 = turnoAtual;
                return { disparou: true, bloqueouTotal: true, nome: 'Esquiva Instintiva (+4 Def)', danoFinal: 0, texto: `REAÇÃO DA AMEAÇA: ${cr.nomeCriatura || cr.nome} usou Esquiva Instintiva (+4 Def) e DESVIOU do golpe!` };
            }
            if (margem >= 0 && Number(p.danoBruto || 0) >= Math.max(15, Number(cr.pvMax || 60) * 0.25)) {
                cr._ultimaRodadaReacaoV68 = turnoAtual;
                const danoRed = Math.round(p.danoBruto * 0.70);
                return { disparou: true, bloqueouTotal: false, nome: 'Escamas / Couro Endurecido (-30%)', danoFinal: danoRed, texto: `REAÇÃO DA AMEAÇA: ${cr.nomeCriatura || cr.nome} endureceu a guarda e reduziu o dano (${p.danoBruto} ${danoRed})!` };
            }
        } else if (p.tipoAtaque === 'RESISTENCIA') {
            const deficit = Number(p.cdAlvo || 18) - Number(p.rolagemRes || 10);
            if (deficit > 0 && deficit <= 3) {
                cr._ultimaRodadaReacaoV68 = turnoAtual;
                return { disparou: true, passouResistencia: true, nome: 'Resistência Instintiva (+4 Res)', texto: `REAÇÃO DA AMEAÇA: ${cr.nomeCriatura || cr.nome} usou Resistência Instintiva (+4) e RESISTIU ao efeito!` };
            }
        }
    }
    return { disparou: false };
}

// --- 4. EXECUÇÃO CONTROLADA DA CRIATURA COM REAÇÃO INTELIGENTE DO HERÓI + ANIMAÇÃO COESA ACERTO/ERRO/RESISTÊNCIA ---
function executarHabilidadeControladaCriaturaV67JS(contexto, idxCriatura, acaoId, nomeAcao, catV67, ehArea) {
    const animCode = obterAnimacaoPropriaCategoriaV67JS(nomeAcao, catV67);

    if (contexto === 'MESA' && ESTADO_MESA_ONLINE_ATUAL) {
        const m = ESTADO_MESA_ONLINE_ATUAL;
        const cr = (m.listaInimigosMesa || [])[Number(idxCriatura || 0)];
        const parts = m.participantes || [];
        const alvoH = parts.find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || parts[0];
        if (!cr) return;

        let msg = '', resAnim = 'BUFF', detRol = '', valEff = '';
        if (catV67 === 'CURA') {
            const cura = Math.max(8, Math.round(cr.pvMax * 0.15));
            cr.pvAtual = Math.min(cr.pvMax, cr.pvAtual + cura);
            resAnim = 'CURA'; valEff = `+${cura} PV`;
            msg = `[Criatura Controlada] ${cr.nome} usou ${nomeAcao} e recuperou +${cura} PV (${cr.pvAtual}/${cr.pvMax})!`;
        } else if (catV67 === 'DEFENSIVO') {
            cr._bonusDefTempV67 = 4; resAnim = 'DEFESA'; valEff = '+4 Defesa';
            msg = `[Criatura Controlada] ${cr.nome} assumiu ${nomeAcao} (+4 Def)!`;
        } else if (catV67 === 'BUFF') {
            cr._buffAtqTempV67 = 2; resAnim = 'BUFF'; valEff = '+2 Atq / +15%';
            msg = `[Criatura Controlada] ${cr.nome} ativou ${nomeAcao} (+2 Atq / +15% Dano)!`;
        } else if (catV67 === 'DEBUFFS' || ehArea) {
            const cd = Number(cr.cdEfeito || 18);
            const d20 = Math.floor(Math.random() * 20) + 1;
            const totalRes = d20 + 6;
            const passou = totalRes >= cd;
            detRol = `Res d20(${d20})+6=${totalRes} vs CD ${cd}`;
            if (ehArea) {
                const danoBase = Math.max(6, Math.round(Number(cr.danoMedio || 16) * (passou ? 0.5 : 1.0)));
                parts.forEach(p => { p.pvAtual = Math.max(0, p.pvAtual - danoBase); });
                resAnim = passou ? 'RES_SUCESSO' : 'RES_FALHA';
                valEff = passou ? `½ Dano (-${danoBase} PV)` : `-${danoBase} PV`;
                msg = `[Criatura Controlada] ${cr.nome} usou ${nomeAcao} (CD ${cd}): ${detRol} — ${passou ? 'RESISTIU (½ Dano)!' : 'FALHOU (Dano Total)!'} (-${danoBase} PV)`;
            } else {
                resAnim = passou ? 'RES_SUCESSO' : 'RES_FALHA';
                valEff = passou ? 'Anulado' : 'Abalado (-2)';
                msg = `[Criatura Controlada] ${cr.nome} usou ${nomeAcao} (${detRol}) — ${passou ? 'RESISTIU!' : 'FALHOU (Abalado -2)!'}`;
            }
        } else {
            const d20 = Math.floor(Math.random() * 20) + 1;
            const bonusAtq = Number(cr.ataque || 10) + Number(cr._buffAtqTempV67 || 0);
            const totalAtq = d20 + bonusAtq;
            const defAlvo = Number((alvoH && alvoH.defesa) || 20);
            const danoBruto = Math.max(4, Math.round(Number(cr.danoMedio || 16) * (0.85 + Math.random() * 0.30) * (cr._buffAtqTempV67 ? 1.15 : 1.0)));
            cr._buffAtqTempV67 = 0;
            detRol = `d20(${d20})+${bonusAtq}=${totalAtq} vs Def ${defAlvo}`;
            if (alvoH && (d20 === 20 || totalAtq >= defAlvo)) {
                const danoFinal = d20 === 20 ? Math.round(danoBruto * 1.5) : danoBruto;
                alvoH.pvAtual = Math.max(0, alvoH.pvAtual - danoFinal);
                resAnim = d20 === 20 ? 'CRITICO' : 'ACERTO';
                valEff = `-${danoFinal} PV`;
                msg = `[Criatura Controlada] ${cr.nome} usou ${nomeAcao} em ${alvoH.nome}: ${detRol} — ${d20 === 20 ? 'CRÍTICO!' : 'ACERTOU!'} (-${danoFinal} PV)`;
            } else {
                resAnim = 'ERRO';
                valEff = 'Esquivou!';
                msg = `[Criatura Controlada] ${cr.nome} usou ${nomeAcao} em ${alvoH ? alvoH.nome : 'Herói'}: ${detRol} — ERROU!`;
            }
        }

        if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function') {
            dispararAnimacaoCoreografadaPalco2DJS({
                tipo: animCode, resultado: resAnim, detalheRolagem: detRol, valorDanoOuEfeito: valEff,
                ladoAlvo: (catV67 === 'CURA' || catV67 === 'DEFENSIVO' || catV67 === 'BUFF') ? 'CRIATURA' : 'HEROI',
                origem: { gx: cr.gx || 6, gy: cr.gy || 2 },
                destino: (catV67 === 'CURA' || catV67 === 'DEFENSIVO' || catV67 === 'BUFF') ? { gx: cr.gx || 6, gy: cr.gy || 2 } : { gx: alvoH ? alvoH.gx : 2, gy: alvoH ? alvoH.gy : 2 },
                label: `${cr.nome.slice(0,12)}: ${nomeAcao.slice(0,18)}`
            });
        }
        if (typeof registrarLogMesaOnline === 'function') registrarLogMesaOnline(msg);
        renderizarMesaOnlineCompletaUI();
        renderizarPainelAcoesPersonagemClicadoMesaJS();
        return;
    }

    // Contexto ARENA (com Sistema de Reações Inteligentes do Herói IA!)
    if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario();
    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    if (!a) return;
    const cr = (a.listaCriaturas || [])[Number(idxCriatura || 0)];
    const priv = a._privadoCriatura;
    if (!cr || !priv) return;

    // Restaura reação do Herói no turno da criatura se necessário
    if (a.reacaoDisponivel === undefined) a.reacaoDisponivel = true;

    let msgArena = '', resAnim = 'BUFF', detRol = '', valEff = '', reacaoTexto = '';
    if (catV67 === 'CURA') {
        const cura = Math.max(10, Math.round(cr.pvMax * 0.15));
        cr.pvAtual = Math.min(cr.pvMax, cr.pvAtual + cura);
        priv.pvAtual = cr.pvAtual;
        resAnim = 'CURA'; valEff = `+${cura} PV`;
        msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> usou <strong>${nomeAcao}</strong> e regenerou <strong>+${cura} PV</strong> (${cr.pvAtual}/${cr.pvMax} PV)!`;
    } else if (catV67 === 'DEFENSIVO') {
        cr._bonusDefTempV67 = 4; resAnim = 'DEFESA'; valEff = '+4 Defesa';
        msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> assumiu <strong>${nomeAcao}</strong> (+4 na Defesa)!`;
    } else if (catV67 === 'BUFF') {
        cr._buffAtqTempV67 = 2; resAnim = 'BUFF'; valEff = '+2 Atq / +15%';
        msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> ativou <strong>${nomeAcao}</strong> (+2 Ataque e +15% Dano)!`;
    } else if (catV67 === 'DEBUFFS' || ehArea) {
        const cd = Number(cr.cdEfeito || priv.cdEfeito || 18);
        const d20 = Math.floor(Math.random() * 20) + 1;
        let resH = d20 + 6;
        let passou = resH >= cd;
        if (!passou) {
            const reac = avaliarReacaoInteligenteOponenteV68JS({ alvoTipo: 'HEROI', tipoAtaque: 'RESISTENCIA', rolagemRes: resH, cdAlvo: cd, stHeroi: st, estadoArena: a });
            if (reac.disparou && reac.passouResistencia) {
                passou = true; resH += 4; reacaoTexto = reac.texto;
            }
        }
        detRol = `Res d20(${d20})+${passou && reacaoTexto ? 10 : 6}=${resH} vs CD ${cd}`;
        if (ehArea) {
            const danoBase = Math.max(6, Math.round(Number(cr.danoMedio || priv.danoMedio || 16) * (passou ? 0.5 : 1.0)));
            a.pvHeroi = Math.max(0, a.pvHeroi - danoBase);
            resAnim = reacaoTexto ? 'REACAO_BLOQUEOU' : (passou ? 'RES_SUCESSO' : 'RES_FALHA');
            valEff = passou ? `½ Dano (-${danoBase} PV)` : `-${danoBase} PV`;
            msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> usou <strong>${nomeAcao}</strong> (${detRol}) — <strong>${passou ? 'HERÓI RESISTIU (½ Dano)!' : 'FALHOU NA RESISTÊNCIA!'}</strong> (-${danoBase} PV) ${reacaoTexto ? `<br><span style="color:#38BDF8;">${reacaoTexto}</span>` : ''}`;
        } else {
            resAnim = reacaoTexto ? 'REACAO_BLOQUEOU' : (passou ? 'RES_SUCESSO' : 'RES_FALHA');
            valEff = passou ? 'Resistiu!' : 'Abalado (-2)';
            msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> usou <strong>${nomeAcao}</strong> (${detRol}) — <strong>${passou ? 'HERÓI RESISTIU!' : 'FALHOU (Condição Aplicada!)'}</strong> ${reacaoTexto ? `<br><span style="color:#38BDF8;">${reacaoTexto}</span>` : ''}`;
        }
    } else {
        const d20 = Math.floor(Math.random() * 20) + 1;
        const bonusAtq = Number(cr.ataque || priv.ataque || 10) + Number(cr._buffAtqTempV67 || 0);
        const totalAtq = d20 + bonusAtq;
        const defH = Number(a.defHeroiBase || 18) + Number(a._bonusDefHeroiTempV67 || 0);
        let danoBruto = Math.max(4, Math.round(Number(cr.danoMedio || priv.danoMedio || 16) * (0.85 + Math.random() * 0.30) * (cr._buffAtqTempV67 ? 1.15 : 1.0)));
        if (d20 === 20) danoBruto = Math.round(danoBruto * 1.5);
        cr._buffAtqTempV67 = 0;
        detRol = `d20(${d20})+${bonusAtq}=${totalAtq} vs Def ${defH}`;

        if (d20 === 20 || totalAtq >= defH) {
            // Herói IA avalia Reação Inteligente!
            const reac = avaliarReacaoInteligenteOponenteV68JS({
                alvoTipo: 'HEROI', tipoAtaque: 'ATAQUE', rolagemAtq: totalAtq, defesaAlvo: defH,
                danoBruto, stHeroi: st, estadoArena: a
            });
            if (reac.disparou && reac.bloqueouTotal) {
                resAnim = 'REACAO_BLOQUEOU';
                valEff = `Bloqueado (${reac.nome})`;
                reacaoTexto = reac.texto;
                msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> atacou com <strong>${nomeAcao}</strong> (${detRol}) — <strong style="color:#38BDF8;">${reac.texto}</strong>`;
            } else {
                const danoFinal = reac.disparou ? reac.danoFinal : danoBruto;
                a.pvHeroi = Math.max(0, a.pvHeroi - danoFinal);
                resAnim = reac.disparou ? 'REACAO_BLOQUEOU' : (d20 === 20 ? 'CRITICO' : 'ACERTO');
                valEff = reac.disparou ? `-${danoFinal} PV (${reac.nome})` : `-${danoFinal} PV`;
                reacaoTexto = reac.disparou ? reac.texto : '';
                msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> usou <strong>${nomeAcao}</strong> (${detRol}) — <strong>${d20 === 20 ? 'CRÍTICO!' : 'ACERTOU!'} (-${danoFinal} PV)</strong> ${reacaoTexto ? `<br><span style="color:#38BDF8;">${reacaoTexto}</span>` : ''}`;
            }
        } else {
            resAnim = 'ERRO';
            valEff = 'Esquivou!';
            msgArena = `<strong>[Criatura Controlada]</strong> <strong>${cr.nomeCriatura}</strong> usou <strong>${nomeAcao}</strong> (${detRol}) — <strong>ERROU (Herói Esquivou)!</strong>`;
        }
    }

    // Próximo turno recarrega reação do herói se gasto
    if (!a.reacaoDisponivel && Math.random() < 0.5) a.reacaoDisponivel = true;

    try {
        if (typeof tocarSomPorEfeitoAnimacaoJRPG === 'function') {
            tocarSomPorEfeitoAnimacaoJRPG(resAnim === 'ERRO' ? 'UI_CLICK' : (resAnim === 'REACAO_BLOQUEOU' ? 'ESCUDO' : (resAnim === 'CURA' ? 'CURA_BUFF' : 'IMPACTO_PESADO')));
        }
    } catch(e) {}

    if (typeof dispararAnimacaoCoreografadaPalco2DJS === 'function') {
        dispararAnimacaoCoreografadaPalco2DJS({
            tipo: animCode, resultado: resAnim, detalheRolagem: detRol, valorDanoOuEfeito: valEff, reacaoInfo: reacaoTexto,
            ladoAlvo: (catV67 === 'CURA' || catV67 === 'DEFENSIVO' || catV67 === 'BUFF') ? 'CRIATURA' : 'HEROI',
            origem: { gx: cr.gx || 6, gy: cr.gy || 2 },
            destino: (catV67 === 'CURA' || catV67 === 'DEFENSIVO' || catV67 === 'BUFF') ? { gx: cr.gx || 6, gy: cr.gy || 2 } : (a.posHeroi || { gx: 2, gy: 2 }),
            label: `${cr.nomeCriatura.slice(0,14)}: ${nomeAcao.slice(0,18)}`
        });
    }
    if (typeof registrarLinhaLogArena === 'function') registrarLinhaLogArena(msgArena);
    const pill = document.getElementById('arena-fullscreen-live-roll-pill');
    if (pill) pill.innerHTML = msgArena.replace(/<[^>]+>/g, '').slice(0, 120);
    if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
    renderizarPainelAcoesPersonagemClicadoArenaJS();
}

// --- 5. SISTEMA VTT (RÉGUA, ÁREAS, PING, NÉVOA DE GUERRA, CONDIÇÕES E ROLADOR) ---
function selecionarFerramentaVTTJS(ferramenta, contexto) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    const vtt = window.__VTT_STATE__;
    if (ferramenta === 'NEVOA') {
        vtt.nevoaGuerra = !vtt.nevoaGuerra;
    } else if (ferramenta === 'LIMPAR') {
        vtt.ferramenta = 'MOVER';
        vtt.reguaOrigem = null; vtt.reguaDestino = null;
        vtt.areaAtiva = null; vtt.pingAtivo = null;
    } else {
        vtt.ferramenta = (vtt.ferramenta === ferramenta) ? 'MOVER' : ferramenta;
        if (vtt.ferramenta !== 'REGUA') { vtt.reguaOrigem = null; vtt.reguaDestino = null; }
    }
    if (contexto === 'MESA' && typeof renderizarMesaOnlineCompletaUI === 'function') renderizarMesaOnlineCompletaUI();
    else if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
    renderizarPainelAcoesPersonagemClicadoArenaJS();
    renderizarPainelAcoesPersonagemClicadoMesaJS();
}

function rolarDadoRapidoVTTJS(tipoDado, contexto) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    let txt = '';
    if (tipoDado === '2d20') {
        const d1 = Math.floor(Math.random() * 20) + 1;
        const d2 = Math.floor(Math.random() * 20) + 1;
        txt = `VTT 2d20 (Melhor): [${d1}, ${d2}] ${Math.max(d1, d2)}`;
    } else {
        const faces = Number(String(tipoDado).replace('d', '')) || 20;
        const r = Math.floor(Math.random() * faces) + 1;
        txt = `VTT 1d${faces}: ${r}`;
    }
    window.__VTT_STATE__.ultimoDadoVTT = txt;
    const pill = document.getElementById('arena-fullscreen-live-roll-pill');
    if (pill) pill.textContent = txt;
    if (contexto === 'MESA' && typeof registrarLogMesaOnline === 'function') registrarLogMesaOnline(txt);
    else if (typeof registrarLinhaLogArena === 'function') registrarLinhaLogArena(`<strong>${txt}</strong>`);
    renderizarPainelAcoesPersonagemClicadoArenaJS();
    renderizarPainelAcoesPersonagemClicadoMesaJS();
}

function alternarCondicaoRapidaVTTJS(condNome, contexto) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    let alvo = null;
    if (contexto === 'MESA' && ESTADO_MESA_ONLINE_ATUAL) {
        const sel = window.__PERSONAGEM_CLICADO_MESA__ || { tipo: 'HEROI_MESA', id: HEROI_SELECIONADO_GRID_MESA_ID };
        alvo = sel.tipo === 'AMEACA_MESA'
            ? (ESTADO_MESA_ONLINE_ATUAL.listaInimigosMesa || [])[Number(sel.id || 0)]
            : (ESTADO_MESA_ONLINE_ATUAL.participantes || []).find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID);
    } else if (typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
        const sel = window.__PERSONAGEM_CLICADO_ARENA__ || { tipo: 'HEROI' };
        alvo = sel.tipo === 'AMEACA'
            ? (__ARENA_STATE__.listaCriaturas || [])[Number(sel.id || 0)]
            : __ARENA_STATE__;
    }
    if (!alvo) return;
    if (!alvo._vttCondicoes) alvo._vttCondicoes = {};
    alvo._vttCondicoes[condNome] = !alvo._vttCondicoes[condNome];
    if (contexto === 'MESA' && typeof renderizarMesaOnlineCompletaUI === 'function') renderizarMesaOnlineCompletaUI();
    else if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
    renderizarPainelAcoesPersonagemClicadoArenaJS();
    renderizarPainelAcoesPersonagemClicadoMesaJS();
}

function interceptarCliqueGridVTTJS(gx, gy, contexto) {
    const vtt = window.__VTT_STATE__;
    if (!vtt || vtt.ferramenta === 'MOVER') return false;
    const x = Math.max(0, Math.min(119, Number(gx)));
    const y = Math.max(0, Math.min(119, Number(gy)));
    if (vtt.ferramenta === 'REGUA') {
        if (!vtt.reguaOrigem || vtt.reguaDestino) {
            vtt.reguaOrigem = { gx: x, gy: y, contexto };
            vtt.reguaDestino = null;
        } else {
            vtt.reguaDestino = { gx: x, gy: y, contexto };
        }
    } else if (vtt.ferramenta === 'AREA_ESFERA' || vtt.ferramenta === 'AREA_CONE' || vtt.ferramenta === 'AREA_LINHA') {
        vtt.areaAtiva = { tipo: vtt.ferramenta, gx: x, gy: y, raioQ: vtt.ferramenta === 'AREA_ESFERA' ? 4 : 6, contexto };
    } else if (vtt.ferramenta === 'PING') {
        vtt.pingAtivo = { gx: x, gy: y, timestamp: Date.now(), contexto };
    }
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    if (contexto === 'MESA' && typeof renderizarMesaOnlineCompletaUI === 'function') renderizarMesaOnlineCompletaUI();
    else if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
    return true;
}

// Hook VTT no clique do grid da Arena e da Mesa Online (sem hoisting recursivo!)
const __MOVER_ARENA_PREV_V68__ = window.moverHeroiParaCelulaGridArenaJS;
window.moverHeroiParaCelulaGridArenaJS = function(gx, gy) {
    if (interceptarCliqueGridVTTJS(gx, gy, 'ARENA')) return;
    if (typeof __MOVER_ARENA_PREV_V68__ === 'function') return __MOVER_ARENA_PREV_V68__(gx, gy);
};
const __MOVER_MESA_PREV_V68__ = window.clicarCelulaGrid2DMesaOnlineJS;
window.clicarCelulaGrid2DMesaOnlineJS = function(gx, gy) {
    if (interceptarCliqueGridVTTJS(gx, gy, 'MESA')) return;
    if (typeof __MOVER_MESA_PREV_V68__ === 'function') return __MOVER_MESA_PREV_V68__(gx, gy);
};

// --- 6. RENDERIZAÇÃO COESA DE CAMADAS VTT + OVERLAY ACERTO/ERRO/REAÇÃO/RESISTÊNCIA NO SVG ---
window.construirTrilhaMovimentoAtivaSVG = function(cols, rows, contexto) {
    let svg = '';
    const tr = window.__TRILHA_MOVIMENTO_ATIVA__;
    if (tr && (Date.now() - tr.timestamp <= 2400) && (!contexto || !tr.contexto || tr.contexto === contexto)) {
        const p1t = mapearGridParaPalco2DSVG(tr.gxOrig, tr.gyOrig, cols || 12, rows || 7);
        const p2t = mapearGridParaPalco2DSVG(tr.gxDest, tr.gyDest, cols || 12, rows || 7);
        const bolinhasSVG = (tr.passos || []).map((pt, idx, arr) => {
            const pm = mapearGridParaPalco2DSVG(pt.gx, pt.gy, cols || 12, rows || 7);
            return `<circle cx="${pm.px.toFixed(1)}" cy="${(pm.py - 6).toFixed(1)}" r="${idx === arr.length - 1 ? 8 : 5}" fill="${idx === arr.length - 1 ? '#4ADE80' : '#38BDF8'}" stroke="#FEF08A" stroke-width="1.8" opacity="0.9"/>`;
        }).join('');
        const mxt = (p1t.px + p2t.px) / 2, myt = (p1t.py + p2t.py) / 2 - 22;
        svg += `<g pointer-events="none"><line x1="${p1t.px.toFixed(1)}" y1="${(p1t.py - 6).toFixed(1)}" x2="${p2t.px.toFixed(1)}" y2="${(p2t.py - 6).toFixed(1)}" stroke="#4ADE80" stroke-width="3.5" stroke-dasharray="8 5"/>${bolinhasSVG}<rect x="${(mxt - 68).toFixed(1)}" y="${(myt - 14).toFixed(1)}" width="136" height="17" rx="5" fill="rgba(6,78,59,0.95)" stroke="#4ADE80" stroke-width="1.4"/><text x="${mxt.toFixed(1)}" y="${(myt - 2).toFixed(1)}" text-anchor="middle" font-size="9" font-weight="900" fill="#ECFDF5">Moveu ${(tr.distMetros||0).toFixed(1)}m (${tr.distQ||0}q)</text></g>`;
    }
    const vtt = window.__VTT_STATE__ || {};
    const c = cols || 12, r = rows || 7;

    // A. Camadas VTT (Névoa de Guerra, Moldes de Área, Régua de Distância, Ping Tático)
    if (vtt.nevoaGuerra) {
        svg += `<rect x="0" y="0" width="960" height="460" fill="rgba(2,6,23,0.48)" pointer-events="none"/>`;
    }
    if (vtt.areaAtiva && (!contexto || vtt.areaAtiva.contexto === contexto)) {
        const pa = mapearGridParaPalco2DSVG(vtt.areaAtiva.gx, vtt.areaAtiva.gy, c, r);
        if (vtt.areaAtiva.tipo === 'AREA_ESFERA') {
            svg += `<g pointer-events="none"><circle cx="${pa.px.toFixed(1)}" cy="${pa.py.toFixed(1)}" r="88" fill="rgba(239,68,68,0.24)" stroke="#FACC15" stroke-width="2.5" stroke-dasharray="6 4"/><text x="${pa.px.toFixed(1)}" y="${(pa.py - 94).toFixed(1)}" text-anchor="middle" font-size="10" font-weight="900" fill="#FEF08A">⭕ Esfera 6m (4q)</text></g>`;
        } else if (vtt.areaAtiva.tipo === 'AREA_CONE') {
            svg += `<g pointer-events="none"><polygon points="${pa.px.toFixed(1)},${pa.py.toFixed(1)} ${(pa.px+170).toFixed(1)},${(pa.py-75).toFixed(1)} ${(pa.px+170).toFixed(1)},${(pa.py+75).toFixed(1)}" fill="rgba(249,115,22,0.26)" stroke="#FDE047" stroke-width="2.5" stroke-dasharray="6 4"/><text x="${(pa.px+95).toFixed(1)}" y="${(pa.py - 78).toFixed(1)}" text-anchor="middle" font-size="10" font-weight="900" fill="#FEF08A">Cone 9m (6q)</text></g>`;
        } else if (vtt.areaAtiva.tipo === 'AREA_LINHA') {
            svg += `<g pointer-events="none"><rect x="${pa.px.toFixed(1)}" y="${(pa.py-16).toFixed(1)}" width="240" height="32" rx="6" fill="rgba(56,189,248,0.26)" stroke="#7DD3FC" stroke-width="2.5" stroke-dasharray="6 4"/><text x="${(pa.px+120).toFixed(1)}" y="${(pa.py - 22).toFixed(1)}" text-anchor="middle" font-size="10" font-weight="900" fill="#E0F2FE">Linha 12m (8q)</text></g>`;
        }
    }
    if (vtt.reguaOrigem && (!contexto || vtt.reguaOrigem.contexto === contexto)) {
        const p1 = mapearGridParaPalco2DSVG(vtt.reguaOrigem.gx, vtt.reguaOrigem.gy, c, r);
        svg += `<circle cx="${p1.px.toFixed(1)}" cy="${p1.py.toFixed(1)}" r="7" fill="#38BDF8" stroke="#FFF" stroke-width="2" pointer-events="none"/>`;
        if (vtt.reguaDestino) {
            const p2 = mapearGridParaPalco2DSVG(vtt.reguaDestino.gx, vtt.reguaDestino.gy, c, r);
            const dq = Math.max(Math.abs(vtt.reguaDestino.gx - vtt.reguaOrigem.gx), Math.abs(vtt.reguaDestino.gy - vtt.reguaOrigem.gy));
            const dm = (dq * 1.5).toFixed(1);
            const alcance = dq <= 6 ? 'Curto' : (dq <= 20 ? 'Médio' : 'Longo');
            const mx = (p1.px + p2.px) / 2, my = (p1.py + p2.py) / 2 - 14;
            svg += `
                <g pointer-events="none">
                    <line x1="${p1.px.toFixed(1)}" y1="${p1.py.toFixed(1)}" x2="${p2.px.toFixed(1)}" y2="${p2.py.toFixed(1)}" stroke="#38BDF8" stroke-width="3.5" stroke-dasharray="7 4"/>
                    <circle cx="${p2.px.toFixed(1)}" cy="${p2.py.toFixed(1)}" r="7" fill="#FACC15" stroke="#FFF" stroke-width="2"/>
                    <rect x="${(mx - 78).toFixed(1)}" y="${(my - 14).toFixed(1)}" width="156" height="20" rx="6" fill="rgba(2,6,23,0.95)" stroke="#38BDF8" stroke-width="1.5"/>
                    <text x="${mx.toFixed(1)}" y="${my.toFixed(1)}" text-anchor="middle" font-size="10" font-weight="900" fill="#E0F2FE">${dm}m (${dq}q) · ${alcance}</text>
                </g>`;
        }
    }
    if (vtt.pingAtivo && (Date.now() - vtt.pingAtivo.timestamp < 4500) && (!contexto || vtt.pingAtivo.contexto === contexto)) {
        const pp = mapearGridParaPalco2DSVG(vtt.pingAtivo.gx, vtt.pingAtivo.gy, c, r);
        svg += `
            <g pointer-events="none">
                <circle cx="${pp.px.toFixed(1)}" cy="${pp.py.toFixed(1)}" r="26" fill="none" stroke="#FACC15" stroke-width="3.5" opacity="0.9"/>
                <circle cx="${pp.px.toFixed(1)}" cy="${pp.py.toFixed(1)}" r="12" fill="rgba(250,204,21,0.35)" stroke="#FEF08A" stroke-width="2"/>
                <text x="${pp.px.toFixed(1)}" y="${(pp.py - 30).toFixed(1)}" text-anchor="middle" font-size="11" font-weight="900" fill="#FEF08A">PING TÁTICO</text>
            </g>`;
    }

    // B. Overlay Visual Coeso de Resultado da Ação (ACERTO / CRÍTICO / ERRO / REAÇÃO / RES_SUCESSO / RES_FALHA)
    const anim = window.__ANIMACAO_PALCO_ATIVA__;
    if (anim && anim.resultado && (Date.now() - anim.timestamp < 1600)) {
        const pOrig = anim.origem ? mapearGridParaPalco2DSVG(anim.origem.gx, anim.origem.gy, c, r) : { px: 280, py: 260 };
        const pDest = anim.destino ? mapearGridParaPalco2DSVG(anim.destino.gx, anim.destino.gy, c, r) : { px: 620, py: 260 };
        const res = anim.resultado;
        const det = anim.detalheRolagem || '';
        const val = anim.valorDanoOuEfeito || '';
        let corBorda = '#FACC15', corFundo = 'rgba(127,29,29,0.94)', tituloBadge = `ACERTOU! ${val}`, efeitoVFX = '';

        if (res === 'CRITICO') {
            corBorda = '#FEF08A'; corFundo = 'rgba(180,83,9,0.96)'; tituloBadge = `CRÍTICO! ${val}`;
            efeitoVFX = `
                <line x1="${pOrig.px.toFixed(1)}" y1="${(pOrig.py-35).toFixed(1)}" x2="${pDest.px.toFixed(1)}" y2="${(pDest.py-35).toFixed(1)}" stroke="#FEF08A" stroke-width="5" stroke-linecap="round"/>
                <circle cx="${pDest.px.toFixed(1)}" cy="${(pDest.py-35).toFixed(1)}" r="46" fill="rgba(250,204,21,0.32)" stroke="#FEF08A" stroke-width="3.5"/>
                <path d="M ${(pDest.px-32).toFixed(1)} ${(pDest.py-65).toFixed(1)} L ${(pDest.px+32).toFixed(1)} ${(pDest.py-5).toFixed(1)} M ${(pDest.px+32).toFixed(1)} ${(pDest.py-65).toFixed(1)} L ${(pDest.px-32).toFixed(1)} ${(pDest.py-5).toFixed(1)}" stroke="#FFF" stroke-width="4"/>`;
        } else if (res === 'ACERTO') {
            corBorda = '#F87171'; corFundo = 'rgba(127,29,29,0.94)'; tituloBadge = `ACERTOU! ${val}`;
            efeitoVFX = `
                <line x1="${pOrig.px.toFixed(1)}" y1="${(pOrig.py-32).toFixed(1)}" x2="${pDest.px.toFixed(1)}" y2="${(pDest.py-32).toFixed(1)}" stroke="#F97316" stroke-width="4" stroke-dasharray="10 4"/>
                <circle cx="${pDest.px.toFixed(1)}" cy="${(pDest.py-32).toFixed(1)}" r="34" fill="rgba(239,68,68,0.28)" stroke="#FCA5A5" stroke-width="3"/>`;
        } else if (res === 'ERRO') {
            corBorda = '#94A3B8'; corFundo = 'rgba(15,23,42,0.95)'; tituloBadge = `ERROU! (ESQUIVOU)`;
            // Arco desviado passando acima/ao lado do alvo sem acertar!
            efeitoVFX = `
                <path d="M ${pOrig.px.toFixed(1)} ${(pOrig.py-32).toFixed(1)} Q ${((pOrig.px+pDest.px)/2).toFixed(1)} ${(pDest.py-105).toFixed(1)} ${(pDest.px+36).toFixed(1)} ${(pDest.py-78).toFixed(1)}" fill="none" stroke="#94A3B8" stroke-width="3" stroke-dasharray="6 5"/>
                <ellipse cx="${pDest.px.toFixed(1)}" cy="${(pDest.py-30).toFixed(1)}" rx="28" ry="12" fill="none" stroke="#38BDF8" stroke-width="2" stroke-dasharray="4 3"/>`;
        } else if (res === 'REACAO_BLOQUEOU') {
            corBorda = '#38BDF8'; corFundo = 'rgba(12,74,110,0.96)'; tituloBadge = `REAÇÃO! ${val}`;
            efeitoVFX = `
                <polygon points="${pDest.px.toFixed(1)},${(pDest.py-78).toFixed(1)} ${(pDest.px+36).toFixed(1)},${(pDest.py-56).toFixed(1)} ${(pDest.px+36).toFixed(1)},${(pDest.py-12).toFixed(1)} ${pDest.px.toFixed(1)},${(pDest.py+10).toFixed(1)} ${(pDest.px-36).toFixed(1)},${(pDest.py-12).toFixed(1)} ${(pDest.px-36).toFixed(1)},${(pDest.py-56).toFixed(1)}" fill="rgba(56,189,248,0.26)" stroke="#7DD3FC" stroke-width="3.5"/>`;
        } else if (res === 'RES_SUCESSO') {
            corBorda = '#34D399'; corFundo = 'rgba(6,78,59,0.95)'; tituloBadge = `RESISTIU! ${val}`;
            efeitoVFX = `<circle cx="${pDest.px.toFixed(1)}" cy="${(pDest.py-32).toFixed(1)}" r="40" fill="rgba(16,185,129,0.22)" stroke="#6EE7B7" stroke-width="3.5"/>`;
        } else if (res === 'RES_FALHA') {
            corBorda = '#C084FC'; corFundo = 'rgba(88,28,135,0.95)'; tituloBadge = `FALHOU NA RESISTÊNCIA! ${val}`;
            efeitoVFX = `<circle cx="${pDest.px.toFixed(1)}" cy="${(pDest.py-32).toFixed(1)}" r="42" fill="rgba(168,85,247,0.32)" stroke="#E879F9" stroke-width="3.5" stroke-dasharray="8 4"/>`;
        } else if (res === 'CURA') {
            corBorda = '#4ADE80'; corFundo = 'rgba(6,78,59,0.95)'; tituloBadge = `CURA! ${val}`;
            efeitoVFX = `<circle cx="${pDest.px.toFixed(1)}" cy="${(pDest.py-32).toFixed(1)}" r="36" fill="rgba(74,222,128,0.24)" stroke="#86EFAC" stroke-width="3"/>`;
        } else {
            corBorda = '#FACC15'; corFundo = 'rgba(113,63,18,0.95)'; tituloBadge = `${val || anim.label || 'ATIVADO!'}`;
            efeitoVFX = `<circle cx="${pDest.px.toFixed(1)}" cy="${(pDest.py-32).toFixed(1)}" r="36" fill="rgba(250,204,21,0.22)" stroke="#FDE047" stroke-width="3"/>`;
        }

        const bx = Math.max(135, Math.min(825, pDest.px));
        const by = Math.max(46, pDest.py - 92);
        svg += `
            <g pointer-events="none">
                ${efeitoVFX}
                <rect x="${(bx - 128).toFixed(1)}" y="${(by - 22).toFixed(1)}" width="256" height="${det ? 38 : 24}" rx="8" fill="${corFundo}" stroke="${corBorda}" stroke-width="2"/>
                <text x="${bx.toFixed(1)}" y="${(by - 6).toFixed(1)}" text-anchor="middle" font-size="11.5" font-weight="900" fill="#FFF">${tituloBadge}</text>
                ${det ? `<text x="${bx.toFixed(1)}" y="${(by + 10).toFixed(1)}" text-anchor="middle" font-size="9.5" font-weight="700" fill="#E2E8F0">${det}</text>` : ''}
            </g>`;
    }

    return svg;
}

// --- 7. GERADOR DA BARRA VTT + CARDS DE HABILIDADES POLIDOS (ARENA E MESA ONLINE) ---
function montarHtmlBarraVTTV68JS(contexto, alvoObj) {
    const vtt = window.__VTT_STATE__ || {};
    const conds = (alvoObj && alvoObj._vttCondicoes) ? alvoObj._vttCondicoes : {};
    const listaConds = ['Caído', 'Desprevenido', 'Abalado', 'Envenenado', 'Abençoado'];
    return `
        <div class="t20-vtt-toolbar">
            <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
                <span style="font-size:10px;font-weight:900;color:#38BDF8;">VTT:</span>
                <button type="button" class="t20-vtt-btn ${vtt.ferramenta === 'MOVER' ? 'vtt-active' : ''}" onclick="selecionarFerramentaVTTJS('MOVER', '${contexto}')">Mover</button>
                <button type="button" class="t20-vtt-btn ${vtt.ferramenta === 'REGUA' ? 'vtt-active' : ''}" onclick="selecionarFerramentaVTTJS('REGUA', '${contexto}')">Régua</button>
                <button type="button" class="t20-vtt-btn ${vtt.ferramenta === 'AREA_ESFERA' ? 'vtt-active' : ''}" onclick="selecionarFerramentaVTTJS('AREA_ESFERA', '${contexto}')">⭕ Esfera</button>
                <button type="button" class="t20-vtt-btn ${vtt.ferramenta === 'AREA_CONE' ? 'vtt-active' : ''}" onclick="selecionarFerramentaVTTJS('AREA_CONE', '${contexto}')">Cone</button>
                <button type="button" class="t20-vtt-btn ${vtt.ferramenta === 'AREA_LINHA' ? 'vtt-active' : ''}" onclick="selecionarFerramentaVTTJS('AREA_LINHA', '${contexto}')">Linha</button>
                <button type="button" class="t20-vtt-btn ${vtt.ferramenta === 'PING' ? 'vtt-active' : ''}" onclick="selecionarFerramentaVTTJS('PING', '${contexto}')">Ping</button>
                <button type="button" class="t20-vtt-btn ${vtt.nevoaGuerra ? 'vtt-active' : ''}" onclick="selecionarFerramentaVTTJS('NEVOA', '${contexto}')">Névoa</button>
                <button type="button" class="t20-vtt-btn" onclick="selecionarFerramentaVTTJS('LIMPAR', '${contexto}')"></button>
            </div>
            <div style="display:flex;gap:3px;flex-wrap:wrap;align-items:center;">
                ${listaConds.map(c => `<button type="button" class="t20-vtt-cond-chip ${conds[c] ? 'cond-on' : ''}" onclick="alternarCondicaoRapidaVTTJS('${c}', '${contexto}')">${c}</button>`).join('')}
                <button type="button" class="t20-vtt-btn" style="border-color:#FACC15;color:#FEF08A;" onclick="rolarDadoRapidoVTTJS('2d20', '${contexto}')">2d20</button>
                <button type="button" class="t20-vtt-btn" onclick="rolarDadoRapidoVTTJS('d20', '${contexto}')">d20</button>
                ${vtt.ultimoDadoVTT ? `<span style="font-size:10px;font-weight:900;color:#4ADE80;margin-left:3px;">${vtt.ultimoDadoVTT}</span>` : ''}
            </div>
        </div>
    `;
}

function renderizarCardHabilidadePolidoV68JS(ac, onClickCode) {
    const bgIconPorCat = {
        OFENSIVO: 'linear-gradient(135deg,#991B1B,#DC2626)',
        DEFENSIVO: 'linear-gradient(135deg,#1E3A8A,#2563EB)',
        BUFF: 'linear-gradient(135deg,#B45309,#EAB308)',
        DEBUFFS: 'linear-gradient(135deg,#581C87,#9333EA)',
        CURA: 'linear-gradient(135deg,#065F46,#10B981)'
    };
    const p1 = ac.metaPill1 || (ac.cat === 'OFENSIVO' ? 'Ação Padrão' : (ac.cat === 'CURA' ? 'Recuperação' : ac.cat));
    const p2 = ac.metaPill2 || '';
    return `
        <button type="button" class="t20-v68-skill-card" title="${String(ac.desc || '').replace(/"/g, '&quot;')}" onclick="${onClickCode}">
            <div class="t20-v68-skill-icon" style="background:${bgIconPorCat[ac.cat] || bgIconPorCat.OFENSIVO};">${ac.icone || ''}</div>
            <div class="t20-v68-skill-body">
                <div class="t20-v68-skill-title">${ac.nome}</div>
                <div class="t20-v68-skill-meta">
                    <span class="t20-v68-pill ${ac.cat === 'OFENSIVO' ? 't20-v68-pill-atk' : (ac.cat === 'DEBUFFS' ? 't20-v68-pill-cd' : (ac.cat === 'CURA' ? 't20-v68-pill-heal' : ''))}">${p1}</span>
                    ${p2 ? `<span class="t20-v68-pill">${p2}</span>` : ''}
                    ${ac.custoPM > 0 ? `<span class="t20-v68-pill t20-v68-pill-pm">${ac.custoPM} PM</span>` : ''}
                </div>
            </div>
        </button>
    `;
}

// Re-renderizar Dock da ARENA com VTT + Cards v68 Polidos
function renderizarPainelAcoesPersonagemClicadoArenaJS() {
    if (typeof __ARENA_STATE__ === 'undefined' || !__ARENA_STATE__) {
        if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario();
    }
    const box = document.getElementById('arena-clicked-character-actions-bar');
    if (!box || typeof __ARENA_STATE__ === 'undefined' || !__ARENA_STATE__) return;

    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    const sel = window.__PERSONAGEM_CLICADO_ARENA__ || { tipo: 'HEROI', id: 'HEROI_PRINCIPAL' };
    const listaCriaturas = Array.isArray(a.listaCriaturas) ? a.listaCriaturas : [];
    const focoIdx = Math.min(Math.max(0, Number(a.alvoFocoIdx || 0)), Math.max(0, listaCriaturas.length - 1));
    const crFoco = listaCriaturas[focoIdx] || null;
    const catAtiva = window.__CATEGORIA_ACAO_ARENA_V67__ || 'OFENSIVO';
    const ehCriaturaControlada = (sel.tipo === 'AMEACA' && crFoco);

    const dados = ehCriaturaControlada
        ? montarAcoesEPassivasCriaturaV67JS(crFoco, a._privadoCriatura)
        : montarAcoesEPassivasHeroiV67JS(st);

    const seletorTokensHTML = `
        <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:10.5px;font-weight:900;color:#93C5FD;">Controlar:</span>
            <button type="button" class="btn-roll-inline" style="background:${sel.tipo === 'HEROI' ? '#15803D' : '#1E293B'};border-color:${sel.tipo === 'HEROI' ? '#4ADE80' : '#475569'};font-weight:900;padding:3px 8px;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI', 'HEROI_PRINCIPAL', 'ARENA')">
                ${st.nome.slice(0, 14)}
            </button>
            ${listaCriaturas.map((cr, idx) => `
                <button type="button" class="btn-roll-inline" style="background:${(sel.tipo === 'AMEACA' && Number(sel.id) === idx) ? '#991B1B' : '#1E293B'};border-color:${(sel.tipo === 'AMEACA' && Number(sel.id) === idx) ? '#FACC15' : '#EF4444'};font-weight:900;padding:3px 8px;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA', ${idx}, 'ARENA')">
                    ${cr.rotulo} ${cr.nomeCriatura.slice(0, 14)} (${Math.max(0, cr.pvAtual)}/${cr.pvMax})
                </button>
            `).join('')}
        </div>
    `;

    const catsMeta = [
        { k: 'OFENSIVO', label: 'Ofensivo' },
        { k: 'DEFENSIVO', label: 'Defensivo' },
        { k: 'BUFF', label: 'Buff' },
        { k: 'DEBUFFS', label: 'Debuffs' },
        { k: 'CURA', label: 'Cura' }
    ];
    const tabsHTML = catsMeta.map(c => `
        <button type="button" class="t20-v67-cat-btn ${catAtiva === c.k ? 'cat-active-' + c.k : ''}" onclick="selecionarCategoriaAcaoV67JS('ARENA', '${c.k}')">
            <span>${c.label}</span>
            <span class="t20-v67-cat-count">${(dados.ativas[c.k] || []).length}</span>
        </button>
    `).join('');

    const listaAcoesCat = dados.ativas[catAtiva] || [];
    const armaNome = (st.arma && st.arma.nome) ? st.arma.nome.replace(/'/g, '') : 'Espada Longa';
    const cardsHTML = listaAcoesCat.map(ac => {
        const nmSafe = String(ac.nome || '').replace(/'/g, '');
        const idSafe = String(ac.id || '').replace(/'/g, '');
        const onClickCode = ehCriaturaControlada
            ? `executarHabilidadeControladaCriaturaV67JS('ARENA', ${focoIdx}, '${idSafe}', '${nmSafe}', '${catAtiva}', ${Boolean(ac.ehArea)})`
            : `executarAcaoCategorizadaHeroiArenaV67JS('${idSafe}', '${nmSafe}', '${catAtiva}', '${armaNome}')`;
        return renderizarCardHabilidadePolidoV68JS(ac, onClickCode);
    }).join('') || '<span style="color:#94A3B8;font-size:11.5px;">Nenhuma ação ativa nesta categoria.</span>';

    box.innerHTML = `
        <div class="t20-clicked-char-dock">
            ${montarHtmlBarraVTTV68JS('ARENA', ehCriaturaControlada ? crFoco : a)}
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;">
                ${seletorTokensHTML}
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                    <span style="font-size:10.5px;color:${ehCriaturaControlada ? '#FCA5A5' : '#FDE047'};font-weight:900;">
                        ${ehCriaturaControlada ? `Controlando ${crFoco.nomeCriatura} (Herói com Reações IA Ativas)` : `${st.nome} (Ameaça com Reações IA Ativas)`}
                    </span>
                    <button type="button" class="t20-passives-toggle-btn" onclick="alternarMenuLateralPassivasJS('ARENA')">
                        Passivas (${dados.passivas.length})
                    </button>
                </div>
            </div>
            <div class="t20-v67-cat-tabs">${tabsHTML}</div>
            <div class="t20-v68-skills-grid">${cardsHTML}</div>
        </div>
    `;

    const dr = document.getElementById('t20-passives-side-drawer');
    if (dr && dr.classList.contains('drawer-open')) atualizarConteudoMenuLateralPassivasJS('ARENA');
}

// Re-renderizar Dock da MESA ONLINE com VTT + Cards v68 Polidos
function renderizarPainelAcoesPersonagemClicadoMesaJS() {
    if (!ESTADO_MESA_ONLINE_ATUAL && typeof criarEstadoInicialMesaOnline === 'function') {
        ESTADO_MESA_ONLINE_ATUAL = criarEstadoInicialMesaOnline('VALKARIA-2026');
    }
    const box = document.getElementById('mesa-clicked-character-actions-bar');
    if (!box || !ESTADO_MESA_ONLINE_ATUAL) return;

    const m = ESTADO_MESA_ONLINE_ATUAL;
    const parts = m.participantes || [];
    const inimigos = m.listaInimigosMesa || [];
    if (!HEROI_SELECIONADO_GRID_MESA_ID && parts[0]) HEROI_SELECIONADO_GRID_MESA_ID = parts[0].idHeroi;

    const sel = window.__PERSONAGEM_CLICADO_MESA__ || { tipo: 'HEROI_MESA', id: HEROI_SELECIONADO_GRID_MESA_ID };
    const heroiAtivo = parts.find(p => p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID) || parts[0];
    const focoIdx = Math.min(Math.max(0, Number(m.alvoFocoMesaIdx || 0)), Math.max(0, inimigos.length - 1));
    const inimFoco = inimigos[focoIdx] || null;
    const catAtiva = window.__CATEGORIA_ACAO_MESA_V67__ || 'OFENSIVO';
    const ehCriaturaControlada = (sel.tipo === 'AMEACA_MESA' && inimFoco);

    let dados;
    if (ehCriaturaControlada) {
        dados = montarAcoesEPassivasCriaturaV67JS(inimFoco, null);
    } else {
        const ativasH = { OFENSIVO: [], DEFENSIVO: [], BUFF: [], DEBUFFS: [], CURA: [] };
        const acoesBase = (heroiAtivo && typeof obterRepertorioAcoesCompletasPersonagemMesaJS === 'function')
            ? obterRepertorioAcoesCompletasPersonagemMesaJS(heroiAtivo) : [];
        acoesBase.forEach(ac => {
            const cat = classificarCategoriaAcaoAtivaV67JS(ac.nome, ac.categoria, ac.desc);
            ativasH[cat].push({ id: ac.cod, nome: ac.nome, icone: ac.icone, custoPM: ac.custoPM || 0, cat, desc: ac.desc || '', arma: ac.arma || '' });
        });
        if (ativasH.DEFENSIVO.length === 0) ativasH.DEFENSIVO.push({ id: 'DEFESA_TOTAL', nome: 'Defesa Total', icone: '', custoPM: 0, cat: 'DEFENSIVO', metaPill1: '+4 Defesa', desc: '+4 Defesa até o próximo turno.' });
        if (ativasH.BUFF.length === 0) ativasH.BUFF.push({ id: 'BUFF_INSPIRACAO', nome: 'Foco Tático', icone: '', custoPM: 1, cat: 'BUFF', metaPill1: '+2 Ataque', desc: 'Concede bônus de ataque.' });
        if (ativasH.DEBUFFS.length === 0) ativasH.DEBUFFS.push({ id: 'DEBUFF_DERRUBAR', nome: 'Derrubar / Fintar', icone: '', custoPM: 0, cat: 'DEBUFFS', metaPill1: '-5 Def Alvo', desc: 'Aplica condição tática no inimigo.' });
        if (ativasH.CURA.length === 0) ativasH.CURA.push({ id: 'CURA_POCAO', nome: 'Poção de Cura', icone: '', custoPM: 0, cat: 'CURA', metaPill1: '+2d8+2 PV', desc: 'Recupera PV imediatamente.' });
        dados = { ativas: ativasH, passivas: [{ nome: 'Passivas da Ficha', origem: heroiAtivo ? heroiAtivo.classe : 'Herói', desc: 'Traços raciais e poderes passivos aplicados automaticamente.' }] };
    }

    const seletorTokensMesaHTML = `
        <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:10.5px;font-weight:900;color:#93C5FD;">Controlar:</span>
            ${parts.map(p => {
                const ehSel = (sel.tipo === 'HEROI_MESA' && p.idHeroi === HEROI_SELECIONADO_GRID_MESA_ID);
                return `<button type="button" class="btn-roll-inline" style="background:${ehSel ? '#15803D' : '#1E293B'};border-color:${ehSel ? '#4ADE80' : '#475569'};font-weight:900;padding:3px 7px;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI_MESA', '${p.idHeroi}', 'MESA')">${p.nome.slice(0, 11)}</button>`;
            }).join('')}
            ${inimigos.map((cr, idx) => {
                const ehSel = (sel.tipo === 'AMEACA_MESA' && Number(sel.id) === idx);
                return `<button type="button" class="btn-roll-inline" style="background:${ehSel ? '#991B1B' : '#1E293B'};border-color:${ehSel ? '#FACC15' : '#EF4444'};font-weight:900;padding:3px 7px;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA_MESA', ${idx}, 'MESA')">${cr.rotulo} ${cr.nome.slice(0, 11)} (${Math.max(0, cr.pvAtual)}/${cr.pvMax})</button>`;
            }).join('')}
        </div>
    `;

    const catsMeta = [
        { k: 'OFENSIVO', label: 'Ofensivo' },
        { k: 'DEFENSIVO', label: 'Defensivo' },
        { k: 'BUFF', label: 'Buff' },
        { k: 'DEBUFFS', label: 'Debuffs' },
        { k: 'CURA', label: 'Cura' }
    ];
    const tabsHTML = catsMeta.map(c => `
        <button type="button" class="t20-v67-cat-btn ${catAtiva === c.k ? 'cat-active-' + c.k : ''}" onclick="selecionarCategoriaAcaoV67JS('MESA', '${c.k}')">
            <span>${c.label}</span>
            <span class="t20-v67-cat-count">${(dados.ativas[c.k] || []).length}</span>
        </button>
    `).join('');

    const listaAcoesCat = dados.ativas[catAtiva] || [];
    const cardsHTML = listaAcoesCat.map(ac => {
        const nmSafe = String(ac.nome || '').replace(/'/g, '');
        const idSafe = String(ac.id || '').replace(/'/g, '');
        const onClickCode = ehCriaturaControlada
            ? `executarHabilidadeControladaCriaturaV67JS('MESA', ${focoIdx}, '${idSafe}', '${nmSafe}', '${catAtiva}', ${Boolean(ac.ehArea)})`
            : `executarAcaoEspecificaPersonagemMesaOnlineJS('${heroiAtivo ? heroiAtivo.idHeroi : ''}', '${idSafe}', '${nmSafe}', ${ac.custoPM || 0}, '${catAtiva}', '${String(ac.arma || '').replace(/'/g, '')}')`;
        return renderizarCardHabilidadePolidoV68JS(ac, onClickCode);
    }).join('');

    box.innerHTML = `
        <div class="t20-clicked-char-dock">
            ${montarHtmlBarraVTTV68JS('MESA', ehCriaturaControlada ? inimFoco : heroiAtivo)}
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;">
                ${seletorTokensMesaHTML}
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                    <span style="font-size:10.5px;color:${ehCriaturaControlada ? '#FCA5A5' : '#FDE047'};font-weight:900;">
                        ${ehCriaturaControlada ? `Controlando ${inimFoco.nome}` : (heroiAtivo ? `${heroiAtivo.nome}` : '')}
                    </span>
                    <button type="button" class="t20-passives-toggle-btn" onclick="alternarMenuLateralPassivasJS('MESA')">
                        Passivas (${dados.passivas.length})
                    </button>
                </div>
            </div>
            <div class="t20-v67-cat-tabs">${tabsHTML}</div>
            <div class="t20-v68-skills-grid">${cardsHTML}</div>
        </div>
    `;

    const dr = document.getElementById('t20-passives-side-drawer');
    if (dr && dr.classList.contains('drawer-open')) atualizarConteudoMenuLateralPassivasJS('MESA');
}

// Exports globais v68
window.obterContainerFullscreenAtivoV68JS = obterContainerFullscreenAtivoV68JS;
window.garantirDrawerPassivasDOMJS = garantirDrawerPassivasDOMJS;
window.alternarMenuLateralPassivasJS = alternarMenuLateralPassivasJS;
window.dividirRespeitandoParentesesV68JS = dividirRespeitandoParentesesV68JS;
window.montarAcoesEPassivasCriaturaV67JS = montarAcoesEPassivasCriaturaV67JS;
window.avaliarReacaoInteligenteOponenteV68JS = avaliarReacaoInteligenteOponenteV68JS;
window.executarHabilidadeControladaCriaturaV67JS = executarHabilidadeControladaCriaturaV67JS;
window.selecionarFerramentaVTTJS = selecionarFerramentaVTTJS;
window.rolarDadoRapidoVTTJS = rolarDadoRapidoVTTJS;
window.alternarCondicaoRapidaVTTJS = alternarCondicaoRapidaVTTJS;
window.interceptarCliqueGridVTTJS = interceptarCliqueGridVTTJS;
window.renderizarPainelAcoesPersonagemClicadoArenaJS = renderizarPainelAcoesPersonagemClicadoArenaJS;
window.renderizarPainelAcoesPersonagemClicadoMesaJS = renderizarPainelAcoesPersonagemClicadoMesaJS;




// ======================================================================================
// // 1. CALIBRAÇÃO JS DAS 7 CLASSES FORTES (LUTADOR DESARMADO, NOBRE SUPORTE, LADINO, BARDO, BÁRBARO, PALADINO, INVENTOR)
// 2. LAYOUT DE HABILIDADES UNIFICADO NO VISUAL DA MESA ONLINE (BOTÕES COLORIDOS LEGÍVEIS P/ HERÓIS E CRIATURAS)
// 3. CÂMERA VTT TOP-DOWN (VISÃO SUPERIOR 120x120) + ALTERNADOR DE CÂMERA + MOLDES GEOMÉTRICOS EXATOS
// ======================================================================================

function calcularSinergiaOficial7ClassesV69JS(classeNome, nivel, atr) {
    const cl = String(classeNome || '');
    const nv = Math.max(1, Number(nivel || 5));
    const a = atr || { FOR: 4, DES: 3, CON: 3, INT: 4, SAB: 2, CAR: 4 };
    if (cl === 'Lutador') {
        const medBriga = nv < 5 ? 3.5 : (nv < 9 ? 4.5 : (nv < 13 ? 5.5 : (nv < 17 ? 6.5 : 11.0)));
        const multAtq = nv >= 6 ? 2.65 : 2.0; // Ataque Base + Golpe Relâmpago (1 PM) + Trocação (Nv 6+)
        return {
            estilo: 'Ataque Desarmado (Briga + Golpe Relâmpago + Trocação)',
            bonusAtq: Math.max(1, Math.floor(nv / 4) + 1),
            bonusDpr: Number(((medBriga + Math.max(2, a.FOR || 4)) * multAtq).toFixed(1)),
            bonusDef: Math.max(2, a.CON || 3), // Casca Grossa
            nota: 'Build Desarmada JdA calibrada com Briga, Golpe Relâmpago e Trocação.'
        };
    }
    if (cl === 'Nobre') {
        const bOrd = 1 + Math.floor((nv - 1) / 4);
        return {
            estilo: 'Suporte & Comandante (Orgulho + Gritar Ordens + Autoconfiança)',
            bonusAtq: Math.min(6, Math.max(2, a.CAR || 4)),
            bonusDpr: Number((bOrd * 7.5 + Math.max(1, a.CAR || 4) * 2.5).toFixed(1)), // Multiplicador de 3 aliados + Palavras Afiadas
            bonusDef: Math.max(3, a.CAR || 4), // Autoconfiança
            nota: 'Build de Suporte Nobre calibrada com Multiplicador de Grupo (Gritar Ordens) + Autoconfiança.'
        };
    }
    if (cl === 'Ladino') {
        const dFurt = Math.floor((nv + 1) / 2);
        const multAss = nv >= 5 ? 2.0 : 1.0;
        return {
            estilo: 'Assassino / Ataque Furtivo (+Assassinar + Emboscar)',
            bonusAtq: nv >= 4 ? 2 : 1,
            bonusDpr: Number((dFurt * 3.5 * multAss).toFixed(1)),
            bonusDef: 2,
            nota: 'Build Ladino calibrada com Ataque Furtivo escalonado, Assassinar 2x e Emboscar.'
        };
    }
    if (cl === 'Bardo') {
        const bInsp = 1 + Math.floor((nv - 1) / 4);
        return {
            estilo: 'Suporte Arcano / Esgrima Mágica (+Prestidigitação)',
            bonusAtq: bInsp + Math.floor(Math.max(0, a.CAR || 4) / 2),
            bonusDpr: Number((bInsp * 6.0 + (nv >= 6 ? 7.0 : 0)).toFixed(1)),
            bonusDef: 2,
            nota: 'Build Bardo calibrada com Inspiração em Grupo, Esgrima Mágica e Prestidigitação.'
        };
    }
    if (cl === 'Bárbaro') {
        const furia = 2 + Math.floor((nv - 1) / 5);
        return {
            estilo: 'Fúria & Frenesi (+Alma de Bronze)',
            bonusAtq: furia,
            bonusDpr: Number((furia + (nv >= 2 ? 11.5 : 0)).toFixed(1)),
            bonusDef: 1,
            nota: 'Build Bárbaro calibrada com Fúria escalonada e Ataque Extra de Frenesi.'
        };
    }
    if (cl === 'Paladino') {
        const gd = 1 + Math.floor((nv - 1) / 4);
        return {
            estilo: 'Golpe Divino Escalonado + Vindicação + Égide/Aura Sagrada',
            bonusAtq: Math.max(2, a.CAR || 4) + (nv >= 5 ? 2 : 0),
            bonusDpr: Number((gd * 4.5 + (nv >= 5 ? 4.0 : 0)).toFixed(1)),
            bonusDef: Math.max(2, a.CAR || 4),
            nota: 'Build Paladino calibrada com Golpe Divino 1d8->5d8, Julgamentos e Égide Sagrada.'
        };
    }
    if (cl === 'Inventor') {
        const bInt = Math.max(2, a.INT || 4);
        return {
            estilo: 'Engenhoqueiro / Armeiro (+Engenhosidade INT)',
            bonusAtq: bInt,
            bonusDpr: Number((bInt + 4.5 + (nv >= 5 ? 3.5 : 0)).toFixed(1)),
            bonusDef: Math.max(2, Math.floor(bInt * 0.75)),
            nota: 'Build Inventor calibrada com Engenhosidade (+INT Atq), Armeiro/Balística (+INT Dano) e Engenhocas.'
        };
    }
    return { estilo: cl, bonusAtq: 0, bonusDpr: 0, bonusDef: 0, nota: '' };
}

// Alternador rápido de Câmera VTT (Visão Superior Top-Down vs 2.5D Isométrica)
function alternarCameraVTTJS(contexto) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    window.__MODO_CAMERA_VTT__ = (window.__MODO_CAMERA_VTT__ === 'TOP_DOWN') ? 'ISOMETRICO' : 'TOP_DOWN';
    if (contexto === 'MESA' && typeof renderizarMesaOnlineCompletaUI === 'function') renderizarMesaOnlineCompletaUI();
    else if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
    renderizarPainelAcoesPersonagemClicadoArenaJS();
    renderizarPainelAcoesPersonagemClicadoMesaJS();
}

// Sobrescrever renderizarCardHabilidadePolidoV68JS para usar o VISUAL UNIFICADO ESTILO MESA ONLINE (botões horizontais vibrantes e super legíveis!)
function renderizarCardHabilidadePolidoV68JS(ac, onClickCode) {
    const bgPorCat = {
        OFENSIVO: 'linear-gradient(135deg,#991B1B,#DC2626)',
        DEFENSIVO: 'linear-gradient(135deg,#1E3A8A,#2563EB)',
        BUFF: 'linear-gradient(135deg,#B45309,#D97706)',
        DEBUFFS: 'linear-gradient(135deg,#581C87,#9333EA)',
        CURA: 'linear-gradient(135deg,#065F46,#10B981)'
    };
    const bg = ac.cor || bgPorCat[ac.cat] || bgPorCat.OFENSIVO;
    const statTag = ac.metaPill1 ? `<span class="t20-v69-mesa-stat-badge">${ac.metaPill1}</span>` : '';
    const pmTag = ac.custoPM > 0 ? `<span class="t20-v69-mesa-pm-badge">${ac.custoPM} PM</span>` : '';
    return `
        <button type="button" class="t20-v69-mesa-action-btn" style="background:${bg};" title="${String(ac.desc || '').replace(/"/g, '&quot;')}" onclick="${onClickCode}">
            <span>${ac.icone || ''}</span>
            <span>${ac.nome}</span>
            ${statTag}
            ${pmTag}
        </button>
    `;
}

// Adicionar botão de alternar Câmera Top-Down / 2.5D na Barra VTT (sem hoisting recursivo!)
const __MONTAR_VTT_PREV_V69__ = window.montarHtmlBarraVTTV68JS;
window.montarHtmlBarraVTTV68JS = function(contexto, alvoObj) {
    const htmlBase = (typeof __MONTAR_VTT_PREV_V69__ === 'function') ? __MONTAR_VTT_PREV_V69__(contexto, alvoObj) : '';
    const ehTop = (window.__MODO_CAMERA_VTT__ || 'TOP_DOWN') === 'TOP_DOWN';
    const btnCam = `<button type="button" class="t20-vtt-btn ${ehTop ? 'vtt-active' : ''}" onclick="alternarCameraVTTJS('${contexto}')" title="Alternar entre Câmera VTT Visão Superior (Ortogonal 120x120) e 2.5D">${ehTop ? 'Superior (VTT)' : '2.5D'}</button>`;
    return htmlBase.replace('<span style="font-size:10px;font-weight:900;color:#38BDF8;">VTT:</span>', `<span style="font-size:10px;font-weight:900;color:#38BDF8;">VTT:</span>${btnCam}`);
};

// Usar o wrapper flex estilo Mesa Online (t20-v69-mesa-skills-wrap) em vez do grid apertado!
const __RENDER_DOCK_ARENA_V68__ = renderizarPainelAcoesPersonagemClicadoArenaJS;
window.renderizarPainelAcoesPersonagemClicadoArenaJS = function() {
    __RENDER_DOCK_ARENA_V68__();
    const box = document.getElementById('arena-clicked-character-actions-bar');
    if (box && box.innerHTML) box.innerHTML = box.innerHTML.replace('t20-v68-skills-grid', 't20-v69-mesa-skills-wrap');
};
const __RENDER_DOCK_MESA_V68__ = renderizarPainelAcoesPersonagemClicadoMesaJS;
window.renderizarPainelAcoesPersonagemClicadoMesaJS = function() {
    __RENDER_DOCK_MESA_V68__();
    const box = document.getElementById('mesa-clicked-character-actions-bar');
    if (box && box.innerHTML) box.innerHTML = box.innerHTML.replace('t20-v68-skills-grid', 't20-v69-mesa-skills-wrap');
};

// Exports globais v69
window.calcularSinergiaOficial7ClassesV69JS = calcularSinergiaOficial7ClassesV69JS;
window.alternarCameraVTTJS = alternarCameraVTTJS;
window.renderizarCardHabilidadePolidoV68JS = renderizarCardHabilidadePolidoV68JS;



// Implementação completa de posicionarRapidoArena2DJS (usado pelos botões Avançar Corpo a Corpo e Flanquear!)
function posicionarRapidoArena2DJS(modoPos) {
    if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario();
    if (typeof __ARENA_STATE__ === 'undefined' || !__ARENA_STATE__) return;
    const a = __ARENA_STATE__;
    const alvo = (a.listaCriaturas && a.listaCriaturas[a.alvoFocoIdx || 0]) || null;
    if (!alvo) return;
    const destX = Math.max(0, Math.min(119, Number(alvo.gx || 6) - 1));
    const destY = Math.max(0, Math.min(119, Number(alvo.gy || 2)));
    if (modoPos === 'FLANQUEAR_ALIADO') {
        a.aliadoFlanqueadorAtivo = true;
        a.posAliadoFlanco = { gx: Math.min(119, Number(alvo.gx || 6) + Math.max(1, Number(alvo.espacoQ || 1))), gy: destY };
        a.flanqueandoAtivo = true;
    }
    if (typeof moverHeroiParaCelulaGridArenaJS === 'function') {
        window.__PERSONAGEM_CLICADO_ARENA__ = { tipo: 'HEROI', id: 'HEROI_PRINCIPAL' };
        moverHeroiParaCelulaGridArenaJS(destX, destY);
    }
    if (typeof registrarLinhaLogArena === 'function') {
        registrarLinhaLogArena(modoPos === 'FLANQUEAR_ALIADO'
            ? `<strong>[Tática]</strong> Herói e Aliado cercaram <strong>${alvo.nomeCriatura}</strong> (Flanqueamento ativo: +2 Ataque!).`
            : `<strong>[Movimento]</strong> Herói avançou para alcance corpo a corpo de <strong>${alvo.nomeCriatura}</strong>!`);
    }
    if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
}
window.posicionarRapidoArena2DJS = posicionarRapidoArena2DJS;




// Dynamic Inline Passives Renderer (Mobile-First, No Side Drawer)
window.__PASSIVAS_INLINE_ABERTO_V100__ = { ARENA: false, MESA: false };

function montarHtmlPassivasInlineV100JS(contexto) {
    const ctx = String(contexto || 'ARENA').toUpperCase();
    const aberto = Boolean(window.__PASSIVAS_INLINE_ABERTO_V100__[ctx]);
    let passivas = [];
    let titulo = 'Passivas';
    try {
        if (ctx === 'ARENA') {
            const sel = window.__PERSONAGEM_CLICADO_ARENA__ || { tipo: 'HEROI_ARENA' };
            const a = (typeof ESTADO_ARENA_ATUAL !== 'undefined') ? ESTADO_ARENA_ATUAL : null;
            const crList = (a && a.criaturas) ? a.criaturas : [];
            const crFoco = crList[Math.min(Math.max(0, Number((a && a.alvoFocoIdx) || 0)), Math.max(0, crList.length - 1))] || null;
            if (sel.tipo === 'AMEACA_ARENA' && crFoco && typeof montarAcoesEPassivasCriaturaV67JS === 'function') {
                passivas = (montarAcoesEPassivasCriaturaV67JS(crFoco, null).passivas) || [];
                titulo = `Passivas de ${crFoco.nomeCriatura || 'Ameaça'}`;
            } else if (typeof ESTADO_ATUAL !== 'undefined' && typeof montarAcoesEPassivasHeroiV67JS === 'function') {
                passivas = (montarAcoesEPassivasHeroiV67JS(ESTADO_ATUAL).passivas) || [];
                titulo = `Passivas de ${ESTADO_ATUAL.nome || 'Herói'}`;
            }
        } else {
            const m = (typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined') ? ESTADO_MESA_ONLINE_ATUAL : null;
            const sel = window.__PERSONAGEM_CLICADO_MESA__ || { tipo: 'HEROI_MESA' };
            const inimigos = (m && m.listaInimigosMesa) ? m.listaInimigosMesa : [];
            const inimFoco = inimigos[Math.min(Math.max(0, Number((m && m.alvoFocoMesaIdx) || 0)), Math.max(0, inimigos.length - 1))] || null;
            const parts = (m && m.participantes) ? m.participantes : [];
            const hAtivo = parts.find(p => p.idHeroi === (typeof HEROI_SELECIONADO_GRID_MESA_ID !== 'undefined' ? HEROI_SELECIONADO_GRID_MESA_ID : null)) || parts[0];
            if (sel.tipo === 'AMEACA_MESA' && inimFoco && typeof montarAcoesEPassivasCriaturaV67JS === 'function') {
                passivas = (montarAcoesEPassivasCriaturaV67JS(inimFoco, null).passivas) || [];
                titulo = `Passivas de ${inimFoco.nome || 'Ameaça'}`;
            } else if (hAtivo && typeof montarAcoesEPassivasHeroiV67JS === 'function') {
                const stH = hAtivo.estadoFicha || (typeof ESTADO_ATUAL !== 'undefined' ? ESTADO_ATUAL : null);
                passivas = stH ? ((montarAcoesEPassivasHeroiV67JS(stH).passivas) || []) : [];
                titulo = `Passivas de ${hAtivo.nome || 'Herói'}`;
            }
        }
    } catch (e) { passivas = []; }

    const cards = passivas.length
        ? passivas.map(p => `
            <div class="t20-passive-card">
                <div class="t20-passive-card-head">
                    <span class="t20-passive-card-title">${String(p.nome || 'Passiva')}</span>
                    <span class="t20-passive-card-origin">${String(p.origem || 'Passiva')}</span>
                </div>
                <div class="t20-passive-card-desc">${String(p.desc || 'Efeito passivo ativo continuamente na ficha.')}</div>
            </div>
        `).join('')
        : '<div class="t20-passive-empty">Nenhuma habilidade passiva registrada para este personagem.</div>';

    return `
        <div id="t20-passivas-inline-box-${ctx}" class="t20-passive-inline-panel ${aberto ? 'is-open' : ''}">
            <div class="t20-passive-inline-header">
                <span>${titulo} (${passivas.length})</span>
                <button type="button" class="t20-passive-close-btn" onclick="alternarPassivasInlineV100JS('${ctx}', false)">Ocultar</button>
            </div>
            <div class="t20-passive-cards-grid">${cards}</div>
        </div>
    `;
}

function alternarPassivasInlineV100JS(contexto, forcarEstado) {
    const ctx = String(contexto || 'ARENA').toUpperCase();
    const atual = Boolean(window.__PASSIVAS_INLINE_ABERTO_V100__[ctx]);
    const proximo = (typeof forcarEstado === 'boolean') ? forcarEstado : !atual;
    window.__PASSIVAS_INLINE_ABERTO_V100__[ctx] = proximo;

    // Remove legacy side drawer if present
    const legacy = document.getElementById('t20-passives-side-drawer');
    if (legacy) legacy.classList.remove('drawer-open');
    const bd = document.getElementById('t20-passives-drawer-backdrop');
    if (bd) bd.classList.remove('drawer-open');

    const hostId = ctx === 'ARENA' ? 'arena-clicked-character-actions-bar' : 'mesa-clicked-character-actions-bar';
    const host = document.getElementById(hostId);
    if (!host) return;
    let existing = document.getElementById(`t20-passivas-inline-box-${ctx}`);
    if (existing) existing.remove();
    if (proximo) {
        const dock = host.querySelector('.t20-clicked-char-dock') || host;
        dock.insertAdjacentHTML('beforeend', montarHtmlPassivasInlineV100JS(ctx));
    }
    // Sync toggle button aria-expanded state
    host.querySelectorAll('.t20-passives-toggle-btn').forEach(btn => {
        btn.setAttribute('aria-expanded', proximo ? 'true' : 'false');
        btn.classList.toggle('is-active', proximo);
    });
}

// Redirect legacy side-drawer toggle calls to the dynamic mobile-first inline panel
function alternarMenuLateralPassivasJS(contexto) {
    alternarPassivasInlineV100JS(contexto || 'ARENA');
}
window.alternarMenuLateralPassivasJS = alternarMenuLateralPassivasJS;
window.alternarPassivasInlineV100JS = alternarPassivasInlineV100JS;
window.montarHtmlPassivasInlineV100JS = montarHtmlPassivasInlineV100JS;

// Auto-reattach inline passives panel after Arena or Mesa action dock re-renders if open
(function() {
    if (typeof renderizarPainelAcoesPersonagemClicadoArenaJS === 'function') {
        const origArena = renderizarPainelAcoesPersonagemClicadoArenaJS;
        renderizarPainelAcoesPersonagemClicadoArenaJS = function() {
            const ret = origArena.apply(this, arguments);
            if (window.__PASSIVAS_INLINE_ABERTO_V100__.ARENA) {
                alternarPassivasInlineV100JS('ARENA', true);
            }
            return ret;
        };
        window.renderizarPainelAcoesPersonagemClicadoArenaJS = renderizarPainelAcoesPersonagemClicadoArenaJS;
    }
    if (typeof renderizarPainelAcoesPersonagemClicadoMesaJS === 'function') {
        const origMesa = renderizarPainelAcoesPersonagemClicadoMesaJS;
        renderizarPainelAcoesPersonagemClicadoMesaJS = function() {
            const ret = origMesa.apply(this, arguments);
            if (window.__PASSIVAS_INLINE_ABERTO_V100__.MESA) {
                alternarPassivasInlineV100JS('MESA', true);
            }
            return ret;
        };
        window.renderizarPainelAcoesPersonagemClicadoMesaJS = renderizarPainelAcoesPersonagemClicadoMesaJS;
    }
})();
