function renderizarFichaEArvoreClientSide(estado, abaDestino, msgBanner) {
    window.__ULTIMO_ESTADO_FICHA__ = estado;
    const est = estado.est;
    if (estado.pvAtualFicha === undefined) estado.pvAtualFicha = est.pvMax;
    if (estado.pmAtualFicha === undefined) estado.pmAtualFicha = est.pmMax;

    // 1. Atualiza pílulas do topo
    const pills = document.querySelectorAll('.quick-pill');
    if (pills.length >= 4) {
        pills[0].textContent = 'PV ' + est.pvMax;
        pills[1].textContent = 'PM ' + est.pmMax;
        pills[2].textContent = 'Def ' + est.defesa;
        pills[3].textContent = 'Score ' + Math.round(estado.scoreFinal);
    }
    const sub = document.querySelector('.topbar .subtitle');
    if (sub) sub.textContent = `${estado.nome} (${estado.raca.nome} · ${resumoClassesMulticlasseJS(estado)} · Arma: ${estado.arma ? estado.arma.nome : 'Desarmado'})`;

    const resDano = calcularResumoDanoJS(estado.nivel, estado.classe, est, estado.poderes, estado.itens, estado.arma, estado.escudo, estado.magias, estado.caminhoArcanista);
    const rnBox = (estado.raca && estado.raca.nome) ? estado.raca.nome.toLowerCase() : '';
    const moBox = (est && est.racaAnteriorOsteon) ? est.racaAnteriorOsteon.toLowerCase() : '';
    const todosPodsBox = [...((est.infoOrigem && est.infoOrigem.poderesExtras) || []), ...((est.infoDevocao && est.infoDevocao.poderes) || []), ...(estado.poderes || [])];
    const infoNatBox = obterInfoArmaNaturalJS(rnBox, moBox, todosPodsBox);

    // 2. Escudos de Atributos Oficiais (FOR, DES, CON, INT, SAB, CAR)
    const atrHtml = ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR'].map(s => {
        const v = est.finais[s] || 0;
        const bBase = (estado.atrBase && estado.atrBase[s] !== undefined) ? estado.atrBase[s] : 0;
        return `<div class="t20-attr-shield">
            <div class="sig">${s}</div>
            <div class="val">${v >= 0 ? '+' + v : v}</div>
            <div class="sub-calc">Base ${bBase >= 0 ? '+' + bBase : bBase}</div>
        </div>`;
    }).join('');

    // 3. Tabela Oficial de ATAQUES (idêntica à Ficha_T20.pdf: Ataques | Teste de Ataque | Dano | Crítico | Tipo | Alcance | Rolar)
    const nomeArmaReal = (estado.arma && estado.arma.nome) ? estado.arma.nome : 'Ataque Desarmado';
    const subArmaReal = (estado.arma && estado.arma.subcategoria) ? estado.arma.subcategoria : 'Corpo a Corpo';
    const ehDistFicha = /distância|distancia|fogo|arco|besta|mosquete|pistola|funda|azagaia/i.test(subArmaReal + ' ' + nomeArmaReal);
    const perAtqNome = ehDistFicha ? 'Pontaria' : 'Luta';
    const mAtqBase = (resDano.descDanoArma || '').match(/Ataque\s*([+-]?\d+)/);
    const bonusAtqArma = mAtqBase ? parseInt(mAtqBase[1], 10) : (est.bonusPericias[perAtqNome] || 0);
    const critObjArma = estado.arma ? extrairCriticoArmaJS(estado.arma.critico_ou_penalidade) : { margem: 20, mult: 2 };
    let margArma = critObjArma.margem;
    let multArma = critObjArma.mult;
    if (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'ataque preciso')) { margArma = Math.max(1, margArma - 2); multArma += 1; }
    if (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'armas da ambição')) { margArma = Math.max(1, margArma - 1); }
    const dadoArmaStr = (estado.arma && estado.arma.dano_ou_defesa && /\d+d\d+/.test(estado.arma.dano_ou_defesa)) ? estado.arma.dano_ou_defesa.match(/\d+d\d+/)[0] : '1d6';
    const atrDanoVal = ehDistFicha
        ? ((todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'estilo de disparo') ? Math.max(0, est.finais.DES) : 0) + (nomeArmaReal.toLowerCase().includes('arco longo') ? Math.max(0, est.finais.FOR) : 0))
        : ((todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'acuidade com arma') && est.finais.DES > est.finais.FOR) ? est.finais.DES : est.finais.FOR);
    const bonusFixoDano = atrDanoVal
        + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'estilo de duas mãos') && !ehDistFicha ? 5 : 0)
        + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'especialização em arma') ? 2 : 0)
        + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'sangue de ferro') ? 2 : 0)
        + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'valentão') && !ehDistFicha ? 2 : 0);
    const resumoArsFicha = calcularResumoArsenalSuperiorEMagicoJS(estado);
    const passoArs = resumoArsFicha.passosExtrasArma + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'empunhadura poderosa') ? 1 : 0);
    const infoDadoArs = avancarPassosDanoJS(dadoArmaStr, passoArs);
    const dadoArmaEfetivoStr = `${infoDadoArs.q}d${infoDadoArs.f}`;
    const bonusFixoComArsenal = bonusFixoDano + (resumoArsFicha ? resumoArsFicha.bonusDanoArma : 0);
    const strDadosExtrasArs = (resumoArsFicha && resumoArsFicha.dadosExtrasArmaStr.length > 0) ? ` + ${resumoArsFicha.dadosExtrasArmaStr.join(' + ')}` : '';
    const formulaDanoArma = `${dadoArmaEfetivoStr}${bonusFixoComArsenal >= 0 ? '+' + bonusFixoComArsenal : bonusFixoComArsenal}${strDadosExtrasArs}`;
    const statsDanoBase = calcularDanoMinMaxMedioFormulaJS(formulaDanoArma);
    if (resumoArsFicha) {
        margArma = Math.max(1, margArma - resumoArsFicha.bonusMargemCrit);
        if (resumoArsFicha.duplicaMargem) margArma = Math.max(1, 21 - ((21 - margArma) * 2));
        multArma += resumoArsFicha.bonusMultCrit;
    }

    const tipoDanoArma = /maça|marreta|tacape|bordão|clava|funda|manopla|cajado/i.test(nomeArmaReal) ? 'Impacto'
        : (/arco|besta|florete|lança|pique|tridente|adaga|mosquete|pistola|chifre/i.test(nomeArmaReal) ? 'Perfuração' : 'Corte');
    const alcanceArma = ehDistFicha ? (/arco longo|mosquete|besta pesada/i.test(nomeArmaReal) ? 'Médio (30m)' : 'Curto (9m)') : (/alabarda|pique|corrente/i.test(nomeArmaReal) ? 'Corpo a Corpo (3m Alongada)' : 'Corpo a Corpo (1,5m)');

    // Quantidade de Ataques da Arma por Rodada (Agredir + Ataque Extra + Disparo Rápido + Estilo de Duas Armas + Veloz)
    const ncFichaLow = (estado.classe && estado.classe.nome) ? estado.classe.nome.toLowerCase() : '';
    const temGolpePessoalFicha = todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'golpe pessoal');
    const ehLancinanteFicha = Boolean(resumoArsFicha && resumoArsFicha.lancinante);

    let qtdAtaquesArmaRodada = 1;
    const fontesAtaquesRodada = ['1x Agredir (Padrão)'];
    if (ncFichaLow === 'guerreiro' && estado.nivel >= 6) {
        qtdAtaquesArmaRodada += 1;
        fontesAtaquesRodada.push('+1x Ataque Extra (Guerreiro Nv. 6, 2 PM)');
    }
    if (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'disparo rápido') && ehDistFicha) {
        qtdAtaquesArmaRodada += 1;
        fontesAtaquesRodada.push('+1x Disparo Rápido (Completa)');
    }
    if (todosPodsBox.some(p => ['estilo de duas armas', 'ambidestria'].includes((p.nome || '').toLowerCase())) && !ehDistFicha && !estado.escudo) {
        qtdAtaquesArmaRodada += 1;
        fontesAtaquesRodada.push('+1x Estilo de Duas Armas');
    }
    if (resumoArsFicha && resumoArsFicha.veloz) {
        qtdAtaquesArmaRodada += 1;
        fontesAtaquesRodada.push('+1x Encanto Veloz (1 PM)');
    }

    // Recalcula statsDanoBase com Crítico Mín/Máx/Médio e DPR por Rodada (baseado em qtdAtaquesArmaRodada)
    const statsBaseFull = calcularDanoMinMaxMedioFormulaJS(
        formulaDanoArma, multArma, ehLancinanteFicha, margArma, false, qtdAtaquesArmaRodada
    );

    let dprExtraArmaNatural = 0;
    let dprCritExtraArmaNatural = 0;

    if (infoNatBox) {
        const forNatTmp = Math.max(0, est.finais.FOR) + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'sangue de ferro') ? 2 : 0) + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'valentão') ? 2 : 0);
        const stNatTmp = calcularDanoMinMaxMedioFormulaJS(`${infoNatBox.dadoStr}+${forNatTmp}`, 2, false, 20, false, 1);
        dprExtraArmaNatural = stNatTmp.medio;
        dprCritExtraArmaNatural = stNatTmp.esperadoGolpeComCrit;
    }

    const linhasTabelaAtaques = [];
    linhasTabelaAtaques.push(`<tr class="trained">
        <td><strong>${nomeArmaReal}${resumoArsFicha && resumoArsFicha.gastoTotal > 0 ? ' ' : ''}</strong> <small style="display:block;opacity:0.85;">Ação Padrão: Agredir (0 PM — p. 233)</small></td>
        <td style="text-align:center;font-weight:900;font-size:14px;">${bonusAtqArma >= 0 ? '+' + bonusAtqArma : bonusAtqArma} <small>(${perAtqNome})</small></td>
        <td style="text-align:center;font-weight:800;">
            ${formulaDanoArma}
            <div style="font-size:10.5px;color:#4ADE80;margin-top:2px;">Normal: Mín ${statsBaseFull.min} | Máx ${statsBaseFull.max} | <strong>Méd: ${statsBaseFull.medio}</strong></div>
        </td>
        <td style="text-align:center;">
            <strong>${margArma}/x${multArma}</strong> <small>(${statsBaseFull.chanceCritPct}%)</small>
            <div style="font-size:10px;color:#E2E8F0;margin-top:1px;"><code>${statsBaseFull.formulaCriticoStr}</code></div><div style="font-size:10.5px;color:#FACC15;margin-top:1px;">Mín ${statsBaseFull.critMin} | Máx ${statsBaseFull.critMax} <strong>Crít Méd: ${statsBaseFull.critMedio}</strong></div>
        </td>
        <td style="text-align:center;background:rgba(15,23,42,0.35);">
            <div style="font-size:11px;font-weight:900;color:#38BDF8;">${qtdAtaquesArmaRodada} atq/rod: <strong>${statsBaseFull.dprNormal}</strong> <small>(Normal)</small></div>
            <div style="font-size:10.5px;color:#FDE047;">c/ Crít: <strong>${statsBaseFull.dprComCritico}/rod</strong>${dprExtraArmaNatural > 0 ? `<br><span style="color:#A7F3D0;">+${infoNatBox.nomeCurto}: ${(statsBaseFull.dprComCritico + dprCritExtraArmaNatural).toFixed(1)}/rod</span>` : ''}</div>
        </td>
        <td style="text-align:center;">${tipoDanoArma}<br><small>${alcanceArma}</small></td>
        <td style="text-align:center;"><button type="button" class="btn-roll-inline" onclick="rolarTesteDaFichaOficialJS('Agredir c/ ${nomeArmaReal.replace(/'/g, '')}', ${bonusAtqArma}, '${formulaDanoArma}', ${margArma}, ${multArma})">Rolar</button></td>
    </tr>`);

    const nvGuerreiroFicha = nivelNaClasseJS(estado, 'Guerreiro');
    const nvPaladinoFicha = nivelNaClasseJS(estado, 'Paladino');
    const nvBarbaroFicha = nivelNaClasseJS(estado, 'Bárbaro');
    if (nvGuerreiroFicha >= 1) {
        const cAEBase = 1 + Math.floor((nvGuerreiroFicha - 1) / 4);
        const cAE = Math.max(1, cAEBase - (resumoArsFicha ? resumoArsFicha.redPmAtaque : 0));
        const vAE = 4 * cAEBase;
        const formAEDano = `${dadoArmaEfetivoStr}+${bonusFixoComArsenal + vAE}${strDadosExtrasArs}`;
        const stAEDano = calcularDanoMinMaxMedioFormulaJS(formAEDano, multArma, ehLancinanteFicha, margArma, false, qtdAtaquesArmaRodada, statsBaseFull.medio, statsBaseFull.esperadoGolpeComCrit);
        const formAEDiv = `${dadoArmaEfetivoStr}+${bonusFixoComArsenal + Math.floor(vAE/2)}${strDadosExtrasArs}`;
        const stAEDiv = calcularDanoMinMaxMedioFormulaJS(formAEDiv, multArma, ehLancinanteFicha, margArma, false, qtdAtaquesArmaRodada, statsBaseFull.medio, statsBaseFull.esperadoGolpeComCrit);
        linhasTabelaAtaques.push(`<tr>
            <td><strong>${nomeArmaReal} + Ataque Especial</strong> <small style="display:block;opacity:0.85;">Gasta ${cAE} PM: +${vAE} Atq OU +${vAE} Dano OU +${vAE/2}/+${vAE/2} (p. 65)</small></td>
            <td style="text-align:center;font-weight:800;">+${bonusAtqArma + Math.floor(vAE/2)} <small>(ou +${bonusAtqArma + vAE})</small></td>
            <td style="text-align:center;">
                ${formAEDiv}
                <div style="font-size:10.5px;color:#FDE047;margin-top:2px;">Normal: Mín ${stAEDiv.min} | Máx ${stAEDiv.max} | <strong>Méd: ${stAEDiv.medio}</strong> <small>(100% Dano: ${stAEDano.medio})</small></div>
            </td>
            <td style="text-align:center;">
                <strong>${margArma}/x${multArma}</strong> <small>(${stAEDiv.chanceCritPct}%)</small>
                <div style="font-size:10px;color:#E2E8F0;margin-top:1px;"><code>${stAEDiv.formulaCriticoStr}</code></div><div style="font-size:10.5px;color:#FACC15;margin-top:1px;">Mín ${stAEDiv.critMin} | Máx ${stAEDiv.critMax} <strong>Crít Méd: ${stAEDiv.critMedio}</strong></div>
            </td>
            <td style="text-align:center;background:rgba(15,23,42,0.35);">
                <div style="font-size:11px;font-weight:900;color:#38BDF8;">${qtdAtaquesArmaRodada} atq/rod: <strong>${stAEDiv.dprNormal}</strong></div>
                <div style="font-size:10.5px;color:#FDE047;">c/ Crít: <strong>${stAEDiv.dprComCritico}/rod</strong></div>
            </td>
            <td style="text-align:center;">${tipoDanoArma}<br><small>${alcanceArma}</small></td>
            <td style="text-align:center;"><button type="button" class="btn-roll-inline" onclick="rolarTesteDaFichaOficialJS('${nomeArmaReal.replace(/'/g, '')} + Ataque Especial (+${vAE/2}/+${vAE/2})', ${bonusAtqArma + Math.floor(vAE/2)}, '${formAEDiv}', ${margArma}, ${multArma})">Rolar</button></td>
        </tr>`);
    }
    if (nvPaladinoFicha >= 1) {
        const bCar = Math.max(0, est.finais.CAR);
        const formGD = `${formulaDanoArma} + 1d8`;
        const stGD = calcularDanoMinMaxMedioFormulaJS(formGD, multArma, ehLancinanteFicha, margArma, false, qtdAtaquesArmaRodada, statsBaseFull.medio, statsBaseFull.esperadoGolpeComCrit);
        linhasTabelaAtaques.push(`<tr>
            <td><strong>${nomeArmaReal} + Golpe Divino</strong> <small style="display:block;opacity:0.85;">Gasta ${Math.max(1, 2 - (resumoArsFicha ? resumoArsFicha.redPmAtaque : 0))} PM: +CAR no Ataque e +1d8 no Dano (p. 81)</small></td>
            <td style="text-align:center;font-weight:800;">+${bonusAtqArma + bCar}</td>
            <td style="text-align:center;">
                ${formGD}
                <div style="font-size:10.5px;color:#FDE047;margin-top:2px;">Normal: Mín ${stGD.min} | Máx ${stGD.max} | <strong>Méd: ${stGD.medio}</strong></div>
            </td>
            <td style="text-align:center;">
                <strong>${margArma}/x${multArma}</strong> <small>(${stGD.chanceCritPct}%)</small>
                <div style="font-size:10.5px;color:#FACC15;margin-top:2px;">Crít: Mín ${stGD.critMin} | Máx ${stGD.critMax} | <strong>Crít Méd: ${stGD.critMedio}</strong></div>
            </td>
            <td style="text-align:center;background:rgba(15,23,42,0.35);">
                <div style="font-size:11px;font-weight:900;color:#38BDF8;">${qtdAtaquesArmaRodada} atq/rod: <strong>${stGD.dprNormal}</strong></div>
                <div style="font-size:10.5px;color:#FDE047;">c/ Crít: <strong>${stGD.dprComCritico}/rod</strong></div>
            </td>
            <td style="text-align:center;">${tipoDanoArma}/Luz<br><small>${alcanceArma}</small></td>
            <td style="text-align:center;"><button type="button" class="btn-roll-inline" onclick="rolarTesteDaFichaOficialJS('${nomeArmaReal.replace(/'/g, '')} + Golpe Divino', ${bonusAtqArma + bCar}, '${formGD}', ${margArma}, ${multArma})">Rolar</button></td>
        </tr>`);
    }
    if (nvBarbaroFicha >= 1) {
        const bFur = 2 + Math.floor((nvBarbaroFicha - 1) / 5);
        const formFur = `${dadoArmaEfetivoStr}+${bonusFixoComArsenal + bFur}${strDadosExtrasArs}`;
        // Fúria dura pela cena inteira, então aplica em TODOS os ataques da rodada!
        const stFur = calcularDanoMinMaxMedioFormulaJS(formFur, multArma, ehLancinanteFicha, margArma, false, qtdAtaquesArmaRodada);
        linhasTabelaAtaques.push(`<tr>
            <td><strong>${nomeArmaReal} em Fúria</strong> <small style="display:block;opacity:0.85;">Gasta 2 PM (Cena): +${bFur} Ataque e +${bFur} Dano em todos os golpes (p. 40)</small></td>
            <td style="text-align:center;font-weight:800;">+${bonusAtqArma + bFur}</td>
            <td style="text-align:center;">
                ${formFur}
                <div style="font-size:10.5px;color:#FDE047;margin-top:2px;">Normal: Mín ${stFur.min} | Máx ${stFur.max} | <strong>Méd: ${stFur.medio}</strong></div>
            </td>
            <td style="text-align:center;">
                <strong>${margArma}/x${multArma}</strong> <small>(${stFur.chanceCritPct}%)</small>
                <div style="font-size:10.5px;color:#FACC15;margin-top:2px;">Crít: Mín ${stFur.critMin} | Máx ${stFur.critMax} | <strong>Crít Méd: ${stFur.critMedio}</strong></div>
            </td>
            <td style="text-align:center;background:rgba(15,23,42,0.35);">
                <div style="font-size:11px;font-weight:900;color:#38BDF8;">${qtdAtaquesArmaRodada} atq/rod: <strong>${stFur.dprNormal}</strong></div>
                <div style="font-size:10.5px;color:#FDE047;">c/ Crít: <strong>${stFur.dprComCritico}/rod</strong></div>
            </td>
            <td style="text-align:center;">${tipoDanoArma}<br><small>${alcanceArma}</small></td>
            <td style="text-align:center;"><button type="button" class="btn-roll-inline" onclick="rolarTesteDaFichaOficialJS('${nomeArmaReal.replace(/'/g, '')} (Fúria)', ${bonusAtqArma + bFur}, '${formFur}', ${margArma}, ${multArma})">Rolar</button></td>
        </tr>`);
    }

    if (temGolpePessoalFicha) {
        const formGP = `${formulaDanoArma} + 1d${infoDadoArs.f} + 2d6`;
        const stGP = calcularDanoMinMaxMedioFormulaJS(formGP, multArma, ehLancinanteFicha, margArma, true, qtdAtaquesArmaRodada, statsBaseFull.medio, statsBaseFull.esperadoGolpeComCrit);
        const custoGPLiq = Math.max(1, 4 - (resumoArsFicha ? resumoArsFicha.redPmAtaque : 0));
        linhasTabelaAtaques.push(`<tr>
            <td><strong>Golpe Pessoal c/ ${nomeArmaReal}</strong> <small style="display:block;opacity:0.85;">Gasta ${custoGPLiq} PM: Brutal (+1d${infoDadoArs.f}) + Elemental (+2d6 Fogo) + Preciso (2d20 escolhe o melhor — p. 66)</small></td>
            <td style="text-align:center;font-weight:800;">+${bonusAtqArma} <small>(2d20 Melhor)</small></td>
            <td style="text-align:center;">
                ${formGP}
                <div style="font-size:10.5px;color:#FDE047;margin-top:2px;">Normal: Mín ${stGP.min} | Máx ${stGP.max} | <strong>Méd: ${stGP.medio}</strong></div>
            </td>
            <td style="text-align:center;">
                <strong>${margArma}/x${multArma}</strong> <small>(2d20: ${stGP.chanceCritPct}%)</small>
                <div style="font-size:10px;color:#E2E8F0;margin-top:1px;"><code>${stGP.formulaCriticoStr}</code></div><div style="font-size:10.5px;color:#FACC15;margin-top:1px;">Mín ${stGP.critMin} | Máx ${stGP.critMax} <strong>Crít Méd: ${stGP.critMedio}</strong></div>
            </td>
            <td style="text-align:center;background:rgba(15,23,42,0.35);">
                <div style="font-size:11px;font-weight:900;color:#38BDF8;">${qtdAtaquesArmaRodada} atq/rod: <strong>${stGP.dprNormal}</strong></div>
                <div style="font-size:10.5px;color:#FDE047;">c/ Crít: <strong>${stGP.dprComCritico}/rod</strong></div>
            </td>
            <td style="text-align:center;">${tipoDanoArma}/Fogo<br><small>${alcanceArma}</small></td>
            <td style="text-align:center;"><button type="button" class="btn-roll-inline" onclick="rolarTesteDaFichaOficialJS('Golpe Pessoal c/ ${nomeArmaReal.replace(/'/g, '')}', ${bonusAtqArma}, '${formGP}', ${margArma}, ${multArma}, true)">Rolar</button></td>
        </tr>`);

        // Linha de COMBO OFENSIVO ACUMULADO (ex.: Ataque Especial + Golpe Pessoal no mesmo ataque + Ataque Extra + Arma Natural!)
        if (nvGuerreiroFicha >= 1) {
            const cAEBase = 1 + Math.floor((estado.nivel - 1) / 4);
            const vAE = 4 * cAEBase;
            const bAtqCombo = bonusAtqArma + Math.floor(vAE / 2);
            const formCombo = `${dadoArmaEfetivoStr}+${bonusFixoComArsenal + Math.floor(vAE / 2)}${strDadosExtrasArs} + 1d${infoDadoArs.f} + 2d6`;
            const stCombo = calcularDanoMinMaxMedioFormulaJS(formCombo, multArma, ehLancinanteFicha, margArma, true, qtdAtaquesArmaRodada, statsBaseFull.medio, statsBaseFull.esperadoGolpeComCrit);
            const pmCombo = Math.max(1, cAEBase - (resumoArsFicha ? resumoArsFicha.redPmAtaque : 0)) + custoGPLiq;
            const dprComboComNatNorm = +(stCombo.dprNormal + dprExtraArmaNatural).toFixed(1);
            const dprComboComNatCrit = +(stCombo.dprComCritico + dprCritExtraArmaNatural).toFixed(1);
            linhasTabelaAtaques.push(`<tr style="background:rgba(180,83,9,0.22);">
                <td><strong>COMBO: ${nomeArmaReal} + Ataque Especial + Golpe Pessoal</strong> <small style="display:block;color:#FDE047;">Acumula ambos no mesmo ataque (${pmCombo} PM): +${Math.floor(vAE/2)} Atq/+${Math.floor(vAE/2)} Dano + Brutal + 2d6 Fogo + Preciso (2d20)</small></td>
                <td style="text-align:center;font-weight:900;color:#FACC15;">+${bAtqCombo} <small>(2d20 Melhor)</small></td>
                <td style="text-align:center;font-weight:800;">
                    ${formCombo}
                    <div style="font-size:10.5px;color:#4ADE80;margin-top:2px;">Normal: Mín ${stCombo.min} | Máx ${stCombo.max} | <strong>Méd: ${stCombo.medio}</strong></div>
                </td>
                <td style="text-align:center;">
                    <strong>${margArma}/x${multArma}</strong> <small>(2d20: ${stCombo.chanceCritPct}%)</small>
                    <div style="font-size:10px;color:#E2E8F0;margin-top:1px;"><code>${stCombo.formulaCriticoStr}</code></div><div style="font-size:10.5px;color:#FACC15;margin-top:1px;">Mín ${stCombo.critMin} | Máx ${stCombo.critMax} <strong>Crít Méd: ${stCombo.critMedio}</strong></div>
                </td>
                <td style="text-align:center;background:rgba(15,23,42,0.45);">
                    <div style="font-size:11px;font-weight:900;color:#4ADE80;">${qtdAtaquesArmaRodada}${infoNatBox ? '+1' : ''} atq: <strong>${dprComboComNatNorm}/rod</strong></div>
                    <div style="font-size:10.5px;color:#FACC15;">c/ Crít: <strong>${dprComboComNatCrit}/rod</strong></div>
                </td>
                <td style="text-align:center;">${tipoDanoArma}/Fogo<br><small>${alcanceArma}</small></td>
                <td style="text-align:center;"><button type="button" class="btn-roll-inline" style="background:#B45309;border-color:#FACC15;" onclick="rolarTesteDaFichaOficialJS('COMBO: ${nomeArmaReal.replace(/'/g, '')} + Ataque Especial + Golpe Pessoal', ${bAtqCombo}, '${formCombo}', ${margArma}, ${multArma}, true)">Rolar Combo</button></td>
            </tr>`);
        }
    }

    // Linha de COMBO MULTICLASSE OFENSIVO (quando o personagem combina habilidades de 2+ classes, ex.: Guerreiro + Bárbaro ou Guerreiro + Paladino!)
    const paresAtqMC = normalizarClassesMulticlasseJS(estado);
    if (paresAtqMC.length > 1 && (nvGuerreiroFicha >= 1 || nvPaladinoFicha >= 1 || nvBarbaroFicha >= 1)) {
        let bAtqMC = bonusAtqArma;
        let bFixoMC = bonusFixoComArsenal;
        let extrasDadosMC = strDadosExtrasArs;
        let pmGastoMC = 0;
        const tagsHabMC = [];
        if (nvGuerreiroFicha >= 1) {
            const cAE_M = 1 + Math.floor((nvGuerreiroFicha - 1) / 4);
            const vAE_M = 4 * cAE_M;
            bAtqMC += Math.floor(vAE_M / 2);
            bFixoMC += Math.floor(vAE_M / 2);
            pmGastoMC += Math.max(1, cAE_M - (resumoArsFicha ? resumoArsFicha.redPmAtaque : 0));
            tagsHabMC.push(`Ataque Especial (+${Math.floor(vAE_M/2)}/+${Math.floor(vAE_M/2)})`);
        }
        if (nvBarbaroFicha >= 1) {
            const bFur_M = 2 + Math.floor((nvBarbaroFicha - 1) / 5);
            pmGastoMC += 2;
            tagsHabMC.push(`Fúria (+${bFur_M}/+${bFur_M} já na base)`);
        }
        if (nvPaladinoFicha >= 1) {
            const dGD_M = 1 + Math.floor(nvPaladinoFicha / 4);
            pmGastoMC += 2;
            tagsHabMC.push(`Golpe Divino (+CAR Atq / +${dGD_M}d8 Dano)`);
            if (!extrasDadosMC.includes('1d8')) extrasDadosMC += ` + ${dGD_M}d8`;
        }
        if (temGolpePessoalFicha) {
            extrasDadosMC += ` + 1d${infoDadoArs.f} + 2d6`;
            pmGastoMC += Math.max(1, 4 - (resumoArsFicha ? resumoArsFicha.redPmAtaque : 0));
            tagsHabMC.push(`Golpe Pessoal (Brutal+2d6+Preciso 2d20)`);
        }
        const formComboMC = `${dadoArmaEfetivoStr}+${bFixoMC}${extrasDadosMC}`;
        const stComboMC = calcularDanoMinMaxMedioFormulaJS(formComboMC, multArma, ehLancinanteFicha, margArma, temGolpePessoalFicha, qtdAtaquesArmaRodada, statsBaseFull.medio, statsBaseFull.esperadoGolpeComCrit);
        linhasTabelaAtaques.push(`<tr style="background:rgba(88,28,135,0.28);border-left:3px solid #C084FC;">
            <td><strong>COMBO MULTICLASSE (${paresAtqMC.map(p => p.classeObj.nome + ' ' + p.nivel).join('/')})</strong> <small style="display:block;color:#E9D5FF;">Acumula habilidades das classes (${pmGastoMC} PM): ${tagsHabMC.join(' + ')}</small></td>
            <td style="text-align:center;font-weight:900;color:#E9D5FF;">+${bAtqMC} ${temGolpePessoalFicha ? '<small>(2d20)</small>' : ''}</td>
            <td style="text-align:center;font-weight:800;">
                ${formComboMC}
                <div style="font-size:10.5px;color:#4ADE80;margin-top:2px;">Normal: Mín ${stComboMC.min} | Máx ${stComboMC.max} | <strong>Méd: ${stComboMC.medio}</strong></div>
            </td>
            <td style="text-align:center;">
                <strong>${margArma}/x${multArma}</strong> <small>(${stComboMC.chanceCritPct}%)</small>
                <div style="font-size:10px;color:#E2E8F0;margin-top:1px;"><code>${stComboMC.formulaCriticoStr}</code></div><div style="font-size:10.5px;color:#FACC15;margin-top:1px;">Mín ${stComboMC.critMin} | Máx ${stComboMC.critMax} <strong>Crít Méd: ${stComboMC.critMedio}</strong></div>
            </td>
            <td style="text-align:center;background:rgba(15,23,42,0.45);">
                <div style="font-size:11px;font-weight:900;color:#C084FC;">${qtdAtaquesArmaRodada} atq: <strong>${stComboMC.dprNormal}/rod</strong></div>
                <div style="font-size:10.5px;color:#FACC15;">c/ Crít: <strong>${stComboMC.dprComCritico}/rod</strong></div>
            </td>
            <td style="text-align:center;">${tipoDanoArma}<br><small>Combo Multiclasse</small></td>
            <td style="text-align:center;"><button type="button" class="btn-roll-inline" style="background:#6B21A8;border-color:#E9D5FF;" onclick="rolarTesteDaFichaOficialJS('COMBO MULTICLASSE: ${nomeArmaReal.replace(/'/g, '')}', ${bAtqMC}, '${formComboMC}', ${margArma}, ${multArma}, ${temGolpePessoalFicha ? 'true' : 'false'})">Rolar Multiclasse</button></td>
        </tr>`);
    }

    if (infoNatBox) {
        const forNat = Math.max(0, est.finais.FOR) + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'sangue de ferro') ? 2 : 0) + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'valentão') ? 2 : 0);
        const atqNat = (est.bonusPericias['Luta'] || 0) + (todosPodsBox.some(p => (p.nome || '').toLowerCase() === 'valentão') ? 2 : 0);
        const formNat = `${infoNatBox.dadoStr}+${forNat}`;
        const stNat = calcularDanoMinMaxMedioFormulaJS(formNat, 2, false, 20, false, 1);
        linhasTabelaAtaques.push(`<tr>
            <td><strong>${infoNatBox.icone} ${infoNatBox.nomeCurto} (Arma Natural)</strong> <small style="display:block;opacity:0.85;">1 PM ao Agredir: +1 ataque extra (${infoNatBox.pagina})</small></td>
            <td style="text-align:center;font-weight:800;">+${atqNat} <small>(Luta)</small></td>
            <td style="text-align:center;">
                ${formNat}
                <div style="font-size:10.5px;color:#A7F3D0;margin-top:2px;">Normal: Mín ${stNat.min} | Máx ${stNat.max} | <strong>Méd: ${stNat.medio}</strong></div>
            </td>
            <td style="text-align:center;">
                <strong>20/x2</strong> <small>(5%)</small>
                <div style="font-size:10.5px;color:#FACC15;margin-top:2px;">Crít: Mín ${stNat.critMin} | Máx ${stNat.critMax} | <strong>Crít Méd: ${stNat.critMedio}</strong></div>
            </td>
            <td style="text-align:center;background:rgba(15,23,42,0.35);">
                <div style="font-size:11px;font-weight:800;color:#A7F3D0;">1 atq extra: <strong>+${stNat.medio}/rod</strong></div>
                <div style="font-size:10.5px;color:#FDE047;">c/ Crít: <strong>+${stNat.esperadoGolpeComCrit}/rod</strong></div>
            </td>
            <td style="text-align:center;">Perfuração<br><small>Corpo a Corpo (1,5m)</small></td>
            <td style="text-align:center;"><button type="button" class="btn-roll-inline" onclick="rolarTesteDaFichaOficialJS('${infoNatBox.nomeCurto} (Arma Natural)', ${atqNat}, '${formNat}', 20, 2)">Rolar</button></td>
        </tr>`);
    }

    if (resDano.danoMedioRaio > 0) {
        const fRaioStr = resDano.descRaio.split('[')[0].trim();
        const stRaio = calcularDanoMinMaxMedioFormulaJS(fRaioStr, 2, false, 20, false, 1);
        linhasTabelaAtaques.push(`<tr>
            <td><strong>Raio Arcano (Poder de Arcanista)</strong> <small style="display:block;opacity:0.85;">Ação Padrão (0 PM): ${resDano.descRaio.split('—')[0]}</small></td>
            <td style="text-align:center;font-weight:800;">CD ${est.cdMagia} <small>(Reflexos)</small></td>
            <td style="text-align:center;">${fRaioStr}<div style="font-size:10.5px;color:#4ADE80;">Mín ${stRaio.min} | Máx ${stRaio.max} | <strong>Méd: ${stRaio.medio}</strong></div></td>
            <td style="text-align:center;">—</td>
            <td style="text-align:center;font-weight:800;color:#38BDF8;">1 disparo: <strong>${stRaio.medio}/rod</strong></td>
            <td style="text-align:center;">Essência/Elem.<br><small>Curto/Médio</small></td>
            <td style="text-align:center;"><button type="button" class="btn-roll-inline" onclick="rolarTesteDaFichaOficialJS('Raio Arcano', 0, '${fRaioStr}', 20, 2)">Rolar</button></td>
        </tr>`);
    }

    // 4. Decomposição Oficial da DEFESA (10 + DES + Armadura + Escudo + Outros)
    const usaPesadaFicha = Boolean(estado.armadura && (estado.armadura.subcategoria || '').toLowerCase().includes('pesada'));
    const modDesDef = usaPesadaFicha ? 0 : est.finais.DES;
    const bArmadura = estado.armadura ? parseIntSeguro(estado.armadura.dano_ou_defesa, 0) : 0;
    const penArmadura = estado.armadura ? parseIntSeguro(estado.armadura.critico_ou_penalidade, 0) : 0;
    const bEscudo = estado.escudo ? parseIntSeguro(estado.escudo.dano_ou_defesa, 0) : 0;
    const penEscudo = estado.escudo ? parseIntSeguro(estado.escudo.critico_ou_penalidade, 0) : 0;
    const bOutrosDef = est.defesa - (10 + modDesDef + bArmadura + bEscudo);

    // 5. Tabela Oficial Completa das 30 PERÍCIAS (TOTAL = 1/2 Nível + Atributo + Treino + Outros)
    const metadeNivel = Math.floor(estado.nivel / 2);
    const bonusTreino = estado.nivel <= 6 ? 2 : (estado.nivel <= 14 ? 4 : 6);
    const perSet = new Set((estado.pericias || []).map(x => x.toLowerCase()));
    const perLinhas = (CATALOGO_T20.pericias || []).map(per => {
        const np = per.nome;
        const valTotal = est.bonusPericias[np] !== undefined ? est.bonusPericias[np] : 0;
        const tr = Array.from(perSet).some(ps => np.toLowerCase() === ps || np.toLowerCase().startsWith(ps));
        const modAtr = est.finais[per.atributo_chave] || 0;
        const tVal = tr ? bonusTreino : 0;
        const outrosVal = valTotal - (metadeNivel + modAtr + tVal);
        const marcaSomenteTreinada = per.somente_treinada ? '<span title="Somente Treinada (Livro p. 114)" style="color:#F59E0B;"></span>' : '';
        const marcaPenArm = per.penalidade_armadura ? '<span title="Penalidade de Armadura (Livro p. 114)" style="color:#93C5FD;"></span>' : '';
        const podeRolar = !per.somente_treinada || tr;
        return `<tr${tr ? ' class="trained"' : ''}>
            <td>${tr ? '' : '<span style="opacity:0.45;">○ </span>'}<strong>${np}</strong> ${marcaSomenteTreinada}${marcaPenArm} <small style="opacity:0.75;">(${per.atributo_chave})</small></td>
            <td style="text-align:center;font-weight:900;font-size:13.5px;">${podeRolar ? (valTotal >= 0 ? '+' + valTotal : valTotal) : '<span style="opacity:0.5;font-size:11px;" title="Somente Treinada">—</span>'}</td>
            <td style="text-align:center;opacity:0.85;">+${metadeNivel}</td>
            <td style="text-align:center;opacity:0.85;">${modAtr >= 0 ? '+' + modAtr : modAtr}</td>
            <td style="text-align:center;opacity:0.85;">${tVal > 0 ? '+' + tVal : '0'}</td>
            <td style="text-align:center;opacity:0.85;">${outrosVal !== 0 ? (outrosVal > 0 ? '+' + outrosVal : outrosVal) : '0'}</td>
            <td style="text-align:center;">${podeRolar ? `<button type="button" class="btn-roll-inline" onclick="rolarTesteDaFichaOficialJS('Perícia: ${np.replace(/'/g, '')}', ${valTotal}, null)"></button>` : '<small style="opacity:0.45;">Treino</small>'}</td>
        </tr>`;
    }).join('');

    // 6. Habilidades, Poderes, Magias e Equipamento (Página 2 da Ficha_T20.pdf)
    const rowsPodNivel = (estado.poderes || []).map((p, idxP) => {
        const nvAq = idxP + 2;
        const tipoLbl = p.eh_poder_classe ? `Classe: ${p.categoria_ou_classe}` : `Geral: ${p.categoria_ou_classe}`;
        const pmLbl = (p.custo_pm && p.custo_pm !== '0') ? ` · ${p.custo_pm} PM` : '';
        return `<div class="item-row"><span class="tag" style="background:var(--t20-ruby-dark);">Nv. ${nvAq}</span><span class="tag">${tipoLbl}</span><strong>${p.nome}</strong> <small>(${p.acao}${pmLbl})</small>: ${p.efeito_resumo}</div>`;
    });
    const rowsPodOrig = ((est.infoOrigem && est.infoOrigem.poderesExtras) || []).map(p =>
        `<div class="item-row"><span class="tag" style="background:#B45309;">1º Nv · Origem</span><strong>${p.nome}</strong> <small>(${p.acao || 'Passivo'})</small>: ${p.efeito_resumo}</div>`
    );
    const rowsPodDev = ((est.infoDevocao && est.infoDevocao.poderes) || []).map(p =>
        `<div class="item-row"><span class="tag" style="background:#6D28D9;">1º Nv · Concedido</span><strong>${p.nome}</strong> <small>(${p.acao || 'Passivo'})</small>: ${p.efeito_resumo}</div>`
    );
    const podHtml = [...rowsPodOrig, ...rowsPodDev, ...rowsPodNivel].join('') || '<div class="item-row">Nenhum poder adicional selecionado.</div>';

    const circMaxFicha = circuloMaximoPermitido(estado.classe, estado.nivel);
    const regraCircStr = ['druida', 'bardo'].includes(ncFichaLow)
        ? `1º ao 4º Círculo (2º no Nv. 6, 3º no Nv. 10, 4º no Nv. 14 — Atual: ${circMaxFicha}º Círculo)`
        : (['arcanista', 'clérigo', 'clerigo'].includes(ncFichaLow)
            ? `1º ao 5º Círculo (2º no Nv. 5, 3º no Nv. 9, 4º no Nv. 13, 5º no Nv. 17 — Atual: ${circMaxFicha}º Círculo)`
            : `Círculo Máximo Atual: ${circMaxFicha}º`);

    const magLinhasTabela = (estado.magias || []).map(m => {
        const infM = resDano.detalhesMagias[m.id_magia] || {};
        const temDanoMag = (infM.danoMedio || 0) > 0 && !(infM.formulaFinal || '').toLowerCase().startsWith('cura ');
        const ehCuraMag = (infM.formulaFinal || '').toLowerCase().startsWith('cura ');
        let colDanoMagHTML = '<span style="opacity:0.65;">Controle / Buff / Utilidade</span>';
        let btnRollMagHTML = `<button type="button" class="btn-roll-inline" onclick="mostrarAba('tab-arena');inicializarArenaVisualSeNecessario();">Arena</button>`;

        if (temDanoMag) {
            const dMin1 = infM.danoMin1Alvo || Math.round(infM.danoMedio * 0.55);
            const dMax1 = infM.danoMax1Alvo || Math.round(infM.danoMedio * 1.45);
            const dMed1 = infM.danoMedio;
            const metade1Alvo = Math.floor(dMed1 / 2);
            if (infM.ehArea) {
                const nAlv = infM.alvosEfetivosArea || infM.alvosAreaPadrao || 3;
                const dMinA = infM.danoMinArea || (dMin1 * nAlv);
                const dMaxA = infM.danoMaxArea || (dMax1 * nAlv);
                const dMedA = infM.danoMedioArea || +(dMed1 * nAlv).toFixed(1);
                colDanoMagHTML = `
                    <div style="font-size:11px;"><strong>1 Alvo:</strong> (${dMax1} Máx + ${dMin1} Mín)/2 = <strong style="color:#4ADE80;">${dMed1}</strong> <small style="opacity:0.85;">(Resistido ½: ${metade1Alvo})</small></div>
                    <div style="margin-top:3px;padding:4px 6px;background:rgba(180,83,9,0.28);border:1px solid #F59E0B;border-radius:5px;font-size:11px;">
                        <strong style="color:#FACC15;">Área (${nAlv} alvos · ${infM.geometriaArea.split('(')[0].trim()}):</strong><br>
                        • <strong>Bruto (${nAlv}×):</strong> (${dMaxA} Máx + ${dMinA} Mín)/2 = <strong style="color:#FEF08A;font-size:12.5px;">${dMedA}</strong><br>
                        • <span style="color:#A7F3D0;"><strong>Ponderado c/ CD ${est.cdMagia}:</strong> ~<strong>${infM.danoMedioAreaResistencia || dMedA}</strong> (50% falham = ${dMed1}, 50% passam = ${metade1Alvo})</span>
                    </div>
                `;
                btnRollMagHTML = `<button type="button" class="btn-roll-inline" style="background:#9333EA;border-color:#FACC15;" onclick="rolarMagiaDaFichaOficialJS('${m.nome.replace(/'/g, '')}', '${(infM.formulaFinal || '').replace(/'/g, '')}', ${est.cdMagia}, '${(m.resistencia || 'Reflexos reduz à metade').replace(/'/g, '')}', ${nAlv})">Rolar (${nAlv}x)</button>`;
            } else {
                colDanoMagHTML = `
                    <div style="font-size:11px;"><strong>Alvo Único (1 criatura):</strong></div>
                    <div style="color:#4ADE80;font-size:11px;">(${dMax1} Máx + ${dMin1} Mín) / 2 = <strong style="font-size:12.5px;">${dMed1}</strong></div>
                    <div style="font-size:10px;opacity:0.85;">${(m.resistencia || '').toLowerCase().includes('metade') ? `Se passar na CD ${est.cdMagia}: ${metade1Alvo} dano (½)` : `Sem redução por metade (${m.resistencia || 'Acerto/Efeito'})`}</div>
                `;
                btnRollMagHTML = `<button type="button" class="btn-roll-inline" style="background:#6D28D9;" onclick="rolarMagiaDaFichaOficialJS('${m.nome.replace(/'/g, '')}', '${(infM.formulaFinal || '').replace(/'/g, '')}', ${est.cdMagia}, '${(m.resistencia || 'Nenhuma').replace(/'/g, '')}', 1)">Rolar</button>`;
            }
        } else if (ehCuraMag) {
            colDanoMagHTML = `<div style="color:#4ADE80;font-weight:800;">${infM.formulaFinal}</div>`;
        }

        return `<tr${infM.ehArea ? ' style="background:rgba(124,58,237,0.12);"' : ''}>
            <td style="text-align:center;"><span class="tag">${m.circulo}º</span></td>
            <td>
                <strong>${m.nome}</strong> ${infM.ehArea ? '<span class="tag" style="background:#B45309;color:#FEF08A;">DANO EM ÁREA</span>' : ''}
                <br><small style="color:#FDE047;">Aprimorada (${infM.pmGasto || m.circulo} PM): ${infM.formulaFinal || ''}</small>
            </td>
            <td>${colDanoMagHTML}</td>
            <td>${m.escola}</td>
            <td>${m.execucao}<br><small>${m.alcance}</small></td>
            <td>${m.resistencia || 'Nenhuma'}<br><small>CD ${est.cdMagia}</small></td>
            <td><small>${m.efeito_e_aprimoramentos}</small></td>
            <td style="text-align:center;">${btnRollMagHTML}</td>
        </tr>`;
    }).join('');

    const itensLinhasTabela = (estado.itens || []).map(it =>
        `<tr>
            <td><strong>${it.nome}</strong></td>
            <td><span class="tag">${it.categoria}</span> <small>${it.subcategoria || ''}</small></td>
            <td>${it.dano_ou_defesa || '—'} <small>(${it.critico_ou_penalidade || '—'})</small></td>
            <td style="text-align:right;">${it.preco || '—'}</td>
            <td style="text-align:center;font-weight:700;">${it.espacos}</td>
        </tr>`
    ).join('');

    const cspHtml = (!estado.validacoes || estado.validacoes.length === 0)
        ? '<div class="csp-ok">FICHA OFICIAL 100% VÁLIDA NO MOTOR CSP — Todos os pré-requisitos de nível/círculo, proficiências, devoção e carga atendidos!</div>'
        : `<div class="csp-err"><strong>Violações de Regra Detectadas pelo Motor CSP (${estado.validacoes.length}):</strong><ul style="margin:6px 0 0 18px;padding:0;">${estado.validacoes.map(v => `<li>${v}</li>`).join('')}</ul></div>`;

    const sim = simularCombateMonteCarloJS(estado, est, resDano);
    const dprOtimo = Math.max(resDano.danoMedioArma || 0, resDano.maiorDanoMagia || 0, resDano.danoMedioRaio || 0);
    const scOtimo = estado.scoreFinal;
    const scBase = estado.scoreInicial || (scOtimo * 0.72);
    const nIt = estado.iteracoes || 120;

    // ==========================================================================
    // ORIENTADOR & GUIA ESTRATÉGICO DE COMBATES (CAP. 7 — 83 AMEAÇAS OFICIAIS)
    // ==========================================================================
    const modoEscalaSim = window.__FICHA_SIM_ESCALA__ || 'DUELO_1V1';
    const filtroAmeacasSim = window.__FICHA_SIM_FILTRO__ || 'RECOMENDADAS_VENCIVEIS';
    const todasCriaturasCap7 = (CATALOGO_T20 && CATALOGO_T20.ameacas_cap7) ? CATALOGO_T20.ameacas_cap7 : [];
    const avaliacoesCriaturasSim = todasCriaturasCap7.map(cr => simularDueloContraCriaturaCap7JS(estado, est, resDano, cr, modoEscalaSim));

    // Ordena as recomendações priorizando ameaças que o herói VENCE (winPct >= 50%), mais próximas ao nível do herói!
    const venciveisOrdenadas = [...avaliacoesCriaturasSim]
        .filter(av => av.winPct >= 50.0)
        .sort((a, b) => {
            const distA = Math.abs((a.criatura.nd_numerico || 1) - estado.nivel);
            const distB = Math.abs((b.criatura.nd_numerico || 1) - estado.nivel);
            if (Math.abs(distA - distB) > 0.5) return distA - distB;
            return b.winPct - a.winPct;
        });

    // Determina a criatura atualmente selecionada pelo usuário para o Guia Estratégico Detalhado
    let idCriaturaGuia = window.__FICHA_SIM_CRIATURA_ID__ || 'AUTO_RECOMENDADA';
    let avSelecionadaGuia = null;
    if (idCriaturaGuia !== 'AUTO_RECOMENDADA') {
        avSelecionadaGuia = avaliacoesCriaturasSim.find(av => av.criatura.id_ameaca === idCriaturaGuia || av.criatura.nome === idCriaturaGuia);
    }
    if (!avSelecionadaGuia) {
        avSelecionadaGuia = venciveisOrdenadas[0] || avaliacoesCriaturasSim[0];
        if (avSelecionadaGuia) idCriaturaGuia = avSelecionadaGuia.criatura.id_ameaca;
    }
    const guiaTaticoAtivo = avSelecionadaGuia ? gerarGuiaEstrategicoCombateFichaJS(estado, est, resDano, avSelecionadaGuia) : null;

    // Filtra a lista da tabela conforme a escolha do usuário
    let listaExibidaTabelaSim = [];
    if (filtroAmeacasSim === 'RECOMENDADAS_VENCIVEIS') {
        listaExibidaTabelaSim = venciveisOrdenadas.slice(0, 12);
        if (listaExibidaTabelaSim.length === 0) {
            listaExibidaTabelaSim = [...avaliacoesCriaturasSim].sort((a, b) => b.winPct - a.winPct).slice(0, 8);
        }
    } else if (filtroAmeacasSim === 'VITORIA_GARANTIDA') {
        listaExibidaTabelaSim = avaliacoesCriaturasSim.filter(av => av.winPct >= 85.0).sort((a, b) => (b.criatura.nd_numerico || 0) - (a.criatura.nd_numerico || 0)).slice(0, 15);
    } else if (filtroAmeacasSim === 'DESAFIOS_TATICOS') {
        listaExibidaTabelaSim = avaliacoesCriaturasSim.filter(av => av.winPct >= 40.0 && av.winPct <= 84.9).sort((a, b) => b.winPct - a.winPct).slice(0, 15);
    } else {
        listaExibidaTabelaSim = avaliacoesCriaturasSim;
    }

    const linhasRecomendadasSimHTML = listaExibidaTabelaSim.map(av => {
        const cr = av.criatura;
        const ehAlvoGuia = avSelecionadaGuia && avSelecionadaGuia.criatura.id_ameaca === cr.id_ameaca;
        const estResumoCurto = av.menorRes
            ? `Focar <strong>${av.menorRes.nome} (${av.menorRes.val >= 0 ? '+' + av.menorRes.val : av.menorRes.val})</strong>` + (nivelNaClasseJS(estado, 'Guerreiro') >= 1 ? ` · AE: <strong>${av.modoAERecomendado}</strong>` : '')
            : 'Ataque Padrão';
        return `<tr${ehAlvoGuia ? ' class="trained"' : ''}>
            <td>
                <strong>${ehAlvoGuia ? '' : ''}${cr.nome}</strong>
                <span class="tag" style="margin-left:4px;">ND ${cr.nd} · ${cr.papel}</span>
                <small style="display:block;opacity:0.8;">${cr.grupo_cap7} · ${cr.pagina_livro_pdf}</small>
            </td>
            <td style="text-align:center;">Def <strong>${av.defCriatura}</strong><br><small>Atq <strong>+${av.atqCriatura}</strong></small></td>
            <td style="text-align:center;"><strong>${av.pvCriaturaMax} PV</strong><br><small>Dano ~${av.danoCriaturaAplicado}/rod</small></td>
            <td style="text-align:center;">
                <span style="color:#4ADE80;font-weight:800;">Fraqueza: ${av.menorRes.sigla} ${av.menorRes.val >= 0 ? '+' + av.menorRes.val : av.menorRes.val}</span><br>
                <small style="opacity:0.8;">Evitar: ${av.maiorRes.sigla} ${av.maiorRes.val >= 0 ? '+' + av.maiorRes.val : av.maiorRes.val}</small>
            </td>
            <td style="text-align:center;">
                Acerto: <strong>${av.probAcertoHeroiPct}%</strong><br>
                <small>Vence em <strong>${av.ttkHeroi}t</strong> (Aguenta ${av.ttkInimigo}t)</small>
            </td>
            <td style="text-align:right;font-weight:900;font-size:13.5px;color:${av.corFaixa};">
                ${av.winPct}%
                <small style="display:block;font-size:10px;font-weight:700;">${av.faixaDificuldade}</small>
            </td>
            <td><small>${estResumoCurto}</small></td>
            <td style="text-align:center;white-space:nowrap;">
                <button type="button" class="btn-roll-inline" style="background:#1E3A8A;margin-right:3px;" onclick="atualizarOrientadorCombateFichaJS('${cr.id_ameaca}')">Guia</button>
                <button type="button" class="btn-roll-inline" style="background:#991B1B;" onclick="desafiarCriaturaCap7NaArena('${cr.id_ameaca}')">Arena</button>
            </td>
        </tr>`;
    }).join('');

    const temaAtual = document.body.getAttribute('data-app-theme') || 'DARK';

    const fichaCompletaHTML = `
    <div class="sheet-card">
        <!-- BARRA SUPERIOR DE CONTROLES RÁPIDOS E TEMA DA FICHA -->
        <div class="t20-sheet-toolbar">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                <span style="font-family:'Cinzel Decorative','Cinzel',serif;font-weight:900;font-size:15px;color:var(--t20-ruby);">TORMENTA 20 — FICHA DE PERSONAGEM (EDIÇÃO JOGO DO ANO)</span>
                <span class="tag">Score IA: ${estado.scoreFinal.toFixed(1)} pts</span>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;">
                <button type="button" id="btn-toggle-tema-ficha" class="btn btn-save" style="width:auto;min-height:32px;padding:4px 10px;font-size:11.5px;" onclick="alternarTemaFichaClarasEscurasJS()">
                    ${temaAtual === 'PARCHMENT' ? 'Mudar p/ Tema Escuro (Grimório)' : 'Mudar p/ Tema Ficha Clássica Impressa (Clara)'}
                </button>
                <button type="button" class="btn btn-save" style="width:auto;min-height:32px;padding:4px 10px;font-size:11.5px;" onclick="sortearAparenciaAleatoriaRacialJS()">
                    Sortear Visual (${estado.raca.nome})
                </button>
                <button type="button" class="btn btn-ai" style="width:auto;min-height:32px;padding:4px 12px;font-size:11.5px;margin:0;" onclick="mostrarAba('tab-arena');inicializarArenaVisualSeNecessario();">
                    Combater na Arena JRPG
                </button>
                <button type="button" class="btn btn-save" style="width:auto;min-height:32px;padding:4px 10px;font-size:11.5px;margin:0;background:#15803D;color:#FFF;" onclick="salvarFichaLocalStorageOffline()">
                    Salvar Ficha
                </button>
                <button type="button" class="btn btn-save" style="width:auto;min-height:32px;padding:4px 10px;font-size:11.5px;margin:0;background:#1E3A8A;color:#FFF;" onclick="abrirGerenciadorFichasNuvemJS()">
                    Fichas Salvas
                </button>
                <button type="button" class="btn btn-manual" style="width:auto;min-height:32px;padding:4px 10px;font-size:11.5px;margin:0;" onclick="mostrarAba('tab-manual')">
                    Editar Ficha
                </button>
            </div>
        </div>

        <!-- TOAST INTERATIVO DE ROLAGEM DIRETA NA FICHA -->
        <div id="ficha-quick-roll-toast" style="display:none;background:linear-gradient(90deg, #14532D, #065F46);border:2px solid #FACC15;color:#FFFFFF;padding:9px 14px;border-radius:9px;margin-bottom:12px;font-size:13.5px;box-shadow:0 6px 16px rgba(0,0,0,0.45);"></div>
        <div id="ficha-cloud-manager-box" style="display:none;background:rgba(15,23,42,0.95);border:2px solid #38BDF8;border-radius:10px;padding:12px;margin-bottom:12px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                <strong style="color:#38BDF8;font-size:13px;">Fichas Salvas (Google Sheets Nuvem / LocalStorage Offline)</strong>
                <button type="button" class="btn-roll-inline" onclick="abrirGerenciadorFichasNuvemJS()">Fechar</button>
            </div>
            <div id="ficha-cloud-manager-list"></div>
        </div>

        <!-- CABEÇALHO OFICIAL ESTILO FICHA_T20.PDF -->
        <div class="t20-header-grid">
            <div style="display:flex;align-items:center;justify-content:center;">
                <div id="ficha-retrato-custom-svg">
                    ${typeof construirCardVitrine3DRetratoFichaSVG === 'function' ? construirCardVitrine3DRetratoFichaSVG(estado) : `<svg viewBox="120 55 200 245" width="116" height="142" xmlns="http://www.w3.org/2000/svg"><defs>${gerarDefsShader3DRPG()}</defs>${construirSpriteSVGHeroiJRPG(estado)}</svg>`}
                </div>
            </div>
            <div style="display:grid;grid-template-rows:1fr 1fr;gap:8px;">
                <div class="t20-field-box">
                    <div class="lbl-t20">PERSONAGEM</div>
                    <div class="val-t20" style="font-size:17px;">${estado.nome}</div>
                </div>
                <div class="t20-field-box">
                    <div class="lbl-t20">RAÇA & TAMANHO</div>
                    <div class="val-t20">${estado.raca.nome} <small style="opacity:0.75;">(${estado.raca.tamanho || 'Médio'} · ${est.deslocamento}m)</small></div>
                </div>
            </div>
            <div style="display:grid;grid-template-rows:1fr 1fr;gap:8px;">
                <div class="t20-field-box">
                    <div class="lbl-t20">JOGADOR(A) / ARQUÉTIPO</div>
                    <div class="val-t20">${estado.jogador} <small style="opacity:0.8;">(${estado.arquetipo})</small></div>
                </div>
                <div class="t20-field-box">
                    <div class="lbl-t20">ORIGEM</div>
                    <div class="val-t20">${est.infoOrigem ? est.infoOrigem.labelOrigem : (estado.origem ? estado.origem.nome : 'Sem Origem')}</div>
                </div>
            </div>
            <div style="display:grid;grid-template-rows:1fr 1fr;gap:8px;">
                <div class="t20-field-box">
                    <div class="lbl-t20">CLASSE & NÍVEL</div>
                    <div class="val-t20">${resumoClassesMulticlasseJS(estado)}</div>
                </div>
                <div class="t20-field-box">
                    <div class="lbl-t20">DIVINDADE</div>
                    <div class="val-t20">${estado.deus ? `${estado.deus.nome} (${estado.deus.energia})` : 'Sem Divindade'}</div>
                </div>
            </div>
        </div>
        ${typeof construirPainelPersonalizacaoAparenciaFichaHTML === 'function' ? construirPainelPersonalizacaoAparenciaFichaHTML(estado) : ''}

        ${cspHtml}
        <div style="height:10px;"></div>

        <!-- PAINEL INTERATIVO DE MULTICLASSE OFICIAL (CAP. 1, P. 34 — TORMENTA20 EDIÇÃO JOGO DO ANO) -->
        ${(() => {
            const paresMC = normalizarClassesMulticlasseJS(estado);
            const ehMC = paresMC.length > 1;
            const c1At = paresMC[0] ? paresMC[0].classeObj.nome : estado.classe.nome;
            const nv1At = paresMC[0] ? paresMC[0].nivel : estado.nivel;
            const c2At = estado.classeSecundaria ? estado.classeSecundaria.nome : 'NENHUMA';
            const nv2At = estado.classeSecundaria ? (estado.nivelClasseSecundaria || 0) : 0;
            const c3At = estado.classeTerciaria ? estado.classeTerciaria.nome : 'NENHUMA';
            const nv3At = estado.classeTerciaria ? (estado.nivelClasseTerciaria || 0) : 0;
            const optsC1 = CATALOGO_T20.classes.map(c => `<option value="${c.nome}" ${c.nome === c1At ? 'selected' : ''}>${c.nome} (PV ${c.pv_inicial}+${c.pv_por_nivel}/nv · PM ${c.pm_por_nivel}/nv)</option>`).join('');
            const optsC2 = `<option value="NENHUMA" ${c2At === 'NENHUMA' ? 'selected' : ''}>— Nenhuma (Classe Única) —</option>` + CATALOGO_T20.classes.map(c => `<option value="${c.nome}" ${c.nome === c2At ? 'selected' : ''}>+ ${c.nome} (+${c.pv_por_nivel} PV/nv · +${c.pm_por_nivel} PM/nv)</option>`).join('');
            const optsC3 = `<option value="NENHUMA" ${c3At === 'NENHUMA' ? 'selected' : ''}>— Nenhuma —</option>` + CATALOGO_T20.classes.map(c => `<option value="${c.nome}" ${c.nome === c3At ? 'selected' : ''}>+ ${c.nome} (+${c.pv_por_nivel} PV/nv · +${c.pm_por_nivel} PM/nv)</option>`).join('');
            const habsMC = (est.habilidadesMulticlasse || []).map(h => `<span class="tag" style="background:${h.tag.includes('Multiclasse') ? '#6B21A8' : 'var(--t20-ruby-dark)'};color:#FFF;margin:2px;"><strong>${h.classe} ${h.nivel}:</strong> ${h.nome}</span>`).join(' ');

            return `<div class="t20-section-box" style="margin-bottom:12px;border:2px solid ${ehMC ? '#A855F7' : 'var(--t20-gold)'};background:${ehMC ? 'linear-gradient(135deg, rgba(59,7,100,0.28), rgba(15,23,42,0.88))' : 'var(--t20-card-bg)'};">
                <div class="t20-sec-hdr" style="background:${ehMC ? 'linear-gradient(90deg, #581C87, #7E22CE)' : 'var(--t20-ruby)'};">
                    <span>MULTICLASSE & PROGRESSÃO DE NÍVEIS (LIVRO BÁSICO JOGO DO ANO, CAP. 1, P. 34)</span>
                    <span>${resumoClassesMulticlasseJS(estado)}</span>
                </div>
                <div style="padding:10px 12px;">
                    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px;align-items:center;background:rgba(15,23,42,0.65);padding:8px 10px;border-radius:8px;border:1px solid rgba(192,132,252,0.45);">
                        <div style="flex:1;min-width:250px;">
                            <label style="font-size:10.5px;font-weight:800;color:#E9D5FF;display:block;margin-bottom:2px;">Política de Multiclasse do Algoritmo (MCTS / CSP):</label>
                            <select id="ficha-mc-modo-ia" onchange="otimizarMulticlassePelaIAFichaJS(this.value)" style="min-height:32px;padding:4px 8px;font-size:11.5px;background:#0F172A;color:#F8FAFC;border:1px solid #A855F7;">
                                <option value="AUTO_MCTS" ${(estado.modoMulticlasse || 'AUTO_MCTS') === 'AUTO_MCTS' ? 'selected' : ''}>IA Decide Automaticamente (Compara Classe Pura vs. Todas as Multiclasses)</option>
                                <option value="SEM_MULTICLASSE" ${estado.modoMulticlasse === 'SEM_MULTICLASSE' ? 'selected' : ''}>Sem Multiclasse (Forçar 100% Classe Única / Monoclasse)</option>
                                <option value="FORCAR_MULTICLASSE_OTIMA" ${estado.modoMulticlasse === 'FORCAR_MULTICLASSE_OTIMA' ? 'selected' : ''}>Forçar Melhor Multiclasse pela IA (Sempre Híbrido Otimizado)</option>
                                <option value="DIP_1_NIVEL" ${estado.modoMulticlasse === 'DIP_1_NIVEL' ? 'selected' : ''}>Dip Tático de 1 Nível (Nv-1 na 1ª Classe + 1 Nv na Melhor 2ª Classe)</option>
                                <option value="DIP_2_NIVEIS" ${estado.modoMulticlasse === 'DIP_2_NIVEIS' ? 'selected' : ''}>Dip de 2 Níveis (Nv-2 na 1ª Classe + 2 Nv na Melhor 2ª Classe + Poder)</option>
                                <option value="EQUILIBRADA_50_50" ${estado.modoMulticlasse === 'EQUILIBRADA_50_50' ? 'selected' : ''}>Multiclasse Equilibrada (~50% / 50% entre 2 Classes Sinérgicas)</option>
                                <option value="TRICLASSE_OTIMA" ${estado.modoMulticlasse === 'TRICLASSE_OTIMA' ? 'selected' : ''}>Triclasse Sinérgica Otimizada pela IA (Combina 3 Classes)</option>
                                <option value="MANUAL_FIXA" ${estado.modoMulticlasse === 'MANUAL_FIXA' ? 'selected' : ''}>Multiclasse Manual (Escolher livremente nos seletores abaixo)</option>
                            </select>
                        </div>
                        <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                            <button type="button" class="btn-roll-inline" style="background:linear-gradient(135deg,#6B21A8,#9333EA);border-color:#FACC15;padding:6px 11px;font-size:11.5px;" onclick="otimizarMulticlassePelaIAFichaJS('FORCAR_MULTICLASSE_OTIMA')">IA Escolher Melhor Multiclasse</button>
                            <button type="button" class="btn-roll-inline" style="background:linear-gradient(135deg,#065F46,#047857);border-color:#34D399;padding:6px 11px;font-size:11.5px;" onclick="otimizarMulticlassePelaIAFichaJS('AUTO_MCTS')">Comparar Pura vs. Multiclasse</button>
                            <button type="button" class="btn-roll-inline" style="background:#334155;padding:6px 10px;font-size:11.5px;" onclick="otimizarMulticlassePelaIAFichaJS('SEM_MULTICLASSE')">Sem Multiclasse (${estado.classe.nome} Pura)</button>
                        </div>
                    </div>
                    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;align-items:center;">
                        <span style="font-size:11px;font-weight:800;color:#FDE047;">Variações Clássicas (1 Clique):</span>
                        <button type="button" class="btn-roll-inline" onclick="selecionarPresetMulticlasseFichaJS('Guerreiro', 'Bárbaro', 1, 'NENHUMA', 0)">Guerreiro ${Math.max(1, estado.nivel-1)} / Bárbaro 1 (Dip Fúria)</button>
                        <button type="button" class="btn-roll-inline" onclick="selecionarPresetMulticlasseFichaJS('Guerreiro', 'Paladino', 2, 'NENHUMA', 0)">Guerreiro + Paladino (Golpe Divino)</button>
                        <button type="button" class="btn-roll-inline" onclick="selecionarPresetMulticlasseFichaJS('Guerreiro', 'Arcanista', Math.max(1, estado.nivel - 1), 'NENHUMA', 0)">Guerreiro 1 / Arcanista ${Math.max(1, estado.nivel-1)} (Magus)</button>
                        <button type="button" class="btn-roll-inline" onclick="selecionarPresetMulticlasseFichaJS('Caçador', 'Ladino', Math.max(1, Math.floor(estado.nivel/2)), 'NENHUMA', 0)">Caçador + Ladino (Furtivo)</button>
                        <button type="button" class="btn-roll-inline" onclick="selecionarPresetMulticlasseFichaJS('Guerreiro', 'Bárbaro', 1, 'Paladino', 1)">Triclasse: Guerreiro + Bárbaro + Paladino</button>
                    </div>
                    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(175px, 1fr));gap:8px;align-items:end;margin-bottom:8px;">
                        <div>
                            <label style="font-size:10.5px;font-weight:800;display:block;margin-bottom:2px;">Nível Total de Personagem (1–20)</label>
                            <input type="number" id="ficha-mc-nivel-total" min="1" max="20" value="${estado.nivel}" onchange="aplicarMulticlasseRapidaFichaJS()" style="min-height:32px;padding:4px 8px;font-size:12px;">
                        </div>
                        <div>
                            <label style="font-size:10.5px;font-weight:800;display:block;margin-bottom:2px;">1ª Classe (Primária — Nv. ${nv1At})</label>
                            <select id="ficha-mc-classe1" onchange="aplicarMulticlasseRapidaFichaJS()" style="min-height:32px;padding:4px 8px;font-size:12px;">${optsC1}</select>
                        </div>
                        <div>
                            <label style="font-size:10.5px;font-weight:800;display:block;margin-bottom:2px;">2ª Classe (Multiclasse — p. 34)</label>
                            <select id="ficha-mc-classe2" onchange="aplicarMulticlasseRapidaFichaJS()" style="min-height:32px;padding:4px 8px;font-size:12px;">${optsC2}</select>
                        </div>
                        <div>
                            <label style="font-size:10.5px;font-weight:800;display:block;margin-bottom:2px;">Níveis na 2ª Classe</label>
                            <input type="number" id="ficha-mc-nivel2" min="0" max="19" value="${nv2At}" onchange="aplicarMulticlasseRapidaFichaJS()" style="min-height:32px;padding:4px 8px;font-size:12px;">
                        </div>
                        <div>
                            <label style="font-size:10.5px;font-weight:800;display:block;margin-bottom:2px;">3ª Classe (Opcional)</label>
                            <select id="ficha-mc-classe3" onchange="aplicarMulticlasseRapidaFichaJS()" style="min-height:32px;padding:4px 8px;font-size:12px;">${optsC3}</select>
                        </div>
                        <div>
                            <label style="font-size:10.5px;font-weight:800;display:block;margin-bottom:2px;">Níveis na 3ª Classe</label>
                            <input type="number" id="ficha-mc-nivel3" min="0" max="18" value="${nv3At}" onchange="aplicarMulticlasseRapidaFichaJS()" style="min-height:32px;padding:4px 8px;font-size:12px;">
                        </div>
                    </div>
                    <div style="font-size:11px;line-height:1.45;background:rgba(15,23,42,0.55);padding:8px 10px;border-radius:6px;border-left:3px solid #C084FC;">
                        <div><strong>Regras Oficiais de Multiclasse Aplicadas (Livro Básico JdA, p. 34):</strong></div>
                        <div>• <strong>PV em Multiclasse:</strong> <code>${est.detPV}</code> <em>(Apenas o 1º nível da 1ª classe recebe PV inicial cheio; classes secundárias somam o PV por nível + CON)</em>.</div>
                        <div>• <strong>PM em Multiclasse:</strong> <code>${est.detPM}</code>.</div>
                        <div>• <strong>Perícias & Círculos de Magia:</strong> Perícias iniciais vêm apenas da 1ª classe (<strong>${c1At}</strong>); círculos de magia e limites de PM de habilidades respeitam o nível individual em cada classe.</div>
                        <div style="margin-top:4px;"><strong>Habilidades Automáticas das Classes Ativas:</strong> ${habsMC}</div>
                    </div>
                    ${(() => {
                        const candsRank = gerarCandidatosMulticlassePorPoliticaJS(estado.classe, estado.nivel, estado.arquetipo, 'AUTO_MCTS', 'NENHUMA', 0, 'NENHUMA', 0);
                        const rankMC = avaliarRankingMulticlasseMCTSJS({
                            nivel: estado.nivel, raca: estado.raca, classe: estado.classe, origem: estado.origem, deus: estado.deus,
                            caminhoArcanista: estado.caminhoArcanista, arquetipo: estado.arquetipo, atrBase: estado.atrBase,
                            livres: estado.livres, pericias: estado.pericias, poderes: estado.poderes, itens: estado.itens,
                            arma: estado.arma, armadura: estado.armadura, escudo: estado.escudo, magias: estado.magias
                        }, candsRank).slice(0, 5);
                        if (!rankMC.length) return '';
                        const rowsR = rankMC.map((r, idxR) => {
                            const c2N = r.classeSecundaria ? r.classeSecundaria.nome : 'NENHUMA';
                            const nv2N = r.nivelClasseSecundaria || 0;
                            const c3N = r.classeTerciaria ? r.classeTerciaria.nome : 'NENHUMA';
                            const nv3N = r.nivelClasseTerciaria || 0;
                            const ehAtual = (r.resumoDist === paresMC.map(p => p.classeObj.nome + ' ' + p.nivel).join(' / '));
                            return `<tr${ehAtual ? ' class="trained"' : ''}>
                                <td><strong>${idxR === 0 ? '' : '#' + (idxR + 1) + ' '}${r.resumoDist}</strong> <small style="display:block;opacity:0.8;">${r.rotuloPolitica}</small></td>
                                <td style="text-align:center;">PV <strong>${r.estCand.pvMax}</strong> | PM <strong>${r.estCand.pmMax}</strong> | Def <strong>${r.estCand.defesa}</strong></td>
                                <td style="text-align:center;color:#4ADE80;font-weight:800;">${r.dprPotencial}/rod</td>
                                <td style="text-align:right;font-weight:900;color:#FDE047;">${r.scoreTotalMC} pts</td>
                                <td><small>${r.justificativaSinergia}</small></td>
                                <td style="text-align:center;">
                                    <button type="button" class="btn-roll-inline" style="background:${ehAtual ? '#065F46' : '#1E3A8A'};" onclick="selecionarPresetMulticlasseFichaJS('${r.classe.nome}', '${c2N}', ${nv2N}, '${c3N}', ${nv3N})">${ehAtual ? 'Ativa' : 'Aplicar'}</button>
                                </td>
                            </tr>`;
                        }).join('');
                        return `<details class="t20-collapsible" style="margin-top:8px;margin-bottom:0;">
                            <summary style="padding:6px 10px;font-size:11.5px;">
                                <span>Ver Comparativo da IA: Classe Pura vs. Melhores Variações de Multiclasse p/ Nv. ${estado.nivel} (Top ${rankMC.length})</span>
                                <span style="font-size:10.5px;opacity:0.85;">Clique para comparar e aplicar ▼</span>
                            </summary>
                            <div class="collapsible-body" style="padding:8px;">
                                <div style="overflow-x:auto;">
                                    <table class="skills-table" style="font-size:11px;">
                                        <thead>
                                            <tr>
                                                <th>Distribuição de Classes</th>
                                                <th style="text-align:center;">PV / PM / Defesa</th>
                                                <th style="text-align:center;">DPR Potencial</th>
                                                <th style="text-align:right;">Score Sinergia IA</th>
                                                <th>Análise Tática da Variação (Livro p. 34)</th>
                                                <th style="text-align:center;">Ação</th>
                                            </tr>
                                        </thead>
                                        <tbody>${rowsR}</tbody>
                                    </table>
                                </div>
                            </div>
                        </details>`;
                    })()}
                </div>
            </div>`;
        })()}

        <!-- PÁGINA 1 DA FICHA OFICIAL: 2 COLUNAS (ESQUERDA: ATRIBUTOS, PV/PM, ATAQUES, DEFESA | DIREITA: 30 PERÍCIAS) -->
        <div class="sheet-columns">
            <!-- COLUNA ESQUERDA DA FICHA OFICIAL -->
            <div>
                <!-- 1. SEIS ESCUDOS DE ATRIBUTOS (FOR, DES, CON, INT, SAB, CAR) -->
                <div class="t20-attr-shield-row">${atrHtml}</div>

                <!-- 2. PONTOS DE VIDA (PV) & PONTOS DE MANA (PM) -->
                <div class="t20-pv-pm-grid">
                    <div class="t20-vital-box">
                        <div class="vital-hdr">
                            <span>PV — PONTOS DE VIDA</span>
                            <span style="font-size:10px;opacity:0.9;">Morte Instantânea: ${-Math.max(10, Math.floor(est.pvMax / 2))} PV</span>
                        </div>
                        <div class="t20-vital-cells">
                            <div class="t20-vital-cell">
                                <div style="font-size:9.5px;font-weight:800;opacity:0.75;">MÁXIMOS</div>
                                <div style="font-size:22px;font-weight:900;font-family:'Cinzel',serif;color:#EF4444;">${est.pvMax}</div>
                            </div>
                            <div class="t20-vital-cell">
                                <div style="font-size:9.5px;font-weight:800;opacity:0.75;">ATUAIS</div>
                                <div id="ficha-input-pv-atual" style="font-size:22px;font-weight:900;font-family:'Cinzel',serif;color:#4ADE80;">${estado.pvAtualFicha}</div>
                                <div style="display:flex;justify-content:center;gap:3px;margin-top:3px;">
                                    <button type="button" class="btn-roll-inline" onclick="ajustarPVPMFichaDiretoJS('PV', -5)">-5</button>
                                    <button type="button" class="btn-roll-inline" onclick="ajustarPVPMFichaDiretoJS('PV', -1)">-1</button>
                                    <button type="button" class="btn-roll-inline" style="background:#065F46;" onclick="ajustarPVPMFichaDiretoJS('PV', 1)">+1</button>
                                    <button type="button" class="btn-roll-inline" style="background:#065F46;" onclick="ajustarPVPMFichaDiretoJS('PV', 5)">+5</button>
                                    <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="ajustarPVPMFichaDiretoJS('PV', 999)">Máx</button>
                                </div>
                            </div>
                        </div>
                        <div style="padding:4px 10px 7px 10px;font-size:11px;opacity:0.85;border-top:1px dashed rgba(148,163,184,0.25);">
                            <strong>Fórmula:</strong> ${est.detPV}
                        </div>
                    </div>

                    <div class="t20-vital-box pm-box">
                        <div class="vital-hdr">
                            <span>PM — PONTOS DE MANA</span>
                            <span style="font-size:10px;opacity:0.9;">Limite: ${resDano.limitePM} PM/uso</span>
                        </div>
                        <div class="t20-vital-cells">
                            <div class="t20-vital-cell">
                                <div style="font-size:9.5px;font-weight:800;opacity:0.75;">MÁXIMOS</div>
                                <div style="font-size:22px;font-weight:900;font-family:'Cinzel',serif;color:#38BDF8;">${est.pmMax}</div>
                            </div>
                            <div class="t20-vital-cell">
                                <div style="font-size:9.5px;font-weight:800;opacity:0.75;">ATUAIS</div>
                                <div id="ficha-input-pm-atual" style="font-size:22px;font-weight:900;font-family:'Cinzel',serif;color:#38BDF8;">${estado.pmAtualFicha}</div>
                                <div style="display:flex;justify-content:center;gap:3px;margin-top:3px;">
                                    <button type="button" class="btn-roll-inline" onclick="ajustarPVPMFichaDiretoJS('PM', -2)">-2</button>
                                    <button type="button" class="btn-roll-inline" onclick="ajustarPVPMFichaDiretoJS('PM', -1)">-1</button>
                                    <button type="button" class="btn-roll-inline" style="background:#065F46;" onclick="ajustarPVPMFichaDiretoJS('PM', 1)">+1</button>
                                    <button type="button" class="btn-roll-inline" style="background:#065F46;" onclick="ajustarPVPMFichaDiretoJS('PM', 4)">+4</button>
                                    <button type="button" class="btn-roll-inline" style="background:#1E3A8A;" onclick="ajustarPVPMFichaDiretoJS('PM', 999)">Máx</button>
                                </div>
                            </div>
                        </div>
                        <div style="padding:4px 10px 7px 10px;font-size:11px;opacity:0.85;border-top:1px dashed rgba(148,163,184,0.25);">
                            <strong>Fórmula:</strong> ${est.detPM}
                        </div>
                    </div>
                </div>

                <!-- 3. QUADRO OFICIAL DE ATAQUES (COM DANO MÉDIO NORMAL, DANO MÉDIO CRÍTICO E DANO MÉDIO POR RODADA) -->
                <div class="section-box">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:8px;">
                        <h3 style="margin:0;border:none;padding:0;">ATAQUES (Normal, Crítico & Dano por Rodada)</h3>
                        <span class="tag" style="background:#1E3A8A;color:#FFF;" title="${fontesAtaquesRodada.join(' + ')}">Ataques por Rodada: ${qtdAtaquesArmaRodada}x Arma${infoNatBox ? ` + 1x ${infoNatBox.nomeCurto}` : ''} (${fontesAtaquesRodada.join(' + ')})</span>
                    </div>
                    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(165px, 1fr));gap:6px;margin-bottom:8px;">
                        <div class="t20-field-box" style="padding:6px 8px;">
                            <div class="lbl-t20">1. DANO MÉDIO NORMAL (1 GOLPE)</div>
                            <div class="val-t20" style="color:#4ADE80;font-size:14px;">${statsBaseFull.medio} <small style="font-size:10.5px;opacity:0.9;">= (${statsBaseFull.max} + ${statsBaseFull.min}) / 2</small></div>
                            <div style="font-size:10px;opacity:0.8;margin-top:2px;">Fórmula: <code>${formulaDanoArma}</code> (Mín ${statsBaseFull.min} | Máx ${statsBaseFull.max})</div>
                        </div>
                        <div class="t20-field-box" style="padding:6px 8px;">
                            <div class="lbl-t20">2. DANO MÉDIO CRÍTICO (${margArma}/x${multArma} · ${statsBaseFull.chanceCritPct}%)</div>
                            <div class="val-t20" style="color:#FACC15;font-size:14px;">${statsBaseFull.critMedio} <small style="font-size:10.5px;opacity:0.9;">= (${statsBaseFull.critMax} + ${statsBaseFull.critMin}) / 2</small></div>
                            <div style="font-size:10px;color:#FDE68A;margin-top:2px;">Fórmula Crít (p. 231): <code>${statsBaseFull.formulaCriticoStr}</code></div>
                        </div>
                        <div class="t20-field-box" style="padding:6px 8px;">
                            <div class="lbl-t20">3. DANO MÉDIO / RODADA (${qtdAtaquesArmaRodada}${infoNatBox ? '+1' : ''} ATAQUES)</div>
                            <div class="val-t20" style="color:#38BDF8;font-size:14px;">${(statsBaseFull.dprNormal + dprExtraArmaNatural).toFixed(1)}/rod <small style="font-size:10.5px;color:#FDE047;">(c/ Crít: ${(statsBaseFull.dprComCritico + dprCritExtraArmaNatural).toFixed(1)}/rod)</small></div>
                            <div style="font-size:10px;opacity:0.85;margin-top:2px;">Golpe Esperado c/ Crít: <code>${statsBaseFull.esperadoGolpeComCrit}</code> × ${qtdAtaquesArmaRodada} atq${infoNatBox ? ` + ${dprCritExtraArmaNatural} (${infoNatBox.nomeCurto})` : ''}</div>
                        </div>
                    </div>
                    <div style="overflow-x:auto;">
                        <table class="skills-table">
                            <thead>
                                <tr>
                                    <th>ATAQUES (Arma / Habilidade)</th>
                                    <th style="text-align:center;">Teste de Ataque</th>
                                    <th style="text-align:center;">Dano Normal<br><small>(Máx + Mín) / 2</small></th>
                                    <th style="text-align:center;">Crítico & Dano Crítico<br><small>(Crít Máx + Mín) / 2</small></th>
                                    <th style="text-align:center;">Dano Médio / Rodada<br><small>(Nº de Ataques)</small></th>
                                    <th style="text-align:center;">Tipo & Alcance</th>
                                    <th style="text-align:center;"></th>
                                </tr>
                            </thead>
                            <tbody>${linhasTabelaAtaques.join('')}</tbody>
                        </table>
                    </div>
                </div>

                <!-- 4. QUADRO OFICIAL DE DEFESA & ARMADURA E ESCUDO (FICHA_T20.PDF) -->
                <div class="section-box">
                    <h3>DEFESA & ARMADURA / ESCUDO</h3>
                    <div class="t20-defesa-equation">
                        <div class="t20-def-box total">
                            <div class="n">${est.defesa}</div>
                            <div class="l">DEFESA</div>
                        </div>
                        <span style="font-weight:900;font-size:16px;">= 10 +</span>
                        <div class="t20-def-box">
                            <div class="n">${modDesDef >= 0 ? '+' + modDesDef : modDesDef}</div>
                            <div class="l">Mod. DES${usaPesadaFicha ? ' (Pes.)' : ''}</div>
                        </div>
                        <span style="font-weight:900;">+</span>
                        <div class="t20-def-box">
                            <div class="n">+${bArmadura}</div>
                            <div class="l">Armadura</div>
                        </div>
                        <span style="font-weight:900;">+</span>
                        <div class="t20-def-box">
                            <div class="n">+${bEscudo}</div>
                            <div class="l">Escudo</div>
                        </div>
                        <span style="font-weight:900;">+</span>
                        <div class="t20-def-box">
                            <div class="n">${bOutrosDef >= 0 ? '+' + bOutrosDef : bOutrosDef}</div>
                            <div class="l">Outros</div>
                        </div>
                    </div>
                    <table class="skills-table">
                        <thead>
                            <tr>
                                <th>ARMADURA & ESCUDO</th>
                                <th style="text-align:center;">Defesa</th>
                                <th style="text-align:center;">Penalidade</th>
                                <th>Categoria / Propriedades</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>${estado.armadura ? estado.armadura.nome : 'Sem Armadura'}</strong></td>
                                <td style="text-align:center;font-weight:800;">+${bArmadura}</td>
                                <td style="text-align:center;">${penArmadura}</td>
                                <td><small>${estado.armadura ? (estado.armadura.subcategoria + ' — ' + estado.armadura.efeito_propriedades) : 'Permite somar DES integral na Defesa'}</small></td>
                            </tr>
                            <tr>
                                <td><strong>${estado.escudo ? estado.escudo.nome : 'Sem Escudo'}</strong></td>
                                <td style="text-align:center;font-weight:800;">+${bEscudo}</td>
                                <td style="text-align:center;">${penEscudo}</td>
                                <td><small>${estado.escudo ? estado.escudo.efeito_propriedades : 'Mão secundária livre / Duas mãos / Esotérico'}</small></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- 5. PROFICIÊNCIAS, CARACTERÍSTICAS & ECONOMIA DE AÇÕES -->
                <div class="section-box">
                    <h3>PROFICIÊNCIAS & OUTRAS CARACTERÍSTICAS</h3>
                    <div class="item-row"><strong>Proficiências Ativas:</strong> ${obterProficienciasAtivasJS(estado.classe, estado.raca, estado.poderes).join(', ')}</div>
                    <div class="item-row"><strong>Deslocamento & Tamanho:</strong> ${est.deslocamento}m (${Math.floor(est.deslocamento / 1.5)} quadrados) · Tamanho ${estado.raca.tamanho || 'Médio'} · Penalidade Total de Armadura/Escudo: <strong>${est.penArm}</strong></div>
                    <div class="item-row"><strong>Ações Padrão na Ficha:</strong> ${resDano.economiaAcoes.acoesPadrao.join(' · ')}</div>
                    <div class="item-row"><strong>Ações de Movimento / Livres:</strong> ${[...resDano.economiaAcoes.acoesMovimento, ...resDano.economiaAcoes.acoesLivres].join(' · ')}</div>
                    <div class="item-row"><strong>Reações Disponíveis na Ficha:</strong> ${resDano.economiaAcoes.reacoes.join(' · ')}</div>
                </div>
            </div>

            <!-- COLUNA DIREITA DA FICHA OFICIAL: TABELA COMPLETA DAS 30 PERÍCIAS -->
            <div>
                <div class="section-box">
                    <h3>PERÍCIAS (${(estado.pericias || []).length} Treinadas · Bônus Treino +${bonusTreino})</h3>
                    <div style="font-size:11px;margin-bottom:6px;opacity:0.85;">
                        <strong></strong> Treinada &nbsp;|&nbsp; <span style="color:#F59E0B;"></span> Somente Treinada (p. 114) &nbsp;|&nbsp; <span style="color:#93C5FD;"></span> Sofre Penalidade de Armadura (${est.penArm})
                    </div>
                    <div style="overflow-x:auto;">
                        <table class="skills-table">
                            <thead>
                                <tr>
                                    <th>PERÍCIAS</th>
                                    <th style="text-align:center;">TOTAL</th>
                                    <th style="text-align:center;">1/2 Nv</th>
                                    <th style="text-align:center;">Atrib.</th>
                                    <th style="text-align:center;">Treino</th>
                                    <th style="text-align:center;">Outros</th>
                                    <th style="text-align:center;"></th>
                                </tr>
                            </thead>
                            <tbody>${perLinhas}</tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- PÁGINA 2 DA FICHA OFICIAL: HABILIDADES DE RAÇA/ORIGEM, PODERES DE CLASSE/NÍVEL, MAGIAS & EQUIPAMENTO -->
        <div class="sheet-columns" style="margin-top:6px;">
            <div class="section-box">
                <h3>HABILIDADES DE RAÇA, ORIGEM & DEVOÇÃO</h3>
                <div class="item-row"><strong>Raça (${estado.raca.nome}):</strong> ${estado.raca.habilidades_raca}</div>
                <div class="item-row"><strong>Origem (${est.infoOrigem ? est.infoOrigem.labelOrigem : 'Sem Origem'}):</strong> ${est.infoOrigem ? est.infoOrigem.resumoRegra : ''}</div>
                <div class="item-row"><strong>Devoção (${estado.deus ? estado.deus.nome : 'Sem Divindade'}):</strong> ${estado.deus ? estado.deus.obrigacoes_restricoes : 'Sem obrigações e restrições.'}</div>
                <div class="item-row"><strong>Habilidades Fixas de ${estado.classe.nome}:</strong> ${estado.classe.habilidades_fixas}</div>
            </div>

            <div class="section-box">
                <h3>HABILIDADES DE CLASSE & PODERES (${(estado.poderes || []).length}/${Math.max(0, estado.nivel - 1)} Poderes de Nível: Nv. 2 ao ${estado.nivel})</h3>
                ${podHtml}
            </div>
        </div>

        <!-- SEÇÃO OFICIAL DE MAGIAS (PÁGINA 2 DA FICHA_T20.PDF — COM CÁLCULO DE DANO MÉDIO INDIVIDUAL E EM ÁREA MULTI-ALVO) -->
        <div class="section-box">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
                <h3 style="margin:0;border:none;padding:0;">MAGIAS (${(estado.magias || []).length} Conhecidas · ${regraCircStr})</h3>
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;font-size:11.5px;">
                    <label style="margin:0;font-weight:800;color:#FACC15;">Alvos Atingidos por Magia em Área (Cap. 4, p. 172):</label>
                    <select id="sel-ficha-alvos-area-magia" onchange="aoMudarAlvosAreaMagiaFichaJS(this.value)" style="width:auto;min-height:30px;padding:3px 8px;font-size:11.5px;background:#1E293B;color:#FEF08A;border:1px solid var(--t20-gold);">
                        <option value="0" ${(window.__ALVOS_AREA_MAGIA_OVERRIDE__ || 0) === 0 ? 'selected' : ''}>Automático pela Área (Cone/Linha = 3 alvos | Esfera 6m = 4 alvos)</option>
                        <option value="1" ${window.__ALVOS_AREA_MAGIA_OVERRIDE__ === 1 ? 'selected' : ''}>1 Alvo (Chefe Solo 1v1)</option>
                        <option value="2" ${window.__ALVOS_AREA_MAGIA_OVERRIDE__ === 2 ? 'selected' : ''}>2 Alvos (Dupla de Inimigos)</option>
                        <option value="3" ${window.__ALVOS_AREA_MAGIA_OVERRIDE__ === 3 ? 'selected' : ''}>3 Alvos (Grupo Padrão em Cone/Linha)</option>
                        <option value="4" ${window.__ALVOS_AREA_MAGIA_OVERRIDE__ === 4 ? 'selected' : ''}>4 Alvos (Esfera de 6m — Grupo Cheio)</option>
                        <option value="5" ${window.__ALVOS_AREA_MAGIA_OVERRIDE__ === 5 ? 'selected' : ''}>5 Alvos (Esfera Ampla)</option>
                        <option value="6" ${window.__ALVOS_AREA_MAGIA_OVERRIDE__ === 6 ? 'selected' : ''}>6 Alvos (Bando de Lacaios / Horda)</option>
                    </select>
                </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(185px, 1fr));gap:8px;margin-bottom:10px;">
                <div class="t20-field-box">
                    <div class="lbl-t20">ATRIBUTO-CHAVE</div>
                    <div class="val-t20">${est.infoMagia ? est.infoMagia.sigla + ' (' + est.infoMagia.desc.split('(')[0].trim() + ')' : 'INT'}</div>
                </div>
                <div class="t20-field-box">
                    <div class="lbl-t20">TESTE DE RESISTÊNCIA (CD = 10 + ½ Nv + Atrib)</div>
                    <div class="val-t20" style="color:#FDE047;">CD ${est.cdMagia}</div>
                </div>
                <div class="t20-field-box">
                    <div class="lbl-t20">LIMITE DE PM POR MAGIA</div>
                    <div class="val-t20">${resDano.strLimitePM}</div>
                </div>
                <div class="t20-field-box">
                    <div class="lbl-t20">MAIOR EXPLOSÃO (1 ALVO / EM ÁREA)</div>
                    <div class="val-t20" style="color:#4ADE80;font-size:13.5px;">1 Alvo: ${resDano.maiorDanoMagia || 0} &nbsp;|&nbsp; <span style="color:#FACC15;">Área: ${resDano.maiorDanoMagiaArea || resDano.maiorDanoMagia || 0}</span></div>
                </div>
            </div>
            ${magLinhasTabela ? `<div style="overflow-x:auto;"><table class="skills-table">
                <thead>
                    <tr>
                        <th style="text-align:center;">Círc.</th>
                        <th>Magia & Fórmula no Limite de PM</th>
                        <th>Dano Médio: 1 Alvo vs. Área Multi-Alvo<br><small>(Dano Máximo + Dano Mínimo) / 2</small></th>
                        <th>Escola</th>
                        <th>Execução & Alcance</th>
                        <th>Resistência & CD</th>
                        <th>Efeito & Aprimoramentos Oficiais</th>
                        <th style="text-align:center;"></th>
                    </tr>
                </thead>
                <tbody>${magLinhasTabela}</tbody>
            </table></div>` : '<div class="item-row">Este personagem não possui magias conhecidas na ficha.</div>'}
        </div>

        <!-- SEÇÃO OFICIAL DE EQUIPAMENTO, CARGA & TESOURO INICIAL POR NÍVEL (CAP. 3 P. 140/164 & CAP. 8 P. 334) -->
        <div class="section-box">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
                <h3 style="margin:0;border:none;padding:0;">EQUIPAMENTO, CARGA & TESOURO INICIAL DO NÍVEL ${estado.nivel} (Tabela 3-1, p. 140)</h3>
                <div style="display:flex;gap:6px;flex-wrap:wrap;font-size:12px;font-weight:800;">
                    <span class="tag" style="background:#854D0E;color:#FEF08A;">Tesouro Inicial Nv. ${estado.nivel}: T$ ${resumoArsFicha.orcamentoNivel.toLocaleString('pt-BR')}</span>
                    <span class="tag" style="background:${resumoArsFicha.dentroDoOrcamento ? '#065F46' : '#991B1B'};color:#FFF;">Gasto em Superiores/Mágicos: T$ ${resumoArsFicha.gastoTotal.toLocaleString('pt-BR')} (Saldo: T$ ${resumoArsFicha.saldoRestante.toLocaleString('pt-BR')})</span>
                    <span class="tag">Carga: ${est.cargaAtual} / ${est.cargaMax} esp.</span>
                </div>
            </div>

            <!-- PAINEL DE SELEÇÃO DE ITENS SUPERIORES, MATERIAIS ESPECIAIS E ITENS MÁGICOS -->
            <div style="background:rgba(15,23,42,0.55);border:1.5px solid var(--t20-gold);border-radius:10px;padding:12px;margin-bottom:12px;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px;">
                    <div>
                        <strong style="font-size:13px;color:#FACC15;">Forja & Arsenal de Itens Superiores e Mágicos (Cap. 3 p. 164 & Cap. 8 p. 334):</strong>
                        <div style="font-size:11px;opacity:0.85;">Selecione melhorias (1 a 4: T$ 300 a T$ 18.000), materiais especiais, encantos mágicos (T$ 18.000 a T$ 72.000) e acessórios dentro do Tesouro Inicial do Nível ${estado.nivel} (<strong>T$ ${resumoArsFicha.orcamentoNivel.toLocaleString('pt-BR')}</strong>).</div>
                    </div>
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        <button type="button" class="btn-roll-inline" style="padding:5px 10px;background:#15803D;" onclick="autoOtimizarArsenalBotaoFichaJS()">Auto-Otimizar p/ Nv. ${estado.nivel} (T$ ${resumoArsFicha.orcamentoNivel.toLocaleString('pt-BR')})</button>
                        <button type="button" class="btn-roll-inline" style="padding:5px 10px;background:#475569;" onclick="limparArsenalSuperiorMagicoFichaJS()">Zerar Melhorias (T$ 0)</button>
                    </div>
                </div>

                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));gap:10px;">
                    <div style="background:rgba(0,0,0,0.28);padding:8px;border-radius:8px;border:1px solid rgba(200,157,84,0.3);">
                        <div style="font-size:11.5px;font-weight:800;color:#FDE047;margin-bottom:5px;">1. Melhorias Superiores da Arma (Tabela 3-6, p. 164):</div>
                        ${CATALOGO_MELHORIAS_ARMA_T20.map(m => {
                            const chk = (estado.configArsenalT20 && (estado.configArsenalT20.melhoriasArma || []).includes(m.id)) ? 'checked' : '';
                            return `<label style="display:flex;align-items:center;gap:5px;font-size:11px;margin:3px 0;cursor:pointer;">
                                <input type="checkbox" ${chk} onchange="alternarMelhoriaArmaFichaJS('${m.id}', this.checked)" style="width:auto;min-height:auto;">
                                <span>${m.nome}</span>
                            </label>`;
                        }).join('')}
                        <div style="margin-top:6px;">
                            <label style="font-size:11px;font-weight:800;color:#93C5FD;">Material Especial da Arma (Tabela 3-8, p. 166):</label>
                            <select onchange="alterarSelectArsenalFichaJS('materialArma', this.value)" style="min-height:30px;font-size:11px;padding:3px 6px;margin-top:3px;">
                                ${CATALOGO_MATERIAIS_ARMA_T20.map(mat => `<option value="${mat.id}" ${(estado.configArsenalT20 && estado.configArsenalT20.materialArma === mat.id) ? 'selected' : ''}>${mat.nome}</option>`).join('')}
                            </select>
                        </div>
                    </div>

                    <div style="background:rgba(0,0,0,0.28);padding:8px;border-radius:8px;border:1px solid rgba(200,157,84,0.3);">
                        <div style="font-size:11.5px;font-weight:800;color:#E9D5FF;margin-bottom:5px;">2. Encantos Mágicos da Arma (Tabela 8-4, p. 334):</div>
                        ${CATALOGO_ENCANTOS_ARMA_T20.map(e => {
                            const chk = (estado.configArsenalT20 && (estado.configArsenalT20.encantosArma || []).includes(e.id)) ? 'checked' : '';
                            return `<label style="display:flex;align-items:center;gap:5px;font-size:11px;margin:3px 0;cursor:pointer;">
                                <input type="checkbox" ${chk} onchange="alternarEncantoArmaFichaJS('${e.id}', this.checked)" style="width:auto;min-height:auto;">
                                <span>${e.nome}</span>
                            </label>`;
                        }).join('')}
                        <div style="margin-top:6px;">
                            <label style="font-size:11px;font-weight:800;color:#A7F3D0;">3. Armadura / Escudo Superior & Mágico:</label>
                            <select onchange="alterarSelectArsenalFichaJS('upgradeArmadura', this.value)" style="min-height:30px;font-size:11px;padding:3px 6px;margin-top:3px;">
                                ${CATALOGO_UPGRADES_ARMADURA_T20.map(au => `<option value="${au.id}" ${(estado.configArsenalT20 && estado.configArsenalT20.upgradeArmadura === au.id) ? 'selected' : ''}>${au.nome}</option>`).join('')}
                            </select>
                        </div>
                        <div style="margin-top:6px;">
                            <label style="font-size:11px;font-weight:800;color:#D8B4FE;">4. Esotérico Superior (Conjuradores, p. 159/165):</label>
                            <select onchange="alterarSelectArsenalFichaJS('upgradeEsoterico', this.value)" style="min-height:30px;font-size:11px;padding:3px 6px;margin-top:3px;">
                                ${CATALOGO_ESOTERICOS_T20.map(es => `<option value="${es.id}" ${(estado.configArsenalT20 && estado.configArsenalT20.upgradeEsoterico === es.id) ? 'selected' : ''}>${es.nome}</option>`).join('')}
                            </select>
                        </div>
                    </div>

                    <div style="background:rgba(0,0,0,0.28);padding:8px;border-radius:8px;border:1px solid rgba(200,157,84,0.3);">
                        <div style="font-size:11.5px;font-weight:800;color:#67E8F9;margin-bottom:5px;">5. Acessórios Mágicos (Cap. 8, pp. 342–347):</div>
                        ${CATALOGO_ACESSORIOS_MAGICOS_T20.map(ac => {
                            const chk = (estado.configArsenalT20 && (estado.configArsenalT20.acessoriosMagicos || []).includes(ac.id)) ? 'checked' : '';
                            return `<label style="display:flex;align-items:center;gap:5px;font-size:11px;margin:3px 0;cursor:pointer;">
                                <input type="checkbox" ${chk} onchange="alternarAcessorioMagicoFichaJS('${ac.id}', this.checked)" style="width:auto;min-height:auto;">
                                <span>${ac.nome}</span>
                            </label>`;
                        }).join('')}
                    </div>
                </div>
            </div>

            <div style="overflow-x:auto;">
                <table class="skills-table">
                    <thead>
                        <tr>
                            <th>Item / Melhoria / Artefato no Inventário</th>
                            <th>Categoria</th>
                            <th>Dano / Defesa / Descrição & Efeito Oficial</th>
                            <th style="text-align:right;">Preço (T$)</th>
                            <th style="text-align:center;">Espaços</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${resumoArsFicha.itensDescritivos.map(itA => `<tr class="trained">
                            <td><strong>${itA.nome}</strong></td>
                            <td>${itA.categoria}</td>
                            <td>${itA.efeito}</td>
                            <td style="text-align:right;font-weight:800;color:#FDE047;">${itA.preco}</td>
                            <td style="text-align:center;">—</td>
                        </tr>`).join('')}
                        ${(estado.itens || []).map((it, idxIt) => `<tr>
                            <td><strong>${it.nome}</strong></td>
                            <td><span class="tag">${it.categoria}</span> <small>${it.subcategoria || ''}</small></td>
                            <td>
                                ${it.dano_ou_defesa && it.dano_ou_defesa !== '-' ? `<strong>${it.dano_ou_defesa}</strong> <small>(${it.critico_ou_penalidade || '—'})</small> · ` : ''}
                                <small style="opacity:0.9;">${it.efeito_propriedades || ''}</small>
                            </td>
                            <td style="text-align:right;white-space:nowrap;">${it.preco || '—'}</td>
                            <td style="text-align:center;font-weight:700;">
                                ${it.espacos}
                                <button type="button" class="btn-roll-inline" style="margin-left:4px;background:#7F1D1D;padding:1px 5px;" title="Remover do Inventário" onclick="removerItemInventarioFichaJS(${idxIt})"></button>
                            </td>
                        </tr>`).join('') || '<tr><td colspan="5">Inventário vazio.</td></tr>'}
                    </tbody>
                </table>
            </div>

            <!-- ENCICLOPÉDIA & ADICIONADOR RÁPIDO DE TODOS OS ITENS DO LIVRO BÁSICO T20 JdA (CAP. 3 & CAP. 8) -->
            <details class="t20-collapsible" style="margin-top:10px;margin-bottom:0;">
                <summary style="padding:9px 14px;font-size:12.5px;">
                    <span>Abrir Catálogo Completo de Itens de Tormenta 20 (${(CATALOGO_T20.itens || []).length} Armas, Armaduras, Escudos, Itens Gerais, Alquímicos, Melhorias e Mágicos)</span>
                    <span style="font-size:11px;opacity:0.85;">Clique para pesquisar e equipar ▼</span>
                </summary>
                <div class="collapsible-body">
                    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;align-items:center;">
                        <select id="filtro-cat-catalogo-itens-ficha" onchange="filtrarCatalogoCompletoItensFichaJS()" style="width:auto;min-width:230px;min-height:34px;font-size:12px;">
                            <option value="TODOS">Todas as Categorias (${(CATALOGO_T20.itens || []).length} Itens)</option>
                            <option value="Arma">Armas Simples, Marciais, Exóticas & Fogo (Cap. 3, p. 145)</option>
                            <option value="Munição">Munições (Flechas, Virotes, Balas, Pedras)</option>
                            <option value="Armadura">Armaduras Leves & Pesadas (Cap. 3, p. 152)</option>
                            <option value="Escudo">Escudos Leve & Pesado (Cap. 3, p. 154)</option>
                            <option value="Equipamento Geral">Itens Gerais: Aventura, Ferramentas, Vestuário & Esotéricos (p. 155)</option>
                            <option value="Alquímico">Alquímicos: Preparados, Catalisadores & Venenos (p. 160)</option>
                            <option value="Alimentação">Alimentação & Pratos Especiais (p. 162)</option>
                            <option value="Animais e Veículos">Animais, Montarias & Veículos (p. 162)</option>
                            <option value="Serviço e Hospedagem">Serviços, Hospedagem & Conjuração (p. 162)</option>
                            <option value="Melhoria Superior">Melhorias para Itens Superiores (Tabela 3-6, p. 164)</option>
                            <option value="Material Especial">Materiais Especiais (Tabela 3-8, p. 166)</option>
                            <option value="Encanto Mágico">Encantos para Armas, Armaduras e Escudos (Cap. 8, p. 335)</option>
                            <option value="Arma Mágica Específica">Armas Mágicas Específicas (Tabela 8-6, p. 337)</option>
                            <option value="Armadura/Escudo Específico">Armaduras & Escudos Mágicos Específicos (Tabela 8-8, p. 339)</option>
                            <option value="Poção e Pergaminho">Poções, Óleos, Granadas & Pergaminhos (Tabela 8-9, p. 340)</option>
                            <option value="Acessório Mágico">Acessórios Mágicos Menores, Médios & Maiores (p. 342)</option>
                        </select>
                        <input type="text" id="busca-catalogo-itens-ficha" oninput="filtrarCatalogoCompletoItensFichaJS()" placeholder="Filtrar item por nome, efeito, dano, preço ou propriedade..." style="flex:1;min-width:220px;min-height:34px;font-size:12px;">
                    </div>
                    <div style="max-height:420px;overflow-y:auto;border:1px solid var(--t20-border);border-radius:8px;">
                        <table class="skills-table" style="font-size:11.5px;">
                            <thead style="position:sticky;top:0;z-index:2;">
                                <tr>
                                    <th>Nome do Item</th>
                                    <th>Categoria / Subcategoria</th>
                                    <th style="text-align:center;">Dano / Defesa / Bônus</th>
                                    <th style="text-align:center;">Crítico / Pen. / Alcance</th>
                                    <th style="text-align:right;">Preço</th>
                                    <th style="text-align:center;">Espaços</th>
                                    <th>Descrição Completa & Efeito (Livro Básico JdA)</th>
                                    <th style="text-align:center;">Ação</th>
                                </tr>
                            </thead>
                            <tbody id="tbody-catalogo-completo-itens-ficha">
                                ${(CATALOGO_T20.itens || []).map(itC => `<tr class="row-cat-item-ficha" data-cat="${itC.categoria}" data-busca="${(itC.nome + ' ' + itC.categoria + ' ' + itC.subcategoria + ' ' + itC.efeito_propriedades + ' ' + itC.dano_ou_defesa).toLowerCase().replace(/"/g, '')}">
                                    <td><strong>${itC.nome}</strong></td>
                                    <td><span class="tag">${itC.categoria}</span><br><small>${itC.subcategoria || ''}</small></td>
                                    <td style="text-align:center;font-weight:800;">${itC.dano_ou_defesa || '—'}</td>
                                    <td style="text-align:center;">${itC.critico_ou_penalidade || '—'}${itC.alcance && itC.alcance !== '-' ? '<br><small>Alc: ' + itC.alcance + '</small>' : ''}</td>
                                    <td style="text-align:right;white-space:nowrap;font-weight:800;color:#FDE047;">${itC.preco}</td>
                                    <td style="text-align:center;font-weight:700;">${itC.espacos}</td>
                                    <td><small>${itC.efeito_propriedades}</small></td>
                                    <td style="text-align:center;"><button type="button" class="btn-roll-inline" onclick="adicionarOuEquiparItemCatalogoFichaJS('${itC.id_item}')">Equipar/Add</button></td>
                                </tr>`).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </details>
        </div>

        <!-- GAVETAS RETRÁTEIS DE AUDITORIA DE IA, DEEP RL E SIMULADOR DE COMBATE (MANTÉM A FICHA LIMPA!) -->
        <details class="t20-collapsible">
            <summary>
                <span>Abrir Auditoria Matemática do Score MCTS (${estado.scoreFinal.toFixed(1)} pts) & Rede Neural PUCT</span>
                <span style="font-size:11px;opacity:0.85;">Clique para expandir ▼</span>
            </summary>
            <div class="collapsible-body">
                <table class="skills-table" style="margin-bottom:12px;">
                    <thead><tr><th>Fator Avaliado pelo Algoritmo</th><th>Memória de Cálculo (Valor × Peso)</th><th style="text-align:right;">Pontos no Score</th></tr></thead>
                    <tbody>
                        ${gerarLinhasAuditoriaScoreJS(estado, est, resDano)}
                        <tr class="trained"><td colspan="2"><strong>SCORE TOTAL FINAL (RECOMPENSA MCTS Q + BÔNUS SIMULADOR)</strong></td><td style="text-align:right;font-size:14px;color:#FDE047;"><strong>${estado.scoreFinal.toFixed(1)} pts</strong></td></tr>
                    </tbody>
                </table>
                <div class="item-row"><strong>Arquitetura ML:</strong> Neural MCTS + PUCT (Policy-Value MLP com CSP Action Masking) | <strong>Vetor Normalizado x[0..7]:</strong> <code>[${codificarFichaTensorJS(estado, est, resDano).slice(0, 8).join(', ')}]</code></div>
            </div>
        </details>

        <details class="t20-collapsible" open>
            <summary>
                <span>Abrir Simulador & Orientador Estratégico de Combates (${venciveisOrdenadas.length} Ameaças Recomendadas que Você Vence + Seletor Livre das 83 Criaturas)</span>
                <span style="font-size:11px;opacity:0.85;">Guia Tático & Chance de Vitória ▼</span>
            </summary>
            <div class="collapsible-body">
                <!-- BARRA DE SELEÇÃO DE AMEAÇA, FILTRO DE RECOMENDAÇÃO E ESCALA -->
                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:10px;background:rgba(15,23,42,0.75);padding:10px 12px;border-radius:10px;border:1.5px solid var(--t20-gold);margin-bottom:12px;">
                    <div>
                        <label style="font-size:11px;font-weight:800;color:#FACC15;display:block;margin-bottom:3px;">1. Testar Qualquer Ameaça do Livro (83 Criaturas Cap. 7):</label>
                        <select id="ficha-sim-sel-criatura" onchange="atualizarOrientadorCombateFichaJS()" style="min-height:34px;font-size:12px;padding:4px 8px;">
                            ${avaliacoesCriaturasSim.map(av => {
                                const cr = av.criatura;
                                const iconeW = av.winPct >= 80 ? '' : (av.winPct >= 50 ? '' : (av.winPct >= 25 ? '' : ''));
                                return `<option value="${cr.id_ameaca}" ${cr.id_ameaca === idCriaturaGuia ? 'selected' : ''}>${iconeW} [Vitória: ${av.winPct}%] ${cr.nome} (ND ${cr.nd} · ${cr.papel} · ${cr.grupo_cap7})</option>`;
                            }).join('')}
                        </select>
                    </div>
                    <div>
                        <label style="font-size:11px;font-weight:800;color:#4ADE80;display:block;margin-bottom:3px;">2. Filtrar Recomendações de Combate na Tabela:</label>
                        <select id="ficha-sim-filtro-ameacas" onchange="atualizarOrientadorCombateFichaJS()" style="min-height:34px;font-size:12px;padding:4px 8px;">
                            <option value="RECOMENDADAS_VENCIVEIS" ${filtroAmeacasSim === 'RECOMENDADAS_VENCIVEIS' ? 'selected' : ''}>Recomendadas para Você Vencer (Vitória ≥ 50% · Ideais p/ Nv. ${estado.nivel})</option>
                            <option value="VITORIA_GARANTIDA" ${filtroAmeacasSim === 'VITORIA_GARANTIDA' ? 'selected' : ''}>Vitória Garantida / Treino Seguro (Vitória ≥ 85%)</option>
                            <option value="DESAFIOS_TATICOS" ${filtroAmeacasSim === 'DESAFIOS_TATICOS' ? 'selected' : ''}>Desafios Táticos Vencíveis c/ Estratégia (40% a 84%)</option>
                            <option value="TODAS_CAP7" ${filtroAmeacasSim === 'TODAS_CAP7' ? 'selected' : ''}>Todas as 83 Ameaças do Capítulo 7 (ND 1/4 a ND 20)</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-size:11px;font-weight:800;color:#93C5FD;display:block;margin-bottom:3px;">3. Modo de Escala do Combate:</label>
                        <select id="ficha-sim-modo-escala" onchange="atualizarOrientadorCombateFichaJS()" style="min-height:34px;font-size:12px;padding:4px 8px;">
                            <option value="DUELO_1V1" ${modoEscalaSim === 'DUELO_1V1' ? 'selected' : ''}>Duelo 1v1 Equilibrado (Cota Individual do Herói)</option>
                            <option value="FICHA_INTEGRAL_LIVRO" ${modoEscalaSim === 'FICHA_INTEGRAL_LIVRO' ? 'selected' : ''}>Ficha 100% Integral do Livro (Chefes p/ Grupo de 4)</option>
                        </select>
                    </div>
                </div>

                <!-- CARD DO ORIENTADOR & GUIA ESTRATÉGICO DE COMBATE PARA A AMEAÇA SELECIONADA -->
                ${avSelecionadaGuia && guiaTaticoAtivo ? `
                <div style="background:linear-gradient(135deg, rgba(15,23,42,0.92), rgba(30,41,59,0.95));border:2px solid ${avSelecionadaGuia.corFaixa};border-radius:10px;padding:12px 14px;margin-bottom:14px;box-shadow:0 6px 18px rgba(0,0,0,0.4);">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;border-bottom:1px solid rgba(200,157,84,0.35);padding-bottom:8px;margin-bottom:10px;">
                        <div>
                            <span style="font-size:11px;font-weight:900;color:#FACC15;text-transform:uppercase;letter-spacing:0.6px;">ORIENTADOR TÁTICO DE COMBATE — PLANO DE VITÓRIA CONTRA:</span>
                            <div style="font-size:16px;font-weight:900;color:#FFFFFF;font-family:'Cinzel',serif;">
                                ${avSelecionadaGuia.criatura.nome} <span class="tag">ND ${avSelecionadaGuia.criatura.nd} · ${avSelecionadaGuia.criatura.papel}</span> <small style="font-size:11.5px;opacity:0.8;">(${avSelecionadaGuia.criatura.grupo_cap7} · ${avSelecionadaGuia.criatura.pagina_livro_pdf})</small>
                            </div>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                            <div style="text-align:right;background:rgba(0,0,0,0.45);padding:5px 10px;border-radius:8px;border:1px solid ${avSelecionadaGuia.corFaixa};">
                                <div style="font-size:10px;color:#CBD5E1;font-weight:800;">CHANCE DE VITÓRIA ESTIMADA</div>
                                <div style="font-size:18px;font-weight:900;color:${avSelecionadaGuia.corFaixa};">${avSelecionadaGuia.winPct}% <small style="font-size:11px;">(${avSelecionadaGuia.faixaDificuldade})</small></div>
                            </div>
                            <button type="button" class="btn btn-ai" style="width:auto;margin:0;padding:8px 14px;font-size:12px;" onclick="desafiarCriaturaCap7NaArena('${avSelecionadaGuia.criatura.id_ameaca}')">
                                Testar Estratégia na Arena Visual
                            </button>
                        </div>
                    </div>

                    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(150px, 1fr));gap:6px;margin-bottom:10px;font-size:11.5px;">
                        <div class="t20-field-box"><div class="lbl-t20">DEFESA & ATAQUE</div><div class="val-t20">Def ${avSelecionadaGuia.defCriatura} · Atq +${avSelecionadaGuia.atqCriatura}</div></div>
                        <div class="t20-field-box"><div class="lbl-t20">PV & DANO/RODADA</div><div class="val-t20">${avSelecionadaGuia.pvCriaturaMax} PV · ~${avSelecionadaGuia.danoCriaturaAplicado}/rod</div></div>
                        <div class="t20-field-box"><div class="lbl-t20">RESISTÊNCIAS DA AMEAÇA</div><div class="val-t20" style="font-size:12px;">Fort +${avSelecionadaGuia.fortC} | Ref +${avSelecionadaGuia.refC} | Von +${avSelecionadaGuia.vonC}</div></div>
                        <div class="t20-field-box"><div class="lbl-t20">PONTO FRACO (EXPLORAR)</div><div class="val-t20" style="color:#4ADE80;">${avSelecionadaGuia.menorRes.nome} (${avSelecionadaGuia.menorRes.val >= 0 ? '+' + avSelecionadaGuia.menorRes.val : avSelecionadaGuia.menorRes.val})</div></div>
                        <div class="t20-field-box"><div class="lbl-t20">RITMO DO DUELO (TTK)</div><div class="val-t20" style="font-size:12px;">Você vence em ${avSelecionadaGuia.ttkHeroi}t (Suporta ${avSelecionadaGuia.ttkInimigo}t)</div></div>
                    </div>

                    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(260px, 1fr));gap:10px;font-size:12px;line-height:1.45;">
                        <div style="background:rgba(0,0,0,0.35);padding:9px 11px;border-radius:8px;border-left:3px solid #38BDF8;">
                            <strong style="color:#38BDF8;display:block;margin-bottom:4px;">1. Análise de Fraquezas & Ações da Criatura:</strong>
                            <div>${guiaTaticoAtivo.pontoFracoHTML}</div>
                            <div style="margin-top:4px;font-size:11px;opacity:0.9;"><strong>Ataques da Ficha:</strong> ${avSelecionadaGuia.criatura.ataques_e_acoes}</div>
                            ${guiaTaticoAtivo.alertas.map(al => `<div style="margin-top:4px;font-size:11px;color:#FDE047;">${al}</div>`).join('')}
                        </div>
                        <div style="background:rgba(0,0,0,0.35);padding:9px 11px;border-radius:8px;border-left:3px solid #FACC15;">
                            <strong style="color:#FACC15;display:block;margin-bottom:4px;">2. Abertura Recomendada (Turno 1 — Setup):</strong>
                            <ul style="margin:0;padding-left:16px;">
                                ${guiaTaticoAtivo.passosTurno1.map(p1 => `<li style="margin-bottom:3px;">${p1}</li>`).join('')}
                            </ul>
                        </div>
                        <div style="background:rgba(0,0,0,0.35);padding:9px 11px;border-radius:8px;border-left:3px solid #4ADE80;">
                            <strong style="color:#4ADE80;display:block;margin-bottom:4px;">3. Rotação Principal de Dano & Controle (Turnos 2+):</strong>
                            <ul style="margin:0;padding-left:16px;">
                                ${guiaTaticoAtivo.passosRotacao.map(pr => `<li style="margin-bottom:3px;">${pr}</li>`).join('')}
                            </ul>
                        </div>
                        <div style="background:rgba(0,0,0,0.35);padding:9px 11px;border-radius:8px;border-left:3px solid #C084FC;">
                            <strong style="color:#E9D5FF;display:block;margin-bottom:4px;">4. Protocolo Defensivo & Reações da Sua Ficha:</strong>
                            <ul style="margin:0;padding-left:16px;">
                                ${guiaTaticoAtivo.passosDefesa.map(pd => `<li style="margin-bottom:3px;">${pd}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                </div>` : ''}

                <!-- TABELA DE AMEAÇAS RECOMENDADAS QUE O PERSONAGEM VENCE -->
                <div style="font-size:12.5px;font-weight:900;color:#FDE047;margin-bottom:6px;">
                    Ameaças Recomendadas do Capítulo 7 (${filtroAmeacasSim === 'RECOMENDADAS_VENCIVEIS' ? 'Combates que seu personagem vence com boa margem estratégica' : 'Lista Filtrada'}):
                </div>
                <div style="overflow-x:auto;max-height:420px;overflow-y:auto;border:1px solid var(--t20-border);border-radius:8px;margin-bottom:12px;">
                    <table class="skills-table" style="margin-bottom:0;">
                        <thead style="position:sticky;top:0;z-index:2;">
                            <tr>
                                <th>Ameaça Oficial (Cap. 7)</th>
                                <th style="text-align:center;">Defesa & Atq</th>
                                <th style="text-align:center;">PV & Dano/Rod</th>
                                <th style="text-align:center;">Ponto Fraco (Explorar)</th>
                                <th style="text-align:center;">Acerto & Ritmo (TTK)</th>
                                <th style="text-align:right;">Chance Vitória</th>
                                <th>Orientação Tática Rápida</th>
                                <th style="text-align:center;">Ações</th>
                            </tr>
                        </thead>
                        <tbody>${linhasRecomendadasSimHTML}</tbody>
                    </table>
                </div>

                <!-- MATRIZ DE DECISÕES TÁTICAS DA SUA FICHA -->
                <div style="font-size:12.5px;font-weight:900;color:#93C5FD;margin-bottom:6px;">
                    Matriz de Valor Esperado (EV) das Ações da Sua Ficha:
                </div>
                <table class="skills-table">
                    <thead>
                        <tr>
                            <th>Tipo de Ação no Turno</th>
                            <th>Ação / Habilidade Avaliada</th>
                            <th style="text-align:center;">Custo PM</th>
                            <th style="text-align:center;">Chance Sucesso</th>
                            <th style="text-align:right;">Valor Esperado (EV)</th>
                            <th>Veredito & Justificativa Tática</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${sim.matrizDecisoes.map(op => `<tr${op.destaque ? ' class="trained"' : ''}><td><strong>${op.tipoAcao}</strong></td><td>${op.nomeAcao}</td><td style="text-align:center;">${op.custoPM} PM</td><td style="text-align:center;">${op.chancePct}%</td><td style="text-align:right;font-weight:700;color:#FDE047;">${op.ev}</td><td><strong>${op.veredito}</strong> — ${op.justificativa}</td></tr>`).join('')}
                    </tbody>
                </table>
            </div>
        </details>
    </div>`;

    const arvoreCompletaHTML = construirHTMLArvore(estado);

    const secFicha = document.getElementById('tab-ficha');
    if (secFicha) {
        secFicha.innerHTML = `<div id="container-ficha-principal">${fichaCompletaHTML}</div><details class="t20-collapsible"><summary><span>Abrir Árvore de Decisões do Algoritmo (CSP AC-3 + MCTS UCT)</span><span style="font-size:11px;opacity:0.85;">Clique para expandir ▼</span></summary><div class="collapsible-body" id="container-arvore-na-ficha">${arvoreCompletaHTML}</div></details>`;
    }
    const secArvore = document.getElementById('tab-arvore');
    if (secArvore) {
        secArvore.innerHTML = arvoreCompletaHTML;
    }

    // Sincroniza imediatamente a arma equipada, os seletores de aparência e os retratos da Ficha e da Arena JRPG!
    if (typeof sincronizarTodosSeletoresAparenciaFichaEArenaJS === 'function') sincronizarTodosSeletoresAparenciaFichaEArenaJS();
    if (typeof atualizarRetratoFichaPrincipalJS === 'function') atualizarRetratoFichaPrincipalJS();
    sincronizarHeroiNaArenaSemResetarInimigoJS();

    if (abaDestino) {
        mostrarAba(abaDestino);
        exibirMensagemStatus(msgBanner);
    }
}

function carregarFichaSalvaHibrido(idFicha) {
    const fd = new FormData();
    if (idFicha % 2 === 1) {
        fd.set('nome', 'Kaelen Fúria-Rubra (Salvo #' + idFicha + ')');
        fd.set('nivel', '6');
        fd.set('arquetipo', 'Dano Marcial');
        fd.set('iteracoes', '140');
        fd.set('fixar_raca', 'Minotauro');
        fd.set('fixar_classe', 'Guerreiro');
        fd.set('fixar_origem', 'Gladiador');
        fd.set('fixar_deus', 'Arsenal');
    } else {
        fd.set('nome', 'Ignis Arquimago (Salvo #' + idFicha + ')');
        fd.set('nivel', '6');
        fd.set('arquetipo', 'Conjurador Arcano');
        fd.set('iteracoes', '140');
        fd.set('fixar_raca', 'Elfo');
        fd.set('fixar_classe', 'Arcanista');
        fd.set('fixar_origem', 'Acólito');
        fd.set('fixar_deus', 'Wynna');
    }
    executarOtimizadorIAMobileOffline(fd, null);
    exibirMensagemStatus('Ficha #' + idFicha + ' carregada com sucesso!');
}


function adicionarBolhaChat(autor, htmlTexto, ehUsuario) {
    const box = document.getElementById('chat-ia-mensagens');
    if (!box) return;
    const div = document.createElement('div');
    div.style.cssText = ehUsuario
        ? 'background:rgba(30,58,138,0.65);border-right:4px solid #38BDF8;color:#F8FAFC;padding:9px 12px;border-radius:6px;margin-bottom:10px;text-align:right;'
        : 'background:rgba(69,10,10,0.65);border-left:4px solid #F59E0B;color:#F8FAFC;padding:10px 12px;border-radius:6px;margin-bottom:10px;';
    div.innerHTML = `<strong>${autor}:</strong> ${htmlTexto}`;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
}

function enviarComandoRapidoChat(textoCmd) {
    const inp = document.getElementById('chat-ia-input');
    if (inp) inp.value = textoCmd;
    mostrarAba('tab-chat');
    executarAgenteChatIA(textoCmd);
    if (inp) inp.value = '';
}

function processarMensagemChatIA(ev) {
    ev.preventDefault();
    const inp = document.getElementById('chat-ia-input');
    if (!inp || !inp.value.trim()) return;
    const msg = inp.value.trim();
    inp.value = '';
    executarAgenteChatIA(msg);
}

function executarAgenteChatIA(msg) {
    adicionarBolhaChat('Você', msg, true);
    const ml = msg.toLowerCase();

    // Garante que temos um estado de ficha carregado em memória
    if (!window.__ULTIMO_ESTADO_FICHA__) {
        const fdInit = new FormData();
        fdInit.set('nome', 'Valkir de Bielefeld');
        fdInit.set('nivel', '6');
        fdInit.set('arquetipo', 'Marcial: Duas Mãos Pesado');
        fdInit.set('iteracoes', '120');
        fdInit.set('fixar_raca', 'Humano');
        fdInit.set('fixar_classe', 'Guerreiro');
        fdInit.set('fixar_origem', 'AUTO');
        fdInit.set('fixar_deus', 'AUTO');
        executarOtimizadorIAMobileOffline(fdInit);
    }
    const st = window.__ULTIMO_ESTADO_FICHA__;

    // 1. Comandos de mudança de estilo de combate / build completa
    const estilosMap = [
        { chaves: ['haste', 'alabarda', 'pique', 'alongada'], arq: 'Marcial: Armas de Haste', classe: 'Guerreiro' },
        { chaves: ['arma e escudo', 'escudo', 'tanque', 'baluarte'], arq: 'Tanque: Arma e Escudo', classe: 'Cavaleiro' },
        { chaves: ['duas armas', 'ambidestria'], arq: 'Marcial: Duas Armas', classe: 'Caçador' },
        { chaves: ['uma mão', 'uma mao', 'duelista', 'esgrima', 'florete'], arq: 'Marcial: Uma Mão Duelista', classe: 'Bucaneiro' },
        { chaves: ['arqueiro', 'arco', 'distância', 'distancia', 'disparo'], arq: 'Marcial: Dano Arqueiro', classe: 'Caçador' },
        { chaves: ['duas mãos', 'duas maos', 'montante', 'destruidor'], arq: 'Marcial: Duas Mãos Pesado', classe: 'Guerreiro' },
        { chaves: ['feiticeiro', 'linhagem', 'carisma arcano'], arq: 'Conjurador Arcano: Feiticeiro', classe: 'Arcanista' },
        { chaves: ['bruxo', 'foco arcano'], arq: 'Conjurador Arcano: Bruxo', classe: 'Arcanista' },
        { chaves: ['arcanista', 'mago', 'conjurador arcano', 'bola de fogo'], arq: 'Conjurador Arcano: Mago', classe: 'Arcanista' },
        { chaves: ['bardo', 'eclético', 'inspiração'], arq: 'Conjurador: Bardo', classe: 'Bardo' },
        { chaves: ['druida', 'allihanna'], arq: 'Suporte Divino: Druida', classe: 'Druida' },
        { chaves: ['clérigo', 'clerigo', 'suporte divino', 'cura', 'devoto fiel'], arq: 'Suporte Divino: Clérigo', classe: 'Clérigo' }
    ];

    if (/(mude|troque|crie|faça|faca|otimize|build|estilo)/.test(ml)) {
        for (const item of estilosMap) {
            if (item.chaves.some(k => ml.includes(k))) {
                const fd = new FormData();
                fd.set('nome', st.nome);
                fd.set('nivel', String(st.nivel));
                fd.set('arquetipo', item.arq);
                fd.set('iteracoes', '140');
                fd.set('fixar_raca', 'AUTO');
                fd.set('fixar_classe', item.classe);
                fd.set('fixar_origem', 'AUTO');
                fd.set('fixar_deus', 'AUTO');
                executarOtimizadorIAMobileOffline(fd, null);
                mostrarAba('tab-chat');
                const novo = window.__ULTIMO_ESTADO_FICHA__;
                adicionarBolhaChat(
                    'Assistente IA',
                    `Pronto! Reconstruí a ficha usando o estilo <strong>${item.arq}</strong> (${novo.raca.nome} ${novo.classe.nome} Nível ${novo.nivel}).<br>` +
                    `• <strong>Arma Equipada:</strong> ${novo.arma ? novo.arma.nome : 'Nenhuma'}${novo.escudo ? ' + ' + novo.escudo.nome : ''}<br>` +
                    `• <strong>Poderes Escolhidos pelo MCTS+PUCT:</strong> ${novo.poderes.map(p => p.nome).join(', ')}<br>` +
                    `• <strong>Novo Score MCTS:</strong> ${novo.scoreFinal.toFixed(1)} pts (PV=${novo.est.pvMax}, PM=${novo.est.pmMax}, Def=${novo.est.defesa}).<br>` +
                    `Toque na aba <strong>Ficha T20</strong> ou <strong>Árvore IA</strong> para ver a ficha atualizada!`,
                    false
                );
                return;
            }
        }
    }

    // 2. Comando para alterar o Nível (ex: "Mude o nível para 10", "Suba para o nível 8")
    const mNiv = ml.match(/n[íi]vel\s*(?:para\s*)?(\d+)|para\s*o?\s*n[íi]vel\s*(\d+)/);
    if (mNiv) {
        const novoNiv = Math.max(1, Math.min(20, parseInt(mNiv[1] || mNiv[2], 10)));
        const fd = new FormData();
        fd.set('nome', st.nome);
        fd.set('nivel', String(novoNiv));
        fd.set('arquetipo', st.arquetipo || 'Marcial: Duas Mãos Pesado');
        fd.set('iteracoes', '140');
        fd.set('fixar_raca', st.raca.nome);
        fd.set('fixar_classe', st.classe.nome);
        fd.set('fixar_origem', st.origem.nome);
        fd.set('fixar_deus', st.deus ? st.deus.nome : 'Nenhum');
        executarOtimizadorIAMobileOffline(fd, null);
        mostrarAba('tab-chat');
        const novo = window.__ULTIMO_ESTADO_FICHA__;
        adicionarBolhaChat(
            'Assistente IA',
            `Atualizei <strong>${novo.nome}</strong> para o <strong>Nível ${novoNiv}</strong> e reexecutei a árvore MCTS+PUCT!<br>` +
            `• <strong>PV Máximos:</strong> ${novo.est.pvMax} (${novo.est.detPV})<br>` +
            `• <strong>PM Máximos:</strong> ${novo.est.pmMax} (${novo.est.detPM})<br>` +
            `• <strong>Poderes Atuais (${novo.poderes.length}):</strong> ${novo.poderes.map(p => p.nome).join(', ')}<br>` +
            `• <strong>Novo Score:</strong> ${novo.scoreFinal.toFixed(1)} pts.`,
            false
        );
        return;
    }

    // 3. Comando para trocar Raça ou Classe ou Deus na ficha atual
    for (const r of CATALOGO_T20.racas) {
        if (ml.includes(r.nome.toLowerCase()) && /(raça|raca|mude|troque|coloque|seja)/.test(ml)) {
            const fd = new FormData();
            fd.set('nome', st.nome); fd.set('nivel', String(st.nivel));
            fd.set('arquetipo', st.arquetipo); fd.set('iteracoes', '120');
            fd.set('fixar_raca', r.nome); fd.set('fixar_classe', st.classe.nome);
            fd.set('fixar_origem', st.origem.nome); fd.set('fixar_deus', 'AUTO');
            executarOtimizadorIAMobileOffline(fd, null);
            mostrarAba('tab-chat');
            const novo = window.__ULTIMO_ESTADO_FICHA__;
            adicionarBolhaChat('Assistente IA', `Raça alterada para <strong>${r.nome}</strong>! O CSP validou a devoção (${novo.deus ? novo.deus.nome : 'Nenhum'}) e recalculou PV=${novo.est.pvMax}, PM=${novo.est.pmMax} e Score=${novo.scoreFinal.toFixed(1)}.`, false);
            return;
        }
    }
    for (const c of CATALOGO_T20.classes) {
        if (ml.includes(c.nome.toLowerCase()) && /(classe|mude|troque|coloque|seja)/.test(ml)) {
            const fd = new FormData();
            fd.set('nome', st.nome); fd.set('nivel', String(st.nivel));
            fd.set('arquetipo', ['arcanista'].includes(c.nome.toLowerCase()) ? 'Conjurador Arcano' : (['clérigo', 'druida'].includes(c.nome.toLowerCase()) ? 'Suporte Divino' : st.arquetipo));
            fd.set('iteracoes', '120');
            fd.set('fixar_raca', st.raca.nome); fd.set('fixar_classe', c.nome);
            fd.set('fixar_origem', 'AUTO'); fd.set('fixar_deus', 'AUTO');
            executarOtimizadorIAMobileOffline(fd, null);
            mostrarAba('tab-chat');
            const novo = window.__ULTIMO_ESTADO_FICHA__;
            adicionarBolhaChat('Assistente IA', `Classe alterada para <strong>${c.nome}</strong> (${naturezaPersonagemJS(novo.classe)})! Proficiências ativas: ${obterProficienciasAtivasJS(novo.classe, novo.raca, novo.poderes).join(', ')}. Novo Score: ${novo.scoreFinal.toFixed(1)} pts.`, false);
            return;
        }
    }

    // 4. Comando para adicionar um Poder específico na ficha atual (ex: "Adicione o poder Vitalidade")
    if (/(adicione|adicionar|coloque|pegue|incluir)/.test(ml)) {
        const todosP = [...CATALOGO_T20.poderes_classe, ...CATALOGO_T20.poderes_gerais];
        const achouP = todosP.find(p => ml.includes(p.nome.toLowerCase()));
        if (achouP) {
            if (!st.poderes.some(x => x.nome === achouP.nome)) {
                st.poderes.push(achouP);
                st.est = calcularEstatisticaCompletaT20({
                    nivel: st.nivel, raca: st.raca, classe: st.classe, atrBase: st.atrBase, livres: st.livres,
                    pericias: st.pericias, poderes: st.poderes, itens: st.itens,
                    arma: st.arma, armadura: st.armadura, escudo: st.escudo
                });
                st.scoreFinal = avaliarScoreMCTSClient(st.est, st.poderes, st.magias, st.arma, st.validacoes, st.arquetipo, st.nivel, st.classe, st.itens, st.escudo);
                renderizarFichaEArvoreClientSide(st, 'tab-chat', `Poder '${achouP.nome}' adicionado à ficha!`);
                adicionarBolhaChat('Assistente IA', `Adicionei o poder <strong>${achouP.nome}</strong> (<em>${achouP.efeito_resumo}</em>) à ficha! Os status foram recalculados: PV=${st.est.pvMax}, PM=${st.est.pmMax}, Defesa=${st.est.defesa}, Score=${st.scoreFinal.toFixed(1)}.`, false);
                return;
            }
        }
        // Ou equipar uma arma mencionada
        const achouArma = CATALOGO_T20.itens.find(i => i.categoria === 'Arma' && ml.includes(i.nome.toLowerCase()));
        if (achouArma) {
            st.arma = achouArma;
            if (!st.itens.includes(achouArma)) st.itens.unshift(achouArma);
            st.est = calcularEstatisticaCompletaT20({
                nivel: st.nivel, raca: st.raca, classe: st.classe, atrBase: st.atrBase, livres: st.livres,
                pericias: st.pericias, poderes: st.poderes, itens: st.itens,
                arma: st.arma, armadura: st.armadura, escudo: st.escudo
            });
            st.scoreFinal = avaliarScoreMCTSClient(st.est, st.poderes, st.magias, st.arma, st.validacoes, st.arquetipo, st.nivel, st.classe, st.itens, st.escudo);
            renderizarFichaEArvoreClientSide(st, 'tab-chat', `Arma '${achouArma.nome}' equipada!`);
            adicionarBolhaChat('Assistente IA', `Equipei a arma <strong>${achouArma.nome}</strong> (Dano ${achouArma.dano_ou_defesa}, Crítico ${achouArma.critico_ou_penalidade}) e atualizei o cálculo de DPR na ficha!`, false);
            return;
        }
    }

    // 5. Explicação detalhada do Score e dos motivos de cada escolha da Ficha Atual
    const resDano = calcularResumoDanoJS(st.nivel, st.classe, st.est, st.poderes, st.itens, st.arma, st.escudo, st.magias);
    const explicacoesPoderes = (st.poderes || []).map((p, idx) =>
        `<li><strong>${idx + 1}. ${p.nome}</strong> (${p.eh_poder_classe ? 'Classe' : p.categoria_ou_classe}): escolhido porque <em>${p.efeito_resumo}</em>, cumprindo o pré-requisito (<code>${p.pre_requisitos}</code>) e maximizando o ganho marginal Q/N no estilo <strong>${st.arquetipo}</strong>.</li>`
    ).join('');

    adicionarBolhaChat(
        'Assistente IA',
        `Aqui está a análise completa das decisões e do Score de <strong>${st.nome}</strong> (${st.raca.nome} ${st.classe.nome} Nv ${st.nivel} — <strong>${st.arquetipo}</strong>):<br><br>` +
        `<strong>1. Por que o Score chegou a ${st.scoreFinal.toFixed(1)} pts?</strong><br>` +
        `• <strong>Capacidade Ofensiva:</strong> ${resDano.descDanoArma}<br>` +
        (resDano.danoMedioRaio > 0 ? `• <strong>Sustentação Mágica (0 PM):</strong> ${resDano.descRaio}<br>` : '') +
        (resDano.melhorMagiaInfo ? `• <strong>Explosão Mágica no Limite de PM (${resDano.limitePM} PM):</strong> ${resDano.melhorMagiaInfo.nome} causa ${resDano.melhorMagiaInfo.info.formulaFinal} (média ${resDano.melhorMagiaInfo.info.danoMedio})<br>` : '') +
        `• <strong>Sobrevivência & Recursos:</strong> PV=${st.est.pvMax}, PM=${st.est.pmMax}, Defesa=${st.est.defesa}, Proficiências: ${obterProficienciasAtivasJS(st.classe, st.raca, st.poderes).join(', ')}.<br><br>` +
        `<strong>2. Motivo de Cada Escolha na Árvore (MCTS + PUCT + CSP):</strong>` +
        `<ul style="margin:6px 0 0 18px;padding:0;">${explicacoesPoderes}</ul>`,
        false
    );
}


// ==============================================================================
// ARENA VISUAL DE COMBATE, ROLADOR DINÂMICO DE DADOS 3D/SVG & RL CAIXA-PRETA
// ==============================================================================

let __ARENA_STATE__ = null;
let __DICE_ANIM_TIMER__ = null;

function criarSVGPoligonoDado(faces, valorTexto, corFundo, corBorda, subtitulo) {
    let shape = '';
    if (faces === 20) {
        shape = `<polygon points="42,4 78,24 78,60 42,80 6,60 6,24" fill="${corFundo}" stroke="${corBorda}" stroke-width="2.5"/>
                 <polygon points="42,14 68,56 16,56" fill="none" stroke="rgba(255,255,255,0.35)" stroke-width="1.4"/>
                 <line x1="42" y1="4" x2="42" y2="14" stroke="rgba(255,255,255,0.35)" stroke-width="1.4"/>
                 <line x1="78" y1="60" x2="68" y2="56" stroke="rgba(255,255,255,0.35)" stroke-width="1.4"/>
                 <line x1="6" y1="60" x2="16" y2="56" stroke="rgba(255,255,255,0.35)" stroke-width="1.4"/>`;
    } else if (faces === 12) {
        shape = `<polygon points="42,5 72,18 79,49 58,76 26,76 5,49 12,18" fill="${corFundo}" stroke="${corBorda}" stroke-width="2.5"/>
                 <polygon points="42,20 60,34 53,56 31,56 24,34" fill="none" stroke="rgba(255,255,255,0.3)" stroke-width="1.3"/>`;
    } else if (faces === 10) {
        shape = `<polygon points="42,4 78,42 42,80 6,42" fill="${corFundo}" stroke="${corBorda}" stroke-width="2.5"/>
                 <line x1="42" y1="4" x2="42" y2="80" stroke="rgba(255,255,255,0.3)" stroke-width="1.3"/>`;
    } else if (faces === 8) {
        shape = `<polygon points="42,5 76,42 42,79 8,42" fill="${corFundo}" stroke="${corBorda}" stroke-width="2.5"/>
                 <line x1="8" y1="42" x2="76" y2="42" stroke="rgba(255,255,255,0.35)" stroke-width="1.4"/>`;
    } else if (faces === 4) {
        shape = `<polygon points="42,6 78,74 6,74" fill="${corFundo}" stroke="${corBorda}" stroke-width="2.5"/>`;
    } else {
        shape = `<rect x="10" y="10" width="64" height="64" rx="12" fill="${corFundo}" stroke="${corBorda}" stroke-width="2.5"/>
                 <rect x="18" y="18" width="48" height="48" rx="6" fill="none" stroke="rgba(255,255,255,0.22)" stroke-width="1.2"/>`;
    }
    return `
        <svg width="84" height="84" viewBox="0 0 84 84" xmlns="http://www.w3.org/2000/svg">
            ${shape}
            <text x="42" y="48" text-anchor="middle" font-size="22" font-weight="900" fill="#FFFFFF" style="text-shadow:0 2px 4px rgba(0,0,0,0.85);">${valorTexto}</text>
            <text x="42" y="70" text-anchor="middle" font-size="9.5" font-weight="700" fill="#FDE68A">d${faces}</text>
        </svg>
        <div style="font-size:11px;font-weight:700;color:#E2E8F0;margin-top:2px;text-align:center;">${subtitulo || ('d' + faces)}</div>
    `;
}

function animarBandejaDadosVisual(listaDados, textoFormulaFinal, tituloBanner) {
    const tray = document.getElementById('dice-tray-visual');
    const mathBox = document.getElementById('dice-math-breakdown');
    const banner = document.getElementById('dice-banner-titulo');
    if (!tray || !mathBox) return;
    if (banner && tituloBanner) banner.innerHTML = tituloBanner;

    if (__DICE_ANIM_TIMER__) {
        clearInterval(__DICE_ANIM_TIMER__);
        __DICE_ANIM_TIMER__ = null;
    }

    // Fase 1: Mostra dados girando (.rolling) com números aleatórios e destaca 2d20 (Melhor Selecionado vs Descartado)
    let frames = 0;
    const renderFrame = (finalizado) => {
        tray.innerHTML = listaDados.map((d, idx) => {
            const valMostrado = finalizado ? d.valor : (Math.floor(Math.random() * d.faces) + 1);
            const clsExtra = finalizado
                ? (d.critico ? 'crit-hit' : (d.falhaCritica ? 'fumble-miss' : ''))
                : 'rolling';
            const ehDescartado = finalizado && Boolean(d.descartado);
            const ehMelhor2d20 = finalizado && Boolean(d.melhorSelecionado);
            const corFundo = ehDescartado ? '#334155' : (ehMelhor2d20 ? '#15803D' : (d.critico ? '#B45309' : (d.falhaCritica ? '#7F1D1D' : (d.cor || '#8B1E24'))));
            const corBorda = ehDescartado ? '#64748B' : (ehMelhor2d20 ? '#4ADE80' : (d.critico ? '#FACC15' : (d.falhaCritica ? '#EF4444' : '#C89D54')));
            const styleWrap = ehDescartado
                ? 'opacity:0.46;filter:grayscale(0.75);transform:scale(0.90);position:relative;'
                : (ehMelhor2d20 ? 'box-shadow:0 0 14px rgba(74,222,128,0.65);border-radius:10px;padding:2px;position:relative;' : 'position:relative;');
            const badgeExtra = ehDescartado
                ? '<div style="font-size:9.5px;font-weight:900;color:#FCA5A5;background:rgba(127,29,29,0.92);padding:1px 5px;border-radius:4px;margin-top:2px;text-decoration:line-through;">DESCARTADO (NÃO SOMA)</div>'
                : (ehMelhor2d20 ? '<div style="font-size:9.5px;font-weight:900;color:#ECFDF5;background:#15803D;padding:1px 6px;border-radius:4px;margin-top:2px;">MELHOR d20 (USADO)</div>' : '');
            return `<div class="die-3d-wrapper ${clsExtra}" id="die-vis-${idx}" style="${styleWrap}">
                ${criarSVGPoligonoDado(d.faces, valMostrado, corFundo, corBorda, d.label)}
                ${badgeExtra}
            </div>`;
        }).join('');
        if (finalizado) {
            mathBox.innerHTML = textoFormulaFinal;
        } else {
            mathBox.innerHTML = 'Rolando os dados na mesa...';
        }
    };

    tocarSomJRPG('DADOS');
    renderFrame(false);
    __DICE_ANIM_TIMER__ = setInterval(() => {
        frames++;
        if (frames >= 5) {
            clearInterval(__DICE_ANIM_TIMER__);
            __DICE_ANIM_TIMER__ = null;
            renderFrame(true);
        } else {
            renderFrame(false);
        }
    }, 65);
}

function rolarDadosLivresMesa(formula, descricao) {
    const fStr = (formula || '1d20').trim();
    const m = fStr.match(/(\d+)d(\d+)/i);
    const qtd = m ? Math.min(12, parseInt(m[1], 10)) : 1;
    const faces = m ? parseInt(m[2], 10) : 20;
    const ehPiorD20 = /pior|kl1|desvantagem/i.test(fStr) || /pior|desvantagem/i.test(descricao || '');
    const ehRolagemMultiplosD20 = (faces === 20 && qtd >= 2);

    const valores = [];
    for (let i = 0; i < qtd; i++) {
        valores.push(Math.floor(Math.random() * faces) + 1);
    }

    if (ehRolagemMultiplosD20) {
        // REGRA OFICIAL TORMENTA20: Rolagens com 2d20 (Preciso, Concentração de Combate, Sortudo) NUNCA somam os d20!
        // Rola os dados e seleciona estritamente o MELHOR resultado (ou o pior se penalidade).
        const escolhido = ehPiorD20 ? Math.min(...valores) : Math.max(...valores);
        let jaMarcouEscolhido = false;
        const dados = valores.map((v, i) => {
            const usarEste = (!jaMarcouEscolhido && v === escolhido);
            if (usarEste) jaMarcouEscolhido = true;
            return {
                faces: 20,
                valor: v,
                critico: usarEste && v === 20,
                falhaCritica: usarEste && v === 1,
                melhorSelecionado: usarEste,
                descartado: !usarEste,
                cor: usarEste ? '#15803D' : '#334155',
                label: usarEste ? `${i + 1}º d20: ${v} (Escolhido)` : `${i + 1}º d20: ${v} (Descartado)`
            };
        });
        const listaStr = valores.map(v => `[${v}]`).join(' vs ');
        animarBandejaDadosVisual(
            dados,
            `<strong>${qtd}d20 — Seleciona o ${ehPiorD20 ? 'Pior' : 'MELHOR'} Resultado (Regra T20)</strong> (${descricao}): Rolados ${listaStr} <strong>Resultado Selecionado = <span style="font-size:18px;color:#4ADE80;">${escolhido}</span></strong> <span style="color:#FCA5A5;font-size:12px;">(Os d20 nunca são somados!)</span>`,
            `Rolagem 2d20 (Melhor Resultado): <strong>${descricao}</strong>`
        );
        return;
    }

    const dados = [];
    let soma = 0;
    for (let i = 0; i < qtd; i++) {
        const v = valores[i];
        soma += v;
        dados.push({
            faces,
            valor: v,
            critico: (faces === 20 && v === 20) || (faces !== 20 && v === faces),
            falhaCritica: (faces === 20 && v === 1),
            cor: faces === 20 ? '#8B1E24' : '#1E3A8A',
            label: `${ i + 1 }º d${faces}: ${v}`
        });
    }
    const valsStr = dados.map(d => `[${d.valor}]`).join(' + ');
    animarBandejaDadosVisual(
        dados,
        `Resultado de <strong>${formula}</strong> (${descricao}): ${valsStr} = <span style="font-size:17px;color:#4ADE80;">${soma}</span>`,
        `Rolagem Livre: <strong>${descricao} (${formula})</strong>`
    );
}

function garantirEstadoFichaParaArena() {
    if (!window.__ULTIMO_ESTADO_FICHA__) {
        const fd = new FormData();
        fd.set('nome', 'Kaelen Fúria-Rubra');
        fd.set('nivel', '6');
        fd.set('arquetipo', 'Marcial: Duas Mãos Pesado');
        fd.set('iteracoes', '90');
        fd.set('fixar_raca', 'Minotauro');
        fd.set('fixar_classe', 'Guerreiro');
        fd.set('fixar_origem', 'Gladiador');
        fd.set('fixar_deus', 'Arsenal');
        executarOtimizadorIAMobileOffline(fd, null);
    }
    return window.__ULTIMO_ESTADO_FICHA__;
}

function inicializarArenaVisualSeNecessario() {
    if (!__ARENA_STATE__) {
        reiniciarCombateArenaVisual();
    } else {
        sincronizarHeroiNaArenaSemResetarInimigoJS();
    }
}

function obterCriaturaCap7ArenaJS(idOuAuto, ndFallback, papelFallback) {
    const lista = (CATALOGO_T20 && CATALOGO_T20.ameacas_cap7) ? CATALOGO_T20.ameacas_cap7 : [];
    if (idOuAuto && idOuAuto !== 'AUTO') {
        const achada = lista.find(c => c.id_ameaca === idOuAuto || c.nome === idOuAuto);
        if (achada) return achada;
    }
    if (lista.length > 0) {
        const poolPapel = lista.filter(c => (c.papel || '').toLowerCase() === (papelFallback || 'Solo').toLowerCase());
        const pool = poolPapel.length ? poolPapel : lista;
        let melhor = pool[0];
        let menorDist = 999;
        for (const c of pool) {
            const d = Math.abs((c.nd_numerico || 1) - ndFallback);
            if (d < menorDist) {
                menorDist = d;
                melhor = c;
            }
        }
        return melhor;
    }
    return null;
}

function filtrarCriaturasArenaCap7JS() {
    const selGrupo = document.getElementById('arena-sel-grupo-cap7');
    const selCriatura = document.getElementById('arena-sel-criatura-cap7');
    if (!selGrupo || !selCriatura) return;
    const g = selGrupo.value;
    if (g === 'TABELA_ND') {
        selCriatura.value = 'AUTO';
        reiniciarCombateArenaVisual();
        return;
    }
    let primeiroVisivel = null;
    for (const opt of Array.from(selCriatura.options)) {
        if (opt.value === 'AUTO') {
            opt.hidden = false;
            continue;
        }
        const og = opt.getAttribute('data-grupo') || '';
        const vis = (g === 'TODOS' || og === g);
        opt.hidden = !vis;
        if (vis && !primeiroVisivel) primeiroVisivel = opt.value;
    }
    if (primeiroVisivel && (selCriatura.value === 'AUTO' || selCriatura.selectedOptions[0]?.hidden)) {
        selCriatura.value = primeiroVisivel;
    }
    reiniciarCombateArenaVisual();
}

function aoSelecionarCriaturaCap7ArenaJS() {
    const selCriatura = document.getElementById('arena-sel-criatura-cap7');
    const selNd = document.getElementById('arena-sel-nd');
    const selPapel = document.getElementById('arena-sel-papel');
    if (selCriatura && selCriatura.value !== 'AUTO') {
        const c = obterCriaturaCap7ArenaJS(selCriatura.value, 6, 'Solo');
        if (c) {
            if (selNd) {
                const ndInt = Math.max(1, Math.min(20, Math.round(c.nd_numerico || 1)));
                for (const op of Array.from(selNd.options)) {
                    if (parseInt(op.value, 10) === ndInt) {
                        selNd.value = String(ndInt);
                        break;
                    }
                }
            }
            if (selPapel) selPapel.value = c.papel || 'Solo';
        }
    }
    reiniciarCombateArenaVisual();
}

function filtrarTabelaBestiarioCap7JS() {
    const selG = document.getElementById('filtro-grupo-bestiario-cap7');
    const inpB = document.getElementById('busca-bestiario-cap7');
    const g = selG ? selG.value : 'TODOS';
    const q = inpB ? inpB.value.trim().toLowerCase() : '';
    const rows = document.querySelectorAll('#tbody-bestiario-cap7 .row-cap7');
    rows.forEach(tr => {
        const tg = tr.getAttribute('data-grupo') || '';
        const tb = tr.getAttribute('data-busca') || '';
        const okG = (g === 'TODOS' || tg === g);
        const okQ = (!q || tb.includes(q));
        tr.style.display = (okG && okQ) ? '' : 'none';
    });
}

function desafiarCriaturaCap7NaArena(idAmeaca) {
    mostrarAba('tab-arena');
    const selGrupo = document.getElementById('arena-sel-grupo-cap7');
    const selCriatura = document.getElementById('arena-sel-criatura-cap7');
    if (selGrupo) selGrupo.value = 'TODOS';
    if (selCriatura) {
        for (const opt of Array.from(selCriatura.options)) opt.hidden = false;
        selCriatura.value = idAmeaca;
    }
    aoSelecionarCriaturaCap7ArenaJS();
}

// ==============================================================================
// MOTOR DE AÇÕES DA FICHA DA CRIATURA (SOPRO, MAGIAS, MULTI-ATAQUES, VENENO, OLHAR, CURA ACELERADA)
// ==============================================================================
function extrairRepertorioAcoesCriaturaJS(priv) {
    const acoes = [];
    const atqTxt = priv.ataquesResumo || 'Ataque padrão';
    const habTxt = priv.habilidadesResumo || '';
    const textoCompleto = `${atqTxt} | ${habTxt}`;
    const cd = priv.cdEfeito || (14 + Math.round(parseFloat(priv.ndTexto) || 4));
    const bAtq = priv.ataque || 10;
    const dMed = priv.danoMedio || 12;

    // 1. Ataque Padrão / Multi-Ataque Principal da Ficha (com detecção de Disparo, Ácido ou Dilacerar)
    const nomeGolpePrincipal = atqTxt.split(';')[0].trim() || `Agredir (${priv.nomeCriatura})`;
    const ehDisparoBase = /arco|besta|mosquete|azagaia/i.test(nomeGolpePrincipal);
    const ehMultiMordida = /5 mordidas|dilacerar|frenesi|ataque em bando|assassinar/i.test(textoCompleto);
    acoes.push({
        id: 'CRIATURA_ATAQUE_PRINCIPAL',
        tipo: 'ATAQUE_FISICO',
        categoria: 'Agredir / Multi-Ataque da Ficha',
        nome: nomeGolpePrincipal,
        icone: ehDisparoBase ? '' : (ehMultiMordida ? '' : ''),
        efeitoAnimacao: ehDisparoBase ? 'ANIM_AMEACA_ESPINHOS_ARTILHARIA' : (ehMultiMordida ? 'ANIM_AMEACA_FURIA_DILACERAR' : 'ANIM_AMEACA_GARRAS_MORDIDA'),
        bonusAtaque: bAtq,
        danoBase: dMed,
        temVeneno: /veneno|peçonha|doença/i.test(textoCompleto),
        temDilacerar: /dilacerar|constrição|bote|marrada/i.test(textoCompleto),
        cdSecundaria: cd,
        descricao: `Executa a rotina marcial oficial da ficha (${nomeGolpePrincipal}).`
    });

    // 2. Sopro / Arma de Sopro / Espinhos / Arsenal de Engenhocas / Jato Elemental
    if (/sopro|cospe-chamas|espinhos|arsenal de engenhocas|caixa com pregos|aura de calor|jato de|cuspe venenoso|mau cheiro|fumos tóxicos/i.test(textoCompleto)) {
        const ehEspinhos = /espinhos|caixa com pregos|balestra/i.test(textoCompleto);
        const ehGelo = /frio|gelo|glacioll|uivantes/i.test(textoCompleto);
        const ehAcidoGas = /ácido|acido|gás|gas|venenoso|mau cheiro|fumos/i.test(textoCompleto);
        const ehRaio = /elétric|eletric|relâmpago|trovao|canhão/i.test(textoCompleto);
        const elem = ehEspinhos ? 'Perfuração' : (ehGelo ? 'Frio' : (ehAcidoGas ? 'Ácido/Veneno' : (ehRaio ? 'Eletricidade' : 'Fogo')));
        const animSopro = ehEspinhos ? 'ANIM_AMEACA_ESPINHOS_ARTILHARIA'
            : ((ehGelo || ehRaio) ? 'ANIM_AMEACA_SOPRO_GELO_RAIO'
            : (ehAcidoGas ? 'ANIM_AMEACA_SOPRO_ACIDO_GAS' : 'ANIM_AMEACA_SOPRO_FOGO'));
        const mSopro = textoCompleto.match(/(Sopro[^;|]*|Cospe-chamas[^;|]*|Espinhos[^;|]*|Arsenal de Engenhocas[^;|]*|Aura de Calor[^;|]*|Jato de[^;|]*|Cuspe Venenoso[^;|]*|Mau Cheiro[^;|]*|Fumos Tóxicos[^;|]*)/i);
        const tituloSopro = mSopro ? mSopro[1].trim() : `Sopro Elemental de ${elem}`;
        acoes.push({
            id: 'CRIATURA_SOPRO_AREA',
            tipo: 'EFEITO_RESISTENCIA',
            periciaResistencia: ehAcidoGas ? 'Fortitude' : 'Reflexos',
            categoria: ehEspinhos ? 'Disparo Especial de Espinhos / Artilharia' : 'Sopro / Explosão de Área',
            nome: tituloSopro,
            icone: ehEspinhos ? '' : (ehGelo ? '' : (ehRaio ? '' : (ehAcidoGas ? '' : ''))),
            efeitoAnimacao: animSopro,
            cd: cd,
            danoBase: Math.round(dMed * 1.45),
            elemento: elem,
            reduzMetade: true,
            descricao: `Dispara ${tituloSopro} (Animação exclusiva: ${animSopro} · CD ${cd}).`
        });
    }

    // 3. Magias Conhecidas e Poderes Sobrenaturais (Necromancia, Drenar Sangue, Relâmpago, Bola de Fogo)
    if (/magia|círculo|relâmpago|bola de fogo|ferver sangue|toque vampírico|assassino fantasmagórico|enxame de pestes|drenar sangue|toque drenante|presença majestosa/i.test(textoCompleto)) {
        const ehNecroDreno = /ferver sangue|toque vampírico|drenar sangue|toque drenante|assassino fantasmagórico|necromancia|presença majestosa/i.test(textoCompleto);
        const ehRaioMag = /relâmpago|toque chocante/i.test(textoCompleto);
        let nomeMagiaCriatura = ehNecroDreno ? 'Drenar Vitalidade / Magia Necromântica' : (ehRaioMag ? 'Magia Acelerada: Relâmpago' : 'Magia: Evocação Arcana / Bola de Fogo');
        let resAlvo = ehNecroDreno ? 'Fortitude' : 'Reflexos';
        let animMag = ehNecroDreno ? 'ANIM_AMEACA_DRENAR_NECROMANCIA' : (ehRaioMag ? 'ANIM_AMEACA_SOPRO_GELO_RAIO' : 'ANIM_AMEACA_SOPRO_FOGO');
        acoes.push({
            id: 'CRIATURA_MAGIA',
            tipo: 'EFEITO_RESISTENCIA',
            periciaResistencia: resAlvo,
            categoria: 'Conjuração / Poder Sobrenatural',
            nome: `${nomeMagiaCriatura} (${resAlvo} CD ${cd})`,
            icone: ehNecroDreno ? '' : (ehRaioMag ? '' : ''),
            efeitoAnimacao: animMag,
            cd: cd,
            danoBase: Math.round(dMed * 1.35),
            elemento: ehNecroDreno ? 'Trevas' : 'Mágico',
            reduzMetade: true,
            drenaVida: ehNecroDreno,
            descricao: `A ameaça executa ${nomeMagiaCriatura} com animação única (${animMag})!`
        });
    }

    // 4. Habilidades Especiais de Controle: Olhar Petrificante, Teia/Constrição, Insanidade da Tormenta/Terror
    if (/olhar|apavorar|insanidade|aura aterradora|teia|constrição|agarrar aprimorado|tentáculos|veneno|doença/i.test(textoCompleto)) {
        const ehOlhar = /olhar/i.test(textoCompleto);
        const ehMedo = /apavorar|insanidade|aura aterradora/i.test(textoCompleto);
        const ehTeiaConst = /teia|constrição|agarrar aprimorado|tentáculos/i.test(textoCompleto);
        const resHab = ehMedo ? 'Vontade' : (ehTeiaConst || ehOlhar ? 'Reflexos' : 'Fortitude');
        const nmHab = ehOlhar ? 'Olhar Petrificante / Atordoante'
            : (ehMedo ? 'Insanidade da Tormenta / Aura Aterradora'
            : (ehTeiaConst ? 'Teia Prendedora / Constrição Tentacular' : 'Injeção de Peçonha Letal'));
        const animHab = ehOlhar ? 'ANIM_AMEACA_OLHAR_PETRIFICANTE'
            : (ehMedo ? 'ANIM_AMEACA_INSANIDADE_TERROR'
            : (ehTeiaConst ? 'ANIM_AMEACA_TEIA_CONSTRICAO' : 'ANIM_AMEACA_SOPRO_ACIDO_GAS'));
        acoes.push({
            id: 'CRIATURA_HABILIDADE_ESPECIAL',
            tipo: 'EFEITO_RESISTENCIA',
            periciaResistencia: resHab,
            categoria: 'Habilidade Especial Única da Ficha',
            nome: `${nmHab} (${resHab} CD ${cd})`,
            icone: ehOlhar ? '' : (ehMedo ? '' : (ehTeiaConst ? '' : '')),
            efeitoAnimacao: animHab,
            cd: cd,
            danoBase: Math.round(dMed * 1.05),
            condicaoAplicada: ehOlhar ? 'Atordoado/Petrificado' : (ehMedo ? 'Abalado/Insano' : (ehTeiaConst ? 'Agarrado/Enredado' : 'Envenenado')),
            reduzMetade: true,
            descricao: `Executa a habilidade especial ${nmHab} com animação exclusiva (${animHab})!`
        });
    }

    // 5. Investida Especial, Marrada, Bote Aéreo, Golpe Avassalador, Passar por Cima ou Comando Tático
    const ehComando = /ordens|formação invencível|açoitar escravos|tropas duyshidakk|guardas esqueletos|ira dracônica/i.test(textoCompleto);
    const mManobra = textoCompleto.match(/(Marrada|Bote|Golpe Avassalador|Passar por Cima|Derrubar|Quebrar|Fúria|Frenesi Insano|Cortar Cabeças)/i);
    const nomeInvestida = ehComando
        ? 'Comando de Guerra / Ira & Invocação'
        : (mManobra ? `${mManobra[1]} Brutal (${priv.nomeCriatura})` : `Investida Esmagadora (${atqTxt.split('(')[0].trim()})`);
    acoes.push({
        id: 'CRIATURA_INVESTIDA_BRUTAL',
        tipo: 'ATAQUE_FISICO',
        categoria: ehComando ? 'Comando Tático / Aura de Guerra' : 'Manobra Especial / Investida Brutal',
        nome: nomeInvestida,
        icone: ehComando ? '' : '',
        efeitoAnimacao: ehComando ? 'ANIM_AMEACA_COMANDO_INVOCACAO' : 'ANIM_AMEACA_INVESTIDA_ESMAGAMENTO',
        bonusAtaque: bAtq + 2,
        danoBase: Math.round(dMed * 1.25),
        temVeneno: false,
        temDilacerar: true,
        cdSecundaria: cd,
        descricao: `Executa ${nomeInvestida} com animação especial exclusiva!`
    });

    return acoes;
}

function reiniciarCombateArenaVisual() {
    const st = garantirEstadoFichaParaArena();
    const selNd = document.getElementById('arena-sel-nd');
    const selPapel = document.getElementById('arena-sel-papel');
    const selCriatura = document.getElementById('arena-sel-criatura-cap7');
    const selGrupo = document.getElementById('arena-sel-grupo-cap7');
    const idCriaturaSel = (selGrupo && selGrupo.value === 'TABELA_ND') ? 'AUTO' : (selCriatura ? selCriatura.value : 'AUTO');
    const ndBase = selNd ? parseInt(selNd.value, 10) : st.nivel;
    const papelBase = selPapel ? selPapel.value : 'Solo';
    const criaturaCap7 = (idCriaturaSel !== 'AUTO') ? obterCriaturaCap7ArenaJS(idCriaturaSel, ndBase, papelBase) : obterCriaturaCap7ArenaJS('AUTO', ndBase, papelBase);
    const usarFichaCap7 = Boolean(criaturaCap7 && (!selGrupo || selGrupo.value !== 'TABELA_ND'));
    const nd = usarFichaCap7 ? Math.max(1, Math.round(criaturaCap7.nd_numerico || ndBase)) : ndBase;
    const papel = usarFichaCap7 ? (criaturaCap7.papel || papelBase) : papelBase;
    const ameacaOculta = obterAmeacaOficialJS(nd, papel);
    const pvOficial = usarFichaCap7 ? criaturaCap7.pv : ameacaOculta.pv;
    const danoOficial = usarFichaCap7 ? criaturaCap7.dano_medio : ameacaOculta.dano_medio;
    const deltaNDArena = nd - (st.nivel || 6);
    // Estatísticas 100% fiéis ao livro na Arena — ZERO redução de PV, Dano, Defesa ou Ataque!
    const fatorPVArena = 1.0;
    const fatorDanoArena = 1.0;
    const pvCriaturaMax = Math.max(1, Math.round(pvOficial));
    const danoCriaturaBase = Math.max(1, Math.round(danoOficial));

    const temReflexosCombate = (st.poderes || []).some(p => (p.nome || '').toLowerCase() === 'reflexos de combate');

    const privObj = {
        idAmeaca: usarFichaCap7 ? criaturaCap7.id_ameaca : ('ND_' + nd),
        nomeCriatura: usarFichaCap7 ? criaturaCap7.nome : (`Ameaça ${papel} ND ${nd}`),
        grupoCap7: usarFichaCap7 ? criaturaCap7.grupo_cap7 : 'Tabela p. 323',
        ndTexto: usarFichaCap7 ? criaturaCap7.nd : String(nd),
        tipoTamanho: usarFichaCap7 ? criaturaCap7.tipo_nivel_tamanho : `${papel} · ${ameacaOculta.patamar}`,
        paginaRef: usarFichaCap7 ? criaturaCap7.pagina_livro_pdf : 'Livro p. 323 / PDF p. 329',
        ataquesResumo: usarFichaCap7 ? criaturaCap7.ataques_e_acoes : 'Ataque padrão de ameaça',
        habilidadesResumo: usarFichaCap7 ? criaturaCap7.habilidades_e_resistencias : 'Estatísticas médias da Tabela de Ameaças',
        iniciativaOficial: usarFichaCap7 ? criaturaCap7.iniciativa : (Math.floor(nd / 2) + (nd <= 6 ? 2 : 4) + 1),
        patamar: ameacaOculta.patamar,
        defesa: usarFichaCap7 ? criaturaCap7.defesa : ameacaOculta.defesa,
        ataque: usarFichaCap7 ? criaturaCap7.bonus_ataque : ameacaOculta.bonus_ataque,
        danoMedio: danoCriaturaBase,
        resForte: usarFichaCap7 ? Math.max(criaturaCap7.fortitude, criaturaCap7.reflexos, criaturaCap7.vontade) : ameacaOculta.res_forte,
        resMedia: usarFichaCap7 ? criaturaCap7.reflexos : ameacaOculta.res_media,
        resFraca: usarFichaCap7 ? Math.min(criaturaCap7.fortitude, criaturaCap7.reflexos, criaturaCap7.vontade) : ameacaOculta.res_fraca,
        fortitude: usarFichaCap7 ? criaturaCap7.fortitude : ameacaOculta.res_forte,
        reflexos: usarFichaCap7 ? criaturaCap7.reflexos : ameacaOculta.res_media,
        vontade: usarFichaCap7 ? criaturaCap7.vontade : ameacaOculta.res_fraca,
        cdEfeito: usarFichaCap7 ? criaturaCap7.cd_efeito : ameacaOculta.cd_efeito,
        pvOficialGrupo4: pvOficial,
        pvAtual: pvCriaturaMax,
        pvMax: pvCriaturaMax
    };
    privObj.repertorioAcoes = extrairRepertorioAcoesCriaturaJS(privObj);

    __ARENA_STATE__ = {
        turno: 1,
        faseTurno: 'TURNO_JOGADOR', // 'TURNO_JOGADOR' | 'REACAO_JOGADOR' | 'TURNO_CRIATURA'
        acoesPadraoRestantes: 1,
        acoesPadraoMax: 1,
        acoesMovimentoRestantes: 1 + (temReflexosCombate ? 1 : 0),
        acoesMovimentoMax: 1 + (temReflexosCombate ? 1 : 0),
        reacaoDisponivel: true,
        concentracaoCombateAtiva: false, // Quando true, o próximo ataque rola 2d20 e seleciona o MELHOR!
        furiaAtiva: false,
        marcaPresaAtiva: false,
        velocidadeAtiva: false,
        armaduraArcanaCena: false,
        pvTempHeroi: 0,
        recargaSoproCriatura: 0,
        ataqueInimigoPendente: null,
        encerrado: false,
        pvHeroi: st.est.pvMax,
        pvHeroiMax: st.est.pvMax,
        pmHeroi: st.est.pmMax,
        pmHeroiMax: st.est.pmMax,
        defHeroiBase: st.est.defesa,
        bonusDefTemp: 0,
        rdTemp: ((st.poderes || []).some(p => p.nome.toLowerCase() === 'encouraçado') ? 2 : 0) + (st.raca && st.raca.nome.toLowerCase() === 'osteon' ? 5 : 0),
        ndCriatura: nd,
        papelCriatura: papel,
        _privadoCriatura: privObj,
        crencaIA: {
            defMin: 10,
            defMax: 65,
            testesMagia: 0,
            falhasMagia: 0,
            danoCausadoAcumulado: 0,
            golpesCriaturaObservados: []
        }
    };

    const bonusIniHeroi = st.est.bonusPericias['Iniciativa'] !== undefined ? st.est.bonusPericias['Iniciativa'] : (Math.floor(st.nivel / 2) + st.est.finais.DES);
    const bonusIniCriatura = __ARENA_STATE__._privadoCriatura.iniciativaOficial;
    const d20IniH = Math.floor(Math.random() * 20) + 1;
    const d20IniC = Math.floor(Math.random() * 20) + 1;
    const totIniH = d20IniH + bonusIniHeroi;
    const totIniC = d20IniC + bonusIniCriatura;
    const heroiVenceuIni = totIniH >= totIniC;

    __ARENA_STATE__.criaturaDesprevenida = heroiVenceuIni;
    __ARENA_STATE__.criaturaCaida = false;
    if (typeof inicializarEncontrosMultiplosEGrid2DArenaJS === 'function') {
        inicializarEncontrosMultiplosEGrid2DArenaJS(__ARENA_STATE__, st);
    }
    __ARENA_STATE__.escudoCriaturaQuebrado = false;

    atualizarTrilhaSonoraInimigoAtualJS();
    atualizarPlacarVisualArena();
    const logBox = document.getElementById('arena-combat-log');
    if (logBox) {
        const listaAcStr = privObj.repertorioAcoes.map(ac => `<span class="tag" style="background:#7F1D1D;">${ac.icone} ${ac.nome}</span>`).join(' ');
        logBox.innerHTML = `<div class="item-row" style="background:rgba(120,53,15,0.38);border-left:4px solid #FACC15;color:#FEF08A;padding:8px;">
            <strong>Batalha por Turnos Iniciada (Estilo Final Fantasy / Pokémon — Cap. 5, p. 230)!</strong><br>
            <strong>${st.nome}</strong> (${st.raca.nome} ${st.classe.nome} Nv ${st.nivel}) vs. <strong>${privObj.nomeCriatura} (ND ${privObj.ndTexto} · ${privObj.grupoCap7} — ${privObj.paginaRef})</strong>.<br>
            <strong>Iniciativa:</strong> Herói <code>1d20(${d20IniH})+${bonusIniHeroi} = ${totIniH}</code> vs. Criatura <code>1d20(${d20IniC})+${bonusIniCriatura} = ${totIniC}</code> 
            <strong>${heroiVenceuIni ? 'SEU TURNO! Você venceu a Iniciativa (a criatura está DESPREVENIDA: -5 na Defesa no 1º turno)!' : 'SEU TURNO! Criatura está alerta — use suas ações Padrão, Movimento e Livre!'}</strong><br>
            <strong>Repertório de Ações da Ficha da Criatura:</strong> ${listaAcStr}
        </div>`;
    }
}


function isolarIdsDefsCenarioSVG(svgStr) {
    const uid = 'cen_' + Math.random().toString(36).slice(2, 8);
    const ids = [
        'bgSkyDrag', 'bgLavaRiver', 'bgFloorDrag', 'goldHoardGlow',
        'bgSkyUndead', 'bgFloorUndead', 'aslothiaMoon',
        'bgSkyTorm', 'bgFloorTorm', 'aharadakEyeGlow',
        'bgSkyDung', 'bgFloorDung', 'torchGlowT20',
        'bgSkyWild', 'bgFloorWild',
        'bgSkyPur', 'bgFloorPur',
        'bgSkyDuy', 'bgFloorDuy',
        'bgSkySsz', 'bgFloorSsz'
    ];
    let out = svgStr;
    ids.forEach(id => {
        out = out.replace(new RegExp('id="' + id + '"', 'g'), 'id="' + id + '_' + uid + '"');
        out = out.replace(new RegExp('url\\(#' + id + '\\)', 'g'), 'url(#' + id + '_' + uid + ')');
    });
    return out;
}

function construirCenarioFundoJRPG(grupoCap7) {
    return isolarIdsDefsCenarioSVG((function(grupoCap7) {
    const selCen = document.getElementById('ap-sel-cenario-arton');
    const cenarioManual = (selCen && selCen.value && selCen.value !== 'AUTO_AMEACA') ? selCen.value : '';
    const g = (cenarioManual || grupoCap7 || 'Masmorras').toLowerCase();

    if (g.includes('drag')) {
        // COVIL DE SCKHARSHANTALLAS / VULCÃO DRACÔNICO E TESOURO DE TIBARES
        return `
            <defs>
                <linearGradient id="bgSkyDrag" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#0D0204"/>
                    <stop offset="45%" stop-color="#38080E"/>
                    <stop offset="80%" stop-color="#7F1D1D"/>
                    <stop offset="100%" stop-color="#EA580C"/>
                </linearGradient>
                <linearGradient id="bgLavaRiver" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stop-color="#EA580C"/>
                    <stop offset="50%" stop-color="#FDE047"/>
                    <stop offset="100%" stop-color="#DC2626"/>
                </linearGradient>
                <linearGradient id="bgFloorDrag" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#290F0B"/>
                    <stop offset="50%" stop-color="#180806"/>
                    <stop offset="100%" stop-color="#090302"/>
                </linearGradient>
                <radialGradient id="goldHoardGlow" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stop-color="#FDE047" stop-opacity="0.55"/>
                    <stop offset="100%" stop-color="#F59E0B" stop-opacity="0"/>
                </radialGradient>
            </defs>
            <rect width="860" height="232" fill="url(#bgSkyDrag)"/>
            <!-- Sol/Clarão Vulcânico de Sckharshantallas -->
            <circle cx="430" cy="145" r="110" fill="url(#goldHoardGlow)"/>
            <!-- Costelas Colossais de Dragão Ancestral no Fundo -->
            <path d="M 110 225 C 125 90, 260 55, 390 120 C 310 95, 195 125, 155 225 Z" fill="#1F0709" stroke="#58131A" stroke-width="2"/>
            <path d="M 210 225 C 225 110, 330 75, 420 135 C 350 112, 265 140, 240 225 Z" fill="#28090C" stroke="#7F1D1D" stroke-width="1.5"/>
            <path d="M 750 225 C 735 90, 600 55, 470 120 C 550 95, 665 125, 705 225 Z" fill="#1F0709" stroke="#58131A" stroke-width="2"/>
            <path d="M 650 225 C 635 110, 530 75, 440 135 C 510 112, 595 140, 620 225 Z" fill="#28090C" stroke="#7F1D1D" stroke-width="1.5"/>
            <!-- Montanhas Vulcânicas Esculpidas e Cascatas de Magma -->
            <path d="M 0 225 L 0 115 L 65 78 L 135 135 L 210 85 L 315 225 Z" fill="#180507" stroke="#450A0A" stroke-width="2"/>
            <path d="M 545 225 L 655 68 L 735 120 L 795 72 L 860 118 L 860 225 Z" fill="#180507" stroke="#450A0A" stroke-width="2"/>
            <path d="M 648 72 C 655 115, 635 160, 660 225 L 682 225 C 662 162, 675 115, 662 72 Z" fill="url(#bgLavaRiver)" opacity="0.88"/>
            <path d="M 198 88 C 205 135, 190 175, 212 225 L 226 225 C 208 175, 218 135, 208 88 Z" fill="url(#bgLavaRiver)" opacity="0.82"/>
            <!-- Solo de Obsidiana e Rio de Lava -->
            <rect y="220" width="860" height="90" fill="url(#bgFloorDrag)"/>
            <path d="M 0 236 C 180 224, 310 252, 460 238 C 610 224, 730 248, 860 234 L 860 254 C 710 268, 580 244, 430 258 C 280 270, 150 244, 0 256 Z" fill="url(#bgLavaRiver)" opacity="0.75"/>
            <!-- Tesouro Dracônico (Montes de Tibares de Ouro, Cálice e Espadas Cravadas) -->
            <path d="M 340 232 Q 430 188 520 232 Z" fill="#D97706" stroke="#FDE047" stroke-width="2"/>
            <path d="M 365 232 Q 430 198 495 232 Z" fill="#FACC15" opacity="0.85"/>
            <circle cx="412" cy="218" r="4" fill="#EF4444"/><circle cx="448" cy="215" r="4.5" fill="#38BDF8"/><circle cx="430" cy="210" r="5" fill="#EF4444"/>
            <line x1="395" y1="212" x2="382" y2="178" stroke="#E2E8F0" stroke-width="3"/><line x1="376" y1="188" x2="392" y2="184" stroke="#FACC15" stroke-width="3"/>
            <!-- Plataformas de Batalha Rúnicas -->
            <ellipse cx="220" cy="272" rx="128" ry="23" fill="#1C0D0A" stroke="#F59E0B" stroke-width="2.8"/>
            <ellipse cx="220" cy="272" rx="112" ry="17" fill="none" stroke="#FEF08A" stroke-width="1" stroke-dasharray="8,5" opacity="0.65"/>
            <ellipse cx="640" cy="272" rx="138" ry="25" fill="#260B0B" stroke="#EF4444" stroke-width="2.8"/>
            <ellipse cx="640" cy="272" rx="120" ry="18" fill="none" stroke="#FCA5A5" stroke-width="1.2" stroke-dasharray="10,6" opacity="0.7"/>
        `;
    }
    if (g.includes('tormenta') || g.includes('lefeu') || g.includes('aharadak')) {
        // ÁREA DE TORMENTA — TEMPESTADE RUBRA E OLHO COLOSSAL DE AHARADAK
        return `
            <defs>
                <linearGradient id="bgSkyTorm" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#1A0208"/>
                    <stop offset="45%" stop-color="#4C0519"/>
                    <stop offset="80%" stop-color="#881337"/>
                    <stop offset="100%" stop-color="#BE123C"/>
                </linearGradient>
                <linearGradient id="bgFloorTorm" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#3B0412"/>
                    <stop offset="55%" stop-color="#1F020A"/>
                    <stop offset="100%" stop-color="#0A0003"/>
                </linearGradient>
                <radialGradient id="aharadakEyeGlow" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stop-color="#FEF08A" stop-opacity="0.95"/>
                    <stop offset="35%" stop-color="#F43F5E" stop-opacity="0.75"/>
                    <stop offset="70%" stop-color="#881337" stop-opacity="0.35"/>
                    <stop offset="100%" stop-color="#4C0519" stop-opacity="0"/>
                </radialGradient>
            </defs>
            <rect width="860" height="232" fill="url(#bgSkyTorm)"/>
            <!-- Nuvens Espirais de Chuva Ácida e Sangue -->
            <path d="M 0 55 Q 210 15 430 62 T 860 45 L 860 0 L 0 0 Z" fill="#2D030E" opacity="0.85"/>
            <path d="M 0 98 Q 260 65 430 105 T 860 88 L 860 40 L 0 40 Z" fill="#4C0519" opacity="0.6"/>
            <!-- O Olho Colossal de Aharadak no Céu Rubro -->
            <circle cx="430" cy="96" r="88" fill="url(#aharadakEyeGlow)"/>
            <path d="M 352 96 Q 430 42 508 96 Q 430 150 352 96 Z" fill="#9F1239" stroke="#FDA4AF" stroke-width="3"/>
            <path d="M 366 96 Q 430 54 494 96 Q 430 138 366 96 Z" fill="#FACC15" stroke="#EA580C" stroke-width="2"/>
            <ellipse cx="430" cy="96" rx="11" ry="34" fill="#090D16" stroke="#FEF08A" stroke-width="1.5"/>
            <circle cx="424" cy="84" r="4.5" fill="#FFFFFF"/>
            <!-- Veias Rubras e Relâmpagos de Matéria Vermelha -->
            <polyline points="120,0 155,58 128,92 175,165 148,222" fill="none" stroke="#FDA4AF" stroke-width="3" opacity="0.85"/>
            <polyline points="740,0 702,64 732,96 688,172 712,222" fill="none" stroke="#FDA4AF" stroke-width="3" opacity="0.85"/>
            <!-- Torres Quitinosas de Coral Rubro e Olhos Aberrantes -->
            <path d="M 25 225 C 35 125, 78 65, 112 45 C 102 105, 118 160, 145 225 Z" fill="#4C0519" stroke="#F43F5E" stroke-width="2"/>
            <path d="M 105 225 C 115 150, 148 112, 175 95 C 165 142, 178 182, 198 225 Z" fill="#6B0F24" stroke="#FB7185" stroke-width="1.8"/>
            <path d="M 835 225 C 825 120, 782 62, 745 42 C 758 102, 742 158, 712 225 Z" fill="#4C0519" stroke="#F43F5E" stroke-width="2"/>
            <path d="M 745 225 C 735 148, 698 110, 672 92 C 682 138, 670 180, 650 225 Z" fill="#6B0F24" stroke="#FB7185" stroke-width="1.8"/>
            <circle cx="88" cy="145" r="7" fill="#FEF08A" stroke="#991B1B" stroke-width="1.5"/><ellipse cx="88" cy="145" rx="2" ry="6" fill="#000"/>
            <circle cx="768" cy="142" r="8" fill="#FEF08A" stroke="#991B1B" stroke-width="1.5"/><ellipse cx="768" cy="142" rx="2" ry="6.5" fill="#000"/>
            <!-- Chão de Carapaça Quitina e Poças de Ácido Rubro -->
            <rect y="220" width="860" height="90" fill="url(#bgFloorTorm)"/>
            <ellipse cx="430" cy="248" rx="95" ry="14" fill="#E11D48" opacity="0.55" stroke="#FDA4AF" stroke-width="1.5"/>
            <ellipse cx="220" cy="272" rx="128" ry="23" fill="#2D0410" stroke="#F43F5E" stroke-width="2.8"/>
            <ellipse cx="220" cy="272" rx="110" ry="16" fill="none" stroke="#FECDD3" stroke-width="1.2" stroke-dasharray="6,6" opacity="0.7"/>
            <ellipse cx="640" cy="272" rx="138" ry="25" fill="#2D0410" stroke="#F43F5E" stroke-width="2.8"/>
            <ellipse cx="640" cy="272" rx="120" ry="18" fill="none" stroke="#FECDD3" stroke-width="1.2" stroke-dasharray="6,6" opacity="0.7"/>
        `;
    }
    if (g.includes('morto') || g.includes('aslothia')) {
        // CATEDRAL PROFANA DE ASLOTHIA — REINO DOS MORTOS-VIVOS DE FERREIN
        return `
            <defs>
                <linearGradient id="bgSkyUndead" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#050811"/>
                    <stop offset="50%" stop-color="#13112E"/>
                    <stop offset="85%" stop-color="#1E293B"/>
                    <stop offset="100%" stop-color="#064E3B"/>
                </linearGradient>
                <linearGradient id="bgFloorUndead" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#0B1512"/>
                    <stop offset="100%" stop-color="#020617"/>
                </linearGradient>
                <radialGradient id="aslothiaMoon" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stop-color="#ECFDF5" stop-opacity="0.95"/>
                    <stop offset="45%" stop-color="#6EE7B7" stop-opacity="0.55"/>
                    <stop offset="100%" stop-color="#10B981" stop-opacity="0"/>
                </radialGradient>
            </defs>
            <rect width="860" height="232" fill="url(#bgSkyUndead)"/>
            <!-- Lua Cheia Espectral de Aslothia -->
            <circle cx="685" cy="74" r="68" fill="url(#aslothiaMoon)"/>
            <circle cx="685" cy="74" r="34" fill="#D1FAE5" opacity="0.9"/>
            <circle cx="674" cy="66" r="6" fill="#A7F3D0" opacity="0.6"/>
            <circle cx="696" cy="82" r="8" fill="#A7F3D0" opacity="0.6"/>
            <!-- Silhueta de Catedral Gótica em Ruínas e Rosácea -->
            <polygon points="355,222 355,95 390,48 430,85 470,48 505,95 505,222" fill="#0F172A" stroke="#334155" stroke-width="2"/>
            <circle cx="430" cy="122" r="24" fill="#1E1B4B" stroke="#64748B" stroke-width="2"/>
            <circle cx="430" cy="122" r="16" fill="none" stroke="#A855F7" stroke-width="1.5" stroke-dasharray="4,3"/>
            <path d="M 412 222 L 412 168 Q 430 148 448 168 L 448 222 Z" fill="#020617" stroke="#475569" stroke-width="1.8"/>
            <!-- Árvores Secas Retorcidas e Grades de Cemitério + Lápides -->
            <path d="M 68 222 L 68 135 L 42 98 M 68 152 L 98 112 M 68 170 L 45 142" fill="none" stroke="#1E293B" stroke-width="5" stroke-linecap="round"/>
            <path d="M 135 162 Q 152 146 168 162 L 168 222 L 135 222 Z" fill="#1E293B" stroke="#475569" stroke-width="2"/>
            <line x1="151" y1="168" x2="151" y2="192" stroke="#64748B" stroke-width="2.5"/><line x1="142" y1="176" x2="160" y2="176" stroke="#64748B" stroke-width="2.5"/>
            <path d="M 735 168 Q 750 152 765 168 L 765 222 L 735 222 Z" fill="#1E293B" stroke="#475569" stroke-width="2"/>
            <!-- Solo e Névoa Necromântica Esverdeada -->
            <rect y="220" width="860" height="90" fill="url(#bgFloorUndead)"/>
            <ellipse cx="430" cy="228" rx="420" ry="18" fill="#10B981" opacity="0.22"/>
            <ellipse cx="310" cy="242" rx="220" ry="12" fill="#A855F7" opacity="0.16"/>
            <ellipse cx="220" cy="272" rx="128" ry="23" fill="#09111E" stroke="#10B981" stroke-width="2.8"/>
            <ellipse cx="640" cy="272" rx="138" ry="25" fill="#130924" stroke="#A855F7" stroke-width="2.8"/>
        `;
    }
    if (g.includes('purista')) {
        // FORTALEZA DE FERRO DA SUPREMACIA PURISTA (BIELEFELD / YUDEN)
        return `
            <defs>
                <linearGradient id="bgSkyPur" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#090D16"/>
                    <stop offset="60%" stop-color="#1E293B"/>
                    <stop offset="100%" stop-color="#450A0A"/>
                </linearGradient>
                <linearGradient id="bgFloorPur" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#27272A"/>
                    <stop offset="100%" stop-color="#09090B"/>
                </linearGradient>
            </defs>
            <rect width="860" height="232" fill="url(#bgSkyPur)"/>
            <!-- Muralhas Ameadas e Torres de Cerco Blindadas -->
            <rect x="0" y="108" width="860" height="114" fill="#18181B" stroke="#3F3F46" stroke-width="2"/>
            <path d="M 0 108 L 0 88 L 40 88 L 40 108 L 80 108 L 80 88 L 120 88 L 120 108 L 160 108 L 160 88 L 200 88 L 200 108 L 240 108 L 240 88 L 280 88 L 280 108 L 320 108 L 320 88 L 360 88 L 360 108 L 500 108 L 500 88 L 540 88 L 540 108 L 580 108 L 580 88 L 620 88 L 620 108 L 660 108 L 660 88 L 700 88 L 700 108 L 740 108 L 740 88 L 780 88 L 780 108 L 820 108 L 820 88 L 860 88 L 860 108 Z" fill="#27272A" stroke="#52525B" stroke-width="1.5"/>
            <!-- Portão de Ferro Central e Estandartes Rubro-Negros -->
            <path d="M 370 222 L 370 118 Q 430 78 490 118 L 490 222 Z" fill="#09090B" stroke="#71717A" stroke-width="3"/>
            <line x1="395" y1="98" x2="395" y2="222" stroke="#52525B" stroke-width="2.5"/>
            <line x1="430" y1="88" x2="430" y2="222" stroke="#52525B" stroke-width="2.5"/>
            <line x1="465" y1="98" x2="465" y2="222" stroke="#52525B" stroke-width="2.5"/>
            <!-- Estandartes de Guerra -->
            <polygon points="145,112 185,112 185,188 165,172 145,188" fill="#991B1B" stroke="#FACC15" stroke-width="1.8"/>
            <polygon points="675,112 715,112 715,188 695,172 675,188" fill="#991B1B" stroke="#FACC15" stroke-width="1.8"/>
            <rect y="220" width="860" height="90" fill="url(#bgFloorPur)"/>
            <ellipse cx="220" cy="272" rx="128" ry="23" fill="#18181B" stroke="#D4AF37" stroke-width="2.8"/>
            <ellipse cx="640" cy="272" rx="138" ry="25" fill="#18181B" stroke="#EF4444" stroke-width="2.8"/>
        `;
    }
    if (g.includes('duyshidakk') || g.includes('goblin') || g.includes('orc')) {
        // ACAMPAMENTO DE GUERRA DUYSHIDAKK — ALIANÇA NEGRA & ECLIPSE DE THWOR
        return `
            <defs>
                <linearGradient id="bgSkyDuy" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#140703"/>
                    <stop offset="55%" stop-color="#431407"/>
                    <stop offset="100%" stop-color="#9A3412"/>
                </linearGradient>
                <linearGradient id="bgFloorDuy" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#291509"/>
                    <stop offset="100%" stop-color="#0C0603"/>
                </linearGradient>
            </defs>
            <rect width="860" height="232" fill="url(#bgSkyDuy)"/>
            <!-- Sol em Eclipse de Thwor Khoshkothruk -->
            <circle cx="430" cy="82" r="42" fill="#F97316" opacity="0.65"/>
            <circle cx="430" cy="82" r="32" fill="#090D16" stroke="#FDE047" stroke-width="2.5"/>
            <!-- Paliçadas de Madeira Pontiaguda e Tendas de Guerra -->
            <polygon points="40,222 50,128 62,222 72,135 84,222 95,125 108,222" fill="#451A03" stroke="#78350F" stroke-width="1.5"/>
            <polygon points="750,222 762,128 774,222 785,135 796,222 808,125 820,222" fill="#451A03" stroke="#78350F" stroke-width="1.5"/>
            <polygon points="150,222 225,122 300,222" fill="#7C2D12" stroke="#F59E0B" stroke-width="2"/>
            <polygon points="560,222 635,122 710,222" fill="#7C2D12" stroke="#F59E0B" stroke-width="2"/>
            <!-- Fogueira de Guerra Central -->
            <path d="M 405 222 Q 430 155 455 222 Z" fill="#F97316" opacity="0.85"/>
            <path d="M 415 222 Q 430 175 445 222 Z" fill="#FEF08A"/>
            <rect y="220" width="860" height="90" fill="url(#bgFloorDuy)"/>
            <ellipse cx="220" cy="272" rx="128" ry="23" fill="#271206" stroke="#F59E0B" stroke-width="2.8"/>
            <ellipse cx="640" cy="272" rx="138" ry="25" fill="#271206" stroke="#EA580C" stroke-width="2.8"/>
        `;
    }
    if (g.includes('cultista') || g.includes('sszzaas')) {
        // SANTUÁRIO OCULTO DE SSZZAAS — TEMPLO OFÍDICO DE VENENO E TRAIÇÃO
        return `
            <defs>
                <linearGradient id="bgSkySsz" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#021008"/>
                    <stop offset="60%" stop-color="#06361D"/>
                    <stop offset="100%" stop-color="#14532D"/>
                </linearGradient>
                <linearGradient id="bgFloorSsz" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#052E16"/>
                    <stop offset="100%" stop-color="#021208"/>
                </linearGradient>
            </defs>
            <rect width="860" height="232" fill="url(#bgSkySsz)"/>
            <!-- Estátua de Naja Colossal de Sszzaas no Altar Central -->
            <path d="M 365 222 C 350 135, 385 72, 430 62 C 475 72, 510 135, 495 222 Z" fill="#064E3B" stroke="#10B981" stroke-width="2.5"/>
            <ellipse cx="430" cy="112" rx="52" ry="34" fill="#047857" stroke="#FACC15" stroke-width="2"/>
            <circle cx="414" cy="106" r="6" fill="#FEF08A"/><circle cx="446" cy="106" r="6" fill="#FEF08A"/>
            <path d="M 426 126 L 420 152 M 434 126 L 440 152" stroke="#EF4444" stroke-width="2.5"/>
            <!-- Pilares Serpentinos com Chamas Verdes -->
            <rect x="95" y="45" width="38" height="177" fill="#064E3B" stroke="#34D399" stroke-width="2"/>
            <rect x="727" y="45" width="38" height="177" fill="#064E3B" stroke="#34D399" stroke-width="2"/>
            <circle cx="114" cy="95" r="20" fill="#10B981" opacity="0.4"/><polygon points="105,102 114,72 123,102" fill="#6EE7B7"/>
            <circle cx="746" cy="95" r="20" fill="#10B981" opacity="0.4"/><polygon points="737,102 746,72 755,102" fill="#6EE7B7"/>
            <rect y="220" width="860" height="90" fill="url(#bgFloorSsz)"/>
            <ellipse cx="220" cy="272" rx="128" ry="23" fill="#062814" stroke="#34D399" stroke-width="2.8"/>
            <ellipse cx="640" cy="272" rx="138" ry="25" fill="#062814" stroke="#A855F7" stroke-width="2.8"/>
        `;
    }
    if (g.includes('ermo') || g.includes('troll') || g.includes('galrasia')) {
        // SELVA PRIMORDIAL DE GALRASIA & ERMOS SELVAGENS DE ALLIHANNA
        return `
            <defs>
                <linearGradient id="bgSkyWild" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#04151F"/>
                    <stop offset="55%" stop-color="#0C3C4C"/>
                    <stop offset="100%" stop-color="#115E59"/>
                </linearGradient>
                <linearGradient id="bgFloorWild" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#064E3B"/>
                    <stop offset="60%" stop-color="#062E22"/>
                    <stop offset="100%" stop-color="#021710"/>
                </linearGradient>
            </defs>
            <rect width="860" height="232" fill="url(#bgSkyWild)"/>
            <!-- Lua Dourada de Allihanna e Montanhas de Lannestull -->
            <circle cx="705" cy="64" r="34" fill="#FEF9C3" opacity="0.88"/>
            <polygon points="0,222 155,95 340,222" fill="#082836"/>
            <polygon points="240,222 445,75 650,222" fill="#0A3342"/>
            <polygon points="530,222 725,92 860,222" fill="#082836"/>
            <!-- Árvores Gigantes de Galrasia, Cipós e Cristais de Mana Bioluminescentes -->
            <path d="M 35 222 L 45 45 L 82 45 L 92 222 Z" fill="#1E1B18" stroke="#3F2E21" stroke-width="2"/>
            <circle cx="65" cy="52" r="58" fill="#065F46" opacity="0.9"/>
            <path d="M 768 222 L 778 45 L 815 45 L 825 222 Z" fill="#1E1B18" stroke="#3F2E21" stroke-width="2"/>
            <circle cx="795" cy="52" r="58" fill="#065F46" opacity="0.9"/>
            <!-- Cristais de Mana de Galrasia -->
            <polygon points="135,222 145,178 158,222" fill="#2DD4BF" stroke="#CCFBF1" stroke-width="1.5"/>
            <polygon points="152,222 162,190 172,222" fill="#38BDF8" stroke="#E0F2FE" stroke-width="1.2"/>
            <polygon points="705,222 718,175 730,222" fill="#2DD4BF" stroke="#CCFBF1" stroke-width="1.5"/>
            <rect y="220" width="860" height="90" fill="url(#bgFloorWild)"/>
            <ellipse cx="220" cy="272" rx="128" ry="23" fill="#063729" stroke="#34D399" stroke-width="2.8"/>
            <ellipse cx="640" cy="272" rx="138" ry="25" fill="#063729" stroke="#F59E0B" stroke-width="2.8"/>
        `;
    }
    // MASMORRAS ANCESTRAIS DE HEREDRIMM / SALÃO DE PEDRA & TOCHAS RÚNICAS
    return `
        <defs>
            <linearGradient id="bgSkyDung" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#070A12"/>
                <stop offset="55%" stop-color="#161F30"/>
                <stop offset="100%" stop-color="#262220"/>
            </linearGradient>
            <linearGradient id="bgFloorDung" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#26211D"/>
                <stop offset="55%" stop-color="#171412"/>
                <stop offset="100%" stop-color="#090807"/>
            </linearGradient>
            <radialGradient id="torchGlowT20" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stop-color="#FDE047" stop-opacity="0.75"/>
                <stop offset="45%" stop-color="#F97316" stop-opacity="0.35"/>
                <stop offset="100%" stop-color="#EA580C" stop-opacity="0"/>
            </radialGradient>
        </defs>
        <rect width="860" height="232" fill="url(#bgSkyDung)"/>
        <!-- Arcos Góticos de Pedra Anã de Heredrimm -->
        <path d="M 108 222 L 108 75 Q 268 18 410 75 L 410 222" fill="none" stroke="#334155" stroke-width="8"/>
        <path d="M 450 222 L 450 75 Q 592 18 752 75 L 752 222" fill="none" stroke="#334155" stroke-width="8"/>
        <!-- Pilares Esculpidos com Runas de Khalmyr -->
        <rect x="64" y="20" width="46" height="202" fill="#1E293B" stroke="#475569" stroke-width="2.5"/>
        <rect x="407" y="20" width="46" height="202" fill="#1E293B" stroke="#475569" stroke-width="2.5"/>
        <rect x="750" y="20" width="46" height="202" fill="#1E293B" stroke="#475569" stroke-width="2.5"/>
        <!-- Braseiros e Tochas Flamejantes -->
        <circle cx="87" cy="94" r="42" fill="url(#torchGlowT20)"/>
        <path d="M 77 104 L 87 72 L 97 104 Z" fill="#F97316"/><path d="M 81 104 L 87 82 L 93 104 Z" fill="#FEF08A"/>
        <circle cx="430" cy="94" r="42" fill="url(#torchGlowT20)"/>
        <path d="M 420 104 L 430 72 L 440 104 Z" fill="#F97316"/><path d="M 424 104 L 430 82 L 436 104 Z" fill="#FEF08A"/>
        <circle cx="773" cy="94" r="42" fill="url(#torchGlowT20)"/>
        <path d="M 763 104 L 773 72 L 783 104 Z" fill="#F97316"/><path d="M 767 104 L 773 82 L 779 104 Z" fill="#FEF08A"/>
        <!-- Piso de Lajes de Pedra e Selos de Batalha -->
        <rect y="220" width="860" height="90" fill="url(#bgFloorDung)"/>
        <line x1="0" y1="246" x2="860" y2="246" stroke="#332D28" stroke-width="1.5"/>
        <ellipse cx="220" cy="272" rx="128" ry="23" fill="#241F1B" stroke="#D4AF37" stroke-width="2.8"/>
        <ellipse cx="220" cy="272" rx="112" ry="17" fill="none" stroke="#FDE047" stroke-width="1" stroke-dasharray="8,5" opacity="0.6"/>
        <ellipse cx="640" cy="272" rx="138" ry="25" fill="#281A1A" stroke="#EF4444" stroke-width="2.8"/>
        <ellipse cx="640" cy="272" rx="120" ry="18" fill="none" stroke="#F87171" stroke-width="1" stroke-dasharray="8,5" opacity="0.6"/>
    `;
})(grupoCap7));
}

const PALETAS_RACIAIS_T20 = {
    'minotauro': [
        { cor: '#78350F', nome: 'Pelagem Marrom-Tapista (Padrão)' },
        { cor: '#27272A', nome: 'Pelagem Negra de Ferro' },
        { cor: '#7F1D1D', nome: 'Pelagem Ruiva-Sangue' },
        { cor: '#E2E8F0', nome: 'Pelagem Branca Albina Sagrada' },
        { cor: '#57534E', nome: 'Pelagem Cinza-Rocha das Montanhas' }
    ],
    'trog': [
        { cor: '#15803D', nome: 'Escamas Verde-Pântano (Padrão)' },
        { cor: '#0F766E', nome: 'Escamas Azul-Turquesa Camaleão' },
        { cor: '#14532D', nome: 'Escamas Musgo Subterrâneo' },
        { cor: '#4D7C0F', nome: 'Escamas Oliva-Veneno' },
        { cor: '#D9F99D', nome: 'Escamas Albino das Cavernas' }
    ],
    'golem': [
        { cor: '#64748B', nome: 'Chassi de Ferro & Bronze (Padrão)' },
        { cor: '#D97706', nome: 'Chassi de Ouro & Latão Sagrado' },
        { cor: '#1E293B', nome: 'Chassi de Obsidiana Negra' },
        { cor: '#78716C', nome: 'Chassi de Granito Rúnico' },
        { cor: '#38BDF8', nome: 'Chassi de Cristal Arcano' }
    ],
    'osteon': [
        { cor: '#E2E8F0', nome: 'Osso Marfim Antigo (Padrão)' },
        { cor: '#475569', nome: 'Osso Carbonizado de Cinzas' },
        { cor: '#A7F3D0', nome: 'Osso Esverdeado de Aslothia' },
        { cor: '#FEF08A', nome: 'Osso Dourado de Faraó' }
    ],
    'qareen': [
        { cor: '#60A5FA', nome: 'Pele Safira (Ar / Frio)' },
        { cor: '#F87171', nome: 'Pele Rubi (Fogo)' },
        { cor: '#FBBF24', nome: 'Pele Âmbar (Eletricidade)' },
        { cor: '#34D399', nome: 'Pele Esmeralda (Ácido)' },
        { cor: '#C084FC', nome: 'Pele Ametista (Trevas)' },
        { cor: '#FEF9C3', nome: 'Pele Perolada (Luz)' }
    ],
    'goblin': [
        { cor: '#4ADE80', nome: 'Pele Verde-Bagaço (Padrão)' },
        { cor: '#65A30D', nome: 'Pele Oliva de Fuligem' },
        { cor: '#94A3B8', nome: 'Pele Cinza de Subterrâneo' },
        { cor: '#EAB308', nome: 'Pele Amarelo-Enxofre' }
    ],
    'lefou': [
        { cor: '#FCA5A5', nome: 'Pele Pálida Rubra (Padrão)' },
        { cor: '#E11D48', nome: 'Carapaça Carmesim da Tormenta' },
        { cor: '#9CA3AF', nome: 'Quitina Cinza-Aberrante' }
    ],
    'dahllan': [
        { cor: '#FDBA74', nome: 'Pele Seiva Dourada (Padrão)' },
        { cor: '#86EFAC', nome: 'Pele Verde-Folha de Primavera' },
        { cor: '#A16207', nome: 'Casca de Carvalho Antigo' },
        { cor: '#F9A8D4', nome: 'Pétala de Cerejeira' }
    ],
    'sereia/tritão': [
        { cor: '#38BDF8', nome: 'Pele Azul-Oceano (Padrão)' },
        { cor: '#2DD4BF', nome: 'Pele Verde-Recife de Coral' },
        { cor: '#818CF8', nome: 'Pele Índigo das Fendas Abissais' }
    ],
    'medusa': [
        { cor: '#86EFAC', nome: 'Pele Verde-Ofídica (Padrão)' },
        { cor: '#E2E8F0', nome: 'Pele Pálida de Mármore' },
        { cor: '#D97706', nome: 'Pele Bronze de Sszzaas' }
    ],
    'sílfide': [
        { cor: '#FBCFE8', nome: 'Pele Rosa-Fada (Padrão)' },
        { cor: '#BAE6FD', nome: 'Pele Azul-Orvalho' },
        { cor: '#BBF7D0', nome: 'Pele Verde-Brisa' }
    ],
    'suraggel (aggelus)': [
        { cor: '#FEF08A', nome: 'Pele Dourada Celestial (Padrão)' },
        { cor: '#F8FAFC', nome: 'Pele Prateada Astral' },
        { cor: '#FDBA74', nome: 'Pele Bronze Solar' }
    ],
    'suraggel (sulfure)': [
        { cor: '#F87171', nome: 'Pele Rubra Abissal (Padrão)' },
        { cor: '#64748B', nome: 'Pele Cinza das Sombras' },
        { cor: '#C084FC', nome: 'Pele Violeta Profana' }
    ],
    'padrao': [
        { cor: '#FDBA74', nome: 'Pele Clara Dourada' },
        { cor: '#FDE68A', nome: 'Pele Alva / Marfim' },
        { cor: '#D97706', nome: 'Pele Morena / Bronzeada' },
        { cor: '#92400E', nome: 'Pele Negra / Ébano Quente' },
        { cor: '#57534E', nome: 'Pele Negra Escura' }
    ]
};

// ==============================================================================
// SINTETIZADOR DE EFEITOS SONOROS WEB AUDIO API (JRPG SOUND ENGINE)
// ==============================================================================
window.__SOM_JRPG_ATIVO__ = true;
window.__AUDIO_CTX_T20__ = null;

