
// ==============================================================================
// OTIMIZADOR AUTOMÁTICO MCTS DE MULTICLASSE (8 POLÍTICAS — CAP. 1, P. 34)
// ==============================================================================
function gerarCandidatosMulticlassePorPoliticaJS(classePrimObj, nivel, arquetipo, modoMC, fixSecNome, nvSecManual, fixTercNome, nvTercManual) {
    const c1 = classePrimObj;
    const n1Nome = c1.nome;
    const acharCl = (nm) => (!nm || nm === 'NENHUMA' || nm === 'AUTO') ? null : (CATALOGO_T20.classes.find(c => c.nome.toLowerCase() === nm.toLowerCase()) || null);
    const arqL = (arquetipo || '').toLowerCase();

    // Se nível == 1 ou política == SEM_MULTICLASSE, retorna exclusivamente a Classe Pura!
    if (nivel <= 1 || modoMC === 'SEM_MULTICLASSE') {
        return [{
            classe: c1, classeSecundaria: null, nivelClasseSecundaria: 0, classeTerciaria: null, nivelClasseTerciaria: 0,
            rotuloPolitica: 'Classe Pura (Monoclasse 100%)',
            justificativaSinergia: `100% dos níveis em ${n1Nome} (maximiza progressão pura de habilidades e círculos da classe principal).`
        }];
    }

    // Se política == MANUAL_FIXA ou usuário fixou explicitamente uma 2ª classe:
    const clSecFixa = acharCl(fixSecNome);
    const clTercFixa = acharCl(fixTercNome);
    if (modoMC === 'MANUAL_FIXA' || (clSecFixa && clSecFixa.nome !== n1Nome && modoMC !== 'FORCAR_MULTICLASSE_OTIMA' && modoMC !== 'TRICLASSE_OTIMA')) {
        const nv2 = clSecFixa ? Math.max(1, Math.min(nivel - 1, nvSecManual || 1)) : 0;
        const nv3 = (clTercFixa && nivel >= 3) ? Math.max(1, Math.min(nivel - nv2 - 1, nvTercManual || 1)) : 0;
        return [{
            classe: c1, classeSecundaria: clSecFixa, nivelClasseSecundaria: nv2, classeTerciaria: nv3 > 0 ? clTercFixa : null, nivelClasseTerciaria: nv3,
            rotuloPolitica: 'Seleção Manual / Fixada',
            justificativaSinergia: `Distribuição definida manualmente conforme regras de Multiclasse (p. 34).`
        }];
    }

    // Parceiros sinérgicos ordenados por afinidade tática com a 1ª classe e o arquétipo
    const parceirosPorClasse = {
        'guerreiro': [
            { sec: 'Bárbaro', why: 'Soma Fúria (+2 Atq/+2 Dano corpo a corpo por 2 PM, p. 40) com Ataque Especial e Golpe Pessoal' },
            { sec: 'Paladino', why: 'Soma Golpe Divino (+CAR Atq e +1d8 Dano, p. 81) + Abençoado (+CAR nos PM) com Ataque Especial' },
            { sec: 'Arcanista', why: 'Magus de Batalha: combina Armas Marciais e Ataque Especial com Concentração de Combate (2d20), Armadura Arcana e Campo de Força' },
            { sec: 'Caçador', why: 'Soma Marca da Presa (+1d4 a +1d8 em todos os golpes, p. 49) com Ataque Especial e Ataque Extra' },
            { sec: 'Cavaleiro', why: 'Soma Baluarte (+Defesa e +Resistências como Reação, p. 56) e Duelo com Durão' },
            { sec: 'Ladino', why: 'Soma Ataque Furtivo (+Xd6 ao flanquear/desprevenido, p. 73) e Especialista' }
        ],
        'bárbaro': [
            { sec: 'Guerreiro', why: 'Combina Fúria (+Atq/+Dano na cena) com Ataque Especial (+4/+8 explosivo) e Durão (reduz dano à metade)' },
            { sec: 'Lutador', why: 'Soma Golpe Relâmpago (+1 ataque extra por 1 PM, p. 76) e Casca Grossa (+CON na Defesa) à Fúria' },
            { sec: 'Caçador', why: 'Soma Marca da Presa (+1d4/+1d6 em todos os ataques) à Fúria' }
        ],
        'paladino': [
            { sec: 'Guerreiro', why: 'Acumula Golpe Divino (+CAR Atq/+1d8 Dano) com Ataque Especial (+4/+8) e Durão no mesmo golpe' },
            { sec: 'Cavaleiro', why: 'Acumula Égide Sagrada e Aura Sagrada (+CAR nas Resistências) com Baluarte (+Defesa e +Resistências)' },
            { sec: 'Bardo', why: 'Sinergia total de Carisma (CAR): soma Inspiração e Magias Arcanas ao Abençoado (+CAR PM) e Golpe Divino' },
            { sec: 'Arcanista', why: 'Feiticeiro Abençoado (CAR): une Golpe Divino com Concentração de Combate e Armadura Arcana' }
        ],
        'caçador': [
            { sec: 'Ladino', why: 'Acumula Marca da Presa em cada ataque com Ataque Furtivo (+Xd6) e Evasão' },
            { sec: 'Guerreiro', why: 'Soma Ataque Especial (+4/+8 para garantir acerto mesmo com penalidade de Duas Armas/Disparo Rápido)' },
            { sec: 'Bárbaro', why: 'Soma Fúria (+2 Atq/+2 Dano em todos os ataques de Duas Armas) com Marca da Presa' }
        ],
        'ladino': [
            { sec: 'Caçador', why: 'Soma Marca da Presa (+1d4) e Rastreador ao Ataque Furtivo' },
            { sec: 'Bucaneiro', why: 'Soma Insolência (+CAR na Defesa) e Audácia (+CAR em perícia) ao Especialista' },
            { sec: 'Guerreiro', why: 'Soma Ataque Especial (+4 Atq para garantir o acerto do Ataque Furtivo)' }
        ],
        'cavaleiro': [
            { sec: 'Clérigo', why: 'Templário Imortal: une Baluarte e Armadura Pesada com Escudo da Fé, Proteção Divina e Curar Ferimentos' },
            { sec: 'Guerreiro', why: 'Une Baluarte (+Def/+Res) com Durão (reduz dano à metade) e Ataque Especial' },
            { sec: 'Paladino', why: 'Une Baluarte com Abençoado (+CAR PM), Cura pelas Mãos e Golpe Divino' }
        ],
        'bucaneiro': [
            { sec: 'Guerreiro', why: 'Soma Ataque Especial e Durão à Insolência e Audácia' },
            { sec: 'Bardo', why: 'Sinergia de Carisma (CAR): une Esgrima/Insolência com Inspiração e Magias' },
            { sec: 'Ladino', why: 'Une Audácia e Margem de Crítico com Ataque Furtivo (+Xd6)' }
        ],
        'lutador': [
            { sec: 'Bárbaro', why: 'Soma Fúria (+2 Atq/+2 Dano em cada soco + Golpe Relâmpago) com Casca Grossa' },
            { sec: 'Guerreiro', why: 'Soma Ataque Especial e Durão à Trocação e Golpe Relâmpago' }
        ],
        'arcanista': [
            { sec: 'Guerreiro', why: 'Dip Tático (1 nv): concede Armas Marciais, +PV/nv e Ataque Especial sem atrasar os círculos de magia em níveis altos' },
            { sec: 'Paladino', why: 'Para Feiticeiro (CAR): soma Abençoado (+CAR nos PM no 1º nível!) e Golpe Divino' },
            { sec: 'Bardo', why: 'Expande repertório com Inspiração e magias de suporte/cura' }
        ],
        'clérigo': [
            { sec: 'Cavaleiro', why: 'Soma Baluarte (+2 Defesa e +2 Resistências por 1 PM) à Couraça Divina' },
            { sec: 'Guerreiro', why: 'Soma Ataque Especial e Durão ao Clérigo de Combate (Prece de Combate + Arma Sagrada)' }
        ],
        'druida': [
            { sec: 'Bárbaro', why: 'Soma Fúria (+2 Atq/+2 Dano corpo a corpo) à Forma Selvagem e Presas Primordiais' },
            { sec: 'Caçador', why: 'Soma Marca da Presa (+1d4/+1d6 em cada ataque natural) e Explorador (SAB)' },
            { sec: 'Guerreiro', why: 'Soma Ataque Especial (+4/+8) e Durão à Forma Selvagem' }
        ],
        'bardo': [
            { sec: 'Paladino', why: 'Sinergia máxima de Carisma (CAR): soma Abençoado (+CAR PM) e Golpe Divino (+CAR Atq/+1d8 Dano) à Esgrima Mágica' },
            { sec: 'Bucaneiro', why: 'Soma Insolência (+CAR na Defesa) e Audácia (+CAR em perícia) ao Bardo Duelista' }
        ],
        'inventor': [
            { sec: 'Guerreiro', why: 'Soma Ataque Especial (+4/+8 para garantir acerto com Mosquete/Besta) e Durão' },
            { sec: 'Caçador', why: 'Soma Marca da Presa aos disparos balísticos' }
        ],
        'nobre': [
            { sec: 'Paladino', why: 'Sinergia de Carisma (CAR): une Autoconfiança e Gritar Ordens com Abençoado e Golpe Divino' },
            { sec: 'Cavaleiro', why: 'Une Autoconfiança (+CAR na Defesa) com Baluarte' }
        ]
    };

    const listaParceiros = parceirosPorClasse[n1Nome.toLowerCase()] || [
        { sec: 'Guerreiro', why: 'Adiciona Ataque Especial (+4 Atq/Dano por 1 PM)' },
        { sec: 'Bárbaro', why: 'Adiciona Fúria (+2 Atq/Dano na cena)' },
        { sec: 'Paladino', why: 'Adiciona Golpe Divino (+CAR Atq e +1d8 Dano) e Abençoado (+CAR PM)' }
    ];

    const candidatos = [];

    // 1. Candidato Classe Pura (incluído quando modoMC == AUTO_MCTS)
    if (modoMC === 'AUTO_MCTS') {
        candidatos.push({
            classe: c1, classeSecundaria: null, nivelClasseSecundaria: 0, classeTerciaria: null, nivelClasseTerciaria: 0,
            rotuloPolitica: `Monoclasse Pura (${n1Nome} ${nivel})`,
            justificativaSinergia: `Mantém 100% dos ${nivel} níveis em ${n1Nome} para desbloquear poderes/círculos de nível superior sem atraso.`
        });
    }

    // 2. Candidatos de 2 Classes conforme a política selecionada
    for (const parc of listaParceiros) {
        const cl2 = acharCl(parc.sec);
        if (!cl2 || cl2.nome === n1Nome) continue;

        if (modoMC === 'DIP_1_NIVEL' || modoMC === 'AUTO_MCTS' || modoMC === 'FORCAR_MULTICLASSE_OTIMA') {
            if (nivel >= 2) {
                candidatos.push({
                    classe: c1, classeSecundaria: cl2, nivelClasseSecundaria: 1, classeTerciaria: null, nivelClasseTerciaria: 0,
                    rotuloPolitica: `Dip Tático 1 Nv (${n1Nome} ${nivel - 1} / ${cl2.nome} 1)`,
                    justificativaSinergia: parc.why
                });
            }
        }
        if ((modoMC === 'DIP_2_NIVEIS' || modoMC === 'AUTO_MCTS' || modoMC === 'FORCAR_MULTICLASSE_OTIMA') && nivel >= 4) {
            candidatos.push({
                classe: c1, classeSecundaria: cl2, nivelClasseSecundaria: 2, classeTerciaria: null, nivelClasseTerciaria: 0,
                rotuloPolitica: `Dip 2 Níveis (${n1Nome} ${nivel - 2} / ${cl2.nome} 2)`,
                justificativaSinergia: `${parc.why} + habilita escolher 1 Poder de Classe de ${cl2.nome} no 2º nível da classe (p. 34).`
            });
        }
        if ((modoMC === 'EQUILIBRADA_50_50' || modoMC === 'AUTO_MCTS' || modoMC === 'FORCAR_MULTICLASSE_OTIMA') && nivel >= 4) {
            const nv2Eq = Math.max(1, Math.floor(nivel / 2));
            if (nv2Eq !== 1 && nv2Eq !== 2) {
                candidatos.push({
                    classe: c1, classeSecundaria: cl2, nivelClasseSecundaria: nv2Eq, classeTerciaria: null, nivelClasseTerciaria: 0,
                    rotuloPolitica: `Híbrido Equilibrado (${n1Nome} ${nivel - nv2Eq} / ${cl2.nome} ${nv2Eq})`,
                    justificativaSinergia: `Progressão equilibrada 50/50: ${parc.why}.`
                });
            } else if (modoMC === 'EQUILIBRADA_50_50') {
                candidatos.push({
                    classe: c1, classeSecundaria: cl2, nivelClasseSecundaria: nv2Eq, classeTerciaria: null, nivelClasseTerciaria: 0,
                    rotuloPolitica: `Híbrido Equilibrado (${n1Nome} ${nivel - nv2Eq} / ${cl2.nome} ${nv2Eq})`,
                    justificativaSinergia: `Progressão equilibrada 50/50: ${parc.why}.`
                });
            }
        }
        // Caso especial Magus (Guerreiro 1 / Conjurador Nv-1) para não perder círculos de magia!
        if ((modoMC === 'AUTO_MCTS' || modoMC === 'FORCAR_MULTICLASSE_OTIMA') && nivel >= 6 && n1Nome.toLowerCase() === 'guerreiro' && ['arcanista', 'clérigo', 'bardo', 'druida'].includes(cl2.nome.toLowerCase())) {
            candidatos.push({
                classe: c1, classeSecundaria: cl2, nivelClasseSecundaria: nivel - 1, classeTerciaria: null, nivelClasseTerciaria: 0,
                rotuloPolitica: `Magus Conjurador (${n1Nome} 1 / ${cl2.nome} ${nivel - 1})`,
                justificativaSinergia: `Garante perícias/proficiências e Ataque Especial no 1º nv de Guerreiro e dedica ${nivel - 1} níveis a ${cl2.nome} para desbloquear círculos superiores de magia!`
            });
        }
    }

    // 3. Candidatos de Triclasse (quando modoMC == TRICLASSE_OTIMA ou em AUTO_MCTS / FORCAR_MULTICLASSE_OTIMA no nível >= 5)
    if ((modoMC === 'TRICLASSE_OTIMA' || ((modoMC === 'AUTO_MCTS' || modoMC === 'FORCAR_MULTICLASSE_OTIMA') && nivel >= 5)) && nivel >= 3 && listaParceiros.length >= 2) {
        const cl2T = acharCl(listaParceiros[0].sec);
        const cl3T = acharCl(listaParceiros[1].sec);
        if (cl2T && cl3T && cl2T.nome !== cl3T.nome) {
            candidatos.push({
                classe: c1, classeSecundaria: cl2T, nivelClasseSecundaria: 1, classeTerciaria: cl3T, nivelClasseTerciaria: 1,
                rotuloPolitica: `Triclasse Sinérgica (${n1Nome} ${nivel - 2} / ${cl2T.nome} 1 / ${cl3T.nome} 1)`,
                justificativaSinergia: `Combina a base de ${n1Nome} com as habilidades de 1º nível de ${cl2T.nome} E ${cl3T.nome} simultaneamente!`
            });
        }
    }

    if (candidatos.length === 0) {
        candidatos.push({
            classe: c1, classeSecundaria: null, nivelClasseSecundaria: 0, classeTerciaria: null, nivelClasseTerciaria: 0,
            rotuloPolitica: `Monoclasse (${n1Nome} ${nivel})`,
            justificativaSinergia: `Progressão padrão em ${n1Nome}.`
        });
    }
    return candidatos;
}

function avaliarRankingMulticlasseMCTSJS(cfgBase, candidatosMC) {
    const avaliados = [];
    for (const cand of candidatosMC) {
        const paresCand = normalizarClassesMulticlasseJS({
            nivel: cfgBase.nivel,
            classe: cand.classe,
            classeSecundaria: cand.classeSecundaria,
            nivelClasseSecundaria: cand.nivelClasseSecundaria,
            classeTerciaria: cand.classeTerciaria,
            nivelClasseTerciaria: cand.nivelClasseTerciaria
        });
        const circMaxCand = circuloMaximoPermitido(cand.classe, cfgBase.nivel, paresCand);
        let magiasCand = cfgBase.magias || [];
        if (circMaxCand > 0) {
            const parConj = paresCand.find(pc => circuloPorClasseENivelJS(pc.classeObj, pc.nivel) > 0);
            const tipoM = (parConj && ['clérigo', 'clerigo', 'druida'].includes(parConj.classeObj.nome.toLowerCase())) ? 'Divina' : 'Arcana';
            const magDisp = CATALOGO_T20.magias.filter(m => m.circulo <= circMaxCand && (m.tipo === tipoM || m.tipo === 'Universal'));
            magiasCand = magDisp.slice(0, Math.min(magDisp.length, 2 + cfgBase.nivel));
        }
        const estCand = calcularEstatisticaCompletaT20({
            ...cfgBase,
            classe: cand.classe,
            classeSecundaria: cand.classeSecundaria,
            nivelClasseSecundaria: cand.nivelClasseSecundaria,
            classeTerciaria: cand.classeTerciaria,
            nivelClasseTerciaria: cand.nivelClasseTerciaria
        });
        const resDanoCand = calcularResumoDanoJS(cfgBase.nivel, cand.classe, estCand, cfgBase.poderes || [], cfgBase.itens || [], cfgBase.arma, cfgBase.escudo, magiasCand, cfgBase.caminhoArcanista);
        let scBase = avaliarScoreMCTSClient(estCand, cfgBase.poderes || [], magiasCand, cfgBase.arma, [], cfgBase.arquetipo, cfgBase.nivel, cand.classe, cfgBase.itens || [], cfgBase.escudo);

        // Avaliação justa Classe Pura vs. Multiclasse — ZERO bônus artificial pré-definido!
        // Contabiliza slots reais de poderes de progressão (sum(max(0, nivel - 1))) e marcos reais (círculos, Ataque Extra, Trocação)
        const dprPot = window.__ULTIMO_DPR_POTENCIAL_RODADA__ || resDanoCand.danoMedioArma || 0;
        const slotsPoderReal = paresCand.reduce((acc, pc) => acc + Math.max(0, (pc.nivel || 0) - 1), 0);
        const ehPura = paresCand.length === 1;
        let bonusSinergiaMC = dprPot * 1.15 + circMaxCand * 24.0 + slotsPoderReal * 18.0;
        const nvG = paresCand.find(p => p.classeObj.nome === 'Guerreiro')?.nivel || 0;
        const nvLut = paresCand.find(p => p.classeObj.nome === 'Lutador')?.nivel || 0;
        if (nvG >= 6) bonusSinergiaMC += 28.0; // Ataque Extra (Marco Nv 6)
        if (nvLut >= 6) bonusSinergiaMC += 24.0; // Trocação (Marco Nv 6)
        if (ehPura && cfgBase.nivel >= 5) bonusSinergiaMC += 12.0; // Progressão contínua sem perda de níveis mortos

        const scoreTotalMC = +(scBase + bonusSinergiaMC).toFixed(1);
        const resumoDist = paresCand.map(p => `${p.classeObj.nome} ${p.nivel}`).join(' / ');
        avaliados.push({
            ...cand,
            paresClasses: paresCand,
            resumoDist,
            estCand,
            resDanoCand,
            magiasCand,
            dprPotencial: +dprPot.toFixed(1),
            circMaxCand,
            scoreTotalMC
        });
    }
    avaliados.sort((a, b) => b.scoreTotalMC - a.scoreTotalMC);
    return avaliados;
}


// ======================================================================================
// MOTOR DE OTIMIZAÇÃO 100% ORIENTADO A DESCRITORES NUMÉRICOS + CHECKS
// + CÁLCULO REAL DE DPR (ACERTO, CRÍTICO, 2d20), EHP, SUPORTE EM GRUPO,
// BEAM SEARCH (LOOKAHEAD DE COMBOS) E FRONTEIRA DE PARETO MULTI-ESTILO
// ======================================================================================

function slugCheckT20JS(str) {
    return 'check_' + String(str || '').toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
}

// 1. Constrói o conjunto de CHECKS booleanos da ficha (pré-análise O(1))
function construirVetorChecksFichaJS(cfg) {
    const checks = new Set();
    const cls = cfg.classe ? (cfg.classe.nome || '').toLowerCase() : '';
    if (cls) checks.add(slugCheckT20JS('classe_' + cls));
    (cfg.paresClasses || []).forEach(pc => {
        if (pc && pc.classeObj && pc.classeObj.nome) checks.add(slugCheckT20JS('classe_' + pc.classeObj.nome));
    });

    const arma = cfg.arma || null;
    const escudo = cfg.escudo || null;
    const nmA = arma ? (arma.nome || '').toLowerCase() : '';
    const subA = arma ? (arma.subcategoria || '').toLowerCase() : '';
    const propA = arma ? (arma.efeito_propriedades || '').toLowerCase() : '';

    const ehDesarmado = !arma || /manopla|desarmado|briga/.test(nmA);
    const ehDistancia = subA.includes('distância') || subA.includes('fogo') || /mosquete|pistola|arco|besta/.test(nmA);
    const ehFogo = subA.includes('fogo') || /mosquete|pistola/.test(nmA);
    const ehDuasMaos = !ehDesarmado && !ehDistancia && (subA.includes('duas mãos') || /montante|machado táurico|machado de guerra|alabarda|pique|gadanho|marreta|tacape/.test(nmA));
    const ehAgil = !ehDuasMaos && !ehDistancia && (propA.includes('ágil') || propA.includes('leve') || /adaga|espada curta|florete|manopla/.test(nmA));

    if (ehDesarmado) checks.add('check_arma_desarmada');
    if ((cfg.poderes || []).some(p => ['forma selvagem', 'chifres', 'mordida', 'presas primordiais', 'dentes afiados'].includes(String((p && p.nome) || '').toLowerCase()))) {
        checks.add('check_arma_natural');
    }
    const ehArremesso = subA.includes('arremesso') || propA.includes('arremesso') || /azagaia|machadinha|shuriken|dardo|tridente|lança|adaga/.test(nmA);
    if (ehDistancia) checks.add('check_arma_distancia');
    if (ehArremesso) checks.add('check_arma_arremesso');
    if (ehFogo) checks.add('check_arma_fogo');
    if (ehDuasMaos) checks.add('check_arma_duas_maos');
    if (ehAgil) checks.add('check_arma_agil');
    if (!ehDistancia) checks.add('check_arma_corpo_a_corpo');
    if (escudo) checks.add('check_escudo');

    (cfg.poderes || []).forEach(p => {
        if (p && p.nome) {
            const s = slugCheckT20JS(p.nome);
            checks.add(s);
            if (p.nome.toLowerCase().startsWith('estilo de ')) checks.add('check_possui_estilo');
        }
    });
    // Apenas classes conjuradoras plenas recebem check_conjurador (Tatuagem Mística de Qareen em marciais não transforma Bucaneiro/Cavaleiro em conjurador pleno!)
    if (['arcanista', 'clérigo', 'clerigo', 'druida', 'bardo'].includes(cls)) {
        checks.add('check_conjurador');
    }
    return checks;
}

// 2. Compila o DESCRITOR NUMÉRICO estruturado de qualquer Poder/Habilidade do catálogo (ZERO pesos mágicos por nome!)

// Tabela Oficial de Passos de Dano — Tormenta20 Edição Jogo do Ano (Cap. 3, Tabela 3-2)
function aumentarPassoDanoT20JS(dadoStr, passos) {
    const p = parseInt(passos || 0, 10);
    const s = String(dadoStr || '1d6').toLowerCase().replace(/\s+/g, '');
    if (p === 0) return s;
    const trilhaPadrao = ['1d2', '1d3', '1d4', '1d6', '1d8', '1d10', '1d12', '3d6', '4d6', '4d8', '4d10', '4d12'];
    const trilha2d8 = ['1d10', '2d6', '2d8', '3d8', '4d10', '4d12'];
    if (s === '2d4') {
        const idx = Math.max(0, Math.min(trilhaPadrao.length - 1, 4 + p)); // 2d4 equivale ao passo de 1d8 -> +1 = 1d10/2d6 -> 3d6
        return p === 1 ? '2d6' : trilhaPadrao[idx];
    }
    if (s === '2d6') {
        if (p > 0) return trilhaPadrao[Math.min(trilhaPadrao.length - 1, 6 + p)]; // 2d6 +1 = 3d6, +2 = 4d6
        return trilhaPadrao[Math.max(0, 5 + p)]; // 2d6 -1 = 1d10
    }
    if (s === '2d8' || s === '3d8') {
        const i2 = trilha2d8.indexOf(s);
        return trilha2d8[Math.max(0, Math.min(trilha2d8.length - 1, i2 + p))];
    }
    if (s === '2d10') {
        const trilha2d10 = ['1d12', '2d10', '3d10', '4d10', '4d12'];
        const i10 = trilha2d10.indexOf(s);
        return trilha2d10[Math.max(0, Math.min(trilha2d10.length - 1, i10 + p))];
    }
    const idx = trilhaPadrao.indexOf(s);
    if (idx === -1) return s;
    return trilhaPadrao[Math.max(0, Math.min(trilhaPadrao.length - 1, idx + p))];
}
function mediaDadoT20JS(dadoStr) {
    const m = String(dadoStr || '1d6').match(/(\d+)d(\d+)/i);
    if (!m) return 3.5;
    return parseInt(m[1], 10) * ((parseInt(m[2], 10) + 1) / 2);
}
window.aumentarPassoDanoT20JS = aumentarPassoDanoT20JS;
window.mediaDadoT20JS = mediaDadoT20JS;

function compilarDescritorNumericoPoderJS(poder) {
    const nm = String((poder && poder.nome) || '').trim();
    const nl = nm.toLowerCase();
    const ef = String((poder && (poder.efeito_resumo || poder.efeito || '')) || '').toLowerCase();
    const d = {
        id_check: slugCheckT20JS(nm),
        nome: nm,
        tipo_alvo: 'GERAL', // DESARMADO | CORPO | DUAS_MAOS | DISTANCIA | FOGO | ESCUDO | MAGIA | GRUPO | PESSOAL | GERAL
        acao: 'PASSIVA',
        custo_pm: 0,
        atq: 0,
        atq_por_atrib: null,
        dano_fixo: 0,
        dano_por_atrib: null,
        dados_extra_media: 0,
        mult_dados_furtivo: 1.0,
        margem_crit: 0,
        mult_crit: 0,
        usa_2d20_melhor: false,
        ataques_extra: 0,
        defesa: 0,
        defesa_por_atrib: null,
        rd: 0,
        pv_por_nivel: 0,
        pm_extra: 0,
        cura_media: 0,
        buff_grupo_atq: 0,
        buff_grupo_dano: 0,
        buff_grupo_def: 0,
        cd_magia: 0,
        acao_livre_magia: false,
        prereq_checks: [],
        condicionalidade: 'SEMPRE_ATIVO', // SEMPRE_ATIVO (100%) | FREQUENTE (80%) | SITUACIONAL (45%) | EXTREMAMENTE_CONDICIONAL (15% geral / 100% nicho)
        fator_aplicabilidade: 1.0,
        nicho_condicional: '',
        motivo_condicional: 'Sempre aplicável em combate geral'
    };

    // Extração determinística de custo em PM e tipo de ação
    const mPm = ef.match(/(\d+)\s*pm/);
    if (mPm) d.custo_pm = Math.min(6, parseInt(mPm[1], 10));
    if (/ação livre|acao livre/.test(ef)) d.acao = 'LIVRE';
    else if (/reação|reacao/.test(ef)) d.acao = 'REACAO';
    else if (/ação de movimento|acao de movimento/.test(ef)) d.acao = 'MOVIMENTO';
    else if (/ação padrão|acao padrao/.test(ef)) d.acao = 'PADRAO';

    // Descritores mecânicos fiéis ao livro Tormenta20 Edição Jogo do Ano
    if (nl === 'estilo de duas mãos') { d.tipo_alvo = 'DUAS_MAOS'; d.dano_fixo = 5; }
    else if (nl === 'ataque poderoso') { d.tipo_alvo = 'CORPO'; d.atq = -2; d.dano_fixo = 5; }
    else if (nl === 'foco em arma') { d.tipo_alvo = 'GERAL'; d.atq = 2; }
    else if (nl === 'especialização em arma') { d.tipo_alvo = 'GERAL'; d.dano_fixo = 2; }
    else if (nl === 'acuidade com arma') { d.tipo_alvo = 'AGIL'; d.atq_por_atrib = 'DES'; d.dano_por_atrib = 'DES'; }
    else if (nl === 'estilo de disparo') { d.tipo_alvo = 'DISPARO'; d.dano_por_atrib = 'DES'; }
    else if (nl === 'estilo de arremesso') { d.tipo_alvo = 'ARREMESSO'; d.dano_fixo = 2; d.atq = 1; }
    else if (nl === 'arremesso potente') { d.tipo_alvo = 'ARREMESSO'; d.atq_por_atrib = 'FOR'; d.prereq_checks = ['check_estilo_de_arremesso']; }
    else if (nl === 'arremesso múltiplo') { d.tipo_alvo = 'ARREMESSO'; d.ataques_extra = 1.0; d.custo_pm = 1; d.prereq_checks = ['check_estilo_de_arremesso']; }
    else if (nl === 'arsenal das profundezas') { d.tipo_alvo = 'ARREMESSO'; d.dano_fixo = 2; d.mult_crit = 1; }
    else if (nl === 'disparo rápido') { d.tipo_alvo = 'DISTANCIA'; d.atq = -2; d.ataques_extra = 1.0; }
    else if (nl === 'disparo preciso') { d.tipo_alvo = 'DISTANCIA'; d.atq = 2; }
    else if (nl === 'mira apurada') { d.tipo_alvo = 'DISTANCIA'; d.atq = 2; d.margem_crit = 2; d.acao = 'MOVIMENTO'; }
    else if (nl === 'estilo de duas armas') { d.tipo_alvo = 'AGIL'; d.atq = -2; d.ataques_extra = 0.85; }
    else if (nl === 'ambidestria') { d.tipo_alvo = 'AGIL'; d.atq = 2; d.prereq_checks = ['check_estilo_de_duas_armas']; }
    else if (nl === 'estilo de uma arma') { d.tipo_alvo = 'AGIL'; d.atq = 2; d.defesa = 2; }
    else if (nl === 'ataque preciso') { d.tipo_alvo = 'AGIL'; d.margem_crit = 2; d.mult_crit = 1; d.prereq_checks = ['check_estilo_de_uma_arma']; }
    else if (nl === 'estilo de arma e escudo') { d.tipo_alvo = 'ESCUDO'; d.defesa = 2; }
    else if (nl === 'bloqueio com escudo') { d.tipo_alvo = 'ESCUDO'; d.rd = 4; d.acao = 'REACAO'; d.custo_pm = 1; }
    else if (nl === 'encouraçado') { d.tipo_alvo = 'PESSOAL'; d.defesa = 2; }
    else if (nl === 'inexpugnável') { d.tipo_alvo = 'PESSOAL'; d.defesa = 2; d.buff_grupo_def = 1; d.prereq_checks = ['check_encouracado']; }
    else if (nl === 'esquiva') { d.tipo_alvo = 'PESSOAL'; d.defesa = 2; }
    else if (nl === 'vitalidade') { d.tipo_alvo = 'PESSOAL'; d.pv_por_nivel = 1; }
    else if (nl === 'vontade de ferro') { d.tipo_alvo = 'PESSOAL'; d.pm_extra = 3; d.buff_grupo_def = 1; }
    else if (nl === 'valentão') { d.tipo_alvo = 'CORPO'; d.atq = 2; d.dano_fixo = 2; }
    else if (nl === 'destruidor') { d.tipo_alvo = 'DUAS_MAOS'; d.dano_fixo = 3; }
    else if (nl === 'golpe pessoal') { d.tipo_alvo = 'GERAL'; d.dados_extra_media = 10.5; d.margem_crit = 2; d.mult_crit = 1; d.usa_2d20_melhor = true; d.custo_pm = 3; }
    // Poderes Gerais Desarmados & Tormenta (JdA p. 127 & p. 137)
    else if (nl === 'estilo desarmado') { d.tipo_alvo = 'DESARMADO'; d.set_dado_desarmado = '1d6'; d.motivo_condicional = 'Regra Oficial JdA (p. 127): muda dano desarmado para 1d6 letal/não letal (não soma +1 passo com Briga).'; }
    else if (nl === 'corpo aberrante') { d.tipo_alvo = 'DESARMADO'; d.passos_desarmado = 1; d.motivo_condicional = 'Regra Oficial JdA (p. 137): +1 passo no dano desarmado (+1 a cada 4 outros poderes da Tormenta).'; }
    // Lutador (Desarmado)
    else if (nl === 'trocação') { d.tipo_alvo = 'DESARMADO'; d.ataques_extra = 1.05; d.custo_pm = 3.5; d.condicionalidade = 'FREQUENTE'; d.fator_aplicabilidade = 0.85; d.motivo_condicional = 'Regra Oficial JdA (p. 77): exige acertar o golpe anterior e tem custo cumulativo crescente (+1 PM, +2 PM, +3 PM...).'; }
    else if (nl === 'braços calejados') { d.tipo_alvo = 'DESARMADO'; d.defesa_por_atrib = 'FOR'; }
    else if (nl === 'golpe imprudente') { d.tipo_alvo = 'DESARMADO'; d.dados_extra_media = 4.5; d.defesa = -2; }
    else if (nl === 'até acertar') { d.tipo_alvo = 'DESARMADO'; d.atq = 2; d.dano_fixo = 3; }
    else if (nl === 'lutador de chão') { d.tipo_alvo = 'DESARMADO'; d.atq = 2; d.dano_fixo = 2; }
    else if (nl === 'rasteira') { d.tipo_alvo = 'DESARMADO'; d.atq = 2; d.custo_pm = 1; }
    else if (nl === 'voadora') { d.tipo_alvo = 'DESARMADO'; d.dados_extra_media = 3.5; d.custo_pm = 1; }
    else if (nl === 'trincado') { d.tipo_alvo = 'DESARMADO'; d.dano_por_atrib = 'CON'; }
    // Ladino
    else if (nl === 'assassinar') { d.tipo_alvo = 'AGIL'; d.mult_dados_furtivo = 2.0; d.custo_pm = 3; d.acao = 'MOVIMENTO'; }
    else if (nl === 'emboscar') { d.tipo_alvo = 'AGIL'; d.ataques_extra = 0.55; d.custo_pm = 2; }
    else if (nl === 'velocidade ladina') { d.tipo_alvo = 'PESSOAL'; d.defesa = 1; d.atq = 1; d.custo_pm = 2; }
    else if (nl === 'rolamento defensivo') { d.tipo_alvo = 'PESSOAL'; d.rd = 8; d.acao = 'REACAO'; d.custo_pm = 2; }
    else if (nl === 'sombra') { d.tipo_alvo = 'AGIL'; d.atq = 2; }
    // Inventor
    else if (nl === 'armeiro') { d.tipo_alvo = 'CORPO'; d.atq_por_atrib = 'INT'; d.dano_por_atrib = 'INT'; }
    else if (nl === 'balística') { d.tipo_alvo = 'DISTANCIA'; d.atq_por_atrib = 'INT'; d.dano_por_atrib = 'INT'; }
    else if (nl === 'ajuste de mira') { d.tipo_alvo = 'DISTANCIA'; d.atq = 2; d.dano_fixo = 3; d.acao = 'MOVIMENTO'; d.custo_pm = 1; }
    else if (nl === 'cano raiado') { d.tipo_alvo = 'DISTANCIA'; d.margem_crit = 1; }
    else if (nl === 'couraceiro') { d.tipo_alvo = 'PESSOAL'; d.defesa_substitui_des = 'INT'; d.bloqueado_armadura_pesada = true; }
    else if (nl === 'blindagem') { d.tipo_alvo = 'PESSOAL'; d.defesa_por_atrib = 'INT'; d.requer_armadura_pesada = true; }
    else if (nl === 'braços calejados') { d.tipo_alvo = 'PESSOAL'; d.defesa_por_atrib = 'FOR'; d.bloqueado_armadura_pesada = true; }
    else if (nl === 'engenhoqueiro') { d.tipo_alvo = 'MAGIA'; d.dados_extra_media = 12.0; d.buff_grupo_def = 2; d.cd_magia = 2; }
    else if (nl === 'alquimista iniciado') { d.tipo_alvo = 'GERAL'; d.cura_media = 9.0; d.dados_extra_media = 7.0; }
    else if (nl === 'maestria em perícia') { d.tipo_alvo = 'GERAL'; d.atq = 2; d.custo_pm = 1; }
    // Bárbaro
    else if (nl === 'frenesi') { d.tipo_alvo = 'CORPO'; d.ataques_extra = 1.0; d.custo_pm = 2; }
    else if (nl === 'alma de bronze') { d.tipo_alvo = 'PESSOAL'; d.pv_por_nivel = 1.5; }
    else if (nl === 'sangue dos inimigos') { d.tipo_alvo = 'CORPO'; d.atq = 2; d.dano_fixo = 3; }
    else if (nl === 'crítico brutal') { d.tipo_alvo = 'CORPO'; d.mult_crit = 1; }
    else if (nl === 'golpe poderoso') { d.tipo_alvo = 'CORPO'; d.dados_extra_media = 5.5; d.custo_pm = 1; }
    else if (nl === 'espírito inquebrável') { d.tipo_alvo = 'PESSOAL'; d.rd = 5; }
    // Paladino
    else if (nl.includes('iluminação')) { d.tipo_alvo = 'GERAL'; d.pm_extra = 8; d.custo_pm = 1; }
    else if (nl.includes('vindicação')) { d.tipo_alvo = 'GERAL'; d.atq = 2; d.dano_fixo = 4; d.custo_pm = 1; }
    else if (nl === 'arma sagrada') { d.tipo_alvo = 'CORPO'; d.dados_extra_media = 4.5; }
    else if (nl === 'aura de cura') { d.tipo_alvo = 'GRUPO'; d.cura_media = 10.0; d.buff_grupo_def = 2; }
    else if (nl === 'aura poderosa') { d.tipo_alvo = 'GRUPO'; d.buff_grupo_def = 3; }
    // Nobre & Bardo (Suporte & Grupo)
    else if (nl === 'inspirar confiança') { d.tipo_alvo = 'GRUPO'; d.buff_grupo_atq = 2.5; d.buff_grupo_def = 2; d.custo_pm = 2; }
    else if (nl === 'palavras afiadas') { d.tipo_alvo = 'GERAL'; d.dados_extra_media = 10.5; d.custo_pm = 2; }
    else if (nl === 'voz poderosa') { d.tipo_alvo = 'GRUPO'; d.buff_grupo_atq = 1.5; d.buff_grupo_dano = 2.0; }
    else if (nl === 'liderar pelo exemplo') { d.tipo_alvo = 'GRUPO'; d.buff_grupo_atq = 2.0; d.buff_grupo_dano = 2.5; d.custo_pm = 2; }
    else if (nl === 'armadura brilhante') { d.tipo_alvo = 'PESSOAL'; d.defesa_por_atrib = 'CAR'; }
    else if (nl === 'esgrima mágica') { d.tipo_alvo = 'AGIL'; d.atq_por_atrib = 'CAR'; }
    else if (nl === 'prestidigitação') { d.tipo_alvo = 'MAGIA'; d.acao_livre_magia = true; d.custo_pm = 2; }
    else if (nl === 'golpe mágico') { d.tipo_alvo = 'AGIL'; d.pm_extra = 8; }
    else if (nl === 'inspiração marcial') { d.tipo_alvo = 'GRUPO'; d.buff_grupo_dano = 3.0; }
    else if (nl === 'melodia curativa') { d.tipo_alvo = 'GRUPO'; d.cura_media = 9.0; d.custo_pm = 1; }
    // Conjuradores & Druida
    else if (nl === 'magia acelerada') { d.tipo_alvo = 'MAGIA'; d.acao_livre_magia = true; d.dados_extra_media = 14.0; d.custo_pm = 4; }
    else if (nl === 'magia ilimitada') { d.tipo_alvo = 'MAGIA'; d.pm_extra = 2; }
    else if (nl === 'arcano de batalha') { d.tipo_alvo = 'MAGIA'; d.dano_por_atrib = 'INT'; }
    else if (nl === 'fortalecimento arcano') { d.tipo_alvo = 'MAGIA'; d.cd_magia = 2; }
    else if (nl === 'comandar') {
        d.tipo_alvo = 'GRUPO'; d.acao = 'MOVIMENTO'; d.custo_pm = 0.25;
        d.buff_grupo_atq = 1; d.buff_grupo_dano = 0; d.buff_grupo_def = 0;
        d.condicionalidade = 'FREQUENTE'; d.fator_aplicabilidade = 0.85;
        d.motivo_condicional = 'Regra Oficial JdA (p. 129): Ação de movimento + 1 PM/cena para +1 em testes de perícia dos aliados (não soma na Defesa).';
    }
    else if (nl === 'foco em magia') { d.tipo_alvo = 'MAGIA'; d.pm_extra = 2; d.custo_pm = -0.5; }
    else if (nl === 'poder mágico') { d.tipo_alvo = 'MAGIA'; d.pm_extra = 6; }
    else if (nl === 'prece de combate') { d.tipo_alvo = 'GRUPO'; d.buff_grupo_atq = 1.5; d.cura_media = 8.0; d.custo_pm = 2; }
    else if (nl === 'forma selvagem') { d.tipo_alvo = 'ARMA_NATURAL'; d.atq = 2; d.dano_fixo = 4; d.dados_extra_media = 5.5; d.defesa = 2; d.custo_pm = 0.75; }
    else if (nl === 'forma selvagem aprimorada') { d.tipo_alvo = 'ARMA_NATURAL'; d.atq = 3; d.dano_fixo = 6; d.ataques_extra = 0.5; d.defesa = 3; d.prereq_checks = ['check_forma_selvagem']; d.custo_pm = 1.5; }
    else if (nl === 'magia natural') { d.tipo_alvo = 'MAGIA'; d.dados_extra_media = 8.0; d.cura_media = 6.0; d.prereq_checks = ['check_forma_selvagem']; }
    else if (nl === 'aspecto do verão') { d.tipo_alvo = 'CORPO'; d.dados_extra_media = 3.5; d.pm_extra = 4; }
    else if (nl === 'aumento de atributo') { d.tipo_alvo = 'GERAL'; d.atq = 1; d.dano_fixo = 1; d.defesa = 0.5; d.cd_magia = 1; }
    // Descritores reais de Poderes Concedidos & Origens (fim do empate alfabético em Aharadak / Aristocrata!)
    else if (nl === 'armas da ambição') { d.tipo_alvo = 'GERAL'; d.atq = 1; d.margem_crit = 1; d.custo_pm = 0; }
    else if (nl === 'sangue de ferro') { d.tipo_alvo = 'GERAL'; d.dano_fixo = 2; d.rd = 5; d.custo_pm = 0.75; d.fator_aplicabilidade = 0.85; } // 3 PM + ação de ativação
    else if (nl === 'espada justiceira') { d.tipo_alvo = 'CORPO'; d.dados_extra_media = 3.5; d.custo_pm = 0.25; } // 1 PM por CENA
    else if (nl === 'kiai divino') { d.tipo_alvo = 'CORPO'; d.dados_extra_media = 8.5; d.custo_pm = 2.0; }
    else if (nl === 'espada solar') { d.tipo_alvo = 'CORPO'; d.dados_extra_media = 3.5; d.custo_pm = 0.25; d.condicionalidade = 'FREQUENTE'; d.fator_aplicabilidade = 0.80; d.motivo_condicional = 'Frequente (80%): +1d6 fogo apenas em armas cortantes.'; }
    else if (nl === 'coragem total') { d.tipo_alvo = 'PESSOAL'; d.buff_grupo_def = 1; d.defesa = 1; }
    else if (nl === 'bênção do mana' || nl === 'bencao do mana') { d.tipo_alvo = 'MAGIA'; d.pm_extra = 6; }
    else if (nl === 'centelha mágica' || nl === 'centelha magica') { d.tipo_alvo = 'MAGIA'; d.dados_extra_media = 4.5; d.pm_extra = 2; }
    else if (nl === 'teurgista místico' || nl === 'teurgista mistico') { d.tipo_alvo = 'MAGIA'; d.cd_magia = 1; d.cura_media = 6.0; }
    else if (nl === 'dom da esperança' || nl === 'dom da esperanca') { d.tipo_alvo = 'PESSOAL'; d.pv_por_nivel = 1.5; }
    else if (nl === 'aura de cura' || nl === 'cura gentil') { d.tipo_alvo = 'GRUPO'; d.cura_media = 8.5; }
    else if (nl === 'fulgor solar') { d.tipo_alvo = 'PESSOAL'; d.defesa = 1.0; d.custo_pm = 0.25; d.condicionalidade = 'FREQUENTE'; d.fator_aplicabilidade = 0.75; d.motivo_condicional = 'Frequente (75%): impõe Ofuscado (-2 ataque inimigo) ao emitir luz; não causa dano direto.'; }
    else if (nl === 'voz da civilização' || nl === 'mente analítica' || nl === 'conhecimento enciclopédico') { d.tipo_alvo = 'MAGIA'; d.cd_magia = 1; d.pm_extra = 2; }
    else if (nl === 'dom da ressurreição' || nl === 'dom da imortalidade') { d.tipo_alvo = 'GRUPO'; d.buff_grupo_def = 3; d.cura_media = 8.0; }
    else if (nl === 'armadura óssea' || nl === 'armadura ossea') {
        d.tipo_alvo = 'PESSOAL'; d.rd = 5;
        d.condicionalidade = 'SITUACIONAL'; d.fator_aplicabilidade = 0.50;
        d.motivo_condicional = 'Situacional (50%): RD 5 apenas contra corte, frio e perfuração (não reduz impacto, fogo, ácido, eletricidade ou essência).';
    }
    else if (nl === 'afinidade com a tormenta') {
        d.tipo_alvo = 'PESSOAL'; d.defesa = 2.0; d.rd = 5;
        d.condicionalidade = 'EXTREMAMENTE_CONDICIONAL'; d.fator_aplicabilidade = 0.15; d.nicho_condicional = 'TORMENTA';
        d.motivo_condicional = 'Extremamente Condicional: bônus completo apenas contra criaturas/efeitos da Tormenta (15% no caso geral; 100% em RL contra a Tormenta).';
    }
    else if (nl === 'percepção temporal' || nl === 'rejeição divina' || nl === 'inimigo de criatura') {
        d.tipo_alvo = 'PESSOAL'; d.defesa = 1.5; d.atq = 1.5;
        d.condicionalidade = 'EXTREMAMENTE_CONDICIONAL'; d.fator_aplicabilidade = 0.20; d.nicho_condicional = 'NICHO';
        d.motivo_condicional = 'Extremamente Condicional: depende de tipo específico de inimigo ou gatilho raro.';
    }
    else if (nl === 'sangue azul') {
        d.tipo_alvo = 'PESSOAL'; d.buff_grupo_def = 1.0;
        d.condicionalidade = 'EXTREMAMENTE_CONDICIONAL'; d.fator_aplicabilidade = 0.15; d.nicho_condicional = 'SOCIAL';
        d.motivo_condicional = 'Extremamente Condicional: benefício puramente social/nobreza fora de combate.';
    }
    else if (nl === 'sortudo') { d.tipo_alvo = 'GERAL'; d.atq = 1.2; d.buff_grupo_def = 1; d.custo_pm = 3; }
    else if (nl === 'reflexos de combate') { d.tipo_alvo = 'GERAL'; d.atq = 1; d.defesa = 1; }
    else if (nl === 'saque rápido' || nl === 'saque rapido') { d.tipo_alvo = 'DISTANCIA'; d.atq = 1; d.ataques_extra = 0.2; }
    else if (nl === 'sentidos aguçados' || nl === 'sentidos agucados') { d.tipo_alvo = 'GERAL'; d.defesa = 1; d.atq = 0.5; }
    else if (nl === 'torcida') { d.tipo_alvo = 'GERAL'; d.atq = 1.5; d.dano_fixo = 1.5; }
    else if (nl === 'venefício' || nl === 'veneficio') { d.tipo_alvo = 'AGIL'; d.dados_extra_media = 4.5; }
    else if (nl === 'membro da igreja' || nl === 'cura pelos bosques') { d.tipo_alvo = 'GRUPO'; d.cura_media = 5.0; }
    else {
        // Parser genérico baseado no texto oficial do poder para poderes não listados explicitamente
        const mAtq = ef.match(/\+(\d+)\s*(?:em testes de ataque|no ataque|em ataque)/);
        if (mAtq) d.atq = parseInt(mAtq[1], 10);
        const mDano = ef.match(/\+(\d+)\s*(?:nas rolagens de dano|no dano|de dano)/);
        if (mDano) d.dano_fixo = parseInt(mDano[1], 10);
        const mDef = ef.match(/\+(\d+)\s*(?:na defesa|em defesa)/);
        if (mDef) d.defesa = parseInt(mDef[1], 10);
        const mRd = ef.match(/(?:rd|redução de dano)\s*(\d+)/);
        if (mRd) d.rd = parseInt(mRd[1], 10);
        const mCd = ef.match(/\+(\d+)\s*(?:na cd|em cd)/);
        if (mCd) d.cd_magia = parseInt(mCd[1], 10);
        if (/cura|pv/.test(ef) && /\d+d\d+/.test(ef)) d.cura_media = 6.5;
        if (/aliado/.test(ef) && /\+\d+/.test(ef)) { d.tipo_alvo = 'GRUPO'; d.buff_grupo_atq = 1.0; d.buff_grupo_def = 1.0; }
    }
    // Classificação automática de condicionalidade para poderes frequentes ou situacionais
    if (d.condicionalidade === 'SEMPRE_ATIVO') {
        if (['valentão', 'assassinar', 'emboscar', 'sombra', 'rasteira', 'voadora', 'lutador de chão', 'torcida'].includes(nl)) {
            d.condicionalidade = 'FREQUENTE'; d.fator_aplicabilidade = 0.80;
            d.motivo_condicional = 'Frequente (80%): depende de posicionamento tático (flanquear, caído, desprevenido ou 1º turno).';
        } else if (['venefício', 'voz da civilização', 'mente analítica', 'membro da igreja', 'cura pelos bosques'].includes(nl) || /contra mortos-vivos|contra lefeu|contra a tormenta|subterrâneo|floresta|pântano/.test(ef)) {
            d.condicionalidade = 'SITUACIONAL'; d.fator_aplicabilidade = 0.45;
            d.motivo_condicional = 'Situacional (45%): depende de terreno, preparação prévia ou tipo específico de encontro.';
        }
    }
    return d;
}

// 3. Avaliador Matemático Puro v72 (DPR Esperado com Crítico/2d20 + EHP + Suporte em Grupo + Economia de PM)
function avaliarBuildNumericaDescritoresV72JS(est, poderes, magias, arma, arquetipo, nivel, classeObj, escudo, perfilOverride, modoArsenal) {
    const nv = Math.max(1, Number(nivel || 6));
    const cls = classeObj ? (classeObj.nome || '').toLowerCase() : 'guerreiro';
    const atr = (est && est.finais) ? est.finais : { FOR: 3, DES: 2, CON: 2, INT: 1, SAB: 1, CAR: 1 };
    const checks = construirVetorChecksFichaJS({ classe: classeObj, paresClasses: est ? est.paresClasses : [], arma, escudo, poderes, magias });

    // Cálculo 100% intrínseco às estatísticas do personagem — ZERO valores de inimigo!

    // Dano base da arma (ou Briga do Lutador)
    let armaDadoMedia = 4.5;
    let armaMargemBase = 20;
    let armaMultBase = 2;
    if (checks.has('check_arma_desarmada')) {
        const podListL = (poderes || []).map(p => String((p && p.nome) || '').toLowerCase());
        const temEstiloDes = podListL.includes('estilo desarmado');
        const temCorpoAber = podListL.includes('corpo aberrante');
        const qtdTormenta = podListL.filter(n => ['corpo aberrante', 'carapaça', 'empunhadura rubra', 'visco rubro', 'dentes afiados', 'membros extras', 'membros estendidos', 'pele corrompida', 'sangue ácido', 'anatomia insana', 'antenas', 'olhos vermelhos'].includes(n)).length;
        // Regra Oficial JdA: Desarmado padrão = 1d3 (não letal); Estilo Desarmado = 1d6 letal (NÃO acumula com Briga!); Briga (Lutador) = 1d6/1d8/1d10/1d12/2d10
        let dadoDesarm = '1d3';
        if (cls === 'lutador') {
            dadoDesarm = nv < 5 ? '1d6' : (nv < 9 ? '1d8' : (nv < 13 ? '1d10' : (nv < 17 ? '1d12' : '2d10')));
        } else if (temEstiloDes) {
            dadoDesarm = '1d6';
        }
        // Corpo Aberrante (JdA p. 137): +1 passo (+1 passo a cada 4 outros poderes da Tormenta)
        if (temCorpoAber) {
            const passosCA = 1 + Math.floor(Math.max(0, qtdTormenta - 1) / 4);
            dadoDesarm = aumentarPassoDanoT20JS(dadoDesarm, passosCA);
        }
        armaDadoMedia = mediaDadoT20JS(dadoDesarm);
    } else if (arma && arma.dano_ou_defesa) {
        const mD = String(arma.dano_ou_defesa).match(/(\d+)d(\d+)/i);
        if (mD) armaDadoMedia = parseInt(mD[1], 10) * ((parseInt(mD[2], 10) + 1) / 2);
        const crStr = String(arma.critico_ou_penalidade || '20/x2');
        const mM = crStr.match(/(\d+)\s*\//);
        if (mM) armaMargemBase = parseInt(mM[1], 10);
        const mX = crStr.match(/x(\d+)/i);
        if (mX) armaMultBase = parseInt(mX[1], 10);
    }

    // Atributo base de ataque e dano
    const bonusTreino = Math.floor(nv / 2) + (nv < 7 ? 2 : (nv < 15 ? 4 : 6));
    let atqBase = bonusTreino + (checks.has('check_arma_distancia') ? (atr.DES || 0) : (atr.FOR || 0));
    // Regra Oficial JdA (Cap. 3): armas de arremesso somam FOR nas rolagens de dano nativamente; disparo não.
    let danoFixo = (checks.has('check_arma_distancia') && !checks.has('check_arma_arremesso')) ? 0 : Math.max(0, atr.FOR || 0);
    let dadosExtra = 0;
    let margemCrit = armaMargemBase;
    let multCrit = armaMultBase;
    let ataquesPorRodada = 1.0;
    let usa2d20 = false;
    let defTotal = (est && est.defesa) ? est.defesa : (10 + Math.max(0, atr.DES || 0));
    let rdTotal = 0;
    let pvTotal = (est && est.pvMax) ? est.pvMax : 40;
    let pmTotal = (est && est.pmMax) ? est.pmMax : 15;
    let curaMedia = 0;
    let buffGrpAtq = 0, buffGrpDano = 0, buffGrpDef = 0;
    let cdBonus = 0;
    let pmPorRodada = 0;

    const usaArmPesadaEval = Boolean(est && est.armadura && String(est.armadura.subcategoria || '').toLowerCase().includes('pesada'));
    const estJaCalculouDef = Boolean(est && est.defesa !== undefined);

    // Habilidades fixas de classe (respeitando bloqueio de Armadura Pesada e sem duplicar est.defesa)
    if (cls === 'lutador') {
        if (!estJaCalculouDef && !usaArmPesadaEval && nv >= 2) defTotal += Math.max(0, atr.CON || 0);
        if (checks.has('check_arma_desarmada')) { ataquesPorRodada += 1.0; pmPorRodada += 1; }
    }
    if (cls === 'guerreiro') { const ae = 4 * (1 + Math.floor((nv - 1) / 4)); atqBase += ae * 0.5; danoFixo += ae * 0.5; pmPorRodada += 1 + Math.floor((nv - 1) / 4); }
    if (cls === 'bárbaro') { const f = 2 + Math.floor((nv - 1) / 5); atqBase += f; danoFixo += f; pmPorRodada += 0.5; }
    if (cls === 'paladino') {
        atqBase += Math.max(0, atr.CAR || 0);
        dadosExtra += (1 + Math.floor((nv - 1) / 4)) * 4.5;
        if (!estJaCalculouDef && nv >= 5 && escudo) defTotal += Math.max(0, atr.CAR || 0);
        pmPorRodada += 2;
    }
    if (cls === 'ladino') { dadosExtra += Math.floor((nv + 1) / 2) * 3.5; }
    if (cls === 'bucaneiro') {
        if (!estJaCalculouDef && !usaArmPesadaEval) defTotal += Math.min(nv, Math.max(0, atr.CAR || 0));
    }
    if (cls === 'nobre') {
        const ord = 1 + Math.floor((nv - 1) / 4);
        buffGrpAtq += ord; buffGrpDano += ord;
        // Autoconfiança: substitui DES por CAR apenas sem armadura pesada (não soma em cima de DES)
        if (!estJaCalculouDef && !usaArmPesadaEval) {
            defTotal += Math.max(0, (atr.CAR || 0) - Math.max(0, atr.DES || 0));
        }
        pmPorRodada += 2;
    }
    if (cls === 'bardo') { const insp = 1 + Math.floor((nv - 1) / 4); buffGrpAtq += insp; buffGrpDano += insp; atqBase += insp; danoFixo += insp; pmPorRodada += 1; }
    if (cls === 'inventor') { atqBase += Math.max(0, atr.INT || 0); pmPorRodada += 1; }

    let multFurtivo = 1.0;
    let danoMagiaExtra = 0;

    // Soma APENAS descritores compatíveis com os checks da ficha!
    const descritoresAplicados = [];
    for (const pod of (poderes || [])) {
        const d = compilarDescritorNumericoPoderJS(pod);
        if (d.tipo_alvo === 'DESARMADO' && !checks.has('check_arma_desarmada')) continue;
        if (d.tipo_alvo === 'ARMA_NATURAL' && !checks.has('check_arma_natural') && (d.nome || '').toLowerCase() !== 'forma selvagem') continue;
        if ((d.nome || '').toLowerCase() === 'estilo de uma arma' && checks.has('check_arma_desarmada')) continue;
        if (d.tipo_alvo === 'DUAS_MAOS' && !checks.has('check_arma_duas_maos')) continue;
        const permiteAtqPodArrem = (d.nome || '').toLowerCase() === 'ataque poderoso' && checks.has('check_arma_arremesso') && checks.has('check_arremesso_potente');
        if (d.tipo_alvo === 'CORPO' && checks.has('check_arma_distancia') && !permiteAtqPodArrem) continue;
        if (d.tipo_alvo === 'DISTANCIA' && !checks.has('check_arma_distancia') && !checks.has('check_arma_arremesso')) continue;
        if (d.tipo_alvo === 'DISPARO' && (!checks.has('check_arma_distancia') || checks.has('check_arma_arremesso'))) continue;
        if (d.tipo_alvo === 'ARREMESSO' && !checks.has('check_arma_arremesso')) continue;
        if (d.tipo_alvo === 'AGIL' && !checks.has('check_arma_agil') && !checks.has('check_arma_desarmada')) continue;
        if (d.tipo_alvo === 'ESCUDO' && !checks.has('check_escudo')) continue;
        if (d.tipo_alvo === 'MAGIA' && !checks.has('check_conjurador') && cls !== 'inventor') continue;
        if (d.prereq_checks.some(req => !checks.has(req))) continue;

        // Pondera o ganho mecânico pela aplicabilidade real (100% se Sempre Ativo ou se nicho == contexto ativo ex: TORMENTA!)
        const ctxAtivoV78 = String(window.__CONTEXTO_OTIMIZACAO_V78__ || 'GERAL').toUpperCase();
        const fc = (d.nicho_condicional && ctxAtivoV78 === d.nicho_condicional) ? 1.0 : (d.fator_aplicabilidade || 1.0);
        descritoresAplicados.push({ ...d, fatorAplicado: fc });
        atqBase += d.atq * fc;
        if (d.atq_por_atrib) {
            const valA = Math.max(0, atr[d.atq_por_atrib] || 0);
            const baseSub = checks.has('check_arma_distancia') ? (atr.DES || 0) : (atr.FOR || 0);
            atqBase += Math.max(1, valA - baseSub + 1) * fc;
        }
        danoFixo += d.dano_fixo * fc;
        if (d.dano_por_atrib) danoFixo += Math.max(0, atr[d.dano_por_atrib] || 0) * fc;
        if (d.tipo_alvo === 'MAGIA') danoMagiaExtra += d.dados_extra_media * fc;
        else dadosExtra += d.dados_extra_media * fc;
        if (d.mult_dados_furtivo > multFurtivo) multFurtivo = 1.0 + (d.mult_dados_furtivo - 1.0) * fc;
        margemCrit = Math.max(12, margemCrit - d.margem_crit * fc);
        multCrit += d.mult_crit * fc;
        if (d.usa_2d20_melhor) usa2d20 = true;
        ataquesPorRodada += d.ataques_extra * fc;
        defTotal += d.defesa * fc;
        if (d.defesa_substitui_des && !usaArmPesadaEval && !estJaCalculouDef) {
            defTotal += Math.max(0, (atr[d.defesa_substitui_des] || 0) - Math.max(0, atr.DES || 0)) * fc;
        }
        if (d.defesa_por_atrib && !estJaCalculouDef) {
            const bloqPes = Boolean(d.bloqueado_armadura_pesada && usaArmPesadaEval);
            const faltaPes = Boolean(d.requer_armadura_pesada && !usaArmPesadaEval);
            if (!bloqPes && !faltaPes) defTotal += Math.max(0, atr[d.defesa_por_atrib] || 0) * fc;
        }
        rdTotal += d.rd * fc;
        pvTotal += d.pv_por_nivel * nv * fc;
        pmTotal += d.pm_extra * fc;
        curaMedia += d.cura_media * fc;
        buffGrpAtq += d.buff_grupo_atq * fc;
        buffGrpDano += d.buff_grupo_dano * fc;
        buffGrpDef += d.buff_grupo_def * fc;
        cdBonus += d.cd_magia * fc;
        pmPorRodada += d.custo_pm * fc;
    }

    if (cls === 'ladino' && multFurtivo > 1.0) {
        dadosExtra += Math.floor((nv + 1) / 2) * 3.5 * (multFurtivo - 1.0);
    }

    // Avalia magias ANTES de dprMarcial (para 2d20/Velocidade funcionarem) e aplica Regra Oficial de Acúmulo de Magias (T20 JdA p. 226: bônus da mesma fonte NÃO somam — usa-se o MAIOR!)
    let melhorDprMagiaReal = 0;
    let melhorPmBurstMagia = 1;
    let maxDefMagia = 0, maxRdMagia = 0, maxBuffAtqMag = 0, maxBuffDanoMag = 0, maxBuffDefMag = 0, maxAtqExtraMag = 0;
    let pmBuffMag = 0;
    for (const mg of (magias || [])) {
        const dm = (typeof compilarDescritorMagiaEAprimoramentoV73JS === 'function')
            ? compilarDescritorMagiaEAprimoramentoV73JS(mg, nv, classeObj, atr, poderes, [], est ? est.caminhoArcanista : null)
            : null;
        if (!dm) continue;
        // Regra Oficial JdA (p. 170): Magia Arcana de Tatuagem Mística/Centelha em não-conjurador com armadura sofre Falha de Conjuração Arcana (Misticismo CD 20+PM) sem Magia Discreta!
        const ehArcana = String((mg && mg.tipo) || "Arcana").toLowerCase() !== "divina";
        const temMagDiscreta = (poderes || []).some(p => String((p && p.nome) || "").toLowerCase() === "magia discreta");
        // Regra Oficial JdA (p. 40 & p. 133): em Fúria (Bárbaro ou Fúria Divina) NÃO é possível lançar magias!
        const emFuriaV89 = cls === 'bárbaro' || cls === 'barbaro' || (poderes || []).some(p => String((p && p.nome) || '').toLowerCase() === 'fúria divina');
        if (emFuriaV89) continue;
        const ehClasseConj = ["arcanista", "bardo", "clérigo", "clerigo", "druida"].includes(cls);
        const falhaArmadura = !ehClasseConj && ehArcana && !temMagDiscreta && cls !== "lutador";
        if (falhaArmadura) continue;
        if (dm.dprEsperado > melhorDprMagiaReal) {
            melhorDprMagiaReal = dm.dprEsperado;
            melhorPmBurstMagia = Math.max(1, dm.pmBurst || 1);
        }
        if (dm.curaEsperada > curaMedia) curaMedia = dm.curaEsperada;
        if (dm.defBonus > maxDefMagia) maxDefMagia = dm.defBonus;
        if (dm.rdBonus > maxRdMagia) maxRdMagia = dm.rdBonus;
        if (dm.usa2d20) { usa2d20 = true; pmBuffMag = Math.max(pmBuffMag, Math.max(1.0, ataquesPorRodada)); }
        if (dm.ataquesExtra > maxAtqExtraMag) { maxAtqExtraMag = dm.ataquesExtra; pmBuffMag = Math.max(pmBuffMag, 0.75); }
        if (dm.buffGrpAtq > maxBuffAtqMag) maxBuffAtqMag = dm.buffGrpAtq;
        if (dm.buffGrpDano > maxBuffDanoMag) maxBuffDanoMag = dm.buffGrpDano;
        if (dm.buffGrpDef > maxBuffDefMag) maxBuffDefMag = dm.buffGrpDef;
    }
    defTotal += Math.min(6, maxDefMagia * 0.55);
    rdTotal += Math.min(15, maxRdMagia * 0.40);
    ataquesPorRodada += maxAtqExtraMag * 0.65;
    buffGrpAtq += maxBuffAtqMag * 0.75;
    buffGrpDano += maxBuffDanoMag * 0.75;
    buffGrpDef += maxBuffDefMag * 0.75;
    pmPorRodada += pmBuffMag;

    // Cálculo de itens mantido À PARTE! Por padrão (`modoArsenal = 'NENHUM'`), avalia apenas o personagem base puro.
    // Quando especificado ('SUPERIOR' | 'MAGICO' | 'AMBOS'), aplica exclusivamente a camada de itens solicitada!
    const modoArsNorm = String(modoArsenal || 'NENHUM').toUpperCase();
    let arsenalV89 = null;
    if (modoArsNorm !== 'NENHUM' && typeof calcularResumoArsenalFiltradoV90JS === 'function') {
        try {
            arsenalV89 = calcularResumoArsenalFiltradoV90JS({
                nivel: nv,
                classe: classeObj,
                arma,
                armadura: (est && est.armadura) || null,
                escudo: escudo || null,
                poderes: poderes || [],
                magias: magias || [],
                arquetipo: arquetipo || 'DPR Máximo (Dano)',
                est: est || { finais: atr }
            }, modoArsNorm);
        } catch (e) { arsenalV89 = null; }
    }
    if (arsenalV89) {
        if (arsenalV89.passosExtrasArma > 0 && arma && arma.dano_ou_defesa && !checks.has('check_arma_desarmada')) {
            const dadoUp = aumentarPassoDanoT20JS(String(arma.dano_ou_defesa).split('/')[0].trim(), arsenalV89.passosExtrasArma);
            armaDadoMedia = Math.max(armaDadoMedia, mediaDadoT20JS(dadoUp));
        }
        atqBase += (arsenalV89.bonusAtqArma || 0);
        danoFixo += (arsenalV89.bonusDanoArma || 0);
        dadosExtra += (arsenalV89.mediaDadosExtrasArma || 0);
        margemCrit = Math.max(12, margemCrit - (arsenalV89.bonusMargemCrit || 0));
        if (arsenalV89.duplicaMargem) {
            const amp = Math.max(1, 21 - margemCrit);
            margemCrit = Math.max(10, 21 - amp * 2);
        }
        multCrit += (arsenalV89.bonusMultCrit || 0);
        if (arsenalV89.veloz) { ataquesPorRodada += 1.0; pmPorRodada += 2.0; }
        defTotal += (arsenalV89.bonusDefesaTotal || 0);
        rdTotal += (arsenalV89.rdArmadura || 0);
        cdBonus += (arsenalV89.bonusCdMagia || 0);
        danoMagiaExtra += (arsenalV89.bonusDanoMagiaMedia || 0);
        pmTotal += (arsenalV89.pmExtraAcessorios || 0);
        pmPorRodada = Math.max(0, pmPorRodada - (arsenalV89.redPmAtaque || 0) * 0.5);
        // Esotéricos/Catalisadores com +Limite de PM e -PM permitem aprimoramentos extras reais de dano (+1d6 = +3.5 por PM adicional sob o teto!)
        const limPmExtraV100 = (arsenalV89.bonusLimitePm || 0);
        const redPmMagV100 = (arsenalV89.redPmMagia || 0);
        if (checks.has('check_conjurador') && (limPmExtraV100 > 0 || redPmMagV100 > 0)) {
            const pmEfetivoExtra = limPmExtraV100 + redPmMagV100 * 0.75;
            danoMagiaExtra += pmEfetivoExtra * 4.5 * Math.min(2.2, 0.7 + nv * 0.075);
            melhorPmBurstMagia = Math.max(1, melhorPmBurstMagia - redPmMagV100 + limPmExtraV100 * 0.5);
        }
    }

    // Sustentabilidade de PM em 4 rodadas (idêntica para marciais e conjuradores!)
    const fatorPM = pmPorRodada > 0 ? Math.min(1.0, pmTotal / Math.max(1, pmPorRodada * 4.0)) : 1.0;
    const fatorPMMagia = melhorDprMagiaReal > 0 ? Math.min(1.0, pmTotal / Math.max(1, melhorPmBurstMagia * 4.0)) : 1.0;

    // Cálculo 100% intrínseco do personagem (média 1d20 = 10.5 | média 2d20 max = 13.825 | chance intrínseca de crítico)
    const mediaDadoD20 = usa2d20 ? 13.825 : 10.5;
    const rolagemAtqMedia = mediaDadoD20 + atqBase;
    const pCrit1 = Math.max(0.05, Math.min(0.50, (21 - margemCrit) / 20.0));
    const pCrit = usa2d20 ? (1 - Math.pow(1 - pCrit1, 2)) : pCrit1;
    const pHit = Math.min(0.95, 0.50 + Math.max(0, rolagemAtqMedia - 10.5) * 0.025);

    const danoNormal = Math.max(1, armaDadoMedia + danoFixo + dadosExtra);
    const danoCritico = (arsenalV89 && arsenalV89.lancinante) ? Math.max(1, (armaDadoMedia + danoFixo + dadosExtra) * multCrit) : Math.max(1, (armaDadoMedia + danoFixo) * multCrit + dadosExtra);
    const danoMedioPorGolpe = (1 - pCrit) * danoNormal + pCrit * danoCritico;
    const fatorPrecisaoProp = 1.0 + Math.max(0, rolagemAtqMedia - 10.5) * 0.032;
    // Aplica cadência real de recarga para Armas de Fogo (Pistola/Mosquete) e Bestas (JdA Cap. 3 pp. 146–149)
    const infoRecV88 = calcularRecargaArmaT20JS(arma, poderes);
    let atqEfetivosRec = ataquesPorRodada;
    if (!infoRecV88.permiteDisparoRapido && (poderes || []).some(p => String((p && p.nome) || '').toLowerCase() === 'disparo rápido')) {
        atqEfetivosRec = Math.max(1.0, atqEfetivosRec - 1.0); // Disparo Rápido exige recarga Livre!
    }
    const fatorRecMov = infoRecV88.acaoEfetiva === 'MOVIMENTO' ? 0.92 : 1.0; // consome Ação de Movimento recarregando
    const dprMarcial = (atqEfetivosRec * infoRecV88.fatorCadencia) * danoMedioPorGolpe * fatorPrecisaoProp * fatorRecMov * (0.65 + 0.35 * fatorPM);

    // Falha de Conjuração Arcana em armadura para não-conjuradores (JdA p. 170)
    const fatorFalhaArcanaNaoConj = (!checks.has('check_conjurador') && defTotal >= 14) ? 0.35 : 1.0;
    // Bônus de CD (Esotérico Poderoso, Catalisador, Manto do Arquimago, Atributo-chave) escala a probabilidade de falha no Teste de Resistência (dano inteiro vs metade no sucesso, JdA p. 171)
    const atribMagKeyV100 = ['clérigo', 'clerigo', 'druida'].includes(cls) ? 'SAB' : (cls === 'bardo' ? 'CAR' : 'INT');
    const cdBaseV100 = 10 + Math.floor(nv / 2) + Math.max(0, (atr && atr[atribMagKeyV100]) || 0);
    const trMedioNdV100 = Math.round(2 + nv * 0.85);
    const pFalhaBaseV100 = Math.max(0.05, Math.min(0.95, (cdBaseV100 - trMedioNdV100 - 1) / 20.0));
    const pFalhaFinalV100 = Math.max(0.05, Math.min(0.95, (cdBaseV100 + cdBonus - trMedioNdV100 - 1) / 20.0));
    const multCdRealV100 = checks.has('check_conjurador') ? ((0.5 + 0.5 * pFalhaFinalV100) / Math.max(0.525, 0.5 + 0.5 * pFalhaBaseV100)) : 1.0;
    const dprMagBaseV100 = Math.max(melhorDprMagiaReal * fatorFalhaArcanaNaoConj, checks.has('check_conjurador') ? (nv * 3.0) : 0);
    const dprMagico = (dprMagBaseV100 * multCdRealV100 + danoMagiaExtra) * (0.45 + 0.55 * fatorPMMagia);
    // Economia de Ações real — no mesmo turno você usa 1 Ação Padrão (ou ataca ou lança magia); só acumula ambos se tiver Prestidigitação ou Magia Acelerada!
    const temAcaoLivreMag = checks.has('check_prestidigitacao') || checks.has('check_magia_acelerada');
    const dprEfetivo = temAcaoLivreMag
        ? (Math.max(dprMarcial, dprMagico) + Math.min(dprMarcial, dprMagico) * 0.40)
        : Math.max(dprMarcial, dprMagico);

    // Sobrevivência Intrínseca (100% PV, Defesa, RD e Resistências do próprio personagem — ZERO dados de inimigo!)
    const bonusPer = (est && est.bonusPericias) ? est.bonusPericias : {};
    const somaResHeroi = (bonusPer['Fortitude'] || 0) + (bonusPer['Reflexos'] || 0) + (bonusPer['Vontade'] || 0);
    const ehDistNaoTanque = checks.has('check_arma_distancia') && !String(arquetipo || '').toLowerCase().includes('tanque');
    const pesoRdTatico = ehDistNaoTanque ? 7.7 : 14.0;
    const ehpTurnos = (pvTotal * (1 + Math.max(0, defTotal - 10) * 0.045) + rdTotal * pesoRdTatico + somaResHeroi * 2.5) / 10.0;

    // Valor de Suporte Intrínseco (baseado apenas nos buffs e curas do personagem)
    const valorSuporte = (buffGrpAtq * 9.0) + (buffGrpDano * 7.5) + (buffGrpDef * 6.5) + (curaMedia * 1.1);

    // ZERO override por nome de classe! Todas as 14 classes são avaliadas com os MESMOS pesos do arquétipo selecionado!
    const arqL = String(perfilOverride || arquetipo || 'Dano Marcial').toLowerCase();
    let wDPR = 4.5, wEHP = 2.0, wSup = 0.25, wMag = 0.35; // Padrão: DPR Máximo (Dano)
    if (arqL.includes('tanque') || arqL.includes('defesa') || arqL.includes('sobreviv')) {
        wDPR = 1.0; wEHP = 15.0; wSup = 0.6; wMag = 0.4;
    } else if (arqL.includes('suporte') || arqL.includes('buff') || arqL.includes('cura') || arqL.includes('divino')) {
        wDPR = 0.8; wEHP = 5.0; wSup = 4.5; wMag = 1.2;
    } else if (arqL.includes('arcano') || arqL.includes('conjurador') || arqL.includes('controle')) {
        wDPR = 2.8; wEHP = 3.0; wSup = 0.8; wMag = 3.2;
    } else if (arqL.includes('qualquer') || arqL.includes('equilibr')) {
        wDPR = 2.8; wEHP = 5.5; wSup = 1.4; wMag = 1.0;
    }

    const scoreTotal = (dprEfetivo * wDPR) + (ehpTurnos * wEHP) + (valorSuporte * wSup) + ((pmTotal * 0.45 + cdBonus * 6.5) * wMag);
    return {
        score: Number(scoreTotal.toFixed(1)),
        dpr: Number(dprEfetivo.toFixed(1)),
        dprMarcial: Number(dprMarcial.toFixed(1)),
        dprMagico: Number(dprMagico.toFixed(1)),
        ehpTurnos: Number(ehpTurnos.toFixed(2)),
        suporte: Number(valorSuporte.toFixed(1)),
        pAcertoPct: Number((pHit * 100).toFixed(1)),
        pCritPct: Number((pCrit * 100).toFixed(1)),
        danoNormal: Number(danoNormal.toFixed(1)),
        danoCritico: Number(danoCritico.toFixed(1)),
        ataquesPorRodada: Number(ataquesPorRodada.toFixed(2)),
        fatorPMPct: Number((fatorPM * 100).toFixed(0)),
        qtdChecksAtivos: checks.size,
        descritoresAtivos: descritoresAplicados.length,
        arsenalAtqBonus: arsenalV89 ? (arsenalV89.bonusAtqArma || 0) : 0,
        arsenalDanoBonus: arsenalV89 ? ((arsenalV89.bonusDanoArma || 0) + (arsenalV89.mediaDadosExtrasArma || 0)) : 0,
        arsenalDefBonus: arsenalV89 ? (arsenalV89.bonusDefesaTotal || 0) : 0,
        arsenalItens: arsenalV89 ? (arsenalV89.itensDescritivos || []) : []
    };
}

// 4. Gera Perfis Multi-Estilo / Fronteira de Pareto (ex.: Druida Forma Selvagem vs Conjurador vs Suporte)
function gerarFronteiraParetoMultiEstiloV72JS(est, poderes, magias, arma, nivel, classeObj, escudo) {
    const perfis = [
        { id: 'DPR', rotulo: 'Máximo DPR / Ofensivo', arq: 'Dano Marcial' },
        { id: 'EQUILIBRADA', rotulo: 'Equilibrada (DPR + Sobrevivência EHP)', arq: 'Tanque: Defesa' },
        { id: 'SUPORTE', rotulo: 'Suporte de Grupo (Buffs + Cura + EHP)', arq: 'Suporte Divino' },
        { id: 'MAGIA', rotulo: 'Conjurador / Controle Arcano', arq: 'Conjurador Arcano' }
    ];
    return perfis.map(pf => ({
        ...pf,
        metricas: avaliarBuildNumericaDescritoresV72JS(est, poderes, magias, arma, pf.arq, nivel, classeObj, escudo, pf.arq)
    })).sort((a, b) => b.metricas.score - a.metricas.score);
}

// 5. Calcula a Importância Marginal de cada Poder (ΔDPR, ΔEHP, ΔSuporte)
function calcularImportanciaFatoresPoderesV72JS(est, poderes, magias, arma, arquetipo, nivel, classeObj, escudo) {
    const baseFull = avaliarBuildNumericaDescritoresV72JS(est, poderes, magias, arma, arquetipo, nivel, classeObj, escudo);
    return (poderes || []).map(pod => {
        const semEste = (poderes || []).filter(p => p.nome !== pod.nome);
        const semMet = avaliarBuildNumericaDescritoresV72JS(est, semEste, magias, arma, arquetipo, nivel, classeObj, escudo);
        return {
            nome: pod.nome,
            deltaScore: Number((baseFull.score - semMet.score).toFixed(1)),
            deltaDpr: Number((baseFull.dpr - semMet.dpr).toFixed(1)),
            deltaEhp: Number((baseFull.ehpTurnos - semMet.ehpTurnos).toFixed(2)),
            deltaSuporte: Number((baseFull.suporte - semMet.suporte).toFixed(1)),
            descritor: compilarDescritorNumericoPoderJS(pod)
        };
    }).sort((a, b) => b.deltaScore - a.deltaScore);
}

window.construirVetorChecksFichaJS = construirVetorChecksFichaJS;
window.compilarDescritorNumericoPoderJS = compilarDescritorNumericoPoderJS;
window.avaliarBuildNumericaDescritoresV72JS = avaliarBuildNumericaDescritoresV72JS;
window.gerarFronteiraParetoMultiEstiloV72JS = gerarFronteiraParetoMultiEstiloV72JS;
window.calcularImportanciaFatoresPoderesV72JS = calcularImportanciaFatoresPoderesV72JS;

function avaliarScoreMCTSClient(est, poderes, magias, arma, validacoes, arquetipo, nivel, classeObj, itens, escudo) {
    const m = avaliarBuildNumericaDescritoresV72JS(est, poderes, magias, arma, arquetipo, nivel, classeObj, escudo);
    let score = m.score;
    if (validacoes && validacoes.length > 0) score -= validacoes.length * 200;
    return Number(score.toFixed(1));
}

async function submeterFormularioHibrido(ev, rota) {
    ev.preventDefault();
    const form = ev.target;
    const formData = new FormData(form);
    if (rota === '/otimizar_ia') {
        executarOtimizadorIAMobileOffline(formData);
    } else if (rota === '/atualizar_manual') {
        executarAtualizacaoManualOffline(formData);
    } else if (rota === '/salvar') {
        salvarFichaLocalStorageOffline();
    }
}

function executarOtimizadorIAMobileOffline(formData, abaDestinoOpcional) {
    const nome = formData.get('nome') || 'Herói Otimizado (IA)';
    const nivel = Math.max(1, Math.min(20, parseInt(formData.get('nivel') || '6', 10)));
    let arquetipo = formData.get('arquetipo') || 'Qualquer';
    const tipoPers = (formData.get('tipo_personagem') || 'TODOS').toUpperCase();
    const funcTat = (formData.get('funcao_tatica') || 'DPS Sustentado').toLowerCase();
    const iteracoes = Math.max(20, Math.min(500, parseInt(formData.get('iteracoes') || '120', 10)));
    const fixRaca = formData.get('fixar_raca') || 'AUTO';
    const fixClasse = formData.get('fixar_classe') || 'AUTO';
    const fixOrigem = formData.get('fixar_origem') || 'AUTO';
    const fixDeus = formData.get('fixar_deus') || 'AUTO';

    if (arquetipo.toLowerCase() === 'qualquer' || arquetipo.toLowerCase() === 'auto') {
        const fcLow = fixClasse.toLowerCase();
        if (fcLow === 'arcanista') arquetipo = 'Conjurador Arcano: Mago';
        else if (fcLow === 'clérigo' || fcLow === 'clerigo') arquetipo = 'Suporte Divino: Clérigo';
        else if (fcLow === 'druida') arquetipo = 'Suporte Divino: Druida';
        else if (fcLow === 'bardo') arquetipo = 'Conjurador: Bardo';
        else if (fcLow === 'paladino') arquetipo = 'Híbrido: Paladino Abençoado';
        else if (fcLow === 'cavaleiro') arquetipo = 'Tanque: Arma e Escudo';
        else if (fcLow === 'caçador' || fcLow === 'cacador') arquetipo = funcTat.includes('explosivo') ? 'Marcial: Dano Arqueiro' : 'Marcial: Duas Armas';
        else if (fcLow === 'bucaneiro' || fcLow === 'ladino') arquetipo = 'Marcial: Uma Mão Duelista';
        else if (tipoPers === 'CONJURADOR' || funcTat.includes('controle')) arquetipo = 'Conjurador Arcano: Mago';
        else if (funcTat.includes('suporte') || funcTat.includes('cura')) arquetipo = 'Suporte Divino: Clérigo';
        else if (funcTat.includes('tanque')) arquetipo = 'Tanque: Arma e Escudo';
        else if (tipoPers === 'HIBRIDO') arquetipo = 'Híbrido: Paladino Abençoado';
        else arquetipo = 'Marcial: Duas Mãos Pesado';
    }
    const arqL = arquetipo.toLowerCase();

    // 1. CSP: Seleção de Classe
    const mapaClasse = {
        'marcial: duas mãos pesado': 'Guerreiro',
        'marcial: armas de haste': 'Guerreiro',
        'marcial: uma mão duelista': 'Bucaneiro',
        'marcial: duas armas': 'Caçador',
        'tanque: arma e escudo': 'Cavaleiro',
        'marcial: dano arqueiro': 'Caçador',
        'dano marcial': 'Guerreiro',
        'dano arqueiro': 'Caçador',
        'tanque / defesa': 'Cavaleiro',
        'conjurador arcano': 'Arcanista',
        'conjurador arcano: mago': 'Arcanista',
        'conjurador arcano: bruxo': 'Arcanista',
        'conjurador arcano: feiticeiro': 'Arcanista',
        'conjurador: bardo': 'Bardo',
        'suporte divino': 'Clérigo',
        'suporte divino: clérigo': 'Clérigo',
        'suporte divino: druida': 'Druida',
        'multiclasse: guerreiro + bárbaro': 'Guerreiro',
        'multiclasse: guerreiro + paladino': 'Guerreiro',
        'multiclasse: guerreiro + arcanista': 'Guerreiro',
        'multiclasse: caçador + ladino': 'Caçador',
        'multiclasse: cavaleiro + clérigo': 'Cavaleiro'
    };
    const nomeClasseAlvo = (fixClasse !== 'AUTO') ? fixClasse : (mapaClasse[arqL] || 'Guerreiro');
    const classeObj = CATALOGO_T20.classes.find(c => c.nome.toLowerCase() === nomeClasseAlvo.toLowerCase()) || CATALOGO_T20.classes[0];

    // Resolução de Multiclasse (Cap. 1, p. 34) no Otimizador IA com 8 Políticas
    let modoMulticlasse = formData.get('modo_multiclasse') || 'AUTO_MCTS';
    let fixClasseSec = formData.get('fixar_classe_secundaria') || 'NENHUMA';
    let nvClasseSec = Math.max(0, parseIntSeguro(formData.get('nivel_classe_secundaria'), 0));
    let fixClasseTerc = formData.get('fixar_classe_terciaria') || 'NENHUMA';
    let nvClasseTerc = Math.max(0, parseIntSeguro(formData.get('nivel_classe_terciaria'), 0));
    if (arqL.includes('multiclasse:')) {
        if (fixClasseSec === 'NENHUMA' || fixClasseSec === 'AUTO') {
            if (arqL.includes('guerreiro + bárbaro')) { fixClasseSec = 'Bárbaro'; nvClasseSec = nivel >= 7 ? 2 : 1; modoMulticlasse = 'MANUAL_FIXA'; }
            else if (arqL.includes('guerreiro + paladino')) { fixClasseSec = 'Paladino'; nvClasseSec = nivel >= 6 ? 2 : 1; modoMulticlasse = 'MANUAL_FIXA'; }
            else if (arqL.includes('guerreiro + arcanista')) { fixClasseSec = 'Arcanista'; nvClasseSec = Math.max(1, nivel - 1); modoMulticlasse = 'MANUAL_FIXA'; }
            else if (arqL.includes('caçador + ladino')) { fixClasseSec = 'Ladino'; nvClasseSec = Math.max(1, Math.floor(nivel / 2)); modoMulticlasse = 'MANUAL_FIXA'; }
            else if (arqL.includes('cavaleiro + clérigo')) { fixClasseSec = 'Clérigo'; nvClasseSec = Math.max(1, nivel - 2); modoMulticlasse = 'MANUAL_FIXA'; }
        }
    }
    let classeSecObj = (fixClasseSec && fixClasseSec !== 'NENHUMA' && fixClasseSec !== 'AUTO' && fixClasseSec.toLowerCase() !== classeObj.nome.toLowerCase())
        ? (CATALOGO_T20.classes.find(c => c.nome.toLowerCase() === fixClasseSec.toLowerCase()) || null)
        : null;
    let classeTercObj = (fixClasseTerc && fixClasseTerc !== 'NENHUMA' && fixClasseTerc !== 'AUTO' && fixClasseTerc.toLowerCase() !== classeObj.nome.toLowerCase())
        ? (CATALOGO_T20.classes.find(c => c.nome.toLowerCase() === fixClasseTerc.toLowerCase()) || null)
        : null;
    if (classeSecObj && nvClasseSec <= 0 && nivel >= 2) nvClasseSec = 1;
    if (!classeSecObj || nivel < 2) nvClasseSec = 0;
    if (classeTercObj && nvClasseTerc <= 0 && nivel >= 3) nvClasseTerc = 1;
    if (!classeTercObj || nivel < 3) nvClasseTerc = 0;
    let paresClassesMCTS = normalizarClassesMulticlasseJS({
        nivel, classe: classeObj, classeSecundaria: classeSecObj, nivelClasseSecundaria: nvClasseSec,
        classeTerciaria: classeTercObj, nivelClasseTerciaria: nvClasseTerc
    });
    let rankingMulticlasseMCTS = [];
    let caminhoArcanista = formData.get('caminho_arcanista') || 'Mago';
    if (arqL.includes('feiticeiro')) caminhoArcanista = 'Feiticeiro';
    else if (arqL.includes('bruxo')) caminhoArcanista = 'Bruxo';
    else if (arqL.includes('mago')) caminhoArcanista = 'Mago';
    const infoMagiaAlvo = obterAtributoChaveMagiaJS(classeObj, caminhoArcanista);
    const atribChave = ['arcanista', 'bardo', 'clérigo', 'clerigo', 'druida'].some(k => classeObj.nome.toLowerCase().includes(k))
        ? infoMagiaAlvo.sigla
        : ((classeObj.atributo_principal || 'FOR').split(' ')[0] || 'FOR').toUpperCase();

    // 2. CSP: Alocação de Atributos Base (10 pontos JdA)
    let atrBase = { FOR: 4, DES: 0, CON: 3, INT: 0, SAB: 0, CAR: -1 };
    let livres = ['FOR', 'CON', 'DES'];
    if (arqL.includes('tanque') || arqL.includes('defesa')) {
        atrBase = (atribChave === 'CAR')
            ? { FOR: 2, DES: 0, CON: 3, INT: 0, SAB: 1, CAR: 3 }
            : { FOR: 2, DES: 1, CON: 4, INT: 0, SAB: 1, CAR: 0 };
        livres = ['CON', 'FOR', 'SAB'];
    } else if (arqL.includes('arcano') || arqL.includes('bardo') || classeObj.nome.toLowerCase() === 'arcanista') {
        if (atribChave === 'CAR') {
            atrBase = { FOR: -1, DES: 2, CON: 2, INT: 1, SAB: 0, CAR: 4 };
            livres = ['CAR', 'DES', 'CON'];
        } else {
            atrBase = { FOR: -1, DES: 2, CON: 2, INT: 4, SAB: 1, CAR: 0 };
            livres = ['INT', 'DES', 'CON'];
        }
    } else if (arqL.includes('suporte') || arqL.includes('divino')) {
        atrBase = { FOR: 1, DES: 0, CON: 2, INT: 0, SAB: 4, CAR: 1 };
        livres = ['SAB', 'CON', 'FOR'];
    } else if (arqL.includes('arqueiro')) {
        atrBase = { FOR: -1, DES: 4, CON: 2, INT: 0, SAB: 2, CAR: 0 };
        livres = ['DES', 'SAB', 'CON'];
    }

    // 3. CSP AC-3: Seleção de Raça
    let podasCSP = 0;
    let altsRaca = [];
    let racaObj = CATALOGO_T20.racas[0];
    const propModChave = 'mod_' + atribChave.toLowerCase();
    if (fixRaca !== 'AUTO') {
        racaObj = CATALOGO_T20.racas.find(r => r.nome.toLowerCase() === fixRaca.toLowerCase()) || CATALOGO_T20.racas[0];
        for (const r of CATALOGO_T20.racas) {
            if (parseIntSeguro(r[propModChave], 0) < 0 && altsRaca.length < 2) {
                altsRaca.push({ nome: r.nome, tipo: 'PODADO_CSP', visitas: 0, motivo: 'Podado AC-3: penaliza ' + atribChave + ' (' + r[propModChave] + ')' });
            }
        }
    } else {
        let melhorScoreR = -999;
        let candidatasBoas = [];
        for (const r of CATALOGO_T20.racas) {
            const modChave = parseIntSeguro(r[propModChave], 0);
            if (modChave < 0) {
                podasCSP++;
                if (altsRaca.length < 2) {
                    altsRaca.push({ nome: r.nome, tipo: 'PODADO_CSP', visitas: 0, motivo: 'Podado AC-3: penaliza ' + atribChave + ' (' + modChave + ')' });
                }
                continue;
            }
            let sc = modChave * 5 + parseIntSeguro(r.mod_con, 0) * 3 + ((r.mod_livre || '').includes('3') ? 4 : 0);
            if (arqL.includes('tanque') && r.nome.toLowerCase() === 'anão') sc += 8;
            if (arqL.includes('arcano') && ['elfo', 'qareen'].includes(r.nome.toLowerCase())) sc += 8;
            candidatasBoas.push({ sc, r });
            if (sc > melhorScoreR) {
                melhorScoreR = sc;
                racaObj = r;
            }
        }
        candidatasBoas.sort((a, b) => b.sc - a.sc);
        for (const item of candidatasBoas.slice(1, 3)) {
            altsRaca.push({ nome: item.r.nome, tipo: 'EXPLORADO_MCTS', visitas: 0, motivo: 'Sinergia racial menor (' + item.sc + ' pts vs ' + melhorScoreR + ' pts)' });
        }
    }

    // 4. CSP: Origem & Divindade (AC-3) — Respeitando Golem (Sem Origem, p. 22) e Osteon (Memória Póstuma, p. 27)
    const nrLowMcts = racaObj.nome.toLowerCase();
    // Avaliação Numérica Global de TODAS as Origens (ZERO lista pré-definida de origens!)
    let origemObj = null;
    let altsOrigemV74 = [];
    if (nrLowMcts === 'golem' || fixOrigem === 'Nenhum') { // Osteon PODE escolher Origem (apenas Golem tem Sem Origem!)
        origemObj = null;
        podasCSP += CATALOGO_T20.origens.length;
    } else if (fixOrigem !== 'AUTO') {
        origemObj = CATALOGO_T20.origens.find(o => o.nome.toLowerCase() === fixOrigem.toLowerCase()) || CATALOGO_T20.origens[0];
    } else {
        const armaRefOrig = (CATALOGO_T20.itens || []).find(i => i.nome.toLowerCase() === String(formData.get('fixar_arma') || '').toLowerCase()) || null;
        const evalOrigens = (CATALOGO_T20.origens || []).map(orig => {
            const infoO = (typeof obterBeneficiosOrigemGolemOsteonJS === 'function')
                ? obterBeneficiosOrigemGolemOsteonJS(racaObj, orig, [], null, arquetipo, [], armaRefOrig, null, classeObj)
                : { poderesExtras: [] };
            const podsO = [...(infoO.poderesExtras || [])];
            if (podsO.length === 0 && orig.poder_unico) {
                podsO.push({ nome: orig.poder_unico, efeito_resumo: orig.efeito_poder_unico || orig.beneficios_poderes || '' });
            }
            const metO = avaliarBuildNumericaDescritoresV72JS({ finais: atrBase, pvMax: 30 + nivel * 5, pmMax: 10 + nivel * 3, defesa: 14 }, podsO, [], armaRefOrig, arquetipo, nivel, classeObj, null);
            // Pequeno bônus por perícia de combate/conjuração útil treinada pela Origem para desempatar com critério mecânico (nunca alfabético!)
            const perO = String(orig.pericias_disponiveis || '').toLowerCase();
            let bonusPerO = 0;
            if (/luta|pontaria|iniciativa|fortitude|vontade|reflexos/.test(perO)) bonusPerO += 0.8;
            if (/furtividade|ladinagem/.test(perO) && classeObj.nome.toLowerCase() === 'ladino') bonusPerO += 1.5;
            if (/ofício|oficio|investigação/.test(perO) && classeObj.nome.toLowerCase() === 'inventor') bonusPerO += 1.5;
            if (/misticismo|religião|cura/.test(perO) && ['arcanista', 'clérigo', 'druida', 'bardo'].includes(classeObj.nome.toLowerCase())) bonusPerO += 1.5;
            if (/diplomacia|nobreza|atuação/.test(perO) && ['nobre', 'bardo'].includes(classeObj.nome.toLowerCase())) bonusPerO += 1.5;
            return { orig, score: Number((metO.score + bonusPerO).toFixed(2)), pods: podsO.map(p => p.nome).join(', ') || 'Perícias' };
        }).sort((a, b) => b.score - a.score);
        origemObj = evalOrigens[0] ? evalOrigens[0].orig : CATALOGO_T20.origens[0];
        altsOrigemV74 = evalOrigens.slice(1, 4).map(x => ({
            nome: x.orig.nome, tipo: 'EXPLORADO_MCTS', visitas: 12,
            motivo: `Avaliação Global de Origens v74: Score ${x.score} (${x.pods}) vs Campeã ${evalOrigens[0].score}`
        }));
    }

    let deusesValidos = [];
    let altsDeus = [];
    for (const d of CATALOGO_T20.deuses) {
        // Se o personagem tem multiclasse (ex.: Arcanista/Paladino ou Guerreiro/Druida), a divindade DEVE ser permitida por TODAS as classes da ficha!
        const permitidoTodasClassesMC = (paresClassesMCTS && paresClassesMCTS.length > 0)
            ? paresClassesMCTS.every(pc => deusPermite(d, racaObj.nome, pc.classeObj.nome))
            : deusPermite(d, racaObj.nome, classeObj.nome);
        if (permitidoTodasClassesMC) {
            deusesValidos.push(d);
        } else {
            podasCSP++;
            if (altsDeus.length < 2) {
                altsDeus.push({ nome: d.nome, tipo: 'PODADO_CSP', visitas: 0, motivo: 'Podado AC-3: exige devoto (' + d.devotos_permitidos + ')' });
            }
        }
    }
    // Avaliação Numérica Global de TODAS as Divindades legais pelo CSP (ZERO lista fixa prefDeus!)
    let deusObj = null;
    if (fixDeus === 'Nenhum') {
        deusObj = null;
    } else if (fixDeus !== 'AUTO') {
        deusObj = deusesValidos.find(d => d.nome.toLowerCase() === fixDeus.toLowerCase()) || deusesValidos[0] || null;
    } else if (deusesValidos.length > 0) {
        const evalDeuses = deusesValidos.map(d => {
            const nomesPodsConced = String(d.poderes_concedidos || '').split(/[,;/]+/).map(s => s.trim()).filter(Boolean);
            const podsObjs = nomesPodsConced.map(np =>
                (CATALOGO_T20.poderes_gerais || []).find(p => p.nome.toLowerCase() === np.toLowerCase())
                || { nome: np, efeito_resumo: d.poderes_concedidos || '' }
            );
            // Escolhe o melhor poder concedido daquela divindade numericamente!
            let melhorScoreD = -999;
            let melhorPodD = nomesPodsConced[0] || '';
            for (const po of podsObjs) {
                const metD = avaliarBuildNumericaDescritoresV72JS({ finais: atrBase, pvMax: 30 + nivel * 5, pmMax: 10 + nivel * 3, defesa: 14 }, [po], [], null, arquetipo, nivel, classeObj, null);
                if (metD.score > melhorScoreD) { melhorScoreD = metD.score; melhorPodD = po.nome; }
            }
            return { deus: d, score: melhorScoreD, melhorPod: melhorPodD };
        }).sort((a, b) => b.score - a.score);
        deusObj = evalDeuses[0].deus;
        altsDeus = [
            ...altsDeus.slice(0, 1),
            ...evalDeuses.slice(1, 3).map(x => ({
                nome: x.deus.nome, tipo: 'EXPLORADO_MCTS', visitas: 12,
                motivo: `Avaliação Global de Divindades v74: Score ${x.score} (${x.melhorPod}) vs Campeã ${evalDeuses[0].score}`
            }))
        ];
    }
    for (const dAlt of deusesValidos.slice(0, 3)) {
        if (deusObj && dAlt.nome !== deusObj.nome && altsDeus.length < 3) {
            altsDeus.push({ nome: dAlt.nome, tipo: 'EXPLORADO_MCTS', visitas: 0, motivo: 'Poderes concedidos com menor sinergia' });
        }
    }

    // 5. Perícias e Equipamentos Iniciais Consistentes
    const periciasFixas = (classeObj.pericias_fixas || '').split(/\s+e\s+|\/|,/i).map(x => x.split('(')[0].split(/\s+ou\s+/i)[0].trim()).filter(Boolean);
    const periciasPrioritarias = ['Luta', 'Fortitude', 'Iniciativa', 'Percepção', 'Vontade', 'Reflexos', 'Atletismo', 'Misticismo', 'Religião', 'Cura'];
    const periciasLista = [...periciasFixas];
    const limitePericias = 2 + parseIntSeguro(classeObj.qtd_pericias_escolha, 2) + Math.max(0, atrBase.INT);
    for (const pExtra of periciasPrioritarias) {
        if (periciasLista.length >= limitePericias) break;
        if (!periciasLista.some(x => x.toLowerCase() === pExtra.toLowerCase())) periciasLista.push(pExtra);
    }

    const acharItem = (n) => CATALOGO_T20.itens.find(i => i.nome.toLowerCase() === n.toLowerCase()) || null;
    const atrOvV73Pre = formData.get('_v73_atr_override');
    const livOvV73Pre = formData.get('_v73_livres_override');
    if (atrOvV73Pre) { try { atrBase = JSON.parse(atrOvV73Pre); } catch(e) {} }
    if (livOvV73Pre) { try { livres = JSON.parse(livOvV73Pre); } catch(e) {} }
    const fixArmaPre = formData.get('fixar_arma') || 'AUTO';
    // Busca dinâmica de Arma, Armadura e Escudo sobre TODO o catálogo proficiente (zero lista fixa por classe!)
    const eqDin = buscarMelhorEquipamentoDinamicoV80JS(classeObj, racaObj, deusObj, atrBase, livres, nivel, arquetipo, fixArmaPre);
    let armaEq = eqDin.armaEq, armaduraEq = eqDin.armaduraEq, escudoEq = eqDin.escudoEq, itensInv = eqDin.itensInv;
    // Otimiza a distribuição exata de 10 pontos JdA especializada na arma/classe/arquétipo (sem diluir FOR e DES!)
    if (typeof otimizarDistribuicao10PontosJdAV83JS === 'function') {
        const optAtrV83 = otimizarDistribuicao10PontosJdAV83JS(classeObj, racaObj, armaEq, arquetipo, nivel, caminhoArcanista, atrBase);
        atrBase = optAtrV83.atrBase;
        livres = optAtrV83.livres;
    }
    if (armaEq && /distância|distancia|fogo/.test(String(armaEq.subcategoria || '').toLowerCase()) && !periciasLista.includes('Pontaria')) {
        periciasLista.unshift('Pontaria');
    }
    // atrBase já otimizado em 10 pontos JdA especializados acima!
    const fixArma = formData.get('fixar_arma') || 'AUTO';
    if (fixArma && fixArma !== 'AUTO') {
        const armaForcada = acharItem(fixArma) || {
            id_item: 'ARMA_CUSTOM',
            nome: fixArma,
            categoria: 'Arma',
            subcategoria: fixArma.toLowerCase().includes('arco') || fixArma.toLowerCase().includes('besta') ? 'Arma Marcial à Distância' : (fixArma.toLowerCase().includes('mosquete') || fixArma.toLowerCase().includes('pistola') ? 'Arma de Fogo' : 'Arma Marcial Corpo a Corpo — Duas Mãos'),
            preco: 'T$ 50',
            dano_ou_defesa: fixArma.toLowerCase().includes('táurico') || fixArma.toLowerCase().includes('mosquete') ? '2d8' : (fixArma.toLowerCase().includes('marreta') ? '3d4' : (fixArma.toLowerCase().includes('gadanho') ? '2d4' : '1d10')),
            critico_ou_penalidade: fixArma.toLowerCase().includes('gadanho') ? 'x4' : (fixArma.toLowerCase().includes('táurico') || fixArma.toLowerCase().includes('machado') ? 'x3' : '19/x2'),
            espacos: 2,
            efeito_propriedades: fixArma.toLowerCase().includes('alabarda') ? 'Alongada' : 'Personalizada pelo jogador'
        };
        armaEq = armaForcada;
        if (!itensInv.includes(armaEq)) itensInv.unshift(armaEq);
    }

    // 5B. Otimização MCTS da Combinação de Classes / Multiclasse conforme `modoMulticlasse`
    let candsMC = gerarCandidatosMulticlassePorPoliticaJS(
        classeObj, nivel, arquetipo, modoMulticlasse,
        classeSecObj ? classeSecObj.nome : 'NENHUMA', nvClasseSec,
        classeTercObj ? classeTercObj.nome : 'NENHUMA', nvClasseTerc
    );
    // Filtro estrito de tipo_personagem na MULTICLASSE (MARCIAL não permite Arcanista/Clérigo/Druida/Bardo!)
    const permitTipoMC = (tipoPers === 'MARCIAL' || arquetipo.toLowerCase().startsWith('marcial:'))
        ? new Set(['guerreiro', 'bárbaro', 'caçador', 'ladino', 'bucaneiro', 'cavaleiro', 'lutador'])
        : (tipoPers === 'CONJURADOR'
            ? new Set(['arcanista', 'clérigo', 'druida', 'bardo'])
            : (tipoPers === 'HIBRIDO'
                ? new Set(['paladino', 'inventor', 'nobre', 'bardo', 'druida'])
                : null));
    if (permitTipoMC) {
        const filtrados = candsMC.filter(c => [c.classe, c.classeSecundaria, c.classeTerciaria].filter(Boolean).every(co => permitTipoMC.has(String(co.nome || '').toLowerCase())));
        if (filtrados.length > 0) candsMC = filtrados;
    }
    // Bloqueia combinação de baixíssima sinergia Mago/Bruxo (INT) + Paladino (CAR) na multiclasse automática
    if (classeObj.nome.toLowerCase() === 'arcanista' && (caminhoArcanista || 'Mago').toLowerCase() !== 'feiticeiro') {
        const semPal = candsMC.filter(c => ![c.classeSecundaria, c.classeTerciaria].filter(Boolean).some(co => String(co.nome || '').toLowerCase() === 'paladino'));
        if (semPal.length > 0) candsMC = semPal;
    }
    rankingMulticlasseMCTS = avaliarRankingMulticlasseMCTSJS({
        nivel, raca: racaObj, classe: classeObj, origem: origemObj, deus: deusObj,
        caminhoArcanista, arquetipo, atrBase, livres, pericias: periciasLista,
        poderes: [], itens: itensInv, arma: armaEq, armadura: armaduraEq, escudo: escudoEq
    }, candsMC);
    if (rankingMulticlasseMCTS.length > 0) {
        const campMC = rankingMulticlasseMCTS[0];
        classeSecObj = campMC.classeSecundaria;
        nvClasseSec = campMC.nivelClasseSecundaria;
        classeTercObj = campMC.classeTerciaria;
        nvClasseTerc = campMC.nivelClasseTerciaria;
        paresClassesMCTS = campMC.paresClasses;
    }

    // 6. Grimório de Magias (prioriza magias de Reação, Ação Livre [Concentração de Combate] e Explosão de Dano!)
    // Revalida divindade após escolha de multiclasse (impede Aharadak/Arsenal se Paladino entrou na multiclasse!)
    if (deusObj && paresClassesMCTS && paresClassesMCTS.some(pc => !deusPermite(deusObj, racaObj.nome, pc.classeObj.nome))) {
        const legaisPosMC = (CATALOGO_T20.deuses || []).filter(d => paresClassesMCTS.every(pc => deusPermite(d, racaObj.nome, pc.classeObj.nome)));
        // Avaliação dinâmica de TODAS as divindades legais pós-multiclasse (sem lista fixa!)
        const atrPosMC = Object.assign({ FOR: 0, DES: 0, CON: 0, INT: 0, SAB: 0, CAR: 0 }, atrBase);
        const estPosMC = { finais: atrPosMC, pvMax: (classeObj.pv_inicial || 16) + nivel * (classeObj.pv_por_nivel || 4), pmMax: nivel * (classeObj.pm_por_nivel || 3), defesa: 14 };
        const rankDeusMC = legaisPosMC.map(d => {
            const pNames = String(d.poderes_concedidos || '').split('/').map(s => s.trim()).filter(Boolean);
            const melhorP = pNames.map(pn => ({ nome: pn, efeito_resumo: '' }))
                .map(po => avaliarBuildNumericaDescritoresV72JS(estPosMC, [po], [], armaEq, arquetipo, nivel, classeObj, escudoEq).score)
                .sort((a, b) => b - a)[0] || 0;
            return { d, sc: melhorP };
        }).sort((a, b) => b.sc - a.sc);
        deusObj = rankDeusMC[0] ? rankDeusMC[0].d : null;
    }
    const circMax = circuloMaximoPermitido(classeObj, nivel, paresClassesMCTS);
    // Busca Dinâmica de Magias & 56 Combinações de 3 Escolas (Bardo/Druida) — ZERO prioMagiasMap fixo!
    const atrMagPre = Object.assign({ FOR: 0, DES: 0, CON: 0, INT: 0, SAB: 0, CAR: 0 }, atrBase);
    if (racaObj) {
        atrMagPre.FOR += Number(racaObj.mod_for || 0); atrMagPre.DES += Number(racaObj.mod_des || 0);
        atrMagPre.CON += Number(racaObj.mod_con || 0); atrMagPre.INT += Number(racaObj.mod_int || 0);
        atrMagPre.SAB += Number(racaObj.mod_sab || 0); atrMagPre.CAR += Number(racaObj.mod_car || 0);
    }
    const grimDinV80 = buscarMelhorGrimorioDinamicoV80JS(classeObj, racaObj, nivel, circMax, arquetipo, atrMagPre, [], itensInv, caminhoArcanista);
    let magiasEscolhidas = grimDinV80.magias || [];
    const escolasOtimizadasV80 = grimDinV80.escolasEscolhidas || [];
    const motivoEscolasV80 = grimDinV80.motivoEscolas || '';

    // Estado inicial antes do MCTS
    const estInicial = calcularEstatisticaCompletaT20({
        nivel, raca: racaObj, classe: classeObj, classeSecundaria: classeSecObj, nivelClasseSecundaria: nvClasseSec, classeTerciaria: classeTercObj, nivelClasseTerciaria: nvClasseTerc, origem: origemObj, deus: deusObj, caminhoArcanista, atrBase, livres,
        pericias: periciasLista, poderes: [], itens: itensInv,
        arma: armaEq, armadura: armaduraEq, escudo: escudoEq
    });
    const scoreInicial = avaliarScoreMCTSClient(estInicial, [], magiasEscolhidas, armaEq, [], arquetipo, nivel, classeObj, itensInv, escudoEq);

    // 7. MCTS (Busca em Árvore com UCT) para Seleção de Poderes de Classe e Gerais
    // Regra Oficial T20 JdA (Cap. 1, p. 34 — Multiclasse): Poderes só são ganhos a partir do 2º nível de CADA classe!
    // Ex.: 4/1/1 (Nv Total 6) => max(0,4-1) + max(0,1-1) + max(0,1-1) = 3 poderes (Nv 2, 3 e 4 da 1ª classe apenas)!
    const slotsPoderesMulticlasse = [];
    for (const pc of paresClassesMCTS) {
        const nvC = Math.max(0, Number(pc.nivel || 0));
        for (let lv = 2; lv <= nvC; lv++) {
            slotsPoderesMulticlasse.push({ classeObj: pc.classeObj, nivelNaClasse: lv });
        }
    }
    const maxPoderes = slotsPoderesMulticlasse.length;
    const nomesClassesComSlotMCTS = new Set(slotsPoderesMulticlasse.map(sl => (sl.classeObj.nome || '').toLowerCase()));
    const candidatosPoderes = [
        ...CATALOGO_T20.poderes_classe.filter(p => nomesClassesComSlotMCTS.has((p.categoria_ou_classe || '').toLowerCase()) || p.categoria_ou_classe.toLowerCase() === 'todas'),
        ...CATALOGO_T20.poderes_gerais
    ];

    const poderesEscolhidos = [];
    const nomesPodSet = new Set([origemObj ? (origemObj.poder_unico || '') : '', ...((estInicial.infoOrigem && estInicial.infoOrigem.poderesExtras) ? estInicial.infoOrigem.poderesExtras.map(x => x.nome) : [])]);
    const periciasSet = new Set(periciasLista);

    const passosArvore = [
        {
            ordem: 1,
            fase: 'MCTS + CSP (Política: ' + modoMulticlasse + ')',
            cat: '1. Classe & Otimização de Multiclasse (p. 34)',
            vencedor: paresClassesMCTS.map(p => `${p.classeObj.nome} ${p.nivel}`).join(' / '),
            detalhe: (rankingMulticlasseMCTS[0] ? `${rankingMulticlasseMCTS[0].rotuloPolitica} — ${rankingMulticlasseMCTS[0].justificativaSinergia}` : `Atrib. Principal: ${classeObj.atributo_principal}`),
            visitas: iteracoes,
            score: rankingMulticlasseMCTS[0] ? rankingMulticlasseMCTS[0].scoreTotalMC : scoreInicial,
            uct: rankingMulticlasseMCTS[0] ? rankingMulticlasseMCTS[0].scoreTotalMC : scoreInicial,
            alts: (rankingMulticlasseMCTS.length > 1)
                ? rankingMulticlasseMCTS.slice(1, 4).map(r => ({
                    nome: r.resumoDist,
                    tipo: 'EXPLORADO_MCTS',
                    visitas: Math.max(8, Math.floor(iteracoes / 4)),
                    motivo: `${r.rotuloPolitica}: Score ${r.scoreTotalMC} pts | DPR ${r.dprPotencial}/rod`
                }))
                : CATALOGO_T20.classes.filter(c => c.nome !== classeObj.nome).slice(0, 2).map(c => ({
                    nome: c.nome, tipo: 'EXPLORADO_MCTS', visitas: 0, motivo: `Atrib: ${c.atributo_principal} | PV ${c.pv_inicial}+${c.pv_por_nivel}/nv (Subótimo)`
                }))
        },
        {
            ordem: 2,
            fase: 'CSP (Consistência AC-3)',
            cat: '2. Raça & Atributos',
            vencedor: `${racaObj.nome} (Base 10 pts JdA)`,
            detalhe: `Mods aplicados -> FOR ${estInicial.finais.FOR >= 0 ? '+' + estInicial.finais.FOR : estInicial.finais.FOR}, DES ${estInicial.finais.DES >= 0 ? '+' + estInicial.finais.DES : estInicial.finais.DES}, CON ${estInicial.finais.CON >= 0 ? '+' + estInicial.finais.CON : estInicial.finais.CON}, INT ${estInicial.finais.INT >= 0 ? '+' + estInicial.finais.INT : estInicial.finais.INT}, SAB ${estInicial.finais.SAB >= 0 ? '+' + estInicial.finais.SAB : estInicial.finais.SAB}, CAR ${estInicial.finais.CAR >= 0 ? '+' + estInicial.finais.CAR : estInicial.finais.CAR}`,
            visitas: iteracoes,
            score: scoreInicial,
            uct: scoreInicial,
            alts: altsRaca.slice(0, 3)
        },
        {
            ordem: 3,
            fase: 'CSP (Consistência de Arco AC-3)',
            cat: '3. Origem / Memória Póstuma & Divindade',
            vencedor: `${origemObj ? origemObj.nome : ('Sem Origem (' + racaObj.nome + ')')} + Devoto de ${deusObj ? deusObj.nome : 'Nenhum'}`,
            detalhe: `${estInicial.infoOrigem ? estInicial.infoOrigem.resumoRegra : ''} | Domínio Divino: ${deusesValidos.length}/20 deuses compatíveis`,
            visitas: iteracoes,
            score: scoreInicial,
            uct: scoreInicial,
            alts: altsDeus.slice(0, 3)
        }
    ];

    let estAtual = estInicial;
    let scoreAtual = scoreInicial;

    for (let passo = 1; passo <= maxPoderes; passo++) {
        const slotAtualMC = slotsPoderesMulticlasse[passo - 1] || { classeObj, nivelNaClasse: passo + 1 };
        const nivelAquisicao = slotAtualMC.nivelNaClasse;
        const nomeClasseSlotL = (slotAtualMC.classeObj.nome || '').toLowerCase();
        let legais = [];
        let podadosNivel = [];
        for (const cand of candidatosPoderes) {
            if (nomesPodSet.has(cand.nome)) continue;
            // Poder de classe só pode ser adquirido em slot daquela classe (nunca em classe de nível 1!)
            if (cand.eh_poder_classe) {
                const catCandL = (cand.categoria_ou_classe || '').toLowerCase();
                if (catCandL !== 'todas' && catCandL !== nomeClasseSlotL) continue;
            }
            const res = satisfazPreReqOffline(cand.pre_requisitos, estAtual.finais, nivelAquisicao, periciasSet, nomesPodSet, deusObj ? deusObj.nome : '', { classeObj: slotAtualMC.classeObj, paresClasses: paresClassesMCTS, racaObj, poderesAtuais: poderesEscolhidos, armaEq, escudoEq, magiasAtuais: magiasEscolhidas });
            const resEst = res.ok ? verificarConflitoEstiloJS(poderesEscolhidos, cand, classeObj, armaEq, escudoEq) : res;
            if (res.ok && resEst.ok) {
                const poderesTeste = [...poderesEscolhidos, cand];
                const estTeste = calcularEstatisticaCompletaT20({
                    nivel, raca: racaObj, classe: classeObj, classeSecundaria: classeSecObj, nivelClasseSecundaria: nvClasseSec, classeTerciaria: classeTercObj, nivelClasseTerciaria: nvClasseTerc, origem: origemObj, deus: deusObj, caminhoArcanista, atrBase, livres,
                    pericias: periciasLista, poderes: poderesTeste, itens: itensInv,
                    arma: armaEq, armadura: armaduraEq, escudo: escudoEq
                });
                const scTeste = avaliarScoreMCTSClient(estTeste, poderesTeste, magiasEscolhidas, armaEq, [], arquetipo, nivel, classeObj, itensInv, escudoEq);
                // Avaliação 100% Numérica por Descritores + Checks + Lookahead de Pré-Requisito (ZERO pesos mágicos por nome!)
                const descCandV72 = compilarDescritorNumericoPoderJS(cand);
                // Lookahead de combo (Beam 2-step): se este poder libera um poder futuro forte (ex: Estilo de Duas Armas -> Ambidestria, Forma Selvagem -> Aprimorada), estima o ganho desbloqueado
                let bonusDesbloqueioCombo = 0.0;
                if (passo < maxPoderes) {
                    const checkDesb = descCandV72.id_check;
                    const desbloqueados = candidatosPoderes.filter(p2 => !nomesPodSet.has(p2.nome) && compilarDescritorNumericoPoderJS(p2).prereq_checks.includes(checkDesb));
                    if (desbloqueados.length > 0) {
                        const estCombo = calcularEstatisticaCompletaT20({
                            nivel, raca: racaObj, classe: classeObj, classeSecundaria: classeSecObj, nivelClasseSecundaria: nvClasseSec, classeTerciaria: classeTercObj, nivelClasseTerciaria: nvClasseTerc, origem: origemObj, deus: deusObj, caminhoArcanista, atrBase, livres,
                            pericias: periciasLista, poderes: [...poderesTeste, desbloqueados[0]], itens: itensInv, arma: armaEq, armadura: armaduraEq, escudo: escudoEq
                        });
                        const scCombo = avaliarScoreMCTSClient(estCombo, [...poderesTeste, desbloqueados[0]], magiasEscolhidas, armaEq, [], arquetipo, nivel, classeObj, itensInv, escudoEq);
                        bonusDesbloqueioCombo = Math.max(0, (scCombo - scTeste) * 0.35);
                    }
                }
                legais.push({ cand, estTeste, scTeste: +(scTeste + bonusDesbloqueioCombo).toFixed(1) });
            } else {
                podasCSP++;
                if (podadosNivel.length < 2 && !res.motivo.toLowerCase().includes('devoto')) {
                    podadosNivel.push({ nome: cand.nome, tipo: 'PODADO_CSP', visitas: 0, motivo: 'Podado CSP: ' + (res.ok ? resEst.motivo : res.motivo) });
                }
            }
        }
        legais.sort((a, b) => b.scTeste - a.scTeste);
        if (legais.length === 0) break;

        const melhor = legais[0];
        poderesEscolhidos.push(melhor.cand);
        nomesPodSet.add(melhor.cand.nome);
        estAtual = melhor.estTeste;
        scoreAtual = melhor.scTeste;

        const visNo = Math.max(5, Math.floor(iteracoes / (passo * 1.25)));
        const uctNo = +(scoreAtual + 1.414 * Math.sqrt(Math.log(iteracoes) / visNo)).toFixed(1);

        const altsPasso = [
            ...legais.slice(1, 3).map((x, idx) => ({
                nome: x.cand.nome,
                tipo: 'EXPLORADO_MCTS',
                visitas: Math.max(2, Math.floor(visNo / (idx + 2))),
                motivo: `Média MCTS menor (${x.scTeste.toFixed(1)} vs ${scoreAtual.toFixed(1)} em ${Math.max(2, Math.floor(visNo / (idx + 2)))} visitas)`
            })),
            ...podadosNivel
        ];

        const tagCat = melhor.cand.eh_poder_classe ? `Classe: ${melhor.cand.categoria_ou_classe}` : `Geral: ${melhor.cand.categoria_ou_classe}`;
        passosArvore.push({
            ordem: 3 + passo,
            fase: 'MCTS (Seleção UCT)',
            cat: `${3 + passo}. Poder de ${slotAtualMC.classeObj.nome} (Nv ${slotAtualMC.nivelNaClasse} na classe · Slot #${passo}/${maxPoderes})`,
            vencedor: melhor.cand.nome,
            detalhe: `[Adquirido no Nv. ${passo + 1} · ${tagCat}] ${melhor.cand.efeito_resumo}`,
            visitas: visNo,
            score: scoreAtual,
            uct: uctNo,
            alts: altsPasso
        });
    }

    const estadoGeradoOtim = {
        nome,
        jogador: 'MCTS_CSP_Optimizer',
        modo: 'Algoritmo Híbrido (CSP + MCTS)',
        arquetipo,
        nivel,
        raca: racaObj,
        classe: classeObj,
        classeSecundaria: classeSecObj,
        nivelClasseSecundaria: nvClasseSec,
        classeTerciaria: classeTercObj,
        nivelClasseTerciaria: nvClasseTerc,
        modoMulticlasse,
        rankingMulticlasseMCTS,
        caminhoArcanista,
        origem: origemObj,
        deus: deusObj,
        atrBase,
        livres,
        est: estAtual,
        pericias: periciasLista,
        poderes: poderesEscolhidos,
        itens: itensInv,
        arma: armaEq,
        armadura: armaduraEq,
        escudo: escudoEq,
        magias: magiasEscolhidas,
        validacoes: [],
        iteracoes,
        nosExpandidos: iteracoes + 1,
        podasCSP,
        scoreInicial,
        scoreFinal: scoreAtual,
        passosArvore
    };
    if (abaDestinoOpcional === '__SILENCIOSO_RL__') {
        window.__ULTIMO_ESTADO_FICHA__ = estadoGeradoOtim;
        return estadoGeradoOtim;
    }
    if (formData.get('_v74_silent') !== '1') renderizarFichaEArvoreClientSide(estadoGeradoOtim, abaDestinoOpcional !== undefined ? abaDestinoOpcional : 'tab-ficha', `Ficha e Árvore atualizadas para ${racaObj.nome} ${resumoClassesMulticlasseJS(estadoGeradoOtim)} (PV=${estAtual.pvMax}, PM=${estAtual.pmMax}, Score=${scoreAtual.toFixed(1)})!`);
    return estadoGeradoOtim;
}

function executarAtualizacaoManualOffline(formData) {
    const nome = formData.get('nome') || 'Personagem Manual';
    const jogador = formData.get('jogador') || 'Jogador';
    const nivel = Math.max(1, Math.min(20, parseInt(formData.get('nivel') || '1', 10)));
    const racaObj = CATALOGO_T20.racas.find(r => r.nome === formData.get('raca')) || CATALOGO_T20.racas[0];
    const classeObj = CATALOGO_T20.classes.find(c => c.nome === formData.get('classe')) || CATALOGO_T20.classes[0];
    const nomeClSecM = formData.get('classe_secundaria') || 'NENHUMA';
    const classeSecObj = (nomeClSecM !== 'NENHUMA' && nomeClSecM !== classeObj.nome)
        ? (CATALOGO_T20.classes.find(c => c.nome === nomeClSecM) || null)
        : null;
    const nvClasseSec = classeSecObj ? Math.max(0, parseIntSeguro(formData.get('nivel_classe_secundaria'), 0)) : 0;
    const nomeClTercM = formData.get('classe_terciaria') || 'NENHUMA';
    const classeTercObj = (nomeClTercM !== 'NENHUMA' && nomeClTercM !== classeObj.nome && (!classeSecObj || nomeClTercM !== classeSecObj.nome))
        ? (CATALOGO_T20.classes.find(c => c.nome === nomeClTercM) || null)
        : null;
    const nvClasseTerc = classeTercObj ? Math.max(0, parseIntSeguro(formData.get('nivel_classe_terciaria'), 0)) : 0;
    const origemObj = CATALOGO_T20.origens.find(o => o.nome === formData.get('origem')) || CATALOGO_T20.origens[0];
    const deusNome = formData.get('deus') || 'Nenhum';
    const deusObj = CATALOGO_T20.deuses.find(d => d.nome === deusNome) || null;
    const caminhoArcanista = formData.get('caminho_arcanista') || 'Mago';

    const atrBase = {
        FOR: parseIntSeguro(formData.get('atr_FOR'), 0),
        DES: parseIntSeguro(formData.get('atr_DES'), 0),
        CON: parseIntSeguro(formData.get('atr_CON'), 0),
        INT: parseIntSeguro(formData.get('atr_INT'), 0),
        SAB: parseIntSeguro(formData.get('atr_SAB'), 0),
        CAR: parseIntSeguro(formData.get('atr_CAR'), 0)
    };
    const livres = (formData.get('livres') || 'FOR,DES,CON').split(',').map(s => s.trim().toUpperCase()).filter(Boolean);

    const periciasFixas = (classeObj.pericias_fixas || '').split(/\s+e\s+|\/|,/i).map(x => x.split('(')[0].split(/\s+ou\s+/i)[0].trim()).filter(Boolean);
    const periciasSel = [...periciasFixas];
    for (const pS of formData.getAll('pericias')) {
        if (pS && !periciasSel.includes(pS)) periciasSel.push(pS);
    }

    const podIdsSel = new Set(formData.getAll('poderes'));
    const todosCandidatos = [...CATALOGO_T20.poderes_classe, ...CATALOGO_T20.poderes_gerais];
    const poderesEscolhidos = todosCandidatos.filter(p => podIdsSel.has(p.id_poder));

    const acharItem = (n) => (!n || n === 'Nenhum') ? null : (CATALOGO_T20.itens.find(i => i.nome === n || i.id_item === n) || null);
    const armaEq = acharItem(formData.get('arma'));
    const armaduraEq = acharItem(formData.get('armadura'));
    const escudoEq = acharItem(formData.get('escudo'));
    const itensInv = [armaEq, armaduraEq, escudoEq].filter(Boolean);
    for (const iid of formData.getAll('itens_extras')) {
        const itEx = acharItem(iid);
        if (itEx && !itensInv.includes(itEx)) itensInv.push(itEx);
    }

    const magIdsSel = new Set(formData.getAll('magias'));
    const magiasEscolhidas = CATALOGO_T20.magias.filter(m => magIdsSel.has(m.id_magia));

    const estAtual = calcularEstatisticaCompletaT20({
        nivel, raca: racaObj, classe: classeObj, classeSecundaria: classeSecObj, nivelClasseSecundaria: nvClasseSec,
        classeTerciaria: classeTercObj, nivelClasseTerciaria: nvClasseTerc,
        origem: origemObj, deus: deusObj, caminhoArcanista, atrBase, livres,
        pericias: periciasSel, poderes: poderesEscolhidos, itens: itensInv,
        arma: armaEq, armadura: armaduraEq, escudo: escudoEq
    });

    // Validação CSP da Ficha Manual
    const validacoes = [];
    if (deusObj && !deusPermite(deusObj, racaObj.nome, classeObj.nome)) {
        validacoes.push(`[CSP:Devocao] ${deusObj.nome} permite apenas (${deusObj.devotos_permitidos}), incompatível com ${racaObj.nome} ${classeObj.nome}.`);
    }
    const maxPodPermitidos = Math.max(0, nivel - 1);
    if (poderesEscolhidos.length > maxPodPermitidos) {
        validacoes.push(`[CSP:LimitePoderesNivel] Personagem de nível ${nivel} possui ${poderesEscolhidos.length} poderes selecionados, mas a regra oficial permite no máximo ${maxPodPermitidos} poderes de progressão (1 por nível a partir do 2º nível).`);
    }
    const perSet = new Set(periciasSel);
    const podSet = new Set([origemObj.poder_unico || '', ...poderesEscolhidos.map(p => p.nome)]);
    for (const pod of poderesEscolhidos) {
        const nomesClManSet = new Set((estAtual.paresClasses || [{ classeObj, nivel }]).map(pc => (pc.classeObj.nome || '').toLowerCase()));
        if (pod.eh_poder_classe && !nomesClManSet.has(pod.categoria_ou_classe.toLowerCase()) && pod.categoria_ou_classe.toLowerCase() !== 'todas') {
            validacoes.push(`[CSP:ClassePoder] '${pod.nome}' é exclusivo de ${pod.categoria_ou_classe}.`);
        }
        const check = satisfazPreReqOffline(pod.pre_requisitos, estAtual.finais, nivel, perSet, podSet, deusObj ? deusObj.nome : '', { classeObj, racaObj, poderesAtuais: poderesEscolhidos, armaEq, escudoEq, magiasAtuais: magiasEscolhidas });
        if (!check.ok) validacoes.push(`[CSP:PreRequisito] Poder '${pod.nome}' requer: ${check.motivo}.`);
    }
    const cMax = circuloMaximoPermitido(classeObj, nivel, estAtual.paresClasses);
    for (const m of magiasEscolhidas) {
        if (m.circulo > cMax) validacoes.push(`[CSP:Magia] '${m.nome}' (${m.circulo}º círculo) excede o limite (${cMax}º círculo).`);
    }
    if (estAtual.cargaAtual > estAtual.cargaMax) {
        validacoes.push(`[CSP:Carga] Sobrecarga (${estAtual.cargaAtual}/${estAtual.cargaMax} espaços).`);
    }
    for (const eqItem of [armaEq, armaduraEq, escudoEq]) {
        if (eqItem) {
            const checkProf = temProficienciaItemJS(eqItem, classeObj, racaObj, poderesEscolhidos, escudoEq);
            if (!checkProf.ok) validacoes.push(`[CSP:Proficiencia] Sem proficiência para '${eqItem.nome}': ${checkProf.motivo}.`);
        }
    }
    if (classeObj.nome.toLowerCase() === 'arcanista' && armaduraEq && !poderesEscolhidos.some(p => p.nome.toLowerCase() === 'magia discreta')) {
        validacoes.push(`[CSP:ArmaduraArcana] Arcanista vestindo '${armaduraEq.nome}' sem 'Magia Discreta' sofre falha de conjuração arcana.`);
    }
    for (const pod of poderesEscolhidos) {
        const outrosP = poderesEscolhidos.filter(x => x !== pod);
        const checkEst = verificarConflitoEstiloJS(outrosP, pod, classeObj, armaEq, escudoEq);
        if (!checkEst.ok) validacoes.push(`[CSP:ConflitoEstilo] ${checkEst.motivo}.`);
    }

    const scoreFinal = avaliarScoreMCTSClient(estAtual, poderesEscolhidos, magiasEscolhidas, armaEq, validacoes, 'Dano Marcial', nivel, classeObj, itensInv, escudoEq);

    const passosArvore = [
        {
            ordem: 1,
            fase: 'Manual (Validado CSP)',
            cat: '1. Raça & Classe',
            vencedor: `${racaObj.nome} ${classeObj.nome} (Nv ${nivel})`,
            detalhe: `PV: ${estAtual.pvMax} | PM: ${estAtual.pmMax} | Defesa: ${estAtual.defesa}`,
            visitas: 1,
            score: scoreFinal,
            uct: scoreFinal,
            alts: []
        },
        {
            ordem: 2,
            fase: 'Manual (Validado CSP)',
            cat: '2. Origem & Divindade',
            vencedor: `${origemObj.nome} + ${deusObj ? deusObj.nome : 'Sem Divindade'}`,
            detalhe: `Poder de Origem: ${origemObj.poder_unico}`,
            visitas: 1,
            score: scoreFinal,
            uct: scoreFinal,
            alts: []
        }
    ];
    poderesEscolhidos.forEach((p, idx) => {
        passosArvore.push({
            ordem: idx + 3,
            fase: 'Manual (Validado CSP)',
            cat: `${idx + 3}. Poder Selecionado`,
            vencedor: p.nome,
            detalhe: `[${p.eh_poder_classe ? 'Classe:' + p.categoria_ou_classe : 'Geral:' + p.categoria_ou_classe}] ${p.efeito_resumo}`,
            visitas: 1,
            score: scoreFinal,
            uct: scoreFinal,
            alts: []
        });
    });

    renderizarFichaEArvoreClientSide({
        nome,
        jogador,
        modo: 'Seleção Manual pelo Usuário',
        arquetipo: 'Personalizado',
        nivel,
        raca: racaObj,
        classe: classeObj,
        classeSecundaria: classeSecObj,
        nivelClasseSecundaria: nvClasseSec,
        classeTerciaria: classeTercObj,
        nivelClasseTerciaria: nvClasseTerc,
        caminhoArcanista,
        origem: origemObj,
        deus: deusObj,
        atrBase,
        livres,
        est: estAtual,
        pericias: periciasSel,
        poderes: poderesEscolhidos,
        itens: itensInv,
        arma: armaEq,
        armadura: armaduraEq,
        escudo: escudoEq,
        magias: magiasEscolhidas,
        validacoes,
        iteracoes: 1,
        nosExpandidos: passosArvore.length,
        podasCSP: 0,
        scoreInicial: scoreFinal,
        scoreFinal,
        passosArvore
    }, 'tab-ficha', `Ficha manual '${nome}' atualizada (PV=${estAtual.pvMax}, PM=${estAtual.pmMax})!`);
}



function codificarFichaTensorJS(estado, est, resDano) {
    const atr = est.finais;
    const nat = naturezaPersonagemJS(estado.classe);
    const estArma = identificarEstiloArmaJS(estado.arma, estado.escudo);
    return [
        +(atr.FOR / 10).toFixed(3), +(atr.DES / 10).toFixed(3), +(atr.CON / 10).toFixed(3),
        +(atr.INT / 10).toFixed(3), +(atr.SAB / 10).toFixed(3), +(atr.CAR / 10).toFixed(3),
        +(estado.nivel / 20).toFixed(3), +(est.pvMax / 150).toFixed(3), +(est.pmMax / 100).toFixed(3),
        +((est.defesa - 10) / 25).toFixed(3), +((est.cdMagia - 10) / 20).toFixed(3),
        +(resDano.limitePM / 25).toFixed(3), +(resDano.danoMedioArma / 80).toFixed(3),
        +(resDano.danoMedioRaio / 40).toFixed(3), +(resDano.maiorDanoMagia / 100).toFixed(3),
        nat === 'Marcial' ? 1 : 0, nat === 'Conjurador' ? 1 : 0,
        estArma === 'DUAS_MAOS' ? 1 : (estArma === 'ARQUERIA_DISPARO' ? 0.5 : 0),
        +((estado.poderes || []).length / 10).toFixed(3), +((estado.magias || []).length / 10).toFixed(3)
    ];
}

function simularDueloContraAmeacaNDJS(estado, est, resDano, ndAlvo, papelAlvo, usarFichaIntegralGrupo4) {
    const nivelH = Math.max(1, estado.nivel || 6);
    const nd = Math.max(1, Math.min(20, ndAlvo || nivelH));
    const am = obterAmeacaOficialJS(nd, papelAlvo || 'Solo');
    const deltaND = nd - nivelH;

    // Regra Oficial do Livro Básico (p. 282-283 e p. 323):
    // - Defesa, Bônus de Ataque, Resistências e CD da Ameaça são SEMPRE 100% os valores da tabela oficial!
    // - No modo Ficha Integral (ou quando deltaND >= 3, mudança de Patamar), PV e Dano são 100% integrais!
    // - No modo Duelo 1v1 equilibrado (deltaND <= 0), a cota individual de 1 herói (1/4 do grupo) é 30% PV e 45% do dano focado.
    const fatorPV = usarFichaIntegralGrupo4 ? 1.0 : (deltaND >= 3 ? 1.0 : (deltaND === 2 ? 0.75 : (deltaND === 1 ? 0.50 : 0.30)));
    const fatorDano = usarFichaIntegralGrupo4 ? 1.0 : (deltaND >= 2 ? 1.0 : (deltaND === 1 ? 0.75 : 0.45));

    const pvChefeMax = Math.max(20, Math.round(am.pv * fatorPV));
    const danoChefeBase = Math.max(6, Math.round(am.dano_medio * fatorDano));
    const defChefe = am.defesa;
    const atqChefe = am.bonus_ataque;
    const resChefe = am.res_media;

    const ehConj = ehConjuradorJS(estado.classe, estado.poderes);
    const melhorMag = resDano.melhorMagiaInfo;
    const danoMagMax = resDano.maiorDanoMagia || 0;
    const custoMag = melhorMag ? melhorMag.info.pmGasto : 3;
    const danoRaio = Math.max(resDano.danoMedioRaio || 0, ehConj ? 4.5 * Math.max(1, circuloMaximoPermitido(estado.classe, nivelH)) : 0);
    const danoArma = Math.max(resDano.danoMedioArma || 0, 6.5 + Math.max(0, est.finais.FOR));
    let melhorPerAtq = Math.max(est.bonusPericias['Luta'] || 0, est.bonusPericias['Pontaria'] || 0);
    const mAtqJS = (resDano.descDanoArma || '').match(/Ataque\s*([+-]?\d+)/);
    if (mAtqJS) melhorPerAtq = parseInt(mAtqJS[1], 10);

    const ncLow = estado.classe ? estado.classe.nome.toLowerCase() : '';
    const bonusAE = (ncLow === 'guerreiro') ? (4 * (1 + Math.floor((nivelH - 1) / 4))) : 0;
    const custoAE = (ncLow === 'guerreiro') ? (1 + Math.floor((nivelH - 1) / 4)) : 0;
    const atqEfetivoHeroi = melhorPerAtq + bonusAE;

    // Cálculo Analítico Exato de Probabilidade de Acerto (Regra do 1 natural falha [5%] e 20 natural acerta [5%], Livro p. 221)
    const d20MinParaAcertar = defChefe - atqEfetivoHeroi;
    const facesQueAcertam = Math.max(1, Math.min(19, 21 - d20MinParaAcertar));
    const probAcertoHeroiPct = +((facesQueAcertam / 20) * 100).toFixed(1);

    const d20MinInimigoAcertar = est.defesa - atqChefe;
    const facesInimigoAcerta = Math.max(1, Math.min(19, 21 - d20MinInimigoAcertar));
    const probAcertoInimigoPct = +((facesInimigoAcerta / 20) * 100).toFixed(1);

    let rdHeroi = 0;
    const magNomes = (estado.magias || []).map(m => (m.nome || '').toLowerCase());
    const podNomes = (estado.poderes || []).map(p => (p.nome || '').toLowerCase());
    if (podNomes.includes('encouraçado')) rdHeroi += 2;
    if (estado.raca && estado.raca.nome.toLowerCase() === 'osteon') rdHeroi += 5;
    if (magNomes.some(n => n.includes('campo de força')) && nivelH >= 5) rdHeroi += 15;
    else if (ncLow === 'guerreiro' && nivelH >= 3) rdHeroi += Math.round(danoChefeBase * 0.25);

    const bonusIniHeroi = est.bonusPericias['Iniciativa'] !== undefined ? est.bonusPericias['Iniciativa'] : (Math.floor(nivelH / 2) + est.finais.DES);
    const bonusIniChefe = Math.floor(nd / 2) + (nd <= 6 ? 3 : (nd <= 10 ? 6 : 11));

    const episodios = 40;
    let vitorias = 0, somaQ = 0, somaTurnos = 0, somaDanoCausado = 0, somaDanoSofrido = 0;
    let seed = 2026 + nd * 37 + nivelH * 19 + est.pvMax * 7;
    function rand() { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; }
    function d20() { return Math.floor(rand() * 20) + 1; }

    for (let ep = 0; ep < episodios; ep++) {
        let pvH = est.pvMax, pmH = est.pmMax, pvC = pvChefeMax;
        let turnos = 0, danoEp = 0, sofridoEp = 0;
        const iniH = d20() + bonusIniHeroi;
        const iniC = d20() + bonusIniChefe;
        const heroiPrimeiro = iniH >= iniC;

        while (pvH > 0 && pvC > 0 && turnos < 20) {
            turnos++;
            // Se a criatura venceu a Iniciativa, ELA ATACA PRIMEIRO no turno!
            if (!heroiPrimeiro) {
                const rIni = d20();
                const defHAtual = (turnos === 1) ? Math.max(10, est.defesa - 5) : est.defesa;
                if (rIni === 20 || (rIni !== 1 && (rIni + atqChefe) >= defHAtual)) {
                    const dBruto = Math.round(danoChefeBase * (0.90 + 0.20 * rand()) * (rIni === 20 ? 1.5 : 1.0));
                    const dFinal = Math.max(1, dBruto - rdHeroi);
                    pvH = Math.max(0, pvH - dFinal);
                    sofridoEp += dFinal;
                }
                if (pvH <= 0) break;
            }

            // Turno do Herói (se estiver vivo!)
            let dC = 0;
            if (ehConj && melhorMag && pmH >= custoMag && danoMagMax > danoArma) {
                pmH -= custoMag;
                const dRes = d20();
                const passou = (dRes === 20) || (dRes !== 1 && (dRes + resChefe) >= est.cdMagia);
                dC = danoMagMax * (0.92 + 0.16 * rand()) * (passou ? 0.5 : 1.0);
            } else {
                const gastaAE = (!ehConj && pmH >= custoAE) ? custoAE : 0;
                pmH -= gastaAE;
                const bAtqTurno = gastaAE > 0 ? bonusAE : 0;
                const rAtq = d20();
                const defCAtual = (turnos === 1 && heroiPrimeiro) ? Math.max(10, defChefe - 5) : defChefe;
                const acertou = (rAtq === 20) || (rAtq !== 1 && (rAtq + melhorPerAtq + bAtqTurno) >= defCAtual);
                if (acertou) {
                    dC = (danoArma * 0.82) * (rAtq >= 19 ? 1.45 : 1.0) * (0.92 + 0.16 * rand());
                }
            }
            pvC = Math.max(0, pvC - dC);
            danoEp += dC;

            // Se o herói agiu primeiro e a criatura sobreviveu, a criatura contra-ataca agora!
            if (heroiPrimeiro && pvC > 0) {
                const rIni = d20();
                if (rIni === 20 || (rIni !== 1 && (rIni + atqChefe) >= est.defesa)) {
                    const dBruto = Math.round(danoChefeBase * (0.90 + 0.20 * rand()) * (rIni === 20 ? 1.5 : 1.0));
                    const dFinal = Math.max(1, dBruto - rdHeroi);
                    pvH = Math.max(0, pvH - dFinal);
                    sofridoEp += dFinal;
                }
            }
        }

        const venceu = (pvC <= 0) && (pvH > 0);
        if (venceu) vitorias++;
        // Cálculo Estrito da Recompensa R_k:
        // - Vitória: +100 base + até +60 por % de PV restante + até +40 por rapidez (1/turnos) => [102 .. 200]
        // - Derrota: -100 base + até +60 pela % de PV arrancada da ameaça - 20 se abatido no 1º turno => [-120 .. -40]
        const rEp = venceu
            ? (100 + 60 * (pvH / Math.max(1, est.pvMax)) + (40 / Math.max(1, turnos)))
            : (-100 + 60 * Math.min(1, danoEp / Math.max(1, pvChefeMax)) - (turnos <= 1 ? 20 : 0));
        somaQ = (ep === 0) ? rEp : (somaQ + 0.25 * (rEp - somaQ));
        somaTurnos += turnos;
        somaDanoCausado += danoEp / Math.max(1, turnos);
        somaDanoSofrido += sofridoEp / Math.max(1, turnos);
    }

    const dprHeroi = +(somaDanoCausado / episodios).toFixed(1);
    const dprInimigo = Math.max(1, +(somaDanoSofrido / episodios).toFixed(1));
    const ttkHeroi = +(pvChefeMax / Math.max(0.5, dprHeroi)).toFixed(1);
    const ttkInimigo = +(est.pvMax / dprInimigo).toFixed(1);
    const winPct = +((vitorias / episodios) * 100).toFixed(1);
    const qFinal = +somaQ.toFixed(1);

    let vereditoND = 'Desafio Equilibrado (ND = Nível)';
    if (deltaND >= 5) vereditoND = 'INVENCÍVEL NO NÍVEL ATUAL (ND +5: Patamar Superior / Hit-Kill)';
    else if (deltaND >= 3) vereditoND = 'Quase Impossível / Letal (ND +' + deltaND + ')';
    else if (deltaND >= 1) vereditoND = 'Desafio Difícil / Chefe (ND +' + deltaND + ')';

    return {
        nd,
        deltaND,
        patamar: am.patamar,
        papel: papelAlvo || 'Solo',
        defChefe,
        atqChefe,
        danoChefeOficial: am.dano_medio,
        danoChefeAplicado: danoChefeBase,
        pvGrupo4: am.pv,
        pvChefeMax,
        resForte: am.res_forte,
        resMedia: am.res_media,
        resFraca: am.res_fraca,
        cdEfeito: am.cd_efeito,
        probAcertoHeroiPct,
        probAcertoInimigoPct,
        dprHeroi,
        dprInimigo,
        ttkHeroi,
        ttkInimigo,
        winPct,
        qFinal,
        vereditoND
    };
}

function simularCombateMonteCarloJS(estado, est, resDano) {
    const nd = Math.max(1, Math.min(20, estado.nivel));
    const amSolo = obterAmeacaOficialJS(nd, 'Solo');
    const amLac = obterAmeacaOficialJS(nd, 'Lacaio');
    const amEsp = obterAmeacaOficialJS(nd, 'Especial');

    const pvGrupo4 = amSolo.pv;
    const pvChefeMax = Math.max(25, Math.round(amSolo.pv * 0.35));
    const defChefe = amSolo.defesa;
    const atqChefe = amSolo.bonus_ataque;
    const danoChefeBase = Math.max(6, Math.round(amSolo.dano_medio * 0.50));
    const resChefe = amSolo.res_media;

    const ehConj = ehConjuradorJS(estado.classe, estado.poderes);
    const melhorMag = resDano.melhorMagiaInfo;
    const danoMagMax = resDano.maiorDanoMagia || 0;
    const custoMag = melhorMag ? melhorMag.info.pmGasto : 3;
    const danoRaio = Math.max(resDano.danoMedioRaio || 0, ehConj ? 4.5 * Math.max(1, circuloMaximoPermitido(estado.classe, nd)) : 0);
    const danoArma = Math.max(resDano.danoMedioArma || 0, 6.5 + Math.max(0, est.finais.FOR));
    let melhorPerAtq = Math.max(est.bonusPericias['Luta'] || 0, est.bonusPericias['Pontaria'] || 0);
    const mAtqJS = (resDano.descDanoArma || '').match(/Ataque\s*([+-]?\d+)/);
    if (mAtqJS) melhorPerAtq = parseInt(mAtqJS[1], 10);
    const nomeArma = estado.arma ? estado.arma.nome : 'Ataque Desarmado';
    const estiloArma = identificarEstiloArmaJS(estado.arma, estado.escudo, estado.poderes, estado.arquetipo);

    // Probabilidades exatas contra a Ameaça Solo Oficial (p. 323) — considerando Ataque Especial p/ Guerreiro
    const bonusAEAtqJS = (estado.classe && estado.classe.nome.toLowerCase() === 'guerreiro') ? (4 * (1 + Math.floor((nd - 1) / 4))) : 0;
    const atqEfetivoDecJS = melhorPerAtq + bonusAEAtqJS;
    const alvosD20Acerto = Math.max(1, Math.min(19, 21 - (defChefe - atqEfetivoDecJS)));
    const probAcertoArma = +((alvosD20Acerto / 20) * 100).toFixed(1);
    const evDanoArma = +(danoArma * (probAcertoArma / 100) * 1.08).toFixed(1);

    const alvosD20Passa = Math.max(1, Math.min(19, 21 - (est.cdMagia - resChefe)));
    const probFalhaRes = +(((20 - alvosD20Passa) / 20) * 100).toFixed(1);
    const fatorMag = (probFalhaRes / 100) * 1.0 + ((100 - probFalhaRes) / 100) * 0.5;
    const evDanoMagia = melhorMag ? +(danoMagMax * fatorMag).toFixed(1) : 0;
    const evDanoRaio = danoRaio > 0 ? +(danoRaio * fatorMag).toFixed(1) : 0;

    // Mitigação / Reação Defensiva (Estritamente Reações Existentes na Ficha e no Livro Básico!)
    let rdEstimada = 0;
    let reacaoNome = 'Defesa & Testes de Resistência Passivos da Ficha (0 PM — Livro p. 233)';
    let reacaoCusto = 0;
    const magNomesSim = (estado.magias || []).map(m => (m.nome || '').toLowerCase());
    const podNomesSim = [
        ...((est.infoOrigem && est.infoOrigem.poderesExtras) || []),
        ...((est.infoDevocao && est.infoDevocao.poderes) || []),
        ...(estado.poderes || [])
    ].map(p => (p.nome || '').toLowerCase());
    const clSimLow = (estado.classe && estado.classe.nome) ? estado.classe.nome.toLowerCase() : '';
    if (podNomesSim.includes('encouraçado')) rdEstimada += 2;
    if (magNomesSim.some(n => n.includes('campo de força')) && magNomesSim.some(n => n.includes('armadura arcana'))) {
        rdEstimada += 18;
        reacaoNome = "Magias da Ficha: 'Armadura Arcana' (Reação, 2 PM: +5 Defesa, p. 179) OU 'Campo de Força' (Reação, 4 PM: RD 30, p. 182)";
        reacaoCusto = 2;
    } else if (magNomesSim.some(n => n.includes('campo de força'))) {
        rdEstimada += 15;
        reacaoNome = "Magia da Ficha: 'Campo de Força' (Reação, 4 PM: RD 30 contra o próximo dano, p. 182)";
        reacaoCusto = 4;
    } else if (magNomesSim.some(n => n.includes('armadura arcana'))) {
        rdEstimada += 9;
        reacaoNome = "Magia da Ficha: 'Armadura Arcana' (Reação, 2 PM: +5 na Defesa contra o ataque, p. 179)";
        reacaoCusto = 2;
    } else if (magNomesSim.some(n => n.includes('salto dimensional'))) {
        rdEstimada += 10;
        reacaoNome = "Magia da Ficha: 'Salto Dimensional' (Reação, 4 PM: +5 Defesa/Reflexos e salta 1,5m, p. 205)";
        reacaoCusto = 4;
    } else if (magNomesSim.some(n => n.includes('escudo da fé')) || magNomesSim.some(n => n.includes('proteção divina'))) {
        rdEstimada += 7;
        reacaoNome = "Magia da Ficha: 'Escudo da Fé' (Reação, 1 PM: +2 Defesa, p. 191) / 'Proteção Divina' (Reação, 1 PM: +2 Resistências, p. 201)";
        reacaoCusto = 1;
    } else if (clSimLow === 'guerreiro' && nd >= 3) {
        rdEstimada += Math.round(danoChefeBase * 0.40);
        reacaoNome = "Habilidade de Classe: 'Durão' (Reação, 3 PM: reduz o dano sofrido à metade, p. 65)";
        reacaoCusto = 3;
    } else if (podNomesSim.includes('rolamento defensivo')) {
        rdEstimada += Math.round(danoChefeBase * 0.40);
        reacaoNome = "Poder da Ficha: 'Rolamento Defensivo' (Reação, 2 PM: reduz o dano sofrido à metade, p. 74)";
        reacaoCusto = 2;
    } else if (podNomesSim.includes('aparar')) {
        rdEstimada += Math.round(danoChefeBase * 0.35);
        reacaoNome = "Poder da Ficha: 'Aparar' (Reação, 1 PM: teste de ataque oposto para evitar o acerto, p. 51)";
        reacaoCusto = 1;
    } else if (clSimLow === 'cavaleiro') {
        const bBal = 2 + 2 * Math.floor((nd - 1) / 4);
        rdEstimada += 6 + bBal;
        reacaoNome = `Habilidade de Classe: 'Baluarte' (Reação, 1 PM: +${bBal} na Defesa e nos Testes de Resistência, p. 56)`;
        reacaoCusto = 1;
    } else if (clSimLow === 'nobre') {
        rdEstimada += 6;
        reacaoNome = "Habilidade de Classe: 'Orgulho' (Reação ao fazer teste, 2 PM: +4 em Resistência, p. 79)";
        reacaoCusto = 2;
    } else if (podNomesSim.includes('sortudo')) {
        rdEstimada += 5;
        reacaoNome = "Poder da Ficha: 'Sortudo' (Reação, 3 PM: rola novamente um teste recém-realizado, p. 129)";
        reacaoCusto = 3;
    }

    // Setup / Ação Livre ou Movimento
    let setupNome = 'Posicionamento Tático & Engajamento (Movimento)';
    let setupCusto = 0;
    let setupJust = 'Mantém o alcance ótimo do estilo de combate sem custo de PM.';
    const ncLow = estado.classe ? estado.classe.nome.toLowerCase() : '';
    const racaLowSim = (estado.raca && estado.raca.nome) ? estado.raca.nome.toLowerCase() : '';
    const memOstSim = (est && est.racaAnteriorOsteon) ? est.racaAnteriorOsteon.toLowerCase() : '';
    const todosPodsSim = [...((est.infoOrigem && est.infoOrigem.poderesExtras) || []), ...((est.infoDevocao && est.infoDevocao.poderes) || []), ...(estado.poderes || [])];
    const infoNatSim = obterInfoArmaNaturalJS(racaLowSim, memOstSim, todosPodsSim);
    const temChifresSim = Boolean(infoNatSim);
    const temGolpePessoalSim = (estado.poderes || []).some(p => (p.nome || '').toLowerCase() === 'golpe pessoal');
    if (ncLow === 'guerreiro') {
        const escEsp = 4 * (1 + Math.floor((nd - 1) / 4));
        setupCusto = 1 + Math.floor((nd - 1) / 4);
        const strGPSim = temGolpePessoalSim ? ' + Golpe Pessoal (Brutal +1d / Elemental +2d6 / Preciso 2d20)' : '';
        const strChSim = infoNatSim ? ` + ${infoNatSim.icone} ${infoNatSim.nomeCurto} (1 PM: +1 atq ${infoNatSim.dadoStr}+FOR)` : '';
        setupNome = `Ataque Especial (${setupCusto} PM: +${escEsp} no Ataque OU +${escEsp} no Dano OU +${escEsp / 2} Atq/+${escEsp / 2} Dano, p. 65)${strGPSim}${strChSim}`;
        setupJust = `Regra Oficial p. 65: aplica +${escEsp} no Teste de Ataque, +${escEsp} na Rolagem de Dano ou divide +${escEsp / 2}/+${escEsp / 2} em 1 ataque.`;
    } else if (ncLow === 'bárbaro') {
        setupNome = 'Fúria (+2 Ataque e +2 Dano corpo a corpo)';
        setupCusto = 2;
        setupJust = 'Aumenta precisão e dano em todos os turnos da cena.';
    } else if (ncLow === 'paladino') {
        setupNome = 'Golpe Divino (+CAR no Ataque e +1d8/+2d8 Dano)';
        setupCusto = 2;
        setupJust = 'Soma Carisma no teste de ataque para romper a Defesa da ameaça.';
    } else if (ncLow === 'caçador') {
        setupNome = 'Marca da Presa (+1d4/+1d8 Dano extra contra a criatura)';
        setupCusto = 1;
        setupJust = 'Adiciona dados extras de dano em cada ataque da rodada.';
    } else if (ehConj) {
        const sigM = est.infoMagia ? est.infoMagia.sigla : 'INT';
        const valM = Math.max(0, est.finais[sigM] || 0);
        setupNome = `Canalização Mágica (${sigM} +${valM} | Limite ${resDano.limitePM} PM/magia)`;
        setupCusto = 0;
        setupJust = `Maximiza os aprimoramentos até ${resDano.limitePM} PM e fixa a CD em ${est.cdMagia}.`;
    }

    const usaMagiaPrincipal = Boolean(ehConj && melhorMag && evDanoMagia >= evDanoArma);
    const matrizDecisoes = [
        {
            tipoAcao: '1. Ação Livre / Movimento (Setup)',
            nomeAcao: setupNome,
            custoPM: setupCusto,
            chancePct: 100,
            ev: ehConj ? Math.max(0, est.finais[est.infoMagia ? est.infoMagia.sigla : 'INT'] || 0) : 4.0,
            veredito: 'BUFF / SETUP ÓTIMO',
            justificativa: setupJust,
            destaque: false
        }
    ];
    if (melhorMag) {
        matrizDecisoes.push({
            tipoAcao: '2. Ação Padrão (Magia Aprimorada)',
            nomeAcao: `Lançar '${melhorMag.nome}' (${melhorMag.info.formulaFinal})`,
            custoPM: custoMag,
            chancePct: probFalhaRes,
            ev: evDanoMagia,
            veredito: usaMagiaPrincipal ? 'MELHOR DECISÃO PRINCIPAL (MAIOR EV)' : '○ OPÇÃO SECUNDÁRIA',
            justificativa: `CD ${est.cdMagia} vs Res. Média +${resChefe} (${probFalhaRes}% falha total [100%], resto 50%) -> EV = ${evDanoMagia} dano/turno.`,
            destaque: usaMagiaPrincipal
        });
    }
    if (danoRaio > 0) {
        matrizDecisoes.push({
            tipoAcao: '2. Ação Padrão (Sustentação 0 PM)',
            nomeAcao: `Combo Raio Arcano (${resDano.descRaio.split('—')[0].trim()})`,
            custoPM: 0,
            chancePct: probFalhaRes,
            ev: evDanoRaio,
            veredito: '○ SUSTENTAÇÃO (ECONOMIA 0 PM)',
            justificativa: `Preserva mana quando PM < ${custoMag} causando EV = ${evDanoRaio} dano/turno a custo zero.`,
            destaque: false
        });
    }
    matrizDecisoes.push({
        tipoAcao: '2. Ação Padrão / Completa (Ataque c/ Arma)',
        nomeAcao: `Atacar com ${nomeArma} [${estiloArma}]`,
        custoPM: ehConj ? 0 : setupCusto,
        chancePct: probAcertoArma,
        ev: evDanoArma,
        veredito: !usaMagiaPrincipal ? 'MELHOR DECISÃO PRINCIPAL (MAIOR EV)' : 'SUBÓTIMO P/ CONJURADOR',
        justificativa: `Ataque +${melhorPerAtq} vs Defesa ${defChefe} (${probAcertoArma}% acerto × ${danoArma} DPR bruto) -> EV = ${evDanoArma} dano/turno.`,
        destaque: !usaMagiaPrincipal
    });
    if (temChifresSim && !ehConj) {
        const temValSim = (estado.poderes || []).some(p => (p.nome || '').toLowerCase() === 'valentão');
        const temSgSim = (estado.poderes || []).concat((est.infoDevocao && est.infoDevocao.poderes) || []).some(p => (p.nome || '').toLowerCase() === 'sangue de ferro');
        const bLutaChSim = (est.bonusPericias['Luta'] || melhorPerAtq) + (temValSim ? 2 : 0);
        const alvosChSim = Math.max(1, Math.min(19, 21 - ((defChefe - 5) - bLutaChSim)));
        const probChSim = Math.round((alvosChSim / 20) * 100);
        const forChSim = Math.max(0, est.finais.FOR) + (temValSim ? 2 : 0) + (temSgSim ? 2 : 0);
        const dBrutoChSim = +(3.675 + forChSim).toFixed(1);
        const evChSim = +(dBrutoChSim * (probChSim / 100)).toFixed(1);
        matrizDecisoes.push({
            tipoAcao: `2A. Ataque Extra Natural — ${infoNatSim.icone} ${infoNatSim.nomeCurto} (${infoNatSim.pagina})`,
            nomeAcao: `${infoNatSim.icone} Ataque Extra c/ ${infoNatSim.nomeCurto} ao Agredir (Ataque +${bLutaChSim} | Dano ${infoNatSim.dadoStr}+${forChSim} perfuração, crít. 20/x2)`,
            custoPM: 1,
            chancePct: probChSim,
            ev: evChSim,
            veredito: 'ATAQUE EXTRA RACIAL (1x/RODADA AO AGREDIR)',
            justificativa: `Regra p. 25: 1x/rodada ao usar a ação Agredir com outra arma, gasta 1 PM para fazer +1 ataque corpo a corpo extra com os chifres (1d6+${forChSim} = ${dBrutoChSim} méd., EV=+${evChSim}).`,
            destaque: true
        });
    }
    if (temGolpePessoalSim && !ehConj) {
        const alvosBaseSim = Math.max(1, Math.min(19, 21 - (defChefe - atqEfetivoDecJS)));
        const probPrecisoSim = Math.round((1 - Math.pow((20 - alvosBaseSim) / 20, 2)) * 100);
        const dBrutoGPSim = +(danoArma * 0.65 + 11.5).toFixed(1);
        const evGPSim = +(dBrutoGPSim * (probPrecisoSim / 100)).toFixed(1);
        matrizDecisoes.push({
            tipoAcao: '2B. Poder de Guerreiro — Golpe Pessoal (p. 66–67)',
            nomeAcao: `Golpe Pessoal c/ ${nomeArma}: Brutal (+1d) + Elemental (+2d6 Fogo) + Preciso (2d20 — escolhe o melhor)`,
            custoPM: Math.min(nd, 4),
            chancePct: probPrecisoSim,
            ev: evGPSim,
            veredito: 'EXPLOSÃO DE DANO MARCIAL (BURST C/ 2d20)',
            justificativa: `Combina Brutal (+1 PM: +1 dado da arma), Elemental (+2 PM: +2d6 fogo) e Preciso (+1 PM: rola 2d20 no ataque, elevando o acerto de ${probAcertoArma}% para ${probPrecisoSim}% -> EV=${evGPSim}).`,
            destaque: true
        });
    }
    matrizDecisoes.push({
        tipoAcao: '3. Reação Defensiva (Turno da Criatura)',
        nomeAcao: reacaoNome,
        custoPM: reacaoCusto,
        chancePct: 100,
        ev: rdEstimada,
        veredito: 'REAÇÃO DEFENSIVA ÓTIMA',
        justificativa: `Mitiga em ~${rdEstimada} pts o dano médio da ameaça (Ataque +${atqChefe} vs Defesa ${est.defesa}).`,
        destaque: false
    });

    const melhorSequencia = `1º [Livre/Setup] ${setupNome} (${setupCusto} PM) 2º [Ação Padrão Ótima] ` +
        (usaMagiaPrincipal
            ? `Lançar '${melhorMag.nome}' aprimorada (${custoMag} PM, EV=${evDanoMagia} dano) nos turnos iniciais e alternar para Raio Arcano (0 PM, EV=${evDanoRaio}) se PM acabar`
            : `Atacar com ${nomeArma} [${estiloArma}] (Ataque +${melhorPerAtq} vs Def ${defChefe}, EV=${evDanoArma} dano/rod)`) +
        ` 3º [Reação] ${reacaoNome}.`;

    let vitorias = 0, somaDPR = 0, somaDanoSofrido = 0, somaRod = 0, somaPV = 0, somaPM = 0;
    const logs = [];
    const turnosDetalhados = [];
    const episodios = 25;
    let seed = 1337 + nd * 17 + est.pvMax * 3 + est.pmMax * 5;
    function rand() { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; }
    function d20() { return Math.floor(rand() * 20) + 1; }

    for (let ep = 0; ep < episodios; ep++) {
        let pvH = est.pvMax, pmH = est.pmMax, pvC = pvChefeMax, danoEp = 0, sofridoEp = 0, rod = 0;
        const turnosEp = [];
        const logsEp = [];
        while (pvH > 0 && pvC > 0 && rod < 20) {
            rod++;
            let dCausado = 0, acaoPadrao = '', rolagemTxt = '';
            const acaoLivre = (setupCusto === 0 || pmH >= setupCusto) ? setupNome : 'Movimento Tático (0 PM)';

            if (ehConj && melhorMag && pmH >= custoMag && danoMagMax > danoArma) {
                pmH -= custoMag;
                const dRes = d20();
                const rRes = dRes + resChefe;
                const passou = rRes >= est.cdMagia;
                dCausado = +(danoMagMax * (0.92 + 0.16 * rand()) * (passou ? 0.5 : 1.0)).toFixed(1);
                acaoPadrao = `Magia '${melhorMag.nome}' (${melhorMag.info.formulaFinal}) [-${custoMag} PM]`;
                rolagemTxt = `Res. Criatura: d20(${dRes})+${resChefe}=${rRes} vs CD ${est.cdMagia} (${passou ? 'Passou: 50% dano' : 'FALHOU: 100% dano!'})`;
            } else if (ehConj && danoRaio > danoArma) {
                const dRes = d20();
                const rRes = dRes + resChefe;
                const passou = rRes >= est.cdMagia;
                dCausado = +(danoRaio * (0.92 + 0.16 * rand()) * (passou ? 0.5 : 1.0)).toFixed(1);
                acaoPadrao = 'Combo Raio Arcano [0 PM — Sustentação]';
                rolagemTxt = `Res. Criatura: d20(${dRes})+${resChefe}=${rRes} vs CD ${est.cdMagia} (${passou ? 'Passou: 50%' : 'FALHOU: 100%!'})`;
            } else {
                const cEsp = (!ehConj && pmH >= setupCusto) ? setupCusto : 0;
                pmH -= cEsp;
                const escVal = (ncLow === 'guerreiro' && cEsp > 0) ? (4 * cEsp) : 0;
                // Usa Ataque Especial focado em Ataque (+escVal no teste de ataque, +0 no dano) ou Golpe Pessoal no Turno 1
                const usaGP = temGolpePessoalSim && rod === 1 && pmH >= 3;
                if (usaGP) pmH -= 3;
                const d20A = d20();
                const d20B = usaGP ? d20() : d20A;
                const rAtq = usaGP ? Math.max(d20A, d20B) : d20A;
                const strD20 = usaGP ? `2d20(${d20A},${d20B}${rAtq} Preciso)` : `d20(${rAtq})`;
                const defAlvoTurno = (rod === 1) ? Math.max(10, defChefe - 5) : defChefe;
                const totAtq = rAtq + melhorPerAtq + escVal;
                const acertou = rAtq === 20 || (rAtq !== 1 && totAtq >= defAlvoTurno);
                const crit = acertou && rAtq >= 19;
                const tagGastos = [];
                if (cEsp) tagGastos.push(ncLow === 'guerreiro' ? `Ataque Especial -${cEsp} PM: +${escVal} Atq` : `-${cEsp} PM`);
                if (usaGP) tagGastos.push(`Golpe Pessoal -3 PM: Brutal+Elemental+Preciso`);
                acaoPadrao = `Agredir c/ ${nomeArma} [${estiloArma}]${tagGastos.length ? ' (' + tagGastos.join(' | ') + ')' : ''}`;
                if (acertou) {
                    const dGolpeP = +((danoArma * 0.72) * (crit ? 1.45 : 1.0) * (0.94 + 0.12 * rand()) + (usaGP ? 10.5 : 0)).toFixed(1);
                    dCausado += dGolpeP;
                    rolagemTxt = `${strD20}+${melhorPerAtq + escVal}=${totAtq} vs Def ${defAlvoTurno}${rod === 1 ? ' [Desprevenido -5]' : ''} (${crit ? 'CRÍTICO!' : 'ACERTOU!'}: ${dGolpeP} dano)`;
                } else {
                    rolagemTxt = `${strD20}+${melhorPerAtq + escVal}=${totAtq} vs Def ${defAlvoTurno} (ERROU)`;
                }
                // Habilidade Racial Chifres (Minotauro p. 25): 1 PM ao Agredir -> +1 ataque corpo a corpo extra (1d6+FOR perfuração)
                if (temChifresSim && pmH >= 1) {
                    pmH -= 1;
                    const rCh = d20();
                    const temValTurn = (estado.poderes || []).some(p => (p.nome || '').toLowerCase() === 'valentão');
                    const temSgTurn = (estado.poderes || []).concat((est.infoDevocao && est.infoDevocao.poderes) || []).some(p => (p.nome || '').toLowerCase() === 'sangue de ferro');
                    const bLutaCh = (est.bonusPericias['Luta'] || melhorPerAtq) + (temValTurn ? 2 : 0);
                    const fixoChTurn = Math.max(0, est.finais.FOR) + (temValTurn ? 2 : 0) + (temSgTurn ? 2 : 0);
                    const totCh = rCh + bLutaCh;
                    const acCh = rCh === 20 || (rCh !== 1 && totCh >= defAlvoTurno);
                    acaoPadrao += ` + ${infoNatSim.icone} Ataque Extra ${infoNatSim.nomeCurto} (-1 PM)`;
                    if (acCh) {
                        const d6Ch = Math.floor(rand() * 6) + 1 + (rCh === 20 ? (Math.floor(rand() * 6) + 1) : 0);
                        const dChTot = d6Ch + fixoChTurn;
                        dCausado = +(dCausado + dChTot).toFixed(1);
                        rolagemTxt += ` | ${infoNatSim.icone} ${infoNatSim.nomeCurto}: d20(${rCh})+${bLutaCh}=${totCh} (ACERTOU: ${infoNatSim.dadoStr}[${d6Ch}]+${fixoChTurn} = +${dChTot} perfuração)`;
                    } else {
                        rolagemTxt += ` | ${infoNatSim.icone} ${infoNatSim.nomeCurto}: d20(${rCh})+${bLutaCh}=${totCh} (ERROU)`;
                    }
                }
            }
            const pvCAntes = pvC;
            pvC = Math.max(0, pvC - dCausado);
            danoEp += dCausado;

            let dSofrido = 0;
            let acaoCriatura = 'Criatura derrotada (0 PV) — não age!';
            if (pvC > 0) {
                const rIni = d20();
                const totIni = rIni + atqChefe;
                if (rIni === 20 || (rIni !== 1 && totIni >= est.defesa)) {
                    const brutoIni = Math.round(danoChefeBase * (0.88 + 0.24 * rand()));
                    dSofrido = Math.max(1, brutoIni - rdEstimada);
                    pvH = Math.max(0, pvH - dSofrido);
                    acaoCriatura = `Ataque d20(${rIni})+${atqChefe}=${totIni} vs Def ${est.defesa} (Acertou: ${brutoIni} bruto - ${rdEstimada} mitigação = ${dSofrido} dano)`;
                } else {
                    acaoCriatura = `Ataque d20(${rIni})+${atqChefe}=${totIni} vs Def ${est.defesa} (Errou o Herói!)`;
                }
            }
            sofridoEp += dSofrido;
            turnosEp.push({
                turno: rod,
                acaoLivre,
                acaoPadrao,
                rolagemTxt,
                danoCausado: dCausado,
                pvCriaturaApos: `${Math.round(pvCAntes)} ${Math.round(pvC)}/${pvChefeMax} PV`,
                acaoCriatura,
                danoSofrido: dSofrido,
                saldoHeroi: `PV: ${Math.round(pvH)}/${est.pvMax} | PM: ${Math.round(pmH)}/${est.pmMax}`
            });
            logsEp.push(`Turno ${rod}: [Livre] ${acaoLivre} | [Padrão] ${acaoPadrao} (${rolagemTxt}) -> ${dCausado} dano | Criatura PV: ${Math.round(pvC)}/${pvChefeMax} | [Inimigo] ${acaoCriatura}`);
        }
        const chifresHitEp = turnosEp.some(t => t.rolagemTxt.includes('Chifres:') && t.rolagemTxt.includes('ACERTOU:'));
        const gpHitEp = turnosEp.some(t => t.rolagemTxt.includes('Preciso') && (t.rolagemTxt.includes('ACERTOU') || t.rolagemTxt.includes('CRÍTICO')));
        const jaTemCombo = turnosDetalhados.some(t => t.rolagemTxt.includes('Chifres:') && t.rolagemTxt.includes('ACERTOU:')) && turnosDetalhados.some(t => t.rolagemTxt.includes('Preciso') && (t.rolagemTxt.includes('ACERTOU') || t.rolagemTxt.includes('CRÍTICO')));
        if (turnosDetalhados.length === 0 || (!jaTemCombo && chifresHitEp && gpHitEp && pvC <= 0)) {
            turnosDetalhados.length = 0;
            turnosDetalhados.push(...turnosEp);
            logs.length = 0;
            logs.push(...logsEp);
        }
        if (pvC <= 0 && pvH > 0) vitorias++;
        somaRod += rod;
        somaDPR += danoEp / Math.max(1, rod);
        somaDanoSofrido += sofridoEp / Math.max(1, rod);
        somaPV += (pvH / Math.max(1, est.pvMax)) * 100;
        somaPM += (pmH / Math.max(1, est.pmMax)) * 100;
    }

    const winSolo = +((vitorias / episodios) * 100).toFixed(1);
    const winLacaio = Math.min(100, +(winSolo + 14.0).toFixed(1));
    const winEspecial = Math.min(100, +(winSolo + 8.0).toFixed(1));
    const dprEfetivo = +(somaDPR / episodios).toFixed(1);
    const sofridoMedio = Math.max(1, +(somaDanoSofrido / episodios).toFixed(1));
    const ttkHeroi = +(pvChefeMax / Math.max(1, dprEfetivo)).toFixed(1);
    const ttkAmeaca = +(est.pvMax / sofridoMedio).toFixed(1);

    const pvLac1v1 = Math.max(12, Math.round(amLac.pv * 0.35));
    const pvEsp1v1 = Math.max(18, Math.round(amEsp.pv * 0.35));
    const tabelaPapeis = [
        {
            papel: 'Solo (Chefe Combatente)',
            ataque: amSolo.bonus_ataque, danoMedio: amSolo.dano_medio, defesa: amSolo.defesa,
            resForte: amSolo.res_forte, resMedia: amSolo.res_media, resFraca: amSolo.res_fraca,
            pvGrupo4: amSolo.pv, pv1v1: pvChefeMax, cd: amSolo.cd_efeito,
            ttk: ttkHeroi, win: winSolo
        },
        {
            papel: 'Lacaio (Grupo / Capanga)',
            ataque: amLac.bonus_ataque, danoMedio: amLac.dano_medio, defesa: amLac.defesa,
            resForte: amLac.res_forte, resMedia: amLac.res_media, resFraca: amLac.res_fraca,
            pvGrupo4: amLac.pv, pv1v1: pvLac1v1, cd: amLac.cd_efeito,
            ttk: +(pvLac1v1 / Math.max(1, dprEfetivo)).toFixed(1), win: winLacaio
        },
        {
            papel: 'Especial (Conjurador / Líder)',
            ataque: amEsp.bonus_ataque, danoMedio: amEsp.dano_medio, defesa: amEsp.defesa,
            resForte: amEsp.res_forte, resMedia: amEsp.res_media, resFraca: amEsp.res_fraca,
            pvGrupo4: amEsp.pv, pv1v1: pvEsp1v1, cd: amEsp.cd_efeito,
            ttk: +(pvEsp1v1 / Math.max(1, dprEfetivo)).toFixed(1), win: winEspecial
        }
    ];

    const explicacaoWinrate = `Em ${episodios} combates Monte Carlo contra a Ameaça Solo ND ${nd} (Def ${defChefe}, Res. Média +${resChefe}, Cota 1v1 ${pvChefeMax} PV), o herói venceu ${vitorias}/${episodios} episódios (${winSolo}%). Razão Matemática: Com a decisão ótima, o herói causa ${dprEfetivo} de dano efetivo/turno (derrubando os ${pvChefeMax} PV da ameaça em TTK = ${ttkHeroi} turnos), enquanto sofre em média ${sofridoMedio} de dano/turno (suportando até TTK_inimigo = ${ttkAmeaca} turnos com seus ${est.pvMax} PV).`;

    return {
        nomeAmeaca: `Ameaça Oficial p.323 — ${amSolo.patamar} (ND ${nd} Solo)`,
        patamar: amSolo.patamar,
        nd,
        pvGrupo4,
        pvAmeaca: pvChefeMax,
        defAmeaca: defChefe,
        atqAmeaca: amSolo.bonus_ataque,
        danoMedioAmeaca: amSolo.dano_medio,
        resForte: amSolo.res_forte,
        resMedia: amSolo.res_media,
        resFraca: amSolo.res_fraca,
        cdEfeito: amSolo.cd_efeito,
        episodios,
        vitorias,
        taxaVitoria: winSolo,
        taxaVitoriaLacaio: winLacaio,
        taxaVitoriaEspecial: winEspecial,
        danoEfetivo: dprEfetivo,
        rodadasMedias: +(somaRod / episodios).toFixed(1),
        pvRestPct: Math.round(somaPV / episodios),
        pmRestPct: Math.round(somaPM / episodios),
        explicacaoWinrate,
        melhorSequencia,
        tabelaPapeis,
        matrizDecisoes,
        turnosDetalhados,
        logs
    };
}

function gerarLinhasAuditoriaScoreJS(estado, est, resDano) {
    const arq = (estado.arquetipo || 'Dano Marcial').toLowerCase();
    const atr = est.finais;
    const poderes = estado.poderes || [];
    const magias = estado.magias || [];
    const linhas = [];

    if (arq.includes('tanque') || arq.includes('defesa')) {
        linhas.push(['Sobrevivência (PV Máximos)', `${est.pvMax} PV × peso 2.2`, +(est.pvMax * 2.2).toFixed(1)]);
        linhas.push(['Mitigação & Couraça (Defesa)', `(${est.defesa} - 10) Def × peso 14.0`, +((est.defesa - 10) * 14.0).toFixed(1)]);
        linhas.push(['Resiliência Física (Fortitude)', `Bônus +${est.bonusPericias['Fortitude'] || 0} × peso 5.0`, +((est.bonusPericias['Fortitude'] || 0) * 5.0).toFixed(1)]);
        linhas.push(['Resiliência Mental (Vontade)', `Bônus +${est.bonusPericias['Vontade'] || 0} × peso 3.5`, +((est.bonusPericias['Vontade'] || 0) * 3.5).toFixed(1)]);
        let ptsP = 0; const nms = [];
        for (const p of poderes) {
            const ef = (p.nome + ' ' + p.efeito_resumo).toLowerCase();
            const g = /(defesa|redução de dano|rd|pv|escudo|armadura|resistência|encouraçado|inexpugnável|esquiva|vitalidade|torre)/.test(ef) ? 24 : 6;
            ptsP += g; nms.push(`${p.nome} (+${g})`);
        }
        linhas.push(['Sinergia Defensiva dos Poderes', nms.join(', ') || 'Nenhum', ptsP]);
    } else if (arq.includes('arcano') || arq.includes('conjurador')) {
        const nmB = resDano.melhorMagiaInfo ? resDano.melhorMagiaInfo.nome : 'N/A';
        linhas.push(['Dano Explosivo de Magia (Aprimorada)', `${nmB}: média ${resDano.maiorDanoMagia} × peso 2.8`, +(resDano.maiorDanoMagia * 2.8).toFixed(1)]);
        linhas.push(['Dano Sustentado 0 PM (Raio Arcano)', `Média ${resDano.danoMedioRaio}/rod × peso 3.2`, +(resDano.danoMedioRaio * 3.2).toFixed(1)]);
        linhas.push(['Teto de Conjuração (Limite PM/Magia)', `${resDano.limitePM} PM/magia × peso 9.5`, +(resDano.limitePM * 9.5).toFixed(1)]);
        linhas.push(['Dificuldade de Resistência (CD Magia)', `(${est.cdMagia} - 10) CD × peso 18.0`, +((est.cdMagia - 10) * 18.0).toFixed(1)]);
        linhas.push(['Reserva de Mana (PM Máximos)', `${est.pmMax} PM × peso 3.0`, +(est.pmMax * 3.0).toFixed(1)]);
        linhas.push(['Atributo-Chave de Conjuração', `Mod +${Math.max(atr.INT, atr.CAR)} × peso 14.0`, +(Math.max(atr.INT, atr.CAR) * 14.0).toFixed(1)]);
        let ptsP = 0; const nms = [];
        for (const p of poderes) {
            const nl = p.nome.toLowerCase();
            const g = ['arcano de batalha', 'magia ilimitada', 'fortalecimento arcano', 'raio arcano', 'raio elemental', 'raio poderoso', 'poder mágico', 'magia acelerada', 'foco em magia'].includes(nl) ? 32 : (['vontade de ferro', 'bênção do mana', 'conhecimento mágico', 'magia pungente', 'aumento de atributo'].includes(nl) ? 22 : 4);
            ptsP += g; nms.push(`${p.nome} (+${g})`);
        }
        linhas.push(['Sinergia Arcana dos Poderes', nms.join(', ') || 'Nenhum', ptsP]);
    } else if (arq.includes('suporte') || arq.includes('divino')) {
        linhas.push(['Reserva de Mana Divina (PM)', `${est.pmMax} PM × peso 2.6`, +(est.pmMax * 2.6).toFixed(1)]);
        linhas.push(['Sabedoria & Fé (Atrib. Chave)', `SAB +${atr.SAB} × peso 12.0`, +(atr.SAB * 12.0).toFixed(1)]);
        linhas.push(['Sustentação (PV & Defesa)', `${est.pvMax} PV (×1.4) + Def (${est.defesa}-10)×8.0`, +(est.pvMax * 1.4 + (est.defesa - 10) * 8.0).toFixed(1)]);
        let ptsM = 0; for (const m of magias) ptsM += (m.circulo || 1) * 15 + 10;
        linhas.push(['Grimório de Cura & Buffs', `${magias.length} magias divinas`, ptsM]);
        let ptsP = 0; const nms = [];
        for (const p of poderes) {
            const ef = (p.nome + ' ' + p.efeito_resumo).toLowerCase();
            const g = /(cura|aliado|pm|defesa|orar|fé|sagrado|vontade)/.test(ef) ? 22 : 6;
            ptsP += g; nms.push(`${p.nome} (+${g})`);
        }
        linhas.push(['Sinergia de Suporte dos Poderes', nms.join(', ') || 'Nenhum', ptsP]);
    } else {
        const melhorAtq = Math.max(est.bonusPericias['Luta'] || 0, est.bonusPericias['Pontaria'] || 0);
        linhas.push(['Dano Médio por Rodada (DPR Arma)', `${resDano.danoMedioArma} dano/rod × peso 4.2`, +(resDano.danoMedioArma * 4.2).toFixed(1)]);
        linhas.push(['Precisão de Ataque (Luta/Pontaria)', `Bônus +${melhorAtq} × peso 8.0`, +(melhorAtq * 8.0).toFixed(1)]);
        linhas.push(['Vigor & Fôlego (PV + PM)', `${est.pvMax} PV (×1.5) + ${est.pmMax} PM (×1.5)`, +((est.pvMax + est.pmMax) * 1.5).toFixed(1)]);
        linhas.push(['Estabilidade Defensiva (Defesa)', `(${est.defesa} - 10) Def × peso 6.0`, +((est.defesa - 10) * 6.0).toFixed(1)]);
        let ptsP = 0; const nms = [];
        for (const p of poderes) {
            const nl = p.nome.toLowerCase();
            const g = ['golpe pessoal', 'estilo de duas mãos', 'ataque poderoso', 'destruidor', 'ataque pesado', 'trespassar', 'valentão', 'especialização em arma', 'foco em arma', 'empunhadura poderosa', 'aumento de atributo', 'estilo de disparo', 'arqueiro', 'disparo rápido', 'disparo preciso', 'mira apurada'].includes(nl) ? 28 : 6;
            ptsP += g; nms.push(`${p.nome} (+${g})`);
        }
        const rnAudit = (estado.raca && estado.raca.nome) ? estado.raca.nome.toLowerCase() : '';
        const moAudit = (est && est.racaAnteriorOsteon) ? est.racaAnteriorOsteon.toLowerCase() : '';
        const todosPodsAud = [...((est.infoOrigem && est.infoOrigem.poderesExtras) || []), ...((est.infoDevocao && est.infoDevocao.poderes) || []), ...poderes];
        const infoNatAud = obterInfoArmaNaturalJS(rnAudit, moAudit, todosPodsAud);
        if (infoNatAud) {
            const forCh = Math.max(0, atr.FOR) + (todosPodsAud.some(p => (p.nome || '').toLowerCase() === 'sangue de ferro') ? 2 : 0) + (todosPodsAud.some(p => (p.nome || '').toLowerCase() === 'valentão') ? 2 : 0);
            const dMedCh = +(infoNatAud.mediaDadoCrit + forCh).toFixed(1);
            linhas.push([`${infoNatAud.icone} Ataque Extra: ${infoNatAud.nomeCurto} (${infoNatAud.pagina})`, `1 PM ao Agredir +1 ataque extra (${infoNatAud.dadoStr}+${forCh} perfuração = +${dMedCh} dano méd. × 4.2)`, +(dMedCh * 4.2).toFixed(1)]);
        }
        if (poderes.some(p => (p.nome || '').toLowerCase() === 'golpe pessoal')) {
            linhas.push(['Poder de Guerreiro: Golpe Pessoal Otimizado (Nv 5+, p. 66–67)', 'Destruidor (+1x Crít) + Letal (+2 Margem) + Brutal (+1d) + Preciso (2d20 — escolhe o melhor) + Lento (-2 PM)', 38.0]);
        }
        linhas.push(['Sinergia Marcial dos Poderes', nms.join(', ') || 'Nenhum', ptsP]);
    }

    const nViol = (estado.validacoes || []).length;
    linhas.push([
        nViol > 0 ? 'Penalidade por Violação CSP' : 'Consistência de Regras CSP',
        nViol > 0 ? `${nViol} violação(ões) × -200.0` : '0 violações (Pré-requisitos & Proficiências 100% OK)',
        nViol > 0 ? -200 * nViol : 0
    ]);

    return linhas.map(([nm, mem, pts]) =>
        `<tr><td><strong>${nm}</strong></td><td>${mem}</td><td style="text-align:right;font-weight:700;color:#FDE047;">${pts >= 0 ? '+' + pts.toFixed(1) : pts.toFixed(1)} pts</td></tr>`
    ).join('');
}

function construirHTMLArvore(estado) {
    const passos = estado.passosArvore || [];
    const largPasso = 235;
    const largSvg = Math.max(760, passos.length * largPasso + 80);
    const yPrin = 95;
    let svgParts = [];

    passos.forEach((p, idx) => {
        const xC = 115 + idx * largPasso;
        if (idx < passos.length - 1) {
            svgParts.push(`<line x1="${xC + 85}" y1="${yPrin}" x2="${115 + (idx + 1) * largPasso - 85}" y2="${yPrin}" stroke="#C89D54" stroke-width="4" />`);
        }
        (p.alts || []).slice(0, 2).forEach((alt, iAlt) => {
            const yAlt = 215 + iAlt * 82;
            const corB = alt.tipo === 'PODADO_CSP' ? '#B42318' : '#64748B';
            const corF = alt.tipo === 'PODADO_CSP' ? '#FDECEA' : '#F1F5F9';
            const ico = alt.tipo === 'PODADO_CSP' ? 'CSP' : `○ N=${alt.visitas || 0}`;
            const xOrig = xC - 30;
            svgParts.push(`<path d="M ${xOrig} ${yPrin + 34} C ${xOrig} ${yAlt}, ${xC - 80} ${yAlt}, ${xC - 75} ${yAlt}" fill="none" stroke="${corB}" stroke-width="2" stroke-dasharray="5,4" />`);
            svgParts.push(`<rect x="${xC - 78}" y="${yAlt - 24}" width="156" height="48" rx="7" fill="${corF}" stroke="${corB}" stroke-width="1.8" />`);
            svgParts.push(`<text x="${xC}" y="${yAlt - 5}" text-anchor="middle" font-size="11" font-weight="bold" fill="${corB}">${ico}: ${(alt.nome || '').slice(0, 18)}</text>`);
            svgParts.push(`<text x="${xC}" y="${yAlt + 12}" text-anchor="middle" font-size="9.5" fill="#475569">${(alt.motivo || '').slice(0, 25)}</text>`);
        });
        const met = p.fase.includes('MCTS') ? `N=${p.visitas} | Score=${Math.round(p.score)}` : p.fase;
        svgParts.push(`<rect x="${xC - 85}" y="${yPrin - 36}" width="170" height="72" rx="10" fill="#7A181D" stroke="#C89D54" stroke-width="2.5" />`);
        svgParts.push(`<text x="${xC}" y="${yPrin - 16}" text-anchor="middle" font-size="10" font-weight="bold" fill="#F3E5AB">${(p.cat || '').slice(0, 22)}</text>`);
        svgParts.push(`<text x="${xC}" y="${yPrin + 4}" text-anchor="middle" font-size="12" font-weight="bold" fill="#FFFFFF">${(p.vencedor || '').slice(0, 20)}</text>`);
        svgParts.push(`<text x="${xC}" y="${yPrin + 22}" text-anchor="middle" font-size="10" fill="#E2E8F0">${met}</text>`);
    });

    const cardsHtml = passos.map(p => {
        const badgeCor = p.fase.includes('MCTS') ? '#8B1E24' : '#1E6F43';
        const metBadge = p.fase.includes('MCTS')
            ? `<span class="tag">Visitas N=${p.visitas} · Q/N=${p.score.toFixed(1)} · UCT=${p.uct.toFixed(1)}</span>`
            : '';
        const altsHtml = (p.alts || []).map(a =>
            a.tipo === 'PODADO_CSP'
                ? `<div class="tree-branch-pruned"><strong>[Podado pelo CSP] ${a.nome}</strong> — ${a.motivo}</div>`
                : `<div class="tree-branch-alt"><strong>○ [Ramo Alternativo${a.visitas ? ' N=' + a.visitas : ''}] ${a.nome}</strong> — ${a.motivo}</div>`
        ).join('');
        return `<div class="tree-step-card">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;">
                <div><span class="tag" style="background:${badgeCor};color:#FFF;">${p.fase}</span> <strong>${p.cat}</strong></div>
                <div>${metBadge}</div>
            </div>
            <div class="tree-winner-box"><strong>Escolha Vencedora: ${p.vencedor}</strong><div style="font-size:12px;color:#4A3F35;margin-top:3px;">${p.detalhe}</div></div>
            ${altsHtml}
        </div>`;
    }).join('');

    return `
    <div class="sheet-card">
        <div class="sheet-banner">
            <div>
                <h2 class="sheet-title">Árvore de Escolhas do Algoritmo (CSP + MCTS)</h2>
                <div style="font-size:13px;color:var(--t20-muted);">
                    Personagem: <strong>${estado.nome}</strong> | Arquétipo: <strong>${estado.arquetipo}</strong> |
                    Iterações MCTS: <strong>${estado.iteracoes}</strong> | Nós Expandidos: <strong>${estado.nosExpandidos}</strong> |
                    Podas CSP (AC-3): <strong>${estado.podasCSP}</strong>
                </div>
            </div>
            <div><span class="tag" style="font-size:13px;padding:6px 10px;">Score: ${estado.scoreInicial.toFixed(1)} → ${estado.scoreFinal.toFixed(1)}</span></div>
        </div>
        <div style="font-size:12px;color:var(--t20-muted);margin-bottom:8px;">
            <strong>Dica Mobile:</strong> Deslize horizontalmente no diagrama abaixo para inspecionar todos os níveis da árvore.
        </div>
        <div class="tree-scroll-wrapper"><svg width="${largSvg}" height="360" viewBox="0 0 ${largSvg} 360" xmlns="http://www.w3.org/2000/svg" style="font-family:'Segoe UI',sans-serif;">${svgParts.join('')}</svg></div>
        <h3 style="color:#FDE047;margin:18px 0 10px 0;font-size:15px;text-transform:uppercase;">
            Detalhamento Nível a Nível do Caminho Traçado (${passos.length} Decisões)
        </h3>
        ${cardsHtml}
    </div>`;
}

function alternarTemaFichaClarasEscurasJS() {
    const atual = document.body.getAttribute('data-app-theme') || 'DARK';
    const novo = (atual === 'PARCHMENT') ? 'DARK' : 'PARCHMENT';
    if (novo === 'DARK') document.body.removeAttribute('data-app-theme');
    else document.body.setAttribute('data-app-theme', 'PARCHMENT');
    tocarSomJRPG('UI_CLICK');
    const btnT = document.getElementById('btn-toggle-tema-ficha');
    if (btnT) {
        btnT.innerHTML = novo === 'PARCHMENT'
            ? 'Mudar p/ Tema Escuro (Grimório)'
            : 'Mudar p/ Tema Ficha Clássica Impressa (Clara)';
    }
}

function ajustarPVPMFichaDiretoJS(tipo, delta) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    if (st.pvAtualFicha === undefined) st.pvAtualFicha = st.est.pvMax;
    if (st.pmAtualFicha === undefined) st.pmAtualFicha = st.est.pmMax;
    if (tipo === 'PV') {
        st.pvAtualFicha = (delta === 999) ? st.est.pvMax : Math.max(-Math.floor(st.est.pvMax / 2), Math.min(st.est.pvMax, st.pvAtualFicha + delta));
        const el = document.getElementById('ficha-input-pv-atual');
        if (el) el.textContent = st.pvAtualFicha;
    } else {
        st.pmAtualFicha = (delta === 999) ? st.est.pmMax : Math.max(0, Math.min(st.est.pmMax, st.pmAtualFicha + delta));
        const el = document.getElementById('ficha-input-pm-atual');
        if (el) el.textContent = st.pmAtualFicha;
    }
    if (__ARENA_STATE__) {
        if (tipo === 'PV') __ARENA_STATE__.pvHeroi = Math.max(0, st.pvAtualFicha);
        else __ARENA_STATE__.pmHeroi = Math.max(0, st.pmAtualFicha);
        atualizarPlacarVisualArena();
    }
}

function aoMudarAlvosAreaMagiaFichaJS(val) {
    window.__ALVOS_AREA_MAGIA_OVERRIDE__ = parseInt(val || '0', 10);
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (st) {
        renderizarFichaEArvoreClientSide(st, 'tab-ficha');
    }
}

function rolarMagiaDaFichaOficialJS(nomeMagia, formulaDano, cdMagia, resistenciaTxt, numAlvosArea) {
    tocarSomJRPG('MAGIA');
    const stRef = calcularDanoMinMaxMedioFormulaJS(formulaDano, 2, false);
    const regexTermosDados = /(\d+)d(\d+)/gi;
    let matchD;
    let somaD = 0;
    const partesRoladas = [];
    while ((matchD = regexTermosDados.exec(formulaDano)) !== null) {
        const qBase = parseInt(matchD[1], 10);
        const faces = parseInt(matchD[2], 10);
        const rolagensGrupo = [];
        for (let i = 0; i < qBase; i++) {
            const r = Math.floor(Math.random() * faces) + 1;
            somaD += r;
            rolagensGrupo.push(r);
        }
        partesRoladas.push(`${qBase}d${faces}[${rolagensGrupo.join('+')}]`);
    }
    const semDados = formulaDano.replace(/(\d+)d(\d+)/gi, ' ');
    const regexFixos = /([+-]\s*\d+)/g;
    let mf;
    let fixoTotal = 0;
    while ((mf = regexFixos.exec(semDados)) !== null) {
        fixoTotal += parseInt(mf[1].replace(/\s+/g, ''), 10) || 0;
    }
    const dano1Alvo = Math.max(1, somaD + fixoTotal);
    const nAlv = Math.max(1, parseInt(numAlvosArea || 1, 10));
    const danoTotalArea = dano1Alvo * nAlv;
    const strArea = nAlv > 1
        ? ` &nbsp;|&nbsp; <strong>Dano Total em Área (${nAlv} alvos atingidos): <span style="color:#FACC15;font-size:16px;">${danoTotalArea}</span></strong> <small style="color:#A7F3D0;">(Mín Área ${stRef.min * nAlv} | Máx Área ${stRef.max * nAlv} | Méd Área ${(stRef.medio * nAlv).toFixed(1)})</small>`
        : '';

    const toast = document.getElementById('ficha-quick-roll-toast');
    if (toast) {
        toast.style.display = 'block';
        toast.innerHTML = `<strong>Magia: ${nomeMagia} (CD ${cdMagia} · ${resistenciaTxt}):</strong> Rolou <code>${partesRoladas.join(' + ')}${fixoTotal > 0 ? ' + ' + fixoTotal : ''}</code> <strong>Dano por Alvo: <span style="color:#4ADE80;font-size:15px;">${dano1Alvo}</span></strong> <small>(Mín ${stRef.min} | Máx ${stRef.max} | Méd ${stRef.medio})</small>${strArea}`;
    }
}

function rolarTesteDaFichaOficialJS(titulo, bonus, formulaDano, critMargem, critMult, usa2d20Melhor) {
    tocarSomJRPG('DADOS');
    const d1 = Math.floor(Math.random() * 20) + 1;
    const d2 = usa2d20Melhor ? (Math.floor(Math.random() * 20) + 1) : d1;
    const d20 = usa2d20Melhor ? Math.max(d1, d2) : d1;
    const total = d20 + bonus;
    const marg = critMargem || 20;
    const mult = critMult || 2;
    const ehCrit = d20 >= marg;
    const ehFumble = d20 === 1;
    let msgDano = '';
    if (formulaDano) {
        const statsRef = calcularDanoMinMaxMedioFormulaJS(formulaDano);
        const regexTermosDados = /(\d+)d(\d+)/gi;
        let matchD;
        let idxGrupo = 0;
        let somaD = 0;
        const partesRoladas = [];
        while ((matchD = regexTermosDados.exec(formulaDano)) !== null) {
            const qBase = parseInt(matchD[1], 10);
            const faces = parseInt(matchD[2], 10);
            // Regra Oficial T20 (p. 231): apenas os dados base da arma (1º grupo) multiplicam no crítico!
            const qFinal = (ehCrit && idxGrupo === 0) ? (qBase * mult) : qBase;
            const rolagensGrupo = [];
            for (let i = 0; i < qFinal; i++) {
                const r = Math.floor(Math.random() * faces) + 1;
                somaD += r;
                rolagensGrupo.push(r);
            }
            partesRoladas.push(`${qFinal}d${faces}[${rolagensGrupo.join('+')}]`);
            idxGrupo++;
        }
        const semDados = formulaDano.replace(/(\d+)d(\d+)/gi, ' ');
        const regexFixos = /([+-]\s*\d+)/g;
        let mf;
        let fixoTotal = 0;
        while ((mf = regexFixos.exec(semDados)) !== null) {
            fixoTotal += parseInt(mf[1].replace(/\s+/g, ''), 10) || 0;
        }
        const totDano = Math.max(1, somaD + fixoTotal);
        msgDano = ` &nbsp;|&nbsp; <strong>Dano${ehCrit ? ' CRÍTICO (x' + mult + ')' : ''}:</strong> <code>${partesRoladas.join(' + ')}${fixoTotal >= 0 ? ' + ' + fixoTotal : ' - ' + Math.abs(fixoTotal)}</code> = <strong style="color:#FACC15;font-size:16px;">${totDano}</strong> <small style="color:#A7F3D0;">(Mín ${statsRef.min} | Máx ${statsRef.max} | Méd ${statsRef.medio})</small>`;
    }
    const strDadoRolado = usa2d20Melhor
        ? `2d20(${d1}, ${d2} Melhor: ${d20})`
        : `1d20(${d20})`;
    const toast = document.getElementById('ficha-quick-roll-toast');
    if (toast) {
        toast.style.display = 'block';
        toast.innerHTML = `<strong>${titulo}:</strong> Rolou <code>${strDadoRolado} ${bonus >= 0 ? '+' + bonus : bonus}</code> = <strong style="font-size:16px;color:${ehCrit ? '#4ADE80' : (ehFumble ? '#F87171' : '#FDE047')};">${total}</strong> ${ehCrit ? 'AMEAÇA DE CRÍTICO!' : (ehFumble ? 'FALHA NATURAL (1)!' : '')}${msgDano}`;
    }
}

function recalcularFichaComArsenalAtualizadoJS(msgNotif) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    const resArs = calcularResumoArsenalSuperiorEMagicoJS(st);
    // Recalcula estatísticas base e aplica bônus do Arsenal Superior/Mágico
    const estBase = calcularEstatisticasCompletasJS(
        st.nivel, st.raca, st.classe, st.origem, st.deus, st.atrBase, st.bonusRaciais,
        st.poderes, st.itens, st.armadura, st.escudo, st.pericias, st.magias, st.caminhoArcanista,
        st.racaAnteriorOsteon
    );
    for (const [sig, valB] of Object.entries(resArs.bonusAtributos || {})) {
        if (valB > 0) {
            estBase.finais[sig] = (estBase.finais[sig] || 0) + valB;
        }
    }
    estBase.defesa += (resArs.bonusDefesaTotal || 0);
    estBase.cdMagia += (resArs.bonusCdMagia || 0);
    estBase.pmMax += (resArs.pmExtraAcessorios || 0);
    if (resArs.bonusResistencias > 0) {
        for (const pRes of ['Fortitude', 'Reflexos', 'Vontade']) {
            estBase.bonusPericias[pRes] = (estBase.bonusPericias[pRes] || 0) + resArs.bonusResistencias;
        }
    }
    st.est = estBase;
    st.pvAtualFicha = estBase.pvMax;
    st.pmAtualFicha = estBase.pmMax;
    renderizarFichaEArvoreClientSide(st, 'tab-ficha', msgNotif || `Arsenal Superior & Mágico atualizado (Gasto: T$ ${resArs.gastoTotal.toLocaleString('pt-BR')} / Orçamento Nv. ${st.nivel}: T$ ${resArs.orcamentoNivel.toLocaleString('pt-BR')})!`);
}

function alternarMelhoriaArmaFichaJS(idMelh, marcado) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    if (!st.configArsenalT20) st.configArsenalT20 = autoOtimizarArsenalSuperiorEMagicoPorNivelJS(st);
    const arr = new Set(st.configArsenalT20.melhoriasArma || []);
    if (marcado) {
        if (arr.size >= 4) {
            exibirMensagemStatus('Regra Oficial (Tabela 3-6, p. 164): Um item superior pode ter no máximo 4 melhorias!');
            renderizarFichaEArvoreClientSide(st, 'tab-ficha');
            return;
        }
        arr.add(idMelh);
    } else {
        arr.delete(idMelh);
    }
    st.configArsenalT20.melhoriasArma = Array.from(arr);
    recalcularFichaComArsenalAtualizadoJS();
}

function alternarEncantoArmaFichaJS(idEnc, marcado) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    if (!st.configArsenalT20) st.configArsenalT20 = autoOtimizarArsenalSuperiorEMagicoPorNivelJS(st);
    const arr = new Set(st.configArsenalT20.encantosArma || []);
    if (marcado) {
        if (arr.size >= 3) {
            exibirMensagemStatus('Regra Oficial (Tabela 8-4, p. 334): Uma arma mágica pode ter no máximo 3 encantos (Maior)!');
            renderizarFichaEArvoreClientSide(st, 'tab-ficha');
            return;
        }
        arr.add(idEnc);
    } else {
        arr.delete(idEnc);
    }
    st.configArsenalT20.encantosArma = Array.from(arr);
    recalcularFichaComArsenalAtualizadoJS();
}

function alternarAcessorioMagicoFichaJS(idAc, marcado) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    if (!st.configArsenalT20) st.configArsenalT20 = autoOtimizarArsenalSuperiorEMagicoPorNivelJS(st);
    const arr = new Set(st.configArsenalT20.acessoriosMagicos || []);
    if (marcado) {
        if (arr.size >= 4) {
            exibirMensagemStatus('Regra Oficial (Limite de Vestimenta, p. 141/342): Você pode vestir no máximo 4 itens/acessórios simultaneamente!');
            renderizarFichaEArvoreClientSide(st, 'tab-ficha');
            return;
        }
        arr.add(idAc);
    } else {
        arr.delete(idAc);
    }
    st.configArsenalT20.acessoriosMagicos = Array.from(arr);
    recalcularFichaComArsenalAtualizadoJS();
}

function alterarSelectArsenalFichaJS(campo, valor) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    if (!st.configArsenalT20) st.configArsenalT20 = autoOtimizarArsenalSuperiorEMagicoPorNivelJS(st);
    st.configArsenalT20[campo] = valor;
    recalcularFichaComArsenalAtualizadoJS();
}

function autoOtimizarArsenalBotaoFichaJS() {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    st.configArsenalT20 = autoOtimizarArsenalSuperiorEMagicoPorNivelJS(st);
    st.configArsenalT20._nivelCalculado = st.nivel;
    recalcularFichaComArsenalAtualizadoJS(`Arsenal otimizado automaticamente para o Nível ${st.nivel} dentro do orçamento de T$ ${obterOrcamentoInicialPorNivelJS(st.nivel).toLocaleString('pt-BR')} (Tabela 3-1, p. 140)!`);
}

function filtrarCatalogoCompletoItensFichaJS() {
    const selCat = document.getElementById('filtro-cat-catalogo-itens-ficha');
    const inpBusca = document.getElementById('busca-catalogo-itens-ficha');
    const cat = selCat ? selCat.value : 'TODOS';
    const q = inpBusca ? inpBusca.value.trim().toLowerCase() : '';
    const rows = document.querySelectorAll('.row-cat-item-ficha');
    rows.forEach(tr => {
        const cRow = tr.getAttribute('data-cat') || '';
        const bRow = tr.getAttribute('data-busca') || '';
        const okCat = (cat === 'TODOS') || (cRow === cat);
        const okBusca = !q || bRow.includes(q);
        tr.style.display = (okCat && okBusca) ? '' : 'none';
    });
}

function adicionarOuEquiparItemCatalogoFichaJS(idItem) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    const itObj = (CATALOGO_T20.itens || []).find(i => i.id_item === idItem);
    if (!itObj) return;
    if (!st.itens) st.itens = [];
    st.itens.push(itObj);
    const catLow = (itObj.categoria || '').toLowerCase();
    let msgAcao = `Item "${itObj.nome}" (${itObj.preco}, ${itObj.espacos} esp.) adicionado ao inventário da ficha!`;
    if (catLow.includes('arma') && itObj.dano_ou_defesa && itObj.dano_ou_defesa !== '-') {
        st.arma = itObj;
        msgAcao = `Arma "${itObj.nome}" (${itObj.dano_ou_defesa}, Crít ${itObj.critico_ou_penalidade}) equipada como arma principal e adicionada à ficha!`;
    } else if (catLow.includes('armadura')) {
        st.armadura = itObj;
        msgAcao = `Armadura "${itObj.nome}" (Def ${itObj.dano_ou_defesa}, Pen ${itObj.critico_ou_penalidade}) equipada na ficha!`;
    } else if (catLow.includes('escudo')) {
        st.escudo = itObj;
        msgAcao = `Escudo "${itObj.nome}" (Def ${itObj.dano_ou_defesa}, Pen ${itObj.critico_ou_penalidade}) equipado na ficha!`;
    }
    recalcularFichaComArsenalAtualizadoJS(msgAcao);
}

function removerItemInventarioFichaJS(idxItem) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st || !st.itens || idxItem < 0 || idxItem >= st.itens.length) return;
    const rem = st.itens.splice(idxItem, 1)[0];
    if (rem && st.arma && st.arma.id_item === rem.id_item) {
        st.arma = st.itens.find(x => (x.categoria || '').toLowerCase().includes('arma')) || null;
    }
    recalcularFichaComArsenalAtualizadoJS(`Item "${rem ? rem.nome : ''}" removido do inventário.`);
}

function limparArsenalSuperiorMagicoFichaJS() {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    st.configArsenalT20 = {
        _nivelCalculado: st.nivel,
        orcamentoNivel: obterOrcamentoInicialPorNivelJS(st.nivel),
        melhoriasArma: [],
        materialArma: 'NENHUM',
        encantosArma: [],
        upgradeArmadura: 'ARM_NORMAL',
        upgradeEsoterico: 'ESO_NENHUM',
        acessoriosMagicos: []
    };
    recalcularFichaComArsenalAtualizadoJS('Melhorias superiores e encantos mágicos zerados (Equipamento Mundano Base).');
}



function aplicarMulticlasseRapidaFichaJS(msgCustom) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    const selC1 = document.getElementById('ficha-mc-classe1');
    const selC2 = document.getElementById('ficha-mc-classe2');
    const inpN2 = document.getElementById('ficha-mc-nivel2');
    const selC3 = document.getElementById('ficha-mc-classe3');
    const inpN3 = document.getElementById('ficha-mc-nivel3');
    const inpNvTotal = document.getElementById('ficha-mc-nivel-total');

    if (inpNvTotal) {
        st.nivel = Math.max(1, Math.min(20, parseIntSeguro(inpNvTotal.value, st.nivel || 6)));
    }
    if (selC1 && selC1.value) {
        const c1Obj = CATALOGO_T20.classes.find(c => c.nome === selC1.value);
        if (c1Obj) st.classe = c1Obj;
    }
    const nomeC2 = selC2 ? selC2.value : 'NENHUMA';
    if (nomeC2 && nomeC2 !== 'NENHUMA' && nomeC2 !== st.classe.nome && st.nivel >= 2) {
        st.classeSecundaria = CATALOGO_T20.classes.find(c => c.nome === nomeC2) || null;
        st.nivelClasseSecundaria = Math.max(1, Math.min(st.nivel - 1, parseIntSeguro(inpN2 ? inpN2.value : 1, 1)));
    } else {
        st.classeSecundaria = null;
        st.nivelClasseSecundaria = 0;
    }
    const nomeC3 = selC3 ? selC3.value : 'NENHUMA';
    if (nomeC3 && nomeC3 !== 'NENHUMA' && nomeC3 !== st.classe.nome && (!st.classeSecundaria || nomeC3 !== st.classeSecundaria.nome) && st.nivel >= 3) {
        st.classeTerciaria = CATALOGO_T20.classes.find(c => c.nome === nomeC3) || null;
        st.nivelClasseTerciaria = Math.max(1, Math.min(st.nivel - st.nivelClasseSecundaria - 1, parseIntSeguro(inpN3 ? inpN3.value : 1, 1)));
    } else {
        st.classeTerciaria = null;
        st.nivelClasseTerciaria = 0;
    }

    const paresAt = normalizarClassesMulticlasseJS(st);
    const cMaxNovo = circuloMaximoPermitido(st.classe, st.nivel, paresAt);
    if (cMaxNovo > 0 && (!st.magias || st.magias.length === 0)) {
        const parConj = paresAt.find(pc => circuloPorClasseENivelJS(pc.classeObj, pc.nivel) > 0);
        const tipoM = (parConj && ['clérigo', 'clerigo', 'druida'].includes(parConj.classeObj.nome.toLowerCase())) ? 'Divina' : 'Arcana';
        const magDisp = CATALOGO_T20.magias.filter(m => m.circulo <= cMaxNovo && (m.tipo === tipoM || m.tipo === 'Universal'));
        st.magias = magDisp.slice(0, Math.min(magDisp.length, 3));
    }

    st.est = calcularEstatisticaCompletaT20({
        nivel: st.nivel,
        raca: st.raca,
        classe: st.classe,
        classeSecundaria: st.classeSecundaria,
        nivelClasseSecundaria: st.nivelClasseSecundaria,
        classeTerciaria: st.classeTerciaria,
        nivelClasseTerciaria: st.nivelClasseTerciaria,
        origem: st.origem,
        deus: st.deus,
        caminhoArcanista: st.caminhoArcanista,
        racaAnteriorOsteon: st.est ? st.est.racaAnteriorOsteon : '',
        arquetipo: st.arquetipo,
        atrBase: st.atrBase,
        livres: st.livres,
        pericias: st.pericias,
        poderes: st.poderes,
        itens: st.itens,
        arma: st.arma,
        armadura: st.armadura,
        escudo: st.escudo
    });
    st.pvAtualFicha = st.est.pvMax;
    st.pmAtualFicha = st.est.pmMax;
    st.scoreFinal = avaliarScoreMCTSClient(st.est, st.poderes, st.magias, st.arma, st.validacoes || [], st.arquetipo, st.nivel, st.classe, st.itens, st.escudo);
    const resumoStr = resumoClassesMulticlasseJS(st);
    renderizarFichaEArvoreClientSide(st, 'tab-ficha', msgCustom || `Multiclasse atualizada: ${resumoStr} (PV=${st.est.pvMax}, PM=${st.est.pmMax}, Def=${st.est.defesa})!`);
}

function selecionarPresetMulticlasseFichaJS(nomeC1, nomeC2, nvC2Padrao, nomeC3, nvC3Padrao) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    if (st.nivel < 2 && nomeC2 && nomeC2 !== 'NENHUMA') st.nivel = 6;
    const selC1 = document.getElementById('ficha-mc-classe1');
    const selC2 = document.getElementById('ficha-mc-classe2');
    const inpN2 = document.getElementById('ficha-mc-nivel2');
    const selC3 = document.getElementById('ficha-mc-classe3');
    const inpN3 = document.getElementById('ficha-mc-nivel3');
    const inpNvTotal = document.getElementById('ficha-mc-nivel-total');
    if (inpNvTotal) inpNvTotal.value = String(st.nivel);
    if (selC1 && nomeC1) selC1.value = nomeC1;
    if (selC2) selC2.value = nomeC2 || 'NENHUMA';
    if (inpN2) inpN2.value = String(nomeC2 && nomeC2 !== 'NENHUMA' ? Math.min(st.nivel - 1, nvC2Padrao || 2) : 0);
    if (selC3) selC3.value = nomeC3 || 'NENHUMA';
    if (inpN3) inpN3.value = String(nomeC3 && nomeC3 !== 'NENHUMA' ? Math.min(st.nivel - 2, nvC3Padrao || 1) : 0);
    aplicarMulticlasseRapidaFichaJS(`Preset de Multiclasse aplicado: ${nomeC1}${nomeC2 && nomeC2 !== 'NENHUMA' ? ' + ' + nomeC2 : ' (Classe Única)'}!`);
}


function otimizarMulticlassePelaIAFichaJS(modoForcado) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    const selModo = document.getElementById('ficha-mc-modo-ia');
    const modo = modoForcado || (selModo ? selModo.value : 'FORCAR_MULTICLASSE_OTIMA');
    if (selModo && modoForcado) selModo.value = modoForcado;
    st.modoMulticlasse = modo;

    const cands = gerarCandidatosMulticlassePorPoliticaJS(
        st.classe, st.nivel, st.arquetipo, modo,
        st.classeSecundaria ? st.classeSecundaria.nome : 'NENHUMA', st.nivelClasseSecundaria || 0,
        st.classeTerciaria ? st.classeTerciaria.nome : 'NENHUMA', st.nivelClasseTerciaria || 0
    );
    const ranking = avaliarRankingMulticlasseMCTSJS({
        nivel: st.nivel, raca: st.raca, classe: st.classe, origem: st.origem, deus: st.deus,
        caminhoArcanista: st.caminhoArcanista, arquetipo: st.arquetipo, atrBase: st.atrBase,
        livres: st.livres, pericias: st.pericias, poderes: st.poderes, itens: st.itens,
        arma: st.arma, armadura: st.armadura, escudo: st.escudo, magias: st.magias
    }, cands);
    st.rankingMulticlasseMCTS = ranking;
    if (ranking.length > 0) {
        const venc = ranking[0];
        st.classe = venc.classe;
        st.classeSecundaria = venc.classeSecundaria;
        st.nivelClasseSecundaria = venc.nivelClasseSecundaria;
        st.classeTerciaria = venc.classeTerciaria;
        st.nivelClasseTerciaria = venc.nivelClasseTerciaria;
        const selC1 = document.getElementById('ficha-mc-classe1');
        const selC2 = document.getElementById('ficha-mc-classe2');
        const inpN2 = document.getElementById('ficha-mc-nivel2');
        const selC3 = document.getElementById('ficha-mc-classe3');
        const inpN3 = document.getElementById('ficha-mc-nivel3');
        if (selC1) selC1.value = st.classe.nome;
        if (selC2) selC2.value = st.classeSecundaria ? st.classeSecundaria.nome : 'NENHUMA';
        if (inpN2) inpN2.value = String(st.nivelClasseSecundaria || 0);
        if (selC3) selC3.value = st.classeTerciaria ? st.classeTerciaria.nome : 'NENHUMA';
        if (inpN3) inpN3.value = String(st.nivelClasseTerciaria || 0);
        aplicarMulticlasseRapidaFichaJS(`IA selecionou [${venc.rotuloPolitica}]: ${venc.resumoDist} (Score MCTS: ${venc.scoreTotalMC} pts) — ${venc.justificativaSinergia}`);
    }
}

// ==============================================================================
// SIMULADOR & ORIENTADOR ESTRATÉGICO DE COMBATES (GUIA TÁTICO CONTRA AS 83 AMEAÇAS DO CAP. 7)
// ==============================================================================
function simularDueloContraCriaturaCap7JS(estado, est, resDano, criaturaCap7, modoEscala) {
    const nivelH = Math.max(1, estado.nivel || 6);
    const ndNum = Math.max(0.25, parseFloat(criaturaCap7.nd_numerico || 1));
    const papel = (criaturaCap7.papel || 'Solo');
    const usarIntegral = (modoEscala === 'FICHA_INTEGRAL_LIVRO');

    // No modo DUELO_1V1, ajusta apenas PV e Dano da ameaça para a cota individual de 1 aventureiro (1/4 do grupo),
    // mantendo Lacaios de ND baixo (<= 1) com 100% dos PV para fidelidade absoluta!
    const fatorPV = usarIntegral ? 1.0 : (papel.toLowerCase() === 'lacaio' && ndNum <= Math.max(1, nivelH * 0.5) ? 1.0 : 0.35);
    const fatorDano = usarIntegral ? 1.0 : (papel.toLowerCase() === 'lacaio' && ndNum <= Math.max(1, nivelH * 0.5) ? 0.85 : 0.50);

    const pvCriaturaMax = Math.max(5, Math.round((criaturaCap7.pv || 20) * fatorPV));
    const danoCriaturaBase = Math.max(2, Math.round((criaturaCap7.dano_medio || 8) * fatorDano));
    const defCriatura = criaturaCap7.defesa || 14;
    const atqCriatura = criaturaCap7.bonus_ataque !== undefined ? criaturaCap7.bonus_ataque : 5;
    const fortC = criaturaCap7.fortitude !== undefined ? criaturaCap7.fortitude : 3;
    const refC = criaturaCap7.reflexos !== undefined ? criaturaCap7.reflexos : 3;
    const vonC = criaturaCap7.vontade !== undefined ? criaturaCap7.vontade : 3;

    // Identifica a menor e a maior resistência da criatura para orientar o jogador!
    const listaRes = [
        { nome: 'Fortitude', sigla: 'Fort', val: fortC },
        { nome: 'Reflexos', sigla: 'Ref', val: refC },
        { nome: 'Vontade', sigla: 'Von', val: vonC }
    ].sort((a, b) => a.val - b.val);
    const menorRes = listaRes[0];
    const maiorRes = listaRes[2];

    const paresCl = normalizarClassesMulticlasseJS(estado);
    const ehConj = paresCl.some(p => ehConjuradorJS(p.classeObj, estado.poderes));
    const melhorMag = resDano.melhorMagiaInfo;
    const danoMagMax = resDano.maiorDanoMagia || 0;
    const custoMag = melhorMag ? (melhorMag.info.pmGasto || 3) : 3;
    const danoArmaBase = Math.max(resDano.danoMedioArma || 0, 5.5 + Math.max(0, est.finais.FOR));
    const dprPotencialArma = Math.max(danoArmaBase, window.__ULTIMO_DPR_POTENCIAL_RODADA__ || danoArmaBase);

    let melhorPerAtq = Math.max(est.bonusPericias['Luta'] || 0, est.bonusPericias['Pontaria'] || 0);
    const mAtqJS = (resDano.descDanoArma || '').match(/Ataque\s*([+-]?\d+)/);
    if (mAtqJS) melhorPerAtq = parseInt(mAtqJS[1], 10);

    const nvGuerreiro = nivelNaClasseJS(estado, 'Guerreiro');
    const nvBarbaro = nivelNaClasseJS(estado, 'Bárbaro');
    const nvPaladino = nivelNaClasseJS(estado, 'Paladino');
    const nvCacador = nivelNaClasseJS(estado, 'Caçador');
    const nvLadino = nivelNaClasseJS(estado, 'Ladino');
    const nvCavaleiro = nivelNaClasseJS(estado, 'Cavaleiro');

    const bonusAE = nvGuerreiro >= 1 ? (4 * (1 + Math.floor((nvGuerreiro - 1) / 4))) : 0;
    const custoAE = nvGuerreiro >= 1 ? (1 + Math.floor((nvGuerreiro - 1) / 4)) : 0;
    const bonusGDAtq = nvPaladino >= 1 ? Math.max(0, est.finais.CAR) : 0;
    const tem2d20Preciso = (estado.poderes || []).some(p => (p.nome || '').toLowerCase() === 'golpe pessoal') || (estado.magias || []).some(m => (m.nome || '').toLowerCase().includes('concentração de combate'));

    // Escolha inteligente do modo de Ataque Especial pelo Orientador:
    // Se precisa de 11+ no d20 sem Ataque Especial, recomenda Foco em Ataque (+bonusAE no Atq);
    // Se já acerta com 6 ou menos no d20, recomenda Foco em Dano (+bonusAE no Dano); caso contrário, Dividido!
    const d20SemAE = defCriatura - (melhorPerAtq + bonusGDAtq);
    let modoAERecomendado = 'DIVIDIDO';
    let bAtqAERec = Math.floor(bonusAE / 2);
    let bDanoAERec = Math.floor(bonusAE / 2);
    if (d20SemAE >= 11) {
        modoAERecomendado = 'ATAQUE';
        bAtqAERec = bonusAE;
        bDanoAERec = 0;
    } else if (d20SemAE <= 6) {
        modoAERecomendado = 'DANO';
        bAtqAERec = 0;
        bDanoAERec = bonusAE;
    }

    const atqEfetivoHeroi = melhorPerAtq + bAtqAERec + bonusGDAtq;
    const d20MinParaAcertar = defCriatura - atqEfetivoHeroi;
    const facesQueAcertam = Math.max(1, Math.min(19, 21 - d20MinParaAcertar));
    const pSimples = facesQueAcertam / 20.0;
    const probAcertoHeroiPct = +(tem2d20Preciso ? ((1 - Math.pow(1 - pSimples, 2)) * 100) : (pSimples * 100)).toFixed(1);

    const d20MinInimigoAcertar = est.defesa - atqCriatura;
    const facesInimigoAcerta = Math.max(1, Math.min(19, 21 - d20MinInimigoAcertar));
    const probAcertoInimigoPct = +((facesInimigoAcerta / 20.0) * 100).toFixed(1);

    let rdHeroi = 0;
    const magNomes = (estado.magias || []).map(m => (m.nome || '').toLowerCase());
    const podNomes = (estado.poderes || []).map(p => (p.nome || '').toLowerCase());
    if (podNomes.includes('encouraçado')) rdHeroi += 2;
    if (estado.raca && estado.raca.nome.toLowerCase() === 'osteon') rdHeroi += 5;
    if (nvBarbaro >= 5) rdHeroi += 2 * Math.floor((nvBarbaro - 2) / 3);
    if (magNomes.some(n => n.includes('campo de força')) && circuloMaximoPermitido(estado.classe, nivelH, paresCl) >= 2) rdHeroi += 15;
    else if (nvGuerreiro >= 3) rdHeroi += Math.round(danoCriaturaBase * 0.25);

    const bonusIniHeroi = est.bonusPericias['Iniciativa'] !== undefined ? est.bonusPericias['Iniciativa'] : (Math.floor(nivelH / 2) + est.finais.DES);
    const bonusIniCriatura = criaturaCap7.iniciativa !== undefined ? criaturaCap7.iniciativa : Math.floor(ndNum / 2);

    const episodios = 40;
    let vitorias = 0, somaQ = 0, somaTurnos = 0, somaDanoCausado = 0, somaDanoSofrido = 0;
    let seed = 2026 + Math.round(ndNum * 100) + nivelH * 19 + est.pvMax * 7 + (criaturaCap7.defesa || 15) * 13;
    function rand() { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; }
    function d20() { return Math.floor(rand() * 20) + 1; }

    for (let ep = 0; ep < episodios; ep++) {
        let pvH = est.pvMax, pmH = est.pmMax, pvC = pvCriaturaMax;
        let turnos = 0, danoEp = 0, sofridoEp = 0;
        const iniH = d20() + bonusIniHeroi;
        const iniC = d20() + bonusIniCriatura;
        const heroiPrimeiro = iniH >= iniC;

        while (pvH > 0 && pvC > 0 && turnos < 20) {
            turnos++;
            if (!heroiPrimeiro) {
                const rIni = d20();
                const defHAtual = (turnos === 1 && !podNomes.includes('esquiva')) ? Math.max(10, est.defesa - 2) : est.defesa;
                if (rIni === 20 || (rIni !== 1 && (rIni + atqCriatura) >= defHAtual)) {
                    const dBruto = Math.round(danoCriaturaBase * (0.90 + 0.20 * rand()) * (rIni === 20 ? 1.5 : 1.0));
                    const dFinal = Math.max(1, dBruto - rdHeroi);
                    pvH = Math.max(0, pvH - dFinal);
                    sofridoEp += dFinal;
                }
                if (pvH <= 0) break;
            }

            let dC = 0;
            if (ehConj && melhorMag && pmH >= custoMag && danoMagMax > dprPotencialArma * 0.85) {
                pmH -= custoMag;
                const dRes = d20();
                const passou = (dRes === 20) || (dRes !== 1 && (dRes + menorRes.val) >= est.cdMagia);
                dC = danoMagMax * (0.92 + 0.16 * rand()) * (passou ? 0.5 : 1.0);
            } else {
                const gastaAE = (nvGuerreiro >= 1 && pmH >= custoAE) ? custoAE : 0;
                pmH -= gastaAE;
                const bAtqTurno = gastaAE > 0 ? bAtqAERec : 0;
                const bDanoTurno = gastaAE > 0 ? bDanoAERec : 0;
                const r1 = d20();
                const r2 = tem2d20Preciso ? d20() : r1;
                const rAtq = Math.max(r1, r2);
                const defCAtual = (turnos === 1 && heroiPrimeiro) ? Math.max(10, defCriatura - 5) : defCriatura;
                const acertou = (rAtq === 20) || (rAtq !== 1 && (rAtq + melhorPerAtq + bAtqTurno + bonusGDAtq) >= defCAtual);
                if (acertou) {
                    dC = (dprPotencialArma + bDanoTurno) * 0.85 * (rAtq >= 19 ? 1.35 : 1.0) * (0.92 + 0.16 * rand());
                }
            }
            pvC = Math.max(0, pvC - dC);
            danoEp += dC;

            if (heroiPrimeiro && pvC > 0) {
                const rIni = d20();
                if (rIni === 20 || (rIni !== 1 && (rIni + atqCriatura) >= est.defesa)) {
                    const dBruto = Math.round(danoCriaturaBase * (0.90 + 0.20 * rand()) * (rIni === 20 ? 1.5 : 1.0));
                    const dFinal = Math.max(1, dBruto - rdHeroi);
                    pvH = Math.max(0, pvH - dFinal);
                    sofridoEp += dFinal;
                }
            }
        }
        const venceu = pvC <= 0 && pvH > 0;
        if (venceu) vitorias++;
        const qEp = (venceu ? 100 : -100) + ((danoEp / Math.max(1, pvCriaturaMax)) * 50) - ((sofridoEp / Math.max(1, est.pvMax)) * 40) - turnos * 2.5;
        somaQ += qEp;
        somaTurnos += turnos;
        somaDanoCausado += (danoEp / Math.max(1, turnos));
        somaDanoSofrido += (sofridoEp / Math.max(1, turnos));
    }

    const winPct = +((vitorias / episodios) * 100).toFixed(1);
    const qFinal = +(somaQ / episodios).toFixed(1);
    const dprHeroiReal = Math.max(0.5, +(somaDanoCausado / episodios).toFixed(1));
    const dprInimigoReal = Math.max(0.5, +(somaDanoSofrido / episodios).toFixed(1));
    const ttkHeroi = +(pvCriaturaMax / dprHeroiReal).toFixed(1);
    const ttkInimigo = +(est.pvMax / dprInimigoReal).toFixed(1);

    let faixaDificuldade = 'Vitória Garantida (Treino Seguro)';
    let corFaixa = '#4ADE80';
    if (winPct >= 85) {
        faixaDificuldade = 'Vitória Garantida (Favorável)';
        corFaixa = '#4ADE80';
    } else if (winPct >= 65) {
        faixaDificuldade = 'Combate Ideal (Vencível c/ Estratégia)';
        corFaixa = '#38BDF8';
    } else if (winPct >= 45) {
        faixaDificuldade = 'Desafio Tático Equilibrado (Exige Cuidado)';
        corFaixa = '#FACC15';
    } else if (winPct >= 20) {
        faixaDificuldade = 'Alto Risco (Requer Aliados ou Buffs)';
        corFaixa = '#FB923C';
    } else {
        faixaDificuldade = 'Perigo Mortal em 1v1 (Enfrente em Grupo de 4)';
        corFaixa = '#F87171';
    }

    return {
        criatura: criaturaCap7,
        pvCriaturaMax,
        danoCriaturaAplicado: danoCriaturaBase,
        defCriatura,
        atqCriatura,
        fortC,
        refC,
        vonC,
        menorRes,
        maiorRes,
        modoAERecomendado,
        bAtqAERec,
        bDanoAERec,
        probAcertoHeroiPct,
        probAcertoInimigoPct,
        ttkHeroi,
        ttkInimigo,
        dprHeroiReal,
        dprInimigoReal,
        winPct,
        qFinal,
        faixaDificuldade,
        corFaixa
    };
}

function gerarGuiaEstrategicoCombateFichaJS(estado, est, resDano, resultadoSim) {
    const c = resultadoSim.criatura;
    const paresCl = normalizarClassesMulticlasseJS(estado);
    const nvGuerreiro = nivelNaClasseJS(estado, 'Guerreiro');
    const nvBarbaro = nivelNaClasseJS(estado, 'Bárbaro');
    const nvPaladino = nivelNaClasseJS(estado, 'Paladino');
    const nvCacador = nivelNaClasseJS(estado, 'Caçador');
    const nvLadino = nivelNaClasseJS(estado, 'Ladino');
    const nvCavaleiro = nivelNaClasseJS(estado, 'Cavaleiro');
    const nvBardo = nivelNaClasseJS(estado, 'Bardo');
    const podNomes = (estado.poderes || []).map(p => (p.nome || '').toLowerCase());
    const magNomes = (estado.magias || []).map(m => (m.nome || '').toLowerCase());
    const habResTxt = (c.habilidades_e_resistencias || 'Nenhuma habilidade especial listada.');

    // 1. Análise de Fraquezas e Alertas da Ameaça
    const alertas = [];
    if (/imunidade/i.test(habResTxt)) alertas.push(`<strong>Imunidades da Ameaça:</strong> verifique em <em>"${habResTxt}"</em> para não usar dano elemental imune.`);
    if (/redução de dano|rd\s*\d+/i.test(habResTxt)) alertas.push(`<strong>Redução de Dano (RD):</strong> a criatura possui RD natural; priorize golpes pesados de alto dano único, <em>Ataque Poderoso</em>, <em>Golpe Pessoal Penetrante</em> ou aço-rubi.`);
    if (/veneno|doença/i.test(habResTxt + ' ' + (c.ataques_e_acoes || ''))) alertas.push(`<strong>Perigo de Veneno/Doença:</strong> os ataques causam condição secundária em Fortitude (CD ${c.cd_efeito || 15}).`);
    if (/voo|voar/i.test(c.deslocamento || '')) alertas.push(`<strong>Criatura Voadora (${c.deslocamento}):</strong> mantenha arma de alcance/disparo, magias ou use manobra <em>Derrubar</em> para forçá-la ao chão.`);
    const pontoFracoHTML = `A defesa mais vulnerável de <strong>${c.nome}</strong> é <strong>${resultadoSim.menorRes.nome} (${resultadoSim.menorRes.val >= 0 ? '+' + resultadoSim.menorRes.val : resultadoSim.menorRes.val})</strong>, enquanto sua resistência mais forte é <strong>${resultadoSim.maiorRes.nome} (${resultadoSim.maiorRes.val >= 0 ? '+' + resultadoSim.maiorRes.val : resultadoSim.maiorRes.val})</strong>. Defesa física: <strong>${resultadoSim.defCriatura}</strong> (sua chance de acerto recomendada é de <strong>${resultadoSim.probAcertoHeroiPct}%</strong>).`;

    // 2. Plano de Abertura (Turno 1)
    const passosTurno1 = [];
    if (magNomes.some(m => m.includes('concentração de combate'))) {
        passosTurno1.push(`Lance <strong>Concentração de Combate (Ação Livre, 1 PM)</strong> para rolar <code>2d20</code> e escolher o melhor resultado no ataque.`);
    }
    if (nvBarbaro >= 1) {
        const bFur = 2 + Math.floor((nvBarbaro - 1) / 5);
        passosTurno1.push(`Ative <strong>Fúria (Ação Livre, 2 PM)</strong> logo no início para ganhar <strong>+${bFur} no Ataque e +${bFur} no Dano</strong> pela cena inteira.`);
    }
    if (nvCacador >= 1) {
        const dMP = nvCacador < 5 ? '1d4' : (nvCacador < 13 ? '1d6' : '1d8');
        passosTurno1.push(`Use sua Ação de Movimento para aplicar <strong>Marca da Presa (1 PM)</strong> em ${c.nome}, somando <strong>+${dMP} de dano</strong> em todos os seus ataques.`);
    }
    if (nvBardo >= 1) {
        passosTurno1.push(`Ative <strong>Inspiração (2 PM)</strong> no 1º turno para conceder bônus em todos os testes de perícia (incluindo Luta, Pontaria e Misticismo) durante a cena.`);
    }
    if (passosTurno1.length === 0) {
        const ehDist = estado.arma && /distância|arco|besta|mosquete|pistola/i.test((estado.arma.subcategoria || '') + ' ' + (estado.arma.nome || ''));
        if (ehDist) {
            passosTurno1.push(`Use sua Ação de Movimento para <strong>Mirar (p. 235)</strong> (anulando penalidades${podNomes.includes('mira apurada') ? ' e ganhando +2 Atq/+2 Margem por Mira Apurada' : ''}) antes de disparar.`);
        } else {
            passosTurno1.push(`Se vencer a Iniciativa (seu bônus: <strong>+${est.bonusPericias['Iniciativa'] || 0}</strong> vs <strong>+${c.iniciativa || 0}</strong> da criatura), engaje imediatamente no Turno 1 enquanto ${c.nome} está <strong>Desprevenido (-5 na Defesa: cai de ${resultadoSim.defCriatura} para ${Math.max(10, resultadoSim.defCriatura - 5)})</strong>!`);
        }
    }

    // 3. Rotação Principal de Ataque / Magia (Turnos 2+)
    const passosRotacao = [];
    if (nvGuerreiro >= 1) {
        const cAE = 1 + Math.floor((nvGuerreiro - 1) / 4);
        const vAE = 4 * cAE;
        if (resultadoSim.modoAERecomendado === 'ATAQUE') {
            passosRotacao.push(`Como a Defesa de ${c.nome} é elevada (${resultadoSim.defCriatura}), use <strong>Ataque Especial (${cAE} PM) no modo FOCO EM ATAQUE (+${vAE} no Ataque)</strong> para elevar sua precisão a ${resultadoSim.probAcertoHeroiPct}%.`);
        } else if (resultadoSim.modoAERecomendado === 'DANO') {
            passosRotacao.push(`Como a Defesa de ${c.nome} é baixa (${resultadoSim.defCriatura}) para o seu bônus de ataque, use <strong>Ataque Especial (${cAE} PM) no modo FOCO EM DANO (+${vAE} no Dano)</strong> para abatê-lo rapidamente!`);
        } else {
            passosRotacao.push(`Use <strong>Ataque Especial (${cAE} PM) no modo DIVIDIDO (+${Math.floor(vAE/2)} no Ataque e +${Math.floor(vAE/2)} no Dano)</strong> para equilibrar precisão e letalidade.`);
        }
    }
    if (nvPaladino >= 1) {
        passosRotacao.push(`Combine <strong>Golpe Divino (2 PM)</strong> nos ataques principais para somar <strong>+${Math.max(0, est.finais.CAR)} (CAR) no Ataque e +1d8 no Dano</strong>.`);
    }
    if (podNomes.includes('golpe pessoal')) {
        passosRotacao.push(`Empilhe seu <strong>Golpe Pessoal (Brutal + Elemental + Preciso 2d20)</strong> no golpe principal para maximizar a chance de crítico e o burst por rodada.`);
    }
    if (nvLadino >= 1) {
        const dF = Math.ceil(nvLadino / 2);
        passosRotacao.push(`Posicione-se em <strong>Flanqueamento (+2 Atq)</strong> ou use <strong>Fintar</strong> para deixar ${c.nome} Desprevenido e ativar <strong>+${dF}d6 de Ataque Furtivo</strong>!`);
    }
    if ((estado.magias || []).length > 0) {
        const magiasOfensivas = (estado.magias || []).filter(m => !/armadura arcana|campo de força|escudo da fé|proteção divina|curar ferimentos|queda suave/i.test(m.nome || ''));
        const magContraMenorRes = magiasOfensivas.find(m => (m.resistencia || '').toLowerCase().includes(resultadoSim.menorRes.sigla.toLowerCase()));
        if (magContraMenorRes) {
            passosRotacao.push(`<strong>Magia Ideal contra o Ponto Fraco (${resultadoSim.menorRes.nome} ${resultadoSim.menorRes.val >= 0 ? '+' + resultadoSim.menorRes.val : resultadoSim.menorRes.val}):</strong> lance <strong>${magContraMenorRes.nome}</strong> (CD ${est.cdMagia}) para explorar a menor resistência da criatura!`);
        } else if (resDano.melhorMagiaInfo) {
            passosRotacao.push(`Use <strong>${resDano.melhorMagiaInfo.nome}</strong> aprimorada até seu limite de PM (${resDano.limitePM} PM)${podNomes.includes('magia acelerada') ? ' combinada com <strong>Magia Acelerada (+4 PM, Ação Livre)</strong>' : ''}.`);
        }
    }
    if (passosRotacao.length === 0) {
        passosRotacao.push(`Mantenha ataques consistentes com <strong>${estado.arma ? estado.arma.nome : 'sua arma principal'}</strong> (DPR estimado: <strong>${resultadoSim.dprHeroiReal}/rodada</strong>, derrubando os ${resultadoSim.pvCriaturaMax} PV em cerca de <strong>${resultadoSim.ttkHeroi} turnos</strong>).`);
    }

    // 4. Protocolo Defensivo e Reações
    const passosDefesa = [];
    if (magNomes.some(m => m.includes('armadura arcana'))) {
        passosDefesa.push(`Guarde <strong>2 PM para Armadura Arcana (Reação: +5 na Defesa)</strong> quando ${c.nome} rolar entre ${est.defesa} e ${est.defesa + 4} no teste de ataque.`);
    }
    if (magNomes.some(m => m.includes('campo de força')) && circuloMaximoPermitido(estado.classe, estado.nivel, paresCl) >= 2) {
        passosDefesa.push(`Use <strong>Campo de Força (Reação, 4 PM: RD 30)</strong> para anular quase totalmente o dano médio de <strong>${resultadoSim.danoCriaturaAplicado}/rodada</strong> de ${c.nome}.`);
    }
    if (nvGuerreiro >= 3) {
        passosDefesa.push(`Ative <strong>Durão (Reação, 3 PM: reduz dano à metade)</strong> sempre que sofrer um acerto crítico ou ataque pesado de ${c.nome}.`);
    }
    if (nvCavaleiro >= 1) {
        passosDefesa.push(`Ative <strong>Baluarte (Reação, 1 PM)</strong> para elevar sua Defesa e Resistências contra os ataques de ${c.nome}.`);
    }
    if (passosDefesa.length === 0) {
        passosDefesa.push(`Sua Defesa passiva é <strong>${est.defesa}</strong> contra o bônus de ataque <strong>+${resultadoSim.atqCriatura}</strong> de ${c.nome} (inimigo acerta ${resultadoSim.probAcertoInimigoPct}% das vezes causando ~${resultadoSim.danoCriaturaAplicado} dano). Mantenha <em>Bálsamo Restaurador</em> ou poções à mão se a luta passar de ${Math.max(2, Math.floor(resultadoSim.ttkInimigo - 1))} turnos.`);
    }

    return {
        pontoFracoHTML,
        alertas,
        passosTurno1,
        passosRotacao,
        passosDefesa
    };
}

function atualizarOrientadorCombateFichaJS(idAmeacaForcada) {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    const selFiltro = document.getElementById('ficha-sim-filtro-ameacas');
    const selEscala = document.getElementById('ficha-sim-modo-escala');
    const selCriatura = document.getElementById('ficha-sim-sel-criatura');
    if (selFiltro) window.__FICHA_SIM_FILTRO__ = selFiltro.value;
    if (selEscala) window.__FICHA_SIM_ESCALA__ = selEscala.value;
    if (idAmeacaForcada) {
        window.__FICHA_SIM_CRIATURA_ID__ = idAmeacaForcada;
    } else if (selCriatura) {
        window.__FICHA_SIM_CRIATURA_ID__ = selCriatura.value;
    }
    renderizarFichaEArvoreClientSide(st, null, '');
}


// ======================================================================================
// // 1. DESCRITOR NUMÉRICO DE MAGIAS & APRIMORAMENTOS (COM RESISTÊNCIA DO ND E EFICIÊNCIA DE PM)
// 2. COMPETIÇÃO AUTOMÁTICA DE RAMOS DE ATRIBUTO & ESTILO NA RAIZ PARA TODAS AS CLASSES VERSÁTEIS
// ======================================================================================

function compilarDescritorMagiaEAprimoramentoV73JS(magia, nivel, classeObj, atrFinais, poderes, itens, caminhoArcanista) {
    const det = (typeof detalharAprimoramentoMagiaJS === 'function')
        ? detalharAprimoramentoMagiaJS(magia, nivel, classeObj, atrFinais, poderes, itens, caminhoArcanista)
        : { pmGasto: 1, danoMedio: 0, limitePM: nivel };
    const nl = String((magia && magia.nome) || '').toLowerCase();
    const nv = Math.max(1, Number(nivel || 6));
    // Cálculo 100% intrínseco da magia do personagem (CD própria, Dano próprio, Área e Alvos — ZERO resistência de inimigo!)
    const atribKey = (typeof obterAtributoChaveMagiaJS === 'function') ? obterAtributoChaveMagiaJS(classeObj, caminhoArcanista).sigla : 'INT';
    const cd = 10 + Math.floor(nv / 2) + Math.max(0, (atrFinais && atrFinais[atribKey]) || 0);
    const ehAcertoAuto = nl.includes('seta infalível');
    const fatorCDProp = ehAcertoAuto ? 1.12 : (1.0 + Math.max(0, cd - 10) * 0.035);

    const out = {
        nome: magia.nome,
        circulo: magia.circulo || 1,
        pmBurst: Math.max(1, det.pmGasto || 1),
        limitePM: det.limitePM || nv,
        dprEsperado: 0,
        eficienciaDprPorPM: 0,
        curaEsperada: 0,
        defBonus: 0,
        rdBonus: 0,
        usa2d20: false,
        ataquesExtra: 0,
        buffGrpAtq: 0,
        buffGrpDano: 0,
        buffGrpDef: 0
    };

    if (nl.includes('curar ferimentos') || nl.includes('sopro da salvação')) {
        out.curaEsperada = Number((det.danoMedio || 11).toFixed(1));
    } else if (nl.includes('armadura arcana')) {
        out.defBonus = 5 + Math.floor(Math.max(0, (det.limitePM || nv) - 1) / 2);
    } else if (nl.includes('campo de força')) {
        out.rdBonus = 30;
    } else if (nl.includes('escudo da fé')) {
        out.defBonus = 2 + Math.floor(Math.max(0, (det.limitePM || nv) - 1) / 2);
    } else if (nl.includes('concentração de combate')) {
        out.usa2d20 = true;
    } else if (nl.includes('velocidade')) {
        out.ataquesExtra = 1.0;
    } else if (nl.includes('bênção') || nl.includes('bencao')) {
        const b = 1 + Math.floor(Math.max(0, (det.limitePM || nv) - 1) / 2);
        out.buffGrpAtq = b; out.buffGrpDano = b;
    } else if (nl.includes('oração') || nl.includes('oracao')) {
        const b = 2 + Math.floor(Math.max(0, (det.limitePM || nv) - 3) / 2);
        out.buffGrpAtq = b; out.buffGrpDano = b; out.buffGrpDef = b;
    } else if (det.danoMedio > 0) {
        const ehArea = /bola de fogo|relâmpago|explosão de chamas|jato corrosivo|tempestade|cone|esfera|linha|área|area/i.test(nl + ' ' + String(magia.efeito_e_aprimoramentos || ''));
        const alvosOverride = Number(window.__ALVOS_AREA_MAGIA_OVERRIDE__ || 0);
        const alvosConsiderados = ehArea ? (alvosOverride > 0 ? alvosOverride : 1.5) : 1.0;
        out.cd = cd;
        out.fatorCDProp = Number(fatorCDProp.toFixed(3));
        out.ehArea = ehArea;
        out.alvosConsiderados = alvosConsiderados;
        out.dprAlvoUnico = Number((det.danoMedio * fatorCDProp).toFixed(1));
        out.dprEsperado = Number((det.danoMedio * fatorCDProp * alvosConsiderados).toFixed(1));
        out.eficienciaDprPorPM = Number((out.dprEsperado / out.pmBurst).toFixed(2));
    }
    return out;
}

// Catálogo de Ramos Competitivos de Atributo & Estilo na Raiz para TODAS as classes versáteis!
function obterRamosCompetitivosPorClasseV73JS(classeNome) {
    const cl = String(classeNome || '').toLowerCase();
    if (cl === 'guerreiro') return [
        { id: 'FOR_2M', rotulo: 'FOR · Duas Mãos (Montante)', arq: 'Marcial: Duas Mãos Pesado', arma: 'Montante', atrBase: { FOR: 4, DES: 0, CON: 3, INT: 0, SAB: 0, CAR: -1 }, livres: ['FOR', 'CON', 'DES'] },
        { id: 'DES_DUEL', rotulo: 'DES · Ágil / Acuidade (Florete)', arq: 'Marcial: Uma Mão Duelista', arma: 'Florete', atrBase: { FOR: -1, DES: 4, CON: 3, INT: 0, SAB: 0, CAR: 0 }, livres: ['DES', 'CON', 'INT'] },
        { id: 'DES_ARQ', rotulo: 'DES · Arqueiro / Disparo (Arco longo)', arq: 'Marcial: Dano Arqueiro', arma: 'Arco longo', atrBase: { FOR: -1, DES: 4, CON: 3, INT: 0, SAB: 0, CAR: 0 }, livres: ['DES', 'CON', 'SAB'] },
        { id: 'FOR_ARREM', rotulo: 'FOR · Arremessador Potente (Azagaia)', arq: 'Marcial: Dano Arqueiro', arma: 'Azagaia', atrBase: { FOR: 4, DES: 2, CON: 2, INT: 0, SAB: 0, CAR: -1 }, livres: ['FOR', 'DES', 'CON'] }
    ];
    if (cl === 'caçador' || cl === 'cacador') return [
        { id: 'DES_ARQ', rotulo: 'DES · Arqueiro (Arco longo)', arq: 'Marcial: Dano Arqueiro', arma: 'Arco longo', atrBase: { FOR: -1, DES: 4, CON: 2, INT: 0, SAB: 2, CAR: 0 }, livres: ['DES', 'SAB', 'CON'] },
        { id: 'DES_2A', rotulo: 'DES · Duas Armas Ágeis (Espada curta)', arq: 'Marcial: Duas Armas', arma: 'Espada curta', atrBase: { FOR: -1, DES: 4, CON: 2, INT: 0, SAB: 2, CAR: 0 }, livres: ['DES', 'CON', 'SAB'] },
        { id: 'FOR_CAC', rotulo: 'FOR · Corpo a Corpo (Cimitarra)', arq: 'Marcial: Duas Armas', arma: 'Cimitarra', atrBase: { FOR: 4, DES: 0, CON: 2, INT: 0, SAB: 2, CAR: -1 }, livres: ['FOR', 'DES', 'CON'] },
        { id: 'FOR_ARREM_CAC', rotulo: 'FOR · Caçador Arremessador (Azagaia)', arq: 'Marcial: Dano Arqueiro', arma: 'Azagaia', atrBase: { FOR: 4, DES: 2, CON: 1, INT: 0, SAB: 1, CAR: -1 }, livres: ['FOR', 'DES', 'SAB'] }
    ];
    if (cl === 'paladino') return [
        { id: 'FOR_CAR_ESC', rotulo: 'FOR+CAR · Arma & Escudo (Espada longa)', arq: 'Tanque: Arma e Escudo', arma: 'Espada longa', atrBase: { FOR: 3, DES: -1, CON: 0, INT: 0, SAB: 0, CAR: 4 }, livres: ['CAR', 'FOR', 'CON'] },
        { id: 'FOR_CAR_2M', rotulo: 'FOR+CAR · Vingador Duas Mãos (Montante)', arq: 'Marcial: Duas Mãos Pesado', arma: 'Montante', atrBase: { FOR: 4, DES: -1, CON: 0, INT: 0, SAB: 0, CAR: 3 }, livres: ['FOR', 'CAR', 'CON'] },
        { id: 'DES_CAR_AGIL', rotulo: 'DES+CAR · Duelista Sagrado (Florete)', arq: 'Marcial: Uma Mão Duelista', arma: 'Florete', atrBase: { FOR: -1, DES: 4, CON: 0, INT: 0, SAB: 0, CAR: 3 }, livres: ['DES', 'CAR', 'CON'] }
    ];
    if (cl === 'arcanista') return [
        { id: 'INT_MAGO', rotulo: 'INT · Mago (Grimório + Arcano de Batalha)', arq: 'Conjurador Arcano: Mago', caminho: 'Mago', arma: 'Cajado arcano', atrBase: { FOR: -1, DES: 2, CON: 2, INT: 4, SAB: 0, CAR: 0 }, livres: ['INT', 'CON', 'DES'] },
        { id: 'CAR_FEIT', rotulo: 'CAR · Feiticeiro (Linhagem + PM)', arq: 'Conjurador Arcano: Feiticeiro', caminho: 'Feiticeiro', arma: 'Cajado arcano', atrBase: { FOR: -1, DES: 2, CON: 2, INT: 0, SAB: 0, CAR: 4 }, livres: ['CAR', 'CON', 'DES'] }
    ];
    if (cl === 'inventor') return [
        { id: 'INT_BAL', rotulo: 'INT · Balística / Arma de Fogo (Mosquete)', arq: 'Marcial: Dano Arqueiro', arma: 'Mosquete', atrBase: { FOR: -1, DES: 2, CON: 2, INT: 4, SAB: 0, CAR: 0 }, livres: ['INT', 'DES', 'CON'] },
        { id: 'INT_ARM', rotulo: 'INT · Armeiro Corpo a Corpo (Espada longa)', arq: 'Tanque: Arma e Escudo', arma: 'Espada longa', atrBase: { FOR: 0, DES: -1, CON: 3, INT: 4, SAB: 0, CAR: 0 }, livres: ['INT', 'CON', 'DES'] },
        { id: 'INT_ENG', rotulo: 'INT · Engenhoqueiro / Alquimista', arq: 'Conjurador Arcano: Mago', arma: 'Besta leve', atrBase: { FOR: -1, DES: 2, CON: 2, INT: 4, SAB: 0, CAR: 0 }, livres: ['INT', 'CON', 'SAB'] }
    ];
    if (cl === 'druida') return [
        { id: 'FOR_SAB_FS', rotulo: 'FOR+SAB · Forma Selvagem (Corpo a Corpo)', arq: 'Dano Marcial', arma: 'Cimitarra', atrBase: { FOR: 4, DES: -1, CON: 0, INT: 0, SAB: 3, CAR: 0 }, livres: ['FOR', 'SAB', 'CON'] },
        { id: 'SAB_CONJ', rotulo: 'SAB · Conjurador Elemental', arq: 'Conjurador Arcano', arma: 'Bordão', atrBase: { FOR: -1, DES: 2, CON: 2, INT: 0, SAB: 4, CAR: 0 }, livres: ['SAB', 'CON', 'DES'] },
        { id: 'SAB_SUP', rotulo: 'SAB · Suporte & Cura de Grupo', arq: 'Suporte Divino: Druida', arma: 'Bordão', atrBase: { FOR: -1, DES: 0, CON: 3, INT: 0, SAB: 4, CAR: 0 }, livres: ['SAB', 'CON', 'CAR'] }
    ];
    if (cl === 'bardo') return [
        { id: 'CAR_ESGR', rotulo: 'CAR · Esgrima Mágica (Florete + Prestidigitação)', arq: 'Marcial: Uma Mão Duelista', arma: 'Florete', atrBase: { FOR: -1, DES: 2, CON: 2, INT: 0, SAB: 0, CAR: 4 }, livres: ['CAR', 'DES', 'CON'] },
        { id: 'CAR_SUP', rotulo: 'CAR · Conjurador & Suporte de Grupo', arq: 'Suporte Divino', arma: 'Espada curta', atrBase: { FOR: -1, DES: 2, CON: 2, INT: 0, SAB: 0, CAR: 4 }, livres: ['CAR', 'CON', 'INT'] }
    ];
    if (cl === 'clérigo' || cl === 'clerigo') return [
        { id: 'SAB_SUP', rotulo: 'SAB · Conjurador Divino & Suporte', arq: 'Suporte Divino: Clérigo', arma: 'Maça', atrBase: { FOR: 0, DES: -1, CON: 3, INT: 0, SAB: 4, CAR: 0 }, livres: ['SAB', 'CON', 'CAR'] },
        { id: 'FOR_SAB_G', rotulo: 'FOR+SAB · Clérigo de Guerra', arq: 'Tanque: Arma e Escudo', arma: 'Maça', atrBase: { FOR: 3, DES: -1, CON: 2, INT: 0, SAB: 3, CAR: -1 }, livres: ['FOR', 'SAB', 'CON'] }
    ];
    if (cl === 'ladino') return [
        { id: 'DES_CAC', rotulo: 'DES · Assassino Corpo a Corpo (Espada curta)', arq: 'Marcial: Uma Mão Duelista', arma: 'Espada curta', atrBase: { FOR: -1, DES: 4, CON: 0, INT: 3, SAB: 0, CAR: 0 }, livres: ['DES', 'INT', 'CON'] },
        { id: 'DES_DIST', rotulo: 'DES · Atirador Furtivo (Arco curto)', arq: 'Marcial: Dano Arqueiro', arma: 'Arco curto', atrBase: { FOR: -1, DES: 4, CON: 0, INT: 3, SAB: 0, CAR: 0 }, livres: ['DES', 'INT', 'CON'] }
    ];
    if (cl === 'bucaneiro') return [
        { id: 'DES_CAR_ESG', rotulo: 'DES+CAR · Esgrimista (Florete + Audácia)', arq: 'Marcial: Uma Mão Duelista', arma: 'Florete', atrBase: { FOR: -1, DES: 4, CON: 0, INT: 0, SAB: 0, CAR: 3 }, livres: ['DES', 'CAR', 'CON'] },
        { id: 'DES_CAR_PIS', rotulo: 'DES+CAR · Pistoleiro (Pistola + Audácia)', arq: 'Marcial: Dano Arqueiro', arma: 'Pistola', atrBase: { FOR: -1, DES: 4, CON: 0, INT: 0, SAB: 0, CAR: 3 }, livres: ['DES', 'CAR', 'CON'] }
    ];
    if (cl === 'lutador') return [
        { id: 'FOR_CON_LUT', rotulo: 'FOR+CON · Desarmado Bruto (Briga + Casca Grossa)', arq: 'Dano Marcial', arma: 'Manopla', atrBase: { FOR: 4, DES: 0, CON: 3, INT: 0, SAB: 0, CAR: -1 }, livres: ['FOR', 'CON', 'DES'] },
        { id: 'DES_FOR_LUT', rotulo: 'DES+FOR · Desarmado Ágil (Acuidade + Iniciativa)', arq: 'Marcial: Uma Mão Duelista', arma: 'Manopla', atrBase: { FOR: 0, DES: 4, CON: 3, INT: 0, SAB: 0, CAR: -1 }, livres: ['DES', 'FOR', 'CON'] }
    ];
    return [];
}

// Competição Automática na Raiz: roda a otimização completa em cada ramo e escolhe o maior Score numérico v72!
function competirRamosAtributoEEstiloNaRaizV73JS(formData, fnOtimizarBase) {
    if (formData.get('_v73_subramo') === '1') return fnOtimizarBase(formData);
    const fixArma = formData.get('fixar_arma') || 'AUTO';
    const fixClasse = formData.get('fixar_classe') || 'AUTO';
    if (fixArma !== 'AUTO' || fixClasse === 'AUTO') return fnOtimizarBase(formData);

    const ramos = obterRamosCompetitivosPorClasseV73JS(fixClasse);
    if (!ramos || ramos.length < 2) return fnOtimizarBase(formData);

    const resultados = [];
    for (const r of ramos) {
        const fdSub = new FormData();
        // Copia campos relevantes do formData original
        ['nome', 'nivel', 'arquetipo', 'fixar_classe', 'fixar_raca', 'fixar_deus', 'fixar_origem',
         'fixar_classe_secundaria', 'nivel_classe_secundaria', 'fixar_classe_terciaria', 'nivel_classe_terciaria',
         'modo_multiclasse', 'raca_anterior_osteon', 'iteracoes'].forEach(k => {
            const v = formData.get(k);
            if (v !== null && v !== undefined) fdSub.set(k, v);
        });
        fdSub.set('_v73_subramo', '1');
        fdSub.set('fixar_arma', r.arma);
        if (r.caminho) fdSub.set('caminho_arcanista', r.caminho);
        fdSub.set('_v73_atr_override', JSON.stringify(r.atrBase));
        fdSub.set('_v73_livres_override', JSON.stringify(r.livres));
        const res = fnOtimizarBase(fdSub);
        const met = avaliarBuildNumericaDescritoresV72JS(res.est, res.poderes, res.magias, res.arma, formData.get('arquetipo') || r.arq, res.nivel, res.classe, res.escudo);
        resultados.push({ ramo: r, res, met });
    }
    resultados.sort((a, b) => b.met.score - a.met.score);
    const camp = resultados[0];
    camp.res.comparativoRamosAtributoV73 = resultados.map(x => ({
        id: x.ramo.id,
        rotulo: x.ramo.rotulo,
        arma: x.ramo.arma,
        score: x.met.score,
        dpr: x.met.dpr,
        ehpTurnos: x.met.ehpTurnos,
        suporte: x.met.suporte,
        pAcertoPct: x.met.pAcertoPct,
        pCritPct: x.met.pCritPct,
        vencedor: x.ramo.id === camp.ramo.id
    }));
    // Anexa na Árvore de Decisão os ramos de Atributo/Estilo que competiram na raiz!
    if (Array.isArray(camp.res.passosArvore) && camp.res.passosArvore.length >= 2) {
        const passoAtr = camp.res.passosArvore[1];
        passoAtr.vencedor = `${camp.res.raca.nome} · Ramo Campeão: ${camp.ramo.rotulo}`;
        passoAtr.alts = resultados.slice(1).map(x => ({
            nome: x.ramo.rotulo,
            tipo: 'EXPLORADO_MCTS',
            visitas: 25,
            motivo: `Competição Raiz v73: Score ${x.met.score} (DPR ${x.met.dpr}, EHP ${x.met.ehpTurnos}t, Sup ${x.met.suporte}) vs Campeão ${camp.met.score}`
        }));
    }
    return camp.res;
}

window.compilarDescritorMagiaEAprimoramentoV73JS = compilarDescritorMagiaEAprimoramentoV73JS;

// ======================================================================================
// BUSCA DINÂMICA TOTAL (ZERO CAMINHOS PRÉ-DEFINIDOS / ZERO TABELAS FIXAS)
// ======================================================================================

function pontuarMagiaDinamicaV80JS(magia, nivel, classeObj, atrFinais, arquetipo, poderes, itens, caminhoArcanista) {
    const desc = compilarDescritorMagiaEAprimoramentoV73JS(magia, nivel, classeObj, atrFinais, poderes || [], itens || [], caminhoArcanista || 'Mago');
    const txt = (String(magia.nome || '') + ' ' + String(magia.efeito_e_aprimoramentos || '') + ' ' + String(magia.alvo_ou_area || '')).toLowerCase();
    const arqL = String(arquetipo || '').toLowerCase();
    const nv = Math.max(1, Number(nivel || 6));
    const atribKey = (typeof obterAtributoChaveMagiaJS === 'function') ? obterAtributoChaveMagiaJS(classeObj, caminhoArcanista).sigla : 'INT';
    const cd = 10 + Math.floor(nv / 2) + Math.max(0, (atrFinais && atrFinais[atribKey]) || 0);
    const fatorCD = 1.0 + Math.max(0, cd - 10) * 0.035;
    const ehArea = /esfera|cone|linha|cilindro|área|area|criaturas escolhidas|aliados|inimigos/.test(txt);
    const multAlvos = ehArea ? 1.75 : 1.0;

    // Extração genérica de propriedades mecânicas do texto oficial da magia (sem lista fixa de nomes!)
    let cura = desc.curaEsperada || 0;
    if (cura === 0 && /cura|recupera|pv tempor/.test(txt)) {
        const mD = txt.match(/(\d+)d(\d+)(?:\s*\+\s*(\d+))?/);
        cura = mD ? (Number(mD[1]) * ((Number(mD[2]) + 1) / 2) + Number(mD[3] || 0)) : (6 + (magia.circulo || 1) * 4);
    }

    let defB = desc.defBonus || 0;
    if (defB === 0 && /\+(\d+)\s*(?:na\s*)?defesa/.test(txt)) {
        defB = Number((txt.match(/\+(\d+)\s*(?:na\s*)?defesa/) || [0, 2])[1]);
    }
    if (/camuflagem|imagem espelhada|espelho|chance de falha|50%/.test(txt)) defB += 3.5;

    let rdB = desc.rdBonus || 0;
    if (rdB === 0 && /rd\s*(\d+)|redução de dano\s*(\d+)|metade do dano/.test(txt)) {
        const mR = txt.match(/(?:rd|redução de dano)\s*(\d+)/);
        rdB = mR ? Number(mR[1]) : 10;
    }

    let buffB = (desc.buffGrpAtq || 0) * 3.0 + (desc.buffGrpDano || 0) * 2.0 + (desc.buffGrpDef || 0) * 2.5;
    if (buffB === 0 && /\+(\d+)\s*(?:em testes de ataque|nos testes de ataque|de ataque|nas rolagens de dano|em testes de resistência|em todos os testes)/.test(txt) && !/penalidade|-/.test(txt)) {
        const mB = Math.min(5, Number((txt.match(/\+(\d+)\s*(?:em testes de ataque|nos testes de ataque|de ataque|nas rolagens de dano|em testes de resistência|em todos os testes)/) || [0, 2])[1]));
        buffB = mB * (ehArea ? 4.5 : 2.5);
    }
    if (desc.usa2d20 || /dois dados|rola 2d20|melhor resultado/.test(txt)) buffB += 6.5;
    if (desc.ataquesExtra > 0 || /ação padrão adicional|ataque extra|velocidade/.test(txt)) buffB += 9.0;

    // Controle / Debuff genérico pelas condições oficiais do Apêndice de Tormenta20
    let controle = 0;
    if (/paralisad|atordoad|petrificad|inconscient|imóvel/.test(txt)) controle += 14.0;
    else if (/confus|apavorad|ceg|pasm|fascinad|enfeitiçad|dominad/.test(txt)) controle += 11.5;
    else if (/enredad|lent|caíd|agarrad|exaust|fatigad|enjoad/.test(txt)) controle += 8.5;
    else if (/ofuscad|vulnerável|vulneravel|desprevenid|abalad|alquebrad|enfraquecid|dissipa|anula/.test(txt)) controle += 6.5;
    if (controle > 0) controle *= fatorCD * multAlvos;

    // Utilidade tática (teleporte, voo, invisibilidade, reação)
    let util = 0;
    if (/reação|reacao/.test(String(magia.execucao || '').toLowerCase())) util += 3.5;
    if (/teletransporte|salto dimensional|voo|voar|invisível|invisivel/.test(txt)) util += 5.0;

    const dprMag = desc.dprEsperado || 0;
    const eficPM = Math.max(0.4, 1.25 - (desc.pmBurst || 1) * 0.04);

    // Pesos dinâmicos derivados exclusivamente do arquétipo / foco da build
    let wDano = 1.0, wDef = 1.0, wCura = 0.8, wBuff = 1.1, wCtrl = 1.0, wUtil = 0.8;
    if (arqL.includes('tanque') || arqL.includes('defesa') || arqL.includes('sobreviv')) {
        wDano = 0.4; wDef = 3.4; wCura = 1.5; wBuff = 1.1; wCtrl = 0.7; wUtil = 0.6;
    } else if (arqL.includes('suporte') || arqL.includes('buff') || arqL.includes('cura')) {
        wDano = 0.45; wDef = 1.2; wCura = 2.4; wBuff = 2.6; wCtrl = 1.3; wUtil = 1.0;
    } else if (arqL.includes('controle') || arqL.includes('conjurador') || arqL.includes('arcano')) {
        wDano = 1.5; wDef = 1.1; wCura = 0.7; wBuff = 1.1; wCtrl = 2.2; wUtil = 1.2;
    } else {
        // DPR / Marcial / Híbrido
        wDano = 1.7; wDef = 1.1; wCura = 0.6; wBuff = 1.9; wCtrl = 0.9; wUtil = 0.9;
    }

    const score = (
        dprMag * 0.48 * wDano +
        (defB * 2.2 + rdB * 0.55) * wDef +
        cura * 0.75 * wCura +
        buffB * 1.45 * wBuff +
        controle * 1.15 * wCtrl +
        util * 1.1 * wUtil +
        (magia.circulo || 1) * 1.2
    ) * eficPM;

    const papel = dprMag >= 14 ? 'DANO' : (controle >= 8 ? 'CONTROLE' : (cura >= 6 ? 'CURA' : (defB >= 2 || rdB >= 5 ? 'DEFESA' : 'BUFF')));
    return { magia, score: Number(score.toFixed(2)), papel, escola: String(magia.escola || 'Evocação').trim(), desc };
}

function buscarMelhorGrimorioDinamicoV80JS(classeObj, racaObj, nivel, circMax, arquetipo, atrFinais, poderes, itens, caminhoArcanista) {
    const clsL = String((classeObj && classeObj.nome) || '').toLowerCase();
    const racaL = String((racaObj && racaObj.nome) || '').toLowerCase();

    if (circMax <= 0) {
        // Qareen (Tatuagem Mística): escolhe dinamicamente a melhor magia de 1º círculo para a build (sem hardcode!)
        if (racaL === 'qareen') {
            const mags1 = (CATALOGO_T20.magias || []).filter(m => m.circulo === 1 && (m.tipo === 'Arcana' || m.tipo === 'Universal'));
            const aval1 = mags1.map(m => pontuarMagiaDinamicaV80JS(m, nivel, classeObj, atrFinais, arquetipo, poderes, itens, caminhoArcanista))
                .sort((a, b) => b.score - a.score);
            return { magias: aval1[0] ? [aval1[0].magia] : [], escolasEscolhidas: aval1[0] ? [aval1[0].escola] : [], motivoEscolas: 'Tatuagem Mística (busca dinâmica 1º círculo)' };
        }
        return { magias: [], escolasEscolhidas: [], motivoEscolas: '' };
    }

    const tipoM = ['clérigo', 'clerigo', 'druida'].some(k => clsL.includes(k)) ? 'Divina' : 'Arcana';
    const magDisp = (CATALOGO_T20.magias || []).filter(m => m.circulo <= circMax && (m.tipo === tipoM || m.tipo === 'Universal'));
    const avalTodas = magDisp.map(m => pontuarMagiaDinamicaV80JS(m, nivel, classeObj, atrFinais, arquetipo, poderes, itens, caminhoArcanista))
        .sort((a, b) => b.score - a.score);
    const limiteQtdMag = Math.min(avalTodas.length, 2 + nivel);

    // Seleciona um conjunto com retorno decrescente para papéis repetidos (evita 8 magias redundantes do mesmo papel)
    const pontuarConjunto = (listaOrdenada) => {
        const escolhidas = [];
        const contagemPapel = {};
        let soma = 0;
        for (const item of listaOrdenada) {
            if (escolhidas.length >= limiteQtdMag) break;
            const c = contagemPapel[item.papel] || 0;
            const fatorDiv = Math.pow(0.84, c);
            soma += item.score * fatorDiv;
            contagemPapel[item.papel] = c + 1;
            escolhidas.push(item.magia);
        }
        return { escolhidas, soma };
    };

    // Regra Oficial T20 JdA: Bardo (p. 43) e Druida (p. 61) escolhem exatamente 3 escolas — Busca Combinatória Exata C(8,3) = 56!
    if (clsL === 'bardo' || clsL === 'druida') {
        const escolasUnicas = [...new Set(avalTodas.map(x => x.escola))];
        if (escolasUnicas.length <= 3) {
            const r = pontuarConjunto(avalTodas);
            return { magias: r.escolhidas, escolasEscolhidas: escolasUnicas, motivoEscolas: `Busca combinatória (${escolasUnicas.join(', ')})` };
        }
        let melhorTrio = null;
        let melhorScore = -1;
        let melhorLista = [];
        for (let i = 0; i < escolasUnicas.length; i++) {
            for (let j = i + 1; j < escolasUnicas.length; j++) {
                for (let k = j + 1; k < escolasUnicas.length; k++) {
                    const trio = new Set([escolasUnicas[i], escolasUnicas[j], escolasUnicas[k]]);
                    const sub = avalTodas.filter(x => trio.has(x.escola));
                    if (sub.length === 0) continue;
                    const resTrio = pontuarConjunto(sub);
                    if (resTrio.soma > melhorScore) {
                        melhorScore = resTrio.soma;
                        melhorTrio = [escolasUnicas[i], escolasUnicas[j], escolasUnicas[k]];
                        melhorLista = resTrio.escolhidas;
                    }
                }
            }
        }
        return {
            magias: melhorLista,
            escolasEscolhidas: melhorTrio || [],
            motivoEscolas: `Busca exata C(${escolasUnicas.length},3) escolas -> ${(melhorTrio || []).join(' + ')} (Score Grimório ${melhorScore.toFixed(1)})`
        };
    }

    const rGeral = pontuarConjunto(avalTodas);
    return { magias: rGeral.escolhidas, escolasEscolhidas: [...new Set(rGeral.escolhidas.map(m => m.escola))], motivoEscolas: 'Busca dinâmica sem tabela fixa' };
}

function buscarMelhorEquipamentoDinamicoV80JS(classeObj, racaObj, deusObj, atrBase, livres, nivel, arquetipo, fixArma) {
    const clsL = String((classeObj && classeObj.nome) || '').toLowerCase();
    const racaL = String((racaObj && racaObj.nome) || '').toLowerCase();
    const arqL = String(arquetipo || '').toLowerCase();
    const itensCat = CATALOGO_T20.itens || [];
    const acharItem = (n) => itensCat.find(i => (i.nome || '').toLowerCase() === String(n || '').toLowerCase()) || null;
    const profs = obterProficienciasAtivasJS(classeObj, racaObj, []).map(x => x.toLowerCase());
    const temMarcial = profs.some(p => p.includes('marciais'));
    const temFogo = profs.some(p => p.includes('fogo'));
    const temArmLeve = profs.some(p => p.includes('leves'));
    const temArmPesada = profs.some(p => p.includes('pesadas'));
    const temEscudo = profs.some(p => p.includes('escudos'));
    const armaPrefDeus = (deusObj && deusObj.arma_preferida) ? deusObj.arma_preferida.split('(')[0].split('/')[0].trim().toLowerCase() : '';

    // Atributos efetivos aproximados para comparar armas (FOR vs DES) e armaduras (penalidade/DES)
    const atrSim = Object.assign({ FOR: 0, DES: 0, CON: 0, INT: 0, SAB: 0, CAR: 0 }, atrBase || {});
    if (racaObj) {
        atrSim.FOR += Number(racaObj.mod_for || 0);
        atrSim.DES += Number(racaObj.mod_des || 0);
        atrSim.CON += Number(racaObj.mod_con || 0);
        atrSim.INT += Number(racaObj.mod_int || 0);
        atrSim.SAB += Number(racaObj.mod_sab || 0);
        atrSim.CAR += Number(racaObj.mod_car || 0);
    }

    // 1. Busca Dinâmica de Armadura (todas as armaduras legais do catálogo, filtradas por proficiência e restrição de classe)
    let armaduraEq = null;
    const podeArmadura = clsL !== 'arcanista' && clsL !== 'lutador'; // Arcanista falha arcana; Lutador perde Casca Grossa/mobilidade
    if (podeArmadura) {
        const armadurasDisp = itensCat.filter(it => {
            if (String(it.categoria || '').toLowerCase() !== 'armadura') return false;
            const sub = String(it.subcategoria || '').toLowerCase();
            const nm = String(it.nome || '').toLowerCase();
            const isPesada = sub.includes('pesada');
            if (isPesada && !temArmPesada) return false;
            if (!isPesada && !temArmLeve) return false;
            // Druida não usa armaduras metálicas (JdA p. 61)
            if (clsL === 'druida' && (isPesada || /cota de malha|brunea|couraça|loriga/.test(nm))) return false;
            // Preço razoável pelo nível (Armadura completa só a partir do nível 7)
            const preco = parseFloat(String(it.preco || '0').replace(/\./g, '').replace(',', '.').replace(/[^\d.]/g, '')) || 0;
            const tetoPreco = nivel < 4 ? 300 : (nivel < 7 ? 1500 : 10000);
            if (preco > tetoPreco) return false;
            return true;
        });
        let melhorDefArm = -999;
        for (const arm of armadurasDisp) {
            const defB = parseInt(String(arm.dano_ou_defesa || '0').replace(/[^\d-]/g, ''), 10) || 0;
            const sub = String(arm.subcategoria || '').toLowerCase();
            const isPesada = sub.includes('pesada');
            const defEf = isPesada ? defB : (defB + Math.max(0, atrSim.DES));
            const pen = Math.abs(parseInt(String(arm.critico_ou_penalidade || '0').replace(/[^\d-]/g, ''), 10) || 0);
            // Penalidade de armadura pesa para furtividade/ladino/arqueiro
            const pesoPen = (clsL === 'ladino' || arqL.includes('arqueiro')) ? 0.9 : 0.25;
            const scArm = defEf - pen * pesoPen;
            if (scArm > melhorDefArm) {
                melhorDefArm = scArm;
                armaduraEq = arm;
            }
        }
    }

    // 2. Busca Dinâmica de Arma + Escudo (avalia TODAS as armas proficientes do catálogo via avaliador numérico!)
    let armaEq = null;
    let escudoEq = null;
    if (fixArma && fixArma !== 'AUTO') {
        armaEq = acharItem(fixArma) || null;
    }

    if (!armaEq) {
        const armasDisp = itensCat.filter(it => {
            if (String(it.categoria || '').toLowerCase() !== 'arma') return false;
            const sub = String(it.subcategoria || '').toLowerCase();
            const nm = String(it.nome || '').toLowerCase();
            if (nm === armaPrefDeus) return true;
            if (sub.includes('exótica') || sub.includes('exotica')) {
                if (racaL === 'anão' && /machado anão|martelo/.test(nm)) return true;
                return false;
            }
            if (sub.includes('fogo')) return temFogo || clsL === 'inventor' || clsL === 'bucaneiro';
            if (sub.includes('marcial')) return temMarcial;
            return true; // Armas simples
        });

        // Ataque Desarmado / Manopla entra como candidato aberto para TODAS as classes (sem privilégio fixo!)
        const manoplaCand = acharItem('Manopla') || { id_item: 'DESARMADO_BASE', nome: 'Ataque Desarmado', categoria: 'Arma', subcategoria: 'Arma Simples Corpo a Corpo — Leve', preco: 'T$ 0', dano_ou_defesa: '1d3', critico_ou_penalidade: '20/x2', espacos: 0, efeito_propriedades: 'Ataque desarmado (Leve)' };
        if (!armasDisp.some(a => /manopla|desarmado/i.test(String(a.nome || '')))) armasDisp.push(manoplaCand);

        const escudosDisp = temEscudo && clsL !== 'arcanista' && clsL !== 'lutador'
            ? [null, ...itensCat.filter(it => String(it.categoria || '').toLowerCase() === 'escudo')]
            : [null];

        // Se o ramo prioriza DES, considera Acuidade com Arma na comparação de armas leves/ágeis
        const podsSim = [];
        if (atrSim.DES > atrSim.FOR) {
            podsSim.push({ nome: 'Acuidade com Arma', efeito_resumo: 'Usa DES em ataque e dano com armas leves/ágeis' });
        }
        if (clsL === 'lutador') {
            podsSim.push({ nome: 'Briga', efeito_resumo: 'Aumenta passo de dano desarmado' });
        }

        const estSimBase = { finais: atrSim, pvMax: (classeObj.pv_inicial || 16) + (nivel - 1) * (classeObj.pv_por_nivel || 4) + nivel * atrSim.CON, pmMax: nivel * (classeObj.pm_por_nivel || 3), defesa: 12 + Math.max(0, atrSim.DES) };
        let melhorScoreEq = -1e9;

        for (const a of armasDisp) {
            const sub = String(a.subcategoria || '').toLowerCase();
            const is2M = sub.includes('duas mãos') || sub.includes('duas maos') || sub.includes('distância') || sub.includes('distancia') || sub.includes('fogo');
            const escCand = is2M ? [null] : escudosDisp;
            for (const esc of escCand) {
                const defEsc = esc ? (parseInt(String(esc.dano_ou_defesa || '0').replace(/[^\d-]/g, ''), 10) || 1) : 0;
                const estTest = Object.assign({}, estSimBase, { defesa: estSimBase.defesa + defEsc });
                const met = avaliarBuildNumericaDescritoresV72JS(estTest, podsSim, [], a, arquetipo, nivel, classeObj, esc);
                // Bônus natural de compatibilidade para conjuradores puros com itens esotéricos / cajado
                let sc = met.score;
                if (clsL === 'arcanista' && /cajado|varinha/.test(String(a.nome || '').toLowerCase())) sc += 2.5;
                // Removido bônus fixo +8.0 — Lutador vence desarmado naturalmente por Briga + Golpe Relâmpago!
                if (sc > melhorScoreEq) {
                    melhorScoreEq = sc;
                    armaEq = a;
                    escudoEq = esc;
                }
            }
        }
    }

    // Itens básicos utilitários compatíveis
    const itensInv = [armaEq, armaduraEq, escudoEq, acharItem('Mochila de aventureiro')].filter(Boolean);
    if (['clérigo', 'clerigo', 'paladino', 'druida'].includes(clsL)) {
        const simb = acharItem('Símbolo sagrado');
        if (simb) itensInv.push(simb);
    }
    if (['arcanista', 'bardo', 'inventor'].includes(clsL)) {
        const ess = acharItem('Essência de mana');
        if (ess) itensInv.push(ess);
    }
    return { armaEq, armaduraEq, escudoEq, itensInv };
}

window.pontuarMagiaDinamicaV80JS = pontuarMagiaDinamicaV80JS;
window.buscarMelhorGrimorioDinamicoV80JS = buscarMelhorGrimorioDinamicoV80JS;
window.buscarMelhorEquipamentoDinamicoV80JS = buscarMelhorEquipamentoDinamicoV80JS;

// ======================================================================================
// OTIMIZADOR DINÂMICO DE 10 PONTOS JdA (ESPECIALIZADO, SEM DILUIÇÃO FOR/DES)
// Tabela Oficial Cap. 1, p. 17: -1 (-1 pt), 0 (0 pt), 1 (1 pt), 2 (2 pts), 3 (4 pts), 4 (7 pts)
// ======================================================================================
const CUSTO_PONTOS_JDA_V83 = { '-1': -1, '0': 0, '1': 1, '2': 2, '3': 4, '4': 7 };

function calcularCusto10PontosJdAV83(atr) {
    return ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR'].reduce((acc, k) => {
        const v = Math.max(-1, Math.min(4, parseInt((atr && atr[k]) || 0, 10)));
        return acc + (CUSTO_PONTOS_JDA_V83[String(v)] !== undefined ? CUSTO_PONTOS_JDA_V83[String(v)] : 0);
    }, 0);
}

function otimizarDistribuicao10PontosJdAV83JS(classeObj, racaObj, armaEq, arquetipo, nivel, caminhoArcanista, atrSeed) {
    const clsL = String((classeObj && classeObj.nome) || '').toLowerCase();
    const arqL = String(arquetipo || '').toLowerCase();
    const subA = String((armaEq && armaEq.subcategoria) || '').toLowerCase();
    const propA = String((armaEq && armaEq.efeito_propriedades) || '').toLowerCase();
    const nmA = String((armaEq && armaEq.nome) || '').toLowerCase();
    const ehDist = subA.includes('distância') || subA.includes('distancia') || subA.includes('fogo') || /arco|besta|mosquete|pistola/.test(nmA);
    const ehAgil = !ehDist && (propA.includes('ágil') || propA.includes('leve') || /florete|espada curta|adaga/.test(nmA));

    // Identifica atributos primário, secundário e terciário sem diluir FOR com DES
    let prim = 'FOR', sec = 'CON', terc = 'SAB', dump1 = 'CAR', dump2 = 'INT';
    if (clsL === 'arcanista') {
        prim = String(caminhoArcanista || 'Mago').toLowerCase() === 'feiticeiro' ? 'CAR' : 'INT';
        sec = 'CON'; terc = 'DES'; dump1 = 'FOR'; dump2 = prim === 'INT' ? 'CAR' : 'INT';
    } else if (clsL === 'bardo') {
        prim = 'CAR'; sec = 'CON'; terc = 'DES'; dump1 = 'FOR'; dump2 = 'SAB';
    } else if (clsL === 'clérigo' || clsL === 'clerigo') {
        prim = 'SAB'; sec = 'CON'; terc = 'CAR'; dump1 = 'DES'; dump2 = 'INT';
    } else if (clsL === 'druida') {
        prim = (atrSeed && atrSeed.FOR >= 3 && !arqL.includes('conjurador') && !arqL.includes('suporte')) ? 'FOR' : 'SAB';
        sec = prim === 'FOR' ? 'SAB' : 'CON'; terc = prim === 'FOR' ? 'CON' : 'DES'; dump1 = 'CAR'; dump2 = 'INT';
    } else if (clsL === 'inventor') {
        prim = 'INT'; sec = 'CON'; terc = 'DES'; dump1 = 'FOR'; dump2 = 'CAR';
    } else if (clsL === 'nobre') {
        prim = 'CAR'; sec = 'CON'; terc = 'INT'; dump1 = 'DES'; dump2 = 'FOR';
    } else if (clsL === 'paladino') {
        prim = arqL.includes('tanque') || arqL.includes('suporte') ? 'CAR' : (ehAgil ? 'DES' : 'FOR');
        sec = prim === 'CAR' ? 'FOR' : 'CAR'; terc = 'CON'; dump1 = prim === 'DES' ? 'FOR' : 'DES'; dump2 = 'INT';
    } else if (clsL === 'ladino') {
        prim = 'DES'; sec = 'INT'; terc = 'CON'; dump1 = 'FOR'; dump2 = 'SAB';
    } else if (clsL === 'bucaneiro') {
        prim = 'DES'; sec = 'CAR'; terc = 'CON'; dump1 = 'FOR'; dump2 = 'SAB';
    } else if (clsL === 'caçador' || clsL === 'cacador') {
        prim = (ehDist || ehAgil || (atrSeed && atrSeed.DES >= 3)) ? 'DES' : 'FOR';
        sec = 'SAB'; terc = 'CON'; dump1 = 'CAR'; dump2 = prim === 'DES' ? 'FOR' : 'INT';
    } else {
        // Guerreiro, Bárbaro, Cavaleiro, Lutador: especializa estritamente em FOR OU DES (NUNCA dilui os dois!)
        const usaDes = ehDist || (ehAgil && atrSeed && atrSeed.DES > atrSeed.FOR);
        prim = usaDes ? 'DES' : 'FOR';
        sec = 'CON';
        terc = (clsL === 'cavaleiro') ? 'CAR' : 'SAB';
        dump1 = 'CAR';
        dump2 = prim === 'FOR' ? 'DES' : 'FOR';
        if (dump1 === terc) dump1 = 'INT';
    }

    // Gera arquétipos de distribuição EXATA de 10 pontos JdA (100% especializados!)
    const mk = (p, s, t, d1, d2) => {
        const o = { FOR: 0, DES: 0, CON: 0, INT: 0, SAB: 0, CAR: 0 };
        o[prim] = p; o[sec] = s;
        if (t !== 0) o[terc] = t;
        if (d1 !== 0 && d1 !== undefined) o[dump1] = d1;
        if (d2 !== 0 && d2 !== undefined && dump2 !== dump1) o[dump2] = d2;
        return o;
    };

    const candidatos = [
        mk(4, 3, 0, -1, 0),    // 7 + 4 - 1 = 10 pts (Especialista Máximo: +4/+3, 1 dump -1, ZERO diluição!)
        mk(4, 3, 1, -1, -1),   // 7 + 4 + 1 - 1 - 1 = 10 pts (+4/+3/+1, 2 dumps -1)
        mk(4, 2, 2, -1, 0),    // 7 + 2 + 2 - 1 = 10 pts (+4/+2/+2, 1 dump -1)
        mk(4, 2, 1, 0, 0),     // 7 + 2 + 1 = 10 pts (+4/+2/+1, sem dump negativo)
        mk(3, 3, 2, 0, 0)      // 4 + 4 + 2 = 10 pts (apenas para classes duais ex: Paladino/Tanque se vencer no score)
    ].filter(c => calcularCusto10PontosJdAV83(c) === 10);

    const livresOrd = [prim, sec, terc].filter((v, i, a) => a.indexOf(v) === i);
    const podsEval = (prim === 'DES' && !ehDist) ? [{ nome: 'Acuidade com Arma', efeito_resumo: 'Usa DES em ataque e dano' }] : [];
    let melhor = candidatos[0];
    let melhorScore = -1e9;

    for (const c of candidatos) {
        const atrR = Object.assign({}, c);
        if (racaObj) {
            atrR.FOR += Number(racaObj.mod_for || 0); atrR.DES += Number(racaObj.mod_des || 0);
            atrR.CON += Number(racaObj.mod_con || 0); atrR.INT += Number(racaObj.mod_int || 0);
            atrR.SAB += Number(racaObj.mod_sab || 0); atrR.CAR += Number(racaObj.mod_car || 0);
            const qtdL = Number(racaObj.mod_livre || 0);
            const nr = String(racaObj.nome || '').toLowerCase();
            const proibido = nr === 'osteon' ? 'CON' : (nr === 'lefou' ? 'CAR' : '');
            const candsL = [...livresOrd, 'CON', 'SAB', 'INT', 'CAR', 'FOR', 'DES'].filter((v, i, a) => a.indexOf(v) === i && v !== proibido);
            candsL.slice(0, qtdL).forEach(sig => { atrR[sig] = (atrR[sig] || 0) + 1; });
        }
        const pvE = (classeObj.pv_inicial || 16) + (nivel - 1) * (classeObj.pv_por_nivel || 4) + nivel * atrR.CON;
        const pmE = nivel * (classeObj.pm_por_nivel || 3);
        const defE = 12 + Math.max(0, atrR.DES);
        const met = avaliarBuildNumericaDescritoresV72JS({ finais: atrR, pvMax: Math.max(10, pvE), pmMax: Math.max(3, pmE), defesa: defE }, podsEval, [], armaEq, arquetipo, nivel, classeObj, null);
        // Pequeno desempate natural em favor de especialização máxima no atributo-chave (4 vs 3)
        const sc = met.score + (c[prim] === 4 ? 1.5 : 0);
        if (sc > melhorScore) {
            melhorScore = sc;
            melhor = c;
        }
    }
    return { atrBase: melhor, livres: livresOrd };
}

window.calcularCusto10PontosJdAV83 = calcularCusto10PontosJdAV83;
window.otimizarDistribuicao10PontosJdAV83JS = otimizarDistribuicao10PontosJdAV83JS;

// ======================================================================================
// RECARGA REAL DE ARMAS DE FOGO/BESTAS + SISTEMA ESPACIAL DE MOVIMENTO & ALCANCE
// ======================================================================================

function calcularRecargaArmaT20JS(arma, poderes) {
    const nm = String((arma && arma.nome) || '').toLowerCase();
    const sub = String((arma && arma.subcategoria) || '').toLowerCase();
    const prop = String((arma && arma.efeito_propriedades) || '').toLowerCase();
    const podsL = new Set((poderes || []).map(p => String((p && p.nome) || '').toLowerCase()));
    const temSaque = podsL.has('saque rápido');
    const temEstArrem = podsL.has('estilo de arremesso');

    const ehFogo = sub.includes('fogo') || /pistola|mosquete/.test(nm);
    const ehBestaPes = /besta pesada/.test(nm);
    const ehBestaLeve = /besta leve/.test(nm);
    const ehArrem = sub.includes('arremesso') || prop.includes('arremesso') || /azagaia|machadinha|shuriken|dardo|tridente|lança|adaga/.test(nm);
    const ehArco = /arco/.test(nm);

    let acaoBase = 'LIVRE';
    let acaoEfetiva = 'LIVRE';
    let fatorCadencia = 1.0;
    let permiteDisparoRapido = true;
    let descricao = 'Recarga Livre (1 ataque/turno + movimento livre)';

    if (ehFogo || ehBestaPes) {
        acaoBase = 'PADRAO';
        if (temSaque) {
            acaoEfetiva = 'MOVIMENTO';
            fatorCadencia = 1.0; // Dispara (Padrão) + Recarrega (Movimento) = 1/turno, mas sem movimento livre!
            permiteDisparoRapido = false;
            descricao = 'Recarga Movimento (Saque Rápido: dispara 1x/turno, consome Ação de Movimento)';
        } else {
            acaoEfetiva = 'PADRAO';
            fatorCadencia = 0.5; // Turno 1 dispara, Turno 2 recarrega (Ação Padrão) = 0,5 ataque/turno!
            permiteDisparoRapido = false;
            descricao = 'Recarga Padrão (sem Saque Rápido: dispara a cada 2 turnos = 0,5x cadência)';
        }
    } else if (ehBestaLeve) {
        acaoBase = 'MOVIMENTO';
        if (temSaque) {
            acaoEfetiva = 'LIVRE';
            fatorCadencia = 1.0;
            permiteDisparoRapido = true;
            descricao = 'Recarga Livre (Saque Rápido: movimento livre + Disparo Rápido liberado)';
        } else {
            acaoEfetiva = 'MOVIMENTO';
            fatorCadencia = 1.0;
            permiteDisparoRapido = false;
            descricao = 'Recarga Movimento (dispara 1x/turno, consome Ação de Movimento)';
        }
    } else if (ehArrem && sub.includes('distância')) {
        acaoBase = 'MOVIMENTO';
        if (temEstArrem || temSaque) {
            acaoEfetiva = 'LIVRE';
            fatorCadencia = 1.0;
            permiteDisparoRapido = true;
            descricao = 'Saque Livre (Estilo de Arremesso/Saque Rápido)';
        } else {
            acaoEfetiva = 'MOVIMENTO';
            fatorCadencia = 1.0;
            permiteDisparoRapido = false;
            descricao = 'Saque Movimento (consome Ação de Movimento para sacar nova arma)';
        }
    } else if (ehArco) {
        acaoBase = 'LIVRE';
        acaoEfetiva = 'LIVRE';
        fatorCadencia = 1.0;
        permiteDisparoRapido = true;
        descricao = 'Recarga Livre (Arco: movimento livre + Disparo Rápido)';
    }
    return { acaoBase, acaoEfetiva, fatorCadencia, permiteDisparoRapido, ehFogo, ehBestaPes, ehBestaLeve, ehArrem, ehArco, descricao };
}

function obterPerfilEspacialPersonagemV88JS(ficha) {
    const raca = ficha.raca || {};
    const cls = String((ficha.classe && ficha.classe.nome) || '').toLowerCase();
    const arma = ficha.arma || null;
    const armadura = ficha.armadura || null;
    const poderes = ficha.poderes || [];
    const magias = ficha.magias || [];
    const podsL = new Set(poderes.map(p => String((p && p.nome) || '').toLowerCase()));

    // 1. Deslocamento Real (m) conforme T20 JdA
    let deslocamento = Number(raca.deslocamento_m || 9);
    const armPesada = armadura && String(armadura.subcategoria || '').toLowerCase().includes('pesada');
    if (armPesada && !podsL.has('fanático')) deslocamento = Math.max(3, deslocamento - 3);
    if (podsL.has('atlético')) deslocamento += 3;
    if (cls === 'bárbaro' && (ficha.nivel || 6) >= 5) deslocamento += 3; // Movimento Rápido
    if (cls === 'caçador' && podsL.has('explorador')) deslocamento += 1.5;

    // 2. Alcance Efetivo & Papel Espacial (CORPO vs DISTANCIA)
    const nmA = String((arma && arma.nome) || '').toLowerCase();
    const subA = String((arma && arma.subcategoria) || '').toLowerCase();
    const propA = String((arma && arma.efeito_propriedades) || '').toLowerCase();
    const ehConj = ['arcanista', 'clérigo', 'clerigo', 'druida', 'bardo'].includes(cls) && magias.length > 0;
    const ehArrem = subA.includes('arremesso') || propA.includes('arremesso') || /azagaia|machadinha|shuriken|dardo|tridente|lança/.test(nmA);
    const ehDisp = subA.includes('distância') || subA.includes('fogo') || /arco|besta|mosquete|pistola|funda/.test(nmA);
    const ehAlongada = propA.includes('alongada') || /alabarda|pique|lança montada/.test(nmA);

    let papelEspacial = 'CORPO';
    let alcanceMaxM = ehAlongada ? 3.0 : 1.5;
    let fonteAlcance = ehAlongada ? `${arma ? arma.nome : 'Haste'} (Alongada 3m)` : `${arma ? arma.nome : 'Corpo a Corpo'} (Adjacente 1,5m)`;

    if (ehDisp || (ehArrem && subA.includes('distância'))) {
        papelEspacial = 'DISTANCIA';
        if (/arco longo|besta pesada|mosquete/.test(nmA)) { alcanceMaxM = 30; fonteAlcance = `${arma.nome} (Alcance Médio: 30m)`; }
        else if (/arco curto|besta leve|funda/.test(nmA)) { alcanceMaxM = 18; fonteAlcance = `${arma.nome} (Alcance Curto/Médio: 18m)`; }
        else { alcanceMaxM = 9; fonteAlcance = `${arma.nome} (Alcance Curto: 9m)`; }
    } else if (ehConj) {
        papelEspacial = 'DISTANCIA';
        const temAmpliada = podsL.has('magia ampliada');
        const temMedia = magias.some(m => String(m.alcance || '').toLowerCase().includes('médio') || String(m.alcance || '').toLowerCase().includes('medio'));
        alcanceMaxM = (temMedia ? 30 : 9) * (temAmpliada ? 2 : 1);
        fonteAlcance = `Magias (${temMedia ? 'Alcance Médio 30m' : 'Alcance Curto 9m'}${temAmpliada ? ' ×2 Magia Ampliada' : ''})`;
    }

    const recarga = papelEspacial === 'DISTANCIA' && !ehConj
        ? calcularRecargaArmaT20JS(arma, poderes)
        : { acaoBase: 'LIVRE', acaoEfetiva: 'LIVRE', fatorCadencia: 1.0, permiteDisparoRapido: true, descricao: ehConj ? 'Conjuração (sem recarga de arma)' : 'Corpo a Corpo (sem recarga)' };

    const met = avaliarBuildNumericaDescritoresV72JS(ficha.est, poderes, magias, arma, ficha.arquetipo || 'DPR Máximo (Dano)', ficha.nivel || 6, ficha.classe, ficha.escudo);
    return {
        nome: ficha.nome || 'Herói',
        classe: (ficha.classe && ficha.classe.nome) || 'Guerreiro',
        raca: raca.nome || 'Humano',
        deslocamento,
        papelEspacial,
        alcanceMaxM,
        fonteAlcance,
        recarga,
        temDisparoPreciso: podsL.has('disparo preciso'),
        dprEstatico: met.dpr,
        dprPorTurnoBase: met.dpr
    };
}

function simularMovimentoEAlcanceV88JS(ficha, cfgCenario) {
    const perfil = obterPerfilEspacialPersonagemV88JS(ficha);
    const cfg = Object.assign({
        perfilAlvo: 'CORPO_9M',
        larguraMapaM: 45,
        rodadas: 6
    }, cfgCenario || {});

    const mapaMax = Math.max(18, Number(cfg.larguraMapaM || 45));
    const nRodadas = Math.max(3, Math.min(12, Number(cfg.rodadas || 6)));
    const deslAlvo = cfg.perfilAlvo === 'AGIL_12M' ? 12 : (cfg.perfilAlvo === 'LENTO_6M' ? 6 : 9);
    const alvoEhDistancia = cfg.perfilAlvo === 'ATIRADOR_9M';

    // Posição relativa em arena aberta 2D (largura = mapaMax): começa EXATAMENTE em Alcance Curto (9m de separação)!
    let dist = 9.0;
    let posHeroi = 1.5;
    let posAlvo = posHeroi + dist;
    let armaCarregada = true;
    let rodadasComAtaque = 0;
    let somaDistancias = 0;
    let somaDanoEspacial = 0;
    let rodadasZonaIdeal = 0;
    const historico = [];

    for (let r = 1; r <= nRodadas; r++) {
        const distIni = Number(dist.toFixed(1));
        let acaoMov = '';
        let acaoPad = '';
        let atacou = false;
        let danoRodada = 0;
        let penalidadeEngajado = false;

        if (perfil.papelEspacial === 'DISTANCIA') {
            // Objetivo do personagem à distância: ficar na DISTÂNCIA MÁXIMA POSSÍVEL dentro do alcance efetivo!
            const precisaRecarregar = !armaCarregada;
            let movLivre = true;

            if (precisaRecarregar && perfil.recarga.acaoEfetiva === 'PADRAO') {
                // Gasta Ação Padrão recarregando, mas usa Ação de Movimento para recuar!
                armaCarregada = true;
                acaoPad = `Recarrega ${ficha.arma ? ficha.arma.nome : 'arma'} (Ação Padrão — 0 ataques)`;
                const recuo = Number(Math.min(perfil.deslocamento, Math.max(0, mapaMax - dist)).toFixed(1));
                dist = Number((dist + recuo).toFixed(1));
                posAlvo = Number(Math.min(mapaMax, posHeroi + dist).toFixed(1));
                acaoMov = recuo > 0 ? `Recua ${recuo}m em direção à borda segura` : 'Encostado na borda do mapa (0m recuo)';
            } else {
                if (precisaRecarregar && perfil.recarga.acaoEfetiva === 'MOVIMENTO') {
                    armaCarregada = true;
                    movLivre = false;
                    acaoMov = `Recarrega ${ficha.arma ? ficha.arma.nome : 'arma'} (consome Ação de Movimento — não pode kitar)`;
                }
                const distAtual = dist;
                // Se tem movimento livre e está aquém do alcance máximo, recua pelo perímetro da arena para maximizar a distância!
                if (movLivre) {
                    const distDesejada = Math.min(perfil.alcanceMaxM, mapaMax - 1.5);
                    if (distAtual < distDesejada) {
                        const passoRecuo = Math.min(perfil.deslocamento, distDesejada - distAtual);
                        dist = Number((dist + passoRecuo).toFixed(1));
                        posAlvo = Number(Math.min(mapaMax, posHeroi + dist).toFixed(1));
                        acaoMov = passoRecuo > 0 ? `Recua ${passoRecuo.toFixed(1)}m (buscando alcance máx. ${perfil.alcanceMaxM}m)` : 'Mantém posição no limite do mapa';
                    } else if (distAtual > perfil.alcanceMaxM) {
                        const passoAv = Math.min(perfil.deslocamento, distAtual - perfil.alcanceMaxM);
                        dist = Number(Math.max(1.5, dist - passoAv).toFixed(1));
                        posAlvo = Number(Math.min(mapaMax, posHeroi + dist).toFixed(1));
                        acaoMov = `Avança ${passoAv.toFixed(1)}m para entrar no alcance (${perfil.alcanceMaxM}m)`;
                    } else {
                        acaoMov = `Mantém distância ótima (${distAtual.toFixed(1)}m)`;
                    }
                }
                const distTiro = Number(dist.toFixed(1));
                if (distTiro <= perfil.alcanceMaxM + 0.1) {
                    atacou = true;
                    // Penalidade -5 se o alvo estiver adjacente (<=1.5m) sem Disparo Preciso
                    penalidadeEngajado = distTiro <= 1.5 && !perfil.temDisparoPreciso;
                    const multEng = penalidadeEngajado ? 0.72 : 1.0;
                    // Se recarga era Padrão (0.5x já embutido no dprEstatico), normalizamos o disparo individual para 100% no turno que atira!
                    const dprDisparo = perfil.recarga.acaoEfetiva === 'PADRAO' ? (perfil.dprEstatico * 2.0) : perfil.dprEstatico;
                    danoRodada = Number((dprDisparo * multEng).toFixed(1));
                    acaoPad = `Dispara/Conjura a ${distTiro}m${penalidadeEngajado ? ' (-5 engajado sem Disparo Preciso)' : ''} → ${danoRodada} dano`;
                    if (perfil.recarga.acaoEfetiva === 'PADRAO' || perfil.recarga.acaoEfetiva === 'MOVIMENTO') {
                        armaCarregada = false;
                    }
                } else {
                    acaoPad = `Fora de alcance (${distTiro}m > ${perfil.alcanceMaxM}m) — sem ataque`;
                }
            }
        } else {
            // Objetivo do combatente corpo a corpo: ficar ADJACENTE ao alvo (1,5m ou 3,0m com haste)!
            const distAtual = dist;
            if (distAtual <= perfil.alcanceMaxM + 0.1) {
                acaoMov = `Mantém engajamento adjacente (${distAtual.toFixed(1)}m)`;
                atacou = true;
                danoRodada = perfil.dprEstatico;
                acaoPad = `Agredir corpo a corpo (${distAtual.toFixed(1)}m) → ${danoRodada} dano`;
            } else if (distAtual <= perfil.alcanceMaxM + perfil.deslocamento + 0.1) {
                const av = Number((distAtual - perfil.alcanceMaxM).toFixed(1));
                dist = perfil.alcanceMaxM;
                posAlvo = Number(Math.min(mapaMax, posHeroi + dist).toFixed(1));
                acaoMov = `Avança ${av}m até ficar adjacente (${perfil.alcanceMaxM}m)`;
                atacou = true;
                danoRodada = perfil.dprEstatico;
                acaoPad = `Agredir corpo a corpo → ${danoRodada} dano`;
            } else if (distAtual <= perfil.alcanceMaxM + perfil.deslocamento * 2 + 0.1) {
                const av = Number((distAtual - perfil.alcanceMaxM).toFixed(1));
                dist = perfil.alcanceMaxM;
                posAlvo = Number(Math.min(mapaMax, posHeroi + dist).toFixed(1));
                acaoMov = `Investida (2× deslocamento: ${av}m, +2 Atq / -2 Def)`;
                atacou = true;
                danoRodada = Number((perfil.dprEstatico * 0.85).toFixed(1));
                acaoPad = `Golpe de Investida → ${danoRodada} dano`;
            } else {
                const av = Number((perfil.deslocamento * 2).toFixed(1));
                dist = Number(Math.max(perfil.alcanceMaxM, dist - av).toFixed(1));
                posAlvo = Number(Math.min(mapaMax, posHeroi + dist).toFixed(1));
                acaoMov = `Corrida / Movimento Duplo (+${av}m)`;
                acaoPad = `Ainda fora de alcance (${dist.toFixed(1)}m) — 0 ataques`;
            }
        }

        // Turno do Alvo
        let acaoAlvo = '';
        if (alvoEhDistancia) {
            const recAlvo = Number(Math.min(deslAlvo, Math.max(0, mapaMax - 1.5 - dist)).toFixed(1));
            dist = Number((dist + recAlvo).toFixed(1));
            posAlvo = Number(Math.min(mapaMax, posHeroi + dist).toFixed(1));
            acaoAlvo = recAlvo > 0 ? `Alvo recua ${recAlvo.toFixed(1)}m (mantendo distância)` : 'Alvo atingiu limite da arena';
        } else {
            if (dist > 1.5) {
                const avAlvo = Number(Math.min(deslAlvo, dist - 1.5).toFixed(1));
                dist = Number(Math.max(1.5, dist - avAlvo).toFixed(1));
                posAlvo = Number(Math.min(mapaMax, posHeroi + dist).toFixed(1));
                acaoAlvo = `Alvo avança ${avAlvo.toFixed(1)}m em direção ao herói`;
            } else {
                acaoAlvo = 'Alvo mantém pressão adjacente (1,5m)';
            }
        }

        const distFim = Number(dist.toFixed(1));
        if (atacou) rodadasComAtaque++;
        somaDistancias += distFim;
        somaDanoEspacial += danoRodada;
        const emZonaIdeal = perfil.papelEspacial === 'DISTANCIA' ? (distFim >= 6.0 && distFim <= perfil.alcanceMaxM + 0.1) : (distFim <= perfil.alcanceMaxM + 0.1);
        if (emZonaIdeal) rodadasZonaIdeal++;

        historico.push({
            rodada: r, distIni, distFim, posHeroi, posAlvo,
            acaoMov, acaoPad, acaoAlvo, atacou, danoRodada, emZonaIdeal
        });
    }

    const uptimePct = Number(((rodadasComAtaque / nRodadas) * 100).toFixed(1));
    const dprEspacialReal = Number((somaDanoEspacial / nRodadas).toFixed(1));
    const distMediaM = Number((somaDistancias / nRodadas).toFixed(1));
    const zonaIdealPct = Number(((rodadasZonaIdeal / nRodadas) * 100).toFixed(1));
    const eficienciaEspacialPct = perfil.dprEstatico > 0 ? Number(Math.min(100, (dprEspacialReal / perfil.dprEstatico) * 100).toFixed(1)) : 0;

    return {
        perfil,
        cfg: { ...cfg, larguraMapaM: mapaMax, rodadas: nRodadas },
        uptimePct,
        dprEspacialReal,
        distMediaM,
        zonaIdealPct,
        eficienciaEspacialPct,
        historico
    };
}

function renderizarAbaMovimentoV88JS() {
    const container = document.getElementById('movimento-v88-resultado');
    if (!container) return;
    const ficha = window.__ULTIMO_ESTADO_FICHA__;
    if (!ficha) {
        container.innerHTML = '<div style="padding:16px;color:#FDE68A;">Gere ou carregue uma ficha primeiro para simular movimento e alcance.</div>';
        return;
    }
    const selAlvo = document.getElementById('mov-sel-alvo');
    const selMapa = document.getElementById('mov-sel-mapa');
    const selRod = document.getElementById('mov-sel-rodadas');
    const sim = simularMovimentoEAlcanceV88JS(ficha, {
        perfilAlvo: selAlvo ? selAlvo.value : 'CORPO_9M',
        larguraMapaM: selMapa ? parseInt(selMapa.value, 10) : 45,
        rodadas: selRod ? parseInt(selRod.value, 10) : 6
    });

    const W = 720, H = 195, padX = 36;
    const scaleX = (m) => padX + (Math.max(0, Math.min(sim.cfg.larguraMapaM, m)) / sim.cfg.larguraMapaM) * (W - padX * 2);
    const ult = sim.historico[sim.historico.length - 1];
    const ini = sim.historico[0];

    let svgTicks = '';
    for (let m = 0; m <= sim.cfg.larguraMapaM; m += 9) {
        const x = scaleX(m).toFixed(1);
        svgTicks += `<line x1="${x}" y1="30" x2="${x}" y2="155" stroke="rgba(255,255,255,0.12)" stroke-dasharray="3,3"/>` +
            `<text x="${x}" y="174" fill="#94A3B8" font-size="10" text-anchor="middle">${m}m</text>`;
    }

    const hx0 = scaleX(ini.posHeroi).toFixed(1), ax0 = scaleX(ini.posAlvo).toFixed(1);
    const hx1 = scaleX(ult.posHeroi).toFixed(1), ax1 = scaleX(ult.posAlvo).toFixed(1);
    const rangePx = Math.min(W - padX * 2, (sim.perfil.alcanceMaxM / sim.cfg.larguraMapaM) * (W - padX * 2));

    const svgMapa = `
    <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;background:#0F172A;border-radius:10px;border:1px solid rgba(251,191,36,0.35);">
        ${svgTicks}
        <line x1="${padX}" y1="68" x2="${W - padX}" y2="68" stroke="rgba(148,163,184,0.35)" stroke-width="2"/>
        <line x1="${padX}" y1="126" x2="${W - padX}" y2="126" stroke="rgba(251,191,36,0.45)" stroke-width="2"/>
        <text x="${padX}" y="22" fill="#94A3B8" font-size="11" font-weight="bold">Início (Alcance Curto: 9m)</text>
        <text x="${padX}" y="106" fill="#FCD34D" font-size="11" font-weight="bold">Posição Final (Rodada ${sim.cfg.rodadas} — Distância: ${ult.distFim}m)</text>
        <!-- Linha inicial -->
        <circle cx="${hx0}" cy="68" r="9" fill="#38BDF8" stroke="#fff" stroke-width="1.5"/>
        <text x="${hx0}" y="53" fill="#38BDF8" font-size="10" text-anchor="middle">Herói (${ini.posHeroi}m)</text>
        <circle cx="${ax0}" cy="68" r="9" fill="#F87171" stroke="#fff" stroke-width="1.5"/>
        <text x="${ax0}" y="53" fill="#F87171" font-size="10" text-anchor="middle">Alvo (${ini.posAlvo}m)</text>
        <!-- Zona de alcance final -->
        <rect x="${hx1}" y="114" width="${Math.max(4, Math.min(rangePx, W - padX - Number(hx1))).toFixed(1)}" height="24" rx="4" fill="rgba(56,189,248,0.18)" stroke="rgba(56,189,248,0.5)" stroke-dasharray="4,2"/>
        <!-- Linha final -->
        <circle cx="${hx1}" cy="126" r="10" fill="#22C55E" stroke="#fff" stroke-width="2"/>
        <text x="${hx1}" y="148" fill="#86EFAC" font-size="10" text-anchor="middle">Herói (${ult.posHeroi}m)</text>
        <circle cx="${ax1}" cy="126" r="10" fill="#EF4444" stroke="#fff" stroke-width="2"/>
        <text x="${ax1}" y="148" fill="#FCA5A5" font-size="10" text-anchor="middle">Alvo (${ult.posAlvo}m)</text>
    </svg>`;

    const rowsLog = sim.historico.map(h => `
        <tr style="border-bottom:1px solid rgba(255,255,255,0.08);">
            <td style="padding:6px;font-weight:700;color:#FCD34D;">R${h.rodada}</td>
            <td style="padding:6px;">${h.distIni}m → <b>${h.distFim}m</b></td>
            <td style="padding:6px;color:#BAE6FD;">${h.acaoMov}</td>
            <td style="padding:6px;color:${h.atacou ? '#86EFAC' : '#FCA5A5'};">${h.acaoPad}</td>
            <td style="padding:6px;color:#CBD5E1;">${h.acaoAlvo}</td>
        </tr>`).join('');

    container.innerHTML = `
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;margin-bottom:12px;">
            <div style="background:#1E293B;padding:10px;border-radius:8px;border:1px solid #334155;">
                <div style="font-size:11px;color:#94A3B8;">Deslocamento Real</div>
                <div style="font-size:18px;font-weight:800;color:#38BDF8;">${sim.perfil.deslocamento}m</div>
                <div style="font-size:10px;color:#CBD5E1;">${sim.perfil.raca} ${sim.perfil.classe}</div>
            </div>
            <div style="background:#1E293B;padding:10px;border-radius:8px;border:1px solid #334155;">
                <div style="font-size:11px;color:#94A3B8;">Alcance Efetivo</div>
                <div style="font-size:18px;font-weight:800;color:#FCD34D;">${sim.perfil.alcanceMaxM}m</div>
                <div style="font-size:10px;color:#CBD5E1;">${sim.perfil.fonteAlcance}</div>
            </div>
            <div style="background:#1E293B;padding:10px;border-radius:8px;border:1px solid #334155;">
                <div style="font-size:11px;color:#94A3B8;">Recarga & Cadência</div>
                <div style="font-size:16px;font-weight:800;color:${sim.perfil.recarga.acaoEfetiva === 'LIVRE' ? '#4ADE80' : '#FBBF24'};">${sim.perfil.recarga.acaoEfetiva} (${Math.round(sim.perfil.recarga.fatorCadencia * 100)}%)</div>
                <div style="font-size:10px;color:#CBD5E1;">${sim.perfil.recarga.descricao}</div>
            </div>
            <div style="background:#1E293B;padding:10px;border-radius:8px;border:1px solid #334155;">
                <div style="font-size:11px;color:#94A3B8;">Uptime Ofensivo</div>
                <div style="font-size:18px;font-weight:800;color:${sim.uptimePct >= 80 ? '#4ADE80' : '#F87171'};">${sim.uptimePct}%</div>
                <div style="font-size:10px;color:#CBD5E1;">Zona ideal: ${sim.zonaIdealPct}% | Dist. média: ${sim.distMediaM}m</div>
            </div>
            <div style="background:#1E293B;padding:10px;border-radius:8px;border:1px solid #334155;">
                <div style="font-size:11px;color:#94A3B8;">DPR Espacial vs. Estático</div>
                <div style="font-size:18px;font-weight:800;color:#C084FC;">${sim.dprEspacialReal} <span style="font-size:12px;color:#94A3B8;">/ ${sim.perfil.dprEstatico}</span></div>
                <div style="font-size:10px;color:#CBD5E1;">Eficiência real em mapa: ${sim.eficienciaEspacialPct}%</div>
            </div>
        </div>
        <div style="margin-bottom:12px;">${svgMapa}</div>
        <div style="overflow-x:auto;background:#0F172A;border-radius:8px;border:1px solid #334155;">
            <table style="width:100%;border-collapse:collapse;font-size:12px;color:#E2E8F0;">
                <thead>
                    <tr style="background:#1E293B;text-align:left;color:#FCD34D;">
                        <th style="padding:7px;">Rod.</th>
                        <th style="padding:7px;">Distância</th>
                        <th style="padding:7px;">Ação de Movimento</th>
                        <th style="padding:7px;">Ação Padrão / Ataque</th>
                        <th style="padding:7px;">Reação do Alvo</th>
                    </tr>
                </thead>
                <tbody>${rowsLog}</tbody>
            </table>
        </div>` + renderEquipmentComparison(ficha) + renderGlobalItemMatrix(ficha) + renderCombinatorialCalculator();
}

window.calcularRecargaArmaT20JS = calcularRecargaArmaT20JS;
window.obterPerfilEspacialPersonagemV88JS = obterPerfilEspacialPersonagemV88JS;
window.simularMovimentoEAlcanceV88JS = simularMovimentoEAlcanceV88JS;
window.renderizarAbaMovimentoV88JS = renderizarAbaMovimentoV88JS;

/**
 * Módulo de Avaliação Isolada de Equipamentos e Análise Combinatória.
 * Mantém o otimizador intrínseco desacoplado de itens e permite isolar
 * separadamente o impacto de itens comuns, superiores, mágicos e combinados.
 */

const EQUIPMENT_BENCHMARK_MATRIX = [["Arcanista",1,"Osteon","Cajado arcano",8.2,8.2,0,8.2,0,8.2,0,3.56,3.56,49.5,49.5],["Arcanista",2,"Osteon","Cajado arcano",12.5,14.5,16,14.5,16,14.5,16,5.21,5.21,116.7,143.1],["Arcanista",3,"Osteon","Cajado arcano",20.7,22.7,9.7,22.7,9.7,22.7,9.7,5.76,5.76,191.6,218],["Arcanista",4,"Osteon","Cajado arcano",31.5,31.5,0,31.5,0,31.5,0,7.05,7.3,237.2,237.9],["Arcanista",5,"Osteon","Cajado arcano",64.3,64.3,0,64.3,0,64.3,0,7.6,7.89,380.9,381.8],["Arcanista",6,"Humano","Cajado arcano",120.3,120.3,0,120.3,0,120.3,0,9.83,10.21,552.9,554.1],["Arcanista",7,"Anão","Cajado arcano",124.4,129.9,4.4,129.9,4.4,129.9,4.4,12.9,12.9,603.2,639.4],["Arcanista",8,"Anão","Cajado arcano",153.3,155.3,1.3,155.3,1.3,155.3,1.3,14.45,14.45,697.4,723.8],["Arcanista",9,"Anão","Cajado arcano",167.1,169.1,1.2,169.1,1.2,169.1,1.2,15.25,15.43,750,776.9],["Arcanista",10,"Anão","Cajado arcano",172.8,174.8,1.2,174.8,1.2,174.8,1.2,16.8,17,825.5,852.5],["Arcanista",11,"Anão","Cajado arcano",187,192.5,2.9,192.5,2.9,192.5,2.9,17.6,17.82,880.7,917.5],["Arcanista",12,"Anão","Cajado arcano",191.1,196.6,2.9,198.6,3.9,198.6,3.9,19.65,19.88,940.7,1004],["Arcanista",13,"Anão","Cajado arcano",205.7,213.2,3.6,215.2,4.6,215.2,4.6,20.45,21.71,997,1089.8],["Arcanista",14,"Anão","Cajado arcano",210.1,217.6,3.6,219.6,4.5,219.6,4.5,28.3,37.3,1043,1159],["Arcanista",15,"Anão","Cajado arcano",225.2,232.7,3.3,234.7,4.2,234.7,4.2,31,34.55,1106.5,1206.2],["Arcanista",16,"Anão","Cajado arcano",222.7,230.2,3.4,232.2,4.3,232.2,4.3,38.49,48.51,1133.3,1252.4],["Arcanista",17,"Anão","Cajado arcano",222.8,230.3,3.4,236.3,6.1,236.3,6.1,39.96,50.16,1153.4,1325.8],["Arcanista",18,"Anão","Cajado arcano",242.9,250.4,3.1,252.4,3.9,252.4,3.9,43.03,53.41,1231.9,1359.3],["Arcanista",19,"Anão","Cajado arcano",243,250.5,3.1,252.5,3.9,252.5,3.9,45.44,67.46,1249.4,1411.6],["Arcanista",20,"Anão","Cajado arcano",263.8,271.3,2.8,273.3,3.6,273.3,3.6,48.69,71.11,1330.4,1493.8],["Bárbaro",1,"Osteon","Montante",18.9,18.9,0,18.9,0,18.9,0,6.05,6.05,97.8,97.8],["Bárbaro",2,"Osteon","Montante",33.4,34.2,2.4,33.4,0,34.2,2.4,7.91,7.91,166.9,170.6],["Bárbaro",3,"Osteon","Montante",48.4,49.6,2.5,48.4,0,49.6,2.5,9.01,9.01,237.1,242.6],["Bárbaro",4,"Minotauro","Montante",67.1,68.6,2.2,67.1,0,68.6,2.2,11.12,11.12,326.2,332.9],["Bárbaro",5,"Minotauro","Montante",82.1,84,2.3,82.1,0,84,2.3,12.39,12.39,396.5,405],["Bárbaro",6,"Minotauro","Machado de batalha",88.4,93.7,6,88.4,0,93.7,6,21.58,21.58,446.1,470.1],["Bárbaro",7,"Minotauro","Montante",113.3,123.8,9.3,113.3,0,123.8,9.3,17.37,17.37,550.2,597.5],["Bárbaro",8,"Minotauro","Montante",122.4,133.5,9.1,122.4,0,133.5,9.1,26.42,26.42,609.5,659.6],["Bárbaro",9,"Minotauro","Montante",127.4,144,13,127.4,0,144,13,27.71,27.71,635,709.9],["Bárbaro",10,"Minotauro","Montante",135,152.4,12.9,141.3,4.7,159.5,18.1,29.75,29.75,673.8,784.1],["Bárbaro",11,"Trog","Montante",140,142.6,1.9,153.2,9.4,155.8,11.3,32.97,32.97,703.5,774.6],["Bárbaro",12,"Qareen","Montante",143.9,162.3,12.8,157.2,9.2,177.1,23.1,30.72,30.72,716.8,866.2],["Bárbaro",13,"Qareen","Montante",147.8,147.8,0,174.4,18,174.4,18,31.84,31.84,737.4,856.9],["Bárbaro",14,"Qareen","Montante",153.6,173.1,12.7,188.3,22.6,210.3,36.9,33.71,33.71,769.1,1024.1],["Bárbaro",15,"Qareen","Montante",158.8,178.9,12.7,194.4,22.4,217,36.6,40.58,41.4,806.9,1070.2],["Bárbaro",16,"Qareen","Montante",168.5,189.6,12.5,208.1,23.5,235.7,39.9,47.07,47.94,863.8,1167.9],["Bárbaro",17,"Qareen","Montante",173.9,195.5,12.4,214.3,23.2,242.5,39.4,48.69,56.61,891.7,1216.6],["Bárbaro",18,"Qareen","Montante",181.9,204.5,12.4,231.8,27.4,262,44,51.06,60,933.2,1311.4],["Bárbaro",19,"Qareen","Montante",181.9,204.5,12.4,231.8,27.4,262,44,56.87,66.17,945.3,1324.2],["Bárbaro",20,"Qareen","Montante",184.6,207.5,12.4,234.9,27.2,265.5,43.8,66.46,88.91,977.1,1386],["Bardo",1,"Osteon","Florete",8.2,8.2,0,8.2,0,8.2,0,4.28,4.28,62,62],["Bardo",2,"Osteon","Florete",12.5,14.5,16,14.5,16,14.5,16,5.92,5.92,126.3,152.7],["Bardo",3,"Osteon","Florete",18.7,20.7,10.7,20.7,10.7,20.7,10.7,6.68,6.68,177.8,204.2],["Bardo",4,"Osteon","Florete",21.4,21.4,0,21.4,0,21.4,0,8.43,8.75,218.6,219.5],["Bardo",5,"Osteon","Florete",31.5,31.5,0,31.5,0,31.5,0,9.23,9.6,271.2,272.3],["Bardo",6,"Humano","Florete",84.6,84.6,0,84.6,0,84.6,0,11.82,12.28,420.1,421.5],["Bardo",7,"Humano","Florete",126.2,131.3,4,131.3,4,131.3,4,14.26,14.26,575.8,610.9],["Bardo",8,"Anão","Florete",99.2,101.2,2,101.2,2,101.2,2,17.73,17.73,531.7,558.1],["Bardo",9,"Anão","Florete",150.6,152.6,1.3,152.6,1.3,152.6,1.3,18.81,19.23,700.6,728.2],["Bardo",10,"Anão","Florete",154,156,1.3,156,1.3,156,1.3,23.55,24.09,748.1,776.1],["Bardo",11,"Anão","Florete",168.2,173.7,3.3,173.7,3.3,173.7,3.3,24.87,25.47,800.4,838.4],["Bardo",12,"Anão","Florete",172.1,177.6,3.2,179.6,4.4,179.6,4.4,29.52,30.16,837.2,901.7],["Bardo",13,"Anão","Florete",169.3,176.8,4.4,178.8,5.6,178.8,5.6,36.2,38.28,867,962.3],["Bardo",14,"Anão","Florete",187.6,195.1,4,197.1,5.1,197.1,5.1,38.77,47.99,937.5,1054.2],["Bardo",15,"Anão","Florete",189.4,196.9,4,198.9,5,198.9,5,42.08,46.04,960.6,1061.5],["Bardo",16,"Anão","Florete",208.5,216,3.6,218,4.6,218,4.6,44.65,55.02,1033.1,1153.2],["Bardo",17,"Anão","Florete",212.1,219.6,3.5,225.6,6.4,225.6,6.4,46.47,57.03,1064.9,1238.4],["Bardo",18,"Anão","Florete",232,239.5,3.2,241.5,4.1,241.5,4.1,49.04,59.8,1139.8,1268.3],["Bardo",19,"Anão","Florete",232.3,239.8,3.2,241.8,4.1,241.8,4.1,52.83,75.75,1154.9,1319.9],["Bardo",20,"Anão","Florete",252.9,260.4,3,262.4,3.8,262.4,3.8,55.5,78.86,1232.1,1398.4],["Bucaneiro",1,"Osteon","Pistola",5.1,5.1,0,5.1,0,5.1,0,5.81,5.81,35.2,35.2],["Bucaneiro",2,"Osteon","Pistola",11.9,12.2,2.5,11.9,0,12.2,2.5,7.4,7.4,69.5,70.8],["Bucaneiro",3,"Osteon","Pistola",20.5,21,2.4,20.5,0,21,2.4,8.25,8.25,110.1,112.3],["Bucaneiro",4,"Qareen","Pistola",14,14,0,14,0,14,0,12.77,12.77,92.7,92.7],["Bucaneiro",5,"Qareen","Florete",17,17,0,17,0,17,0,14.09,14.09,113.2,113.2],["Bucaneiro",6,"Qareen","Florete",20,20,0,20,0,20,0,17.51,17.51,134,134],["Bucaneiro",7,"Qareen","Florete",23,23,0,23,0,23,0,21.74,21.74,156.4,156.4],["Bucaneiro",8,"Qareen","Florete",26,26,0,26,0,26,0,24.14,24.14,177.1,177.1],["Bucaneiro",9,"Qareen","Florete",29,29,0,29,0,29,0,25.78,25.78,196,196],["Bucaneiro",10,"Qareen","Florete",32,32,0,32,0,32,0,28.59,28.59,215.6,215.6],["Bucaneiro",11,"Qareen","Florete",35,35,0,35,0,35,0,30.73,30.73,233.8,233.8],["Bucaneiro",12,"Qareen","Florete",38,38,0,38,0,38,0,33.19,33.19,252.7,252.7],["Bucaneiro",13,"Qareen","Florete",41,41,0,41,0,41,0,34.91,34.91,270.2,270.2],["Bucaneiro",14,"Qareen","Florete",44,44,0,44,0,44,0,37.38,37.38,289.1,289.1],["Bucaneiro",15,"Qareen","Florete",47,47,0,47,0,47,0,40.6,41.19,309.5,310.7],["Bucaneiro",16,"Qareen","Florete",50,50,0,50,0,50,0,43.06,43.7,328.4,329.6],["Bucaneiro",17,"Qareen","Florete",53,53,0,53,0,53,0,44.78,52.45,345.8,361.1],["Bucaneiro",18,"Qareen","Florete",56,56,0,56,0,56,0,47.25,55.65,364.7,381.5],["Bucaneiro",19,"Qareen","Florete",59,59,0,59,0,59,0,48.97,57.45,382.1,399.1],["Bucaneiro",20,"Qareen","Florete",62,62,0,62,0,62,0,51.44,70.85,401,439.8],["Caçador",1,"Osteon","Arco longo",6.1,6.1,0,6.1,0,6.1,0,6.56,6.56,41,41],["Caçador",2,"Osteon","Arco longo",13.1,13.5,3.1,13.1,0,13.5,3.1,8.15,8.15,76.6,78.1],["Caçador",3,"Osteon","Arco longo",24.9,25.6,2.8,24.9,0,25.6,2.8,9,9,132,135],["Caçador",4,"Osteon","Azagaia",21.3,21.8,2.3,21.3,0,21.8,2.3,10.85,10.85,122.3,124.6],["Caçador",5,"Minotauro","Cimitarra",24.4,25,2.5,24.4,0,25,2.5,18.92,18.92,153.1,155.9],["Caçador",6,"Qareen","Cimitarra",20,20,0,20,0,20,0,16.64,16.64,135.8,135.8],["Caçador",7,"Qareen","Cimitarra",23,23,0,23,0,23,0,20.96,20.96,158.6,158.6],["Caçador",8,"Qareen","Cimitarra",26,26,0,26,0,26,0,23.18,23.18,179.2,179.2],["Caçador",9,"Qareen","Cimitarra",29,29,0,29,0,29,0,24.64,24.64,198,198],["Caçador",10,"Qareen","Cimitarra",32,32,0,32,0,32,0,26.86,26.86,218.4,218.4],["Caçador",11,"Qareen","Cimitarra",35,35,0,35,0,35,0,28.77,28.77,236.3,236.3],["Caçador",12,"Qareen","Cimitarra",38,38,0,38,0,38,0,31.51,31.51,256.1,256.1],["Caçador",13,"Qareen","Cimitarra",41,41,0,41,0,41,0,33.57,33.57,274.4,274.4],["Caçador",14,"Qareen","Cimitarra",44,44,0,44,0,44,0,35.9,35.9,293.3,293.3],["Caçador",15,"Qareen","Cimitarra",47,47,0,47,0,47,0,38.97,39.57,313.6,314.8],["Caçador",16,"Qareen","Cimitarra",50,50,0,50,0,50,0,41.3,41.92,332.5,333.8],["Caçador",17,"Qareen","Cimitarra",53,53,0,53,0,53,0,42.87,50.54,349.8,365.1],["Caçador",18,"Qareen","Cimitarra",56,56,0,56,0,56,0,45.19,53.6,368.7,385.5],["Caçador",19,"Qareen","Cimitarra",59,59,0,59,0,59,0,46.77,55.24,386,402.9],["Caçador",20,"Qareen","Cimitarra",62,62,0,62,0,62,0,49.09,68.51,404.9,443.8],["Cavaleiro",1,"Osteon","Alabarda",14.1,14.1,0,14.1,0,14.1,0,5.04,5.04,90.2,90.2],["Cavaleiro",2,"Osteon","Alabarda",17.3,17.7,2.3,17.3,0,17.7,2.3,13.84,13.84,225.9,226.4],["Cavaleiro",3,"Osteon","Alabarda",17.3,17.7,2.3,17.3,0,17.7,2.3,21.89,21.89,347.3,347.7],["Cavaleiro",4,"Osteon","Alabarda",17.7,18.2,2.8,17.7,0,18.2,2.8,25.5,25.5,402.4,402.8],["Cavaleiro",5,"Minotauro","Alabarda",19.6,20.1,2.6,19.6,0,20.1,2.6,28.84,28.84,455,455.5],["Cavaleiro",6,"Minotauro","Alabarda",20.1,22.1,10,20.1,0,22.1,10,29.56,29.56,479.9,481.9],["Cavaleiro",7,"Qareen","Alabarda",23,25.2,9.6,23,0,25.2,9.6,30.62,30.62,501.9,504.1],["Cavaleiro",8,"Qareen","Espada longa",26,26,0,26,0,26,0,33.48,33.48,548.3,548.3],["Cavaleiro",9,"Qareen","Alabarda",29,29,0,29,0,29,0,34.55,34.55,572.5,572.5],["Cavaleiro",10,"Qareen","Alabarda",32,32,0,32,0,32,0,36.73,36.73,612.7,612.7],["Cavaleiro",11,"Qareen","Espada longa",35,35,0,35,0,35,0,39.09,39.09,651.6,651.6],["Cavaleiro",12,"Qareen","Espada longa",38,38,0,38,0,38,0,48.34,48.34,793.9,793.9],["Cavaleiro",13,"Qareen","Espada longa",41,41,0,41,0,41,0,49.84,49.84,819.9,819.9],["Cavaleiro",14,"Qareen","Espada longa",44,44,0,44,0,44,0,52.09,52.09,857.3,857.3],["Cavaleiro",15,"Qareen","Espada longa",47,47,0,47,0,47,0,54.1,54.7,890.8,899.9],["Cavaleiro",16,"Qareen","Espada longa",50,50,0,50,0,50,0,56.35,56.99,928.2,937.8],["Cavaleiro",17,"Qareen","Espada longa",53,53,0,53,0,53,0,57.85,65.53,954.2,1069.4],["Cavaleiro",18,"Qareen","Espada longa",56,56,0,56,0,56,0,60.1,68.53,991.5,1118],["Cavaleiro",19,"Qareen","Espada longa",59,59,0,59,0,59,0,61.6,70.11,1017.6,1145.2],["Cavaleiro",20,"Qareen","Espada longa",62,62,0,62,0,62,0,63.86,83.37,1054.9,1347.6],["Clérigo",1,"Osteon","Maça",5,5,0,5,0,5,0,5.51,5.51,92.7,92.7],["Clérigo",2,"Osteon","Maça",6,8,33.3,8,33.3,8,33.3,7.18,7.18,490.4,499.8],["Clérigo",3,"Osteon","Maça",11,13,18.2,13,18.2,13,18.2,8.43,8.43,621.9,631.3],["Clérigo",4,"Osteon","Maça",12,12,0,12,0,12,0,9.96,10.34,800.2,802.1],["Clérigo",5,"Osteon","Maça",36.6,36.6,0,36.6,0,36.6,0,11.27,11.72,1079.2,1081.4],["Clérigo",6,"Anão","Maça",37.5,37.5,0,37.5,0,37.5,0,15.73,16.4,1192.9,1196.2],["Clérigo",7,"Anão","Maça",100,105.3,5.3,105.3,5.3,105.3,5.3,19.37,19.37,1401.1,1413.2],["Clérigo",8,"Anão","Maça",112.3,114.3,1.8,114.3,1.8,114.3,1.8,21.59,21.59,1481.8,1491.2],["Clérigo",9,"Anão","Maça",42.5,44.5,4.7,44.5,4.7,44.5,4.7,23.06,23.53,1556.5,1568.2],["Clérigo",10,"Anão","Maça",39.4,41.4,5.1,41.4,5.1,41.4,5.1,28.36,28.88,1624.6,1636.6],["Clérigo",11,"Anão","Maça",39.4,44.9,14,44.9,14,44.9,14,34.44,35.1,1762.5,1778],["Clérigo",12,"Anão","Maça",44.3,49.8,12.4,51.8,16.9,51.8,16.9,37.28,37.99,1826.7,1851.9],["Clérigo",13,"Anão","Maça",62.2,69.7,12.1,71.7,15.3,71.7,15.3,39.37,41.67,1959.1,2001.5],["Clérigo",14,"Anão","Maça",191.4,198.9,3.9,200.9,5,200.9,5,43.85,53.31,2115.3,2193.5],["Clérigo",15,"Anão","Maça",199.5,207,3.8,209,4.8,209,4.8,53.16,57.53,2275.9,2328.7],["Clérigo",16,"Anão","Maça",71.5,79,10.5,81,13.3,81,13.3,57.42,68.12,2225.2,2309.7],["Clérigo",17,"Anão","Maça",74.5,82,10.1,88,18.1,88,18.1,60.05,70.97,2349.4,2453.8],["Clérigo",18,"Anão","Maça",78.2,85.7,9.6,87.7,12.1,87.7,12.1,63.43,74.57,2399.7,2489.1],["Clérigo",19,"Anão","Maça",81.4,88.9,9.2,90.9,11.7,90.9,11.7,66.06,89.86,2523,2675.7],["Clérigo",20,"Anão","Maça",84.6,92.1,8.9,94.1,11.2,94.1,11.2,69.44,93.73,2572.9,2728],["Druida",1,"Osteon","Cimitarra",3.9,3.9,0,3.9,0,3.9,0,5.92,5.92,93.3,93.3],["Druida",2,"Osteon","Cimitarra",6,8,33.3,8,33.3,8,33.3,7.56,7.56,491.2,500.6],["Druida",3,"Osteon","Bordão",53.3,54.8,2.8,54.8,2.8,54.8,2.8,8.77,8.77,655.8,664.8],["Druida",4,"Osteon","Bordão",67.4,67.4,0,67.4,0,67.4,0,10.93,11.31,739.2,741.1],["Druida",5,"Osteon","Bordão",74.6,74.6,0,74.6,0,74.6,0,11.83,12.27,863.8,866],["Druida",6,"Anão","Bordão",99.7,99.7,0,99.7,0,99.7,0,14.82,15.48,1060.3,1063.7],["Druida",7,"Anão","Bordão",101.3,106.4,5,106.4,5,106.4,5,20.23,20.23,1090.3,1102.1],["Druida",8,"Anão","Bordão",112.4,114.2,1.6,114.2,1.6,114.2,1.6,24.95,24.95,1230.3,1239.6],["Druida",9,"Anão","Bordão",125.2,127.1,1.5,127.1,1.5,127.1,1.5,27.76,28.31,1284,1296.1],["Druida",10,"Anão","Bordão",71.4,73.4,2.8,73.4,2.8,73.4,2.8,35.13,35.73,1385.3,1397.8],["Druida",11,"Anão","Bordão",79.4,84.9,6.9,84.9,6.9,84.9,6.9,37.38,38.04,1432.4,1447.9],["Druida",12,"Anão","Cimitarra",80,82.4,3,84.4,5.5,84.4,5.5,43.61,44.33,1573.8,1596.4],["Druida",13,"Anão","Cimitarra",89.4,92.4,3.4,93.2,4.3,93.2,4.3,46.11,48.4,1623.2,1661.1],["Druida",14,"Anão","Cimitarra",134.2,141.7,5.6,143.7,7.1,143.7,7.1,49.77,59.22,1785.9,1864.2],["Druida",15,"Anão","Cimitarra",135.9,143.4,5.5,145.4,7,145.4,7,55.03,59.4,1841.9,1894.7],["Druida",16,"Anão","Cimitarra",148.2,155.7,5.1,157.7,6.4,157.7,6.4,58.42,69.12,1977.3,2061.8],["Druida",17,"Anão","Cimitarra",152.1,159.6,4.9,165.6,8.9,165.6,8.9,62.03,72.95,2026.8,2131.2],["Druida",18,"Anão","Cimitarra",165.1,172.6,4.5,174.6,5.8,174.6,5.8,65.46,76.6,2162.9,2252.3],["Druida",19,"Anão","Cimitarra",169.1,176.6,4.4,178.6,5.6,178.6,5.6,68.15,91.95,2207.9,2360.6],["Druida",20,"Anão","Cimitarra",182.5,190,4.1,192,5.2,192,5.2,71.58,95.87,2344.5,2499.6],["Guerreiro",1,"Osteon","Montante",17.3,17.3,0,17.3,0,17.3,0,4.79,4.79,87.8,87.8],["Guerreiro",2,"Osteon","Montante",25.3,25.9,2.4,25.3,0,25.9,2.4,6.59,6.59,127.8,130.6],["Guerreiro",3,"Osteon","Arco longo",31.8,32.6,2.5,31.8,0,32.6,2.5,9.51,9.51,163.4,167.1],["Guerreiro",4,"Minotauro","Montante",43.7,44.7,2.3,43.7,0,44.7,2.3,10.03,10.03,221,225.6],["Guerreiro",5,"Humano","Arco longo",105.4,107.7,2.2,105.4,0,107.7,2.2,13.7,13.7,504.2,514.4],["Guerreiro",6,"Humano","Arco longo",125.7,134.4,6.9,125.7,0,134.4,6.9,15.76,15.76,600.2,639.3],["Guerreiro",7,"Qareen","Arco longo",137.6,161.7,17.5,137.6,0,161.7,17.5,16.04,16.04,654.6,763],["Guerreiro",8,"Qareen","Arco longo",149.8,175.8,17.4,149.8,0,175.8,17.4,18.13,18.13,716.5,833.4],["Guerreiro",9,"Qareen","Arco longo",176.4,206.5,17.1,176.4,0,206.5,17.1,19.31,19.31,839,974.5],["Guerreiro",10,"Qareen","Arco longo",186.3,217.8,16.9,197,5.7,230.2,23.6,21.24,21.24,887.6,1085.4],["Guerreiro",11,"Qareen","Arco longo",192.8,196.1,1.7,215.1,11.6,218.6,13.4,22.42,22.42,920,1036],["Guerreiro",12,"Qareen","Arco longo",200,233.7,16.9,222.8,11.4,259.9,29.9,24.34,24.34,958.4,1228],["Guerreiro",13,"Qareen","Arco longo",222.1,222.1,0,261.9,17.9,261.9,17.9,33.06,33.06,1074.2,1253],["Guerreiro",14,"Qareen","Arco longo",225.7,263.2,16.6,278.6,23.4,321.9,42.6,39.77,39.77,1104,1536.8],["Guerreiro",15,"Qareen","Arco longo",232.8,271.3,16.5,286.9,23.2,331.4,42.4,46,46.74,1148.8,1593.9],["Guerreiro",16,"Qareen","Arco longo",236.3,275.4,16.5,344.5,45.8,407.1,72.3,51.64,52.43,1176.4,1946.6],["Guerreiro",17,"Qareen","Arco longo",261.1,303.9,16.4,373.1,42.9,440.2,68.6,57.4,65.23,1300.1,2121.5],["Guerreiro",18,"Qareen","Arco longo",264.9,308.3,16.4,393,48.4,463.2,74.9,62,70.76,1328.5,2238.2],["Guerreiro",19,"Qareen","Arco longo",269.5,313.5,16.3,399.2,48.1,470.4,74.5,54.36,62.87,1339.7,2261],["Guerreiro",20,"Qareen","Arco longo",273.3,317.9,16.3,404.4,48,476.5,74.4,57.66,77.17,1363.9,2317.2],["Inventor",1,"Osteon","Mosquete",7.1,7.1,0,7.1,0,7.1,0,4.6,4.6,41.9,41.9],["Inventor",2,"Osteon","Mosquete",16,16,0,16,0,16,0,6.01,6.01,93.1,93.1],["Inventor",3,"Osteon","Mosquete",20,20,0,20,0,20,0,6.67,6.67,117.6,117.6],["Inventor",4,"Qareen","Besta leve",34,34,0,34,0,34,0,8.02,8.02,186.2,186.2],["Inventor",5,"Qareen","Mosquete",37,37,0,37,0,37,0,8.79,8.79,205.7,205.7],["Inventor",6,"Qareen","Mosquete",40,40,0,40,0,40,0,12.37,12.37,227,227],["Inventor",7,"Qareen","Mosquete",43,43,0,43,0,43,0,16.66,16.66,249.7,249.7],["Inventor",8,"Qareen","Mosquete",46,46,0,46,0,46,0,20.47,20.47,271.5,271.5],["Inventor",9,"Qareen","Mosquete",49,49,0,49,0,49,0,23.69,23.69,292,292],["Inventor",10,"Qareen","Mosquete",52,52,0,52,0,52,0,26.01,26.01,312.7,312.7],["Inventor",11,"Qareen","Besta leve",55,55,0,55,0,55,0,29.33,29.33,333.2,333.2],["Inventor",12,"Qareen","Besta leve",58,58,0,58,0,58,0,31.8,31.8,354.2,354.2],["Inventor",13,"Qareen","Besta leve",61,61,0,61,0,61,0,34.03,34.03,372.8,372.8],["Inventor",14,"Qareen","Besta leve",64,64,0,64,0,64,0,37.07,37.07,393,393],["Inventor",15,"Qareen","Besta leve",67,67,0,67,0,67,0,40.36,40.94,413.7,414.9],["Inventor",16,"Qareen","Besta leve",70,70,0,70,0,70,0,42.9,43.52,432.9,434.2],["Inventor",17,"Qareen","Espada longa",73,73,0,73,0,73,0,43.19,50.85,447.6,462.9],["Inventor",18,"Qareen","Espada longa",76,76,0,76,0,76,0,47.11,55.49,471.2,488],["Inventor",19,"Qareen","Espada longa",79,79,0,79,0,79,0,48.97,57.42,489.1,506],["Inventor",20,"Qareen","Espada longa",82,82,0,82,0,82,0,51.58,70.91,508.4,547.1],["Ladino",1,"Osteon","Arco curto",9,9,0,9,0,9,0,5.43,5.43,52,52],["Ladino",2,"Osteon","Espada curta",16.7,17.2,3,16.7,0,17.2,3,6.86,6.86,90,92.3],["Ladino",3,"Osteon","Arco curto",39,40,2.6,39,0,40,2.6,7.54,7.54,192.4,197.1],["Ladino",4,"Osteon","Arco curto",47.8,49,2.5,47.8,0,49,2.5,9.43,9.43,238.7,244],["Ladino",5,"Osteon","Arco curto",64,65.6,2.5,64,0,65.6,2.5,10.14,10.14,313.9,320.8],["Ladino",6,"Humano","Arco curto",65.6,70.5,7.5,65.6,0,70.5,7.5,23.62,23.62,348.4,370.5],["Ladino",7,"Goblin","Espada curta",87,92.4,6.2,87,0,92.4,6.2,25.68,25.68,449.6,473.7],["Ladino",8,"Goblin","Espada curta",93.8,99.4,6,93.8,0,99.4,6,27.17,27.17,483.9,509],["Ladino",9,"Goblin","Espada curta",111.9,117.9,5.4,111.9,0,117.9,5.4,28.14,28.14,567.6,594.8],["Ladino",10,"Goblin","Espada curta",117.2,123.4,5.3,122.6,4.6,129.1,10.2,29.92,29.92,595.6,649.3],["Ladino",11,"Trog","Espada curta",146.1,149.2,2.1,158.4,8.4,161.7,10.7,30.99,30.99,730.2,800.3],["Ladino",12,"Trog","Espada curta",149.2,156.5,4.9,161.7,8.4,169.5,13.6,36.66,36.66,756.3,847.5],["Ladino",13,"Trog","Espada curta",170.4,170.4,0,194.2,14,194.2,14,38.35,38.35,855.8,962.7],["Ladino",14,"Trog","Espada curta",174,181.7,4.4,205.2,17.9,214.1,23,43.03,43.03,881.6,1062.1],["Ladino",15,"Trog","Espada curta",208,216.5,4.1,241.9,16.3,251.5,20.9,45.93,46.51,1041.1,1238.1],["Ladino",16,"Trog","Espada curta",219.6,228.4,4,268.9,22.4,290.4,32.2,48.07,48.69,1098.5,1418],["Ladino",17,"Trog","Espada curta",240.7,249.8,3.8,293,21.7,316,31.3,52.58,60.23,1202.9,1557],["Ladino",18,"Trog","Espada curta",245,254.2,3.8,306.5,25.1,330.3,34.8,54.86,63.24,1231.2,1632],["Ladino",19,"Trog","Espada curta",266.4,276,3.6,331.3,24.4,356.7,33.9,57.13,65.58,1332.7,1756.2],["Ladino",20,"Anão","Espada curta",260.5,269.8,3.6,324.8,24.7,349.8,34.3,66.57,87.21,1329.6,1772.6],["Lutador",1,"Osteon","Manopla",19.9,19.9,0,19.9,0,19.9,0,5.34,5.34,100.9,100.9],["Lutador",2,"Humano","Manopla",33.7,34.6,2.7,33.7,0,34.6,2.7,7.1,7.1,166.9,170.8],["Lutador",3,"Minotauro","Manopla",47.7,48.8,2.3,47.7,0,48.8,2.3,7.77,7.77,231.4,236.5],["Lutador",4,"Minotauro","Manopla",54.6,55.9,2.4,54.6,0,55.9,2.4,16.54,16.54,280.7,286.3],["Lutador",5,"Minotauro","Manopla",66.2,67.7,2.3,66.2,0,67.7,2.3,17.7,17.7,338.1,344.7],["Lutador",6,"Qareen","Manopla",83.7,89.9,7.4,83.7,0,89.9,7.4,17.98,17.98,417.6,445.6],["Lutador",7,"Qareen","Manopla",99.5,110.4,11,99.5,0,110.4,11,20.33,20.33,493.8,542.9],["Lutador",8,"Qareen","Manopla",114.2,125.6,10,114.2,0,125.6,10,21.93,21.93,563.8,614.9],["Lutador",9,"Qareen","Manopla",130.7,143.2,9.6,130.7,0,143.2,9.6,22.79,22.79,640.2,696.5],["Lutador",10,"Qareen","Manopla",64.9,64.9,0,64.9,0,64.9,0,34.27,34.27,374.8,374.8],["Lutador",11,"Qareen","Manopla",70.6,70.6,0,70.6,0,70.6,0,36.53,36.53,405.8,405.8],["Lutador",12,"Qareen","Manopla",78.5,78.5,0,78.5,0,78.5,0,39.02,39.02,446.6,446.6],["Lutador",13,"Qareen","Manopla",84.4,84.4,0,84.4,0,84.4,0,40.77,40.77,477.3,477.3],["Lutador",14,"Qareen","Manopla",92.8,92.8,0,92.8,0,96.3,3.8,43.26,43.26,520.4,536.4],["Lutador",15,"Qareen","Manopla",98.8,98.8,0,98.8,0,99.8,1,46.5,47.24,554.6,560.5],["Lutador",16,"Qareen","Manopla",107.8,107.8,0,107.8,0,107.8,0,48.99,49.78,600.4,602],["Lutador",17,"Qareen","Manopla",182.5,205.6,12.7,243.2,33.3,274.2,50.2,49.07,56.9,937.2,1365.4],["Lutador",18,"Qareen","Manopla",123.4,123.4,0,125.4,1.6,138,11.8,53.23,61.98,680.1,763.1],["Lutador",19,"Qareen","Manopla",130.9,145.4,11.1,181.4,38.6,199.6,52.5,54.97,63.82,717.4,1044.3],["Lutador",20,"Qareen","Manopla",139.7,139.7,0,139.7,0,140.1,0.3,57.46,78.24,762.8,806.2],["Nobre",1,"Osteon","Espada longa",4.1,4.1,0,4.1,0,4.1,0,4.73,4.73,32.9,32.9],["Nobre",2,"Osteon","Espada longa",12,12.3,2.5,12,0,12.3,2.5,6.56,6.56,72.3,73.9],["Nobre",3,"Osteon","Espada longa",14.7,15.1,2.7,14.7,0,15.1,2.7,7.88,7.88,90.2,92],["Nobre",4,"Qareen","Espada longa",18.6,19.1,2.7,18.6,0,19.1,2.7,9.54,9.54,111.8,114],["Nobre",5,"Qareen","Espada longa",17,17,0,17,0,17,0,12.93,12.93,132,132],["Nobre",6,"Qareen","Espada longa",20,20,0,20,0,20,0,15.2,15.2,159.9,159.9],["Nobre",7,"Qareen","Espada longa",23,23,0,23,0,23,0,18.41,18.41,184.3,184.3],["Nobre",8,"Qareen","Espada longa",26,26,0,26,0,26,0,25.3,25.3,208.4,208.4],["Nobre",9,"Qareen","Espada longa",29,29,0,29,0,29,0,29.07,29.07,234.1,234.1],["Nobre",10,"Qareen","Espada longa",32,32,0,32,0,32,0,32.08,32.08,258.2,258.2],["Nobre",11,"Qareen","Espada longa",35,35,0,35,0,35,0,35.33,35.33,280.4,280.4],["Nobre",12,"Qareen","Espada longa",38,38,0,38,0,38,0,39.5,39.5,302.9,302.9],["Nobre",13,"Qareen","Espada longa",41,41,0,41,0,41,0,41.92,41.92,327.9,327.9],["Nobre",14,"Qareen","Espada longa",44,44,0,44,0,44,0,45.09,45.09,350,350],["Nobre",15,"Qareen","Espada longa",47,47,0,47,0,47,0,49.01,49.67,372,373.3],["Nobre",16,"Qareen","Espada longa",50,50,0,50,0,50,0,52.17,52.88,392.4,393.8],["Nobre",17,"Qareen","Espada longa",53,53,0,53,0,53,0,54.59,62.34,415.5,431],["Nobre",18,"Qareen","Espada longa",56,56,0,56,0,56,0,57.76,66.33,436,453.1],["Nobre",19,"Qareen","Espada longa",59,59,0,59,0,59,0,60.18,68.83,455,472.3],["Nobre",20,"Qareen","Espada longa",62,62,0,62,0,62,0,63.35,83.4,475.4,515.5],["Paladino",1,"Osteon","Montante",22.1,22.1,0,22.1,0,22.1,0,4.44,4.44,109.5,109.5],["Paladino",2,"Osteon","Montante",30.8,31.5,2.3,30.8,0,31.5,2.3,6.09,6.09,152.3,155.5],["Paladino",3,"Osteon","Montante",38.9,39.8,2.3,38.9,0,39.8,2.3,6.98,6.98,191.2,195.2],["Paladino",4,"Minotauro","Montante",48.1,49.2,2.3,48.1,0,49.2,2.3,9.22,9.22,239.7,244.4],["Paladino",5,"Minotauro","Montante",62.5,63.8,2.1,62.5,0,63.8,2.1,10.31,10.31,307,312.8],["Paladino",6,"Minotauro","Montante",71.4,74.5,4.3,71.4,0,74.5,4.3,12.16,12.16,351,365.1],["Paladino",7,"Minotauro","Montante",78.2,83.7,7,78.2,0,83.7,7,14.83,14.83,387.8,412.2],["Paladino",8,"Minotauro","Montante",82.9,88.5,6.8,82.9,0,88.5,6.8,16.73,16.73,413,438.5],["Paladino",9,"Medusa","Florete",107.4,114.3,6.4,107.4,0,114.3,6.4,18.46,18.46,527.4,558.4],["Paladino",10,"Medusa","Florete",111.7,118.8,6.4,117.2,4.9,124.6,11.5,20.57,20.57,551.6,609.4],["Paladino",11,"Medusa","Florete",114.3,116.5,1.9,125.5,9.8,127.8,11.8,21.61,21.61,567.5,627.9],["Paladino",12,"Medusa","Florete",116.5,123.8,6.3,127.8,9.7,135.7,16.5,28.09,28.09,590.7,677.1],["Paladino",13,"Medusa","Florete",130.8,130.8,0,154.1,17.8,154.1,17.8,29.49,29.49,664.3,769.2],["Paladino",14,"Trog","Florete",140,148.2,5.9,170.4,21.7,179.7,28.4,41.19,41.19,723.4,902.1],["Paladino",15,"Trog","Florete",145.2,153.5,5.7,176.3,21.4,185.9,28,44.21,44.95,759,943.7],["Paladino",16,"Trog","Florete",147.7,156.1,5.7,185.8,25.8,201.9,36.7,46.97,47.76,781.4,1026.5],["Paladino",17,"Trog","Florete",163.1,171.8,5.3,203.3,24.6,220.5,35.2,50.65,58.48,859.9,1134],["Paladino",18,"Trog","Florete",165.9,174.7,5.3,213.8,28.9,231.7,39.7,53.5,62.25,882.7,1196.3],["Paladino",19,"Anão","Florete",155.9,164.1,5.3,202.6,30,219.8,41,60.52,69.55,855.9,1161.3],["Paladino",20,"Anão","Florete",158.6,166.9,5.2,205.8,29.8,223.2,40.7,63.58,85.04,876.7,1210.1]];

/** Filtra o arsenal da ficha por camada (NENHUM | SUPERIOR | MAGICO | AMBOS) sem mutar o estado original. */
function filterArsenalByTier(estado, modoArsenal) {
    const modo = String(modoArsenal || 'NENHUM').toUpperCase();
    if (modo === 'NENHUM' || typeof calcularResumoArsenalSuperiorEMagicoJS !== 'function') return null;

    const stBase = Object.assign({}, estado, { configArsenalT20: null });
    const cfgAuto = (typeof autoOtimizarArsenalSuperiorEMagicoPorNivelJS === 'function')
        ? autoOtimizarArsenalSuperiorEMagicoPorNivelJS(stBase)
        : null;
    if (!cfgAuto) return null;

    const cfgFilt = JSON.parse(JSON.stringify(cfgAuto));
    cfgFilt._nivelCalculado = stBase.nivel || 6;

    if (modo === 'SUPERIOR') {
        cfgFilt.encantosArma = [];
        cfgFilt.encantosArmadura = [];
        cfgFilt.encantosEscudo = [];
        cfgFilt.acessoriosMagicos = [];
        cfgFilt.esotericoMagico = 'ESOMAG_NENHUM';
        // Armadura: remove encantos mágicos (ARM_MAG_*), mantendo apenas melhorias superiores
        if (String(cfgFilt.upgradeArmadura || '').startsWith('ARM_MAG_')) {
            cfgFilt.upgradeArmadura = 'ARM_SUP_REFORCADA_ADAMANTE';
        }
    } else if (modo === 'MAGICO') {
        cfgFilt.melhoriasArma = [];
        cfgFilt.materialArma = 'NENHUM';
        cfgFilt.melhoriasArmadura = [];
        cfgFilt.materialArmadura = '';
        cfgFilt.melhoriasEscudo = [];
        cfgFilt.materialEscudo = '';
        // Remove melhorias superiores de esotérico e catalisador alquímico não-mágico
        cfgFilt.upgradeEsoterico = 'ESO_NENHUM';
        cfgFilt.catalisador = 'CAT_NENHUM';
        if (String(cfgFilt.upgradeArmadura || '').startsWith('ARM_SUP_')) {
            cfgFilt.upgradeArmadura = 'ARM_NORMAL';
        }
    }
    stBase.configArsenalT20 = cfgFilt;
    return calcularResumoArsenalSuperiorEMagicoJS(stBase);
}

/** Compara DPR, EHP, bônus de combate e pontuação nos quatro cenários de equipamento. */
function compareEquipmentTiers(ficha) {
    const tiers = [
        { id: 'NENHUM', rotulo: 'Equipamento Comum (Base)', cls: 't20-tier-base' },
        { id: 'SUPERIOR', rotulo: 'Apenas Itens Superiores', cls: 't20-tier-sup' },
        { id: 'MAGICO', rotulo: 'Apenas Itens Mágicos', cls: 't20-tier-mag' },
        { id: 'AMBOS', rotulo: 'Superiores + Mágicos', cls: 't20-tier-both' }
    ];
    const resultados = tiers.map(t => {
        const met = avaliarBuildNumericaDescritoresV72JS(
            ficha.est, ficha.poderes || [], ficha.magias || [], ficha.arma || null,
            ficha.arquetipo || 'DPR Máximo (Dano)', ficha.nivel || 6, ficha.classe, ficha.escudo || null,
            null, t.id
        );
        return {
            modo: t.id,
            rotulo: t.rotulo,
            tierClass: t.cls,
            dpr: met.dpr,
            ehp: met.ehpTurnos,
            score: met.score,
            atqBonus: met.arsenalAtqBonus || 0,
            danoBonus: met.arsenalDanoBonus || 0,
            defBonus: met.arsenalDefBonus || 0
        };
    });
    const base = resultados[0];
    return resultados.map(r => {
        const deltaDpr = Number((r.dpr - base.dpr).toFixed(1));
        const deltaDprPct = base.dpr > 0 ? Number(((deltaDpr / base.dpr) * 100).toFixed(1)) : 0;
        const deltaEhpPct = base.ehp > 0 ? Number((((r.ehp - base.ehp) / base.ehp) * 100).toFixed(1)) : 0;
        return Object.assign({}, r, { deltaDpr, deltaDprPct, deltaEhpPct });
    });
}

/** Renderiza o quadro comparativo de equipamento da ficha atual usando classes editoriais. */
function renderEquipmentComparison(ficha) {
    if (!ficha) return '';
    const comp = compareEquipmentTiers(ficha);
    const rows = comp.map(r => `
        <tr>
            <td class="${r.tierClass}">${r.rotulo}</td>
            <td>+${r.atqBonus} / +${r.danoBonus}</td>
            <td>+${r.defBonus}</td>
            <td><strong>${r.dpr}</strong></td>
            <td class="${r.deltaDpr > 0 ? 't20-delta-pos' : 't20-delta-muted'}">${r.deltaDpr > 0 ? '+' + r.deltaDpr + ' (+' + r.deltaDprPct + '%)' : 'Base'}</td>
            <td>${r.ehp} <span class="t20-delta-muted">(${r.deltaEhpPct > 0 ? '+' + r.deltaEhpPct + '%' : 'Base'})</span></td>
            <td class="t20-score-col">${r.score}</td>
        </tr>`).join('');
    return `
        <section class="t20-panel">
            <div class="t20-panel-header">
                <h3 class="t20-panel-title">Comparativo de Equipamento por Camada — Nível ${ficha.nivel || 6}</h3>
            </div>
            <p class="t20-panel-subtitle">O otimizador base avalia apenas o personagem intrínseco. A tabela abaixo isola o ganho de melhorias superiores, encantos mágicos e ambos combinados.</p>
            <div class="t20-table-wrap">
                <table class="t20-data-table">
                    <thead>
                        <tr>
                            <th>Camada</th>
                            <th>Atq / Dano</th>
                            <th>Defesa</th>
                            <th>DPR</th>
                            <th>Variação DPR</th>
                            <th>EHP</th>
                            <th>Pontuação</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        </section>`;
}

function renderGlobalItemMatrixRows(filtroClasse, filtroNivel) {
    const fc = filtroClasse || 'TODAS';
    const fn = filtroNivel || 'TODOS';
    return EQUIPMENT_BENCHMARK_MATRIX
        .filter(r => (fc === 'TODAS' || r[0] === fc) && (fn === 'TODOS' || String(r[1]) === String(fn)))
        .map(r => `
            <tr>
                <td><strong>${r[0]}</strong></td>
                <td style="text-align:center;">${r[1]}</td>
                <td style="text-align:left;" class="t20-delta-muted">${r[2]} · ${r[3]}</td>
                <td>${r[4]}</td>
                <td class="t20-tier-sup">${r[5]} <span class="t20-delta-muted">(+${r[6]}%)</span></td>
                <td class="t20-tier-mag">${r[7]} <span class="t20-delta-muted">(+${r[8]}%)</span></td>
                <td class="t20-tier-both">${r[9]} (+${r[10]}%)</td>
                <td class="t20-delta-muted">${r[11]} → ${r[12]}</td>
                <td class="t20-score-col">${r[13]} → ${r[14]}</td>
            </tr>`).join('');
}

function updateGlobalItemMatrix() {
    const selC = document.getElementById('t20-matrix-class');
    const selN = document.getElementById('t20-matrix-level');
    const tbody = document.getElementById('t20-matrix-tbody');
    if (!tbody) return;
    tbody.innerHTML = renderGlobalItemMatrixRows(selC ? selC.value : 'TODAS', selN ? selN.value : '20');
}

function renderGlobalItemMatrix(ficha) {
    const nvAtual = (ficha && ficha.nivel) ? String(ficha.nivel) : '20';
    const classesUnicas = [...new Set(EQUIPMENT_BENCHMARK_MATRIX.map(r => r[0]))];
    const optsClasse = ['<option value="TODAS" selected>Todas as 14 Classes</option>']
        .concat(classesUnicas.map(c => `<option value="${c}">${c}</option>`)).join('');
    const optsNivel = ['<option value="TODOS">Todos os Níveis (1–20)</option>']
        .concat(Array.from({ length: 20 }, (_, i) => String(i + 1))
            .map(n => `<option value="${n}"${n === nvAtual ? ' selected' : ''}>Nível ${n}</option>`)).join('');
    return `
        <section class="t20-panel">
            <div class="t20-panel-header">
                <h3 class="t20-panel-title">Matriz de Referência — 14 Classes × Níveis 1 a 20</h3>
                <div class="t20-filter-bar">
                    <select id="t20-matrix-class" class="t20-select" onchange="T20Engine.updateGlobalItemMatrix()">${optsClasse}</select>
                    <select id="t20-matrix-level" class="t20-select" onchange="T20Engine.updateGlobalItemMatrix()">${optsNivel}</select>
                </div>
            </div>
            <p class="t20-panel-subtitle">Referência consolidada em 280 construções (1.120 avaliações). Filtre por classe para inspecionar a curva de progressão ou por nível para comparar todas as classes.</p>
            <div class="t20-table-wrap t20-table-scroll">
                <table class="t20-data-table">
                    <thead>
                        <tr>
                            <th>Classe</th>
                            <th style="text-align:center;">Nv</th>
                            <th style="text-align:left;">Raça · Arma</th>
                            <th>Base</th>
                            <th>Superiores</th>
                            <th>Mágicos</th>
                            <th>Combinados</th>
                            <th>EHP</th>
                            <th>Pontuação</th>
                        </tr>
                    </thead>
                    <tbody id="t20-matrix-tbody">${renderGlobalItemMatrixRows('TODAS', nvAtual)}</tbody>
                </table>
            </div>
        </section>`;
}

function runCombinatorialCalculator() {
    const cls = (document.getElementById('t20-calc-class') || {}).value || 'Guerreiro';
    const raca = (document.getElementById('t20-calc-race') || {}).value || 'Humano';
    const orig = (document.getElementById('t20-calc-origin') || {}).value || 'AUTO';
    const deus = (document.getElementById('t20-calc-deity') || {}).value || 'AUTO';
    const nv = parseInt((document.getElementById('t20-calc-level') || {}).value || '20', 10);
    const out = document.getElementById('t20-calc-result');
    if (!out) return;
    try {
        const fd = new FormData();
        fd.set('nome', `${cls} ${raca} Nv${nv}`);
        fd.set('nivel', String(nv));
        fd.set('arquetipo', 'Qualquer');
        fd.set('tipo_personagem', 'TODOS');
        fd.set('funcao_tatica', 'DPS Sustentado');
        fd.set('iteracoes', '30');
        fd.set('fixar_classe', cls);
        fd.set('fixar_raca', raca);
        fd.set('fixar_origem', orig);
        fd.set('fixar_deus', deus);
        fd.set('modo_multiclasse', 'NAO');
        fd.set('_v74_global_sub', '1');
        fd.set('_v74_silent', '1');
        const fichaCombo = executarOtimizadorIAMobileOffline(fd, '__SILENCIOSO_RL__');
        const comp = compareEquipmentTiers(fichaCombo);
        const origEfetiva = fichaCombo.origem ? fichaCombo.origem.nome : 'Sem Origem';
        const deusEfetivo = fichaCombo.deus ? fichaCombo.deus.nome : 'Sem Devoção';
        const armaEfetiva = fichaCombo.arma ? fichaCombo.arma.nome : '-';
        const rows = comp.map(r => `
            <tr>
                <td class="${r.tierClass}">${r.rotulo}</td>
                <td>+${r.atqBonus} / +${r.danoBonus}</td>
                <td>+${r.defBonus}</td>
                <td><strong>${r.dpr}</strong></td>
                <td class="${r.deltaDpr > 0 ? 't20-delta-pos' : 't20-delta-muted'}">${r.deltaDpr > 0 ? '+' + r.deltaDpr + ' (+' + r.deltaDprPct + '%)' : 'Base'}</td>
                <td>${r.ehp}</td>
                <td class="t20-score-col">${r.score}</td>
            </tr>`).join('');
        out.innerHTML = `
            <div class="t20-meta-line">
                <strong>${fichaCombo.classe.nome} · ${fichaCombo.raca.nome}</strong> (Nível ${nv}) — Origem: <strong>${origEfetiva}</strong> · Divindade: <strong>${deusEfetivo}</strong> · Arma: <strong>${armaEfetiva}</strong>
            </div>
            <div class="t20-table-wrap">
                <table class="t20-data-table">
                    <thead><tr><th>Camada</th><th>Atq / Dano</th><th>Defesa</th><th>DPR</th><th>Variação DPR</th><th>EHP</th><th>Pontuação</th></tr></thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>`;
    } catch (e) {
        out.innerHTML = `<div class="t20-meta-line" style="color:#E08A8A;">Não foi possível calcular esta combinação: ${e.message}</div>`;
    }
}

function renderCombinatorialCalculator() {
    const clsOpts = (CATALOGO_T20.classes || []).map(c => `<option value="${c.nome}">${c.nome}</option>`).join('');
    const racaOpts = (CATALOGO_T20.racas || []).map(r => `<option value="${r.nome}">${r.nome}</option>`).join('');
    const origOpts = '<option value="AUTO">Origem: Automática</option>' + (CATALOGO_T20.origens || []).map(o => `<option value="${o.nome}">${o.nome}</option>`).join('');
    const deusOpts = '<option value="AUTO">Divindade: Automática</option><option value="Sem Devoção">Sem Devoção</option>' + (CATALOGO_T20.deuses || []).map(d => `<option value="${d.nome}">${d.nome}</option>`).join('');
    const nvOpts = Array.from({ length: 20 }, (_, i) => `<option value="${i + 1}"${i + 1 === 20 ? ' selected' : ''}>Nível ${i + 1}</option>`).join('');
    return `
        <section class="t20-panel">
            <div class="t20-panel-header">
                <h3 class="t20-panel-title">Simulador Combinatório de Equipamentos</h3>
            </div>
            <p class="t20-panel-subtitle">Combine qualquer classe, raça, origem, divindade e nível para avaliar em tempo real o impacto isolado das quatro camadas de equipamento com validação de regras.</p>
            <div class="t20-calc-grid">
                <select id="t20-calc-class" class="t20-select" aria-label="Classe">${clsOpts}</select>
                <select id="t20-calc-race" class="t20-select" aria-label="Raça">${racaOpts}</select>
                <select id="t20-calc-origin" class="t20-select" aria-label="Origem">${origOpts}</select>
                <select id="t20-calc-deity" class="t20-select" aria-label="Divindade">${deusOpts}</select>
                <select id="t20-calc-level" class="t20-select" aria-label="Nível">${nvOpts}</select>
                <button type="button" class="t20-btn-primary" onclick="T20Engine.runCombinatorialCalculator()">Calcular Camadas</button>
            </div>
            <div id="t20-calc-result"></div>
        </section>`;
}

// Namespace público limpo (v93+)
window.T20Engine = Object.assign(window.T20Engine || {}, {
    filterArsenalByTier,
    compareEquipmentTiers,
    renderEquipmentComparison,
    renderGlobalItemMatrix,
    updateGlobalItemMatrix,
    runCombinatorialCalculator,
    renderCombinatorialCalculator,
    renderMovementTab: function() {
        if (typeof renderizarAbaMovimentoV88JS === 'function') return renderizarAbaMovimentoV88JS();
    }
});

// Aliases de retrocompatibilidade para chamadores internos
window.calcularResumoArsenalFiltradoV90JS = filterArsenalByTier;
window.compararImpactoItensV90JS = compareEquipmentTiers;
window.renderizarComparativoItensV90HTML = renderEquipmentComparison;
window.BENCHMARK_ITENS_14C_20N_V91 = EQUIPMENT_BENCHMARK_MATRIX;
window.atualizarTabelaMatrizItensV91JS = updateGlobalItemMatrix;
window.renderizarSecaoMatrizCompletaV91HTML = renderGlobalItemMatrix;
window.executarCalculadorCombinatorioItensV92JS = runCombinatorialCalculator;
window.renderizarCalculadorCombinatorioV92HTML = renderCombinatorialCalculator;







window.obterRamosCompetitivosPorClasseV73JS = obterRamosCompetitivosPorClasseV73JS;
window.competirRamosAtributoEEstiloNaRaizV73JS = competirRamosAtributoEEstiloNaRaizV73JS;


// ======================================================================================
// BUSCA COMBINATÓRIA GLOBAL SEM CAMINHOS PRÉ-DEFINIDOS
// Compete TODAS as 14 Classes, TODAS as 17 Raças, TODAS as Origens e TODAS as 20 Divindades!
// ======================================================================================

function obterRamosTodasAs14ClassesV74JS(classeNome) {
    const base = (typeof obterRamosCompetitivosPorClasseV73JS === 'function') ? obterRamosCompetitivosPorClasseV73JS(classeNome) : [];
    if (base && base.length > 0) return base;
    const cl = String(classeNome || '').toLowerCase();
    if (cl === 'bárbaro' || cl === 'barbaro') return [
        { id: 'FOR_2M_BRB', rotulo: 'FOR · Berserker Duas Mãos (Montante)', arq: 'Dano Marcial', arma: 'Montante', atrBase: { FOR: 4, DES: 0, CON: 3, INT: -1, SAB: 0, CAR: 0 }, livres: ['FOR', 'CON', 'DES'] },
        { id: 'FOR_2A_BRB', rotulo: 'FOR · Fúria Duas Armas (Machado de batalha)', arq: 'Marcial: Duas Armas', arma: 'Machado de batalha', atrBase: { FOR: 4, DES: 2, CON: 2, INT: -1, SAB: 0, CAR: 0 }, livres: ['FOR', 'DES', 'CON'] }
    ];
    if (cl === 'cavaleiro') return [
        { id: 'FOR_CON_CAV', rotulo: 'FOR+CON · Baluarte Arma & Escudo', arq: 'Tanque: Arma e Escudo', arma: 'Espada longa', atrBase: { FOR: 2, DES: -1, CON: 4, INT: 0, SAB: 0, CAR: 2 }, livres: ['CON', 'FOR', 'CAR'] },
        { id: 'FOR_2M_CAV', rotulo: 'FOR · Cavaleiro de Carga (Alabarda)', arq: 'Marcial: Armas de Haste', arma: 'Alabarda', atrBase: { FOR: 4, DES: -1, CON: 3, INT: 0, SAB: 0, CAR: 0 }, livres: ['FOR', 'CON', 'CAR'] }
    ];
    if (cl === 'nobre') return [
        { id: 'CAR_SUP_NOB', rotulo: 'CAR · Comandante & Suporte de Grupo', arq: 'Suporte Divino', arma: 'Espada longa', atrBase: { FOR: 0, DES: -1, CON: 2, INT: 2, SAB: 0, CAR: 4 }, livres: ['CAR', 'CON', 'INT'] },
        { id: 'CAR_TANQ_NOB', rotulo: 'CAR · Nobre Tanque (Autoconfiança + Escudo)', arq: 'Tanque: Arma e Escudo', arma: 'Espada longa', atrBase: { FOR: 0, DES: -1, CON: 3, INT: 0, SAB: 0, CAR: 4 }, livres: ['CAR', 'CON', 'FOR'] }
    ];
    return [{ id: 'PADRAO', rotulo: `${classeNome} · Padrão`, arq: 'Dano Marcial', arma: 'Espada longa', atrBase: { FOR: 3, DES: 2, CON: 2, INT: 1, SAB: 1, CAR: 1 }, livres: ['FOR', 'CON', 'DES'] }];
}

function avaliarMelhorRacaNumericaV74JS(classeObj, ramo, nivel, arquetipo) {
    const racas = CATALOGO_T20.racas || [];
    const clsL = (classeObj.nome || '').toLowerCase();
    const isConjurador = ['arcanista', 'bardo', 'clérigo', 'druida'].includes(clsL);
    const isDesBranch = (ramo.livres && ramo.livres[0] === 'DES') || String(ramo.chave || '').toUpperCase().includes('DES');
    const circRef = isConjurador ? Math.min(5, Math.max(1, Math.floor((nivel + 3) / 4))) : 0;

    // Poder representativo de Origem real (para que Golem pague o custo real de Sem Origem sem constante mágica!)
    const poderOrigemRef = isConjurador
        ? { nome: 'Vontade de Ferro', efeito_resumo: '+1 PM a cada 2 níveis e +2 Vontade' }
        : { nome: 'Foco em Arma', efeito_resumo: '+2 em testes de ataque' };

    const evalR = racas.map(r => {
        const nr = (r.nome || '').toLowerCase();
        const atrR = {
            FOR: (ramo.atrBase.FOR || 0) + Number(r.mod_for || 0),
            DES: (ramo.atrBase.DES || 0) + Number(r.mod_des || 0),
            CON: (ramo.atrBase.CON || 0) + Number(r.mod_con || 0),
            INT: (ramo.atrBase.INT || 0) + Number(r.mod_int || 0),
            SAB: (ramo.atrBase.SAB || 0) + Number(r.mod_sab || 0),
            CAR: (ramo.atrBase.CAR || 0) + Number(r.mod_car || 0)
        };
        const qtdLivres = Number(r.mod_livre || 0);
        if (qtdLivres > 0) {
            const proibido = nr === 'osteon' ? 'CON' : (nr === 'lefou' ? 'CAR' : '');
            const candidatosLiv = [...(ramo.livres || ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR']), 'FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR']
                .filter((v, i, a) => a.indexOf(v) === i && v !== proibido);
            candidatosLiv.slice(0, qtdLivres).forEach(sig => { atrR[sig] = (atrR[sig] || 0) + 1; });
        }

        let pvEst = (classeObj.pv_inicial || 16) + (nivel - 1) * (classeObj.pv_por_nivel || 4) + nivel * (atrR.CON || 0);
        let pmEst = nivel * (classeObj.pm_por_nivel || 3);
        let defEst = 12 + Math.max(0, atrR.DES || 0);
        const podsR = [];
        if (isDesBranch) podsR.push({ nome: 'Acuidade com Arma', efeito_resumo: 'Usa DES em ataque e dano com armas leves/ágeis' });

        // Benefício real de Origem (todas as raças EXCETO Golem recebem 1 poder de Origem; Humano recebe +1 poder extra por Versátil!)
        if (nr !== 'golem') podsR.push(poderOrigemRef);
        if (nr === 'humano') podsR.push({ nome: 'Aumento de Atributo', efeito_resumo: '+1 em atributo-chave (Versátil)' });

        // Habilidades raciais oficiais do catálogo T20 JdA (sem ajusteTaticoRaca arbitrário!)
        if (nr === 'anão') pvEst += 3 + nivel;
        if (nr === 'elfo') pmEst += nivel;
        if (nr === 'minotauro') { defEst += 1; podsR.push({ nome: 'Chifres', efeito_resumo: 'Ataque extra 1d6+FOR por 1 PM' }); }
        if (nr === 'osteon') {
            podsR.push({ nome: 'Armadura Óssea', efeito_resumo: 'RD 5 corte/frio/perfuração' });
            pvEst = Math.max(8, pvEst - Math.round(nivel * 0.9)); // Natureza Esquelética (sem cura positiva)
        }
        if (nr === 'golem') {
            pvEst = Math.max(10, pvEst - Math.round(nivel * 0.7)); // Constructo (sem cura comum)
        }
        if (nr === 'qareen') pmEst += Math.max(1, Math.floor(nivel * 0.35)); // Desejos (-1 PM situacional 50% quando pedido por aliado)
        if (nr === 'lefou') podsR.push({ nome: 'Foco em Arma', efeito_resumo: '+1 ataque (Poder da Tormenta)' });
        if (nr === 'trog') { defEst += 1; podsR.push({ nome: 'Mordida', efeito_resumo: 'Ataque extra 1d6+FOR por 1 PM' }); }
        if (nr === 'dahllan') defEst += 2; // Armadura de Allihanna

        // Grimório dinâmico real para conjuradores (e Qareen Tatuagem Mística)
        const magiasRef = (isConjurador || nr === 'qareen')
            ? buscarMelhorGrimorioDinamicoV80JS(classeObj, r, nivel, circRef, arquetipo, atrR, podsR, [], ramo.caminho || 'Mago').magias.slice(0, 3)
            : [];

        const armaObj = (CATALOGO_T20.itens || []).find(i => i.nome.toLowerCase() === String(ramo.arma || '').toLowerCase()) || null;
        const met = avaliarBuildNumericaDescritoresV72JS({ finais: atrR, pvMax: Math.max(10, pvEst), pmMax: Math.max(3, pmEst), defesa: defEst }, podsR, magiasRef, armaObj, arquetipo, nivel, classeObj, null);

        // Fator de mobilidade derivado diretamente de r.deslocamento_m do catálogo (9m = neutro, 12m = +1.0, 6m = -1.0)
        const desl = Number(r.deslocamento_m || 9);
        const fatorMob = ((desl - 9) / 3) * 1.2;
        return { raca: r, score: Number((met.score + fatorMob).toFixed(2)), dpr: met.dpr, ehp: met.ehpTurnos };
    }).sort((a, b) => b.score - a.score);
    return evalR;
}

function executarBuscaGlobalSemAtalhosV74JS(formData, fnOtimizarBase, abaDestinoOpcional) {
    if (formData.get('_v74_global_sub') === '1' || formData.get('_v73_subramo') === '1') {
        return fnOtimizarBase(formData, abaDestinoOpcional);
    }

    const normAuto = (v) => {
        const s = String(v || '').trim();
        return (!s || s.toUpperCase() === 'AUTO' || s.toLowerCase() === 'qualquer') ? 'AUTO' : s;
    };
    const fixClasse = normAuto(formData.get('fixar_classe'));
    const fixRaca = normAuto(formData.get('fixar_raca'));
    const fixArma = normAuto(formData.get('fixar_arma'));
    const fixOrigem = normAuto(formData.get('fixar_origem'));
    const fixDeus = normAuto(formData.get('fixar_deus'));
    const nivel = Math.max(1, Math.min(20, parseInt(formData.get('nivel') || '6', 10)));
    const arquetipo = formData.get('arquetipo') || 'Qualquer';
    const tipoPers = (formData.get('tipo_personagem') || 'TODOS').toUpperCase();

    // 1. Enumerar TODAS as classes candidatas (respeitando filtro fixar_classe e tipo_personagem se definido)
    let classesCand = (CATALOGO_T20.classes || []);
    if (fixClasse !== 'AUTO') {
        const matchCls = classesCand.filter(c => c.nome.toLowerCase() === fixClasse.toLowerCase());
        if (matchCls.length > 0) classesCand = matchCls;
    } else if (tipoPers === 'MARCIAL' || arquetipo.toLowerCase().startsWith('marcial:')) {
        classesCand = classesCand.filter(c => ['guerreiro', 'bárbaro', 'caçador', 'ladino', 'bucaneiro', 'cavaleiro', 'lutador'].includes(c.nome.toLowerCase()));
    } else if (tipoPers === 'CONJURADOR') {
        classesCand = classesCand.filter(c => ['arcanista', 'clérigo', 'druida', 'bardo'].includes(c.nome.toLowerCase()));
    } else if (tipoPers === 'HIBRIDO') {
        classesCand = classesCand.filter(c => ['paladino', 'inventor', 'nobre', 'bardo', 'druida'].includes(c.nome.toLowerCase()));
    }
    if (classesCand.length === 0) classesCand = (CATALOGO_T20.classes || []);

    // 2. Pré-triagem numérica imparcial de TODAS as classes candidatas × ramos × 18 raças (sem renderizar DOM!)
    const preRanking = [];
    for (const cls of classesCand) {
        const ramos = (fixArma !== 'AUTO')
            ? [{ id: 'ARMA_FIXA', rotulo: `${cls.nome} · ${fixArma}`, arq: arquetipo, arma: fixArma, atrBase: { FOR: 3, DES: 3, CON: 2, INT: 2, SAB: 1, CAR: 1 }, livres: ['FOR', 'DES', 'CON'] }]
            : obterRamosTodasAs14ClassesV74JS(cls.nome);
        for (const r of ramos) {
            let evalRacas;
            if (fixRaca !== 'AUTO') {
                const rMatch = (CATALOGO_T20.racas || []).find(x => x.nome.toLowerCase() === fixRaca.toLowerCase()) || CATALOGO_T20.racas[0];
                evalRacas = [{ raca: rMatch, score: 0, dpr: 0, ehp: 0 }];
            } else {
                evalRacas = avaliarMelhorRacaNumericaV74JS(cls, r, nivel, arquetipo);
            }
            const topRaca = evalRacas[0].raca;
            const armaObj = (CATALOGO_T20.itens || []).find(i => i.nome.toLowerCase() === String(r.arma || '').toLowerCase()) || null;
            const pvEst = (cls.pv_inicial || 16) + (nivel - 1) * (cls.pv_por_nivel || 4) + nivel * Math.max(0, r.atrBase.CON || 0);
            const pmEst = nivel * (cls.pm_por_nivel || 3);
            const defEst = 12 + Math.max(0, r.atrBase.DES || 0);
            const metPre = avaliarBuildNumericaDescritoresV72JS({ finais: r.atrBase, pvMax: pvEst, pmMax: pmEst, defesa: defEst }, [], [], armaObj, arquetipo, nivel, cls, null);
            preRanking.push({ cls, ramo: r, topRaca, evalRacas, scorePre: metPre.score });
        }
    }
    preRanking.sort((a, b) => b.scorePre - a.scorePre);

    // 3. v85: Executa otimização completa SILENCIOSA (_v74_silent = '1') no melhor ramo de TODAS as classes elegíveis
    // (impede que a pré-triagem sem poderes/magias elimine Arcanista, Guerreiro, Bárbaro ou Cavaleiro antes do MCTS!)
    const topFinalistas = [];
    if (fixClasse !== 'AUTO') {
        const chavesVistas = new Set();
        for (const item of preRanking) {
            const chave = `${item.cls.nome}::${item.ramo.id}`;
            if (chavesVistas.has(chave)) continue;
            chavesVistas.add(chave);
            topFinalistas.push(item);
            if (topFinalistas.length >= 3) break;
        }
    } else {
        const classesIncluidas = new Set();
        for (const item of preRanking) {
            if (classesIncluidas.has(item.cls.nome)) continue;
            classesIncluidas.add(item.cls.nome);
            topFinalistas.push(item);
        }
    }

    const camposParaCopiar = [
        'nome', 'nivel', 'arquetipo', 'tipo_personagem', 'funcao_tatica',
        'fixar_deus', 'fixar_origem', 'fixar_classe_secundaria', 'nivel_classe_secundaria',
        'fixar_classe_terciaria', 'nivel_classe_terciaria', 'modo_multiclasse',
        'raca_anterior_osteon', 'caminho_arcanista', 'iteracoes'
    ];

    const resultadosFinais = [];
    for (const fin of topFinalistas) {
        const fdSub = new FormData();
        camposParaCopiar.forEach(k => {
            const v = formData.get(k);
            if (v !== null && v !== undefined && v !== '') fdSub.set(k, v);
        });
        fdSub.set('_v74_global_sub', '1');
        fdSub.set('_v73_subramo', '1');
        fdSub.set('_v74_silent', '1'); // NÃO renderiza DOM durante a competição!
        fdSub.set('fixar_classe', fin.cls.nome);
        fdSub.set('fixar_raca', fin.topRaca.nome);
        fdSub.set('fixar_arma', fin.ramo.arma);
        if (fixOrigem !== 'AUTO') fdSub.set('fixar_origem', fixOrigem);
        if (fixDeus !== 'AUTO') fdSub.set('fixar_deus', fixDeus);
        if (fin.ramo.caminho && !formData.get('caminho_arcanista')) fdSub.set('caminho_arcanista', fin.ramo.caminho);
        fdSub.set('_v73_atr_override', JSON.stringify(fin.ramo.atrBase));
        fdSub.set('_v73_livres_override', JSON.stringify(fin.ramo.livres));

        try {
            const res = fnOtimizarBase(fdSub, null);
            if (res && res.est) {
                const met = avaliarBuildNumericaDescritoresV72JS(res.est, res.poderes, res.magias, res.arma, arquetipo, res.nivel, res.classe, res.escudo);
                resultadosFinais.push({ fin, res, met });
            }
        } catch (errSub) {
            console.warn('Sub-ramo v75 ignorado:', fin.cls.nome, errSub);
        }
    }

    if (resultadosFinais.length === 0) {
        // Fallback seguro se algo inesperado ocorrer
        return fnOtimizarBase(formData, abaDestinoOpcional);
    }

    resultadosFinais.sort((a, b) => b.met.score - a.met.score);
    const camp = resultadosFinais[0];

    camp.res.rankingGlobalClassesV74 = resultadosFinais.map(x => ({
        classe: x.fin.cls.nome,
        raca: x.fin.topRaca.nome,
        ramo: x.fin.ramo.rotulo,
        origem: x.res.origem ? x.res.origem.nome : 'Sem Origem',
        deus: x.res.deus ? x.res.deus.nome : 'Nenhum',
        score: x.met.score,
        dpr: x.met.dpr,
        ehpTurnos: x.met.ehpTurnos,
        suporte: x.met.suporte
    }));
    camp.res.totalClassesAvaliadasV74 = classesCand.length;
    camp.res.totalRacasAvaliadasV74 = (CATALOGO_T20.racas || []).length;
    camp.res.totalOrigensAvaliadasV74 = (CATALOGO_T20.origens || []).length;
    camp.res.totalDeusesAvaliadosV74 = (CATALOGO_T20.deuses || []).length;

    if (Array.isArray(camp.res.passosArvore)) {
        if (camp.res.passosArvore[0] && fixClasse === 'AUTO') {
            camp.res.passosArvore[0].fase = `Busca Global v75 (${classesCand.length} Classes Avaliadas — Zero Atalhos)`;
            camp.res.passosArvore[0].alts = resultadosFinais.slice(1, 4).map(x => ({
                nome: `${x.fin.cls.nome} (${x.fin.topRaca.nome} · ${x.fin.ramo.rotulo})`,
                tipo: 'EXPLORADO_MCTS',
                visitas: 30,
                motivo: `Competição Global v75: Score ${x.met.score} (DPR ${x.met.dpr}, EHP ${x.met.ehpTurnos}t, Sup ${x.met.suporte}) vs Campeã ${camp.met.score}`
            }));
        }
        if (camp.res.passosArvore[1] && fixRaca === 'AUTO' && camp.fin.evalRacas && camp.fin.evalRacas.length > 1) {
            camp.res.passosArvore[1].fase = `Busca Global v75 (${camp.fin.evalRacas.length} Raças Avaliadas)`;
            camp.res.passosArvore[1].alts = camp.fin.evalRacas.slice(1, 4).map(r => ({
                nome: r.raca.nome,
                tipo: 'EXPLORADO_MCTS',
                visitas: 20,
                motivo: `Avaliação Global de Raças v75: Score ${r.score} (DPR ${r.dpr}, EHP ${r.ehp}t) vs Campeã ${camp.fin.evalRacas[0].score}`
            }));
        }
    }

    // 4. RENDERIZA APENAS UMA VEZ COM O CAMPEÃO #1 REAL!
    const abaDest = abaDestinoOpcional !== undefined ? abaDestinoOpcional : 'tab-ficha';
    if (typeof renderizarFichaEArvoreClientSide === 'function') {
        const resumoCamp = `Busca Global v75 concluída: ${camp.res.raca.nome} ${camp.res.classe.nome} Nv ${camp.res.nivel} (Score ${camp.met.score} · DPR ${camp.met.dpr} · EHP ${camp.met.ehpTurnos}t)`;
        renderizarFichaEArvoreClientSide(camp.res, abaDest, resumoCamp);
    }
    return camp.res;
}

window.obterRamosTodasAs14ClassesV74JS = obterRamosTodasAs14ClassesV74JS;
window.avaliarMelhorRacaNumericaV74JS = avaliarMelhorRacaNumericaV74JS;
window.executarBuscaGlobalSemAtalhosV74JS = executarBuscaGlobalSemAtalhosV74JS;

const __OPT_BASE_V72__ = executarOtimizadorIAMobileOffline;
executarOtimizadorIAMobileOffline = function(formData, abaDestinoOpcional) {
    return executarBuscaGlobalSemAtalhosV74JS(formData, __OPT_BASE_V72__, abaDestinoOpcional);
};
window.executarOtimizadorIAMobileOffline = executarOtimizadorIAMobileOffline;


// Classifica e exibe habilidades Sempre Ativas vs Frequentes vs Situacionais vs Extremamente Condicionais
function classificarCondicionalidadeHabilidadesFichaV78JS(poderes, deusObj) {
    const lista = [...(poderes || [])];
    if (deusObj && deusObj.poderes_concedidos) {
        const prim = String(deusObj.poderes_concedidos).split(/[,;/]+/)[0].trim();
        if (prim && !lista.some(p => (p.nome || '').toLowerCase() === prim.toLowerCase())) {
            lista.push({ nome: prim, efeito_resumo: deusObj.poderes_concedidos });
        }
    }
    const badgePorTier = {
        SEMPRE_ATIVO: 'Sempre Ativa (100%)',
        FREQUENTE: 'Frequente (80%)',
        SITUACIONAL: 'Situacional (45%)',
        EXTREMAMENTE_CONDICIONAL: 'Extremamente Condicional (15% geral · 100% nicho)'
    };
    return lista.map(p => {
        const d = compilarDescritorNumericoPoderJS(p);
        return {
            nome: d.nome,
            tier: d.condicionalidade,
            badge: badgePorTier[d.condicionalidade] || badgePorTier.SEMPRE_ATIVO,
            fatorGeralPct: Math.round((d.fator_aplicabilidade || 1.0) * 100),
            nicho: d.nicho_condicional || 'GERAL',
            motivo: d.motivo_condicional
        };
    });
}
window.classificarCondicionalidadeHabilidadesFichaV78JS = classificarCondicionalidadeHabilidadesFichaV78JS;
