
const CATALOGO_T20 = __CATALOGO_JSON_INLINE__;

function mostrarAba(idAba) {
    document.querySelectorAll('.tab-section').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));
    var alvo = document.getElementById(idAba);
    if (alvo) alvo.classList.add('active');
    document.querySelectorAll('[data-tab-target="' + idAba + '"]').forEach(b => b.classList.add('active'));
    var btn = document.getElementById('btn-' + idAba);
    if (btn) btn.classList.add('active');
    if (idAba === 'tab-movimento' && typeof renderizarAbaMovimentoV88JS === 'function') {
        renderizarAbaMovimentoV88JS();
    }
    if (idAba === 'tab-arena' && typeof inicializarArenaVisualSeNecessario === 'function') {
        try { inicializarArenaVisualSeNecessario(); } catch (e) { console.error(e); }
    }
    if (idAba === 'tab-mesa-online' && typeof inicializarAbaMesaOnlineUI === 'function') {
        try { inicializarAbaMesaOnlineUI(); } catch (e) { console.error(e); }
    }
    if (idAba === 'tab-ficha' && typeof atualizarRetratoFichaPrincipalJS === 'function') {
        try { atualizarRetratoFichaPrincipalJS(); } catch (e) { console.error(e); }
    }
    try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) { window.scrollTo(0, 0); }
}

function exibirMensagemStatus(msg) {
    var box = document.getElementById('status-banner-box');
    if (box) {
        box.style.display = 'block';
        box.innerHTML = '' + msg;
    }
}

function parseIntSeguro(v, padrao) {
    if (v === null || v === undefined) return padrao;
    const m = String(v).replace('+', '').match(/-?\d+/);
    return m ? parseInt(m[0], 10) : padrao;
}



const SEQUENCIA_PASSOS_JS = ['1d2', '1d3', '1d4', '1d6', '1d8', '1d10', '1d12', '3d6', '4d6', '4d8', '4d10', '4d12'];
const EQUIV_PASSOS_JS = { '2d4': '1d8', '2d6': '1d12', '2d8': '3d6' };

function avancarPassosDanoJS(danoStr, passos) {
    const s = (danoStr || '1d6').trim().toLowerCase();
    const m = s.match(/(\d+)d(\d+)/);
    if (!m) return { str: '1d6', q: 1, f: 6, media: 3.5 };
    const orig = `${m[1]}d${m[2]}`;
    if (!passos || passos <= 0) {
        const q0 = parseInt(m[1], 10), f0 = parseInt(m[2], 10);
        return { str: orig, q: q0, f: f0, media: q0 * ((f0 + 1) / 2) };
    }
    const norm = EQUIV_PASSOS_JS[orig] || orig;
    let idx = SEQUENCIA_PASSOS_JS.indexOf(norm);
    if (idx < 0) idx = 3;
    const nIdx = Math.max(0, Math.min(SEQUENCIA_PASSOS_JS.length - 1, idx + passos));
    const novo = SEQUENCIA_PASSOS_JS[nIdx];
    const m2 = novo.match(/(\d+)d(\d+)/);
    const q2 = m2 ? parseInt(m2[1], 10) : 1;
    const f2 = m2 ? parseInt(m2[2], 10) : 6;
    return { str: novo, q: q2, f: f2, media: q2 * ((f2 + 1) / 2) };
}

function extrairCriticoArmaJS(critStr) {
    const s = (critStr || '').trim().toLowerCase();
    if (!s || s === '—' || s === '-') return { margem: 20, mult: 2 };
    const mAmbos = s.match(/(\d+)\s*\/\s*x(\d+)/);
    if (mAmbos) return { margem: parseInt(mAmbos[1], 10), mult: parseInt(mAmbos[2], 10) };
    let margem = 20, mult = 2;
    const mMult = s.match(/x(\d+)/);
    if (mMult) mult = parseInt(mMult[1], 10);
    const mMarg = s.match(/^(\d+)$/);
    if (mMarg) margem = parseInt(mMarg[1], 10);
    return { margem: Math.max(1, Math.min(20, margem)), mult: Math.max(2, mult) };
}

function pontuarPoderConcedidoJS(nomePoder, classeObj, arquetipo) {
    const nl = (nomePoder || '').toLowerCase();
    const arq = (arquetipo || 'Dano Marcial').toLowerCase();
    const ehConj = ehConjuradorJS(classeObj, []);
    const ehTanque = /(tanque|escudo|defesa)/.test(arq);
    const ehSup = /(suporte|cura|clérigo|clerigo|druida)/.test(arq);
    if (nl.includes('armas da ambição')) return ehConj ? 40 : 95;
    if (nl.includes('sangue de ferro')) return ehConj ? 35 : 92;
    if (nl.includes('arma sagrada') || nl.includes('espada justiceira') || nl.includes('espada solar')) return ehConj ? 45 : 98;
    if (nl.includes('kiai divino') || nl.includes('tradição de lin-wu')) return ehConj ? 30 : 91;
    if (nl.includes('escamas dracônicas')) return ehTanque ? 94 : 75;
    if (nl.includes('bênção do mana')) return (ehConj || ehSup) ? 96 : 55;
    if (nl.includes('teurgista') || nl.includes('centelha') || nl.includes('escudo mágico')) return ehConj ? 90 : 35;
    if (nl.includes('coragem total') || nl.includes('imortalidade')) return ehTanque ? 88 : 70;
    return 65;
}

function filtrarArquetiposPorTipoFuncaoJS() {
    const selTipo = document.getElementById('sel-tipo-personagem');
    const selArq = document.getElementById('sel-arquetipo-ia');
    if (!selTipo || !selArq) return;
    const t = selTipo.value;
    Array.from(selArq.options).forEach(opt => {
        if (opt.value === 'Qualquer') { opt.style.display = ''; return; }
        const txt = opt.textContent.toUpperCase();
        if (t === 'TODOS') opt.style.display = '';
        else if (t === 'MARCIAL') opt.style.display = txt.includes('[MARCIAL]') ? '' : 'none';
        else if (t === 'CONJURADOR') opt.style.display = txt.includes('[CONJURADOR]') ? '' : 'none';
        else if (t === 'HIBRIDO') opt.style.display = (txt.includes('[HÍBRIDO]') || txt.includes('DUELISTA') || txt.includes('DUAS ARMAS') || txt.includes('BARDO')) ? '' : 'none';
    });
    const vis = Array.from(selArq.options).find(o => o.style.display !== 'none');
    if (vis) selArq.value = vis.value;
}

function obterAtributoChaveMagiaJS(classeObj, caminhoArcanista) {
    if (!classeObj) return { sigla: 'INT', desc: 'Inteligência (Padrão)' };
    const nc = (classeObj.nome || '').toLowerCase();
    const cam = (caminhoArcanista || 'Mago').toLowerCase();
    if (nc.includes('arcanista')) {
        if (cam.includes('feiticeiro')) return { sigla: 'CAR', desc: 'Carisma (Caminho do Feiticeiro — Linhagem Inata)' };
        if (cam.includes('bruxo')) return { sigla: 'INT', desc: 'Inteligência (Caminho do Bruxo — Foco Arcano)' };
        return { sigla: 'INT', desc: 'Inteligência (Caminho do Mago — Grimório)' };
    }
    if (nc.includes('bardo')) return { sigla: 'CAR', desc: 'Carisma (Magias de Bardo)' };
    if (nc.includes('clérigo') || nc.includes('clerigo')) return { sigla: 'SAB', desc: 'Sabedoria (Magias Divinas de Clérigo)' };
    if (nc.includes('druida')) return { sigla: 'SAB', desc: 'Sabedoria (Magias Divinas de Druida)' };
    if (nc.includes('paladino')) return { sigla: 'SAB', desc: 'Sabedoria (Orar) & Carisma (Abençoado)' };
    const prim = ((classeObj.atributo_principal || 'INT').split(' ')[0] || 'INT').toUpperCase();
    return { sigla: ['INT', 'SAB', 'CAR'].includes(prim) ? prim : 'INT', desc: prim + ' (Classe)' };
}


function obterInfoArmaNaturalJS(racaNome, memOsteon, poderes) {
    const rn = (racaNome || '').toLowerCase();
    const mo = (memOsteon || '').toLowerCase();
    const pods = poderes || [];
    const temPresas = pods.some(p => (p.nome || '').toLowerCase() === 'presas primordiais');
    const temDentes = pods.some(p => (p.nome || '').toLowerCase() === 'dentes afiados');
    if (rn === 'minotauro' || (rn === 'osteon' && mo.includes('minotauro'))) {
        return {
            icone: '',
            nomeCurto: 'Chifres',
            titulo: 'Arma Natural & Ataque Extra — Chifres (Minotauro, Livro p. 25)' + (temPresas ? ' + Presas Primordiais' : ''),
            dadoStr: temPresas ? '1d8' : '1d6',
            faces: temPresas ? 8 : 6,
            mediaDadoCrit: temPresas ? 4.725 : 3.675,
            pagina: 'Livro p. 25 / PDF p. 31'
        };
    }
    if (rn === 'trog' || (rn === 'osteon' && mo.includes('trog')) || temPresas || temDentes) {
        const ehTrog = rn === 'trog' || (rn === 'osteon' && mo.includes('trog'));
        return {
            icone: ehTrog ? '' : '',
            nomeCurto: 'Mordida',
            titulo: `${ehTrog ? '' : ''} Arma Natural & Ataque Extra — Mordida (${ehTrog ? 'Trog, Livro p. 31' : (temPresas ? 'Presas Primordiais, p. 134' : 'Dentes Afiados, p. 137')})` + (ehTrog && temPresas ? ' [+2 passos Presas Primordiais]' : ''),
            dadoStr: (ehTrog && temPresas) ? '1d10' : '1d6',
            faces: (ehTrog && temPresas) ? 10 : 6,
            mediaDadoCrit: (ehTrog && temPresas) ? 5.775 : 3.675,
            pagina: ehTrog ? 'Livro p. 31 / PDF p. 37' : 'Livro p. 134'
        };
    }
    return null;
}

function obterBeneficiosOrigemGolemOsteonJS(racaObj, origemObj, poderesAtuais, racaAnteriorOsteon, arquetipo, periciasAtuais, armaObj, escudoObj, classeObj) {
    const nr = racaObj ? (racaObj.nome || '').toLowerCase() : 'humano';
    const arq = (arquetipo || 'Dano Marcial').toLowerCase();
    const clsL = classeObj ? (classeObj.nome || '').toLowerCase() : '';
    const estiloArmaAt = (typeof identificarEstiloArmaJS === 'function' && armaObj) ? identificarEstiloArmaJS(armaObj, escudoObj, poderesAtuais) : 'DUAS_MAOS';
    const jaTemEstilo = (poderesAtuais || []).some(p => (p.nome || '').toLowerCase().startsWith('estilo de '));
    const armaEhDuasMaos = ['DUAS_MAOS', 'ARMA_LONGA_HASTE'].includes(estiloArmaAt) && !['lutador', 'ladino', 'inventor', 'nobre', 'bardo'].includes(clsL);

    let ordemPref = ['vitalidade', 'reflexos de combate', 'esquiva', 'vontade de ferro', 'sortudo'];
    if (clsL === 'lutador') {
        ordemPref = ['vitalidade', 'reflexos de combate', 'esquiva', 'vontade de ferro', 'sortudo'];
    } else if (clsL === 'ladino') {
        ordemPref = ['acuidade com arma', 'esquiva', 'reflexos de combate', 'sortudo', 'vitalidade'];
    } else if (clsL === 'inventor') {
        ordemPref = estiloArmaAt === 'ARQUERIA_DISPARO'
            ? ['estilo de disparo', 'disparo preciso', 'saque rápido', 'sortudo', 'vontade de ferro']
            : ['sortudo', 'vontade de ferro', 'vitalidade', 'esquiva', 'reflexos de combate'];
    } else if (clsL === 'nobre' || clsL === 'bardo' || arq.includes('arcano') || arq.includes('suporte') || arq.includes('divino')) {
        ordemPref = ['sortudo', 'vontade de ferro', 'vitalidade', 'esquiva', 'reflexos de combate'];
    } else if (escudoObj || arq.includes('tanque') || arq.includes('escudo') || arq.includes('defesa')) {
        ordemPref = ['estilo de arma e escudo', 'encouraçado', 'vitalidade', 'esquiva', 'bloqueio com escudo'];
    } else if (estiloArmaAt === 'ARQUERIA_DISPARO' || arq.includes('arqueiro') || arq.includes('disparo')) {
        ordemPref = ['estilo de disparo', 'disparo preciso', 'foco em arma', 'reflexos de combate', 'saque rápido'];
    } else if (estiloArmaAt === 'ARMA_LONGA_HASTE' || arq.includes('haste')) {
        ordemPref = ['estilo de arma longa', 'piqueiro', 'estilo de duas mãos', 'ataque poderoso', 'foco em arma'];
    } else if (estiloArmaAt === 'DUAS_ARMAS' || arq.includes('duas armas')) {
        ordemPref = ['estilo de duas armas', 'acuidade com arma', 'foco em arma', 'reflexos de combate', 'vitalidade'];
    } else if (estiloArmaAt === 'UMA_ARMA_ESGRIMA' || arq.includes('uma mão') || arq.includes('duelista')) {
        ordemPref = ['estilo de uma arma', 'ataque preciso', 'acuidade com arma', 'foco em arma', 'esquiva'];
    } else if (armaEhDuasMaos) {
        ordemPref = ['estilo de duas mãos', 'ataque poderoso', 'foco em arma', 'vitalidade', 'reflexos de combate', 'esquiva'];
    }
    if (jaTemEstilo) {
        ordemPref = ordemPref.filter(p => !p.startsWith('estilo de '));
        ordemPref.push('vitalidade', 'reflexos de combate', 'esquiva', 'vontade de ferro', 'sortudo');
    }

    if (nr === 'golem') {
        let cand = null;
        for (const nmP of ordemPref) {
            const achou = (CATALOGO_T20.poderes_gerais || []).find(p => p.nome.toLowerCase() === nmP);
            if (achou && !(poderesAtuais || []).some(x => x.nome.toLowerCase() === nmP)) { cand = achou; break; }
        }
        return {
            semOrigem: true,
            labelOrigem: 'Sem Origem (Golem: Propósito de Criação — p. 22)',
            periciaExtra: '',
            poderesExtras: cand ? [cand] : [],
            resumoRegra: `Sem Origem (Regra de Golem, p. 22) Propósito de Criação concedeu o Poder Geral Otimizado: '${cand ? cand.nome : 'Vitalidade'}'`
        };
    }
    // Regra Oficial T20 JdA (p. 27) — Osteon possui Memória Póstuma E escolhe uma Origem normalmente!
    let osteonMemPoderExtra = null;
    let osteonMemTag = '';
    if (nr === 'osteon') {
        const mem = racaAnteriorOsteon || 'Minotauro (Chifres & Couro Rígido)';
        osteonMemTag = ` + Memória Póstuma [${mem.split('(')[0].trim()}]`;
        if (mem.toLowerCase().includes('humano')) {
            for (const nmP of ordemPref) {
                const achou = (CATALOGO_T20.poderes_gerais || []).find(p => p.nome.toLowerCase() === nmP);
                if (achou && !(poderesAtuais || []).some(x => x.nome.toLowerCase() === nmP)) { osteonMemPoderExtra = achou; break; }
            }
        }
        if (!origemObj) {
            return {
                semOrigem: false,
                labelOrigem: `Osteon · Memória Póstuma [${mem.split('(')[0].trim()}] (p. 27)`,
                periciaExtra: '',
                poderesExtras: osteonMemPoderExtra ? [osteonMemPoderExtra] : [],
                resumoRegra: `Osteon (p. 27): Memória Póstuma (${mem}) + Armadura Óssea (RD 5) — pode selecionar qualquer Origem normalmente.`
            };
        }
    }
    if (!origemObj) {
        return { semOrigem: true, labelOrigem: 'Sem Origem', periciaExtra: '', poderesExtras: [], resumoRegra: 'Sem Origem selecionada.' };
    }
    const prioPer = ['Percepção', 'Iniciativa', 'Fortitude', 'Vontade', 'Reflexos', 'Atletismo', 'Acrobacia', 'Guerra', 'Misticismo', 'Religião', 'Cura', 'Intimidação', 'Furtividade', 'Pontaria', 'Luta'];
    const perList = (origemObj.pericias_disponiveis || '').split(/\/|,/i).map(s => s.split('(')[0].trim()).filter(s => s && !s.toLowerCase().includes('escolhida'));
    perList.sort((a, b) => (prioPer.indexOf(a) === -1 ? 99 : prioPer.indexOf(a)) - (prioPer.indexOf(b) === -1 ? 99 : prioPer.indexOf(b)));
    const perSetAt = new Set((periciasAtuais || []).map(x => x.toLowerCase()));
    let perExtra = perList.find(p => !perSetAt.has(p.toLowerCase())) || perList[0] || 'Percepção';
    if (perSetAt.has(perExtra.toLowerCase())) {
        const fb = prioPer.find(p => !perSetAt.has(p.toLowerCase()));
        if (fb) perExtra = fb;
    }

    const nomesPodOrig = (origemObj.poderes_disponiveis || '').split(/\/|,/i).map(s => s.trim()).filter(Boolean);
    let podOrig = null;
    nomesPodOrig.sort((a, b) => (a.toLowerCase().includes('poder de combate') ? -1 : 1));
    for (const np of nomesPodOrig) {
        if (np.toLowerCase().includes('poder de combate')) {
            for (const nmC of ordemPref) {
                const achouC = (CATALOGO_T20.poderes_gerais || []).find(p => p.nome.toLowerCase() === nmC);
                if (achouC && !(poderesAtuais || []).some(x => x.nome.toLowerCase() === achouC.nome.toLowerCase())) {
                    podOrig = achouC;
                    break;
                }
            }
            if (podOrig) break;
        }
        const achou = (CATALOGO_T20.poderes_gerais || []).find(p => p.nome.toLowerCase() === np.toLowerCase());
        if (achou && !(poderesAtuais || []).some(x => x.nome.toLowerCase() === achou.nome.toLowerCase())) {
            podOrig = achou;
            break;
        }
    }
    if (!podOrig) {
        podOrig = {
            id_poder: 'ORIG_' + origemObj.id_origem,
            categoria_ou_classe: `Origem (${origemObj.nome})`,
            nome: origemObj.poder_unico,
            pre_requisitos: `Origem ${origemObj.nome}`,
            custo_pm: 'Passivo/Variável',
            acao: 'Livre/Passivo',
            efeito_resumo: origemObj.efeito_poder_unico,
            eh_poder_classe: false
        };
    }
    return {
        semOrigem: false,
        labelOrigem: `${origemObj.nome} (${podOrig.nome})`,
        periciaExtra: perExtra,
        poderesExtras: [podOrig],
        resumoRegra: `Origem '${origemObj.nome}' (p. 88 — 2 Benefícios Otimizados): [1] Perícia '${perExtra}' + [2] Poder de Origem '${podOrig.nome}' (${podOrig.efeito_resumo})`
    };
}

function obterPoderesConcedidosDevocaoJS(deusObj, classeObj, arquetipo) {
    if (!deusObj) return { qtd: 0, regra: 'Sem Divindade (0 Poderes Concedidos)', poderes: [] };
    const nc = classeObj ? (classeObj.nome || '').toLowerCase() : '';
    const ehDevotoFiel = ['clérigo', 'clerigo', 'druida', 'paladino'].some(k => nc.includes(k));
    const qtd = ehDevotoFiel ? 2 : 1;
    const habNome = nc.includes('paladino') ? 'Devoto Fiel / Abençoado' : 'Devoto Fiel';
    const regra = ehDevotoFiel
        ? `${habNome} (${classeObj.nome} devoto de ${deusObj.nome}: recebe 2 Poderes Concedidos)`
        : `Devoto de ${deusObj.nome} (recebe 1 Poder Concedido)`;
    const nomes = (deusObj.poderes_concedidos || '').split(/\/|,|\s+e\s+/i).map(s => s.trim()).filter(Boolean);
    const lista = [];
    for (const nm of nomes) {
        let achou = (CATALOGO_T20.poderes_gerais || []).find(p => p.nome.toLowerCase() === nm.toLowerCase() || p.nome.toLowerCase().includes(nm.toLowerCase()));
        if (!achou) {
            achou = {
                id_poder: 'CONC_' + nm.slice(0, 5).toUpperCase(),
                categoria_ou_classe: 'Concedido',
                nome: nm,
                pre_requisitos: 'Devoto de ' + deusObj.nome,
                custo_pm: 'Passivo/Ativo',
                acao: 'Livre/Padrão',
                efeito_resumo: 'Poder Concedido por ' + deusObj.nome + ' (' + deusObj.titulo + ').',
                eh_poder_classe: false
            };
        }
        if (!lista.some(x => x.nome.toLowerCase() === achou.nome.toLowerCase())) lista.push(achou);
    }
    lista.sort((a, b) => pontuarPoderConcedidoJS(b.nome, classeObj, arquetipo || '') - pontuarPoderConcedidoJS(a.nome, classeObj, arquetipo || ''));
    return { qtd, regra, poderes: lista.slice(0, qtd) };
}

function obterAmeacaOficialJS(ndNivel, papel) {
    const ndStr = String(Math.max(1, Math.min(20, ndNivel || 1)));
    const pap = (papel || 'Solo').toLowerCase();
    const lista = CATALOGO_T20.ameacas || [];
    return lista.find(a => a.nd === ndStr && a.papel.toLowerCase() === pap)
        || lista.find(a => a.nd === ndStr && a.papel === 'Solo')
        || { patamar: 'Veterano', nd: ndStr, papel: 'Solo', bonus_ataque: 20, dano_medio: 56, defesa: 27, res_forte: 18, res_media: 12, res_fraca: 7, pv: 240, cd_efeito: 22 };
}

function deusPermite(deus, racaNome, classeNome) {
    if ((classeNome || '').toLowerCase().includes('druida')) {
        return ['allihanna', 'megalokk', 'oceano'].includes((deus.nome || '').toLowerCase());
    }
    if ((classeNome || '').toLowerCase().includes('paladino')) {
        // Regra Oficial Tormenta20 Edição Jogo do Ano (Cap. 1, p. 81): Paladinos só podem ser devotos destas 8 divindades!
        return ['azgher', 'khalmyr', 'lena', 'lin-wu', 'marah', 'tanna-toh', 'thyatis', 'valkaria'].includes((deus.nome || '').trim().toLowerCase());
    }
    if ((classeNome || '').toLowerCase().includes('clérigo') || (classeNome || '').toLowerCase().includes('clerigo')) {
        return true;
    }
    const perm = (deus.devotos_permitidos || '').toLowerCase();
    if (perm.includes('quaisquer') || perm.includes('todas') || perm.includes('todos')) return true;
    const rRad = (racaNome || '').toLowerCase().slice(0, 4);
    const cRad = (classeNome || '').toLowerCase().slice(0, 5);
    return (rRad && perm.includes(rRad)) || (cRad && perm.includes(cRad));
}


// ==============================================================================
// MOTOR DE MULTICLASSE OFICIAL — TORMENTA20 EDIÇÃO JOGO DO ANO (CAP. 1, P. 34)
// ==============================================================================
function circuloPorClasseENivelJS(classeObj, nvClasse) {
    if (!classeObj || !nvClasse || nvClasse <= 0) return 0;
    const nc = (classeObj.nome || '').trim().toLowerCase();
    const hab = (classeObj.habilidades_fixas || '').toLowerCase();
    if (nc === 'druida' || nc === 'bardo' || hab.includes('4º círculo') || hab.includes('4o círculo')) {
        if (nvClasse >= 14) return 4;
        if (nvClasse >= 10) return 3;
        if (nvClasse >= 6) return 2;
        return 1;
    }
    if (nc === 'arcanista' || nc === 'clérigo' || nc === 'clerigo' || hab.includes('5º círculo') || hab.includes('5o círculo')) {
        return Math.min(5, 1 + Math.floor((nvClasse - 1) / 4));
    }
    return 0;
}

function normalizarClassesMulticlasseJS(cfgOuEstado) {
    if (!cfgOuEstado) return [];
    const clPrim = cfgOuEstado.classe || cfgOuEstado.classeObj;
    if (!clPrim) return [];
    const nvTotal = Math.max(1, Math.min(20, parseIntSeguro(cfgOuEstado.nivel, 1)));
    const clSec = cfgOuEstado.classeSecundaria || null;
    const clTerc = cfgOuEstado.classeTerciaria || null;
    let nvSec = (clSec && clSec.nome && clSec.nome.toLowerCase() !== clPrim.nome.toLowerCase())
        ? Math.max(0, parseIntSeguro(cfgOuEstado.nivelClasseSecundaria, 0))
        : 0;
    let nvTerc = (clTerc && clTerc.nome && clTerc.nome.toLowerCase() !== clPrim.nome.toLowerCase() && (!clSec || clTerc.nome.toLowerCase() !== clSec.nome.toLowerCase()))
        ? Math.max(0, parseIntSeguro(cfgOuEstado.nivelClasseTerciaria, 0))
        : 0;
    if (nvSec + nvTerc >= nvTotal) {
        const excesso = (nvSec + nvTerc) - (nvTotal - 1);
        if (nvTerc >= excesso) {
            nvTerc -= excesso;
        } else {
            const resto = excesso - nvTerc;
            nvTerc = 0;
            nvSec = Math.max(0, nvSec - resto);
        }
    }
    const nvPrim = Math.max(1, nvTotal - nvSec - nvTerc);
    const pares = [{ classeObj: clPrim, nivel: nvPrim, primaria: true }];
    if (clSec && nvSec > 0) pares.push({ classeObj: clSec, nivel: nvSec, primaria: false });
    if (clTerc && nvTerc > 0) pares.push({ classeObj: clTerc, nivel: nvTerc, primaria: false });
    return pares;
}

function nivelNaClasseJS(cfgOuEstado, nomeClasseAlvo) {
    const alvo = (nomeClasseAlvo || '').trim().toLowerCase();
    if (!alvo) return 0;
    const pares = normalizarClassesMulticlasseJS(cfgOuEstado || (typeof window !== 'undefined' ? window.__ULTIMO_ESTADO_FICHA__ : null));
    for (const p of pares) {
        if ((p.classeObj.nome || '').trim().toLowerCase() === alvo) return p.nivel;
    }
    return 0;
}

function resumoClassesMulticlasseJS(cfgOuEstado) {
    const pares = normalizarClassesMulticlasseJS(cfgOuEstado);
    if (!pares.length) return 'Sem Classe';
    if (pares.length === 1) {
        const c0 = pares[0].classeObj;
        const sufixoArc = (c0.nome || '').toLowerCase().includes('arcanista') ? ` (${cfgOuEstado.caminhoArcanista || 'Mago'})` : '';
        return `${c0.nome}${sufixoArc} Nv. ${pares[0].nivel}`;
    }
    return pares.map(p => {
        const sufixoArc = (p.classeObj.nome || '').toLowerCase().includes('arcanista') ? ` (${cfgOuEstado.caminhoArcanista || 'Mago'})` : '';
        return `${p.classeObj.nome}${sufixoArc} ${p.nivel}`;
    }).join(' / ') + ` (Nível ${cfgOuEstado.nivel})`;
}

function listarHabilidadesClasseMulticlasseJS(paresClasses, caminhoArcanista) {
    const habs = [];
    for (const item of (paresClasses || [])) {
        const cl = item.classeObj;
        const nv = item.nivel;
        const nc = (cl.nome || '').toLowerCase();
        const tagOrig = item.primaria ? `1ª Classe (${cl.nome} Nv. ${nv})` : `Multiclasse (${cl.nome} Nv. ${nv} — p. 34)`;
        if (nc === 'guerreiro') {
            const cAE = 1 + Math.floor((nv - 1) / 4);
            const bAE = 4 * cAE;
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Ataque Especial (${cAE} PM: +${bAE} Atq/Dano, p. 65)` });
            if (nv >= 3) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Durão (Reação, 3 PM: reduz dano à metade, p. 65)' });
            if (nv >= 6) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Ataque Extra (2 PM: +1 ataque ao Agredir, p. 65)' });
        } else if (nc === 'bárbaro') {
            const bFur = 2 + Math.floor((nv - 1) / 5);
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Fúria (2 PM: +${bFur} Ataque e +${bFur} Dano corpo a corpo, p. 40)` });
            if (nv >= 3) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Instinto Selvagem (+1 a +4 em Percepção e Reflexos, p. 40)' });
            if (nv >= 5) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Redução de Dano Passiva (RD ${2 * Math.floor((nv - 2) / 3)}, p. 41)` });
        } else if (nc === 'paladino') {
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Abençoado (+CAR nos PM no 1º nível & Devoto Fiel, p. 81)' });
            const dGD = 1 + Math.floor(nv / 4);
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Golpe Divino (2 PM: +CAR no Ataque e +${dGD}d8 no Dano, p. 81)` });
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Cura pelas Mãos (Movimento, 1 PM: cura 1d8+1 PV, p. 81)' });
            if (nv >= 3) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Aura Sagrada (Sustentada, 1 PM: +CAR em todas as Resistências, p. 81)' });
        } else if (nc === 'caçador') {
            const dMP = nv < 5 ? '1d4' : (nv < 13 ? '1d6' : '1d8');
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Marca da Presa (1 PM: +${dMP} nas rolagens de dano, p. 49)` });
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Rastreador (+2 em Sobrevivência, p. 49)' });
            if (nv >= 3) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Explorador (+2 em Percepção/Iniciativa/Sobrevivência, p. 49)' });
        } else if (nc === 'ladino') {
            const dFurt = Math.ceil(nv / 2);
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Ataque Furtivo (+${dFurt}d6 dano extra contra alvo Desprevenido/Flanqueado, p. 73)` });
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Especialista (1 PM: dobra bônus de treino em perícias escolhidas, p. 73)' });
            if (nv >= 2) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Evasão (0 dano em Reflexos bem-sucedido, p. 73)' });
        } else if (nc === 'cavaleiro') {
            const bBal = 2 * (1 + Math.floor((nv - 1) / 4));
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Baluarte (Reação, 1 PM: +${bBal} Defesa e Resistências, p. 56)` });
            if (nv >= 2) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Duelo (Livre, 2 PM: +${2 + Math.floor((nv - 2) / 5)} Ataque e Dano contra 1 oponente, p. 56)` });
        } else if (nc === 'bucaneiro') {
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Insolência (+CAR na Defesa limitada pelo nível de Bucaneiro, p. 50)' });
            if (nv >= 2) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Audácia (2 PM: soma +CAR em teste de perícia, p. 50) & Evasão' });
        } else if (nc === 'lutador') {
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Briga (Dano desarmado escalonado, p. 76) & Golpe Relâmpago (1 PM: +1 ataque desarmado)' });
            if (nv >= 2) habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Casca Grossa (+CON na Defesa sem armadura pesada, p. 76)' });
        } else if (nc === 'arcanista') {
            const circ = circuloPorClasseENivelJS(cl, nv);
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Caminho do Arcanista (${caminhoArcanista || 'Mago'}) & Magias Arcanas até ${circ}º Círculo (Limite ${nv} PM de classe, p. 36–37)` });
        } else if (nc === 'clérigo' || nc === 'clerigo') {
            const circ = circuloPorClasseENivelJS(cl, nv);
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Devoto Fiel (2 Poderes Concedidos) & Magias Divinas até ${circ}º Círculo (Limite ${nv} PM de classe, p. 58)` });
        } else if (nc === 'druida') {
            const circ = circuloPorClasseENivelJS(cl, nv);
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Devoto Fiel, Empatia Selvagem & Magias Divinas até ${circ}º Círculo (2º círculo no Nv. 6 de Druida, p. 61)` });
        } else if (nc === 'bardo') {
            const circ = circuloPorClasseENivelJS(cl, nv);
            const bInsp = 1 + Math.floor((nv - 1) / 4);
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: `Inspiração (2 PM: +${bInsp} em perícias na cena) & Magias até ${circ}º Círculo (2º círculo no Nv. 6 de Bardo, p. 44)` });
        } else if (nc === 'inventor') {
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Engenhosidade (2 PM: +INT em teste de perícia) & Protótipo (p. 68)' });
        } else if (nc === 'nobre') {
            habs.push({ classe: cl.nome, nivel: nv, tag: tagOrig, nome: 'Autoconfiança (+CAR na Defesa), Espólio & Orgulho (p. 78)' });
        }
    }
    return habs;
}

function circuloMaximoPermitido(classeObj, nivel, paresClassesOpt) {
    if (Array.isArray(paresClassesOpt) && paresClassesOpt.length > 0) {
        return Math.max(0, ...paresClassesOpt.map(p => circuloPorClasseENivelJS(p.classeObj, p.nivel)));
    }
    const stGlob = (typeof window !== 'undefined' && window.__ULTIMO_ESTADO_FICHA__) ? window.__ULTIMO_ESTADO_FICHA__ : null;
    if (stGlob && stGlob.classe && classeObj && stGlob.classe.nome === classeObj.nome && (stGlob.classeSecundaria || stGlob.classeTerciaria) && stGlob.nivel === nivel) {
        const paresG = normalizarClassesMulticlasseJS(stGlob);
        return Math.max(0, ...paresG.map(p => circuloPorClasseENivelJS(p.classeObj, p.nivel)));
    }
    return circuloPorClasseENivelJS(classeObj, nivel);
}


const PERICIAS_RADICAIS_JS = new Set([
    'acrobacia', 'adestramento', 'atletismo', 'atuação', 'cavalgar', 'conhecimento',
    'cura', 'diplomacia', 'enganação', 'fortitude', 'furtividade', 'guerra',
    'iniciativa', 'intimidação', 'intuição', 'investigação', 'jogatina', 'ladinagem',
    'luta', 'misticismo', 'nobreza', 'ofício', 'percepção', 'pilotagem',
    'pontaria', 'reflexos', 'religião', 'sobrevivência', 'vontade'
]);

function ehNomePericiaJS(txt) {
    const tl = (txt || '').trim().toLowerCase();
    return tl.startsWith('ofício') || PERICIAS_RADICAIS_JS.has(tl);
}

function naturezaPersonagemJS(classeObj) {
    if (!classeObj) return 'Marcial';
    const nc = classeObj.nome.toLowerCase();
    if (['arcanista', 'clérigo', 'druida'].includes(nc)) return 'Conjurador';
    if (['bardo', 'paladino', 'inventor'].includes(nc)) return 'Híbrido (Marcial & Conjurador)';
    return 'Marcial';
}

function ehConjuradorJS(classeObj, poderes) {
    if (!classeObj) return false;
    const hab = (classeObj.habilidades_fixas || '').toLowerCase();
    if (hab.includes('magias arcanas') || hab.includes('magias divinas')) return true;
    return (poderes || []).some(p => (p.efeito_resumo || '').toLowerCase().includes('lançar'));
}

function obterProficienciasAtivasJS(classeObj, racaObj, poderes) {
    const profs = ['Armas simples'];
    const nc = classeObj ? classeObj.nome.toLowerCase() : '';
    if (nc !== 'arcanista') profs.push('Armaduras leves');
    if (classeObj) {
        const ps = (classeObj.proficiencias || '').toLowerCase();
        if (ps.includes('armas marciais') && !profs.includes('Armas marciais')) profs.push('Armas marciais');
        if (ps.includes('armaduras pesadas') && !profs.includes('Armaduras pesadas')) profs.push('Armaduras pesadas');
        if (ps.includes('escudos') && !profs.includes('Escudos')) profs.push('Escudos');
    }
    if (racaObj && racaObj.nome.toLowerCase() === 'anão') {
        profs.push('Armas tradicionais anãs (Machado anão, etc.)');
    }
    for (const p of (poderes || [])) {
        const np = (p.nome || '').toLowerCase();
        if (np === 'proficiência') {
            for (const c of ['Armas marciais', 'Armas exóticas', 'Armas de fogo', 'Armaduras pesadas', 'Escudos']) {
                if (!profs.includes(c)) profs.push(c);
            }
        } else if (np === 'armeiro' && !profs.includes('Armas marciais')) {
            profs.push('Armas marciais');
        } else if (np === 'couraceiro') {
            if (!profs.includes('Armaduras pesadas')) profs.push('Armaduras pesadas');
            if (!profs.includes('Escudos')) profs.push('Escudos');
        } else if ((np === 'balística' || np === 'pistoleiro') && !profs.includes('Armas de fogo')) {
            profs.push('Armas de fogo');
        }
    }
    return profs;
}

function temProficienciaItemJS(item, classeObj, racaObj, poderes, escudo) {
    if (!item) return { ok: true, motivo: 'OK' };
    const profs = obterProficienciasAtivasJS(classeObj, racaObj, poderes).map(x => x.toLowerCase());
    const cat = (item.categoria || '').toLowerCase();
    const sub = (item.subcategoria || '').toLowerCase();
    const nomeI = (item.nome || '').toLowerCase();
    if (cat === 'arma') {
        if (sub.includes('simples')) return { ok: true, motivo: 'OK' };
        if (sub.includes('marcial')) {
            return { ok: profs.some(p => p.includes('marciais')), motivo: 'Requer proficiência com Armas Marciais' };
        }
        if (sub.includes('exótica')) {
            if (racaObj && racaObj.nome.toLowerCase() === 'anão' && (nomeI.includes('machado') || nomeI.includes('martelo'))) {
                return { ok: true, motivo: 'Tradição de Heredrimm' };
            }
            if ((nomeI.includes('bastarda') || nomeI.includes('katana')) && profs.some(p => p.includes('marciais')) && !escudo) {
                return { ok: true, motivo: 'Arma adaptável usada com 2 mãos' };
            }
            return { ok: profs.some(p => p.includes('exóticas')), motivo: `Requer poder 'Proficiência' para arma exótica (${item.nome})` };
        }
        if (sub.includes('fogo')) {
            return { ok: profs.some(p => p.includes('fogo')), motivo: `Requer proficiência com Armas de Fogo (${item.nome})` };
        }
    } else if (cat === 'armadura') {
        if (sub.includes('leve')) {
            return { ok: profs.some(p => p.includes('armaduras leves')), motivo: 'Arcanista não possui proficiência com armaduras leves' };
        }
        if (sub.includes('pesada')) {
            return { ok: profs.some(p => p.includes('armaduras pesadas')), motivo: `Requer proficiência com Armaduras Pesadas (${item.nome})` };
        }
    } else if (cat === 'escudo') {
        return { ok: profs.some(p => p.includes('escudos')), motivo: `Requer proficiência com Escudos (${item.nome})` };
    }
    return { ok: true, motivo: 'OK' };
}

function patamarAtualJS(nivel) {
    if (nivel <= 4) return 1;
    if (nivel <= 10) return 2;
    if (nivel <= 16) return 3;
    return 4;
}

function satisfazPreReqOffline(preReqStr, atrFinais, nivel, periciasSet, poderesNomesSet, deusNome, ctxExtra) {
    const limpo = (preReqStr || '').trim();
    if (!limpo || ['nenhum', '-', 'n/a'].includes(limpo.toLowerCase())) {
        return { ok: true, motivo: 'OK' };
    }
    const ctx = ctxExtra || {};
    const classeObj = ctx.classeObj || null;
    const racaObj = ctx.racaObj || null;
    const poderesAtuais = ctx.poderesAtuais || [];
    const armaEq = ctx.armaEq || null;
    const escudoEq = ctx.escudoEq || null;
    const magiasAtuais = ctx.magiasAtuais || [];

    if (limpo.toLowerCase().includes('patamar')) {
        const qtdAum = poderesAtuais.filter(p => (p.nome || '').toLowerCase() === 'aumento de atributo').length;
        const limPat = patamarAtualJS(nivel);
        if (qtdAum >= limPat) {
            return { ok: false, motivo: `Máx. 1x por patamar (limite no nível ${nivel}: ${limPat}x)` };
        }
        return { ok: true, motivo: 'OK' };
    }

    const partes = limpo.split(',').map(s => s.trim()).filter(Boolean);
    for (const p of partes) {
        const pl = p.toLowerCase();
        // 1. Devoção
        if (pl.startsWith('devoto') || pl === 'qualquer devoto') {
            if (!deusNome) return { ok: false, motivo: 'Requer ' + p };
            if (pl.includes('exceto lena/marah') && ['lena', 'marah'].includes(deusNome.toLowerCase())) {
                return { ok: false, motivo: 'Incompatível com Lena/Marah' };
            }
            if (pl !== 'devoto' && pl !== 'qualquer devoto' && !pl.includes('exceto') && !pl.includes(deusNome.toLowerCase())) {
                return { ok: false, motivo: 'Requer ' + p + ' (atual: ' + deusNome + ')' };
            }
            continue;
        }
        // 2. Proficiências
        if (pl.includes('proficiência') || pl === 'escudo') {
            const profs = obterProficienciasAtivasJS(classeObj, racaObj, poderesAtuais).map(x => x.toLowerCase());
            if (pl.includes('armaduras pesadas') && !profs.some(x => x.includes('armaduras pesadas'))) {
                return { ok: false, motivo: 'Requer Proficiência com Armaduras Pesadas' };
            }
            if (pl.includes('escudo') && !profs.some(x => x.includes('escudos'))) {
                return { ok: false, motivo: 'Requer Proficiência com Escudos' };
            }
            if (pl.includes('arma')) {
                if (!armaEq) return { ok: false, motivo: 'Requer arma equipada' };
                const checkA = temProficienciaItemJS(armaEq, classeObj, racaObj, poderesAtuais, escudoEq);
                if (!checkA.ok) return checkA;
            }
            continue;
        }
        // 3. Magias / Conjuração / Não Conjurador / Dissipar Magia
        if (pl.includes('lançar magias') || pl.includes('habilidade de classe magias') || pl.includes('não conjurador') || pl === 'dissipar magia') {
            const ehConj = ehConjuradorJS(classeObj, poderesAtuais);
            if (pl.includes('não conjurador')) {
                if (ehConj) return { ok: false, motivo: 'Exclusivo para não conjuradores' };
                continue;
            }
            if (pl === 'dissipar magia') {
                if (!magiasAtuais.some(m => (m.nome || '').toLowerCase().includes('dissipar magia'))) {
                    return { ok: false, motivo: "Requer conhecer a magia 'Dissipar Magia'" };
                }
                continue;
            }
            if (pl.includes('2º círculo') || pl.includes('2o círculo')) {
                const cMax = circuloMaximoPermitido(classeObj, nivel);
                if (cMax < 2) return { ok: false, motivo: `Requer lançar magias de 2º círculo (atual: ${cMax}º)` };
                continue;
            }
            if (!ehConj) return { ok: false, motivo: 'Requer habilidade de classe Magias / Lançar Magias' };
            continue;
        }
        // 4. Nível mínimo e Classe (com suporte a Nível de Classe vs Nível de Personagem em Multiclasse, p. 34)
        const mNiv = pl.match(/(\d+)[ºo°]?\s*nível(?:\s+de\s+([a-zA-Zçãõáéíóúâêô]+))?|nível\s*(\d+)/);
        if (mNiv) {
            const reqN = parseInt(mNiv[1] || mNiv[3], 10);
            const clEsp = (mNiv[2] || '').trim().toLowerCase();
            if (clEsp && clEsp !== 'personagem') {
                const paresCtx = (ctxExtra && ctxExtra.paresClasses) ? ctxExtra.paresClasses : (classeObj ? [{ classeObj, nivel }] : []);
                const parAchado = paresCtx.find(pc => (pc.classeObj.nome || '').toLowerCase() === clEsp);
                if (!parAchado || parAchado.nivel <= 0) {
                    return { ok: false, motivo: 'Requer classe ' + clEsp };
                }
                if (parAchado.nivel < reqN) {
                    return { ok: false, motivo: `Requer ${reqN}º nível de ${clEsp} (atual na classe: ${parAchado.nivel})` };
                }
                continue;
            }
            if (nivel < reqN) return { ok: false, motivo: 'Nível de personagem >= ' + reqN + ' (atual: ' + nivel + ')' };
            continue;
        }
        // 5. Treinado em perícia explícito
        if (pl.includes('treinado em') || pl.includes('treinado na perícia')) {
            if (pl.includes('treinado na perícia')) continue;
            const perStr = p.replace(/treinado em\s*/i, '').trim();
            const opcoes = perStr.split(/\s+ou\s+/i).map(x => x.trim().toLowerCase());
            const tem = opcoes.some(op => Array.from(periciasSet).some(ps => ps.toLowerCase().includes(op.split('(')[0].trim())));
            if (!tem) return { ok: false, motivo: 'Treinado em ' + perStr };
            continue;
        }
        // 6. Atributo mínimo
        const mAtr = pl.match(/^(for|des|con|int|sab|car)\s+(\d+)$/);
        if (mAtr) {
            const sig = mAtr[1].toUpperCase();
            const minV = parseInt(mAtr[2], 10);
            if ((atrFinais[sig] || 0) < minV) return { ok: false, motivo: 'Atributo ' + sig + ' >= ' + minV + ' (atual: ' + (atrFinais[sig] || 0) + ')' };
            continue;
        }
        // 7. Perícias na forma curta (ex: 'Luta', 'Iniciativa', 'Guerra', 'Enganação e Investigação')
        if (pl.includes(' e ') && pl.split(/\s+e\s+/).every(ehNomePericiaJS)) {
            for (const sp of pl.split(/\s+e\s+/)) {
                const rad = sp.split('(')[0].trim();
                const tem = Array.from(periciasSet).some(ps => ps.toLowerCase().includes(rad));
                if (!tem) return { ok: false, motivo: 'Treinado em ' + sp };
            }
            continue;
        }
        if (ehNomePericiaJS(pl)) {
            const rad = pl.split('(')[0].trim();
            const tem = Array.from(periciasSet).some(ps => ps.toLowerCase().includes(rad));
            if (!tem) return { ok: false, motivo: 'Treinado em ' + p };
            continue;
        }
        // 8. Habilidades de classe específicas
        if (['forma selvagem', 'canalizar energia', 'bruxo', 'feiticeiro', 'mago', 'bruxo ou mago', 'montaria'].includes(pl)) {
            const nc = classeObj ? classeObj.nome.toLowerCase() : '';
            if (['bruxo', 'feiticeiro', 'mago', 'bruxo ou mago'].includes(pl) && nc !== 'arcanista') return { ok: false, motivo: 'Requer Arcanista' };
            if (pl === 'forma selvagem' && nc !== 'druida') return { ok: false, motivo: 'Requer Forma Selvagem (Druida)' };
            if (pl === 'canalizar energia' && nc !== 'clérigo') return { ok: false, motivo: 'Requer Canalizar Energia (Clérigo)' };
            continue;
        }
        // 9. Poder pré-requisito
        const opcoesPod = p.split(/\s+ou\s+/i).map(x => x.trim().toLowerCase());
        const temPod = opcoesPod.some(op => Array.from(poderesNomesSet).some(pn => pn.toLowerCase().includes(op)));
        if (!temPod) return { ok: false, motivo: "Pré-requisito '" + p + "'" };
    }
    return { ok: true, motivo: 'OK' };
}
function calcularEstatisticaCompletaT20(cfg) {
    const nivel = cfg.nivel;
    const raca = cfg.raca;
    const classe = cfg.classe;
    const poderes = cfg.poderes || [];
    const itens = cfg.itens || [];
    const periciasSet = new Set(cfg.pericias || []);

    // 1. Atributos Finais = Base + Modificadores Raciais + Livres + Aumento de Atributo - Tormenta
    const finais = {
        FOR: parseIntSeguro(cfg.atrBase.FOR, 0) + parseIntSeguro(raca.mod_for, 0),
        DES: parseIntSeguro(cfg.atrBase.DES, 0) + parseIntSeguro(raca.mod_des, 0),
        CON: parseIntSeguro(cfg.atrBase.CON, 0) + parseIntSeguro(raca.mod_con, 0),
        INT: parseIntSeguro(cfg.atrBase.INT, 0) + parseIntSeguro(raca.mod_int, 0),
        SAB: parseIntSeguro(cfg.atrBase.SAB, 0) + parseIntSeguro(raca.mod_sab, 0),
        CAR: parseIntSeguro(cfg.atrBase.CAR, 0) + parseIntSeguro(raca.mod_car, 0)
    };
    const modLivreStr = (raca.mod_livre || '').toLowerCase();
    if (modLivreStr.includes('atributo') || modLivreStr.includes('qualquer')) {
        const qtdLivres = modLivreStr.includes('3') ? 3 : (modLivreStr.includes('2') ? 2 : 1);
        const usados = [];
        const ehOsteonR = raca.nome.toLowerCase() === 'osteon';
        for (const s of (cfg.livres || ['FOR', 'DES', 'CON'])) {
            let sig = s.trim().toUpperCase();
            if (ehOsteonR && sig === 'CON') {
                sig = ['DES', 'INT', 'SAB', 'CAR', 'FOR'].find(a => !usados.includes(a)) || 'DES';
            }
            if (finais[sig] !== undefined && !usados.includes(sig) && usados.length < qtdLivres) {
                usados.push(sig);
                finais[sig] += 1;
            }
        }
    }

    const infoMagia = obterAtributoChaveMagiaJS(classe, cfg.caminhoArcanista);
    const atribPrincipal = (classe.nome || '').toLowerCase().includes('arcanista')
        ? infoMagia.sigla
        : ((classe.atributo_principal || 'FOR').split(' ')[0] || 'FOR').toUpperCase();
    const infoOrigem = obterBeneficiosOrigemGolemOsteonJS(raca, cfg.origem, poderes, cfg.racaAnteriorOsteon, cfg.arquetipo, cfg.pericias, cfg.arma, cfg.escudo, classe);
    if (infoOrigem.periciaExtra) periciasSet.add(infoOrigem.periciaExtra);
    const infoDevocao = obterPoderesConcedidosDevocaoJS(cfg.deus, classe, cfg.arquetipo);
    const todosPoderesAtivos = [...infoOrigem.poderesExtras, ...infoDevocao.poderes, ...poderes];
    for (const p of todosPoderesAtivos) {
        if ((p.nome || '').toLowerCase() === 'aumento de atributo') {
            if (finais[atribPrincipal] !== undefined) finais[atribPrincipal] += 1;
        }
    }

    const qtdTormenta = poderes.filter(p => (p.categoria_ou_classe || '').toLowerCase() === 'tormenta').length;
    if (qtdTormenta > 0) {
        const temAfinidade = poderes.some(p => (p.nome || '').toLowerCase() === 'afinidade com a tormenta');
        const efetivos = temAfinidade ? Math.max(0, qtdTormenta - 1) : qtdTormenta;
        if (efetivos > 0) finais.CAR -= (1 + Math.floor((efetivos - 1) / 2));
    }

    // 2. Cálculo Exato de PV por Classe / Multiclasse (Cap. 1, p. 34), Raça e Poderes
    const paresClasses = normalizarClassesMulticlasseJS(cfg);
    const usaSabPV = poderes.some(p => (p.nome || '').toLowerCase() === 'dom da esperança');
    const modPV = usaSabPV ? finais.SAB : finais.CON;
    const siglaPV = usaSabPV ? 'SAB' : 'CON';
    const clPrim = paresClasses[0].classeObj;
    const nvPrim = paresClasses[0].nivel;
    const pvInicialClasse = parseIntSeguro(clPrim.pv_inicial, 12);
    const pvPorNivelClasse = parseIntSeguro(clPrim.pv_por_nivel, 3);

    const pv1 = Math.max(1, pvInicialClasse + modPV);
    const pvPorNvPrim = Math.max(1, pvPorNivelClasse + modPV);
    const pvSubPrim = (nvPrim - 1) * pvPorNvPrim;
    let pvMax = pv1 + pvSubPrim;
    const partesDetPV = [];
    if (nvPrim === 1) {
        partesDetPV.push(`${pv1} (1º nv ${clPrim.nome}: ${pvInicialClasse}+${modPV} ${siglaPV})`);
    } else {
        partesDetPV.push(`${pv1} (1º nv ${clPrim.nome}: ${pvInicialClasse}+${modPV} ${siglaPV}) + ${pvSubPrim} (${nvPrim - 1} nv ${clPrim.nome} × [${pvPorNivelClasse}+${modPV} ${siglaPV}])`);
    }
    // Regra Oficial de Multiclasse (Livro p. 34): ao adquirir nível em uma nova classe, soma APENAS os PV de nível subsequente (pv_por_nivel + CON)!
    for (let idxC = 1; idxC < paresClasses.length; idxC++) {
        const clSec = paresClasses[idxC].classeObj;
        const nvSec = paresClasses[idxC].nivel;
        const pvPorNvSec = Math.max(1, parseIntSeguro(clSec.pv_por_nivel, 3) + modPV);
        const ganhoSec = nvSec * pvPorNvSec;
        pvMax += ganhoSec;
        partesDetPV.push(`${ganhoSec} (Multiclasse ${clSec.nome} ${nvSec} nv × [${parseIntSeguro(clSec.pv_por_nivel, 3)}+${modPV} ${siglaPV}] — p. 34)`);
    }
    let detPV = partesDetPV.join(' + ');

    const memOstJS = (cfg.racaAnteriorOsteon || 'Anão').toLowerCase();
    if ((raca.habilidades_raca || '').toLowerCase().includes('duro como pedra') || raca.nome.toLowerCase() === 'anão' || (raca.nome.toLowerCase() === 'osteon' && memOstJS.includes('anão'))) {
        const ganhoAnao = 3 + (nivel - 1);
        pvMax += ganhoAnao;
        detPV += ` + ${ganhoAnao} (Anão: Duro como Pedra)`;
    }
    for (const p of poderes) {
        if ((p.nome || '').toLowerCase() === 'vitalidade') {
            pvMax += nivel;
            detPV += ` + ${nivel} (Vitalidade)`;
        }
    }
    detPV += ` = ${pvMax} PV`;

    // 3. Cálculo Exato de PM por Classe / Multiclasse (Cap. 1, p. 34), Raça, Poderes e Itens
    let pmMax = 0;
    const partesDetPM = [];
    const atribPmSomados = new Set();
    const nomeClasseL = classe.nome.toLowerCase();
    for (const parC of paresClasses) {
        const clAt = parC.classeObj;
        const nvAt = parC.nivel;
        const pmNvAt = parseIntSeguro(clAt.pm_por_nivel, 3);
        const subPm = pmNvAt * nvAt;
        pmMax += subPm;
        partesDetPM.push(`${subPm} (${clAt.nome}: ${pmNvAt}/nv × ${nvAt})`);
        const ncAtLow = (clAt.nome || '').toLowerCase();
        if (['arcanista', 'bardo', 'clérigo', 'clerigo', 'druida'].some(k => ncAtLow.includes(k))) {
            const infM = obterAtributoChaveMagiaJS(clAt, cfg.caminhoArcanista);
            const sigMag = infM.sigla;
            if (!atribPmSomados.has(sigMag)) {
                atribPmSomados.add(sigMag);
                const bonusAtribPM = Math.max(0, finais[sigMag] || 0);
                if (bonusAtribPM > 0) {
                    pmMax += bonusAtribPM;
                    partesDetPM.push(`${bonusAtribPM} (Atrib. Magias ${sigMag} [${clAt.nome}])`);
                }
            }
        } else if (ncAtLow.includes('paladino') && !atribPmSomados.has('CAR_ABENCOADO')) {
            atribPmSomados.add('CAR_ABENCOADO');
            const bonusCarPM = Math.max(0, finais.CAR || 0);
            if (bonusCarPM > 0) {
                pmMax += bonusCarPM;
                partesDetPM.push(`${bonusCarPM} (Abençoado Paladino: +CAR)`);
            }
        }
    }
    let detPM = partesDetPM.join(' + ');
    if ((raca.habilidades_raca || '').toLowerCase().includes('sangue mágico') || raca.nome.toLowerCase() === 'elfo' || (raca.nome.toLowerCase() === 'osteon' && memOstJS.includes('elfo'))) {
        pmMax += nivel;
        detPM += ` + ${nivel} (Elfo: Sangue Mágico)`;
    }
    for (const p of poderes) {
        const nl = (p.nome || '').toLowerCase();
        if (nl === 'vontade de ferro') {
            const g = Math.floor(nivel / 2);
            if (g > 0) { pmMax += g; detPM += ` + ${g} (Vontade de Ferro)`; }
        } else if (nl === 'bênção do mana') {
            const g = Math.floor(nivel / 2);
            if (g > 0) { pmMax += g; detPM += ` + ${g} (Bênção do Mana)`; }
        } else if (nl === 'poder mágico') {
            pmMax += nivel;
            detPM += ` + ${nivel} (Poder Mágico)`;
        }
    }
    if (nomeClasseL.includes('arcanista') && itens.some(i => (i.nome || '').toLowerCase() === 'chapéu arcano')) {
        pmMax += 1;
        detPM += ` + 1 (Chapéu Arcano)`;
    }
    detPM += ` = ${pmMax} PM`;

    // 4. Defesa, Deslocamento, Carga e Perícias
    let deslocamento = parseIntSeguro(raca.deslocamento_m, 9);
    let bonusArm = 0;
    let penArm = 0;
    let limitaDes = false;

    if (cfg.armadura) {
        bonusArm += parseIntSeguro(cfg.armadura.dano_ou_defesa, 0);
        penArm += Math.abs(parseIntSeguro(cfg.armadura.critico_ou_penalidade, 0));
        if ((cfg.armadura.subcategoria || '').toLowerCase().includes('pesada')) {
            limitaDes = true;
            if (raca.nome.toLowerCase() !== 'anão' && !poderes.some(p => p.nome.toLowerCase() === 'fanático')) {
                deslocamento = Math.max(3, deslocamento - 3);
            }
        }
    }
    if (cfg.escudo) {
        bonusArm += parseIntSeguro(cfg.escudo.dano_ou_defesa, 0);
        penArm += Math.abs(parseIntSeguro(cfg.escudo.critico_ou_penalidade, 0));
    }

    const nomeRacaLowDef = (raca.nome || '').toLowerCase();
    const memOstDef = (cfg.racaAnteriorOsteon || '').toLowerCase();
    if (nomeRacaLowDef === 'golem' || /chassi/i.test(raca.habilidades_raca || '')) {
        deslocamento = 6;
        penArm += 2;
    }
    // Regras JdA de Atributo na Defesa: Armadura Pesada bloqueia DES, Autoconfiança e Couraceiro (p. 152/69/79)
    const clsDefLow = (classe.nome || '').toLowerCase();
    const temCouraceiro = todosPoderesAtivos.some(p => (p.nome || '').toLowerCase() === 'couraceiro');
    const temBlindagem = todosPoderesAtivos.some(p => (p.nome || '').toLowerCase() === 'blindagem');
    const temBracosCalejados = todosPoderesAtivos.some(p => (p.nome || '').toLowerCase() === 'braços calejados');
    const usaArmLeve = Boolean(cfg.armadura && !limitaDes);

    let atribBaseDef = 0;
    let usouCarNaDef = false;
    let usouIntNaDef = false;
    if (!limitaDes) {
        atribBaseDef = finais.DES;
        // Autoconfiança (Nobre, p. 79): substitui DES por CAR sem armadura pesada
        if (clsDefLow === 'nobre' && finais.CAR > atribBaseDef) {
            atribBaseDef = finais.CAR;
            usouCarNaDef = true;
        }
        // Couraceiro (Inventor, p. 69): substitui DES por INT ao usar armadura leve
        if (temCouraceiro && usaArmLeve && finais.INT > atribBaseDef) {
            atribBaseDef = finais.INT;
            usouIntNaDef = true;
            usouCarNaDef = false;
        }
    } else if (temBlindagem) {
        // Blindagem (Inventor, p. 68): única exceção que soma INT na Defesa com armadura pesada
        atribBaseDef = Math.max(0, finais.INT || 0);
        usouIntNaDef = true;
    }

    let defesa = 10 + atribBaseDef + bonusArm;

    // Habilidades de classe/poderes que somam atributo na Defesa apenas SEM armadura pesada
    if (!limitaDes) {
        if (clsDefLow === 'bucaneiro' && !usouCarNaDef) {
            defesa += Math.min(nivel, Math.max(0, finais.CAR || 0)); // Insolência (p. 46)
        }
        if (clsDefLow === 'lutador' && nivel >= 2) {
            const escCasca = nivel >= 5 ? (1 + Math.floor((nivel - 5) / 4)) : 0;
            defesa += Math.max(0, finais.CON || 0) + escCasca; // Casca Grossa (p. 76)
        }
        if (temBracosCalejados) {
            defesa += Math.max(0, finais.FOR || 0); // Braços Calejados (sem armadura pesada)
        }
    }
    // Égide Sagrada (Paladino nv. 5+ com escudo) funciona com armadura pesada
    if (clsDefLow === 'paladino' && nivel >= 5 && cfg.escudo && !usouCarNaDef) {
        defesa += Math.max(0, finais.CAR || 0);
    }
    if (nomeRacaLowDef === 'golem' || /chassi/i.test(raca.habilidades_raca || '')) {
        defesa += 2;
    } else if (nomeRacaLowDef === 'minotauro' || nomeRacaLowDef === 'trog' || /(couro rígido|casca grossa|armadura natural)/i.test(raca.habilidades_raca || '') || (nomeRacaLowDef === 'osteon' && memOstDef.includes('minotauro'))) {
        defesa += 1;
    }

    let cargaMax = 10 + (finais.FOR >= 0 ? 2 * finais.FOR : finais.FOR);
    let cdMagia = 10 + Math.floor(nivel / 2) + (finais[infoMagia.sigla] !== undefined ? finais[infoMagia.sigla] : finais.INT);

    for (const p of poderes) {
        const nl = (p.nome || '').toLowerCase();
        if (nl === 'esquiva') defesa += 2;
        else if (nl === 'encouraçado' && cfg.armadura && (cfg.armadura.subcategoria || '').toLowerCase().includes('pesada')) defesa += 2;
        else if (nl === 'estilo de arma e escudo' && cfg.escudo) defesa += 2;
        else if (nl === 'estilo de uma arma' && cfg.arma && !cfg.escudo && !(cfg.arma.subcategoria || '').toLowerCase().includes('duas mãos')) defesa += 2;
        else if (nl === 'escamas dracônicas') defesa += 2;
        else if (nl === 'costas largas') cargaMax += 5;
        else if (nl === 'inventário organizado') cargaMax += Math.max(0, finais.INT);
        else if (nl === 'atlético') deslocamento += 3;
        else if (nl === 'fortalecimento arcano') cdMagia += (circuloMaximoPermitido(classe, nivel) >= 4 ? 2 : 1);
    }

    const cargaAtual = +(itens.reduce((acc, it) => acc + (parseFloat(it.espacos) || 0), 0)).toFixed(1);
    const metadeNivel = Math.floor(nivel / 2);
    const bonusTreino = nivel <= 6 ? 2 : (nivel <= 14 ? 4 : 6);
    const bonusPericias = {};
    for (const per of CATALOGO_T20.pericias) {
        const tr = Array.from(periciasSet).some(ps => ps.toLowerCase() === per.nome.toLowerCase() || per.nome.toLowerCase().startsWith(ps.toLowerCase()));
        let tot = metadeNivel + (finais[per.atributo_chave] || 0) + (tr ? bonusTreino : 0);
        if (per.penalidade_armadura) tot -= penArm;
        bonusPericias[per.nome] = tot;
    }
    for (const p of todosPoderesAtivos) {
        const nl = (p.nome || '').toLowerCase();
        if (nl === 'vitalidade' && bonusPericias['Fortitude'] !== undefined) bonusPericias['Fortitude'] += 2;
        if (nl === 'vontade de ferro' && bonusPericias['Vontade'] !== undefined) bonusPericias['Vontade'] += 2;
        if (nl === 'esquiva' && bonusPericias['Reflexos'] !== undefined) bonusPericias['Reflexos'] += 2;
        if (nl === 'atlético' && bonusPericias['Atletismo'] !== undefined) bonusPericias['Atletismo'] += 2;
        if (nl === 'escamas dracônicas' && bonusPericias['Fortitude'] !== undefined) bonusPericias['Fortitude'] += 2;
        if (nl === 'coragem total' && bonusPericias['Vontade'] !== undefined) bonusPericias['Vontade'] += 2;
        if (nl === 'sentidos aguçados' && bonusPericias['Percepção'] !== undefined) bonusPericias['Percepção'] += 2;
        if (nl === 'mente vazia') {
            if (bonusPericias['Iniciativa'] !== undefined) bonusPericias['Iniciativa'] += 2;
            if (bonusPericias['Percepção'] !== undefined) bonusPericias['Percepção'] += 2;
            if (bonusPericias['Vontade'] !== undefined) bonusPericias['Vontade'] += 2;
        }
    }
    if (nomeRacaLowDef === 'elfo') {
        if (bonusPericias['Misticismo'] !== undefined) bonusPericias['Misticismo'] += 2;
        if (bonusPericias['Percepção'] !== undefined) bonusPericias['Percepção'] += 2;
    } else if (nomeRacaLowDef === 'goblin') {
        if (bonusPericias['Fortitude'] !== undefined) bonusPericias['Fortitude'] += 2;
    } else if (nomeRacaLowDef === 'hynne') {
        if (bonusPericias['Enganação'] !== undefined) bonusPericias['Enganação'] += 2;
        if (bonusPericias['Atletismo'] !== undefined && finais.DES > finais.FOR) bonusPericias['Atletismo'] += (finais.DES - finais.FOR);
    } else if (nomeRacaLowDef === 'kliren') {
        if (bonusPericias['Ofício'] !== undefined) bonusPericias['Ofício'] += 2;
    } else if (nomeRacaLowDef.includes('aggelus')) {
        if (bonusPericias['Diplomacia'] !== undefined) bonusPericias['Diplomacia'] += 2;
        if (bonusPericias['Intuição'] !== undefined) bonusPericias['Intuição'] += 2;
    } else if (nomeRacaLowDef.includes('sulfure')) {
        if (bonusPericias['Enganação'] !== undefined) bonusPericias['Enganação'] += 2;
        if (bonusPericias['Furtividade'] !== undefined) bonusPericias['Furtividade'] += 2;
    } else if (nomeRacaLowDef === 'lefou') {
        if (bonusPericias['Luta'] !== undefined) bonusPericias['Luta'] += 2;
        if (bonusPericias['Fortitude'] !== undefined) bonusPericias['Fortitude'] += 2;
    }

    const habilidadesMulticlasse = listarHabilidadesClasseMulticlasseJS(paresClasses, cfg.caminhoArcanista);
    return { racaNome: raca.nome, racaAnteriorOsteon: cfg.racaAnteriorOsteon || '', finais, pvMax, pmMax, detPV, detPM, defesa, deslocamento, penArm: -penArm,
        cargaAtual, cargaMax, cdMagia, bonusPericias, infoMagia, infoDevocao, infoOrigem, paresClasses, habilidadesMulticlasse
    };
}


const GRUPOS_ESTILO_JS = {
    DUAS_MAOS: ['destruidor', 'estilo de duas mãos', 'ataque pesado'],
    ARMA_LONGA_HASTE: ['estilo de arma longa', 'piqueiro'],
    ARQUERIA_DISPARO: ['arqueiro', 'estilo de disparo', 'disparo preciso', 'disparo rápido', 'mira apurada'],
    ARREMESSO: ['estilo de arremesso', 'arremesso potente', 'arremesso múltiplo'],
    DUAS_ARMAS: ['estilo de duas armas', 'ambidestria', 'arma secundária grande'],
    UMA_ARMA_ESGRIMA: ['estilo de uma arma', 'ataque preciso', 'esgrimista', 'acuidade com arma'],
    ARMA_E_ESCUDO: ['estilo de arma e escudo', 'ataque com escudo', 'bloqueio com escudo', 'solidez', 'escudeiro']
};

const PODERES_CORPO_A_CORPO_JS = new Set([
    'destruidor', 'estilo de duas mãos', 'ataque pesado', 'ataque poderoso', 'trespassar',
    'valentão', 'ambidestria', 'estilo de duas armas', 'esgrimista', 'acuidade com arma',
    'ataque reflexo', 'tornado de dor', 'golpe de raspão', 'estilo de uma arma', 'ataque preciso',
    'estilo de arma e escudo', 'ataque com escudo', 'quebrar aprimorado', 'derrubar aprimorado'
]);

function identificarEstiloArmaJS(arma, escudo, poderes, arquetipo) {
    const arq = (arquetipo || '').toLowerCase();
    const nms = (poderes || []).map(p => (p.nome || '').toLowerCase());
    if (!arma) {
        if (escudo) return 'ARMA_E_ESCUDO';
        return 'CONJURADOR_OU_DESARMADO';
    }
    const nmArma = (arma.nome || '').toLowerCase();
    const sub = (arma.subcategoria || '').toLowerCase();
    const prop = (arma.efeito_propriedades || '').toLowerCase();

    // 1. Armas à Distância (Disparo vs Arremesso) NUNCA são consideradas corpo a corpo, duas mãos CaC ou duas armas CaC!
    if (sub.includes('distância') || sub.includes('distancia') || sub.includes('fogo') || /arco|besta|mosquete|pistola|funda/.test(nmArma)) {
        return (prop.includes('arremesso') || /azagaia|rede|boleadeira/.test(nmArma)) ? 'ARREMESSO' : 'ARQUERIA_DISPARO';
    }
    // 2. Armas Corpo a Corpo Alongadas / De Haste (Alabarda, Pique, Lança Montada)
    if (prop.includes('alongada') || /alabarda|pique|lança montada/.test(nmArma)) {
        return 'ARMA_LONGA_HASTE';
    }
    // 3. Armas Corpo a Corpo de Duas Mãos (Montante, Marreta, Machado de Guerra/Taurico, Gadanho, Cajado de Batalha)
    if (sub.includes('duas mãos') || sub.includes('duas maos') || /montante|marreta|machado de guerra|machado táurico|gadanho|cajado de batalha/.test(nmArma)) {
        return 'DUAS_MAOS';
    }
    // 4. Arma de Uma Mão/Leve + Escudo equipado -> sempre ARMA_E_ESCUDO (mão secundária ocupada pelo escudo!)
    const temEscudoReal = Boolean(escudo && escudo.nome && escudo.nome !== 'Nenhum');
    if (temEscudoReal) {
        return 'ARMA_E_ESCUDO';
    }
    // 5. Arma de Uma Mão/Leve SEM escudo -> verifica se usa Duas Armas ou Uma Arma (mão livre)
    if (nms.includes('estilo de duas armas') || nms.includes('ambidestria') || arq.includes('duas armas')) {
        return 'DUAS_ARMAS';
    }
    return 'UMA_ARMA_ESGRIMA';
}

function auditarCompatibilidadePoderesArmaJS(arma, escudo, poderes, classeObj) {
    const estilo = identificarEstiloArmaJS(arma, escudo, poderes);
    const ehDist = ['ARQUERIA_DISPARO', 'ARREMESSO'].includes(estilo);
    const ehDuasMaos = ['DUAS_MAOS', 'ARMA_LONGA_HASTE'].includes(estilo);
    const ehUmaMaoLivre = (estilo === 'UMA_ARMA_ESGRIMA');
    const ehDuasArmas = (estilo === 'DUAS_ARMAS');
    const temEscudo = (estilo === 'ARMA_E_ESCUDO');
    const prop = arma ? ((arma.efeito_propriedades || '') + ' ' + (arma.subcategoria || '')).toLowerCase() : '';
    const ehAgilOuLeve = prop.includes('ágil') || prop.includes('agil') || prop.includes('leve') || (arma && /florete|adaga|espada curta|cimitarra|chicote|katar/.test((arma.nome || '').toLowerCase()));

    const compativeis = [];
    const bloqueados = [];

    for (const p of (poderes || [])) {
        const nm = (p.nome || '').trim();
        const low = nm.toLowerCase();
        let ok = true;
        let motivo = 'Compatível com a arma e empunhadura atuais.';

        if (['estilo de duas mãos', 'destruidor', 'ataque pesado'].includes(low) && !ehDuasMaos) {
            ok = false; motivo = 'Exige arma corpo a corpo de Duas Mãos (ou Alongada).';
        } else if (['estilo de arma longa', 'piqueiro'].includes(low) && estilo !== 'ARMA_LONGA_HASTE') {
            ok = false; motivo = 'Exige arma alongada (ex.: Alabarda, Pique).';
        } else if (['estilo de disparo', 'arqueiro', 'disparo rápido', 'disparo preciso', 'mira apurada'].includes(low) && estilo !== 'ARQUERIA_DISPARO') {
            ok = false; motivo = 'Exige arma de ataque à distância de disparo (Arco, Besta, Arma de Fogo).';
        } else if (['estilo de arremesso', 'arremesso potente', 'arremesso múltiplo'].includes(low) && estilo !== 'ARREMESSO') {
            ok = false; motivo = 'Exige arma de arremesso.';
        } else if (['estilo de uma arma', 'ataque preciso', 'en garde'].includes(low) && !ehUmaMaoLivre) {
            ok = false; motivo = 'Exige arma corpo a corpo em uma mão e nada na outra (sem escudo, sem 2ª arma e não de duas mãos).';
        } else if (['estilo de duas armas', 'ambidestria', 'arma secundária grande'].includes(low) && (ehDist || ehDuasMaos || temEscudo)) {
            ok = false; motivo = 'Exige empunhar duas armas de uma mão/leves (incompatível com Duas Mãos, Escudo ou Arco/Besta).';
        } else if (['estilo de arma e escudo', 'ataque com escudo', 'bloqueio com escudo'].includes(low) && !temEscudo) {
            ok = false; motivo = 'Exige um Escudo equipado.';
        } else if (['ataque poderoso', 'trespassar', 'valentão', 'derrubar aprimorado', 'quebrar aprimorado', 'tornado de dor', 'ataque reflexo'].includes(low) && ehDist) {
            ok = false; motivo = 'Exclusivo para ataques Corpo a Corpo (não funciona à distância).';
        } else if (['acuidade com arma', 'esgrimista'].includes(low) && (ehDist || ehDuasMaos)) {
            ok = false; motivo = 'Exige arma corpo a corpo leve ou ágil (não funciona com armas pesadas de duas mãos ou disparo).';
        }

        if (ok) compativeis.push({ nome: nm, motivo });
        else bloqueados.push({ nome: nm, motivo });
    }

    const rotulosEstilo = {
        'DUAS_MAOS': 'Corpo a Corpo — Duas Mãos',
        'ARMA_LONGA_HASTE': 'Corpo a Corpo — Arma Alongada (Duas Mãos)',
        'UMA_ARMA_ESGRIMA': 'Corpo a Corpo — Uma Mão (Mão Secundária Livre)',
        'DUAS_ARMAS': 'Corpo a Corpo — Duas Armas',
        'ARMA_E_ESCUDO': 'Corpo a Corpo — Arma e Escudo',
        'ARQUERIA_DISPARO': 'À Distância — Disparo (Pontaria)',
        'ARREMESSO': 'À Distância — Arremesso (Pontaria)',
        'CONJURADOR_OU_DESARMADO': 'Conjurador / Desarmado'
    };

    return {
        estiloCodigo: estilo,
        estiloRotulo: rotulosEstilo[estilo] || estilo,
        ehAtaqueDistancia: ehDist,
        ehDuasMaos: ehDuasMaos,
        ehUmaMaoLivre: ehUmaMaoLivre,
        ehDuasArmas: ehDuasArmas,
        temEscudo: temEscudo,
        ehAgilOuLeve: ehAgilOuLeve,
        compativeis,
        bloqueados
    };
}

// =============================================================================
// CALCULADORA OFICIAL DE ND E REESCALONADOR DE ESTATÍSTICAS (T20 JdA Cap. 7, p. 323) - v51
// =============================================================================
function obterMetricasTabelaOficialPorNDJS(ndValor, papel) {
    const num = Number(ndValor) || 1;
    const pap = (papel || 'Solo').toLowerCase();
    // Para NDs fracionários (1/4 = 0.25, 1/3 = 0.33, 1/2 = 0.5)
    if (num < 1) {
        const f = num <= 0.26 ? 0.35 : (num <= 0.35 ? 0.50 : 0.70);
        const base1 = obterAmeacaOficialJS(1, papel);
        return {
            patamar: 'Iniciante',
            nd: num <= 0.26 ? '1/4' : (num <= 0.35 ? '1/3' : '1/2'),
            papel: papel || 'Lacaio',
            bonus_ataque: Math.max(4, Math.round(base1.bonus_ataque * (0.65 + f * 0.25))),
            dano_medio: Math.max(4, Math.round(base1.dano_medio * f)),
            defesa: Math.max(11, Math.round(base1.defesa - (1 - f) * 4)),
            res_forte: Math.max(3, Math.round(base1.res_forte - 2)),
            res_media: Math.max(1, Math.round(base1.res_media - 2)),
            res_fraca: Math.max(0, Math.round(base1.res_fraca - 2)),
            pv: Math.max(6, Math.round(base1.pv * f)),
            cd_efeito: Math.max(12, Math.round(base1.cd_efeito - 2))
        };
    }
    const ndInt = Math.max(1, Math.min(20, Math.round(num)));
    return obterAmeacaOficialJS(ndInt, papel);
}

function parseNDStringParaNumeroJS(ndStr) {
    const s = String(ndStr || '1').trim();
    if (s === '1/4' || s === '0.25') return 0.25;
    if (s === '1/3' || s === '0.33') return 0.33;
    if (s === '1/2' || s === '0.5') return 0.5;
    if (s === 'S' || s === 'S+') return 20;
    const n = parseFloat(s);
    return isNaN(n) ? 1 : n;
}

function formatarNumeroNDParaTextoJS(ndNum) {
    const n = Number(ndNum);
    if (Math.abs(n - 0.25) < 0.04) return '1/4';
    if (Math.abs(n - 0.33) < 0.05) return '1/3';
    if (Math.abs(n - 0.5) < 0.05) return '1/2';
    return String(Math.max(1, Math.min(20, Math.round(n))));
}

function reescalonarCriaturaParaNovoNDJS(criaturaOrig, novoNDInput, novoPapelInput, novoTamanhoInput) {
    if (!criaturaOrig) return null;
    const ndOrigNum = parseNDStringParaNumeroJS(criaturaOrig.ndOriginal || criaturaOrig.ndTexto || criaturaOrig.nd || 1);
    const ndNovoNum = parseNDStringParaNumeroJS(novoNDInput);
    const ndNovoTxt = formatarNumeroNDParaTextoJS(ndNovoNum);

    const papelOrig = criaturaOrig.papelOriginal || criaturaOrig.papel || 'Solo';
    const papelNovo = (novoPapelInput && novoPapelInput !== 'MANTER') ? novoPapelInput : papelOrig;

    const refOrig = obterMetricasTabelaOficialPorNDJS(ndOrigNum, papelOrig);
    const refNovo = obterMetricasTabelaOficialPorNDJS(ndNovoNum, papelNovo);

    const pvBaseOrig = Number(criaturaOrig.pvBaseOriginal || criaturaOrig.pvOficialGrupo4 || criaturaOrig.pvMax || refOrig.pv || 40);
    const atqBaseOrig = Number(criaturaOrig.ataqueBaseOriginal !== undefined ? criaturaOrig.ataqueBaseOriginal : (criaturaOrig.ataque || refOrig.bonus_ataque || 10));
    const danoBaseOrig = Number(criaturaOrig.danoBaseOriginal !== undefined ? criaturaOrig.danoBaseOriginal : (criaturaOrig.danoMedio || refOrig.dano_medio || 15));
    const defBaseOrig = Number(criaturaOrig.defesaBaseOriginal !== undefined ? criaturaOrig.defesaBaseOriginal : (criaturaOrig.defesa || refOrig.defesa || 16));
    const cdBaseOrig = Number(criaturaOrig.cdBaseOriginal !== undefined ? criaturaOrig.cdBaseOriginal : (criaturaOrig.cdEfeito || criaturaOrig.cd || refOrig.cd_efeito || 15));

    const ratioPV = refOrig.pv > 0 ? (refNovo.pv / refOrig.pv) : 1;
    const ratioDano = refOrig.dano_medio > 0 ? (refNovo.dano_medio / refOrig.dano_medio) : 1;
    const deltaAtq = refNovo.bonus_ataque - refOrig.bonus_ataque;
    const deltaDef = refNovo.defesa - refOrig.defesa;
    const deltaCD = refNovo.cd_efeito - refOrig.cd_efeito;
    const deltaResF = refNovo.res_forte - refOrig.res_forte;
    const deltaResM = refNovo.res_media - refOrig.res_media;
    const deltaResW = refNovo.res_fraca - refOrig.res_fraca;

    const pvCalculado = Math.max(6, Math.round(pvBaseOrig * ratioPV));
    const danoCalculado = Math.max(4, Math.round(danoBaseOrig * ratioDano));
    const atqCalculado = Math.max(2, Math.round(atqBaseOrig + deltaAtq));
    const defCalculada = Math.max(10, Math.round(defBaseOrig + deltaDef));
    const cdCalculada = Math.max(11, Math.round(cdBaseOrig + deltaCD));

    const patamarNovo = ndNovoNum <= 4 ? 'Iniciante' : (ndNovoNum <= 10 ? 'Veterano' : (ndNovoNum <= 16 ? 'Campeão' : 'Lenda'));

    let tamCat = criaturaOrig.tamanhoCat || 'Médio';
    let espacoQ = criaturaOrig.espacoQ || 1;
    if (novoTamanhoInput && novoTamanhoInput !== 'MANTER') {
        const mapTam = {
            'PEQUENO': { cat: 'Pequeno', q: 1 },
            'MEDIO': { cat: 'Médio', q: 1 },
            'GRANDE': { cat: 'Grande', q: 2 },
            'ENORME': { cat: 'Enorme', q: 3 },
            'COLOSSAL': { cat: 'Colossal', q: 6 }
        };
        if (mapTam[novoTamanhoInput]) {
            tamCat = mapTam[novoTamanhoInput].cat;
            espacoQ = mapTam[novoTamanhoInput].q;
        }
    }

    return {
        ndOriginal: formatarNumeroNDParaNumeroTexto(ndOrigNum),
        ndNovo: ndNovoTxt,
        ndNovoNum: ndNovoNum,
        papelNovo: papelNovo,
        patamarNovo: patamarNovo,
        tamanhoCat: tamCat,
        espacoQ: espacoQ,
        pv: pvCalculado,
        defesa: defCalculada,
        ataque: atqCalculado,
        danoMedio: danoCalculado,
        cd: cdCalculada,
        resForte: Math.max(1, (Number(criaturaOrig.resForte || criaturaOrig.forte || refOrig.res_forte) + deltaResF)),
        resMedia: Math.max(0, (Number(criaturaOrig.resMedia || criaturaOrig.media || refOrig.res_media) + deltaResM)),
        resFraca: Math.max(-2, (Number(criaturaOrig.resFraca || criaturaOrig.fraca || refOrig.res_fraca) + deltaResW))
    };
}

function formatarNumeroNDParaNumeroTexto(n) {
    return formatarNumeroNDParaTextoJS(n);
}

function calcularNDTotalEncontroCombinadoJS(listaCriaturas) {
    const vivosOuTodos = (listaCriaturas || []).filter(Boolean);
    if (vivosOuTodos.length === 0) return '1';
    if (vivosOuTodos.length === 1) {
        return String(vivosOuTodos[0].ndTexto || vivosOuTodos[0].nd || '1');
    }
    // Regra Oficial de Encontros Múltiplos (Cap. 7, p. 282): dobrar o número de criaturas soma +2 ao ND efetivo
    let somaPotencia = 0;
    vivosOuTodos.forEach(c => {
        const ndNum = parseNDStringParaNumeroJS(c.ndTexto || c.nd || 1);
        somaPotencia += Math.pow(2, ndNum / 2);
    });
    const ndEquiv = 2 * Math.log2(Math.max(1, somaPotencia));
    return formatarNumeroNDParaTextoJS(Math.round(ndEquiv));
}

function verificarConflitoEstiloJS(poderesAtuais, cand, classeObj, arma, escudo) {
    const nomeC = (cand.nome || '').trim().toLowerCase();
    const possuidos = new Set((poderesAtuais || []).map(p => (p.nome || '').trim().toLowerCase()));

    if ((nomeC === 'raio elemental' || nomeC === 'raio poderoso') && !possuidos.has('raio arcano')) {
        return { ok: false, motivo: "Requer o poder base 'Raio Arcano'" };
    }
    if (nomeC === 'ambidestria' && !possuidos.has('estilo de duas armas')) {
        return { ok: false, motivo: "Requer 'Estilo de Duas Armas'" };
    }
    // Exclusão mútua estrita no Inventor entre Armeiro (corpo a corpo) e Balística (armas de fogo/distância)
    const subArmaL = ((arma && arma.subcategoria) ? arma.subcategoria : '').toLowerCase();
    const nmArmaL = ((arma && arma.nome) ? arma.nome : '').toLowerCase();
    const armaEhDistancia = subArmaL.includes('distância') || subArmaL.includes('fogo') || /mosquete|pistola|arco|besta/.test(nmArmaL);
    if (nomeC === 'armeiro') {
        if (possuidos.has('balística')) return { ok: false, motivo: "Conflito de Especialização (Inventor): já possui 'Balística' (armas à distância)" };
        if (armaEhDistancia) return { ok: false, motivo: "'Armeiro' aplica-se a armas corpo a corpo; build atual usa arma à distância/de fogo" };
    }
    if (nomeC === 'balística') {
        if (possuidos.has('armeiro')) return { ok: false, motivo: "Conflito de Especialização (Inventor): já possui 'Armeiro' (armas corpo a corpo)" };
        if (arma && !armaEhDistancia) return { ok: false, motivo: "'Balística' exige arma à distância/de fogo; build atual usa arma corpo a corpo" };
    }
    // Separação oficial 3 vias — Corpo a Corpo vs. Disparo vs. Arremesso (JdA Cap. 2, p. 124–129; Golpe Pessoal liberado em todos!)
    const propArmaL = ((arma && arma.efeito_propriedades) ? arma.efeito_propriedades : '').toLowerCase();
    const armaEhArremesso = subArmaL.includes('arremesso') || propArmaL.includes('arremesso') || /azagaia|machadinha|shuriken|dardo|tridente|lança|adaga/.test(nmArmaL);
    const armaEhDisparo = (armaEhDistancia && !subArmaL.includes('arremesso')) || /arco|besta|mosquete|pistola|funda/.test(nmArmaL);
    const PODERES_EXCLUSIVOS_CORPO_V87 = [
        'ataque poderoso', 'trespassar', 'ataque pesado', 'ataque preciso', 'valentão',
        'derrubar aprimorado', 'quebrar aprimorado', 'desarmar aprimorado', 'tornado de dor',
        'ataque reflexo', 'kiai divino', 'espada solar', 'espada justiceira',
        'frenesi', 'golpe poderoso', 'estilo de duas mãos', 'estilo de uma arma',
        'estilo de duas armas', 'estilo de arma longa', 'estilo desarmado', 'piqueiro', 'acuidade com arma'
    ];
    const PODERES_EXCLUSIVOS_DISPARO_V87 = ['estilo de disparo', 'arqueiro', 'balística'];
    const PODERES_EXCLUSIVOS_ARREMESSO_V87 = ['estilo de arremesso', 'arremesso potente', 'arremesso múltiplo'];
    const PODERES_DISTANCIA_OU_ARREMESSO_V87 = ['disparo rápido', 'disparo preciso', 'mira apurada'];

    if (armaEhDisparo && PODERES_EXCLUSIVOS_CORPO_V87.includes(nomeC)) {
        return { ok: false, motivo: `Conflito Corpo a Corpo vs. Disparo (JdA): '${cand.nome}' aplica-se apenas a ataques corpo a corpo; build atual usa '${arma ? arma.nome : 'arma de disparo'}'` };
    }
    if (armaEhArremesso && subArmaL.includes('distância') && PODERES_EXCLUSIVOS_CORPO_V87.includes(nomeC)) {
        const excecaoArremesso = (nomeC === 'ataque poderoso' && possuidos.has('arremesso potente')) || nomeC === 'acuidade com arma';
        if (!excecaoArremesso) {
            return { ok: false, motivo: `Conflito Arremesso (JdA): '${cand.nome}' exige corpo a corpo (ou Arremesso Potente para Ataque Poderoso)` };
        }
    }
    if (arma && !armaEhDisparo && PODERES_EXCLUSIVOS_DISPARO_V87.includes(nomeC)) {
        return { ok: false, motivo: `Conflito Disparo (JdA): '${cand.nome}' exige arma de disparo/fogo; build atual usa '${arma.nome}'` };
    }
    if (arma && !armaEhArremesso && PODERES_EXCLUSIVOS_ARREMESSO_V87.includes(nomeC)) {
        return { ok: false, motivo: `Conflito Arremesso (JdA): '${cand.nome}' exige arma de arremesso (ex.: Azagaia, Machadinha, Lança, Adaga); build atual usa '${arma.nome}'` };
    }
    // Disparo Rápido (JdA p. 126) EXIGE recarregar a arma como Ação Livre!
    if (nomeC === 'disparo rápido' && arma) {
        const ehFogoOuBestaPes = subArmaL.includes('fogo') || /pistola|mosquete|besta pesada/.test(nmArmaL);
        const ehBestaLeve = /besta leve/.test(nmArmaL);
        if (ehFogoOuBestaPes) {
            return { ok: false, motivo: `Regra Oficial de Recarga (JdA p. 126/148): '${arma.nome}' recarrega como Ação Padrão (ou Movimento com Saque Rápido), não permitindo 'Disparo Rápido' (exige recarga Livre)` };
        }
        if (ehBestaLeve && !possuidos.has('saque rápido')) {
            return { ok: false, motivo: `Regra Oficial de Recarga (JdA p. 126): 'Besta leve' exige 'Saque Rápido' para recarregar como Ação Livre e usar 'Disparo Rápido'` };
        }
    }
    if (arma && !armaEhDisparo && !armaEhArremesso && PODERES_DISTANCIA_OU_ARREMESSO_V87.includes(nomeC)) {
        return { ok: false, motivo: `Conflito Distância vs. Corpo a Corpo (JdA): '${cand.nome}' exige arma à distância ou arremesso; build atual usa '${arma.nome}'` };
    }

    let grupoCand = null;
    for (const [g, lista] of Object.entries(GRUPOS_ESTILO_JS)) {
        if (lista.includes(nomeC)) { grupoCand = g; break; }
    }
    const estiloArma = identificarEstiloArmaJS(arma, escudo, poderesAtuais);

    if (grupoCand) {
        if (nomeC.startsWith('estilo de ')) {
            for (const pPos of possuidos) {
                if (pPos.startsWith('estilo de ') && pPos !== nomeC) {
                    return { ok: false, motivo: `Conflito de Postura: já possui '${pPos}'` };
                }
            }
        }
        const compativeis = new Set([grupoCand]);
        for (const [outroG, listaOutros] of Object.entries(GRUPOS_ESTILO_JS)) {
            if (compativeis.has(outroG)) continue;
            for (const pOut of listaOutros) {
                if (possuidos.has(pOut)) {
                    return { ok: false, motivo: `Conflito de Estilo CSP: '${cand.nome}' (${grupoCand}) não combina com '${pOut}' (${outroG})` };
                }
            }
        }
        if (grupoCand === 'ARMA_LONGA_HASTE' && estiloArma !== 'ARMA_LONGA_HASTE') { return { ok: false, motivo: `'${cand.nome}' exige arma alongada/de haste (Alabarda, Pique)` }; }
        if (grupoCand === 'DUAS_MAOS' && !['DUAS_MAOS', 'ARMA_LONGA_HASTE'].includes(estiloArma)) {
            return { ok: false, motivo: `'${cand.nome}' exige arma corpo a corpo de duas mãos` };
        }
        if (grupoCand === 'ARQUERIA_DISPARO' && estiloArma !== 'ARQUERIA_DISPARO') {
            return { ok: false, motivo: `'${cand.nome}' exige arma de disparo à distância` };
        }
        if (grupoCand === 'DUAS_ARMAS' && ['DUAS_MAOS', 'ARMA_LONGA_HASTE', 'ARMA_E_ESCUDO', 'ARQUERIA_DISPARO'].includes(estiloArma)) {
            return { ok: false, motivo: `'${cand.nome}' incompatível com ${estiloArma}` };
        }
        if (grupoCand === 'ARMA_E_ESCUDO' && !escudo) {
            return { ok: false, motivo: `'${cand.nome}' exige escudo equipado` };
        }
        if (grupoCand === 'UMA_ARMA_ESGRIMA' && ['DUAS_MAOS', 'ARMA_LONGA_HASTE', 'ARMA_E_ESCUDO', 'ARQUERIA_DISPARO'].includes(estiloArma)) {
            return { ok: false, motivo: `'${cand.nome}' exige arma leve/ágil sem escudo` };
        }
    }
    if (estiloArma === 'ARQUERIA_DISPARO' && PODERES_CORPO_A_CORPO_JS.has(nomeC)) {
        return { ok: false, motivo: `'${cand.nome}' é exclusivo para corpo a corpo` };
    }
    if (classeObj && classeObj.nome.toLowerCase() === 'arcanista') {
        if (PODERES_CORPO_A_CORPO_JS.has(nomeC) || ['DUAS_MAOS', 'ARQUERIA_DISPARO', 'DUAS_ARMAS', 'ARMA_E_ESCUDO'].includes(grupoCand)) {
            return { ok: false, motivo: `'${cand.nome}' sem sinergia com Conjurador Arcano` };
        }
    }
    return { ok: true, motivo: 'OK' };
}

function detalharAprimoramentoMagiaJS(magia, nivel, classeObj, atrFinais, poderes, itens, caminhoArcanista) {
    const custoBase = ({ 1: 1, 2: 3, 3: 6, 4: 10, 5: 15 })[magia.circulo] || 1;
    const atribChave = obterAtributoChaveMagiaJS(classeObj, caminhoArcanista).sigla;
    const valAtrib = Math.max(0, atrFinais[atribChave] || 0);
    const temMagiaIlimitada = (poderes || []).some(p => p.nome.toLowerCase() === 'magia ilimitada');
    const temCajado = (itens || []).some(i => ['cajado arcano', 'orbe cristalino'].includes(i.nome.toLowerCase()));
    const temFoco = (poderes || []).some(p => p.nome.toLowerCase() === 'foco em magia');
    const temArcBat = (poderes || []).some(p => p.nome.toLowerCase() === 'arcano de batalha');

    const limitePM = nivel + (temMagiaIlimitada ? valAtrib : 0) + (temCajado ? 1 : 0);
    const redutor = temFoco ? 1 : 0;
    const orcamento = Math.max(0, limitePM - Math.max(1, custoBase - redutor));
    const bonusFixo = temArcBat ? valAtrib : 0;
    const strArc = bonusFixo > 0 ? ` + ${bonusFixo} (Arcano de Batalha)` : '';
    const nl = magia.nome.toLowerCase();

    let pmGasto = Math.min(limitePM, custoBase);
    let formulaFinal = 'Efeito de Controle / Utilidade';
    let aprimDesc = `Custo Base: ${custoBase} PM (Limite atual: ${limitePM} PM)`;
    let danoMedio = 0;

    const circMaxClasse = (typeof circuloMaximoPermitido === 'function') ? circuloMaximoPermitido(classeObj, nivel) : Math.min(5, 1 + Math.floor((nivel - 1) / 4));
    if (nl.includes('seta infalível')) {
        // Regra Oficial T20 JdA (p. 206): aprimoramento para lanças (1d8+1) EXIGE 2º círculo!
        if (orcamento >= 2 && circMaxClasse >= 2) {
            const extras = Math.floor((orcamento - 2) / 2);
            const qtdLancas = 2 + extras;
            pmGasto = Math.max(1, custoBase + 2 + extras * 2 - redutor);
            danoMedio = qtdLancas * 5.5 + bonusFixo;
            formulaFinal = `${qtdLancas}d8 + ${qtdLancas + bonusFixo} essência (Acerto Automático!)`;
            aprimDesc = `Base 1 PM (2 setas) + 2 PM (lanças 1d8+1 · Req. 2ºC) + ${extras * 2} PM (+${extras} lanças)${strArc} [Total: ${pmGasto} PM]`;
        } else if (orcamento >= 2) {
            // No 1º círculo, só pode usar o aprimoramento de +2 PM para mudar para 3 setas (ou +1 seta) sem lanças 1d8+1
            const qtdSetas = 2 + Math.min(2, Math.floor(orcamento / 2));
            pmGasto = Math.max(1, custoBase + (qtdSetas - 2) * 2 - redutor);
            danoMedio = qtdSetas * 3.5 + bonusFixo;
            formulaFinal = `${qtdSetas}d4 + ${qtdSetas + bonusFixo} essência (1º Círculo — Acerto Automático)`;
            aprimDesc = `Base 1 PM (2 setas 1d4+1) + ${(qtdSetas - 2) * 2} PM (+${qtdSetas - 2} setas; lanças 1d8+1 requerem 2ºC)${strArc} [Total: ${pmGasto} PM]`;
        } else {
            pmGasto = Math.max(1, custoBase - redutor);
            danoMedio = 2 * 3.5 + bonusFixo;
            formulaFinal = `2d4 + ${2 + bonusFixo} essência`;
            aprimDesc = `Base 1 PM (2 setas 1d4+1)${strArc}`;
        }
    } else if (nl.includes('toque chocante') || nl.includes('infligir ferimentos')) {
        const dados = 2 + orcamento;
        const fixo = 2 + orcamento + bonusFixo;
        pmGasto = custoBase + orcamento - redutor;
        danoMedio = dados * 4.5 + fixo;
        formulaFinal = `${dados}d8 + ${fixo} (${nl.includes('toque') ? 'eletricidade' : 'trevas'})`;
        aprimDesc = `Base 1 PM (2d8+2) + ${orcamento} PM (+${orcamento}d8+${orcamento})${strArc} [Total: ${pmGasto} PM]`;
    } else if (nl.includes('explosão de chamas') || nl.includes('jato corrosivo')) {
        const dados = 2 + orcamento;
        pmGasto = custoBase + orcamento - redutor;
        danoMedio = dados * 3.5 + bonusFixo;
        formulaFinal = `${dados}d6${bonusFixo ? ' + ' + bonusFixo : ''} (${nl.includes('chamas') ? 'fogo' : 'ácido'} em área)`;
        aprimDesc = `Base 1 PM (2d6) + ${orcamento} PM (+${orcamento}d6)${strArc} [Total: ${pmGasto} PM]`;
    } else if (nl.includes('adaga mental')) {
        const apl = Math.floor(orcamento / 2);
        const dados = 2 + apl;
        pmGasto = custoBase + apl * 2 - redutor;
        danoMedio = dados * 3.5 + bonusFixo;
        formulaFinal = `${dados}d6${bonusFixo ? ' + ' + bonusFixo : ''} psíquico + Atordoado 1 rod.`;
        aprimDesc = `Base 1 PM (2d6) + ${apl * 2} PM (+${apl}d6)${strArc} [Total: ${pmGasto} PM]`;
    } else if (nl.includes('bola de fogo') || nl === 'relâmpago' || nl.includes('toque vamp')) {
        const apl = Math.floor(orcamento / 2);
        const dados = 6 + apl * 2;
        pmGasto = custoBase + apl * 2 - redutor;
        danoMedio = dados * 3.5 + bonusFixo;
        const tipoD = nl.includes('bola') ? 'fogo em esfera 6m' : (nl.includes('relâmpago') ? 'eletricidade linha 30m' : 'trevas (cura metade)');
        formulaFinal = `${dados}d6${bonusFixo ? ' + ' + bonusFixo : ''} (${tipoD})`;
        aprimDesc = `Base 3 PM (6d6) + ${apl * 2} PM (+${apl * 2}d6 via +${apl}×[+2 PM])${strArc} [Total: ${pmGasto} PM]`;
    } else if (nl.includes('curar ferimentos')) {
        const dados = 2 + orcamento;
        const fixoC = 2 + orcamento;
        pmGasto = custoBase + orcamento - redutor;
        danoMedio = dados * 4.5 + fixoC;
        formulaFinal = `Cura ${dados}d8 + ${fixoC} PV (Média: ${danoMedio.toFixed(1)} PV)`;
        aprimDesc = `Base 1 PM (2d8+2) + ${orcamento} PM (+${orcamento}d8+${orcamento} PV) [Total: ${pmGasto} PM]`;
    } else if (nl.includes('armadura arcana')) {
        const ex = Math.floor(orcamento / 2);
        pmGasto = custoBase + ex * 2 - redutor;
        formulaFinal = `+${5 + ex} na Defesa pela cena (ou +${10 + ex} reação)`;
        aprimDesc = `Base 1 PM (+5 Def) + ${ex * 2} PM (+${ex} Def adicional) [Total: ${pmGasto} PM]`;
    } else if (nl.includes('campo de força')) {
        const pvT = 30 + orcamento * 5;
        pmGasto = custoBase + orcamento - redutor;
        formulaFinal = `${pvT} PV temporários (ou RD ${pvT} reação)`;
        aprimDesc = `Base 3 PM (30 PV/RD) + ${orcamento} PM (+${orcamento * 5} PV/RD) [Total: ${pmGasto} PM]`;
    } else {
        const efStr = String(magia.efeito_e_aprimoramentos || '');
        const ehControleSemDano = /teia|escuridão|escuridao|névoa|nevoa|sono|enfeitiçar|comando|área escorregadia|leque cromático|imagem espelhada|disfarce/i.test(nl);
        const mD = !ehControleSemDano ? (efStr.match(/(?:causa|sofre|dano de)[^.]{0,18}(\d+)d(\d+)/i) || efStr.match(/(\d+)d(\d+)\s*(?:pontos de )?dano/i)) : null;
        if (mD) {
            const qd = parseInt(mD[1], 10);
            const fd = parseInt(mD[2], 10);
            const temEscalaDano = /aumenta o dano|\+\d+d\d+/i.test(efStr) && circMaxClasse >= 1;
            const apl = temEscalaDano ? Math.floor(orcamento / 2) : 0;
            const qf = qd + apl;
            pmGasto = Math.max(1, custoBase + apl * 2 - redutor);
            danoMedio = qf * ((fd + 1) / 2) + bonusFixo;
            formulaFinal = `${qf}d${fd}${bonusFixo ? ' + ' + bonusFixo : ''}`;
            aprimDesc = apl > 0
                ? `Base ${custoBase} PM (${qd}d${fd}) + ${apl * 2} PM (+${apl}d${fd})${strArc} [Total: ${pmGasto} PM]`
                : `Base ${custoBase} PM (${qd}d${fd})${strArc}`;
        }
    }
    // Classificação Oficial de Magias de Área (Capítulo 4, pp. 172-173: Esfera, Cone, Cilindro, Linha)
    const alcLow = (magia.alcance || '').toLowerCase();
    const efLow = (magia.efeito_e_aprimoramentos || '').toLowerCase();
    let ehArea = false;
    let alvosAreaPadrao = 1;
    let geometriaArea = 'Alvo Único (1 criatura)';

    if (/bola de fogo|chuva de meteoros|terremoto|cólera de azgher|colera de azgher|barragem elemental|tempestade divina/.test(nl)) {
        ehArea = true;
        alvosAreaPadrao = 4;
        geometriaArea = 'Esfera 6m / Área Ampla (Padrão: 4 alvos)';
    } else if (/explosão de chamas|explosao de chamas|sopro das uivantes|mata-dragão|mata-dragao|erupções glaciais|erupcoes glaciais|coluna de chamas|relâmpago|relampago|raio solar|jato corrosivo|trovão|trovao/.test(nl)) {
        ehArea = true;
        alvosAreaPadrao = 3;
        geometriaArea = 'Cone / Cilindro / Linha (Padrão: 3 alvos)';
    } else if (/esfera|cone|cilindro|linha|área|area|explosão|explosao|criaturas na área/.test(efLow + ' ' + alcLow) && danoMedio > 0 && !formulaFinal.toLowerCase().startsWith('cura ')) {
        ehArea = true;
        alvosAreaPadrao = 3;
        geometriaArea = 'Área de Efeito (Padrão: 3 alvos)';
    }

    // Se o usuário selecionou um número customizado de alvos para magias em área na interface da Ficha:
    const selAlvosOverride = (typeof document !== 'undefined') ? document.getElementById('sel-ficha-alvos-area-magia') : null;
    const valOverride = selAlvosOverride ? parseInt(selAlvosOverride.value || '0', 10) : 0;
    const alvosEfetivosArea = ehArea ? (valOverride > 0 ? valOverride : alvosAreaPadrao) : 1;

    // Bônus de Esotérico Superior (Energético +1d6, Poderoso +1 CD, Tollon -1 PM)
    const stGlobalMag = (typeof window !== 'undefined' && window.__ULTIMO_ESTADO_FICHA__) ? window.__ULTIMO_ESTADO_FICHA__ : null;
    const resArsMag = (stGlobalMag && typeof calcularResumoArsenalSuperiorEMagicoJS === 'function') ? calcularResumoArsenalSuperiorEMagicoJS(stGlobalMag) : null;
    if (resArsMag && resArsMag.bonusDanoMagiaMedia > 0 && danoMedio > 0 && !formulaFinal.toLowerCase().startsWith('cura ')) {
        formulaFinal += ' + 1d6 (Esotérico Energético)';
    }

    let danoMin1Alvo = 0;
    let danoMax1Alvo = 0;
    let danoMedio1Alvo = +danoMedio.toFixed(1);
    if (danoMedio > 0 && typeof calcularDanoMinMaxMedioFormulaJS === 'function') {
        const stM = calcularDanoMinMaxMedioFormulaJS(formulaFinal, 1, false);
        if (stM.max > 0) {
            danoMin1Alvo = stM.min;
            danoMax1Alvo = stM.max;
            danoMedio1Alvo = stM.medio;
        }
    }

    const danoMinArea = +(danoMin1Alvo * alvosEfetivosArea).toFixed(1);
    const danoMaxArea = +(danoMax1Alvo * alvosEfetivosArea).toFixed(1);
    const danoMedioArea = +((danoMaxArea + danoMinArea) / 2.0).toFixed(1);
    // Dano médio considerando teste de resistência que reduz à metade (ex.: 50% dos alvos passam, sofrendo metade -> fator 0.75)
    const resTxtLow = (magia.resistencia || '').toLowerCase();
    const reduzMetade = resTxtLow.includes('reduz à metade') || resTxtLow.includes('reduz a metade');
    const danoMedioAreaResistencia = reduzMetade ? +(danoMedioArea * 0.75).toFixed(1) : danoMedioArea;

    return {
        pmGasto,
        limitePM,
        formulaFinal,
        aprimDesc,
        danoMin1Alvo,
        danoMax1Alvo,
        danoMedio: danoMedio1Alvo,
        ehArea,
        alvosAreaPadrao,
        alvosEfetivosArea,
        geometriaArea,
        danoMinArea,
        danoMaxArea,
        danoMedioArea,
        danoMedioAreaResistencia
    };
}

// ============================================================================
// SISTEMA OFICIAL DE TESOURO INICIAL POR NÍVEL (TABELA 3-1, P. 140),
// ITENS SUPERIORES (TABELA 3-6, P. 164), MATERIAIS ESPECIAIS (TABELA 3-8, P. 166)
// E ITENS MÁGICOS / ACESSÓRIOS (CAPÍTULO 8, TABELA 8-4, PP. 334-347)
// + FÓRMULA EXATA DE DANO MÉDIO = (DANO MÁXIMO + DANO MÍNIMO) / 2
// ============================================================================
const TABELA_DINHEIRO_INICIAL_T20 = {
    1: 14, 2: 300, 3: 600, 4: 1000, 5: 2000,
    6: 3000, 7: 5000, 8: 7000, 9: 10000, 10: 13000,
    11: 19000, 12: 27000, 13: 36000, 14: 49000, 15: 66000,
    16: 88000, 17: 110000, 18: 150000, 19: 200000, 20: 260000
};

const CUSTO_MELHORIAS_SUPERIOR_T20 = { 0: 0, 1: 300, 2: 3000, 3: 9000, 4: 18000 };
const CUSTO_ENCANTOS_MAGICOS_T20 = { 0: 0, 1: 18000, 2: 36000, 3: 72000 };

const CATALOGO_MELHORIAS_ARMA_T20 = [
    { id: 'CERTEIRA', nome: 'Certeira (+1 no Teste de Ataque — 1 melhoria, p. 165)', melhorias: 1, atq: 1, dano: 0, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'PUNGENTE', nome: 'Pungente (+2 no Teste de Ataque — req. Certeira, 2 melhorias, p. 165)', melhorias: 2, atq: 2, dano: 0, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'CRUEL', nome: 'Cruel (+1 na Rolagem de Dano — 1 melhoria, p. 165)', melhorias: 1, atq: 0, dano: 1, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'ATROZ', nome: 'Atroz (+2 na Rolagem de Dano — req. Cruel, 2 melhorias, p. 165)', melhorias: 2, atq: 0, dano: 2, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'PRECISA', nome: 'Precisa (+1 na Margem de Ameaça — 1 melhoria, p. 165)', melhorias: 1, atq: 0, dano: 0, marg: 1, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'MACICA', nome: 'Maciça (+1x no Multiplicador de Crítico — 1 melhoria, p. 165)', melhorias: 1, atq: 0, dano: 0, marg: 0, mult: 1, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'EQUILIBRADA', nome: 'Equilibrada (+2 em Testes de Manobras de Combate — 1 melhoria, p. 165)', melhorias: 1, atq: 0, dano: 0, marg: 0, mult: 0, redPmAtq: 0, manobra: 2, dadoExtra: '', pag: 'p. 165' },
    { id: 'HARMONIZADA', nome: 'Harmonizada (-1 PM em Habilidade de Ataque — 1 melhoria, p. 165)', melhorias: 1, atq: 0, dano: 0, marg: 0, mult: 0, redPmAtq: 1, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'INJECAO_ALQUIMICA', nome: 'Injeção Alquímica (+1d6 Fogo/Ácido ou Veneno — 1 melhoria, p. 165)', melhorias: 1, atq: 0, dano: 0, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '1d6', pag: 'p. 165' },
    { id: 'MIRA_TELESCOPICA', nome: 'Mira Telescópica (Aumenta alcance em 1 passo e dobra Ataque Furtivo — 1 melh., p. 165)', melhorias: 1, atq: 0, dano: 0, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'DISCRETA', nome: 'Discreta (-1 espaço e +5 em Furtividade p/ ocultar — 1 melhoria, p. 165)', melhorias: 1, atq: 0, dano: 0, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'BANHADA_OURO', nome: 'Banhada a Ouro (+2 em Diplomacia — 1 melhoria, p. 164)', melhorias: 1, atq: 0, dano: 0, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 164' },
    { id: 'CRAVEJADA_GEMAS', nome: 'Cravejada de Gemas (+2 em Enganação ou Nobreza — 1 melhoria, p. 165)', melhorias: 1, atq: 0, dano: 0, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' },
    { id: 'MACABRA', nome: 'Macabra (+2 em Intimidação e -2 em Diplomacia — 1 melhoria, p. 165)', melhorias: 1, atq: 0, dano: 0, marg: 0, mult: 0, redPmAtq: 0, manobra: 0, dadoExtra: '', pag: 'p. 165' }
];

const CATALOGO_MATERIAIS_ARMA_T20 = [
    { id: 'NENHUM', nome: 'Aço Comum (Sem Material Especial — T$ 0)', preco: 0, melhoriasReq: 0, passo: 0, marg: 0, danoFixo: 0, dadoExtra: '', redPm: 0, ignoraRd: 0, pag: 'p. 166' },
    { id: 'TOLLON', nome: 'Madeira Tollon (+T$ 200 · Conta como 1 melhoria: arma mágica e -1 PM em habilidades de ataque)', preco: 200, melhoriasReq: 1, passo: 0, marg: 0, danoFixo: 0, dadoExtra: '', redPm: 1, ignoraRd: 0, pag: 'p. 167' },
    { id: 'GELO_ETERNO', nome: 'Gelo Eterno (+T$ 600 · Conta como 1 melhoria: +2 de Dano de Frio)', preco: 600, melhoriasReq: 1, passo: 0, marg: 0, danoFixo: 2, dadoExtra: '', redPm: 0, ignoraRd: 0, pag: 'p. 167' },
    { id: 'MITRAL', nome: 'Mitral (+T$ 1.500 · Conta como 1 melhoria: +1 na Margem de Ameaça e -1 espaço)', preco: 1500, melhoriasReq: 1, passo: 0, marg: 1, danoFixo: 0, dadoExtra: '', redPm: 0, ignoraRd: 0, pag: 'p. 167' },
    { id: 'MATERIA_VERMELHA', nome: 'Matéria Vermelha (+T$ 1.500 · Conta como 1 melhoria: +1d6 de Dano extra; -2 CAR)', preco: 1500, melhoriasReq: 1, passo: 0, marg: 0, danoFixo: 0, dadoExtra: '1d6', redPm: 0, ignoraRd: 0, pag: 'p. 167' },
    { id: 'ADAMANTE', nome: 'Adamante (+T$ 1.500 · Conta como 1 melhoria: Aumenta o Dano da arma em +1 Passo)', preco: 1500, melhoriasReq: 1, passo: 1, marg: 0, danoFixo: 0, dadoExtra: '', redPm: 0, ignoraRd: 0, pag: 'p. 166' },
    { id: 'ACO_RUBI', nome: 'Aço-Rubi (+T$ 3.000 · Conta como 1 melhoria: Ignora 10 de RD e imunidade a crítico)', preco: 3000, melhoriasReq: 1, passo: 0, marg: 0, danoFixo: 0, dadoExtra: '', redPm: 0, ignoraRd: 10, pag: 'p. 166' }
];

const CATALOGO_ENCANTOS_ARMA_T20 = [
    { id: 'FORMIDAVEL', nome: 'Formidável (+2 no Ataque e +2 no Dano — 1 encanto, p. 336)', encantos: 1, atq: 2, dano: 2, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'MAGNIFICA', nome: 'Magnífica (+4 no Ataque e +4 no Dano — req. Formidável, 2 encantos, p. 336)', encantos: 2, atq: 4, dano: 4, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'ENERGETICA', nome: 'Energética (+4 no Ataque, ignora 20 RD e dano de Essência — req. Formidável, 2 enc., p. 336)', encantos: 2, atq: 4, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'AMEACADORA', nome: 'Ameaçadora (Duplica a Margem de Ameaça da arma — 1 encanto, p. 335)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: true, lancinante: false, veloz: false, pag: 'p. 335' },
    { id: 'DILACERANTE', nome: 'Dilacerante (+10 de Dano adicional em Acertos Críticos — 1 encanto, p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'LANCINANTE', nome: 'Lancinante (+10 no Crítico e multiplica bônus numérico fixo no Crítico — 2 enc., p. 336)', encantos: 2, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: true, veloz: false, pag: 'p. 336' },
    { id: 'FLAMEJANTE', nome: 'Flamejante (+1d6 de Dano de Fogo — 1 encanto, p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '1d6', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'ELETRICA', nome: 'Elétrica (+1d6 de Dano de Eletricidade — 1 encanto, p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '1d6', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'CONGELANTE', nome: 'Congelante (+1d6 de Dano de Frio — 1 encanto, p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '1d6', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'CORROSIVA', nome: 'Corrosiva (+1d6 de Dano de Ácido — 1 encanto, p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '1d6', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'TUMULAR', nome: 'Tumular (+1d8 de Dano de Trevas — 1 encanto, p. 337)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '1d8', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 337' },
    { id: 'VENENOSA', nome: 'Venenosa (+1d12 de Dano de Veneno — 1 encanto, p. 337)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '1d12', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 337' },
    { id: 'PIEDOSA', nome: 'Piedosa (+1d8 de Dano Não Letal sem penalidade — 1 encanto, p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '1d8', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'SAGRADA', nome: 'Sagrada (+2 Ataque e +2d6 Luz vs Mal/Mortos-Vivos/Abissais — 1 encanto, p. 337)', encantos: 1, atq: 2, dano: 0, def: 0, dadoExtra: '2d6', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 337' },
    { id: 'PROFANA', nome: 'Profana (+2 Ataque e +2d6 Trevas vs Devotos do Bem/Aggelus — 1 encanto, p. 336)', encantos: 1, atq: 2, dano: 0, def: 0, dadoExtra: '2d6', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'ANTICRIATURA', nome: 'Anticriatura (+4 Ataque e +4d8 Dano por 1 PM vs Tipo Escolhido — 1 enc., p. 335)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 335' },
    { id: 'ASSASSINA', nome: 'Assassina (Dados de Ataque Furtivo sobem p/ d8 ou +2d6 Furtivo por 1 PM — 1 enc., p. 335)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '2d6', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 335' },
    { id: 'CACADORA', nome: 'Caçadora (Ignora Camuflagem/Cobertura Leve e +1 Passo Alcance — 1 enc., p. 335)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 335' },
    { id: 'DANCARINA', nome: 'Dançarina (Flutua e ataca sozinha 1x/rodada por 1 PM — 1 encanto, p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: true, pag: 'p. 336' },
    { id: 'DEFENSORA_ARMA', nome: 'Defensora (+2 na Defesa enquanto empunhada — 1 encanto, p. 336)', encantos: 1, atq: 0, dano: 0, def: 2, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'DESTRUIDORA', nome: 'Destruidora (+2d8 Dano e ignora 20 RD vs Construtos/Objetos — 1 enc., p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'DRENANTE', nome: 'Drenante (+2d10 Trevas e cura PV no Crítico — 1 encanto, p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'EXCRUCIANTE', nome: 'Excruciante (Deixa o alvo Fraco no 1º acerto e Debilitado no 2º — 1 enc., p. 336)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 336' },
    { id: 'SANGUINARIA', nome: 'Sanguinária (Causa Sangramento 1d6 cumulativo a cada acerto — 1 enc., p. 337)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '1d6', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 337' },
    { id: 'TROVEJANTE', nome: 'Trovejante (Atordoa o alvo por 1 rodada em Acerto Crítico — 1 enc., p. 337)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: false, pag: 'p. 337' },
    { id: 'VELOZ', nome: 'Veloz (Permite +1 ataque extra na ação Agredir por 1 PM — 1 encanto, p. 337)', encantos: 1, atq: 0, dano: 0, def: 0, dadoExtra: '', duplicaMargem: false, lancinante: false, veloz: true, pag: 'p. 337' }
];

const CATALOGO_UPGRADES_ARMADURA_T20 = [
    { id: 'ARM_NORMAL', nome: 'Armadura / Escudo Padrão (Sem Melhorias — T$ 0)', preco: 0, def: 0, penRed: 0, res: 0, rd: 0, pag: 'p. 153' },
    { id: 'ARM_REFORCADA_1', nome: '[Superior 1 Melh.] Reforçada (+1 na Defesa, +1 Penalidade — +T$ 300, p. 165)', preco: 300, def: 1, penRed: -1, res: 0, rd: 0, pag: 'p. 165' },
    { id: 'ARM_AJUSTADA_1', nome: '[Superior 1 Melh.] Ajustada (-1 na Penalidade de Armadura — +T$ 300, p. 165)', preco: 300, def: 0, penRed: 1, res: 0, rd: 0, pag: 'p. 165' },
    { id: 'ARM_DELICADA_1', nome: '[Superior 1 Melh.] Delicada (Permite +1 DES na Defesa em armadura pesada — +T$ 300, p. 165)', preco: 300, def: 1, penRed: 0, res: 0, rd: 0, pag: 'p. 165' },
    { id: 'ARM_ESPINHOSA_1', nome: '[Superior 1 Melh.] Espinhosa (+1d6 perfuração ao agarrar / +1 passo no escudo — +T$ 300, p. 165)', preco: 300, def: 0, penRed: 0, res: 0, rd: 0, pag: 'p. 165' },
    { id: 'ARM_POLIDA_1', nome: '[Superior 1 Melh.] Polida (+5 na Defesa na 1ª rodada em luz — +T$ 300, p. 165)', preco: 300, def: 1, penRed: 0, res: 0, rd: 0, pag: 'p. 165' },
    { id: 'ARM_SELADA_1', nome: '[Superior 1 Melh.] Selada (+1 em todos os Testes de Resistência — +T$ 300, p. 166)', preco: 300, def: 0, penRed: 0, res: 1, rd: 0, pag: 'p. 166' },
    { id: 'ARM_SOB_MEDIDA_2', nome: '[Superior 2 Melh.] Sob Medida (-2 na Penalidade de Armadura — +T$ 3.000, p. 166)', preco: 3000, def: 0, penRed: 2, res: 0, rd: 0, pag: 'p. 166' },
    { id: 'ARM_REF_AJUST_2', nome: '[Superior 2 Melh.] Reforçada + Ajustada (+1 Defesa e zera pen. extra — +T$ 3.000, p. 165)', preco: 3000, def: 1, penRed: 0, res: 0, rd: 0, pag: 'p. 165' },
    { id: 'ARM_REF_SELADA_2', nome: '[Superior 2 Melh.] Reforçada + Selada (+1 Defesa e +1 Resistências — +T$ 3.000, p. 166)', preco: 3000, def: 1, penRed: 0, res: 1, rd: 0, pag: 'p. 166' },
    { id: 'ARM_REF_MITRAL_3', nome: '[Superior 3 Melh.] Reforçada + Selada + Mitral (+1 Def, +1 Res, -2 Pen., +2 DES — +T$ 10.500, p. 167)', preco: 10500, def: 2, penRed: 2, res: 1, rd: 0, pag: 'p. 167' },
    { id: 'ARM_ADAMANTE_3', nome: '[Superior 3 Melh.] Reforçada + Selada + Adamante (+1 Def, +1 Res, RD 5 — +T$ 12.000, p. 166)', preco: 12000, def: 1, penRed: 0, res: 1, rd: 5, pag: 'p. 166' },
    { id: 'ARM_ACO_RUBI_4', nome: '[Superior 4 Melh.] Reforçada + Selada + Sob Medida + Aço-Rubi (50% Ignorar Crítico — +T$ 24.000, p. 166)', preco: 24000, def: 1, penRed: 2, res: 1, rd: 0, pag: 'p. 166' },
    { id: 'ARM_MAG_DEFENSORA', nome: '[Encanto Mágico] Defensora (+2 Defesa — +T$ 18.000, p. 338)', preco: 18000, def: 2, penRed: 0, res: 0, rd: 0, pag: 'p. 338' },
    { id: 'ARM_MAG_PROTETORA', nome: '[Encanto Mágico] Protetora (+2 em Todas as Resistências — +T$ 18.000, p. 339)', preco: 18000, def: 0, penRed: 0, res: 2, rd: 0, pag: 'p. 339' },
    { id: 'ARM_MAG_FORTIFICADA', nome: '[Encanto Mágico] Fortificada (50% chance de ignorar Crítico/Furtivo — +T$ 18.000, p. 339)', preco: 18000, def: 0, penRed: 0, res: 0, rd: 0, pag: 'p. 339' },
    { id: 'ARM_MAG_ABENCOADA', nome: '[Encanto Mágico] Abençoada / Opaca (RD 10 Elemental/Trevas e +5 Res. — +T$ 18.000, p. 338)', preco: 18000, def: 0, penRed: 0, res: 1, rd: 5, pag: 'p. 338' },
    { id: 'ARM_MAG_ALADA', nome: '[Encanto Mágico] Alada / Sombria / Acrobática (Voo 12m ou +5 Perícia — +T$ 18.000, p. 338)', preco: 18000, def: 1, penRed: 2, res: 0, rd: 0, pag: 'p. 338' },
    { id: 'ARM_MAG_GUARDIA', nome: '[2 Encantos Mágicos] Guardiã (+4 na Defesa — +T$ 36.000, p. 339)', preco: 36000, def: 4, penRed: 0, res: 0, rd: 0, pag: 'p. 339' },
    { id: 'ARM_MAG_INVULNERAVEL', nome: '[2 Encantos Mágicos] Invulnerável (RD 5 Pesada / RD 2 Leve — +T$ 36.000, p. 339)', preco: 36000, def: 0, penRed: 0, res: 0, rd: 5, pag: 'p. 339' },
    { id: 'ARM_MAG_GUARDIA_ADAMANTE', nome: '[Maior + Superior] Guardiã + Protetora + Reforçada + Adamante (+5 Def, +3 Res, RD 10 — +T$ 84.000)', preco: 84000, def: 5, penRed: 1, res: 3, rd: 10, pag: 'p. 339' }
];

const CATALOGO_ESOTERICOS_T20 = [
    { id: 'ESO_NENHUM', nome: 'Sem Esotérico Superior (T$ 0)', preco: 0, cd: 0, limPm: 0, dadoMagia: 0, def: 0, redPmMag: 0, pag: 'p. 159' },
    { id: 'ESO_BASE', nome: 'Varinha Arcana / Cetro Elemental / Costela de Lich (+1 CD ou +1d6 — T$ 100 a T$ 300)', preco: 100, cd: 1, limPm: 0, dadoMagia: 0, def: 0, redPmMag: 0, pag: 'p. 160' },
    { id: 'ESO_PODEROSO_1', nome: '[1 Melh.] Esotérico Poderoso (+1 na CD de todas as Magias — T$ 400, p. 166)', preco: 400, cd: 1, limPm: 0, dadoMagia: 0, def: 0, redPmMag: 0, pag: 'p. 166' },
    { id: 'ESO_CANALIZADOR_1', nome: '[1 Melh.] Esotérico Canalizador (+1 no Limite de PM de Magias — T$ 400, p. 165)', preco: 400, cd: 0, limPm: 1, dadoMagia: 0, def: 0, redPmMag: 0, pag: 'p. 165' },
    { id: 'ESO_ENERGETICO_1', nome: '[1 Melh.] Esotérico Energético (+1d6 de Dano em Magias — T$ 400, p. 165)', preco: 400, cd: 0, limPm: 0, dadoMagia: 3.5, def: 0, redPmMag: 0, pag: 'p. 165' },
    { id: 'ESO_VIGILANTE_1', nome: '[1 Melh.] Esotérico Vigilante (+2 na Defesa enquanto empunhado — T$ 400, p. 166)', preco: 400, cd: 0, limPm: 0, dadoMagia: 0, def: 2, redPmMag: 0, pag: 'p. 166' },
    { id: 'ESO_POD_ENERG_2', nome: '[2 Melh.] Poderoso + Energético (+1 CD e +1d6 Dano em Magias — T$ 3.100, p. 166)', preco: 3100, cd: 1, limPm: 0, dadoMagia: 3.5, def: 0, redPmMag: 0, pag: 'p. 166' },
    { id: 'ESO_POD_TOLLON_2', nome: '[2 Melh.] Poderoso de Madeira Tollon (+1 CD e -1 PM em Magias — T$ 3.300, p. 167)', preco: 3300, cd: 1, limPm: 0, dadoMagia: 0, def: 0, redPmMag: 1, pag: 'p. 167' },
    { id: 'ESO_ARC_COMPLETO_3', nome: '[3 Melh.] Poderoso + Canalizador + Energético (+1 CD, +1 Lim PM, +1d6 Dano — T$ 9.100, p. 166)', preco: 9100, cd: 1, limPm: 1, dadoMagia: 3.5, def: 0, redPmMag: 0, pag: 'p. 166' },
    { id: 'ESO_ARC_SUPREMO_4', nome: '[4 Melh.] Poderoso + Canalizador + Energético + Mitral/Tollon (+2 CD, +1 Lim PM, +1d6, -1 PM — T$ 19.600)', preco: 19600, cd: 2, limPm: 1, dadoMagia: 3.5, def: 2, redPmMag: 1, pag: 'p. 166' }
];

// Encantos Mágicos de Esotéricos (T20 JdA Cap. 8, pp. 339–346)
const CATALOGO_ESOTERICOS_MAGICOS_T20 = [
    { id: 'ESOMAG_NENHUM', nome: 'Sem Encanto Mágico em Esotérico (T$ 0)', preco: 0, cd: 0, limPm: 0, dadoMagia: 0, redPmMag: 0, pag: 'p. 339' },
    { id: 'ESOMAG_MENOR', nome: '[Menor] Esotérico Encantado — Evocador Menor (+1 CD, +1 Limite PM, +1d6 Dano Magia — T$ 18.000)', preco: 18000, cd: 1, limPm: 1, dadoMagia: 3.5, redPmMag: 0, pag: 'p. 339' },
    { id: 'ESOMAG_MEDIO', nome: '[Médio] Cajado Evocador & Potencializador (+2 CD, +1 Limite PM, +2d6 Dano Magia — T$ 36.000)', preco: 36000, cd: 2, limPm: 1, dadoMagia: 7.0, redPmMag: 0, pag: 'p. 339' },
    { id: 'ESOMAG_MAIOR', nome: '[Maior] Cajado do Poder / Arquimago (+2 CD, +2 Limite PM, +3d6 Dano Magia, -1 PM — T$ 72.000)', preco: 72000, cd: 2, limPm: 2, dadoMagia: 10.5, redPmMag: 1, pag: 'p. 340' }
];

// Catalisadores Alquímicos Oficiais (T20 JdA Cap. 3, p. 161 — itens alquímicos não-mágicos)
const CATALOGO_CATALISADORES_T20 = [
    { id: 'CAT_NENHUM', nome: 'Sem Catalisador Alquímico (T$ 0)', preco: 0, cd: 0, limPm: 0, dadoMagia: 0, redPmMag: 0, curaExtra: 0, pag: 'p. 161' },
    { id: 'CAT_LIQUEN_LILAS', nome: 'Líquen Lilás (+1d6 Dano em Magias de Frio/Evocação — T$ 30/uso)', preco: 300, cd: 0, limPm: 0, dadoMagia: 3.5, redPmMag: 0, curaExtra: 0, pag: 'p. 161' },
    { id: 'CAT_OSSO_MONSTRO', nome: 'Osso de Monstro (+1 CD em Magias — T$ 60/uso)', preco: 600, cd: 1, limPm: 0, dadoMagia: 0, redPmMag: 0, curaExtra: 0, pag: 'p. 161' },
    { id: 'CAT_ESSENCIA_ABISSAL', nome: 'Essência Abissal (+1 Passo de Dano / +1d6 em Magias — T$ 150/uso)', preco: 1500, cd: 0, limPm: 0, dadoMagia: 5.5, redPmMag: 0, curaExtra: 0, pag: 'p. 161' },
    { id: 'CAT_PO_AZUL_ESSENCIA', nome: 'Kit Alquímico (Essência Abissal + Osso de Monstro + Pó Azul: +1 CD, +1d6 Dano, -1 PM)', preco: 3000, cd: 1, limPm: 0, dadoMagia: 5.5, redPmMag: 1, curaExtra: 2, pag: 'p. 161' }
];

// Resolvedor Central de Acúmulo de Bônus por Fonte (T20 JdA Cap. 5, p. 226)
// Regras oficiais: Bônus da mesma fonte (ITEM, MAGIA, PARCEIRO, AMBIENTE) NÃO acumulam — prevalece o maior.
// Bônus de HABILIDADE acumulam entre si, exceto vindos da mesma habilidade.
function resolverAcumuloFontesT20JS(bonusLista) {
    const porFonte = { ITEM: 0, MAGIA: 0, PARCEIRO: 0, AMBIENTE: 0 };
    const habsVistas = {};
    let totalHab = 0;
    for (const b of (bonusLista || [])) {
        if (!b || !Number.isFinite(Number(b.valor))) continue;
        const val = Number(b.valor);
        const fonte = String(b.fonte || 'ITEM').toUpperCase();
        if (fonte === 'HABILIDADE') {
            const chave = String(b.nome || 'hab_' + Math.random()).toLowerCase().trim();
            if (habsVistas[chave] === undefined || val > habsVistas[chave]) {
                habsVistas[chave] = val;
            }
        } else if (Object.prototype.hasOwnProperty.call(porFonte, fonte)) {
            if (val > porFonte[fonte]) porFonte[fonte] = val;
        }
    }
    for (const v of Object.values(habsVistas)) totalHab += v;
    const total = totalHab + porFonte.ITEM + porFonte.MAGIA + porFonte.PARCEIRO + porFonte.AMBIENTE;
    return { total, porFonte: Object.assign({ HABILIDADE: totalHab }, porFonte) };
}
if (typeof window !== 'undefined') window.resolverAcumuloFontesT20JS = resolverAcumuloFontesT20JS;


const CATALOGO_ACESSORIOS_MAGICOS_T20 = [
    { id: 'BAINHA_MAGICA', nome: '[Menor] Bainha Mágica (T$ 3.000 — +1 Ataque e +1 Dano na arma, p. 343)', preco: 3000, atq: 1, dano: 1, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'MOCHILA_CARGA', nome: '[Menor] Mochila de Carga (T$ 3.000 — +10 espaços de capacidade de carga, p. 346)', preco: 3000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'MANTO_ELFICO', nome: '[Menor] Manto Élfico (T$ 3.000 — +5 em Furtividade, p. 345)', preco: 3000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'ANEL_SUSTENTO', nome: '[Menor] Anel do Sustento (T$ 3.000 — Dispensa comida e descansa em 2h, p. 343)', preco: 3000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'LANTERNA_REVELACAO', nome: '[Menor] Lanterna da Revelação (T$ 3.000 — Revela criaturas invisíveis, p. 345)', preco: 3000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'CINTO_FORCA_1', nome: '[Médio] Cinto da Força do Gigante (T$ 9.000 — +1 em Força, p. 344)', preco: 9000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { FOR: 1 } },
    { id: 'LUVAS_DES_1', nome: '[Médio] Luvas da Delicadeza (T$ 9.000 — +1 em Destreza, p. 345)', preco: 9000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { DES: 1 } },
    { id: 'AMULETO_CON_1', nome: '[Médio] Amuleto da Robustez (T$ 9.000 — +1 em Constituição, p. 342)', preco: 9000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { CON: 1 } },
    { id: 'TIARA_INT_1', nome: '[Médio] Brincos da Sagacidade (T$ 9.000 — +1 em Inteligência, p. 344)', preco: 9000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { INT: 1 } },
    { id: 'ESTOLA_SAB_1', nome: '[Médio] Estola da Serenidade (T$ 9.000 — +1 em Sabedoria, p. 345)', preco: 9000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { SAB: 1 } },
    { id: 'COROA_CAR_1', nome: '[Médio] Coroa Majestosa (T$ 9.000 — +1 em Carisma, p. 344)', preco: 9000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { CAR: 1 } },
    { id: 'ANEL_PROTECAO', nome: '[Médio] Anel da Proteção (T$ 9.000 — +2 na Defesa, p. 343)', preco: 9000, atq: 0, dano: 0, def: 2, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'MANTO_RESISTENCIA', nome: '[Médio] Manto da Resistência (T$ 9.000 — +2 em Fortitude, Reflexos e Vontade, p. 345)', preco: 9000, atq: 0, dano: 0, def: 0, res: 2, pmExtra: 0, atrBonus: null },
    { id: 'FAIXAS_PUGILISTA', nome: '[Médio] Faixas do Pugilista (T$ 10.000 — +2 Ataque e +2 Dano Desarmado, p. 345)', preco: 10000, atq: 2, dano: 2, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'BRACADEIRAS_ARQUEIRO', nome: '[Médio] Braçadeiras do Arqueiro (T$ 10.500 — Proficiência e +2 Dano c/ Arcos, p. 344)', preco: 10500, atq: 0, dano: 2, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'BOTAS_ALADAS', nome: '[Médio] Botas Aladas (T$ 15.000 — Voo 12m por 2 PM na cena, p. 343)', preco: 15000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'MEDALHAO_LENA', nome: '[Médio] Medalhão de Lena (T$ 21.000 — Maximiza cura mágica 1x/dia, p. 346)', preco: 21000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'COLAR_GUARDIAO', nome: '[Maior] Colar Guardião (T$ 27.000 — +5 na Defesa, p. 344)', preco: 27000, atq: 0, dano: 0, def: 5, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'CINTO_CAMPEAO_2', nome: '[Maior] Cinto do Campeão (T$ 27.000 — +2 em Força, p. 344)', preco: 27000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { FOR: 2 } },
    { id: 'LUVAS_DES_2', nome: '[Maior] Luvas da Destreza Suprema (T$ 27.000 — +2 em Destreza, p. 345)', preco: 27000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { DES: 2 } },
    { id: 'AMULETO_CON_2', nome: '[Maior] Amuleto da Robustez Maior (T$ 27.000 — +2 em Constituição, p. 342)', preco: 27000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { CON: 2 } },
    { id: 'TIARA_SAPIENCIA_2', nome: '[Maior] Tiara da Sapiência (T$ 27.000 — +2 em Inteligência, p. 346)', preco: 27000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { INT: 2 } },
    { id: 'ESTOLA_SAB_2', nome: '[Maior] Estola da Serenidade Maior (T$ 27.000 — +2 em Sabedoria, p. 345)', preco: 27000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { SAB: 2 } },
    { id: 'COROA_MAJESTOSA_2', nome: '[Maior] Coroa Majestosa Maior (T$ 27.000 — +2 em Carisma, p. 344)', preco: 27000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: { CAR: 2 } },
    { id: 'ANEL_ENERGIA', nome: '[Maior] Anel da Energia (T$ 30.000 — +5 PM Máximos, p. 343)', preco: 30000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 5, atrBonus: null },
    { id: 'ANEL_REGENERACAO', nome: '[Maior] Anel da Regeneração (T$ 30.000 — Cura Acelerada 5 PV/turno, p. 343)', preco: 30000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'PULSEIRAS_CELERIDADE', nome: '[Maior] Pulseiras da Celeridade (T$ 30.000 — Efeito Velocidade constante, p. 346)', preco: 30000, atq: 0, dano: 0, def: 0, res: 0, pmExtra: 0, atrBonus: null },
    { id: 'MANTO_ARQUIMAGO', nome: '[Maior] Manto do Arquimago (T$ 90.000 — +4 Defesa, +2 Resistências e +2 CD Arcana, p. 346)', preco: 90000, atq: 0, dano: 0, def: 4, res: 2, pmExtra: 0, cdMagia: 2, atrBonus: null }
];

function obterOrcamentoInicialPorNivelJS(nivel) {
    const nv = Math.max(1, Math.min(20, parseInt(nivel || 1, 10)));
    return TABELA_DINHEIRO_INICIAL_T20[nv] !== undefined ? TABELA_DINHEIRO_INICIAL_T20[nv] : 14;
}

// Calcula exatamente:
// 1) Dano Normal: Mínimo, Máximo e Dano Médio = (Dano Máximo + Dano Mínimo) / 2
// 2) Dano Crítico (Regra T20 JdA p. 231: multiplica apenas o 1º grupo de dados base da arma por multCrit;
//    dados extras como Brutal, Elemental, Golpe Divino, Ataque Furtivo e bônus fixos não multiplicam,
//    exceto se lancinante=true, p. 336): Crítico Mínimo, Crítico Máximo e Dano Médio Crítico = (Crít Máx + Crít Mín) / 2
// 3) Dano Médio por Rodada (DPR Normal e DPR Ponderado por Crítico) baseado na quantidade de ataques (numAtaques)
function calcularDanoMinMaxMedioFormulaJS(formulaStr, multCrit = 2, lancinante = false, margCrit = 20, usa2d20Melhor = false, numAtaques = 1, danoMedioGolpeBaseExtra = null, danoCritGolpeBaseExtra = null) {
    if (!formulaStr || typeof formulaStr !== 'string') {
        return {
            min: 0, max: 0, medio: 0,
            critMin: 0, critMax: 0, critMedio: 0,
            chanceCritPct: 5, esperadoGolpeComCrit: 0,
            numAtaques: 1, dprNormal: 0, dprComCritico: 0, dprCriticoTotal: 0
        };
    }
    const mult = Math.max(2, parseInt(multCrit || 2, 10));
    const marg = Math.max(1, Math.min(20, parseInt(margCrit || 20, 10)));
    let minTotal = 0;
    let maxTotal = 0;
    let critMinDados = 0;
    let critMaxDados = 0;

    const limpa = formulaStr.replace(/\(.*?\)/g, ' ');
    const regexDados = /([+-]?\s*\d+)d(\d+)/gi;
    let m;
    let idxGrupoDado = 0;
    while ((m = regexDados.exec(limpa)) !== null) {
        const qtd = parseInt(m[1].replace(/\s+/g, ''), 10) || 1;
        const faces = parseInt(m[2], 10) || 6;
        // No crítico (Livro p. 231), apenas o 1º termo de dados (dados base da arma) multiplica por mult!
        const qtdCrit = (idxGrupoDado === 0 && qtd > 0) ? (qtd * mult) : qtd;
        if (qtd >= 0) {
            minTotal += qtd * 1;
            maxTotal += qtd * faces;
            critMinDados += qtdCrit * 1;
            critMaxDados += qtdCrit * faces;
        } else {
            minTotal += qtd * faces;
            maxTotal += qtd * 1;
            critMinDados += qtdCrit * faces;
            critMaxDados += qtdCrit * 1;
        }
        idxGrupoDado++;
    }
    const semDados = limpa.replace(/([+-]?\s*\d+)d(\d+)/gi, ' ');
    const regexFixos = /([+-]\s*\d+)/g;
    let mf;
    let fixoSoma = 0;
    while ((mf = regexFixos.exec(semDados)) !== null) {
        const val = parseInt(mf[1].replace(/\s+/g, ''), 10) || 0;
        fixoSoma += val;
    }
    minTotal += fixoSoma;
    maxTotal += fixoSoma;
    // Se possuir o encanto Lancinante (Livro p. 336), o bônus numérico fixo também é multiplicado por mult no crítico!
    const fixoCrit = lancinante ? (fixoSoma * mult) : fixoSoma;
    let critMin = critMinDados + fixoCrit;
    let critMax = critMaxDados + fixoCrit;

    minTotal = Math.max(1, minTotal);
    maxTotal = Math.max(minTotal, maxTotal);
    critMin = Math.max(minTotal, critMin);
    critMax = Math.max(critMin, critMax);

    const medio = +((maxTotal + minTotal) / 2.0).toFixed(1);
    const critMedio = +((critMax + critMin) / 2.0).toFixed(1);

    // Probabilidade de ameaça de crítico no d20 (1d20 normal vs 2d20 escolhe o melhor)
    const pNormal = (21 - marg) / 20.0;
    const pEfetiva = usa2d20Melhor ? (1.0 - Math.pow((marg - 1) / 20.0, 2)) : pNormal;
    const chanceCritPct = Math.round(pEfetiva * 100);
    const esperadoGolpeComCrit = +(((1.0 - pEfetiva) * medio) + (pEfetiva * critMedio)).toFixed(1);

    // Cálculo por rodada para N ataques:
    // O 1º ataque usa esta fórmula (ex.: Golpe Pessoal / Ataque Especial), e os ataques adicionais da rodada (nAtq - 1)
    // usam o golpe base da arma (ou a própria fórmula se for um bônus passivo/sustentado como Fúria ou ataque padrão)
    const nAtq = Math.max(1, parseInt(numAtaques || 1, 10));
    const medRestante = (danoMedioGolpeBaseExtra !== null && danoMedioGolpeBaseExtra !== undefined) ? danoMedioGolpeBaseExtra : medio;
    const espCritRestante = (danoCritGolpeBaseExtra !== null && danoCritGolpeBaseExtra !== undefined) ? danoCritGolpeBaseExtra : esperadoGolpeComCrit;

    const dprNormal = +(medio + (nAtq - 1) * medRestante).toFixed(1);
    const dprComCritico = +(esperadoGolpeComCrit + (nAtq - 1) * espCritRestante).toFixed(1);
    const dprCriticoTotal = +(critMedio * nAtq).toFixed(1);

    // Monta a fórmula explícita do Crítico e a memória de cálculo passo a passo
    const termosCritStr = [];
    const regexDados2 = /([+-]?\s*\d+)d(\d+)/gi;
    let m2;
    let idxG2 = 0;
    while ((m2 = regexDados2.exec(limpa)) !== null) {
        const q2 = parseInt(m2[1].replace(/\s+/g, ''), 10) || 1;
        const f2 = parseInt(m2[2], 10) || 6;
        if (idxG2 === 0 && q2 > 0) {
            termosCritStr.push(`${q2 * mult}d${f2} [arma ${q2}d${f2}×${mult}]`);
        } else {
            termosCritStr.push(`${q2}d${f2} [extra s/ mult.]`);
        }
        idxG2++;
    }
    if (fixoCrit !== 0) {
        termosCritStr.push(`${fixoCrit >= 0 ? '+' + fixoCrit : fixoCrit}${lancinante ? ' [fixo×' + mult + ' Lancinante]' : ' [fixo]'}`);
    }
    const formulaCriticoStr = termosCritStr.join(' + ').replace(/\+\s*\+/g, '+ ');
    const memoriaCriticoStr = `(${critMax} Máx + ${critMin} Mín) / 2 = ${critMedio}`;
    const memoriaNormalStr = `(${maxTotal} Máx + ${minTotal} Mín) / 2 = ${medio}`;

    return {
        min: minTotal,
        max: maxTotal,
        medio: medio,
        memoriaNormalStr: memoriaNormalStr,
        critMin: critMin,
        critMax: critMax,
        critMedio: critMedio,
        formulaCriticoStr: formulaCriticoStr,
        memoriaCriticoStr: memoriaCriticoStr,
        chanceCritPct: chanceCritPct,
        esperadoGolpeComCrit: esperadoGolpeComCrit,
        numAtaques: nAtq,
        dprNormal: dprNormal,
        dprComCritico: dprComCritico,
        dprCriticoTotal: dprCriticoTotal
    };
}

function autoOtimizarArsenalSuperiorEMagicoPorNivelJS(estado) {
    if (!estado) return null;
    const nv = Math.max(1, Math.min(20, estado.nivel || 1));
    const orcamentoTotal = obterOrcamentoInicialPorNivelJS(nv);
    const ncLow = (estado.classe && estado.classe.nome) ? estado.classe.nome.toLowerCase() : '';
    const ehConjuradorPuro = ['arcanista', 'clérigo', 'bardo', 'druida'].includes(ncLow);

    let gastoItensBase = 0;
    for (const it of (estado.itens || [])) {
        const pNum = parseFloat(String(it.preco || '0').replace(/[^0-9.,]/g, '').replace(',', '.')) || 0;
        if (nv === 1) gastoItensBase += 0; // Nv 1 recebe equipamento inicial gratuito + 4d6 T$ (p. 140)
        else gastoItensBase += Math.min(pNum, orcamentoTotal * 0.25);
    }
    let saldoRestante = Math.max(0, orcamentoTotal - Math.round(gastoItensBase));

    const cfg = {
        orcamentoNivel: orcamentoTotal,
        melhoriasArma: [],
        materialArma: 'NENHUM',
        encantosArma: [],
        upgradeArmadura: 'ARM_NORMAL',
        upgradeEsoterico: 'ESO_NENHUM',
        esotericoMagico: 'ESOMAG_NENHUM',
        catalisador: 'CAT_NENHUM',
        acessoriosMagicos: []
    };

    if (ehConjuradorPuro) {
        // Esotérico Mágico (níveis 9+), Esotérico Superior (melhorias), Catalisador Alquímico e Armadura
        for (const esoMag of [...CATALOGO_ESOTERICOS_MAGICOS_T20].reverse()) {
            if (esoMag.id !== 'ESOMAG_NENHUM' && esoMag.preco <= saldoRestante * 0.45) {
                cfg.esotericoMagico = esoMag.id;
                saldoRestante -= esoMag.preco;
                break;
            }
        }
        for (const eso of [...CATALOGO_ESOTERICOS_T20].reverse()) {
            if (eso.id !== 'ESO_NENHUM' && eso.preco <= saldoRestante * 0.50) {
                cfg.upgradeEsoterico = eso.id;
                saldoRestante -= eso.preco;
                break;
            }
        }
        for (const cat of [...CATALOGO_CATALISADORES_T20].reverse()) {
            if (cat.id !== 'CAT_NENHUM' && cat.preco <= saldoRestante * 0.25) {
                cfg.catalisador = cat.id;
                saldoRestante -= cat.preco;
                break;
            }
        }
        for (const armUp of [...CATALOGO_UPGRADES_ARMADURA_T20].reverse()) {
            if (armUp.preco <= saldoRestante * 0.45) {
                cfg.upgradeArmadura = armUp.id;
                saldoRestante -= armUp.preco;
                break;
            }
        }
    } else {
        // Combatente / Híbrido: Prioriza Arma Superior -> Material Especial -> Armadura Superior -> Encantos Mágicos -> Acessórios
        if (saldoRestante >= 72000) {
            cfg.encantosArma = ['MAGNIFICA', 'LANCINANTE'];
            saldoRestante -= 72000;
        } else if (saldoRestante >= 36000) {
            cfg.encantosArma = ['FORMIDAVEL', 'FLAMEJANTE'];
            saldoRestante -= 36000;
        } else if (saldoRestante >= 18000) {
            cfg.encantosArma = ['FORMIDAVEL'];
            saldoRestante -= 18000;
        }

        if (saldoRestante >= 18000) {
            cfg.melhoriasArma = ['CERTEIRA', 'CRUEL', 'PRECISA', 'HARMONIZADA'];
            saldoRestante -= 18000;
        } else if (saldoRestante >= 9000) {
            cfg.melhoriasArma = ['CERTEIRA', 'CRUEL', 'PRECISA'];
            saldoRestante -= 9000;
        } else if (saldoRestante >= 3000) {
            cfg.melhoriasArma = ['CERTEIRA', 'CRUEL'];
            saldoRestante -= 3000;
        } else if (saldoRestante >= 300) {
            cfg.melhoriasArma = ['CERTEIRA'];
            saldoRestante -= 300;
        }

        if (cfg.melhoriasArma.length < 4) {
            if (saldoRestante >= 4500 && cfg.melhoriasArma.length <= 2) {
                cfg.materialArma = 'ADAMANTE';
                saldoRestante -= 3000;
            } else if (saldoRestante >= 1800 && cfg.melhoriasArma.length <= 2) {
                cfg.materialArma = 'MITRAL';
                saldoRestante -= 1500;
            }
        }

        for (const armUp of [...CATALOGO_UPGRADES_ARMADURA_T20].reverse()) {
            if (armUp.preco <= saldoRestante * 0.65) {
                cfg.upgradeArmadura = armUp.id;
                saldoRestante -= armUp.preco;
                break;
            }
        }
    }

    // Acessórios Mágicos alinhados ao atributo-chave da classe (JdA p. 226: não empilha 2 itens no mesmo atributo)
    let ordemAcessorios;
    if (ehConjuradorPuro) {
        const clsAuto = String((estado && estado.classe && estado.classe.nome) || '').toLowerCase();
        const ehSab = ['clérigo', 'clerigo', 'druida'].includes(clsAuto);
        const ehCar = clsAuto === 'bardo' || (clsAuto === 'arcanista' && String((estado && estado.caminhoArcanista) || '').toLowerCase().includes('feiticeiro'));
        if (ehSab) {
            ordemAcessorios = ['ESTOLA_SAB_2', 'ANEL_ENERGIA', 'ANEL_PROTECAO', 'MANTO_RESISTENCIA', 'ESTOLA_SAB_1', 'AMULETO_CON_1'];
        } else if (ehCar) {
            ordemAcessorios = ['MANTO_ARQUIMAGO', 'COROA_MAJESTOSA_2', 'ANEL_ENERGIA', 'ANEL_PROTECAO', 'COROA_CAR_1', 'MANTO_RESISTENCIA'];
        } else {
            ordemAcessorios = ['MANTO_ARQUIMAGO', 'TIARA_SAPIENCIA_2', 'ANEL_ENERGIA', 'ANEL_PROTECAO', 'TIARA_INT_1', 'MANTO_RESISTENCIA'];
        }
    } else {
        ordemAcessorios = ['BAINHA_MAGICA', 'CINTO_CAMPEAO_2', 'ANEL_PROTECAO', 'MANTO_RESISTENCIA', 'CINTO_FORCA_1', 'AMULETO_CON_1'];
    }

    for (const idAc of ordemAcessorios) {
        const objAc = CATALOGO_ACESSORIOS_MAGICOS_T20.find(a => a.id === idAc);
        if (objAc && objAc.preco <= saldoRestante && cfg.acessoriosMagicos.length < 4) {
            cfg.acessoriosMagicos.push(idAc);
            saldoRestante -= objAc.preco;
        }
    }

    return cfg;
}

function calcularResumoArsenalSuperiorEMagicoJS(estado) {
    if (!estado) {
        return {
            orcamentoNivel: 14, gastoTotal: 0, saldoRestante: 14, dentroDoOrcamento: true,
            bonusAtqArma: 0, bonusDanoArma: 0, bonusMargemCrit: 0, bonusMultCrit: 0,
            passosExtrasArma: 0, dadosExtrasArmaStr: [], mediaDadosExtrasArma: 0, minDadosExtrasArma: 0, maxDadosExtrasArma: 0,
            redPmAtaque: 0, ignoraRdArma: 0, duplicaMargem: false, lancinante: false, veloz: false,
            bonusDefesaTotal: 0, redPenArmadura: 0, bonusResistencias: 0, rdArmadura: 0,
            bonusCdMagia: 0, bonusLimitePm: 0, bonusDanoMagiaMedia: 0, redPmMagia: 0,
            pmExtraAcessorios: 0, bonusAtributos: { FOR: 0, DES: 0, CON: 0, INT: 0, SAB: 0, CAR: 0 },
            itensDescritivos: []
        };
    }
    const nv = Math.max(1, Math.min(20, estado.nivel || 1));
    const orcamentoNivel = obterOrcamentoInicialPorNivelJS(nv);
    if (!estado.configArsenalT20 || estado.configArsenalT20._nivelCalculado !== nv) {
        estado.configArsenalT20 = autoOtimizarArsenalSuperiorEMagicoPorNivelJS(estado);
        estado.configArsenalT20._nivelCalculado = nv;
    }
    const cfg = estado.configArsenalT20;

    let bonusAtqArma = 0, bonusDanoArma = 0, bonusMargemCrit = 0, bonusMultCrit = 0;
    let passosExtrasArma = 0, redPmAtaque = 0, ignoraRdArma = 0;
    let duplicaMargem = false, lancinante = false, veloz = false;
    const dadosExtrasArmaStr = [];
    let mediaDadosExtrasArma = 0, minDadosExtrasArma = 0, maxDadosExtrasArma = 0;
    let bonusDefesaTotal = 0, redPenArmadura = 0, bonusResistencias = 0, rdArmadura = 0;
    let bonusCdMagia = 0, bonusLimitePm = 0, bonusDanoMagiaMedia = 0, redPmMagia = 0, pmExtraAcessorios = 0;
    const bonusAtributos = { FOR: 0, DES: 0, CON: 0, INT: 0, SAB: 0, CAR: 0 };
    const itensDescritivos = [];

    // 1. Melhorias e Material da Arma Principal
    let numMelhoriasArma = 0;
    const nomesMelhArma = [];
    for (const idM of (cfg.melhoriasArma || [])) {
        const mObj = CATALOGO_MELHORIAS_ARMA_T20.find(x => x.id === idM);
        if (!mObj) continue;
        numMelhoriasArma += mObj.melhorias;
        bonusAtqArma += mObj.atq;
        bonusDanoArma += mObj.dano;
        bonusMargemCrit += mObj.marg;
        bonusMultCrit += mObj.mult;
        redPmAtaque += mObj.redPmAtq;
        if (mObj.dadoExtra === '1d6') {
            dadosExtrasArmaStr.push('1d6');
            mediaDadosExtrasArma += 3.5;
            minDadosExtrasArma += 1;
            maxDadosExtrasArma += 6;
        }
        nomesMelhArma.push(mObj.nome.split('(')[0].trim());
    }
    const matObj = CATALOGO_MATERIAIS_ARMA_T20.find(x => x.id === cfg.materialArma) || CATALOGO_MATERIAIS_ARMA_T20[0];
    if (matObj && matObj.id !== 'NENHUM') {
        numMelhoriasArma += matObj.melhoriasReq;
        passosExtrasArma += matObj.passo;
        bonusMargemCrit += matObj.marg;
        bonusDanoArma += matObj.danoFixo;
        redPmAtaque += matObj.redPm;
        redPmMagia += matObj.redPm;
        ignoraRdArma += matObj.ignoraRd;
        if (matObj.dadoExtra === '1d6') {
            dadosExtrasArmaStr.push('1d6');
            mediaDadosExtrasArma += 3.5;
            minDadosExtrasArma += 1;
            maxDadosExtrasArma += 6;
        }
        nomesMelhArma.push(`Material: ${matObj.nome.split('(')[0].trim()}`);
    }
    const numMelhClamp = Math.min(4, numMelhoriasArma);
    const custoMelhoriasArma = (CUSTO_MELHORIAS_SUPERIOR_T20[numMelhClamp] || 0) + (matObj ? matObj.preco : 0);
    if (nomesMelhArma.length > 0) {
        itensDescritivos.push({
            nome: `Arma Superior (${numMelhClamp} melhoria(s): ${nomesMelhArma.join(', ')})`,
            categoria: 'Arma Superior (Tabela 3-6, p. 164)',
            efeito: `Atq +${bonusAtqArma}, Dano +${bonusDanoArma}${passosExtrasArma ? ', +' + passosExtrasArma + ' Passo' : ''}${bonusMargemCrit ? ', +' + bonusMargemCrit + ' Margem' : ''}${bonusMultCrit ? ', +' + bonusMultCrit + 'x Crít' : ''}${redPmAtaque ? ', -' + redPmAtaque + ' PM' : ''}`,
            preco: `T$ ${custoMelhoriasArma}`,
            precoNum: custoMelhoriasArma
        });
    }

    // 2. Encantos Mágicos da Arma (Cap. 8, p. 335)
    let numEncantosArma = 0;
    const nomesEncArma = [];
    for (const idE of (cfg.encantosArma || [])) {
        const eObj = CATALOGO_ENCANTOS_ARMA_T20.find(x => x.id === idE);
        if (!eObj) continue;
        numEncantosArma += eObj.encantos;
        bonusAtqArma += eObj.atq;
        bonusDanoArma += eObj.dano;
        if (eObj.def) {
            bonusDefesaTotal += eObj.def;
        }
        if (eObj.dadoExtra) {
            dadosExtrasArmaStr.push(eObj.dadoExtra);
            if (eObj.dadoExtra === '1d6') { mediaDadosExtrasArma += 3.5; minDadosExtrasArma += 1; maxDadosExtrasArma += 6; }
            else if (eObj.dadoExtra === '1d8') { mediaDadosExtrasArma += 4.5; minDadosExtrasArma += 1; maxDadosExtrasArma += 8; }
            else if (eObj.dadoExtra === '1d12') { mediaDadosExtrasArma += 6.5; minDadosExtrasArma += 1; maxDadosExtrasArma += 12; }
            else if (eObj.dadoExtra === '2d6') { mediaDadosExtrasArma += 7.0; minDadosExtrasArma += 2; maxDadosExtrasArma += 12; }
        }
        if (eObj.duplicaMargem) duplicaMargem = true;
        if (eObj.lancinante) lancinante = true;
        if (eObj.veloz) veloz = true;
        nomesEncArma.push(eObj.nome.split('(')[0].trim());
    }
    const numEncClamp = Math.min(3, numEncantosArma);
    const custoEncantosArma = CUSTO_ENCANTOS_MAGICOS_T20[numEncClamp] || 0;
    if (nomesEncArma.length > 0) {
        itensDescritivos.push({
            nome: `Arma Mágica (${numEncClamp} encanto(s): ${nomesEncArma.join(', ')})`,
            categoria: 'Arma Mágica (Tabela 8-4, p. 334)',
            efeito: `Encantos ativos: ${nomesEncArma.join(' + ')}`,
            preco: `T$ ${custoEncantosArma}`,
            precoNum: custoEncantosArma
        });
    }

    // 3. Armadura / Escudo Superior ou Mágico
    const armUpObj = CATALOGO_UPGRADES_ARMADURA_T20.find(x => x.id === cfg.upgradeArmadura) || CATALOGO_UPGRADES_ARMADURA_T20[0];
    let custoArmaduraUp = 0;
    if (armUpObj && armUpObj.id !== 'ARM_NORMAL') {
        custoArmaduraUp = armUpObj.preco;
        bonusDefesaTotal += armUpObj.def;
        redPenArmadura += armUpObj.penRed;
        bonusResistencias += armUpObj.res;
        rdArmadura += armUpObj.rd;
        itensDescritivos.push({
            nome: `${armUpObj.nome.split('(')[0].trim()}`,
            categoria: 'Armadura Superior/Mágica (p. 165/338)',
            efeito: `+${armUpObj.def} Defesa${armUpObj.penRed ? ', -' + armUpObj.penRed + ' Penalidade' : ''}${armUpObj.res ? ', +' + armUpObj.res + ' Resistências' : ''}${armUpObj.rd ? ', RD ' + armUpObj.rd : ''}`,
            preco: `T$ ${custoArmaduraUp}`,
            precoNum: custoArmaduraUp
        });
    }

    // 4. Esotérico Superior + Esotérico Mágico + Catalisador Alquímico (v100)
    const esoObj = CATALOGO_ESOTERICOS_T20.find(x => x.id === cfg.upgradeEsoterico) || CATALOGO_ESOTERICOS_T20[0];
    let custoEsoterico = 0;
    if (esoObj && esoObj.id !== 'ESO_NENHUM') {
        custoEsoterico += esoObj.preco;
        bonusCdMagia += esoObj.cd;
        bonusLimitePm += esoObj.limPm;
        bonusDanoMagiaMedia += esoObj.dadoMagia;
        bonusDefesaTotal += esoObj.def;
        redPmMagia += esoObj.redPmMag;
        itensDescritivos.push({
            nome: esoObj.nome.split('(')[0].trim(),
            categoria: 'Esotérico Superior (p. 159/165)',
            efeito: `${esoObj.cd ? '+' + esoObj.cd + ' CD Magia ' : ''}${esoObj.limPm ? '+' + esoObj.limPm + ' Limite PM ' : ''}${esoObj.dadoMagia ? '+1d6 Dano Magia ' : ''}${esoObj.redPmMag ? '-1 PM Magias' : ''}`.trim(),
            preco: `T$ ${esoObj.preco}`,
            precoNum: esoObj.preco
        });
    }
    const esoMagObj = CATALOGO_ESOTERICOS_MAGICOS_T20.find(x => x.id === cfg.esotericoMagico) || CATALOGO_ESOTERICOS_MAGICOS_T20[0];
    if (esoMagObj && esoMagObj.id !== 'ESOMAG_NENHUM') {
        custoEsoterico += esoMagObj.preco;
        bonusCdMagia += esoMagObj.cd;
        bonusLimitePm += esoMagObj.limPm;
        bonusDanoMagiaMedia += esoMagObj.dadoMagia;
        redPmMagia += esoMagObj.redPmMag;
        itensDescritivos.push({
            nome: esoMagObj.nome.split('(')[0].trim(),
            categoria: 'Esotérico Mágico (Cap. 8, p. 339)',
            efeito: `+${esoMagObj.cd} CD, +${esoMagObj.limPm} Limite PM, +${Math.round(esoMagObj.dadoMagia / 3.5)}d6 Dano Magia${esoMagObj.redPmMag ? ', -1 PM' : ''}`,
            preco: `T$ ${esoMagObj.preco}`,
            precoNum: esoMagObj.preco
        });
    }
    const catObj = CATALOGO_CATALISADORES_T20.find(x => x.id === cfg.catalisador) || CATALOGO_CATALISADORES_T20[0];
    if (catObj && catObj.id !== 'CAT_NENHUM') {
        custoEsoterico += catObj.preco;
        bonusCdMagia += catObj.cd;
        bonusLimitePm += catObj.limPm;
        bonusDanoMagiaMedia += catObj.dadoMagia;
        redPmMagia += catObj.redPmMag;
        itensDescritivos.push({
            nome: catObj.nome.split('(')[0].trim(),
            categoria: 'Catalisador Alquímico (Cap. 3, p. 161)',
            efeito: `${catObj.cd ? '+' + catObj.cd + ' CD ' : ''}${catObj.dadoMagia ? '+' + catObj.dadoMagia.toFixed(1) + ' Dano Magia ' : ''}${catObj.redPmMag ? '-1 PM' : ''}`.trim(),
            preco: `T$ ${catObj.preco}`,
            precoNum: catObj.preco
        });
    }

    // 5. Acessórios Mágicos (v100: aplica JdA p. 226 não-acúmulo de mesmo atributo/defesa entre itens + bloqueio de DES em Armadura Pesada)
    let custoAcessorios = 0;
    const usaArmPesadaAc = Boolean(estado && estado.armadura && String(estado.armadura.categoria || estado.armadura.tipo || estado.armadura.nome || '').toLowerCase().match(/pesada|meia armadura|cota de talas|loriga|armadura completa/));
    const clsAc = String((estado && estado.classe && estado.classe.nome) || '').toLowerCase();
    const atribChaveMagAc = ['clérigo', 'clerigo', 'druida'].includes(clsAc) ? 'SAB' : (clsAc === 'bardo' ? 'CAR' : 'INT');
    let maxDefAcessorio = 0, maxResAcessorio = 0, maxCdAcessorio = 0;
    for (const idAc of (cfg.acessoriosMagicos || [])) {
        const acObj = CATALOGO_ACESSORIOS_MAGICOS_T20.find(x => x.id === idAc);
        if (!acObj) continue;
        custoAcessorios += acObj.preco;
        bonusAtqArma += acObj.atq;
        bonusDanoArma += acObj.dano;
        if (acObj.def > maxDefAcessorio) maxDefAcessorio = acObj.def;
        if (acObj.res > maxResAcessorio) maxResAcessorio = acObj.res;
        if ((acObj.cdMagia || 0) > maxCdAcessorio) maxCdAcessorio = acObj.cdMagia;
        pmExtraAcessorios += acObj.pmExtra;
        if (acObj.atrBonus) {
            for (const [k, v] of Object.entries(acObj.atrBonus)) {
                // JdA p. 226: dois acessórios mágicos no mesmo atributo NÃO acumulam — vale o maior
                bonusAtributos[k] = Math.max(bonusAtributos[k] || 0, v);
            }
        }
        itensDescritivos.push({
            nome: acObj.nome.split('(')[0].trim(),
            categoria: 'Acessório Mágico (Cap. 8, p. 342)',
            efeito: acObj.nome.split('—')[1] ? acObj.nome.split('—')[1].replace(')', '') : 'Bônus Mágico',
            preco: `T$ ${acObj.preco}`,
            precoNum: acObj.preco
        });
    }
    bonusDefesaTotal += maxDefAcessorio;
    bonusResistencias += maxResAcessorio;
    bonusCdMagia += maxCdAcessorio;
    if (bonusAtributos.FOR) { bonusAtqArma += bonusAtributos.FOR; bonusDanoArma += bonusAtributos.FOR; }
    if (bonusAtributos.DES && !usaArmPesadaAc) { bonusDefesaTotal += bonusAtributos.DES; }
    if (bonusAtributos[atribChaveMagAc]) { bonusCdMagia += bonusAtributos[atribChaveMagAc]; }

    const gastoTotal = custoMelhoriasArma + custoEncantosArma + custoArmaduraUp + custoEsoterico + custoAcessorios;
    const saldoRestante = orcamentoNivel - gastoTotal;

    return {
        orcamentoNivel,
        gastoTotal,
        saldoRestante,
        dentroDoOrcamento: saldoRestante >= 0,
        bonusAtqArma,
        bonusDanoArma,
        bonusMargemCrit,
        bonusMultCrit,
        passosExtrasArma,
        dadosExtrasArmaStr,
        mediaDadosExtrasArma,
        minDadosExtrasArma,
        maxDadosExtrasArma,
        redPmAtaque,
        ignoraRdArma,
        duplicaMargem,
        lancinante,
        veloz,
        bonusDefesaTotal,
        redPenArmadura,
        bonusResistencias,
        rdArmadura,
        bonusCdMagia,
        bonusLimitePm,
        bonusDanoMagiaMedia,
        redPmMagia,
        pmExtraAcessorios,
        bonusAtributos,
        itensDescritivos
    };
}

function calcularResumoDanoJS(nivel, classeObj, est, poderes, itens, arma, escudo, magias, caminhoArcanista) {
    const atribChave = (est && est.infoMagia) ? est.infoMagia.sigla : obterAtributoChaveMagiaJS(classeObj, caminhoArcanista).sigla;
    const valAtribMag = Math.max(0, est.finais[atribChave] || 0);
    const temMagiaIlimitada = (poderes || []).some(p => p.nome.toLowerCase() === 'magia ilimitada');
    const temCajado = (itens || []).some(i => ['cajado arcano', 'orbe cristalino'].includes(i.nome.toLowerCase()));
    const limitePM = nivel + (temMagiaIlimitada ? valAtribMag : 0) + (temCajado ? 1 : 0);
    const strLimitePM = `${nivel} (Nível)` + (temMagiaIlimitada ? ` + ${valAtribMag} (Magia Ilimitada)` : '') + (temCajado ? ' + 1 (Esotérico)' : '') + ` = ${limitePM} PM/magia`;

    // 1. Combo Raio Arcano
    const cMax = Math.max(1, circuloMaximoPermitido(classeObj, nivel));
    const temRaio = (poderes || []).some(p => p.nome.toLowerCase() === 'raio arcano');
    const temElem = (poderes || []).some(p => p.nome.toLowerCase() === 'raio elemental');
    const temPod = (poderes || []).some(p => p.nome.toLowerCase() === 'raio poderoso');
    const temArcBat = (poderes || []).some(p => p.nome.toLowerCase() === 'arcano de batalha');
    let danoMedioRaio = 0;
    let descRaio = 'Não possui Raio Arcano.';
    if (temRaio) {
        const faces = temPod ? 12 : (temElem ? 10 : 8);
        const alc = temPod ? 'Médio' : 'Curto';
        const elem = temElem ? 'Elemental' : 'Essência';
        const bFix = temArcBat ? valAtribMag : 0;
        danoMedioRaio = +(cMax * ((faces + 1) / 2) + bFix).toFixed(1);
        descRaio = `${cMax}d${faces}${bFix ? ' + ' + bFix + ' (Arcano de Batalha)' : ''} [${elem} | Alcance ${alc} | 0 PM] — Dano Médio: ${danoMedioRaio}/rodada`;
    }

    // 2. Magias, Maior Dano Explosivo (1 Alvo) e Maior Dano em Área (Múltiplos Alvos — Cap. 4 p. 172)
    let maiorDanoMagia = 0;
    let maiorDanoMagiaArea = 0;
    let melhorMagiaInfo = null;
    let melhorMagiaAreaInfo = null;
    const detalhesMagias = {};
    for (const m of (magias || [])) {
        const inf = detalharAprimoramentoMagiaJS(m, nivel, classeObj, est.finais, poderes, itens, caminhoArcanista);
        detalhesMagias[m.id_magia] = inf;
        if (inf.danoMedio > maiorDanoMagia && !inf.formulaFinal.toLowerCase().startsWith('cura ')) {
            maiorDanoMagia = inf.danoMedio;
            melhorMagiaInfo = { nome: m.nome, info: inf };
        }
        if ((inf.danoMedioArea || inf.danoMedio) > maiorDanoMagiaArea && !inf.formulaFinal.toLowerCase().startsWith('cura ')) {
            maiorDanoMagiaArea = inf.danoMedioArea || inf.danoMedio;
            melhorMagiaAreaInfo = { nome: m.nome, info: inf };
        }
    }
    const temMagiaAcelerada = (poderes || []).some(p => (p.nome || '').toLowerCase() === 'magia acelerada');
    if (temMagiaAcelerada && limitePM >= 5 && maiorDanoMagia > 0 && melhorMagiaInfo) {
        const orcAcel = Math.max(1, limitePM - 4);
        const ganhoAcel = +(Math.max(11.0, orcAcel * 4.5 + (temArcBat ? valAtribMag : 0))).toFixed(1);
        maiorDanoMagia = +(maiorDanoMagia + ganhoAcel).toFixed(1);
        melhorMagiaInfo = {
            nome: melhorMagiaInfo.nome,
            info: {
                ...melhorMagiaInfo.info,
                danoMedio: maiorDanoMagia,
                formulaFinal: `${melhorMagiaInfo.info.formulaFinal} + Magia Acelerada [Ação Livre +4 PM: +${ganhoAcel} dano]`
            }
        };
    }

    // 3. Dano Marcial / à Distância da Arma Equipada (com Passos de Dano, Crítico e Estilos Corrigidos)
    const todosPoderes = [...((est && est.infoDevocao) ? est.infoDevocao.poderes : []), ...(poderes || [])];
    const possuiPod = (nm) => todosPoderes.some(p => (p.nome || '').toLowerCase() === nm.toLowerCase());

    let danoMedioArma = 0;
    let descDanoArma = 'Desarmado (1d3 impacto).';
    if (arma) {
        const estilo = identificarEstiloArmaJS(arma, escudo, todosPoderes);
        const ehDist = ['ARQUERIA_DISPARO', 'ARREMESSO'].includes(estilo);
        const perAtk = ehDist ? 'Pontaria' : 'Luta';
        let bonusAtk = est.bonusPericias[perAtk] || 0;
        let partesDano = [];
        let partesAtk = [`${perAtk} ${bonusAtk >= 0 ? '+' + bonusAtk : bonusAtk}`];

        // 3.1 Acuidade com Arma (usa DES no Ataque e no Dano para Uma Mão / Duas Armas se DES > FOR)
        const usaAcuidade = !ehDist && possuiPod('Acuidade com Arma') && ['UMA_ARMA_ESGRIMA', 'DUAS_ARMAS'].includes(estilo) && est.finais.DES > est.finais.FOR;
        if (usaAcuidade) {
            const diff = est.finais.DES - est.finais.FOR;
            bonusAtk += diff;
            partesAtk.push(`+${diff} (DES Acuidade)`);
        }

        // 3.2 Passos de Dano (Arma Sagrada, Armamento da Natureza, Empunhadura Poderosa)
        let passosExtras = 0;
        const fontesPassos = [];
        if (possuiPod('Empunhadura Poderosa')) {
            passosExtras += 1; fontesPassos.push('Empunhadura Poderosa');
            bonusAtk -= 2; partesAtk.push('-2 (Empunhadura Poderosa)');
        }
        if (possuiPod('Arma Sagrada') || possuiPod('Espada Justiceira') || possuiPod('Espada Solar')) {
            passosExtras += 1; fontesPassos.push('Arma Sagrada');
        }
        if (possuiPod('Armamento da Natureza') || (magias || []).some(m => m.nome.toLowerCase().includes('armamento da natureza'))) {
            passosExtras += 1; fontesPassos.push('Armamento da Natureza');
        }

        const infoPasso = avancarPassosDanoJS(arma.dano_ou_defesa || '1d6', passosExtras);
        let mediaDadosArma = infoPasso.media;
        const strPasso = passosExtras > 0 ? ` [${arma.dano_ou_defesa} ${infoPasso.str}: +${fontesPassos.join('/')}]` : '';

        if (possuiPod('Destruidor') && ['DUAS_MAOS', 'ARMA_LONGA_HASTE'].includes(estilo)) {
            mediaDadosArma += infoPasso.q * (2.0 / infoPasso.f) * (((infoPasso.f + 1) / 2.0) - 1.5);
            partesDano.push(`${infoPasso.str}${strPasso} (Destruidor rerrola 1-2: média ${mediaDadosArma.toFixed(1)})`);
        } else {
            partesDano.push(`${infoPasso.str}${strPasso} (média ${mediaDadosArma.toFixed(1)})`);
        }

        // 3.3 Bônus Fixos de Atributo e Estilo
        let fixoDano = 0;
        let dadosExtrasMedia = 0;
        if (!ehDist) {
            if (usaAcuidade) {
                fixoDano += est.finais.DES;
                partesDano.push(`+${est.finais.DES} (DES Acuidade)`);
            } else {
                fixoDano += est.finais.FOR;
                partesDano.push(`${est.finais.FOR >= 0 ? '+' + est.finais.FOR : est.finais.FOR} (FOR)`);
            }
        } else {
            if (arma.nome.toLowerCase().includes('arco longo') || possuiPod('Arremesso Potente')) {
                fixoDano += est.finais.FOR;
                partesDano.push(`+${est.finais.FOR} (FOR Arco Longo/Arremesso)`);
            }
            if (possuiPod('Estilo de Disparo') && estilo === 'ARQUERIA_DISPARO') {
                fixoDano += est.finais.DES;
                partesDano.push(`+${est.finais.DES} (DES Estilo de Disparo)`);
            }
            if (possuiPod('Arqueiro') && estilo === 'ARQUERIA_DISPARO') {
                const bSab = Math.min(nivel, Math.max(0, est.finais.SAB));
                fixoDano += bSab;
                partesDano.push(`+${bSab} (SAB Arqueiro)`);
            }
        }

        if (possuiPod('Estilo de Duas Mãos') && ['DUAS_MAOS', 'ARMA_LONGA_HASTE'].includes(estilo)) {
            fixoDano += 5; partesDano.push('+5 (Estilo de Duas Mãos)');
        }
        if (possuiPod('Estilo de Arma Longa') && estilo === 'ARMA_LONGA_HASTE') {
            bonusAtk += 2; partesAtk.push('+2 (Estilo de Arma Longa)');
        }
        if (possuiPod('Estilo de Uma Arma') && estilo === 'UMA_ARMA_ESGRIMA') {
            bonusAtk += 2; partesAtk.push('+2 (Estilo de Uma Arma)');
        }
        if (possuiPod('Ataque Poderoso') && !ehDist) {
            fixoDano += 5; bonusAtk -= 2; partesDano.push('+5 (Ataque Poderoso)'); partesAtk.push('-2 (Ataque Poderoso)');
        }
        if (possuiPod('Especialização em Arma')) {
            fixoDano += 2; partesDano.push('+2 (Especialização em Arma)');
        }
        if (possuiPod('Valentão') && !ehDist) {
            fixoDano += 2; bonusAtk += 2; partesDano.push('+2 (Valentão)'); partesAtk.push('+2 (Valentão)');
        }
        if (possuiPod('Esgrimista') && ['UMA_ARMA_ESGRIMA', 'DUAS_ARMAS'].includes(estilo)) {
            const gEsg = Math.min(nivel, Math.max(0, est.finais.INT));
            if (gEsg > 0) { fixoDano += gEsg; partesDano.push(`+${gEsg} (INT Esgrimista)`); }
        }
        if (possuiPod('Foco em Arma')) {
            bonusAtk += 2; partesAtk.push('+2 (Foco em Arma)');
        }
        if (possuiPod('Mira Apurada') && ehDist) {
            bonusAtk += 2; partesAtk.push('+2 (Mira Apurada)');
        }
        if (possuiPod('Armas da Ambição')) {
            bonusAtk += 1; partesAtk.push('+1 (Armas da Ambição)');
        }
        if (possuiPod('Sangue de Ferro')) {
            fixoDano += 2; partesDano.push('+2 (Sangue de Ferro)');
        }

        const ncLow = (classeObj.nome || '').toLowerCase();
        const paresAtivosDano = (est && est.paresClasses && est.paresClasses.length > 0)
            ? est.paresClasses
            : [{ classeObj, nivel }];
        const nvClasseMap = {};
        for (const pc of paresAtivosDano) {
            nvClasseMap[(pc.classeObj.nome || '').toLowerCase()] = pc.nivel;
        }
        const nvGuerreiro = nvClasseMap['guerreiro'] || 0;
        const nvBarbaro = nvClasseMap['bárbaro'] || 0;
        const nvCacador = nvClasseMap['caçador'] || 0;
        const nvPaladino = nvClasseMap['paladino'] || 0;
        const nvLadino = nvClasseMap['ladino'] || 0;

        // Ataque Especial (Guerreiro p. 65) escala pelo nível de Guerreiro!
        let escEspGuerreiro = 0;
        let custoEspGuerreiro = 0;
        if (nvGuerreiro >= 1) {
            escEspGuerreiro = 4 * (1 + Math.floor((nvGuerreiro - 1) / 4));
            custoEspGuerreiro = 1 + Math.floor((nvGuerreiro - 1) / 4);
        }
        if (nvBarbaro >= 1 && !ehDist) {
            const furB = 2 + Math.floor((nvBarbaro - 1) / 5);
            fixoDano += furB; bonusAtk += furB;
            partesDano.push(`+${furB} (Fúria Bárbaro Nv ${nvBarbaro})`); partesAtk.push(`+${furB} (Fúria)`);
        }
        if (nvCacador >= 1) {
            const medMP = nvCacador < 5 ? 2.5 : (nvCacador < 13 ? 3.5 : 4.5);
            const strMP = nvCacador < 5 ? '1d4' : (nvCacador < 13 ? '1d6' : '1d8');
            dadosExtrasMedia += medMP;
            partesDano.push(`+${strMP} (Marca da Presa Caçador Nv ${nvCacador}: +${medMP})`);
        }
        if (nvPaladino >= 1 && !ehDist) {
            const bCar = Math.max(0, est.finais.CAR);
            bonusAtk += bCar; dadosExtrasMedia += 4.5;
            partesAtk.push(`+${bCar} (CAR Golpe Divino Paladino Nv ${nvPaladino})`);
            partesDano.push('+1d8 (Golpe Divino: +4.5)');
        }
        if (nvLadino >= 1) {
            const dFurtM = Math.ceil(nvLadino / 2);
            dadosExtrasMedia += dFurtM * 3.5;
            partesDano.push(`+${dFurtM}d6 (Ataque Furtivo Ladino Nv ${nvLadino}: +${(dFurtM * 3.5).toFixed(1)})`);
        }

        // 3.4 Margem de Ameaça e Multiplicador de Crítico
        const critBase = extrairCriticoArmaJS(arma.critico_ou_penalidade);
        let margemCrit = critBase.margem;
        let multCrit = critBase.mult;
        if (possuiPod('Ataque Preciso') && estilo === 'UMA_ARMA_ESGRIMA') { margemCrit = Math.max(1, margemCrit - 2); multCrit += 1; }
        if (possuiPod('En Garde') && estilo === 'UMA_ARMA_ESGRIMA') { margemCrit = Math.max(1, margemCrit - 2); }
        if (possuiPod('Mira Apurada') && ehDist) { margemCrit = Math.max(1, margemCrit - 2); }
        if (possuiPod('Armas da Ambição')) { margemCrit = Math.max(1, margemCrit - 1); }
        if (possuiPod('Tradição de Lin-Wu') && arma.nome.toLowerCase().includes('katana')) { margemCrit = Math.max(1, margemCrit - 1); }
        if (possuiPod('Crítico Brutal')) { multCrit += 1; }

        const chanceAmeacaD20 = (21 - margemCrit) / 20.0;
        const ganhoCritPorGolpe = mediaDadosArma * (multCrit - 1) * chanceAmeacaD20;
        const danoNormalGolpe = mediaDadosArma + fixoDano + dadosExtrasMedia;
        const danoCriticoGolpe = (mediaDadosArma * multCrit) + fixoDano + dadosExtrasMedia;
        const danoGolpe = danoNormalGolpe + ganhoCritPorGolpe;

        // 3.5 Quantidade de Ataques e Ataques Extras (Duas Armas, Disparo Rápido, Ataque com Escudo, Piqueiro)
        let numAtaques = 1;
        let danoExtraSec = 0;
        const detExtras = [];

        if (nvGuerreiro >= 6) {
            numAtaques += 1; detExtras.push('Ataque Extra (Guerreiro Nv 6)');
        }
        if (possuiPod('Disparo Rápido') && ehDist) {
            numAtaques += 1; bonusAtk -= 2;
            partesAtk.push('-2 (Disparo Rápido: Ação Completa)');
            detExtras.push('Disparo Rápido (+1 tiro)');
        }
        if ((estilo === 'DUAS_ARMAS' || possuiPod('Estilo de Duas Armas') || possuiPod('Ambidestria')) && !['DUAS_MAOS', 'ARMA_E_ESCUDO', 'ARQUERIA_DISPARO'].includes(estilo)) {
            if (!possuiPod('Ambidestria')) {
                bonusAtk -= 2; partesAtk.push('-2 (Estilo de Duas Armas s/ Ambidestria)');
            } else {
                partesAtk.push('+0 (Ambidestria zera penalidade)');
            }
            const medSec = possuiPod('Arma Secundária Grande') ? 4.5 : 3.5;
            const dSec = medSec + fixoDano + dadosExtrasMedia + (medSec * chanceAmeacaD20);
            danoExtraSec += dSec;
            detExtras.push(`2ª Arma Mão Inábil (+${dSec.toFixed(1)} dano)`);
        }
        if (possuiPod('Ataque com Escudo') && escudo) {
            const medEsc = escudo.nome.toLowerCase().includes('pesado') ? 3.5 : 2.5;
            const dEsc = medEsc + Math.max(0, est.finais.FOR) + (possuiPod('Sangue de Ferro') ? 2 : 0);
            danoExtraSec += dEsc;
            detExtras.push(`Ataque com Escudo (+${dEsc.toFixed(1)} dano [1d6+FOR])`);
        }
        if (possuiPod('Piqueiro') && estilo === 'ARMA_LONGA_HASTE') {
            const dPiq = +(danoGolpe * 0.65).toFixed(1);
            danoExtraSec += dPiq;
            detExtras.push(`Reação Piqueiro (+${dPiq} dano médio)`);
        }

        // 3.6 Habilidade Racial / Concedida de Arma Natural Extra: Chifres (Minotauro p. 25) ou Mordida (Trog p. 31 / Presas Primordiais p. 134)
        const racaNomeLow = (est && est.racaNome) ? est.racaNome.toLowerCase() : ((window.__ULTIMO_ESTADO_FICHA__ && window.__ULTIMO_ESTADO_FICHA__.raca) ? window.__ULTIMO_ESTADO_FICHA__.raca.nome.toLowerCase() : '');
        const memOsteonLow = (est && est.racaAnteriorOsteon) ? est.racaAnteriorOsteon.toLowerCase() : '';
        const infoNatJS = !ehDist ? obterInfoArmaNaturalJS(racaNomeLow, memOsteonLow, todosPoderes) : null;
        if (infoNatJS) {
            const atqNat = (est.bonusPericias['Luta'] || 0) + (possuiPod('Valentão') ? 2 : 0) + (possuiPod('Fúria Divina') ? 2 : 0) + (ncLow === 'bárbaro' ? (2 + Math.floor((nivel - 1) / 5)) : 0);
            const fixoNat = Math.max(0, est.finais.FOR) + (possuiPod('Sangue de Ferro') ? 2 : 0) + (possuiPod('Valentão') ? 2 : 0) + (possuiPod('Fúria Divina') ? 2 : 0) + (ncLow === 'bárbaro' ? (2 + Math.floor((nivel - 1) / 5)) : 0);
            const dNat = +(infoNatJS.mediaDadoCrit + fixoNat).toFixed(1);
            danoExtraSec += dNat;
            detExtras.push(`${infoNatJS.icone} Ataque Extra ${infoNatJS.nomeCurto} [1 PM ao Agredir]: Atq +${atqNat}, Dano ${infoNatJS.dadoStr}+${fixoNat} perfuração (+${dNat} méd.)`);
        }

        // 3.7 Ataque Especial (Guerreiro p. 65 — aplicado a 1 ataque ao gastar PM: +B no Ataque OU +B no Dano OU +B/2 em ambos)
        if (nvGuerreiro >= 1) {
            const selModoAE = (typeof document !== 'undefined') ? document.getElementById('arena-sel-modo-ae') : null;
            const modoAE = selModoAE ? selModoAE.value : 'ATAQUE';
            let bAtqAE = escEspGuerreiro, bDanoAE = 0, descModoAE = `+${escEspGuerreiro} no Ataque (ou +${escEspGuerreiro} no Dano / +${escEspGuerreiro/2} em ambos)`;
            if (modoAE === 'DANO') {
                bAtqAE = 0; bDanoAE = escEspGuerreiro;
                descModoAE = `+${escEspGuerreiro} na Rolagem de Dano (+0 no Ataque)`;
            } else if (modoAE === 'DIVIDIDO') {
                bAtqAE = Math.floor(escEspGuerreiro / 2); bDanoAE = Math.floor(escEspGuerreiro / 2);
                descModoAE = `+${bAtqAE} no Ataque e +${bDanoAE} no Dano (Dividido Igualmente)`;
            }
            const evAE = +(bDanoAE + bAtqAE * 0.05 * danoGolpe).toFixed(1);
            danoExtraSec += evAE;
            detExtras.push(`Ataque Especial [${custoEspGuerreiro} PM, 1 atq]: ${descModoAE} (+${evAE} EV)`);
        }

        // 3.8 Otimizador Matemático do Poder Golpe Pessoal (Guerreiro Nv 5+, Livro p. 66-67)
        if (possuiPod('Golpe Pessoal')) {
            const mediaUmDado = (infoPasso.f + 1) / 2.0;
            const evCritLetal = +(mediaDadosArma * 0.35 + mediaUmDado + danoGolpe * 0.22 + (['DUAS_MAOS', 'ARMA_LONGA_HASTE'].includes(estilo) ? 4.0 : 0)).toFixed(1);
            const evElem = +(mediaUmDado + 7.0 + (nivel >= 5 ? 5.0 : 0) + danoGolpe * 0.20).toFixed(1);
            const usaCritLetal = evCritLetal >= evElem;
            const dTotalGP = Math.max(evCritLetal, evElem);
            const custoGP = usaCritLetal ? Math.min(nivel, 4) : Math.min(nivel, 5);
            const descGP = usaCritLetal
                ? `Destruidor (+1x Crít) + Letal (+2 Margem) + Brutal (+1d${infoPasso.f}) + Preciso (2d20 — escolhe o melhor) + Lento (-2 PM)`
                : `Brutal (+1d${infoPasso.f}) + Elemental (+2d6 Fogo) + Preciso (2d20 — escolhe o melhor) + Penetrante (-5 RD)`;
            danoExtraSec += dTotalGP;
            detExtras.push(`Golpe Pessoal Otimizado [${custoGP} PM — ${descGP}]: +${dTotalGP} EV`);
        }

        // Integração com Itens Superiores, Materiais Especiais e Itens Mágicos (Cap. 3 e Cap. 8)
        const stGlobal = (typeof window !== 'undefined' && window.__ULTIMO_ESTADO_FICHA__) ? window.__ULTIMO_ESTADO_FICHA__ : null;
        const resumoArsenal = stGlobal ? calcularResumoArsenalSuperiorEMagicoJS(stGlobal) : null;
        if (resumoArsenal) {
            if (resumoArsenal.bonusAtqArma > 0) {
                bonusAtk += resumoArsenal.bonusAtqArma;
                partesAtk.push(`+${resumoArsenal.bonusAtqArma} (Arsenal Superior/Mágico)`);
            }
            if (resumoArsenal.bonusDanoArma > 0) {
                fixoDano += resumoArsenal.bonusDanoArma;
                partesDano.push(`+${resumoArsenal.bonusDanoArma} (Arsenal Superior/Mágico)`);
            }
            if (resumoArsenal.bonusMargemCrit > 0) {
                margemCrit = Math.max(1, margemCrit - resumoArsenal.bonusMargemCrit);
            }
            if (resumoArsenal.duplicaMargem) {
                const ameacaAtual = (21 - margemCrit);
                margemCrit = Math.max(1, 21 - (ameacaAtual * 2));
            }
            if (resumoArsenal.bonusMultCrit > 0) {
                multCrit += resumoArsenal.bonusMultCrit;
            }
            if (resumoArsenal.mediaDadosExtrasArma > 0) {
                dadosExtrasMedia += resumoArsenal.mediaDadosExtrasArma;
                partesDano.push(`+${resumoArsenal.dadosExtrasArmaStr.join('+')} (Encanto/Injeção: +${resumoArsenal.mediaDadosExtrasArma})`);
            }
            if (resumoArsenal.veloz) {
                numAtaques += 1;
                detExtras.push('Encanto Veloz (+1 ataque extra por 1 PM, p. 337)');
            }
        }

        // Cálculo Oficial solicitado pelo usuário: Dano Médio = (Dano Máximo + Dano Mínimo) / 2
        let minDadosExtras = (resumoArsenal ? resumoArsenal.minDadosExtrasArma : 0);
        let maxDadosExtras = (resumoArsenal ? resumoArsenal.maxDadosExtrasArma : 0);
        if (nvCacador >= 1) { minDadosExtras += 1; maxDadosExtras += (nvCacador >= 13 ? 8 : (nvCacador >= 5 ? 6 : 4)); }
        if (nvLadino >= 1) { const df = Math.ceil(nvLadino / 2); minDadosExtras += df; maxDadosExtras += df * 6; }
        if (nvPaladino >= 1) { minDadosExtras += 1; maxDadosExtras += 8; }

        const danoMinimoGolpe = Math.max(1, infoPasso.q * 1 + fixoDano + minDadosExtras);
        const danoMaximoGolpe = Math.max(danoMinimoGolpe, infoPasso.q * infoPasso.f + fixoDano + maxDadosExtras);
        // Dano Médio Exato da Arma: (Dano Máximo + Dano Mínimo) / 2
        danoMedioArma = +((danoMaximoGolpe + danoMinimoGolpe) / 2.0).toFixed(1);
        const dprPotencialRodada = +(danoGolpe * numAtaques + danoExtraSec).toFixed(1);
        window.__ULTIMO_DANO_MIN_ARMA__ = danoMinimoGolpe;
        window.__ULTIMO_DANO_MAX_ARMA__ = danoMaximoGolpe;
        window.__ULTIMO_DPR_POTENCIAL_RODADA__ = dprPotencialRodada;

        const strCrit = `Crítico ${margemCrit}/x${multCrit} (${Math.round(chanceAmeacaD20 * 100)}% no d20: Normal ${danoMedioArma.toFixed(1)} / Crítico ${danoCriticoGolpe.toFixed(1)})`;
        const strExt = detExtras.length > 0 ? ` + [${detExtras.join(' + ')}]` : '';
        descDanoArma = `${arma.nome} [${estilo}] — Ataque ${bonusAtk >= 0 ? '+' + bonusAtk : bonusAtk} [Base 0 PM] (${partesAtk.join(' ')}) | Dano Base: ${partesDano.join(' ')} [Mín: ${danoMinimoGolpe} | Máx: ${danoMaximoGolpe} | Dano Médio (Máx+Mín)/2: ${danoMedioArma}] | ${strCrit}${strExt} | DPR Potencial c/ Combos: ${dprPotencialRodada}/rodada`;
    }

    // 4. Economia de Ações por Turno (Livro p. 232-235)
    const extrasTurno = [];
    if (possuiPod('Reflexos de Combate')) extrasTurno.push('+1 Ação de Movimento no 1º turno (Reflexos de Combate)');
    if (possuiPod('Surto Heroico')) extrasTurno.push('+1 Ação Padrão ou Movimento extra (Surto Heroico, 5 PM)');
    if (possuiPod('Magia Acelerada')) extrasTurno.push('+1 Magia como Ação Livre (Magia Acelerada, +4 PM)');
    if ((magias || []).some(m => m.nome.toLowerCase().includes('velocidade'))) extrasTurno.push('+1 Ação Padrão/Movimento extra (Magia Velocidade)');
    const rnEc = (est && est.racaNome) ? est.racaNome.toLowerCase() : '';
    const moEc = (est && est.racaAnteriorOsteon) ? est.racaAnteriorOsteon.toLowerCase() : '';
    if (rnEc === 'minotauro' || (rnEc === 'osteon' && moEc.includes('minotauro'))) {
        extrasTurno.push('+1 Ataque Extra c/ Chifres ao Agredir (Minotauro p. 25: 1 PM, 1x/rodada, 1d6+FOR perfuração)');
    }
    if ((classeObj.nome || '').toLowerCase() === 'guerreiro' && nivel >= 6) extrasTurno.push('+1 Ataque Extra Livre ao Agredir (Guerreiro Nv 6)');
    if (possuiPod('Golpe Pessoal')) extrasTurno.push('Golpe Pessoal Customizado (Brutal +1d + Elemental +2d6 + Preciso 2d20 — Guerreiro p. 66)');

    const acoesPadrao = arma ? [`Agredir com ${arma.nome}`] : [];
    const acoesMovimento = [`Deslocar-se até ${est.deslocamento}m`];
    const acoesCompletas = ['Investida (Desloca até 2x + Ataque c/ +2 Atq e -2 Def)'];
    const acoesLivres = [];
    const reacoes = [];

    for (const p of todosPoderes) {
        const acL = (p.acao || '').toLowerCase();
        const lbl = (p.custo_pm && p.custo_pm !== '0' && p.custo_pm !== 'Passivo') ? `${p.nome} (${p.custo_pm} PM)` : p.nome;
        if (acL.includes('completa')) acoesCompletas.push(lbl);
        else if (acL.includes('movimento')) acoesMovimento.push(lbl);
        else if (acL.includes('reação') || acL.includes('reacao')) reacoes.push(lbl);
        else if (acL.includes('livre')) acoesLivres.push(lbl);
        else if (acL.includes('padrão') || acL.includes('padrao')) acoesPadrao.push(lbl);
    }
    for (const m of (magias || []).slice(0, 8)) {
        const exL = (m.execucao || '').toLowerCase();
        const nmML = (m.nome || '').toLowerCase();
        if (nmML.includes('armadura arcana')) {
            reacoes.push('Magia: Armadura Arcana (Reação, 2 PM: +5 na Defesa contra o ataque, p. 179)');
            acoesPadrao.push('Magia: Armadura Arcana (Cena, 1 PM: +5 Defesa)');
        } else if (nmML.includes('campo de força')) {
            reacoes.push('Magia: Campo de Força (Reação, 4 PM: RD 30 contra o próximo dano, p. 182)');
            acoesPadrao.push('Magia: Campo de Força (Cena, 3 PM: 30 PV Temp)');
        } else if (nmML.includes('salto dimensional')) {
            reacoes.push('Magia: Salto Dimensional (Reação, 4 PM: +5 Defesa/Reflexos e salta 1,5m, p. 205)');
            acoesPadrao.push('Magia: Salto Dimensional (Padrão, 3 PM)');
        } else if (nmML.includes('concentração de combate')) {
            acoesLivres.push('Magia: Concentração de Combate (Livre, 1 PM: rola 2d20 no ataque e escolhe o melhor, p. 185)');
        } else if (exL.includes('reação') || exL.includes('reacao')) {
            reacoes.push(`Magia: ${m.nome} (Reação)`);
        } else if (exL.includes('movimento')) {
            acoesMovimento.push(`Magia: ${m.nome}`);
        } else if (exL.includes('completa')) {
            acoesCompletas.push(`Magia: ${m.nome}`);
        } else if (exL.includes('livre')) {
            acoesLivres.push(`Magia: ${m.nome}`);
        } else {
            acoesPadrao.push(`Magia: ${m.nome}`);
        }
    }
    // Exibe apenas reações reais presentes na ficha (sem ações genéricas fora do Livro Básico!)
    const ncA = (classeObj.nome || '').toLowerCase();
    if (ncA === 'guerreiro') {
        const cE = 1 + Math.floor((nivel - 1) / 4);
        const vE = 4 * cE;
        acoesLivres.unshift(`Ataque Especial (${cE} PM: +${vE} no Ataque OU +${vE} no Dano OU +${vE/2} Atq/+${vE/2} Dano — p. 65)`);
        if (possuiPod('Golpe Pessoal')) acoesLivres.splice(1, 0, 'Golpe Pessoal (Brutal +1d + Elemental +2d6 + Preciso 2d20 — p. 66)');
        if (nivel >= 3) reacoes.unshift('Durão (Reação, 3 PM: reduz o dano sofrido à metade — p. 65)');
    }
    if (rnEc === 'minotauro' || (rnEc === 'osteon' && moEc.includes('minotauro'))) {
        acoesLivres.unshift('Chifres (1 PM ao Agredir: +1 ataque corpo a corpo extra 1d6+FOR perfuração)');
    }
    else if (ncA === 'bárbaro') acoesLivres.unshift('Fúria (2 PM: +Atq/+Dano)');
    else if (ncA === 'paladino') acoesLivres.unshift('Golpe Divino (2 PM: +CAR Atq / +1d8 Dano)');
    else if (ncA === 'caçador') acoesMovimento.unshift('Marca da Presa (1 PM: +1d4 a +1d8 Dano)');
    else if (ncA === 'cavaleiro') { reacoes.unshift('Baluarte (Reação, 1 PM: +Defesa e +Resistências — p. 56)'); if (nivel >= 2) acoesLivres.unshift('Duelo (Livre, 2 PM: +2 Atq/Dano — p. 56)'); }

    const economiaAcoes = {
        resumoOrcamento: 'Orçamento Base por Turno: 1 Ação Padrão + 1 Ação de Movimento (ou 1 Ação Completa = Padrão + Movimento; ou 2 Ações de Movimento) + Ações Livres + Reações fora do turno' + (extrasTurno.length ? ' | Extras da Build: ' + extrasTurno.join(' ; ') : ''),
        acoesPadrao: acoesPadrao.length ? acoesPadrao : ['Agredir / Usar Habilidade'],
        acoesMovimento,
        acoesCompletas,
        acoesLivres: acoesLivres.length ? acoesLivres : ['Falar / Soltar item'],
        reacoes: reacoes.length ? reacoes : ['Testes de Resistência / Oportunidade']
    };

    return {
        limitePM, strLimitePM, danoMedioRaio, descRaio,
        maiorDanoMagia, maiorDanoMagiaArea, melhorMagiaInfo, melhorMagiaAreaInfo, detalhesMagias,
        danoMedioArma, descDanoArma, economiaAcoes
    };
}

