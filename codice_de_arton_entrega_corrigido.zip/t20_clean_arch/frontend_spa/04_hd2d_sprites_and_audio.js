if (typeof window !== 'undefined' && window.__SOM_JRPG_ATIVO__ === undefined) {
    window.__SOM_JRPG_ATIVO__ = true;
}
if (typeof window !== 'undefined' && typeof window.addEventListener === 'function' && !window.__AUDIO_UNLOCK_BOUND__) {
    window.__AUDIO_UNLOCK_BOUND__ = true;
    ['pointerdown', 'mousedown', 'touchstart', 'keydown'].forEach(evName => {
        window.addEventListener(evName, function() {
            try {
                const Ctx = window.AudioContext || window.webkitAudioContext;
                if (Ctx && !window.__AUDIO_CTX_T20__) window.__AUDIO_CTX_T20__ = new Ctx();
                if (window.__AUDIO_CTX_T20__ && window.__AUDIO_CTX_T20__.state === 'suspended') {
                    window.__AUDIO_CTX_T20__.resume();
                }
            } catch(e) {}
        }, { passive: true });
    });
}

function obterAudioCtxT20() {
    if (window.__SOM_JRPG_ATIVO__ === false) return null;
    try {
        if (!window.__AUDIO_CTX_T20__) {
            const Ctx = window.AudioContext || window.webkitAudioContext;
            if (Ctx) window.__AUDIO_CTX_T20__ = new Ctx();
        }
        if (window.__AUDIO_CTX_T20__ && window.__AUDIO_CTX_T20__.state === 'suspended') {
            window.__AUDIO_CTX_T20__.resume();
        }
        return window.__AUDIO_CTX_T20__;
    } catch (e) {
        return null;
    }
}

function tocarSomPorEfeitoAnimacaoJRPG(efeitoStr) {
    const agora = Date.now();
    if (window.__ULTIMO_SOM_ANIM_TS__ && (agora - window.__ULTIMO_SOM_ANIM_TS__ < 65)) return;
    window.__ULTIMO_SOM_ANIM_TS__ = agora;
    const ef = String(efeitoStr || 'SLASH').toUpperCase();
    if (ef.includes('SOPRO_FOGO') || ef.includes('INIMIGO_SOPRO') || ef === 'SOPRO_DRAGAO') {
        tocarSomJRPG('SOPRO_DRAGAO');
    } else if (ef.includes('GELO_RAIO') || ef.includes('MAGIA_RAIO') || ef.includes('RAIO')) {
        tocarSomJRPG('MAGIA_RAIO');
    } else if (ef.includes('ACIDO_GAS') || ef.includes('DRENAR') || ef.includes('INSANIDADE') || ef.includes('OLHAR') || ef.includes('TEIA')) {
        tocarSomJRPG('MAGIA_TREVAS');
    } else if (ef.includes('ESPINHOS') || ef.includes('ARTILHARIA') || ef.includes('DISPARO')) {
        tocarSomJRPG('DISPARO_ARCO');
    } else if (ef.includes('INVESTIDA') || ef.includes('ESMAGAMENTO') || ef.includes('IMPACTO')) {
        tocarSomJRPG('IMPACTO_ESMAGADOR');
    } else if (ef.includes('COMANDO') || ef.includes('SHIELD') || ef.includes('BUFF') || ef.includes('CURA') || ef.includes('DEFESA')) {
        tocarSomJRPG('CURA_BUFF_ESCUDO');
    } else if (ef.includes('MAGIA_FOGO') || ef === 'MAGIC' || ef.includes('MAGIA')) {
        tocarSomJRPG('MAGIA_FOGO');
    } else if (ef.includes('FURIA') || ef.includes('DILACERAR') || ef.includes('GARRAS') || ef.includes('MONSTRO')) {
        tocarSomJRPG('MORDIDA_GARRAS_MONSTRO');
    } else if (ef.includes('ESTOCADA')) {
        tocarSomJRPG('ESTOCADA_LANCEIRO');
    } else {
        tocarSomJRPG('ESPADA_SLASH');
    }
}

window.__BGM_JRPG_STATE__ = {
    tocando: false,
    timerId: null,
    passo: 0,
    temaAtual: '',
    bpm: 132
};

function mudarTemaGlobalAppJS(tema) {
    if (tema === 'OBSIDIAN') {
        document.body.removeAttribute('data-app-theme');
    } else {
        document.body.setAttribute('data-app-theme', tema);
    }
    const selEstArena = document.getElementById('arena-sel-estilo-visual');
    if (selEstArena) {
        selEstArena.value = (tema === 'PIXEL16') ? 'PIXEL16' : (tema === 'PARCHMENT' ? 'CLASSIC' : 'HD2D');
    }
    alternarEstiloVisualArenaJS((tema === 'PIXEL16') ? 'PIXEL16' : (tema === 'PARCHMENT' ? 'CLASSIC' : 'HD2D'));
}

function obterPerfilMusicalInimigoJS(grupoCap7, nomeCriatura, papel) {
    const g = ((grupoCap7 || '') + ' ' + (nomeCriatura || '')).toLowerCase();
    if (g.includes('drag')) {
        return {
            nomeTema: '🐉 Fúria de Sckharshantallas (Tema de Dragão)',
            bpm: 148,
            ondaLead: 'sawtooth',
            ondaBass: 'sawtooth',
            notasLead: [293.66, 311.13, 369.99, 440.00, 466.16, 440.00, 369.99, 311.13, 293.66, 369.99, 440.00, 587.33, 554.37, 466.16, 440.00, 369.99],
            notasBass: [73.42, 73.42, 110.00, 73.42, 77.78, 77.78, 116.54, 77.78]
        };
    }
    if (g.includes('tormenta') || g.includes('lefeu') || g.includes('lefou') || g.includes('aharadak')) {
        return {
            nomeTema: '👁️ Olho Rubro de Aharadak (Tema da Tormenta)',
            bpm: 156,
            ondaLead: 'sawtooth',
            ondaBass: 'square',
            notasLead: [261.63, 277.18, 369.99, 261.63, 311.13, 369.99, 523.25, 369.99, 277.18, 261.63, 369.99, 466.16, 369.99, 311.13, 277.18, 246.94],
            notasBass: [65.41, 92.50, 65.41, 69.30, 65.41, 92.50, 77.78, 69.30]
        };
    }
    if (g.includes('morto') || g.includes('necromante') || g.includes('vampiro') || g.includes('zumbi') || g.includes('esqueleto') || g.includes('aparição') || g.includes('falange')) {
        return {
            nomeTema: '💀 Noite Eterna de Aslothia (Tema dos Mortos-Vivos)',
            bpm: 116,
            ondaLead: 'triangle',
            ondaBass: 'sawtooth',
            notasLead: [220.00, 261.63, 329.63, 415.30, 440.00, 415.30, 329.63, 261.63, 246.94, 293.66, 349.23, 415.30, 329.63, 293.66, 261.63, 220.00],
            notasBass: [55.00, 55.00, 82.41, 55.00, 65.41, 61.74, 55.00, 51.91]
        };
    }
    if (g.includes('purista') || g.includes('leopardo') || g.includes('baluarte') || g.includes('sargento')) {
        return {
            nomeTema: '🦅 Marcha de Ferro da Supremacia (Tema Purista)',
            bpm: 134,
            ondaLead: 'square',
            ondaBass: 'sawtooth',
            notasLead: [196.00, 196.00, 293.66, 261.63, 233.08, 196.00, 293.66, 392.00, 349.23, 311.13, 293.66, 261.63, 233.08, 261.63, 293.66, 196.00],
            notasBass: [49.00, 49.00, 73.42, 49.00, 58.27, 65.41, 73.42, 49.00]
        };
    }
    if (g.includes('duyshidakk') || g.includes('goblin') || g.includes('hobgoblin') || g.includes('bugbear') || g.includes('orc')) {
        return {
            nomeTema: '👺 Tambores da Aliança Negra (Tema Duyshidakk)',
            bpm: 144,
            ondaLead: 'square',
            ondaBass: 'triangle',
            notasLead: [293.66, 349.23, 392.00, 440.00, 392.00, 349.23, 293.66, 261.63, 293.66, 349.23, 466.16, 440.00, 392.00, 349.23, 329.63, 293.66],
            notasBass: [73.42, 110.00, 73.42, 87.31, 73.42, 110.00, 65.41, 73.42]
        };
    }
    if (g.includes('cultista') || g.includes('nagah') || g.includes('medusa') || g.includes('naja') || g.includes('cascavel') || g.includes('sucuri')) {
        return {
            nomeTema: '🐍 Santuário de Sszzaas (Tema dos Cultistas)',
            bpm: 126,
            ondaLead: 'sine',
            ondaBass: 'sawtooth',
            notasLead: [329.63, 349.23, 415.30, 440.00, 493.88, 523.25, 493.88, 415.30, 349.23, 329.63, 415.30, 349.23, 329.63, 293.66, 349.23, 329.63],
            notasBass: [82.41, 82.41, 87.31, 82.41, 110.00, 87.31, 82.41, 73.42]
        };
    }
    if (g.includes('troll') || g.includes('ermo') || g.includes('wyvern') || g.includes('grifo') || g.includes('ogro')) {
        return {
            nomeTema: '🌲 Caçada Selvagem de Arton (Tema dos Ermos & Trolls)',
            bpm: 138,
            ondaLead: 'sawtooth',
            ondaBass: 'triangle',
            notasLead: [220.00, 261.63, 293.66, 329.63, 392.00, 329.63, 293.66, 261.63, 220.00, 329.63, 369.99, 392.00, 440.00, 392.00, 329.63, 293.66],
            notasBass: [55.00, 82.41, 55.00, 73.42, 65.41, 73.42, 55.00, 49.00]
        };
    }
    return {
        nomeTema: '🗝️ Profundezas das Masmorras (Tema Clássico JRPG)',
        bpm: 132,
        ondaLead: 'square',
        ondaBass: 'triangle',
        notasLead: [329.63, 392.00, 493.88, 659.25, 587.33, 493.88, 392.00, 329.63, 349.23, 440.00, 523.25, 698.46, 659.25, 587.33, 493.88, 392.00],
        notasBass: [82.41, 82.41, 123.47, 82.41, 87.31, 87.31, 98.00, 123.47]
    };
}

function dispararRuidoSintetizado(ctx, dur, freqFiltro, tipoFiltro, vol, tStart) {
    try {
        const bufferSize = Math.max(256, Math.floor(ctx.sampleRate * dur));
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.45));
        }
        const noise = ctx.createBufferSource();
        noise.buffer = buffer;
        const filter = ctx.createBiquadFilter();
        filter.type = tipoFiltro || 'bandpass';
        filter.frequency.setValueAtTime(freqFiltro || 1000, tStart);
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(vol || 0.12, tStart);
        gain.gain.exponentialRampToValueAtTime(0.001, tStart + dur);
        noise.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        noise.start(tStart);
        noise.stop(tStart + dur + 0.01);
    } catch (e) {}
}

function atualizarTrilhaSonoraInimigoAtualJS() {
    const bgm = window.__BGM_JRPG_STATE__;
    if (!bgm || !bgm.tocando) return;
    iniciarTrilhaSonoraInimigoJRPG(true);
}

function alternarTrilhaSonoraJRPG() {
    const bgm = window.__BGM_JRPG_STATE__;
    if (bgm.tocando) {
        pararTrilhaSonoraJRPG();
    } else {
        iniciarTrilhaSonoraInimigoJRPG(false);
    }
}

function pararTrilhaSonoraJRPG() {
    const bgm = window.__BGM_JRPG_STATE__;
    bgm.tocando = false;
    if (bgm.timerId) {
        clearInterval(bgm.timerId);
        bgm.timerId = null;
    }
    const btnBgm = document.getElementById('btn-toggle-bgm-jrpg');
    if (btnBgm) {
        btnBgm.innerHTML = '🎵 Trilha do Inimigo (BGM): PAUSADA (Clique p/ Tocar)';
        btnBgm.style.background = '#334155';
    }
}

function iniciarTrilhaSonoraInimigoJRPG(silencioso) {
    const ctx = obterAudioCtxT20();
    if (!ctx) return;
    const bgm = window.__BGM_JRPG_STATE__;
    if (bgm.timerId) {
        clearInterval(bgm.timerId);
        bgm.timerId = null;
    }
    const a = __ARENA_STATE__;
    const priv = a && a._privadoCriatura ? a._privadoCriatura : { grupoCap7: 'Masmorras', nomeCriatura: 'Ameaça', papel: 'Solo' };
    const perfil = obterPerfilMusicalInimigoJS(priv.grupoCap7, priv.nomeCriatura, priv.papel);

    bgm.tocando = true;
    bgm.temaAtual = perfil.nomeTema;
    bgm.bpm = perfil.bpm;
    bgm.passo = 0;

    const btnBgm = document.getElementById('btn-toggle-bgm-jrpg');
    if (btnBgm) {
        btnBgm.innerHTML = `🎵 BGM Ativa: ${perfil.nomeTema} (${perfil.bpm} BPM) [⏸️ Pausar]`;
        btnBgm.style.background = 'linear-gradient(135deg, #6D28D9, #9333EA)';
    }

    const stepMs = Math.round((60000 / perfil.bpm) / 2);
    bgm.timerId = setInterval(() => {
        if (!bgm.tocando || !window.__SOM_JRPG_ATIVO__) return;
        const c = obterAudioCtxT20();
        if (!c) return;
        const now = c.currentTime;
        const idx = bgm.passo % 16;
        const fLead = perfil.notasLead[idx % perfil.notasLead.length];
        const fBass = perfil.notasBass[Math.floor(idx / 2) % perfil.notasBass.length];

        try {
            // 1. Baixo Ostinato de Batalha
            const oscB = c.createOscillator();
            const gB = c.createGain();
            oscB.type = perfil.ondaBass;
            oscB.frequency.setValueAtTime(fBass, now);
            gB.gain.setValueAtTime(0.055, now);
            gB.gain.exponentialRampToValueAtTime(0.002, now + (stepMs / 1000) * 0.92);
            oscB.connect(gB);
            gB.connect(c.destination);
            oscB.start(now);
            oscB.stop(now + (stepMs / 1000));

            // 2. Melodia Principal do Inimigo
            if (idx % 2 === 0 || idx % 3 === 0) {
                const oscL = c.createOscillator();
                const gL = c.createGain();
                oscL.type = perfil.ondaLead;
                oscL.frequency.setValueAtTime(fLead, now);
                gL.gain.setValueAtTime(0.038, now);
                gL.gain.exponentialRampToValueAtTime(0.002, now + (stepMs / 1000) * 0.88);
                oscL.connect(gL);
                gL.connect(c.destination);
                oscL.start(now);
                oscL.stop(now + (stepMs / 1000));
            }

            // 3. Percussão de Batalha (Bumbo nos tempos 0, 4, 8, 12 e Caixa nos tempos 2, 6, 10, 14)
            if (idx % 4 === 0) {
                const oscK = c.createOscillator();
                const gK = c.createGain();
                oscK.type = 'sine';
                oscK.frequency.setValueAtTime(115, now);
                oscK.frequency.exponentialRampToValueAtTime(32, now + 0.09);
                gK.gain.setValueAtTime(0.08, now);
                gK.gain.exponentialRampToValueAtTime(0.001, now + 0.10);
                oscK.connect(gK);
                gK.connect(c.destination);
                oscK.start(now);
                oscK.stop(now + 0.11);
            } else if (idx % 4 === 2) {
                dispararRuidoSintetizado(c, 0.065, 1600, 'highpass', 0.035, now);
            }
        } catch (e) {}

        bgm.passo++;
    }, stepMs);
}

function alternarSomArenaJRPG() {
    window.__SOM_JRPG_ATIVO__ = !window.__SOM_JRPG_ATIVO__;
    const btn = document.getElementById('btn-toggle-som-jrpg');
    if (btn) {
        btn.innerHTML = window.__SOM_JRPG_ATIVO__ ? '🔊 Efeitos Sonoros (SFX): ON' : '🔇 Efeitos Sonoros: MUDO';
        btn.style.background = window.__SOM_JRPG_ATIVO__ ? '#065F46' : '#475569';
    }
    if (window.__SOM_JRPG_ATIVO__) tocarSomJRPG('UI_CLICK');
}

function tocarSomJRPG(tipo) {
    const ctx = obterAudioCtxT20();
    if (!ctx) return;
    const now = ctx.currentTime;

    const nota = (freq, fEnd, tStart, dur, wave, vol) => {
        try {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = wave || 'triangle';
            osc.frequency.setValueAtTime(Math.max(20, freq), tStart);
            if (fEnd && fEnd !== freq) {
                osc.frequency.exponentialRampToValueAtTime(Math.max(20, fEnd), tStart + dur);
            }
            gain.gain.setValueAtTime(vol || 0.14, tStart);
            gain.gain.exponentialRampToValueAtTime(0.001, tStart + dur);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(tStart);
            osc.stop(tStart + dur + 0.02);
        } catch (e) {}
    };

    if (tipo === 'DADOS') {
        [0, 0.05, 0.10, 0.16, 0.22].forEach((dt, i) => {
            nota(360 + i * 110 + Math.random() * 90, 190, now + dt, 0.045, 'triangle', 0.12);
            dispararRuidoSintetizado(ctx, 0.025, 2400, 'bandpass', 0.05, now + dt);
        });
    } else if (tipo === 'ESPADA_SLASH') {
        // Corte metálico de espada + assobio no ar + impacto
        dispararRuidoSintetizado(ctx, 0.15, 3200, 'bandpass', 0.14, now);
        nota(1350, 260, now, 0.16, 'sawtooth', 0.16);
        nota(160, 48, now + 0.07, 0.18, 'sine', 0.24);
    } else if (tipo === 'IMPACTO_ESMAGADOR') {
        // Esmagamento sísmico de Machado / Marreta / Martelo
        nota(210, 38, now, 0.32, 'sine', 0.28);
        nota(110, 28, now + 0.04, 0.35, 'sawtooth', 0.22);
        dispararRuidoSintetizado(ctx, 0.26, 420, 'lowpass', 0.22, now + 0.03);
    } else if (tipo === 'ESTOCADA_LANCEIRO') {
        // Estocada rápida tripla (Florete / Alabarda / Chifres / Adaga)
        [0, 0.08, 0.16].forEach((dt) => {
            nota(1650, 320, now + dt, 0.09, 'sawtooth', 0.14);
            dispararRuidoSintetizado(ctx, 0.07, 2800, 'highpass', 0.10, now + dt);
        });
    } else if (tipo === 'DISPARO_ARCO') {
        // Corda de arco vibrando + assobio de flecha + cravada no alvo
        nota(180, 95, now, 0.12, 'triangle', 0.18);
        dispararRuidoSintetizado(ctx, 0.18, 2600, 'bandpass', 0.12, now + 0.04);
        nota(420, 110, now + 0.18, 0.10, 'sine', 0.20);
    } else if (tipo === 'TIRO_MOSQUETE') {
        // Estouro de pólvora de Mosquete / Pistola + ricochete
        dispararRuidoSintetizado(ctx, 0.28, 850, 'lowpass', 0.26, now);
        nota(190, 42, now, 0.24, 'sawtooth', 0.24);
        nota(1800, 620, now + 0.12, 0.16, 'sine', 0.11);
    } else if (tipo === 'MAGIA_FOGO') {
        // Explosão de Bola de Fogo / Chamas
        dispararRuidoSintetizado(ctx, 0.42, 650, 'bandpass', 0.24, now);
        nota(320, 75, now, 0.38, 'sawtooth', 0.18);
        nota(580, 140, now + 0.08, 0.32, 'triangle', 0.15);
    } else if (tipo === 'MAGIA_RAIO') {
        // Trovão e descargas elétricas de Relâmpago / Toque Chocante
        for (let k = 0; k < 6; k++) {
            nota(600 + Math.random() * 1600, 220, now + k * 0.045, 0.05, 'sawtooth', 0.14);
        }
        dispararRuidoSintetizado(ctx, 0.35, 1800, 'bandpass', 0.18, now + 0.05);
    } else if (tipo === 'MAGIA_TREVAS') {
        // Dreno necrótico / Trevas / Veneno
        nota(140, 290, now, 0.22, 'sawtooth', 0.15);
        nota(285, 82, now + 0.18, 0.28, 'sawtooth', 0.16);
    } else if (tipo === 'CURA_BUFF_ESCUDO') {
        // Acorde celestial de Cura / Armadura Arcana / Campo de Força / Escudo da Fé
        [523.25, 659.25, 783.99, 987.77, 1046.50].forEach((f, idx) => {
            nota(f, f * 1.01, now + idx * 0.055, 0.24, 'sine', 0.12);
        });
    } else if (tipo === 'SOPRO_DRAGAO') {
        // Rugido dracônico + torrente de sopro elemental
        nota(135, 58, now, 0.45, 'sawtooth', 0.24);
        nota(202, 85, now + 0.05, 0.45, 'sawtooth', 0.18);
        dispararRuidoSintetizado(ctx, 0.55, 780, 'bandpass', 0.25, now + 0.08);
    } else if (tipo === 'MORDIDA_GARRAS_MONSTRO') {
        // Rosnado feroz + rasgo duplo de garras e presas
        nota(165, 65, now, 0.22, 'sawtooth', 0.22);
        dispararRuidoSintetizado(ctx, 0.14, 2100, 'bandpass', 0.18, now + 0.04);
        dispararRuidoSintetizado(ctx, 0.14, 1800, 'bandpass', 0.18, now + 0.16);
    } else if (tipo === 'CRITICO') {
        dispararRuidoSintetizado(ctx, 0.18, 2800, 'bandpass', 0.18, now);
        nota(1100, 180, now, 0.18, 'sawtooth', 0.20);
        [523.25, 659.25, 783.99, 1046.5].forEach((f, idx) => {
            nota(f, f * 1.02, now + 0.05 + idx * 0.055, 0.16, 'square', 0.14);
        });
    } else if (tipo === 'MAGIA') {
        [392.00, 523.25, 659.25, 783.99].forEach((f, idx) => {
            nota(f, f * 1.25, now + idx * 0.05, 0.20, 'triangle', 0.14);
        });
    } else if (tipo === 'CHIFRES_MORDIDA') {
        nota(185, 68, now + 0.05, 0.20, 'sawtooth', 0.20);
        nota(420, 140, now + 0.08, 0.14, 'triangle', 0.16);
    } else if (tipo === 'MISS_DEFESA') {
        nota(880, 540, now, 0.10, 'square', 0.12);
        nota(440, 260, now + 0.05, 0.10, 'triangle', 0.11);
    } else if (tipo === 'VITORIA') {
        const melodia = [
            [523.25, 0.00, 0.11], [523.25, 0.12, 0.11], [523.25, 0.24, 0.11],
            [523.25, 0.36, 0.32], [415.30, 0.70, 0.24], [466.16, 0.96, 0.24],
            [523.25, 1.22, 0.16], [466.16, 1.42, 0.12], [523.25, 1.56, 0.55]
        ];
        melodia.forEach(([f, t, d]) => nota(f, f, now + t, d, 'triangle', 0.16));
    } else {
        nota(660, 880, now, 0.06, 'sine', 0.09);
    }
}

window.__APARENCIA_HEROI__ = window.__APARENCIA_HEROI__ || {
    racaSincronizada: '',
    corPele: '',
    estiloCabeca: 'RACIAL_CLASSICO',
    penteado: 'HEROICO_CLASSICO',
    corCabelo: '#1E293B',
    estiloTraje: 'AUTO_CLASSE',
    materialEspecial: 'ACO_PADRAO',
    corTraje: '#7F1D1D|#991B1B',
    capaCostas: 'CAPA_REAL',
    postura: 'HEROICA_CLASSICA',
    expressao: 'DETERMINADO',
    maoSecundaria: 'AUTO_FICHA',
    efeitoArma: 'ACO_FORJADO',
    estiloArte: 'HQ_TORMENTA20'
};

function obterPaletaRacialHeroiJS(nomeRaca) {
    const nr = (nomeRaca || 'humano').toLowerCase();
    return PALETAS_RACIAIS_T20[nr] || PALETAS_RACIAIS_T20['padrao'];
}

function sincronizarSeletoresAparenciaComRacaJS(racaNome, forcarPadrao) {
    const nr = (racaNome || 'Humano').toLowerCase();
    window.__APARENCIA_HEROI__ = window.__APARENCIA_HEROI__ || {};
    const ap = window.__APARENCIA_HEROI__;
    const paleta = obterPaletaRacialHeroiJS(nr);
    if (forcarPadrao || !ap.corPele || ap.racaSincronizada !== nr || !paleta.some(p => p.cor === ap.corPele)) {
        ap.corPele = paleta[0].cor;
        ap.racaSincronizada = nr;
    }
    ['ap-sel-pele', 'ficha-ap-sel-pele'].forEach(idSel => {
        const selPele = document.getElementById(idSel);
        if (selPele) {
            if (selPele.dataset.racaAtual !== nr || selPele.options.length !== paleta.length) {
                selPele.innerHTML = paleta.map(p => `<option value="${p.cor}">${p.nome}</option>`).join('');
                selPele.dataset.racaAtual = nr;
            }
            selPele.value = ap.corPele;
        }
    });
}

function criarObjetoArmaPorNomeCatalogoOuCustomJS(nomeA) {
    if (!nomeA || nomeA === 'Nenhum' || nomeA === 'AUTO_FICHA') return null;
    const partesEx = String(nomeA).split('#');
    const nomeBaseLimpo = partesEx[0].trim();
    if (window.__APARENCIA_HEROI__) {
        window.__APARENCIA_HEROI__.exemplarArma = partesEx[1] || 'EX1';
    }
    let achou = (CATALOGO_T20.itens || []).find(i => i.nome.toLowerCase() === nomeBaseLimpo.toLowerCase());
    if (achou) return achou;
    const nl = nomeA.toLowerCase();
    const ehDist = nl.includes('arco') || nl.includes('besta') || nl.includes('funda') || nl.includes('azagaia') || nl.includes('shuriken');
    const ehFogo = nl.includes('mosquete') || nl.includes('pistola');
    const eh2Maos = nl.includes('montante') || nl.includes('machado de guerra') || nl.includes('táurico') || nl.includes('marreta') || nl.includes('alabarda') || nl.includes('pique') || nl.includes('gadanho') || nl.includes('corrente') || nl.includes('bordão') || nl.includes('tacape');
    let dano = '1d8';
    if (nl.includes('táurico') || nl.includes('mosquete')) dano = '2d8';
    else if (nl.includes('marreta')) dano = '3d4';
    else if (nl.includes('gadanho')) dano = '2d4';
    else if (nl.includes('montante') || nl.includes('pistola') || nl.includes('corrente')) dano = '2d6';
    else if (nl.includes('machado de guerra') || nl.includes('besta pesada')) dano = '1d12';
    else if (nl.includes('alabarda') || nl.includes('bastarda') || nl.includes('katana') || nl.includes('machado anão')) dano = '1d10';
    else if (nl.includes('florete') || nl.includes('cimitarra') || nl.includes('curta') || nl.includes('lança') || nl.includes('clava') || nl.includes('bordão')) dano = '1d6';
    else if (nl.includes('adaga') || nl.includes('manopla') || nl.includes('funda')) dano = '1d4';
    let crit = '19/x2';
    if (nl.includes('gadanho') || nl.includes('picareta')) crit = 'x4';
    else if (nl.includes('mosquete') || nl.includes('pistola')) crit = '19/x3';
    else if (nl.includes('florete') || nl.includes('cimitarra')) crit = '18/x2';
    else if (nl.includes('machado') || nl.includes('alabarda') || nl.includes('arco')) crit = 'x3';
    else if (nl.includes('maça') || nl.includes('marreta') || nl.includes('tacape') || nl.includes('bordão') || nl.includes('cajado') || nl.includes('manopla')) crit = 'x2';
    return {
        id_item: 'ARMA_' + nomeA.slice(0, 8).toUpperCase().replace(/\s+/g, '_'),
        nome: nomeA,
        categoria: 'Arma',
        subcategoria: ehFogo ? 'Arma de Fogo' : (ehDist ? 'Arma Marcial à Distância' : ('Arma Marcial Corpo a Corpo' + (eh2Maos ? ' — Duas Mãos' : ' — Uma Mão'))),
        preco: 'T$ 50',
        dano_ou_defesa: dano,
        critico_ou_penalidade: crit,
        espacos: eh2Maos ? 2 : 1,
        efeito_propriedades: (nl.includes('alabarda') || nl.includes('pique') || nl.includes('corrente')) ? 'Alongada' : 'Equipada na Ficha & Arena'
    };
}

function rolarDanoArmaEquipadaLivreJS() {
    const st = garantirEstadoFichaParaArena();
    const nmA = (st.arma && st.arma.nome) ? st.arma.nome : 'Ataque Desarmado';
    const dnA = (st.arma && st.arma.dano_ou_defesa && /\d+d\d+/.test(st.arma.dano_ou_defesa)) ? st.arma.dano_ou_defesa.match(/\d+d\d+/)[0] : '1d6';
    rolarDadosLivresMesa(dnA, `${nmA} (${dnA})`);
}

function sincronizarHeroiNaArenaSemResetarInimigoJS() {
    const st = window.__ULTIMO_ESTADO_FICHA__;
    if (!st) return;
    const selArmaStudio = document.getElementById('ap-sel-arma-custom');
    if (selArmaStudio && st.arma && st.arma.nome) {
        const optMatch = Array.from(selArmaStudio.options).find(o => o.value.toLowerCase() === st.arma.nome.toLowerCase());
        selArmaStudio.value = optMatch ? optMatch.value : 'AUTO_FICHA';
    }
    const btnDadoArma = document.getElementById('btn-dado-arma-atual');
    if (btnDadoArma) {
        const nmA = (st.arma && st.arma.nome) ? st.arma.nome : 'Desarmado';
        const dnA = (st.arma && st.arma.dano_ou_defesa && /\d+d\d+/.test(st.arma.dano_ou_defesa)) ? st.arma.dano_ou_defesa.match(/\d+d\d+/)[0] : '1d6';
        btnDadoArma.innerHTML = `🗡️ ${dnA} (${nmA})`;
    }
    if (__ARENA_STATE__) {
        const a = __ARENA_STATE__;
        a.pvHeroiMax = st.est.pvMax;
        a.pvHeroi = Math.min(a.pvHeroiMax, Math.max(1, a.pvHeroi));
        a.pmHeroiMax = st.est.pmMax;
        a.pmHeroi = Math.min(a.pmHeroiMax, a.pmHeroi);
        a.defHeroiBase = st.est.defesa;
        atualizarPlacarVisualArena();
        renderizarPalcoJRPG(st, a, null);
    }
}

function trocarArmaEquipadaVisualJS(valorDireto) {
    const selArena = document.getElementById('ap-sel-arma-custom');
    const selFicha = document.getElementById('ficha-ap-sel-arma-custom');
    const nomeA = valorDireto || (selArena ? selArena.value : (selFicha ? selFicha.value : ''));
    if (!nomeA) return;
    if (selArena) selArena.value = nomeA;
    if (selFicha) selFicha.value = nomeA;
    const st = garantirEstadoFichaParaArena();
    if (nomeA && nomeA !== 'AUTO_FICHA') {
        const achou = criarObjetoArmaPorNomeCatalogoOuCustomJS(nomeA);
        if (achou) {
            st.arma = achou;
            if (!st.itens.some(i => i.nome.toLowerCase() === achou.nome.toLowerCase())) st.itens.unshift(achou);
            st.est = calcularEstatisticaCompletaT20({
                nivel: st.nivel, raca: st.raca, classe: st.classe, origem: st.origem, deus: st.deus,
                caminhoArcanista: st.caminhoArcanista, atrBase: st.atrBase, livres: st.livres,
                pericias: st.pericias, poderes: st.poderes, itens: st.itens,
                arma: st.arma, armadura: st.armadura, escudo: st.escudo
            });
            tocarSomJRPG('ESPADA_SLASH');
            renderizarFichaEArvoreClientSide(st, null, `Arma alterada para ${achou.nome}!`);
        }
    }
    aplicarMudancaAparenciaManualJS();
    sincronizarHeroiNaArenaSemResetarInimigoJS();
}

function sincronizarTodosSeletoresAparenciaFichaEArenaJS() {
    window.__APARENCIA_HEROI__ = window.__APARENCIA_HEROI__ || {};
    const ap = window.__APARENCIA_HEROI__;
    if (ap.estiloCabeca && !ap.acessorioCabeca) ap.acessorioCabeca = ap.estiloCabeca;
    if (ap.acessorioCabeca && !ap.estiloCabeca) ap.estiloCabeca = ap.acessorioCabeca;

    const pares = [
        ['corPele', 'ap-sel-pele', 'ficha-ap-sel-pele'],
        ['estiloCabeca', 'ap-sel-cabeca', 'ficha-ap-sel-cabeca'],
        ['penteado', 'ap-sel-penteado', 'ficha-ap-sel-penteado'],
        ['corCabelo', 'ap-sel-cabelo', 'ficha-ap-sel-cabelo'],
        ['estiloTraje', 'ap-sel-traje', 'ficha-ap-sel-traje'],
        ['materialEspecial', 'ap-sel-material-especial', 'ficha-ap-sel-material-especial'],
        ['corTraje', 'ap-sel-cor-traje', 'ficha-ap-sel-cor-traje'],
        ['capaCostas', 'ap-sel-capa-costas', 'ficha-ap-sel-capa-costas'],
        ['ombreiras', 'ap-sel-ombreiras', 'ficha-ap-sel-ombreiras'],
        ['postura', 'ap-sel-postura', 'ficha-ap-sel-postura'],
        ['expressao', 'ap-sel-expressao', 'ficha-ap-sel-expressao'],
        ['maoSecundaria', 'ap-sel-mao-secundaria', 'ficha-ap-sel-mao-secundaria'],
        ['efeitoArma', 'ap-sel-efeito-arma', 'ficha-ap-sel-efeito-arma'],
        ['auraParticulas', 'ap-sel-aura-particulas', 'ficha-ap-sel-aura-particulas'],
        ['estiloArte', 'ap-sel-estilo-arte', 'ficha-ap-sel-estilo-arte']
    ];
    pares.forEach(([prop, idArena, idFicha]) => {
        const val = ap[prop];
        if (!val) return;
        const elA = document.getElementById(idArena);
        const elF = document.getElementById(idFicha);
        if (elA && elA.value !== val) {
            if (idArena === 'ap-sel-pele' && elA.options.length === 0) {
                const st = garantirEstadoFichaParaArena();
                sincronizarSeletoresAparenciaComRacaJS((st && st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : 'humano', false);
            }
            elA.value = val;
        }
        if (elF && elF.value !== val) {
            if (idFicha === 'ficha-ap-sel-pele' && elF.options.length === 0) {
                const st = garantirEstadoFichaParaArena();
                const pal = obterPaletaRacialHeroiJS((st && st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : 'humano');
                elF.innerHTML = pal.map(p => `<option value="${p.cor}">${p.nome}</option>`).join('');
            }
            elF.value = val;
        }
    });
}

function aplicarMudancaAparenciaSincronizadaJS(origem, chaveEspecifica, valorEspecifico) {
    try { tocarSomJRPG('UI_CLICK'); } catch(e) {}
    window.__APARENCIA_CUSTOMIZADA_PELO_USUARIO__ = true;
    window.__APARENCIA_HEROI__ = window.__APARENCIA_HEROI__ || {};
    const ap = window.__APARENCIA_HEROI__;
    if (chaveEspecifica && valorEspecifico !== undefined) {
        ap[chaveEspecifica] = valorEspecifico;
        if (chaveEspecifica === 'estiloCabeca' || chaveEspecifica === 'acessorioCabeca') {
            ap.estiloCabeca = valorEspecifico;
            ap.acessorioCabeca = valorEspecifico;
        }
    }
    const pfx = (origem === 'FICHA') ? 'ficha-ap-sel-' : 'ap-sel-';
    const getVal = (suf) => {
        const el = document.getElementById(pfx + suf) || document.getElementById('ap-sel-' + suf) || document.getElementById('ficha-ap-sel-' + suf);
        return el ? el.value : '';
    };
    if (!chaveEspecifica) {
        if (getVal('pele')) ap.corPele = getVal('pele');
        if (getVal('cabeca')) { ap.estiloCabeca = getVal('cabeca'); ap.acessorioCabeca = getVal('cabeca'); }
        if (getVal('penteado')) ap.penteado = getVal('penteado');
        if (getVal('cabelo')) ap.corCabelo = getVal('cabelo');
        if (getVal('traje')) ap.estiloTraje = getVal('traje');
        if (getVal('material-especial')) ap.materialEspecial = getVal('material-especial');
        if (getVal('cor-traje')) ap.corTraje = getVal('cor-traje');
        if (getVal('capa-costas')) ap.capaCostas = getVal('capa-costas');
        if (getVal('ombreiras')) ap.ombreiras = getVal('ombreiras');
        if (getVal('postura')) ap.postura = getVal('postura');
        if (getVal('expressao')) ap.expressao = getVal('expressao');
        if (getVal('mao-secundaria')) ap.maoSecundaria = getVal('mao-secundaria');
        if (getVal('efeito-arma')) ap.efeitoArma = getVal('efeito-arma');
        if (getVal('aura-particulas')) ap.auraParticulas = getVal('aura-particulas');
        if (getVal('estilo-arte')) ap.estiloArte = getVal('estilo-arte');
    }
    sincronizarTodosSeletoresAparenciaFichaEArenaJS();
    atualizarRetratoFichaPrincipalJS();
    const st = garantirEstadoFichaParaArena();
    if (typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
        renderizarPalcoJRPG(st, __ARENA_STATE__, null);
    }
    if (typeof renderizarMesaOnlineCompletaUI === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) {
        renderizarMesaOnlineCompletaUI();
    }
}

function aplicarMudancaAparenciaManualJS(origem) {
    aplicarMudancaAparenciaSincronizadaJS(origem || 'ARENA');
}

function sortearAparenciaAleatoriaRacialJS() {
    tocarSomJRPG('UI_CLICK');
    const st = garantirEstadoFichaParaArena();
    const nr = (st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : 'humano';
    sincronizarSeletoresAparenciaComRacaJS(nr, false);
    const paleta = obterPaletaRacialHeroiJS(nr);
    const ap = window.__APARENCIA_HEROI__;

    const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
    ap.corPele = pick(paleta).cor;
    ap.estiloCabeca = pick(['RACIAL_CLASSICO', 'VETERANO_GUERRA', 'ELMO_TEMPLARIO', 'ELMO_VALQUIRIA', 'ELMO_GLADIADOR', 'CAPUZ_SOMBRIO', 'CHAPEU_TRICORNE', 'CHAPEU_ARCANO', 'BANDANA_SAMURAI', 'MASCARA_SSZZAAS', 'COROA_ARTON']); ap.acessorioCabeca = ap.estiloCabeca; ap.auraParticulas = pick(['NENHUMA', 'CHAMAS_SOLARES', 'RAIOS_TEMPESTADE', 'CRISTAIS_GELO', 'LUZ_DIVINA', 'TREVAS_TENEBRA', 'FOLHAS_ALLIHANNA']);
    ap.penteado = pick(['HEROICO_CLASSICO', 'LONGO_ESVOACANTE', 'SAMURAI_COQUE', 'TRANCAS_GUERRA', 'MOICANO_SELVAGEM', 'CACHEADO_VOLUMOSO', 'MONGE_TATUADO', 'FRANJA_SOMBRIA']);
    ap.corCabelo = pick(['#1E293B', '#78350F', '#DC2626', '#FACC15', '#F8FAFC', '#38BDF8', '#10B981', '#A855F7', '#F97316', '#EC4899']);
    ap.estiloTraje = pick(['AUTO_CLASSE', 'PLACAS_PESADAS', 'MEIA_ARMADURA', 'COURACA_PEITORAL', 'COTA_MALHA', 'BRUNEA_ESCAMAS', 'PELES_BARBARAS', 'COURO_BATIDO', 'COURO_FURTIVO', 'MANTO_ARCANO', 'VESTES_SAGRADAS', 'CASACO_CORSARIO', 'TRAJE_INVENTOR']);
    ap.materialEspecial = pick(['ACO_PADRAO', 'ACO_PADRAO', 'ACO_RUBI', 'ADAMANTE', 'MITRAL', 'MATERIA_VERMELHA', 'GELO_ETERNO', 'MADEIRA_TOLLON', 'OURO_AZGHER']);
    ap.corTraje = pick(['#7F1D1D|#991B1B', '#1E3A8A|#1D4ED8', '#334155|#0F172A', '#CBD5E1|#B45309', '#065F46|#047857', '#4C1D95|#6D28D9', '#78350F|#451A03', '#0F766E|#115E59', '#831843|#BE185D']);
    ap.capaCostas = pick(['CAPA_REAL', 'CAPA_RASGADA', 'MANTO_GOLA_ALTA', 'ALJAVA_ARCO', 'MOCHILA_AVENTUREIRO', 'ESTANDARTE_GUERRA', 'HALO_DIVINO', 'PROPULSOR_AETHER', 'SEM_CAPA']);
    ap.postura = pick(['HEROICA_CLASSICA', 'GUARDA_OFENSIVA', 'DUELISTA_AGIL', 'CONJURACAO_ARCANA', 'COLOSSO_IMPONENTE']);
    ap.expressao = pick(['DETERMINADO', 'OLHOS_INCANDESCENTES', 'CICATRIZ_VETERANA', 'PINTURA_TRIBAL', 'SORRISO_AUDACIOSO', 'TAPA_OLHO_CORSARIO', 'MARCA_TORMENTA']);
    ap.maoSecundaria = pick(['AUTO_FICHA', 'ESCUDO_PESADO', 'ESCUDO_TORRE', 'ESCUDO_LEVE', 'DUAS_ARMAS_ADAGA', 'DUAS_ARMAS_ESPADA', 'GRIMORIO_ARCANO', 'ORBE_CRISTAL', 'SIMBOLO_SAGRADO', 'ALAUDE_BARDO', 'ENGENHOCA_INVENTOR']);
    ap.efeitoArma = pick(['ACO_FORJADO', 'FOGO_SOLAR', 'RAIO_TROVAO', 'GELO_CRISTAL', 'VENENO_ACIDO', 'LUZ_PALADINO', 'TREVAS_PROFANA', 'RUBRO_TORMENTA', 'ESSENCIA_ASTRAL']);

    const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
    setVal('ap-sel-pele', ap.corPele);
    setVal('ap-sel-cabeca', ap.estiloCabeca);
    setVal('ap-sel-penteado', ap.penteado);
    setVal('ap-sel-cabelo', ap.corCabelo);
    setVal('ap-sel-traje', ap.estiloTraje);
    setVal('ap-sel-material-especial', ap.materialEspecial);
    setVal('ap-sel-cor-traje', ap.corTraje);
    setVal('ap-sel-capa-costas', ap.capaCostas);
    setVal('ap-sel-postura', ap.postura);
    setVal('ap-sel-expressao', ap.expressao);
    setVal('ap-sel-mao-secundaria', ap.maoSecundaria);
    setVal('ap-sel-efeito-arma', ap.efeitoArma);

    sincronizarTodosSeletoresAparenciaFichaEArenaJS();
    if (__ARENA_STATE__) renderizarPalcoJRPG(st, __ARENA_STATE__, null);
    atualizarRetratoFichaPrincipalJS();
}

function restaurarAparenciaPadraoRacialJS() {
    tocarSomJRPG('UI_CLICK');
    const st = garantirEstadoFichaParaArena();
    const nr = (st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : 'humano';
    sincronizarSeletoresAparenciaComRacaJS(nr, true);
    const ap = window.__APARENCIA_HEROI__;
    ap.estiloCabeca = 'RACIAL_CLASSICO';
    ap.penteado = 'HEROICO_CLASSICO';
    ap.corCabelo = '#1E293B';
    ap.estiloTraje = 'AUTO_CLASSE';
    ap.materialEspecial = 'ACO_PADRAO';
    ap.corTraje = '#7F1D1D|#991B1B';
    ap.capaCostas = 'CAPA_REAL';
    ap.postura = 'HEROICA_CLASSICA';
    ap.expressao = 'DETERMINADO';
    ap.maoSecundaria = 'AUTO_FICHA';
    ap.efeitoArma = 'ACO_FORJADO';
    ap.estiloArte = 'HQ_TORMENTA20';

    const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
    setVal('ap-sel-pele', ap.corPele);
    setVal('ap-sel-cabeca', ap.estiloCabeca);
    setVal('ap-sel-penteado', ap.penteado);
    setVal('ap-sel-cabelo', ap.corCabelo);
    setVal('ap-sel-traje', ap.estiloTraje);
    setVal('ap-sel-material-especial', ap.materialEspecial);
    setVal('ap-sel-cor-traje', ap.corTraje);
    setVal('ap-sel-capa-costas', ap.capaCostas);
    setVal('ap-sel-postura', ap.postura);
    setVal('ap-sel-expressao', ap.expressao);
    setVal('ap-sel-mao-secundaria', ap.maoSecundaria);
    setVal('ap-sel-efeito-arma', ap.efeitoArma);
    setVal('ap-sel-estilo-arte', ap.estiloArte);

    sincronizarTodosSeletoresAparenciaFichaEArenaJS();
    if (__ARENA_STATE__) renderizarPalcoJRPG(st, __ARENA_STATE__, null);
    atualizarRetratoFichaPrincipalJS();
}


// =============================================================================
// =============================================================================
// RETRATO 2D CLÁSSICO DA FICHA E OVERLAYS VISUAIS 2D DE CONDIÇÕES (v46)
// =============================================================================

// =============================================================================

// =============================================================================
// SISTEMA OFICIAL DE MONTARIAS E PARCEIROS (T20 JdA Cap. 6, p. 260-263) + ARTE DARK FANTASY (v52)
// =============================================================================
// =============================================================================
// MOTOR DE MALHA CONTÍNUA CATMULL-ROM & PINTURA VOLUMÉTRICA HD (ZERO POLÍGONOS) - v57
// =============================================================================
window.__T20_SVG_UID_COUNTER__ = 1;
function gerarUidUnicoSVGT20(prefixo) {
    window.__T20_SVG_UID_COUNTER__ = (window.__T20_SVG_UID_COUNTER__ || 1) + 1;
    return (prefixo || 'vtt') + '_' + window.__T20_SVG_UID_COUNTER__ + '_' + Math.random().toString(36).slice(2, 6);
}

function ajustarTomHexT20(hexStr, delta) {
    if (!hexStr || typeof hexStr !== 'string' || !hexStr.startsWith('#')) return '#64748B';
    let h = hexStr.replace('#', '').trim();
    if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
    const num = parseInt(h, 16);
    if (isNaN(num)) return hexStr;
    const r = Math.max(0, Math.min(255, ((num >> 16) & 255) + delta));
    const g = Math.max(0, Math.min(255, ((num >> 8) & 255) + delta));
    const b = Math.max(0, Math.min(255, (num & 255) + delta));
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
}

// Interpolador Matemático Catmull-Rom C² para Malhas Orgânicas de Alta Densidade (Zero Quinas Poligonais)
function catmullRomSplineSVG(pts, fechada, tensao) {
    if (!pts || pts.length < 2) return '';
    const t = tensao !== undefined ? tensao : 0.22;
    const n = pts.length;
    let d = `M ${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
    const limite = fechada ? n : n - 1;
    for (let i = 0; i < limite; i++) {
        const p0 = pts[(i - 1 + n) % n];
        const p1 = pts[i];
        const p2 = pts[(i + 1) % n];
        const p3 = pts[(i + 2) % n];
        const cp1x = p1[0] + (p2[0] - p0[0]) * t;
        const cp1y = p1[1] + (p2[1] - p0[1]) * t;
        const cp2x = p2[0] - (p3[0] - p1[0]) * t;
        const cp2y = p2[1] - (p3[1] - p1[1]) * t;
        d += ` C ${cp1x.toFixed(1)} ${cp1y.toFixed(1)}, ${cp2x.toFixed(1)} ${cp2y.toFixed(1)}, ${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
    }
    if (fechada) d += ' Z';
    return d;
}

// Soldador de Malha Volumétrica em 3 Passos:
// Funde múltiplos segmentos anatômicos em UMA ÚNICA silhueta contínua sem linhas pretas cortando as juntas!
function soldarMalhaVolumetricaContinuaSVG(listaCaminhosCorpo, svgDetalhesInternos, corContorno, largContorno) {
    const strokeC = corContorno || '#08050C';
    const sw = largContorno || 3.4;
    // Passo 1: Silhueta Externa Soldada (une cabeça, pescoço, tronco e membros num só contorno contínuo)
    const camadaSilhueta = listaCaminhosCorpo.map(item =>
        `<path d="${item.d}" fill="${strokeC}" stroke="${strokeC}" stroke-width="${sw}" stroke-linejoin="round" stroke-linecap="round"/>`
    ).join('');
    // Passo 2: Preenchimento Volumétrico Interno Contínuo (sem borda preta nas juntas internas!)
    const camadaVolume = listaCaminhosCorpo.map(item =>
        `<path d="${item.d}" fill="${item.fill}" ${item.sombraInterna ? `stroke="${item.sombraInterna}" stroke-width="0.9"` : 'stroke="none"'} stroke-linejoin="round"/>`
    ).join('');
    // Passo 3: Iluminação Especular Volumétrica e Detalhes Anatômicos de Alta Resolução
    const camadaLuz = listaCaminhosCorpo.map(item =>
        item.luzD ? `<path d="${item.luzD}" fill="${item.luzFill || 'rgba(255,255,255,0.16)'}" stroke="none"/>` : ''
    ).join('');
    return `<g class="t20-welded-organic-mesh">${camadaSilhueta}${camadaVolume}${camadaLuz}${svgDetalhesInternos || ''}</g>`;
}

function construirDefsGradientesDarkFantasyUID(uid, corPele, corArmadura, corCapa, corDetalhe, corCabelo) {
    const pBase = corPele || '#D4A373';
    const pEsp = ajustarTomHexT20(pBase, 48);
    const pLuz = ajustarTomHexT20(pBase, 24);
    const pSombra = ajustarTomHexT20(pBase, -34);
    const pProf = ajustarTomHexT20(pBase, -66);

    const aBase = corArmadura || '#475569';
    const aEsp = ajustarTomHexT20(aBase, 64);
    const aLuz = ajustarTomHexT20(aBase, 28);
    const aSombra = ajustarTomHexT20(aBase, -34);
    const aProf = ajustarTomHexT20(aBase, -68);

    const cBase = corCapa || '#7F1D1D';
    const cLuz = ajustarTomHexT20(cBase, 34);
    const cSombra = ajustarTomHexT20(cBase, -38);
    const cProf = ajustarTomHexT20(cBase, -70);

    const dBase = corDetalhe || '#D97706';
    const dEsp = ajustarTomHexT20(dBase, 58);
    const dSombra = ajustarTomHexT20(dBase, -44);

    const hBase = corCabelo || '#1E293B';
    const hLuz = ajustarTomHexT20(hBase, 42);
    const hSombra = ajustarTomHexT20(hBase, -38);

    return `
        <defs>
            <linearGradient id="${uid}_skin" x1="30%" y1="8%" x2="75%" y2="92%">
                <stop offset="0%" stop-color="${pEsp}"/>
                <stop offset="22%" stop-color="${pLuz}"/>
                <stop offset="55%" stop-color="${pBase}"/>
                <stop offset="84%" stop-color="${pSombra}"/>
                <stop offset="100%" stop-color="${pProf}"/>
            </linearGradient>
            <radialGradient id="${uid}_skinRad" cx="38%" cy="30%" r="65%">
                <stop offset="0%" stop-color="${pEsp}"/>
                <stop offset="35%" stop-color="${pLuz}"/>
                <stop offset="70%" stop-color="${pBase}"/>
                <stop offset="100%" stop-color="${pSombra}"/>
            </radialGradient>
            <linearGradient id="${uid}_armor" x1="25%" y1="6%" x2="80%" y2="94%">
                <stop offset="0%" stop-color="${aEsp}"/>
                <stop offset="22%" stop-color="${aLuz}"/>
                <stop offset="50%" stop-color="${aBase}"/>
                <stop offset="80%" stop-color="${aSombra}"/>
                <stop offset="100%" stop-color="${aProf}"/>
            </linearGradient>
            <radialGradient id="${uid}_armorRad" cx="38%" cy="28%" r="68%">
                <stop offset="0%" stop-color="${aEsp}"/>
                <stop offset="40%" stop-color="${aBase}"/>
                <stop offset="82%" stop-color="${aSombra}"/>
                <stop offset="100%" stop-color="${aProf}"/>
            </radialGradient>
            <linearGradient id="${uid}_cloak" x1="25%" y1="8%" x2="80%" y2="96%">
                <stop offset="0%" stop-color="${cLuz}"/>
                <stop offset="42%" stop-color="${cBase}"/>
                <stop offset="78%" stop-color="${cSombra}"/>
                <stop offset="100%" stop-color="${cProf}"/>
            </linearGradient>
            <linearGradient id="${uid}_gold" x1="20%" y1="0%" x2="85%" y2="100%">
                <stop offset="0%" stop-color="#FEF9C3"/>
                <stop offset="25%" stop-color="${dEsp}"/>
                <stop offset="55%" stop-color="${dBase}"/>
                <stop offset="100%" stop-color="${dSombra}"/>
            </linearGradient>
            <linearGradient id="${uid}_hair" x1="25%" y1="5%" x2="80%" y2="95%">
                <stop offset="0%" stop-color="${hLuz}"/>
                <stop offset="48%" stop-color="${hBase}"/>
                <stop offset="100%" stop-color="${hSombra}"/>
            </linearGradient>
            <linearGradient id="${uid}_leather" x1="25%" y1="10%" x2="80%" y2="92%">
                <stop offset="0%" stop-color="#8A5A36"/>
                <stop offset="42%" stop-color="#52321B"/>
                <stop offset="78%" stop-color="#2B190C"/>
                <stop offset="100%" stop-color="#120A04"/>
            </linearGradient>
            <linearGradient id="${uid}_steel" x1="20%" y1="0%" x2="85%" y2="100%">
                <stop offset="0%" stop-color="#FFFFFF"/>
                <stop offset="28%" stop-color="#E2E8F0"/>
                <stop offset="58%" stop-color="#64748B"/>
                <stop offset="85%" stop-color="#1E293B"/>
                <stop offset="100%" stop-color="#090D16"/>
            </linearGradient>
            <pattern id="${uid}_chain" width="5" height="5" patternUnits="userSpaceOnUse">
                <rect width="5" height="5" fill="#1E293B"/>
                <circle cx="2.5" cy="2.5" r="2" fill="none" stroke="#94A3B8" stroke-width="0.8"/>
                <circle cx="0" cy="0" r="1.5" fill="none" stroke="#CBD5E1" stroke-width="0.6"/>
            </pattern>
            <pattern id="${uid}_scales" width="6" height="5" patternUnits="userSpaceOnUse">
                <rect width="6" height="5" fill="${pBase}"/>
                <path d="M 0 2.5 Q 3 5.5 6 2.5 M -3 0 Q 0 3 3 0 M 3 0 Q 6 3 9 0" fill="none" stroke="${pProf}" stroke-width="0.75"/>
                <path d="M 1 2 Q 3 4.2 5 2" fill="none" stroke="${pEsp}" stroke-width="0.5" opacity="0.65"/>
            </pattern>
            <linearGradient id="${uid}_basePlinth" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#090D16"/>
                <stop offset="22%" stop-color="#334155"/>
                <stop offset="48%" stop-color="#475569"/>
                <stop offset="78%" stop-color="#1E293B"/>
                <stop offset="100%" stop-color="#05070C"/>
            </linearGradient>
        </defs>
    `;
}

// =============================================================================
// MOTOR PIXEL ART 16-BIT / 32-BIT DARK FANTASY (TORMENTA 20 JOGO DO ANO - v58)
// Renderização matricial inteira RLE com shape-rendering="crispEdges" e contorno
// escuro automático de 1px (#07040B) — ZERO polígonos deformados!
// =============================================================================
function construirBaseMiniaturaRPGDeMesaSVG(cx, cy, rx, ry, corAnel, uid, ehInimigo, rotuloBase) {
    const cAnel = corAnel || (ehInimigo ? '#DC2626' : '#D97706');
    const cAnelEsc = ajustarTomHexT20(cAnel, -48);
    const cAnelLuz = ajustarTomHexT20(cAnel, 48);
    const ps = 4;
    const wBase = Math.round((rx * 2) / ps) * ps;
    const x0 = Math.round(cx - wBase / 2);
    const y0 = Math.round(cy - 6);
    const txtPlaca = rotuloBase ? `
        <rect x="${Math.round(cx - Math.min(rx * 0.86, 52))}" y="${y0 + 10}" width="${Math.round(Math.min(rx * 0.86, 52) * 2)}" height="12" fill="#0B0711" stroke="${cAnel}" stroke-width="1.5"/>
        <text x="${cx}" y="${y0 + 19}" text-anchor="middle" font-family="monospace" font-size="7.8" font-weight="900" fill="#FEF08A" letter-spacing="0.4">${rotuloBase}</text>
    ` : '';
    return `
        <g class="t20-pixel-pedestal" shape-rendering="crispEdges">
            <!-- Sombra Pixelada no Chão -->
            <rect x="${x0 - 4}" y="${y0 + 8}" width="${wBase + 8}" height="8" fill="rgba(0,0,0,0.65)"/>
            <rect x="${x0 - 8}" y="${y0 + 10}" width="${wBase + 16}" height="4" fill="rgba(0,0,0,0.42)"/>
            <!-- Corpo do Pedestal em Degraus Pixel Art -->
            <rect x="${x0}" y="${y0 + 2}" width="${wBase}" height="8" fill="#09060E"/>
            <rect x="${x0 + 4}" y="${y0 + 3}" width="${wBase - 8}" height="6" fill="${cAnelEsc}"/>
            <rect x="${x0 + 12}" y="${y0 + 3}" width="${Math.max(8, Math.round(wBase * 0.35))}" height="5" fill="${cAnel}"/>
            <!-- Topo de Pedra de Masmorra Pixelada -->
            <rect x="${x0 + 4}" y="${y0 - 4}" width="${wBase - 8}" height="7" fill="#09060E"/>
            <rect x="${x0 + 8}" y="${y0 - 3}" width="${wBase - 16}" height="5" fill="#1E1B2E"/>
            <rect x="${x0 + 12}" y="${y0 - 2}" width="${wBase - 24}" height="3" fill="#334155"/>
            <!-- Aro Metálico Pixelado -->
            <rect x="${x0 + 4}" y="${y0 + 1}" width="${wBase - 8}" height="2" fill="${cAnel}"/>
            <rect x="${x0 + 16}" y="${y0 + 1}" width="${Math.max(8, Math.round(wBase * 0.28))}" height="2" fill="${cAnelLuz}"/>
            ${txtPlaca}
        </g>
    `;
}

function expandirProporcaoVerticalPixelArtEPX(linhasOrig) {
    // Expande verticalmente matrizes largas (ex: 32x12 -> 32x24) com suavização diagonal EPX/Scale2x
    // para que nenhuma criatura ou token fique "achatado" verticalmente!
    const H0 = linhasOrig.length;
    const W0 = Math.max(...linhasOrig.map(r => r.length));
    if (H0 >= 28) return linhasOrig;
    const g0 = [];
    for (let y = 0; y < H0; y++) {
        const row = [];
        const s = linhasOrig[y] || '';
        for (let x = 0; x < W0; x++) {
            const c = x < s.length ? s[x] : '.';
            row.push(c === ' ' ? '.' : c);
        }
        g0.push(row);
    }
    const out = [];
    for (let y = 0; y < H0; y++) {
        const rTop = [];
        const rBot = [];
        for (let x = 0; x < W0; x++) {
            const P = g0[y][x];
            const A = y > 0 ? g0[y - 1][x] : '.';
            const B = x + 1 < W0 ? g0[y][x + 1] : '.';
            const C = x > 0 ? g0[y][x - 1] : '.';
            const D = y + 1 < H0 ? g0[y + 1][x] : '.';
            let p1 = P, p2 = P;
            if (P === '.') {
                if (A !== '.' && A === C && A !== D) p1 = A;
                else if (A !== '.' && A === B && A !== D) p1 = A;
                if (D !== '.' && D === C && D !== A) p2 = D;
                else if (D !== '.' && D === B && D !== A) p2 = D;
            }
            rTop.push(p1);
            rBot.push(p2);
        }
        out.push(rTop.join(''));
        out.push(rBot.join(''));
    }
    return out;
}

function recortarBordasVaziasMatrizPixelArt(linhasOrig) {
    const H0 = linhasOrig.length;
    const W0 = Math.max(...linhasOrig.map(r => r.length));
    let minY = H0, maxY = -1, minX = W0, maxX = -1;
    for (let y = 0; y < H0; y++) {
        const s = linhasOrig[y] || '';
        for (let x = 0; x < W0; x++) {
            const ch = x < s.length ? s[x] : '.';
            if (ch !== '.' && ch !== ' ') {
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
            }
        }
    }
    if (maxY < minY || maxX < minX) return linhasOrig;
    const recortada = [];
    const wCrop = (maxX - minX + 1) + 2;
    recortada.push('.'.repeat(wCrop));
    for (let y = minY; y <= maxY; y++) {
        const s = linhasOrig[y] || '';
        let sub = '';
        for (let x = minX; x <= maxX; x++) {
            const c = x < s.length ? s[x] : '.';
            sub += (c === ' ' ? '.' : c);
        }
        recortada.push('.' + sub + '.');
    }
    recortada.push('.'.repeat(wCrop));
    return recortada;
}

function renderizarMatrizPixelArtSVG(linhasBrutas, paleta, cx, bottomY, tamPixel, autoOutline, semExpansaoVertical) {
    const multPorte = Number(window.__ESCALA_PORTE_PIXEL_ART__ || 1.0);
    const altPorte = Number(window.__PROPORCAO_VERTICAL_PIXEL_ART__ || 1.12);
    let linhas = recortarBordasVaziasMatrizPixelArt(linhasBrutas);
    if (!semExpansaoVertical) {
        // Apenas matrizes com poucas linhas (<= 15 linhas, ex: humanoides/goblins de 11 linhas)
        // recebem 1 passagem EPX para ganhar resolução vertical. Matrizes já altas (Dragão 24, Mantícora 19)
        // mantêm sua proporção original para NUNCA ficarem esticadas ou achatadas horizontalmente!
        if (linhas.length <= 16) {
            linhas = expandirProporcaoVerticalPixelArtEPX(linhas);
        }
    }
    const usarContorno = (autoOutline !== false);
    const H = linhas.length;
    const W = Math.max(...linhas.map(r => r.length));

    // PROPORÇÃO ANATÔMICA DO TORSO E CORPO (v63):
    // Preserva 100% da largura horizontal (maxW = 166) e amplia o teto vertical (maxH = 178) com leve
    // alongamento vertical de pixel (psY = ps * 1.14) para que o torso NUNCA fique achatado nos Tokens!
    let ps = (tamPixel || 4.0) * multPorte;
    if (!semExpansaoVertical && cx >= 500) {
        const escalaCriatura = (tamPixel || 3.6) / 3.6;
        const maxW = 166 * escalaCriatura * multPorte;
        const maxH = 178 * escalaCriatura * multPorte;
        ps = Math.min(maxW / Math.max(1, W), maxH / Math.max(1, H));
    }
    const psX = semExpansaoVertical ? (ps * 0.94) : ps;
    const psY = semExpansaoVertical ? (ps * 1.08) : (ps * 1.14);

    const grid = [];
    for (let y = 0; y < H; y++) {
        const row = [];
        const str = linhas[y] || '';
        for (let x = 0; x < W; x++) {
            const ch = x < str.length ? str[x] : '.';
            row.push(ch === ' ' ? '.' : ch);
        }
        grid.push(row);
    }

    // Passagem de Contorno Pixel Art 16-Bit Automático (1px #07040B ao redor de qualquer pixel preenchido)
    if (usarContorno) {
        const copia = grid.map(r => r.slice());
        const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
        for (let y = 0; y < H; y++) {
            for (let x = 0; x < W; x++) {
                if (copia[y][x] !== '.') continue;
                for (let d = 0; d < 4; d++) {
                    const ny = y + dirs[d][0];
                    const nx = x + dirs[d][1];
                    if (ny >= 0 && ny < H && nx >= 0 && nx < W) {
                        const viz = copia[ny][nx];
                        if (viz !== '.' && viz !== '#') {
                            grid[y][x] = '#';
                            break;
                        }
                    }
                }
            }
        }
    }

    // Passagem de Sombreamento por Clusters de Pixels (Luz Superior-Esquerda / Sombra Inferior-Direita)
    const copiaShade = grid.map(r => r.slice());
    for (let y = 1; y < H - 1; y++) {
        for (let x = 1; x < W - 1; x++) {
            const ch = copiaShade[y][x];
            if (ch === '1') {
                if (copiaShade[y - 1][x] === '#' && copiaShade[y][x - 1] === '#') {
                    grid[y][x] = '3';
                } else if (copiaShade[y + 1][x] === '#' && copiaShade[y][x + 1] === '#') {
                    grid[y][x] = '2';
                }
            } else if (ch === '4') {
                if (copiaShade[y - 1][x] === '#' && copiaShade[y][x - 1] === '#') {
                    grid[y][x] = '6';
                } else if (copiaShade[y + 1][x] === '#' && copiaShade[y][x + 1] === '#') {
                    grid[y][x] = '5';
                }
            }
        }
    }

    const ox = cx - (W * psX) / 2;
    const oy = bottomY - (H * psY);
    const rects = [];
    for (let y = 0; y < H; y++) {
        let x = 0;
        while (x < W) {
            const ch = grid[y][x];
            if (ch === '.') {
                x++;
                continue;
            }
            let xEnd = x;
            while (xEnd + 1 < W && grid[y][xEnd + 1] === ch) {
                xEnd++;
            }
            const cor = paleta[ch] || (ch === '#' ? '#07040B' : '#F8FAFC');
            const rx = (ox + x * psX).toFixed(2);
            const ry = (oy + y * psY).toFixed(2);
            const rw = ((xEnd - x + 1) * psX + 0.18).toFixed(2);
            const rh = (psY + 0.18).toFixed(2);
            rects.push(`<rect x="${rx}" y="${ry}" width="${rw}" height="${rh}" fill="${cor}"/>`);
            x = xEnd + 1;
        }
    }
    return `<g class="t20-pixel-art-sprite" shape-rendering="crispEdges">${rects.join('')}</g>`;
}

function criarPaletaPixelArtPadraoT20(c1, c2, cDet, cOlho, cPele, cCabelo) {
    const cor1 = c1 || '#991B1B';
    const cor2 = c2 || '#334155';
    const det = cDet || '#F59E0B';
    const pele = cPele || '#FDBA74';
    const cab = cCabelo || '#1E293B';
    return {
        '#': '#07040B',
        '1': cor1,
        '2': ajustarTomHexT20(cor1, -38),
        '3': ajustarTomHexT20(cor1, 36),
        '4': cor2,
        '5': ajustarTomHexT20(cor2, -38),
        '6': ajustarTomHexT20(cor2, 36),
        'D': det,
        'd': ajustarTomHexT20(det, -42),
        'E': cOlho || '#FEF08A',
        'W': '#FFFFFF',
        'S': '#E2E8F0',
        's': '#64748B',
        'K': pele,
        'k': ajustarTomHexT20(pele, -32),
        'H': cab,
        'h': ajustarTomHexT20(cab, -34),
        'R': '#991B1B',
        'r': '#450A0A',
        'F': '#F97316',
        'Y': '#FEF08A',
        'G': '#22C55E',
        'g': '#15803D',
        'C': '#38BDF8',
        'P': '#A855F7',
        'L': '#854D0E',
        'l': '#451A03',
        'B': '#1E293B'
    };
}


function gerarDefsPinturaDarkFantasyT20() { return ''; }
function suavizarPoligonosECantosSVG(svgStr) { return svgStr || ''; }

// =============================================================================
// SISTEMA OFICIAL DE MONTARIAS E PARCEIROS (T20 JdA Cap. 6, p. 260-263) - v57
// =============================================================================
window.__MONTARIA_E_PARCEIRO_ATUAL__ = {
    montaria: 'NENHUMA',
    patamarMontaria: 'INICIANTE',
    parceiro: 'NENHUM',
    patamarParceiro: 'INICIANTE'
};

window.__ANIMACAO_PALCO_ATIVA__ = null;

function obterBonusMontariaEParceiroAtivosJS(st) {
    const cfg = (st && st.montariaParceiro) ? st.montariaParceiro : (window.__MONTARIA_E_PARCEIRO_ATUAL__ || {});
    const mont = cfg.montaria || 'NENHUMA';
    const patM = cfg.patamarMontaria || 'INICIANTE';
    const parc = cfg.parceiro || 'NENHUM';
    const patP = cfg.patamarParceiro || 'INICIANTE';

    const res = {
        montaria: mont,
        patamarMontaria: patM,
        parceiro: parc,
        patamarParceiro: patP,
        montado: mont !== 'NENHUMA',
        tamanhoMontadoCat: 'Médio',
        espacoMontadoQ: 1,
        deslocamentoMontadoM: (st && st.est && st.est.deslocamento) ? Number(st.est.deslocamento) : 9,
        acaoMovimentoExtraMontaria: 0,
        bonusAtaqueCaC: 0,
        bonusAtaqueDist: 0,
        bonusAtaqueInvestida: 0,
        bonusDanoFixoCaC: 0,
        bonusDanoDadosCaCMedia: 0,
        bonusDanoDadosCaCStr: '',
        bonusDanoDadosDistMedia: 0,
        bonusDanoDadosDistStr: '',
        bonusDanoMagiaMedia: 0,
        bonusDanoMagiaStr: '',
        bonusDefesa: 0,
        bonusResistencias: 0,
        reducaoDanoRD: 0,
        reducaoPMMagia: 0,
        bonusCDMagia: 0,
        bonusIniciativa: 0,
        flanqueiaAutomatico: false,
        curaMedicoStr: '',
        curaMedicoMedia: 0,
        resumoMontaria: 'Sem montaria ativa (A pé · Espaço 1x1).',
        resumoParceiro: 'Sem parceiro ativo.'
    };

    if (mont !== 'NENHUMA') {
        res.acaoMovimentoExtraMontaria = 1;
        res.tamanhoMontadoCat = (mont === 'DRAGAO_WYVERN') ? 'Enorme' : 'Grande';
        res.espacoMontadoQ = (mont === 'DRAGAO_WYVERN') ? 3 : 2;

        if (mont === 'CAVALO_GUERRA') {
            res.deslocamentoMontadoM = 15;
            if (patM === 'VETERANO') { res.bonusAtaqueInvestida += 2; res.bonusDanoFixoCaC += 2; }
            else if (patM === 'MESTRE') { res.bonusAtaqueInvestida += 5; res.bonusDanoDadosCaCMedia += 9; res.bonusDanoDadosCaCStr += '+2d8 (Cavalo Mestre)'; }
            res.resumoMontaria = `🐎 Cavalo de Guerra (${patM} · Grande 2x2 · Desl. 15m + 1 Ação Mov/turno)`;
        } else if (mont === 'GRIFO') {
            res.deslocamentoMontadoM = 18;
            res.bonusAtaqueInvestida += 2;
            res.bonusDanoDadosCaCMedia += (patM === 'MESTRE' ? 9 : 4.5);
            res.bonusDanoDadosCaCStr += (patM === 'MESTRE' ? '+2d8 (Grifo Mestre)' : '+1d8 (Grifo)');
            res.resumoMontaria = `🦅 Grifo Real (${patM} · Grande 2x2 · Voo 18m + 1 Ação Mov/turno)`;
        } else if (mont === 'LOBO_CAVERNAS') {
            res.deslocamentoMontadoM = 12;
            res.bonusAtaqueInvestida += 2;
            res.bonusDanoDadosCaCMedia += (patM === 'MESTRE' ? 7 : 3.5);
            res.bonusDanoDadosCaCStr += (patM === 'MESTRE' ? '+2d6+Derrubar (Lobo)' : '+1d6 (Lobo)');
            res.resumoMontaria = `🐺 Lobo-das-Cavernas (${patM} · Grande 2x2 · Desl. 12m + 1 Ação Mov/turno)`;
        } else if (mont === 'GORLOGG') {
            res.deslocamentoMontadoM = 12;
            res.bonusDanoDadosCaCMedia += (patM === 'MESTRE' ? 10.5 : (patM === 'VETERANO' ? 7 : 3.5));
            res.bonusDanoDadosCaCStr += (patM === 'MESTRE' ? '+3d6 (Gorlogg Mestre)' : (patM === 'VETERANO' ? '+2d6 (Gorlogg)' : '+1d6 (Gorlogg)'));
            res.resumoMontaria = `🦖 Gorlogg Selvagem (${patM} · Grande 2x2 · Desl. 12m + 1 Ação Mov/turno)`;
        } else if (mont === 'LEAO_SAGRADO') {
            res.deslocamentoMontadoM = 12;
            res.bonusAtaqueCaC += (patM === 'MESTRE' ? 2 : 1);
            res.bonusDefesa += (patM === 'MESTRE' ? 2 : 1);
            res.bonusResistencias += (patM === 'VETERANO' || patM === 'MESTRE') ? 2 : 0;
            res.resumoMontaria = `🦁 Leão Sagrado de Allihanna (${patM} · Grande 2x2 · Desl. 12m + 1 Ação Mov/turno)`;
        } else if (mont === 'DRAGAO_WYVERN') {
            res.deslocamentoMontadoM = 18;
            res.bonusDanoDadosCaCMedia += (patM === 'MESTRE' ? 13 : 6.5);
            res.bonusDanoDadosCaCStr += (patM === 'MESTRE' ? '+2d12 Fogo (Dragão)' : '+1d12 Fogo (Wyvern)');
            res.bonusDefesa += (patM === 'MESTRE' ? 3 : 2);
            res.resumoMontaria = `🐉 Wyvern / Dragão Menor (${patM} · Enorme 3x3 · Voo 18m + 1 Ação Mov/turno)`;
        }
    }

    if (parc !== 'NENHUM') {
        if (parc === 'COMBATENTE') {
            res.bonusAtaqueCaC += (patP === 'MESTRE' ? 4 : (patP === 'VETERANO' ? 2 : 1));
            res.resumoParceiro = `⚔️ Combatente (${patP}): +${res.bonusAtaqueCaC} em testes de ataque CaC.`;
        } else if (parc === 'FORTAO') {
            res.bonusDanoDadosCaCMedia += (patP === 'MESTRE' ? 10.5 : (patP === 'VETERANO' ? 6.5 : 3.5));
            res.bonusDanoDadosCaCStr += (patP === 'MESTRE' ? '+3d6 (Fortão)' : (patP === 'VETERANO' ? '+1d12 (Fortão)' : '+1d6 (Fortão)'));
            res.resumoParceiro = `🪓 Fortão (${patP}): ${res.bonusDanoDadosCaCStr} no dano CaC.`;
        } else if (parc === 'GUARDIAO') {
            res.bonusDefesa += (patP === 'MESTRE' ? 4 : (patP === 'VETERANO' ? 3 : 2));
            if (patP === 'MESTRE') res.bonusResistencias += 2;
            res.resumoParceiro = `🛡️ Guardião (${patP}): +${res.bonusDefesa} na Defesa${patP === 'MESTRE' ? ' e +2 em Resistências' : ''}.`;
        } else if (parc === 'ASSASSINO') {
            res.flanqueiaAutomatico = (patP === 'VETERANO' || patP === 'MESTRE');
            res.bonusDanoDadosCaCMedia += (patP === 'MESTRE' ? 10.5 : (patP === 'VETERANO' ? 7 : 3.5));
            res.bonusDanoDadosCaCStr += (patP === 'MESTRE' ? '+3d6 Furtivo (Assassino)' : (patP === 'VETERANO' ? '+2d6 Furtivo' : '+1d6 Furtivo'));
            res.resumoParceiro = `🗡️ Assassino (${patP}): ${res.bonusDanoDadosCaCStr}${res.flanqueiaAutomatico ? ' + Flanqueio Automático (+2 Atq)' : ''}.`;
        } else if (parc === 'ATIRADOR') {
            res.bonusAtaqueDist += (patP === 'MESTRE' ? 2 : 1);
            res.bonusDanoDadosDistMedia += (patP === 'MESTRE' ? 10.5 : (patP === 'VETERANO' ? 5.5 : 3.5));
            res.bonusDanoDadosDistStr += (patP === 'MESTRE' ? '+3d6 (Atirador)' : (patP === 'VETERANO' ? '+1d10 (Atirador)' : '+1d6 (Atirador)'));
            res.resumoParceiro = `🏹 Atirador (${patP}): +${res.bonusAtaqueDist} Atq Dist e ${res.bonusDanoDadosDistStr}.`;
        } else if (parc === 'ADEPTO') {
            res.reducaoPMMagia += (patP === 'MESTRE' ? 2 : 1);
            if (patP === 'VETERANO' || patP === 'MESTRE') res.bonusCDMagia += 1;
            res.resumoParceiro = `🔮 Adepto (${patP}): -${res.reducaoPMMagia} PM no custo de magias${res.bonusCDMagia ? ' e +1 na CD' : ''}.`;
        } else if (parc === 'DESTRUIDOR') {
            res.bonusDanoMagiaMedia += (patP === 'MESTRE' ? 14 : (patP === 'VETERANO' ? 9 : 4.5));
            res.bonusDanoMagiaStr += (patP === 'MESTRE' ? '+4d6 Magia (Destruidor)' : (patP === 'VETERANO' ? '+2d8 Magia' : '+1d8 Magia'));
            res.resumoParceiro = `🔥 Destruidor (${patP}): ${res.bonusDanoMagiaStr} em magias ofensivas.`;
        } else if (parc === 'MAGIVOCADOR') {
            res.bonusCDMagia += (patP === 'MESTRE' ? 2 : 1);
            res.bonusDanoMagiaMedia += (patP === 'MESTRE' ? 7 : (patP === 'VETERANO' ? 3.5 : 0));
            res.resumoParceiro = `✨ Magivocador (${patP}): +${res.bonusCDMagia} na CD das magias${res.bonusDanoMagiaMedia ? ' e +dados de dano arcano' : ''}.`;
        } else if (parc === 'MEDICO') {
            res.curaMedicoMedia = (patP === 'MESTRE' ? 22 : (patP === 'VETERANO' ? 13 : 6.5));
            res.curaMedicoStr = (patP === 'MESTRE' ? '4d8+4 PV' : (patP === 'VETERANO' ? '2d8+4 PV' : '1d8+2 PV'));
            res.resumoParceiro = `💚 Médico (${patP}): Cura ${res.curaMedicoStr} por rodada.`;
        } else if (parc === 'VIGILANTE') {
            res.bonusIniciativa += (patP === 'MESTRE' ? 4 : 2);
            res.bonusDefesa += (patP === 'VETERANO' || patP === 'MESTRE') ? 2 : 1;
            res.resumoParceiro = `👁️ Vigilante (${patP}): +${res.bonusIniciativa} Iniciativa/Percepção, +${res.bonusDefesa} Defesa e evita Desprevenido.`;
        }
    }
    return res;
}

function construirSVGMontariaDarkFantasyT20(idMontaria, patamar, uid) {
    if (!idMontaria || idMontaria === 'NENHUMA') return '';
    const m = String(idMontaria).toUpperCase();
    const ehMestre = patamar === 'MESTRE';
    let c1 = '#78350F', c2 = '#451A03', cDet = '#F59E0B', cOlho = '#FACC15';
    let mat = [
        "..................####..........",
        ".................#DDDD#.........",
        "................#113311#........",
        "...............#11EWW11#........",
        "..............#11111122#........",
        "....####.....#22111DDDD#........",
        "...#4444#...#2111111112#........",
        "..#445544###11113331112#........",
        "..#55..#111111DDDDDD111#........",
        ".......#113311D4444D111#........",
        ".......#111111111111112#........",
        ".......#221122222221122#........",
        "........#222#.....#222#.........",
        "........#222#.....#222#.........",
        "........#DDD#.....#DDD#........."
    ];
    if (m.includes('GRIFO')) {
        c1 = '#92400E'; c2 = '#F8FAFC'; cDet = '#FACC15'; cOlho = '#F97316';
        mat = [
            ".........######.................",
            "........#446644#......####......",
            "........#4444444#....#4466#.....",
            ".........#4455444#..#44EWWDD#...",
            "..........#4455444##44444DDD#...",
            "...####....#44554444444422#.....",
            "..#DDDD#....#1111144444411#.....",
            "..#11111####11331111111111#.....",
            "....#111111111111111111122#.....",
            ".....#221122222222221122#.......",
            "......#222#........#DDD#........",
            "......#DDD#........#W.W#........"
        ];
    } else if (m.includes('DRAGAO') || m.includes('WYVERN')) {
        c1 = '#15803D'; c2 = '#166534'; cDet = '#84CC16'; cOlho = '#FEF08A';
        mat = [
            "........######..................",
            ".......#D4466D#........####.....",
            "......#44445544#......#DD111#...",
            "......#445544554#....#111EWW1#..",
            "..#G#..#445544554###11111RRFF#..",
            ".#GGG#..#11111111111111111WW#...",
            "..#22###113311DDDD11111122#.....",
            "...#2211111111DDDD1111122#......",
            ".....#22112222222221122#........",
            "......#222#.......#222#.........",
            "......#W.W#.......#W.W#........."
        ];
    } else if (m.includes('LOBO')) {
        c1 = '#334155'; c2 = '#0F172A'; cDet = '#94A3B8'; cOlho = '#38BDF8';
    } else if (m.includes('GORLOGG')) {
        c1 = '#15803D'; c2 = '#052E16'; cDet = '#EAB308'; cOlho = '#EF4444';
    } else if (m.includes('LEAO')) {
        c1 = '#D97706'; c2 = '#78350F'; cDet = '#FEF08A'; cOlho = '#FEF08A';
    }
    const pal = criarPaletaPixelArtPadraoT20(c1, c2, cDet, cOlho, '#FDBA74', c2);
    return `<g class="t20-mount-pixel" opacity="0.96">${renderizarMatrizPixelArtSVG(mat, pal, 216, 262, ehMestre ? 4.4 : 4.0, true)}</g>`;
}

function construirSVGParceiroDarkFantasyT20(idParceiro, patamar, uid) {
    if (!idParceiro || idParceiro === 'NENHUM') return '';
    const p = String(idParceiro).toUpperCase();
    let c1 = '#1E40AF', c2 = '#475569', cDet = '#FACC15';
    if (p === 'ASSASSINO') { c1 = '#18181B'; c2 = '#7F1D1D'; cDet = '#A855F7'; }
    else if (p === 'ATIRADOR') { c1 = '#166534'; c2 = '#78350F'; cDet = '#84CC16'; }
    else if (p === 'ADEPTO' || p === 'MAGIVOCADOR' || p === 'DESTRUIDOR') { c1 = '#581C87'; c2 = '#1E1B4B'; cDet = '#38BDF8'; }
    else if (p === 'MEDICO') { c1 = '#065F46'; c2 = '#F8FAFC'; cDet = '#34D399'; }
    else if (p === 'FORTAO') { c1 = '#9A3412'; c2 = '#451A03'; cDet = '#F97316'; }
    const mat = [
        ".....######.....",
        "....#HHHHHH#....",
        "...#HKKKKKKH#...",
        "...#KKEKKEKK#...",
        "....#KKKKKK#....",
        "..###11DD11###..",
        ".#44#11DD11#SS#.",
        ".#44#111111#SS#.",
        "..###22DD22###..",
        "....#44..44#....",
        "....#ll..ll#...."
    ];
    const pal = criarPaletaPixelArtPadraoT20(c1, c2, cDet, '#FEF08A', '#FDBA74', '#1E293B');
    return `<g class="t20-partner-pixel">${renderizarMatrizPixelArtSVG(mat, pal, 148, 254, 3.6, true)}</g>`;
}


function alternarModoVisibilidadePalco2DJS() {
    window.__PALCO_MODO_TOKENS_LIMPOS__ = !window.__PALCO_MODO_TOKENS_LIMPOS__;
    if (typeof atualizarPlacarVisualArena === 'function' && __ARENA_STATE__) atualizarPlacarVisualArena();
    if (typeof renderizarMesaOnlineCompletaUI === 'function' && ESTADO_MESA_ONLINE_ATUAL) renderizarMesaOnlineCompletaUI();
}

function extrairTamanhoEEspacoT20(textoTamanho) {
    const t = String(textoTamanho || 'Médio').toLowerCase();
    if (t.includes('colossal')) return { categoria: 'Colossal', espacoQ: 6, espacoM: 9.0, escalaSprite: 5.20, multOcupacao: 5.20 };
    if (t.includes('enorme')) return { categoria: 'Enorme', espacoQ: 3, espacoM: 4.5, escalaSprite: 3.00, multOcupacao: 3.00 };
    if (t.includes('grande')) return { categoria: 'Grande', espacoQ: 2, espacoM: 3.0, escalaSprite: 2.00, multOcupacao: 2.00 };
    if (t.includes('pequeno')) return { categoria: 'Pequeno', espacoQ: 1, espacoM: 1.5, escalaSprite: 0.76, multOcupacao: 0.76 };
    if (t.includes('minúsculo') || t.includes('minusculo')) return { categoria: 'Minúsculo', espacoQ: 1, espacoM: 1.5, escalaSprite: 0.56, multOcupacao: 0.56 };
    return { categoria: 'Médio', espacoQ: 1, espacoM: 1.5, escalaSprite: 1.00, multOcupacao: 1.00 };
}

// =============================================================================
// MOTOR DE CÂMERA DINÂMICA & VIEWPORT PARA MAPA DE BATALHA 120x120 (180m x 180m) - v63
// =============================================================================
window.__MAPA_MUNDO_DIM_T20__ = 120;
window.__MODO_MOVIMENTO_LIVRE_120__ = true;
window.__CAMERA_MAPA_120__ = {
    worldCols: 120,
    worldRows: 120,
    viewCols: 12,
    viewRows: 7,
    camX: 52,
    camY: 56,
    modoSeguir: 'AUTO'
};

function obterCameraAtivaMapa120JS() {
    if (!window.__CAMERA_MAPA_120__) {
        window.__CAMERA_MAPA_120__ = { worldCols: 120, worldRows: 120, viewCols: 12, viewRows: 7, camX: 52, camY: 56, modoSeguir: 'AUTO' };
    }
    const c = window.__CAMERA_MAPA_120__;
    c.worldCols = 120;
    c.worldRows = 120;
    c.viewCols = Math.max(6, Math.min(40, Number(c.viewCols || 12)));
    c.viewRows = Math.max(4, Math.min(24, Number(c.viewRows || 7)));
    c.camX = Math.max(0, Math.min(c.worldCols - c.viewCols, Math.round(Number(c.camX || 0))));
    c.camY = Math.max(0, Math.min(c.worldRows - c.viewRows, Math.round(Number(c.camY || 0))));
    return c;
}

function sincronizarCameraMapa120ComUnidadesJS(heroisLista, criaturasLista, forcarAuto) {
    const cam = obterCameraAtivaMapa120JS();
    if (forcarAuto) cam.modoSeguir = 'AUTO';
    if (cam.modoSeguir !== 'AUTO') return cam;

    const pts = [];
    (heroisLista || []).forEach(h => {
        if (h && h.gx !== undefined && h.gy !== undefined) pts.push({ x: Number(h.gx), y: Number(h.gy), q: Number(h.espacoQ || 1) });
    });
    (criaturasLista || []).forEach(cr => {
        if (cr && Number(cr.pvAtual !== undefined ? cr.pvAtual : 1) > 0 && cr.gx !== undefined && cr.gy !== undefined) {
            pts.push({ x: Number(cr.gx), y: Number(cr.gy), q: Number(cr.espacoQ || 1) });
        }
    });
    if (pts.length === 0) return cam;

    let minX = 999, maxX = -999, minY = 999, maxY = -999;
    pts.forEach(p => {
        minX = Math.min(minX, p.x);
        maxX = Math.max(maxX, p.x + Math.max(1, p.q) - 1);
        minY = Math.min(minY, p.y);
        maxY = Math.max(maxY, p.y + Math.max(1, p.q) - 1);
    });

    // Expande automaticamente o enquadramento quando criaturas Colossais (6×6) ou grupos excedem o viewport atual
    const spanX = (maxX - minX + 1) + 2;
    const spanY = (maxY - minY + 1) + 2;
    const reqCols = Math.min(26, Math.max(12, spanX));
    const reqRows = Math.min(14, Math.max(7, spanY));
    if (reqCols > cam.viewCols) cam.viewCols = reqCols;
    if (reqRows > cam.viewRows) cam.viewRows = reqRows;

    const midX = Math.floor((minX + maxX) / 2);
    const midY = Math.floor((minY + maxY) / 2);
    cam.camX = Math.max(0, Math.min(cam.worldCols - cam.viewCols, midX - Math.floor(cam.viewCols / 2)));
    cam.camY = Math.max(0, Math.min(cam.worldRows - cam.viewRows, midY - Math.floor(cam.viewRows / 2)));
    // Garante que nenhuma extremidade (minX..maxX, minY..maxY) fique cortada nas bordas
    if (minX < cam.camX) cam.camX = Math.max(0, minX);
    if (maxX >= cam.camX + cam.viewCols) cam.camX = Math.max(0, Math.min(cam.worldCols - cam.viewCols, maxX - cam.viewCols + 1));
    if (minY < cam.camY) cam.camY = Math.max(0, minY);
    if (maxY >= cam.camY + cam.viewRows) cam.camY = Math.max(0, Math.min(cam.worldRows - cam.viewRows, maxY - cam.viewRows + 1));
    return cam;
}

function moverCameraMapa120JS(dx, dy, modoAlvo) {
    const cam = obterCameraAtivaMapa120JS();
    cam.modoSeguir = 'MANUAL';
    cam.camX = Math.max(0, Math.min(cam.worldCols - cam.viewCols, cam.camX + Number(dx || 0)));
    cam.camY = Math.max(0, Math.min(cam.worldRows - cam.viewRows, cam.camY + Number(dy || 0)));
    if (typeof atualizarPlacarVisualArena === 'function' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) atualizarPlacarVisualArena();
    if (typeof renderizarMesaOnlineCompletaUI === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) renderizarMesaOnlineCompletaUI();
}

function alterarZoomCameraMapa120JS(presetZoom) {
    const cam = obterCameraAtivaMapa120JS();
    const centroX = cam.camX + Math.floor(cam.viewCols / 2);
    const centroY = cam.camY + Math.floor(cam.viewRows / 2);
    if (presetZoom === 'PROXIMO') { cam.viewCols = 10; cam.viewRows = 6; }
    else if (presetZoom === 'AMPLO') { cam.viewCols = 18; cam.viewRows = 10; }
    else if (presetZoom === 'CERCO') { cam.viewCols = 26; cam.viewRows = 14; }
    else { cam.viewCols = 12; cam.viewRows = 7; }
    cam.camX = Math.max(0, Math.min(cam.worldCols - cam.viewCols, centroX - Math.floor(cam.viewCols / 2)));
    cam.camY = Math.max(0, Math.min(cam.worldRows - cam.viewRows, centroY - Math.floor(cam.viewRows / 2)));
    if (typeof atualizarPlacarVisualArena === 'function' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) atualizarPlacarVisualArena();
    if (typeof renderizarMesaOnlineCompletaUI === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) renderizarMesaOnlineCompletaUI();
}

function centralizarCameraMapa120JS(alvoFoco) {
    const cam = obterCameraAtivaMapa120JS();
    if (alvoFoco === 'AUTO') {
        cam.modoSeguir = 'AUTO';
        if (typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
            sincronizarCameraMapa120ComUnidadesJS([__ARENA_STATE__.posHeroi], __ARENA_STATE__.listaCriaturas, true);
        }
    } else if (alvoFoco === 'HEROI' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__ && __ARENA_STATE__.posHeroi) {
        cam.modoSeguir = 'MANUAL';
        cam.camX = Math.max(0, Math.min(120 - cam.viewCols, __ARENA_STATE__.posHeroi.gx - Math.floor(cam.viewCols / 2)));
        cam.camY = Math.max(0, Math.min(120 - cam.viewRows, __ARENA_STATE__.posHeroi.gy - Math.floor(cam.viewRows / 2)));
    } else if (alvoFoco === 'AMEACA' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
        const cr = (__ARENA_STATE__.listaCriaturas || [])[__ARENA_STATE__.alvoFocoIdx || 0];
        if (cr) {
            cam.modoSeguir = 'MANUAL';
            cam.camX = Math.max(0, Math.min(120 - cam.viewCols, cr.gx - Math.floor(cam.viewCols / 2)));
            cam.camY = Math.max(0, Math.min(120 - cam.viewRows, cr.gy - Math.floor(cam.viewRows / 2)));
        }
    }
    if (typeof atualizarPlacarVisualArena === 'function' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) atualizarPlacarVisualArena();
    if (typeof renderizarMesaOnlineCompletaUI === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) renderizarMesaOnlineCompletaUI();
}

function clicarRadarMiniMapa120JS(evt, svgEl) {
    if (!evt || !svgEl) return;
    const rect = svgEl.getBoundingClientRect();
    const rx = Math.max(0, Math.min(1, (evt.clientX - rect.left) / Math.max(1, rect.width)));
    const ry = Math.max(0, Math.min(1, (evt.clientY - rect.top) / Math.max(1, rect.height)));
    const gx = Math.floor(rx * 120);
    const gy = Math.floor(ry * 120);
    const cam = obterCameraAtivaMapa120JS();
    cam.modoSeguir = 'MANUAL';
    cam.camX = Math.max(0, Math.min(120 - cam.viewCols, gx - Math.floor(cam.viewCols / 2)));
    cam.camY = Math.max(0, Math.min(120 - cam.viewRows, gy - Math.floor(cam.viewRows / 2)));
    if (typeof atualizarPlacarVisualArena === 'function' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) atualizarPlacarVisualArena();
    if (typeof renderizarMesaOnlineCompletaUI === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) renderizarMesaOnlineCompletaUI();
}

function construirMiniMapaRadar120x120SVG(heroisLista, criaturasLista) {
    const cam = obterCameraAtivaMapa120JS();
    let dots = '';
    (criaturasLista || []).forEach((cr, idx) => {
        if (!cr || Number(cr.pvAtual !== undefined ? cr.pvAtual : 1) <= 0) return;
        const q = Math.max(2, Number(cr.espacoQ || 1) * 2.2);
        dots += `<rect x="${Number(cr.gx || 0).toFixed(1)}" y="${Number(cr.gy || 0).toFixed(1)}" width="${q.toFixed(1)}" height="${q.toFixed(1)}" fill="#EF4444" stroke="#FEF08A" stroke-width="0.8"/>`;
    });
    (heroisLista || []).forEach((h, idx) => {
        if (!h) return;
        dots += `<circle cx="${(Number(h.gx || 0) + 0.5).toFixed(1)}" cy="${(Number(h.gy || 0) + 0.5).toFixed(1)}" r="2.6" fill="#4ADE80" stroke="#FFFFFF" stroke-width="0.8"/>`;
    });
    return `
        <svg viewBox="0 0 120 120" width="118" height="118" onclick="clicarRadarMiniMapa120JS(event, this)"
             style="background:#050811; border:1.5px solid #D4AF37; border-radius:8px; cursor:crosshair; display:block; flex-shrink:0;"
             title="Radar Tático 120x120 (180m x 180m) — Clique em qualquer setor para mover a Câmera!">
            <line x1="0" y1="30" x2="120" y2="30" stroke="rgba(148,163,184,0.18)" stroke-width="0.6"/>
            <line x1="0" y1="60" x2="120" y2="60" stroke="rgba(212,175,55,0.32)" stroke-width="0.8" stroke-dasharray="2 2"/>
            <line x1="0" y1="90" x2="120" y2="90" stroke="rgba(148,163,184,0.18)" stroke-width="0.6"/>
            <line x1="30" y1="0" x2="30" y2="120" stroke="rgba(148,163,184,0.18)" stroke-width="0.6"/>
            <line x1="60" y1="0" x2="60" y2="120" stroke="rgba(212,175,55,0.32)" stroke-width="0.8" stroke-dasharray="2 2"/>
            <line x1="90" y1="0" x2="90" y2="120" stroke="rgba(148,163,184,0.18)" stroke-width="0.6"/>
            <rect x="${cam.camX}" y="${cam.camY}" width="${cam.viewCols}" height="${cam.viewRows}" fill="rgba(250,204,21,0.18)" stroke="#FACC15" stroke-width="1.4"/>
            ${dots}
            <text x="4" y="115" font-size="7.5" font-weight="900" fill="#FDE047">120×120 (180m)</text>
        </svg>
    `;
}

function ehPilarCoberturaMapa120(gx, gy) {
    const x = Number(gx || 0), y = Number(gy || 0);
    if (x === 1 && (y === 1 || y === 3)) return true;
    if (x === 55 && (y === 55 || y === 59)) return true;
    return ((x > 4) && (y > 2) && ((x * 7 + y * 13) % 29 === 0) && (x % 4 === 1) && (y % 3 === 1));
}

window.__MODO_CAMERA_VTT__ = window.__MODO_CAMERA_VTT__ || 'TOP_DOWN';

function mapearGridParaPalco2DSVG(gx, gy, totalCols, totalRows) {
    const cam = obterCameraAtivaMapa120JS();
    const cols = Math.max(6, cam.viewCols || 12);
    const rows = Math.max(4, cam.viewRows || 7);
    const localX = Number(gx || 0) - cam.camX;
    const localY = Number(gy || 0) - cam.camY;

    // v69: Câmera VTT Visão Superior (Top-Down Ortogonal 120x120) — quadrados exatos para Régua, Esfera, Cone, Linha e Tokens!
    if ((window.__MODO_CAMERA_VTT__ || 'TOP_DOWN') === 'TOP_DOWN') {
        const cell = Math.max(18, Math.min(Math.floor(810 / cols), Math.floor(330 / rows)));
        const gridW = cell * cols;
        const gridH = cell * rows;
        const offX = (860 - gridW) / 2;
        const offY = (370 - gridH) / 2 + 12;
        const px = offX + (localX + 0.5) * cell;
        const py = offY + (localY + 0.5) * cell;
        const sc = Math.min(0.76, Math.max(0.32, cell / 62));
        return { px, py, sc, tileW: cell, tileH: cell, topDown: true };
    }

    const span = (cols - 1) + (rows - 1);
    const tileW = Math.min(44, Math.max(14, Math.floor(640 / Math.max(6, span))));
    const tileH = Math.min(13, Math.max(4.8, Number((tileW * 0.28).toFixed(2))));
    const u = localX - (cols - 1) / 2;
    const v = localY - (rows - 1) / 2;
    const px = 430 + (u - v) * tileW;
    const py = 232 + (u + v) * tileH;
    const fyNorm = Math.max(0, Math.min(1, (py - 140) / 150));
    const scBase = Math.min(0.74, Math.max(0.28, tileW / 56));
    const sc = scBase + fyNorm * 0.10;
    return { px, py, sc, tileW, tileH, topDown: false };
}

function construirGradePerspectivaChao2DSVG(totalCols, totalRows, modoMesaOnline) {
    const cam = obterCameraAtivaMapa120JS();
    const cols = cam.viewCols || 12;
    const rows = cam.viewRows || 7;
    let losangos = '';
    for (let ly = 0; ly < rows; ly++) {
        for (let lx = 0; lx < cols; lx++) {
            const gx = cam.camX + lx;
            const gy = cam.camY + ly;
            const pTop = mapearGridParaPalco2DSVG(gx - 0.5, gy - 0.5, cols, rows);
            const pRight = mapearGridParaPalco2DSVG(gx + 0.5, gy - 0.5, cols, rows);
            const pBot = mapearGridParaPalco2DSVG(gx + 0.5, gy + 0.5, cols, rows);
            const pLeft = mapearGridParaPalco2DSVG(gx - 0.5, gy + 0.5, cols, rows);
            if (pTop.topDown) {
                const ehParTD = ((gx + gy) % 2 === 0);
                const ehPilarTD = ehPilarCoberturaMapa120(gx, gy);
                const fillTD = ehPilarTD ? 'rgba(71, 85, 105, 0.82)' : (ehParTD ? 'rgba(26, 36, 56, 0.86)' : 'rgba(15, 23, 42, 0.88)');
                const fnClickTD = modoMesaOnline ? `clicarCelulaGrid2DMesaOnlineJS(${gx}, ${gy})` : `moverHeroiParaCelulaGridArenaJS(${gx}, ${gy})`;
                const cellPx = pTop.tileW;
                losangos += `<rect x="${pTop.px.toFixed(1)}" y="${pTop.py.toFixed(1)}" width="${cellPx.toFixed(1)}" height="${cellPx.toFixed(1)}" fill="${fillTD}" stroke="rgba(217,119,6,0.34)" stroke-width="0.85" style="cursor:pointer;" onclick="${fnClickTD}"><title>Quadrado (${gx + 1}, ${gy + 1}) · Mapa VTT 120×120 (1,5m/q)</title></rect>`;
                if (lx === 0 || ly === 0) {
                    losangos += `<text x="${(pTop.px + 3).toFixed(1)}" y="${(pTop.py + 9).toFixed(1)}" font-size="7.5" font-weight="700" fill="rgba(148,163,184,0.55)" pointer-events="none">${gx + 1},${gy + 1}</text>`;
                }
                continue;
            }
            const ehPar = ((gx + gy) % 2 === 0);
            const ehPilar = ehPilarCoberturaMapa120(gx, gy);
            const fillCor = ehPilar ? 'rgba(71, 85, 105, 0.68)' : (ehPar ? 'rgba(30, 41, 59, 0.52)' : 'rgba(15, 23, 42, 0.56)');
            const fnClick = modoMesaOnline ? `clicarCelulaGrid2DMesaOnlineJS(${gx}, ${gy})` : `moverHeroiParaCelulaGridArenaJS(${gx}, ${gy})`;
            losangos += `
                <polygon points="${pTop.px.toFixed(1)},${pTop.py.toFixed(1)} ${pRight.px.toFixed(1)},${pRight.py.toFixed(1)} ${pBot.px.toFixed(1)},${pBot.py.toFixed(1)} ${pLeft.px.toFixed(1)},${pLeft.py.toFixed(1)}"
                         fill="${fillCor}" stroke="rgba(217,119,6,0.38)" stroke-width="0.9"
                         style="cursor:pointer;" onclick="${fnClick}">
                    <title>Quadrado (${gx + 1}, ${gy + 1}) do Mapa 120×120 — Clique para mover para cá!</title>
                </polygon>
            `;
        }
    }
    return `<g class="grid-chao-2d-isometrico" shape-rendering="geometricPrecision">${losangos}</g>`;
}

function construirPegadaIsometricaTamanhoSVG(gx, gy, espacoQ, totalCols, totalRows, corBorda, corFill) {
    const q = Math.max(1, Number(espacoQ || 1));
    const pTop = mapearGridParaPalco2DSVG(gx - 0.5, gy - 0.5, totalCols, totalRows);
    const pRight = mapearGridParaPalco2DSVG(gx + q - 0.5, gy - 0.5, totalCols, totalRows);
    const pBot = mapearGridParaPalco2DSVG(gx + q - 0.5, gy + q - 0.5, totalCols, totalRows);
    const pLeft = mapearGridParaPalco2DSVG(gx - 0.5, gy + q - 0.5, totalCols, totalRows);
    const cx = (pTop.px + pBot.px) / 2;
    const cy = (pTop.py + pBot.py) / 2;

    if (pTop.topDown) {
        const w = q * pTop.tileW;
        const h = q * pTop.tileH;
        const x0 = pTop.px;
        const y0 = pTop.py;
        let subLinhas = '';
        if (q >= 2 && corFill !== 'none') {
            for (let i = 1; i < q; i++) {
                const lx = x0 + i * pTop.tileW;
                const ly = y0 + i * pTop.tileH;
                subLinhas += `<line x1="${lx.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${lx.toFixed(1)}" y2="${(y0 + h).toFixed(1)}" stroke="${corBorda || '#EF4444'}" stroke-width="0.9" stroke-dasharray="3 2" opacity="0.55"/>`;
                subLinhas += `<line x1="${x0.toFixed(1)}" y1="${ly.toFixed(1)}" x2="${(x0 + w).toFixed(1)}" y2="${ly.toFixed(1)}" stroke="${corBorda || '#EF4444'}" stroke-width="0.9" stroke-dasharray="3 2" opacity="0.55"/>`;
            }
        }
        // Âncora proporcional ao quadrado q×q sem distorção (mantém o sprite inteiro dentro do bloco)
        const anchorY = cy + h * 0.28;
        return {
            cx, cy, anchorX: cx, anchorY,
            pTopY: y0, pBotY: y0 + h,
            larguraLosangoPx: w, alturaLosangoPx: h,
            tileW: pTop.tileW, tileH: pTop.tileH, topDown: true,
            sc: pTop.sc,
            svg: `<g class="pegada-ocupacao-isometrica" pointer-events="none"><rect x="${x0.toFixed(1)}" y="${y0.toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" rx="3" fill="${corFill || 'rgba(239,68,68,0.22)'}" stroke="${corBorda || '#EF4444'}" stroke-width="${q >= 2 ? '2.2' : '1.6'}"/>${subLinhas}</g>`
        };
    }

    const larguraLosangoPx = Math.max(24, Math.abs(pRight.px - pLeft.px));
    const alturaLosangoPx = Math.max(10, Math.abs(pBot.py - pTop.py));
    const anchorY = cy + (pBot.py - cy) * (q >= 2 ? 0.25 : 0.12);
    let subLinhas = '';
    if (q >= 2 && corFill !== 'none') {
        for (let i = 1; i < q; i++) {
            const a1 = mapearGridParaPalco2DSVG(gx + i - 0.5, gy - 0.5, totalCols, totalRows);
            const a2 = mapearGridParaPalco2DSVG(gx + i - 0.5, gy + q - 0.5, totalCols, totalRows);
            const b1 = mapearGridParaPalco2DSVG(gx - 0.5, gy + i - 0.5, totalCols, totalRows);
            const b2 = mapearGridParaPalco2DSVG(gx + q - 0.5, gy + i - 0.5, totalCols, totalRows);
            subLinhas += `<line x1="${a1.px.toFixed(1)}" y1="${a1.py.toFixed(1)}" x2="${a2.px.toFixed(1)}" y2="${a2.py.toFixed(1)}" stroke="${corBorda || '#EF4444'}" stroke-width="0.9" stroke-dasharray="3 2" opacity="0.65"/>`;
            subLinhas += `<line x1="${b1.px.toFixed(1)}" y1="${b1.py.toFixed(1)}" x2="${b2.px.toFixed(1)}" y2="${b2.py.toFixed(1)}" stroke="${corBorda || '#EF4444'}" stroke-width="0.9" stroke-dasharray="3 2" opacity="0.65"/>`;
        }
    }
    return {
        cx, cy, anchorX: cx, anchorY,
        pTopY: pTop.py, pBotY: pBot.py,
        larguraLosangoPx, alturaLosangoPx,
        tileW: pTop.tileW, tileH: pTop.tileH, topDown: false,
        sc: (pTop.sc + pBot.sc) / 2,
        svg: `<g class="pegada-ocupacao-isometrica" pointer-events="none"><polygon points="${pTop.px.toFixed(1)},${pTop.py.toFixed(1)} ${pRight.px.toFixed(1)},${pRight.py.toFixed(1)} ${pBot.px.toFixed(1)},${pBot.py.toFixed(1)} ${pLeft.px.toFixed(1)},${pLeft.py.toFixed(1)}" fill="${corFill || 'rgba(239,68,68,0.22)'}" stroke="${corBorda || '#EF4444'}" stroke-width="${q >= 2 ? '2.2' : '1.6'}"/>${subLinhas}</g>`
    };
}

// =============================================================================
// SISTEMA DINÂMICO ANTI-OCLUSÃO & CONTROLE DE VISIBILIDADE DE TOKENS/AMEAÇAS (v64)
// Modos: 'AUTO_ANTI_OCLUSAO' (padrão) | 'FANTASMA_RAIO_X' (35% opacidade) | 'OCULTAR_TOKEN' (só pegada/PV)
// =============================================================================
window.__MODO_OCLUSAO_AMEACA__ = 'AUTO_ANTI_OCLUSAO';
window.__GRID_2D_ARENA_OCULTO__ = false;

function obterRotuloBotaoOclusaoAmeacaJS() {
    const m = window.__MODO_OCLUSAO_AMEACA__ || 'AUTO_ANTI_OCLUSAO';
    if (m === 'OCULTAR_TOKEN') return '🚫 Token Ameaça: Oculto (Só Pegada)';
    if (m === 'FANTASMA_RAIO_X') return '👻 Token Ameaça: Fantasma (35%)';
    return '👁️ Ameaça: Anti-Oclusão Auto';
}

function alternarModoOclusaoAmeacaGiganteJS() {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    const atual = window.__MODO_OCLUSAO_AMEACA__ || 'AUTO_ANTI_OCLUSAO';
    if (atual === 'AUTO_ANTI_OCLUSAO') {
        window.__MODO_OCLUSAO_AMEACA__ = 'FANTASMA_RAIO_X';
    } else if (atual === 'FANTASMA_RAIO_X') {
        window.__MODO_OCLUSAO_AMEACA__ = 'OCULTAR_TOKEN';
    } else {
        window.__MODO_OCLUSAO_AMEACA__ = 'AUTO_ANTI_OCLUSAO';
    }
    const rot = obterRotuloBotaoOclusaoAmeacaJS();
    ['btn-arena-oclusao-ameaca', 'btn-mesa-oclusao-ameaca'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = rot;
    });
    if (typeof atualizarPlacarVisualArena === 'function' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) atualizarPlacarVisualArena();
    if (typeof renderizarMesaOnlineCompletaUI === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) renderizarMesaOnlineCompletaUI();
}

function alternarPainelGrid2DArenaVisivelJS() {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    window.__GRID_2D_ARENA_OCULTO__ = !window.__GRID_2D_ARENA_OCULTO__;
    const box = document.getElementById('arena-tactical-2d-panel');
    if (box) box.style.display = window.__GRID_2D_ARENA_OCULTO__ ? 'none' : 'block';
    const btn = document.getElementById('btn-toggle-grid2d-arena-inline');
    if (btn) btn.innerHTML = window.__GRID_2D_ARENA_OCULTO__ ? '🗺️ Mostrar Grid 2D' : '🗺️ Ocultar Grid 2D';
}

function calcularOpacidadeAntiOclusaoCriatura2D(crObj, heroisLista) {
    const modo = window.__MODO_OCLUSAO_AMEACA__ || 'AUTO_ANTI_OCLUSAO';
    if (modo === 'OCULTAR_TOKEN') return 0.0;
    if (modo === 'FANTASMA_RAIO_X') return 0.35;
    const qC = Math.max(1, Number((crObj && crObj.espacoQ) || 1));
    if (qC <= 1) return 1.0;
    const gxC = Number((crObj && crObj.gx) || 0);
    const gyC = Number((crObj && crObj.gy) || 0);
    // Se algum herói estiver próximo/atrás/adjacente a uma criatura Grande (2x2), Enorme (3x3) ou Colossal (6x6),
    // reduz dinamicamente a opacidade do corpo da criatura para nunca esconder os personagens!
    let menorDist = 999;
    (heroisLista || []).forEach(h => {
        if (!h || h.gx === undefined || h.gy === undefined) return;
        const cx = Math.max(gxC, Math.min(gxC + qC - 1, Number(h.gx)));
        const cy = Math.max(gyC, Math.min(gyC + qC - 1, Number(h.gy)));
        const d = Math.max(Math.abs(Number(h.gx) - cx), Math.abs(Number(h.gy) - cy));
        if (d < menorDist) menorDist = d;
    });
    if (qC >= 6) {
        return menorDist <= 2 ? 0.68 : 0.84;
    }
    if (qC >= 3) {
        return menorDist <= 1 ? 0.74 : 0.90;
    }
    return menorDist <= 1 ? 0.82 : 0.96;
}

function calcularEscalaProporcionalUnidadePalco2D(peg, espacoQ, tamanhoCat, ehCriatura) {
    // Dimensão estritamente proporcional ao(s) quadrado(s) ocupado(s) pela categoria de tamanho T20 JdA:
    // Minúsculo/Pequeno/Médio = 1×1 | Grande = 2×2 | Enorme = 3×3 | Colossal = 6×6
    const q = Math.max(1, Number(espacoQ || 1));
    const tileW = (peg && peg.tileW) ? peg.tileW : 36;
    const catLow = String(tamanhoCat || 'Médio').toLowerCase();

    if (!ehCriatura) {
        // Sprite base do herói tem ~145px de largura; alvo estrito = 84% de 1 quadrado (tileW)
        const sc1x1 = (tileW * 0.84) / 145;
        if (q >= 3 || catLow.includes('enorme')) return Number(Math.min(0.66, sc1x1 * 2.45).toFixed(3));
        if (q === 2 || catLow.includes('grande')) return Number(Math.min(0.48, sc1x1 * 1.75).toFixed(3));
        if (catLow.includes('minúsculo') || catLow.includes('minusculo')) return Number((sc1x1 * 0.62).toFixed(3));
        if (catLow.includes('pequeno')) return Number((sc1x1 * 0.80).toFixed(3));
        return Number(sc1x1.toFixed(3));
    }

    // Sprite base de criatura tem ~165px de largura; alvo estrito = 86% da largura dos quadrados ocupados
    const sc1x1 = (tileW * 0.86) / 165;
    if (q >= 6 || catLow.includes('colossal')) {
        return Number(Math.min(0.76, sc1x1 * 3.80).toFixed(3));
    }
    if (q === 3 || catLow.includes('enorme')) {
        return Number(Math.min(0.68, sc1x1 * 2.55).toFixed(3));
    }
    if (q === 2 || catLow.includes('grande')) {
        return Number(Math.min(0.48, sc1x1 * 1.80).toFixed(3));
    }
    if (catLow.includes('minúsculo') || catLow.includes('minusculo')) {
        return Number((sc1x1 * 0.60).toFixed(3));
    }
    if (catLow.includes('pequeno')) {
        return Number((sc1x1 * 0.78).toFixed(3));
    }
    return Number(sc1x1.toFixed(3));
}

// =============================================================================
// TOKENS VTT (VIRTUAL TABLETOP) DE ALTA RESOLUÇÃO (HERÓIS FRONTAIS E 83 AMEAÇAS HD) - v57
// =============================================================================
function construirToken2DHeroiGridHTML(stOuFake, bordaCor, tamanhoPx, badgesCondStr, pctPv) {
    const sz = tamanhoPx || 44;
    const sprite = (typeof construirSpriteSVGHeroiJRPG === 'function') ? construirSpriteSVGHeroiJRPG(stOuFake) : '';
    const corAnel = bordaCor || '#D97706';
    const uid = gerarUidUnicoSVGT20('tokH');
    const pvPct = pctPv !== undefined ? Math.max(0, Math.min(100, Number(pctPv))) : 100;
    const racaTxt = (stOuFake && stOuFake.raca && stOuFake.raca.nome) ? stOuFake.raca.nome.slice(0, 8).toUpperCase() : 'HERÓI';
    return `
        <div style="position:relative; width:${sz}px; height:${sz}px; flex-shrink:0; filter:drop-shadow(0 3px 6px rgba(0,0,0,0.92));">
            <svg viewBox="0 0 120 134" width="${sz}" height="${sz}" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges" style="display:block; overflow:visible;">
                <defs>
                    <clipPath id="${uid}_clip"><circle cx="60" cy="56" r="50"/></clipPath>
                </defs>
                <circle cx="60" cy="60" r="55" fill="rgba(0,0,0,0.85)"/>
                <circle cx="60" cy="56" r="51" fill="#0F172A"/>
                <g clip-path="url(#${uid}_clip)">
                    <svg x="6" y="1" width="108" height="112" viewBox="144 40 144 205" preserveAspectRatio="xMidYMid meet" shape-rendering="crispEdges">
                        ${sprite}
                    </svg>
                </g>
                <circle cx="60" cy="56" r="51" fill="none" stroke="${corAnel}" stroke-width="4.8"/>
                <circle cx="60" cy="56" r="48" fill="none" stroke="#07040B" stroke-width="1.4"/>
                <rect x="14" y="102" width="92" height="16" rx="4" fill="#140C16" stroke="${corAnel}" stroke-width="1.5"/>
                <text x="60" y="113" text-anchor="middle" font-family="monospace" font-size="10.5" font-weight="900" fill="#FDE68A">${racaTxt}</text>
                <rect x="20" y="120" width="80" height="6" rx="2" fill="#090D16" stroke="#07040B" stroke-width="1"/>
                <rect x="21.5" y="121" width="${Math.round(0.77 * pvPct)}" height="4" fill="${pvPct > 45 ? '#22C55E' : (pvPct > 20 ? '#F59E0B' : '#EF4444')}"/>
            </svg>
            ${badgesCondStr ? `<span style="position:absolute; top:-4px; right:-4px; font-size:10px; background:#090D16; border:1px solid #D97706; border-radius:999px; padding:0 3px; line-height:1.2;">${badgesCondStr}</span>` : ''}
        </div>
    `;
}

function construirToken2DAliadoGridHTML(bordaCor, tamanhoPx) {
    const sz = tamanhoPx || 44;
    const fakeAliado = {
        nome: 'Aliado Tático', nivel: 5, ehMembroPartyMesa: true,
        raca: { nome: 'Humano' }, classe: { nome: 'Cavaleiro' },
        arma: { nome: 'Espada Longa' }, escudo: { nome: 'Escudo Pesado' }, poderes: []
    };
    return construirToken2DHeroiGridHTML(fakeAliado, bordaCor || '#38BDF8', sz, '🛡️', 100);
}

function construirToken2DCriaturaGridHTML(crObj, bordaCor, tamanhoPx, badgesCondStr) {
    const sz = tamanhoPx || 44;
    const nomeLimpo = String((crObj && (crObj.nomeCriatura || crObj.nome)) || 'Ameaça').replace(/ #\d+$/, '').trim();
    const privFake = {
        id_ameaca: crObj ? (crObj.id_ameaca || crObj.id) : '',
        nomeCriatura: nomeLimpo,
        grupoCap7: (crObj && (crObj.grupoCap7 || crObj.grupo_cap7)) || 'Dragões'
    };
    const perfil = (typeof obterPerfilVisualUnico83AmeacasCap7 === 'function')
        ? obterPerfilVisualUnico83AmeacasCap7(nomeLimpo, privFake.grupoCap7)
        : { rotuloCurto: nomeLimpo.slice(0, 8).toUpperCase(), corFundo: '#2A0810', corAnel: '#DC2626', viewBoxToken: '555 62 180 202' };
    const sprite = (typeof construirSpriteSVGCriaturaJRPG === 'function') ? construirSpriteSVGCriaturaJRPG(privFake) : '';
    const corAnel = bordaCor || perfil.corAnel || '#DC2626';
    const uid = gerarUidUnicoSVGT20('tokC');
    const pvPct = (crObj && crObj.pvMax)
        ? Math.max(0, Math.min(100, Math.round((Number(crObj.pvAtual !== undefined ? crObj.pvAtual : crObj.pvMax) / Math.max(1, Number(crObj.pvMax))) * 100)))
        : 100;
    return `
        <div style="position:relative; width:${sz}px; height:${sz}px; flex-shrink:0; filter:drop-shadow(0 3px 6px rgba(0,0,0,0.94));" title="${nomeLimpo}">
            <svg viewBox="0 0 120 134" width="${sz}" height="${sz}" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges" style="display:block; overflow:visible;">
                <defs>
                    <clipPath id="${uid}_clip"><circle cx="60" cy="56" r="50"/></clipPath>
                </defs>
                <circle cx="60" cy="60" r="55" fill="rgba(0,0,0,0.88)"/>
                <circle cx="60" cy="56" r="51" fill="${perfil.corFundo || '#1E0910'}"/>
                <g clip-path="url(#${uid}_clip)">
                    <svg x="5" y="1" width="110" height="112" viewBox="555 58 180 206" preserveAspectRatio="xMidYMid meet" shape-rendering="crispEdges">
                        ${sprite}
                    </svg>
                </g>
                <circle cx="60" cy="56" r="51" fill="none" stroke="${corAnel}" stroke-width="4.8"/>
                <circle cx="60" cy="56" r="48" fill="none" stroke="#07040B" stroke-width="1.4"/>
                <rect x="10" y="102" width="100" height="16" rx="4" fill="#12080C" stroke="${corAnel}" stroke-width="1.5"/>
                <text x="60" y="113" text-anchor="middle" font-family="monospace" font-size="10.2" font-weight="900" fill="#FEF08A">${perfil.rotuloCurto}</text>
                <rect x="20" y="120" width="80" height="6" rx="2" fill="#090D16" stroke="#07040B" stroke-width="1"/>
                <rect x="21.5" y="121" width="${Math.round(0.77 * pvPct)}" height="4" fill="#EF4444"/>
            </svg>
            ${badgesCondStr ? `<span style="position:absolute; top:-4px; right:-4px; font-size:10px; background:#090D16; border:1px solid #F87171; border-radius:999px; padding:0 3px; line-height:1.2;">${badgesCondStr}</span>` : ''}
        </div>
    `;
}

function construirCardVitrine3DRetratoFichaSVG(estado) {
    if (!estado) return '';
    const racaNome = (estado.raca && estado.raca.nome) ? estado.raca.nome.toUpperCase() : 'HUMANO';
    const classeNome = (estado.classe && estado.classe.nome) ? estado.classe.nome.toUpperCase() : 'AVENTUREIRO';
    const sprite = (typeof construirSpriteSVGHeroiJRPG === 'function') ? construirSpriteSVGHeroiJRPG(estado) : '';
    return `
        <svg viewBox="120 44 192 254" width="124" height="162" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges" style="background:#0B0912; border-radius:10px; border:2.5px solid #D97706; display:block; box-shadow:0 8px 20px rgba(0,0,0,0.9);">
            <rect x="120" y="44" width="192" height="254" fill="#120D1D"/>
            <rect x="128" y="52" width="176" height="238" fill="none" stroke="#4C1D95" stroke-width="2"/>
            ${sprite}
            <rect x="126" y="48" width="180" height="20" fill="#3B070B" stroke="#D97706" stroke-width="1.5"/>
            <text x="216" y="61.5" text-anchor="middle" font-family="monospace" font-size="10.2" font-weight="900" fill="#FDE68A" letter-spacing="0.8">${racaNome}</text>
            <rect x="126" y="273" width="180" height="19" fill="#0D0914" stroke="#D97706" stroke-width="1.5"/>
            <text x="216" y="285.5" text-anchor="middle" font-family="monospace" font-size="9.2" font-weight="900" fill="#E2E8F0" letter-spacing="0.5">${classeNome} · NV ${estado.nivel || 1}</text>
        </svg>
    `;
}


function atualizarRetratoFichaPrincipalJS() {
    const st = window.__ULTIMO_ESTADO_FICHA__ || (typeof garantirEstadoFichaParaArena === 'function' ? garantirEstadoFichaParaArena() : null);
    if (!st) return;
    const cardSvg = construirCardVitrine3DRetratoFichaSVG(st);
    ['ficha-retrato-custom-svg', 'card-retrato-3d-ficha'].forEach(idBox => {
        const box = document.getElementById(idBox);
        if (box) box.innerHTML = cardSvg;
    });
    const arenaHeroMini = document.getElementById('arena-svg-heroi');
    if (arenaHeroMini && typeof construirToken2DHeroiGridHTML === 'function') {
        arenaHeroMini.style.background = 'none';
        arenaHeroMini.style.border = 'none';
        arenaHeroMini.innerHTML = construirToken2DHeroiGridHTML(st, '#FACC15', 42, '', 100);
    }
}

function gerarDefsShader3DRPG() { return ''; }

function construirOverlayCondicoes2DSVG(cx, cy, conds) {
    if (!conds) return '';
    let svg = '';
    // 1. EM CHAMAS (Fogo 2D animado na base e torso)
    if (conds.emChamas) {
        svg += `
            <g class="cond-2d-chamas" pointer-events="none">
                <path d="M ${cx - 34} ${cy} Q ${cx - 42} ${cy - 48} ${cx - 18} ${cy - 76} Q ${cx - 8} ${cy - 42} ${cx} ${cy - 88} Q ${cx + 12} ${cy - 44} ${cx + 22} ${cy - 74} Q ${cx + 42} ${cy - 42} ${cx + 34} ${cy} Z" fill="rgba(249,115,22,0.55)" stroke="#EF4444" stroke-width="1.5"/>
                <path d="M ${cx - 20} ${cy} Q ${cx - 24} ${cy - 34} ${cx - 8} ${cy - 54} Q ${cx} ${cy - 28} ${cx + 8} ${cy - 58} Q ${cx + 24} ${cy - 32} ${cx + 20} ${cy} Z" fill="rgba(253,224,71,0.72)"/>
                <text x="${cx - 38}" y="${cy - 85}" font-size="16">🔥</text>
                <text x="${cx + 22}" y="${cy - 78}" font-size="15">🔥</text>
            </g>
        `;
    }
    // 2. SANGRANDO (Gotas carmesim 2D)
    if (conds.sangrando) {
        svg += `
            <g class="cond-2d-sangrando" pointer-events="none">
                <path d="M ${cx - 26} ${cy - 62} C ${cx - 30} ${cy - 50}, ${cx - 22} ${cy - 50}, ${cx - 26} ${cy - 62} Z" fill="#DC2626" stroke="#FEF2F2" stroke-width="0.8"/>
                <circle cx="${cx - 26}" cy="${cy - 48}" r="4.5" fill="#DC2626"/>
                <circle cx="${cx + 28}" cy="${cy - 56}" r="4" fill="#EF4444"/>
                <circle cx="${cx + 22}" cy="${cy - 36}" r="3.5" fill="#B91C1C"/>
                <ellipse cx="${cx}" cy="${cy + 3}" rx="38" ry="6" fill="rgba(220,38,38,0.45)"/>
                <text x="${cx + 26}" y="${cy - 62}" font-size="14">🩸</text>
            </g>
        `;
    }
    // 3. ENVENENADO (Névoa e bolhas ácidas verdes 2D)
    if (conds.envenenado) {
        svg += `
            <g class="cond-2d-veneno" pointer-events="none">
                <ellipse cx="${cx}" cy="${cy - 38}" rx="42" ry="28" fill="rgba(34,197,94,0.22)"/>
                <circle cx="${cx - 22}" cy="${cy - 52}" r="5" fill="#4ADE80" opacity="0.85"/>
                <circle cx="${cx + 18}" cy="${cy - 68}" r="6" fill="#22C55E" opacity="0.85"/>
                <circle cx="${cx - 8}" cy="${cy - 82}" r="4" fill="#86EFAC" opacity="0.9"/>
                <text x="${cx - 36}" y="${cy - 64}" font-size="14">🤢</text>
            </g>
        `;
    }
    // 4. LENTO / ENREDADO (Cristais de gelo / raízes nos pés)
    if (conds.lento) {
        svg += `
            <g class="cond-2d-lento" pointer-events="none">
                <polygon points="${cx - 36},${cy + 2} ${cx - 24},${cy - 24} ${cx - 12},${cy + 2}" fill="rgba(56,189,248,0.72)" stroke="#E0F2FE" stroke-width="1.2"/>
                <polygon points="${cx + 12},${cy + 2} ${cx + 24},${cy - 26} ${cx + 36},${cy + 2}" fill="rgba(56,189,248,0.72)" stroke="#E0F2FE" stroke-width="1.2"/>
                <line x1="${cx - 38}" y1="${cy - 6}" x2="${cx + 38}" y2="${cy - 10}" stroke="#38BDF8" stroke-width="2.5" stroke-dasharray="5 3"/>
            </g>
        `;
    }
    // 5. ATORDOADO / PARALISADO (Estrelas girando no topo)
    if (conds.atordoado) {
        svg += `
            <g class="cond-2d-atordoado" pointer-events="none">
                <ellipse cx="${cx}" cy="${cy - 148}" rx="34" ry="9" fill="none" stroke="#FDE047" stroke-width="2" stroke-dasharray="6 4"/>
                <text x="${cx - 28}" y="${cy - 144}" font-size="14">💫</text>
                <text x="${cx + 14}" y="${cy - 144}" font-size="14">⭐</text>
            </g>
        `;
    }
    // 6. DESPREVENIDO (-5 Defesa)
    if (conds.desprevenido) {
        svg += `
            <g class="cond-2d-desprevenido" pointer-events="none">
                <rect x="${cx - 46}" y="${cy - 172}" width="92" height="17" rx="5" fill="rgba(127,29,29,0.92)" stroke="#FACC15" stroke-width="1.4"/>
                <text x="${cx}" y="${cy - 160}" text-anchor="middle" font-size="9.5" font-weight="900" fill="#FEF08A">❗ DESPREVENIDO (-5 DEF)</text>
            </g>
        `;
    }
    // 7. CAÍDO (-5 Ataque e -5 Defesa CaC)
    if (conds.caido) {
        svg += `
            <g class="cond-2d-caido" pointer-events="none">
                <rect x="${cx - 38}" y="${cy - 22}" width="76" height="17" rx="5" fill="rgba(15,23,42,0.92)" stroke="#F87171" stroke-width="1.4"/>
                <text x="${cx}" y="${cy - 10}" text-anchor="middle" font-size="9.5" font-weight="900" fill="#FCA5A5">🔻 CAÍDO (-5 DEF)</text>
            </g>
        `;
    }
    return svg;
}

// ==============================================================================
// 2. ARSENAL INDIVIDUALIZADO DE TORMENTA 20 (30 ARMAS + 8 MATERIAIS + 10 EFEITOS)
// ==============================================================================
function obterCoresMaterialEspecialT20(matEsp, efArma) {
    const mapaMat = {
        'ACO_PADRAO': { metal1: '#F1F5F9', metal2: '#475569', borda: '#09060C', guarda: '#D97706' },
        'ACO_RUBI': { metal1: '#FDA4AF', metal2: '#9F1239', borda: '#2A040E', guarda: '#FACC15' },
        'ADAMANTE': { metal1: '#94A3B8', metal2: '#0F172A', borda: '#818CF8', guarda: '#C084FC' },
        'MITRAL': { metal1: '#F8FAFC', metal2: '#0284C7', borda: '#082F49', guarda: '#E0F2FE' },
        'MATERIA_VERMELHA': { metal1: '#FB7185', metal2: '#881337', borda: '#4C0519', guarda: '#F43F5E' },
        'GELO_ETERNO': { metal1: '#ECFEFF', metal2: '#0891B2', borda: '#083344', guarda: '#67E8F9' },
        'MADEIRA_TOLLON': { metal1: '#34D399', metal2: '#065F46', borda: '#022C22', guarda: '#A7F3D0' },
        'OURO_AZGHER': { metal1: '#FEF08A', metal2: '#B45309', borda: '#271003', guarda: '#FDE047' }
    };
    const mapaEf = {
        'ACO_FORJADO': { brilho: '#E2E8F0', aura: 'none', part: '' },
        'FOGO_SOLAR': { brilho: '#F97316', aura: '#EA580C', part: '🔥' },
        'RAIO_TROVAO': { brilho: '#38BDF8', aura: '#0284C7', part: '⚡' },
        'GELO_CRISTAL': { brilho: '#67E8F9', aura: '#0891B2', part: '❄️' },
        'VENENO_ACIDO': { brilho: '#22C55E', aura: '#15803D', part: '🧪' },
        'LUZ_PALADINO': { brilho: '#FEF08A', aura: '#EAB308', part: '☀️' },
        'TREVAS_PROFANA': { brilho: '#C084FC', aura: '#581C87', part: '🌑' },
        'RUBRO_TORMENTA': { brilho: '#F43F5E', aura: '#9F1239', part: '👁️' },
        'ESSENCIA_ASTRAL': { brilho: '#818CF8', aura: '#4F46E5', part: '✨' }
    };
    const m = mapaMat[matEsp || 'ACO_PADRAO'] || mapaMat['ACO_PADRAO'];
    const e = mapaEf[efArma || 'ACO_FORJADO'] || mapaEf['ACO_FORJADO'];
    return { ...m, ...e };
}

// Arsenais na Mão Direita do Herói Frontal (Punho em x=254, y=176)
// =============================================================================
// ARSENAL, ESCUDOS, HERÓIS (17 RAÇAS + 14 CLASSES) E 83 AMEAÇAS EM PIXEL ART 16-BIT/32-BIT (v58)
// =============================================================================
function construirSVGArsenaisT20(armaStr, ehConjurador, corDetalhe, efeitoArma, materialEspecial, exemplarStr) {
    const a = String(armaStr || 'espada longa').toLowerCase();
    const cMat = obterCoresMaterialEspecialT20(materialEspecial, efeitoArma);
    const pal = {
        '#': '#07040B',
        'S': cMat.metal1 || '#F1F5F9',
        's': cMat.metal2 || '#64748B',
        'W': '#FFFFFF',
        'D': corDetalhe || '#F59E0B',
        'd': '#92400E',
        'L': '#78350F',
        'l': '#451A03',
        'F': cMat.aura1 || '#F97316',
        'Y': cMat.aura2 || '#FEF08A'
    };
    const temAura = efeitoArma && efeitoArma !== 'ACO_FORJADO';
    let mat = [
        "...WW...",
        "...SS...",
        "..FSSF..",
        "...SS...",
        "..FSSF..",
        "...SS...",
        "...ss...",
        ".DDDDDD.",
        "...LL...",
        "...DD..."
    ];
    if (a.includes('machado') || a.includes('táurico')) {
        mat = [
            "....DD....",
            ".WWSSSSWW.",
            "WSSSSSSSSW",
            "WSSsLLsSSW",
            ".WW.LL.WW.",
            "....LL....",
            "....LL....",
            "....ll....",
            "....DD...."
        ];
    } else if (a.includes('marreta') || a.includes('martelo') || a.includes('maça')) {
        mat = [
            ".DDDDDDDD.",
            "DSSSSSSSSd",
            "DSSsWWsSSD",
            ".DDDDDDDD.",
            "....LL....",
            "....LL....",
            "....ll....",
            "....DD...."
        ];
    } else if (a.includes('alabarda') || a.includes('lança') || a.includes('tridente') || a.includes('gadanho')) {
        mat = [
            "....WW....",
            "...WSSW...",
            "..WSSSSW..",
            "..DDDDDD..",
            "....LL....",
            "....LL....",
            "....LL....",
            "....ll....",
            "....DD...."
        ];
    } else if (a.includes('arco')) {
        mat = [
            "...DDW..",
            "..LL.W..",
            ".LL..W..",
            ".DD.FWY.",
            ".LL..W..",
            "..LL.W..",
            "...DDW.."
        ];
    } else if (a.includes('mosquete') || a.includes('pistola') || a.includes('besta')) {
        mat = [
            "....WW....",
            "....SS....",
            "...DSS....",
            "...LLL....",
            "...LLD...."
        ];
    } else if (a.includes('cajado') || a.includes('varinha') || ehConjurador) {
        mat = [
            "..FYYYYF..",
            ".FYWWWWYF.",
            "..DDDDDD..",
            "....LL....",
            "....LL....",
            "....LL....",
            "....ll....",
            "....DD...."
        ];
    }
    if (!temAura) {
        mat = mat.map(r => r.replace(/F|Y/g, '.'));
    }
    return renderizarMatrizPixelArtSVG(mat, pal, 174, 210, 4.4, true);
}

function construirSVGMaoSecundariaT20(itemSec, corDetalhe, corArmadura, materialEspecial) {
    if (!itemSec || itemSec === 'MAO_LIVRE') return '';
    const s = String(itemSec).toUpperCase();
    const pal = {
        '#': '#07040B',
        '1': corArmadura || '#334155',
        '2': ajustarTomHexT20(corArmadura || '#334155', -35),
        'D': corDetalhe || '#F59E0B',
        'W': '#FFFFFF',
        'S': '#CBD5E1',
        'C': '#38BDF8',
        'F': '#F97316',
        'R': '#991B1B',
        'L': '#78350F'
    };
    let mat = [
        ".DDDDDD.",
        "D11DD11D",
        "D1DDDD1D",
        "D11DD11D",
        ".D2222D.",
        "..DDDD.."
    ];
    if (s.includes('ORBE')) {
        mat = [
            "..CCCC..",
            ".CCWWCC.",
            ".CCCCCC.",
            "..DDDD.."
        ];
    } else if (s.includes('GRIMORIO') || s.includes('PERGAMINHO')) {
        mat = [
            ".DDDDDD.",
            "DRRWWWRD",
            "DRRDDDRD",
            "DRRWWWRD",
            ".DDDDDD."
        ];
    } else if (s.includes('SIMBOLO')) {
        mat = [
            "...DD...",
            ".DDDDDD.",
            "...DD...",
            "...DD..."
        ];
    } else if (s.includes('TOCHA')) {
        mat = [
            "..FWWF..",
            "..FFFF..",
            "...LL...",
            "...LL..."
        ];
    }
    return renderizarMatrizPixelArtSVG(mat, pal, 254, 206, 4.4, true);
}

function construirSpriteSVGHeroiJRPG(st) {
    const raca = (st && st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : 'humano';
    const classe = (st && st.classe && st.classe.nome) ? st.classe.nome.toLowerCase() : 'guerreiro';
    const arma = (st && st.arma && st.arma.nome) ? st.arma.nome.toLowerCase() : 'espada longa';
    const ehConj = (typeof ehConjuradorJS === 'function') ? ehConjuradorJS(st ? st.classe : null, st ? st.poderes : []) : false;

    const ehMembroMesa = Boolean(st && st.ehMembroPartyMesa);
    if (!ehMembroMesa) {
        sincronizarSeletoresAparenciaComRacaJS(raca, false);
    }
    const apGlobal = window.__APARENCIA_HEROI__ || {};
    const paletaRaca = obterPaletaRacialHeroiJS(raca);
    const corPele = (!ehMembroMesa && apGlobal.corPele) ? apGlobal.corPele : paletaRaca[0].cor;

    let corCabelo = (!ehMembroMesa && apGlobal.corCabelo) ? apGlobal.corCabelo : (
        raca.includes('elfo') || raca.includes('aggelus') ? '#EAB308' :
        (raca.includes('anão') ? '#92400E' :
        (raca.includes('dahllan') ? '#15803D' :
        (raca.includes('qareen') || raca.includes('sílfide') ? '#0284C7' :
        (raca.includes('lefou') || raca.includes('sulfure') ? '#991B1B' : '#18181B'))))
    );

    const modTraje = (!ehMembroMesa && apGlobal.estiloTraje && apGlobal.estiloTraje !== 'AUTO_CLASSE') ? apGlobal.estiloTraje.toLowerCase() : classe;
    const cMat = obterCoresMaterialEspecialT20(apGlobal.materialEspecial, apGlobal.efeitoArma);

    // Cores base por classe, mas SEMPRE respeitando a Paleta Heráldica e Material Especial escolhidos pelo usuário!
    let corArmadura = '#475569', corCapa = '#7F1D1D', corDetalhe = '#D97706';
    if (modTraje.includes('arcanista') || modTraje.includes('manto_arcano')) { corArmadura = '#312E81'; corCapa = '#581C87'; corDetalhe = '#FACC15'; }
    else if (modTraje.includes('paladino') || modTraje.includes('completa_ex4')) { corArmadura = '#E2E8F0'; corCapa = '#1D4ED8'; corDetalhe = '#FACC15'; }
    else if (modTraje.includes('cavaleiro') || modTraje.includes('placas')) { corArmadura = '#64748B'; corCapa = '#991B1B'; corDetalhe = '#F59E0B'; }
    else if (modTraje.includes('bárbaro') || modTraje.includes('peles')) { corArmadura = '#78350F'; corCapa = '#451A03'; corDetalhe = '#DC2626'; }
    else if (modTraje.includes('clérigo') || modTraje.includes('vestes_sagradas')) { corArmadura = '#CBD5E1'; corCapa = '#B45309'; corDetalhe = '#FDE047'; }
    else if (modTraje.includes('druida') || modTraje.includes('caçador')) { corArmadura = '#166534'; corCapa = '#3F6212'; corDetalhe = '#84CC16'; }
    else if (modTraje.includes('ladino') || modTraje.includes('furtivo')) { corArmadura = '#1E293B'; corCapa = '#090D16'; corDetalhe = '#A855F7'; }
    else if (modTraje.includes('bardo') || modTraje.includes('bucaneiro') || modTraje.includes('nobre') || modTraje.includes('corsario')) { corArmadura = '#881337'; corCapa = '#4C0519'; corDetalhe = '#FACC15'; }
    else if (modTraje.includes('inventor')) { corArmadura = '#7C2D12'; corCapa = '#1E3A8A'; corDetalhe = '#38BDF8'; }

    if (!ehMembroMesa && apGlobal.corTraje && apGlobal.corTraje.includes('|')) {
        const [cArmUser, cCapUser] = apGlobal.corTraje.split('|');
        if (window.__APARENCIA_CUSTOMIZADA_PELO_USUARIO__ || apGlobal.corTraje !== '#7F1D1D|#991B1B') {
            corArmadura = cArmUser;
            corCapa = cCapUser;
        }
    }
    if (!ehMembroMesa && apGlobal.materialEspecial && apGlobal.materialEspecial !== 'ACO_PADRAO') {
        corArmadura = cMat.metal2 || corArmadura;
        corDetalhe = cMat.metal1 || corDetalhe;
    }

    const ehOsteon = raca.includes('osteon');
    const ehGolem = raca.includes('golem');
    const ehMinotauro = raca.includes('minotauro');
    const ehAnão = raca.includes('anão');
    const ehGoblin = raca.includes('goblin');
    const ehTrog = raca.includes('trog');
    const ehElfoOuOrelha = raca.includes('elfo') || raca.includes('dahllan') || raca.includes('qareen') || raca.includes('sílfide') || raca.includes('kliren');
    const ehChifrudo = raca.includes('lefou') || raca.includes('sulfure');
    const ehMedusa = raca.includes('medusa');

    const cab = (!ehMembroMesa && (apGlobal.acessorioCabeca || apGlobal.estiloCabeca)) ? (apGlobal.acessorioCabeca || apGlobal.estiloCabeca) : 'RACIAL_CLASSICO';
    const penteadoSel = (!ehMembroMesa && apGlobal.penteado) ? apGlobal.penteado : 'HEROICO_CLASSICO';
    const expressaoSel = (!ehMembroMesa && apGlobal.expressao) ? apGlobal.expressao : 'DETERMINADO';
    const posturaSel = (!ehMembroMesa && apGlobal.postura) ? apGlobal.postura : 'HEROICA_CLASSICA';
    const costaSel = (!ehMembroMesa && apGlobal.capaCostas) ? apGlobal.capaCostas : 'CAPA_REAL';
    const ombreiraSel = (!ehMembroMesa && apGlobal.ombreiras) ? apGlobal.ombreiras : 'AUTO_TRAJE';

    // Matriz Base 30x28 sem capa (silhueta limpa) — as capas, asas, armaduras e ombreiras mudam a silhueta real!
    const grid = Array.from({ length: 28 }, () => Array(30).fill('.'));
    const writeRow = (y, xStart, str) => {
        if (y < 0 || y >= 28) return;
        for (let i = 0; i < str.length; i++) {
            const x = xStart + i;
            if (x >= 0 && x < 30 && str[i] !== '.') grid[y][x] = str[i];
        }
    };

    // 1. CAMADA DE TRÁS: SILHUETA DE CAPAS, ASAS, HALOS, MOCHILAS, ALJAVAS E ESTANDARTES
    if (costaSel === 'CAPA_REAL') {
        for (let y = 11; y <= 25; y++) {
            const w = Math.min(11, 6 + Math.floor((y - 11) * 0.4));
            for (let x = 15 - w; x < 15 + w; x++) grid[y][x] = (y === 25 || x === 15 - w || x === 15 + w - 1) ? 'D' : '4';
        }
    } else if (costaSel === 'CAPA_RASGADA') {
        for (let y = 11; y <= 25; y++) {
            const w = 6 + ((y * 3) % 5);
            for (let x = 15 - w; x < 15 + w; x++) {
                if (y >= 22 && (x + y) % 3 === 0) continue;
                grid[y][x] = '4';
            }
        }
    } else if (costaSel === 'MANTO_GOLA_ALTA') {
        writeRow(5, 8, "444........444");
        writeRow(6, 7, "44D44......44D44");
        writeRow(7, 7, "44444......44444");
        writeRow(8, 8, "4444......4444");
        for (let y = 10; y <= 25; y++) {
            for (let x = 5; x <= 24; x++) grid[y][x] = (x === 5 || x === 24) ? 'D' : '4';
        }
    } else if (costaSel === 'MANTO_PELE_INVERNO') {
        writeRow(8, 5, "LLLLLLLLLLLLLLLLLLLL");
        writeRow(9, 4, "WlLLLLLLLLLLLLLLLLLLlW");
        writeRow(10, 4, "LLLLLLLLLLLLLLLLLLLLLL");
        for (let y = 11; y <= 24; y++) {
            for (let x = 6; x <= 23; x++) grid[y][x] = (x + y) % 4 === 0 ? 'l' : 'L';
        }
    } else if (costaSel === 'ASAS_CELESTIAIS_DRACONICAS' || raca.includes('sílfide') || raca.includes('aggelus')) {
        writeRow(4, 1, "DDD....................DDD");
        writeRow(5, 0, "DWWWDD................DDWWWD");
        writeRow(6, 0, "WWWWWWDD............DDWWWWWW");
        writeRow(7, 0, "WWWWWWWWDD........DDWWWWWWWW");
        writeRow(8, 1, "WWWWWWWWWDD....DDWWWWWWWWW");
        writeRow(9, 1, ".WWWWWWWWWWDDDDWWWWWWWWWW.");
        writeRow(10, 2, ".WWWWWWWWWWWWWWWWWWWWWW.");
        writeRow(11, 2, "..WWWW..WWWWWWWW..WWWW..");
        writeRow(12, 3, "..WW....WWWWWW....WW..");
    } else if (costaSel === 'ASAS_MORCEGO_ABISSAL' || raca.includes('sulfure')) {
        writeRow(3, 2, "W........................W");
        writeRow(4, 1, "DDD......................DDD");
        writeRow(5, 0, "D444DD..................DD444D");
        writeRow(6, 0, "44D444DD..............DD444D44");
        writeRow(7, 0, "444D4444DD..........DD4444D444");
        writeRow(8, 1, "444D44444DD......DD44444D444");
        writeRow(9, 1, "4.44D445544DDDDDD445544D44.4");
        writeRow(10, 3, ".4.D455..444444..554D.4.");
    } else if (costaSel === 'HALO_DIVINO') {
        writeRow(1, 9, "DDDDDDDDDDDD");
        writeRow(2, 7, "DDYYYYYYYYYYYYDD");
        writeRow(3, 6, "DYY............YYD");
        writeRow(4, 5, "DY................YD");
        writeRow(5, 5, "DY................YD");
        writeRow(6, 5, "DY................YD");
        writeRow(7, 6, "DYY............YYD");
        writeRow(8, 7, "DDYYYYYYYYYYYYDD");
    } else if (costaSel === 'ESTANDARTE_GUERRA') {
        for (let y = 0; y <= 16; y++) grid[y][23] = 'D';
        writeRow(0, 17, "DDDDDDDD");
        writeRow(1, 17, "444DD444");
        writeRow(2, 17, "44DDDD44");
        writeRow(3, 17, "444DD444");
        writeRow(4, 18, "44..44");
    } else if (costaSel === 'MOCHILA_AVENTUREIRO' || costaSel === 'PROPULSOR_AETHER') {
        const chPack = costaSel === 'PROPULSOR_AETHER' ? 'S' : 'L';
        const chGlow = costaSel === 'PROPULSOR_AETHER' ? 'C' : 'F';
        for (let y = 9; y <= 17; y++) {
            grid[y][7] = chPack; grid[y][8] = chPack;
            grid[y][21] = chPack; grid[y][22] = chPack;
        }
        grid[7][7] = chGlow; grid[8][7] = chGlow;
        grid[7][22] = chGlow; grid[8][22] = chGlow;
    } else if (costaSel === 'ALJAVA_ARCO') {
        writeRow(5, 21, "WRW");
        writeRow(6, 20, ".LLL.");
        writeRow(7, 19, ".LLL.");
        writeRow(8, 19, "LLL.");
    }
    // Se costaSel === 'SEM_CAPA', nada é desenhado atrás: silhueta 100% aberta e limpa!

    // 2. SILHUETA DO TRONCO, ARMADURA E PERNAS (8 Silhuetas Distintas!)
    const ehPlacas = modTraje.includes('placas') || modTraje.includes('completa') || modTraje.includes('cavaleiro') || modTraje.includes('paladino');
    const ehBarbaroPeles = modTraje.includes('peles') || modTraje.includes('bárbaro');
    const ehFurtivoLeve = modTraje.includes('furtivo') || modTraje.includes('ladino') || modTraje.includes('couro') || modTraje.includes('acolchoada');
    const ehMantoArcano = modTraje.includes('manto') || modTraje.includes('arcanista');
    const ehVestesSagradas = modTraje.includes('vestes') || modTraje.includes('clérigo') || modTraje.includes('druida');
    const ehCasacoAberto = modTraje.includes('corsario') || modTraje.includes('bucaneiro') || modTraje.includes('nobre') || modTraje.includes('bardo') || modTraje.includes('inventor');

    if (ehMantoArcano) {
        // Silhueta Manto Longo de Arquimago com mangas largas em sino e saia até os pés
        writeRow(11, 9, "11111DD11111");
        writeRow(12, 8, "111331DD133111");
        writeRow(13, 7, "1111111DD1111111");
        writeRow(14, 6, "111KK111DD111KK111");
        writeRow(15, 6, "DDKK.111DD111.KKDD");
        writeRow(16, 10, "DDDDDDDDDD");
        for (let y = 17; y <= 24; y++) {
            const wR = 5 + Math.floor((y - 17) * 0.35);
            for (let x = 15 - wR; x < 15 + wR; x++) {
                grid[y][x] = (x === 14 || x === 15) ? 'D' : ((x === 15 - wR || x === 15 + wR - 1) ? '2' : '1');
            }
        }
        writeRow(25, 10, "LLLL..LLLL");
        writeRow(26, 10, "DDDD..DDDD");
    } else if (ehVestesSagradas) {
        // Silhueta Batina Clerical / Paladínica com Tabardo Sagrado Central
        writeRow(11, 9, "1111WWWW1111");
        writeRow(12, 8, "11331WDDW13311");
        writeRow(13, 8, "KK111WWWW111KK");
        writeRow(14, 8, "KK111WDDW111KK");
        writeRow(15, 8, "LL111WWWW111LL");
        writeRow(16, 10, "DDDDDDDDDD");
        for (let y = 17; y <= 23; y++) {
            writeRow(y, 10, "112WWWW211");
        }
        writeRow(24, 10, "222.DD.222");
        writeRow(25, 10, "LLL....LLL");
        writeRow(26, 9, "DDDD....DDDD");
    } else if (ehBarbaroPeles) {
        // Silhueta Bárbaro / Gladiador: Peito musculoso exposto com boldrié de couro e tanga de peles
        writeRow(11, 9, "LLKKKKKKKKLL");
        writeRow(12, 8, "KKKKKLLKKKKKKK");
        writeRow(13, 8, "KKKKKKLLKKKKKK");
        writeRow(14, 8, "KKKKKKkLLKKKKK");
        writeRow(15, 8, "LLKKKKkDLLKKLL");
        writeRow(16, 10, "DDDDDDDDDD");
        writeRow(17, 9, "LLLLDDDDLLLL");
        writeRow(18, 9, "LLL.LLLL.LLL");
        writeRow(19, 10, "KKK.LL.KKK");
        writeRow(20, 10, "KKk....kKK");
        writeRow(21, 10, "KKk....kKK");
        writeRow(22, 10, "LLL....LLL");
        writeRow(23, 10, "LLL....LLL");
        writeRow(24, 10, "lLL....LLl");
        writeRow(25, 9, "LLLL....LLLL");
        writeRow(26, 9, "DDDD....DDDD");
    } else if (ehFurtivoLeve) {
        // Silhueta Furtiva Esguia (Assassino / Ladino / Caçador)
        writeRow(11, 10, "1111DD1111");
        writeRow(12, 9, "113311113311");
        writeRow(13, 9, "KK111SS111KK");
        writeRow(14, 9, "KK11222211KK");
        writeRow(15, 9, "LL11222211LL");
        writeRow(16, 10, "LLDDDDDDLL");
        writeRow(17, 10, "1112222111");
        for (let y = 18; y <= 23; y++) {
            writeRow(y, 11, "112..211");
        }
        writeRow(24, 11, "LLL..LLL");
        writeRow(25, 10, "LLLL..LLLL");
        writeRow(26, 10, "2222..2222");
    } else if (ehCasacoAberto) {
        // Silhueta Casaco Longo de Abas Abertas (Bucaneiro / Nobre / Inventor)
        writeRow(11, 9, "111DDDDDD111");
        writeRow(12, 8, "11D11WWWW11D11");
        writeRow(13, 8, "KK111WWWW111KK");
        writeRow(14, 8, "KK11DWWWW1D1KK");
        writeRow(15, 8, "DD111WWWW111DD");
        writeRow(16, 10, "DDDDDDDDDD");
        for (let y = 17; y <= 22; y++) {
            writeRow(y, 8, "11D112..211D11");
        }
        writeRow(23, 8, "11..22..22..11");
        writeRow(24, 10, "LLL....LLL");
        writeRow(25, 9, "LLLL....LLLL");
        writeRow(26, 9, "DDDD....DDDD");
    } else if (ehPlacas) {
        // Silhueta Armadura Completa Gótica Pesada (Larga e Imponente)
        writeRow(11, 8, "111111DD111111");
        writeRow(12, 7, "1133311DD1133311");
        writeRow(13, 7, "111331DDDD133111");
        writeRow(14, 7, "1111111DD1111111");
        writeRow(15, 7, "SS22111DD11122SS");
        writeRow(16, 9, "DDDDDDDDDDDD");
        writeRow(17, 8, "1111DDDDDD1111");
        writeRow(18, 8, "111222..222111");
        for (let y = 19; y <= 23; y++) {
            writeRow(y, 9, y === 21 ? "DDDD....DDDD" : "1122....2211");
        }
        writeRow(24, 9, "SSSS....SSSS");
        writeRow(25, 8, "SSSSS....SSSSS");
        writeRow(26, 8, "DDDDD....DDDDD");
    } else {
        // Silhueta Padrão Marcial (Meia Armadura / Couraça / Cota de Malha)
        writeRow(11, 9, "11111DD11111");
        writeRow(12, 8, "113311DD113311");
        writeRow(13, 8, "KK1133DD3311KK");
        writeRow(14, 8, "KK1111111111KK");
        writeRow(15, 8, "LL1122222211LL");
        writeRow(16, 10, "DDDDDDDDDD");
        writeRow(17, 10, "111DDDD111");
        for (let y = 18; y <= 23; y++) {
            writeRow(y, 10, y === 21 ? "DDD....DDD" : "112....211");
        }
        writeRow(24, 10, "LLL....LLL");
        writeRow(25, 9, "LLLL....LLLL");
        writeRow(26, 9, "DDDD....DDDD");
    }

    // 3. SILHUETA DAS OMBREIRAS (Muda drasticamente a largura dos ombros!)
    if (ombreiraSel === 'OMBREIRAS_COLOSSAIS_ESPINHOS') {
        writeRow(8, 5, "W..................W");
        writeRow(9, 4, "WW..W............W..WW");
        writeRow(10, 4, "DDDDDD111DDDD111DDDDDD");
        writeRow(11, 3, "D111111111DDDD111111111D");
    } else if (ombreiraSel === 'OMBREIRAS_ALADAS_PALADINO') {
        writeRow(8, 3, "DDD..................DDD");
        writeRow(9, 4, "DWWDD..............DDWWD");
        writeRow(10, 5, "DWWWW111DDDD111WWWWD");
        writeRow(11, 6, "DDDD111DDDD111DDDD");
    } else if (ombreiraSel === 'OMBREIRAS_CRANIO_NECRO') {
        writeRow(9, 5, "WWWW............WWWW");
        writeRow(10, 4, "W#WW#W111DDDD111W#WW#W");
        writeRow(11, 5, "WWWW1111DDDD1111WWWW");
    } else if (ombreiraSel === 'OMBREIRAS_PELES_FERA') {
        writeRow(9, 5, "LLLL............LLLL");
        writeRow(10, 4, "LlWWlL111DDDD111LlWWlL");
        writeRow(11, 5, "LLLL1111DDDD1111LLLL");
    } else if (ombreiraSel === 'SEM_OMBREIRAS_LEVE') {
        writeRow(10, 10, "1111DD1111");
    } else if (ehPlacas) {
        writeRow(9, 6, "DDDD..........DDDD");
        writeRow(10, 5, "D1111D111DDDD111D1111D");
    } else {
        writeRow(10, 7, "DDD1111DD1111DDD");
    }

    // 4. CABEÇA, TRAÇOS RACIAIS, PENTEADOS, EXPRESSÕES E ELMOS/CHAPÉUS
    writeRow(2, 11, "HHHHHHHH");
    writeRow(3, 10, "HHHHHHHHHH");
    writeRow(4, 10, "HHKKKKKKHH");
    writeRow(5, 10, "HHKKEKKEHH");
    writeRow(6, 10, "HHKKWKKWHH");
    writeRow(7, 11, "KKKKKKKK");
    writeRow(8, 12, "KKKKKK");
    writeRow(9, 13, "kkkk");

    // Traços raciais na cabeça
    if (ehMinotauro) {
        writeRow(1, 6, "WW..............WW");
        writeRow(2, 5, "WWD...HHHHHHHH...DWW");
        writeRow(3, 6, "DDD.HHHHHHHHHH.DDD");
        writeRow(7, 11, "KKkkkkKK");
        writeRow(8, 11, "kkWWkkWW");
    } else if (ehChifrudo) {
        writeRow(0, 8, "DD..........DD");
        writeRow(1, 9, "DD........DD");
        writeRow(2, 10, "DHHHHHHHHD");
    } else if (ehMedusa) {
        writeRow(1, 8, "GG.GG.GG.GG.GG");
        writeRow(2, 7, "GGGGGGGGGGGGGGGG");
        writeRow(3, 7, "GGYGHHHHHHHHGYGG");
    } else if (ehElfoOuOrelha || ehGoblin) {
        writeRow(5, 7, "KKKKKKEKKEKKKKKK");
        writeRow(6, 8, "KKKKKWKKWKKKKK");
    } else if (ehTrog) {
        writeRow(0, 13, "DDDD");
        writeRow(1, 12, "DDDDDD");
    } else if (ehOsteon) {
        writeRow(2, 11, "WWWWWWWW");
        writeRow(3, 10, "WWWWWWWWWW");
        writeRow(4, 10, "WWWWWWWWWW");
        writeRow(5, 10, "WWWEEWWEEW");
        writeRow(6, 10, "WWWWWWWWWW");
        writeRow(7, 11, "WWW##WWW");
        writeRow(8, 12, "W#W#W#");
    } else if (ehGolem) {
        writeRow(2, 11, "DDDDDDDD");
        writeRow(3, 10, "SSSSSSSSSS");
        writeRow(4, 10, "SSDDDDDDSS");
        writeRow(5, 10, "SSEEEEEESS");
        writeRow(6, 10, "SSSSSSSSSS");
        writeRow(7, 11, "SSddddSS");
    }

    // Penteados
    if (penteadoSel === 'MOICANO_SELVAGEM' && cab === 'RACIAL_CLASSICO') {
        writeRow(0, 13, "HHHH");
        writeRow(1, 12, "HHHHHH");
    } else if (penteadoSel === 'SAMURAI_COQUE' && cab === 'RACIAL_CLASSICO') {
        writeRow(0, 13, "DDDD");
        writeRow(1, 12, "HHHHHH");
    } else if (penteadoSel === 'LONGO_ESVOACANTE' || penteadoSel === 'TRANCAS_GUERRA') {
        writeRow(7, 9, "HHKKKKKKKKHH");
        writeRow(8, 9, "HH.KKKKKK.HH");
        writeRow(9, 9, "HH..kkkk..HH");
    } else if (penteadoSel === 'MONGE_TATUADO' && cab === 'RACIAL_CLASSICO' && !ehOsteon && !ehGolem) {
        writeRow(2, 11, "KKKKKKKK");
        writeRow(3, 10, "KKKKDDKKKK");
    }

    // Elmos, Chapéus, Capuzes, Galhadas e Coroas (Mudam a silhueta superior!)
    if (cab.includes('CHAPEU_ARCANO')) {
        writeRow(0, 13, "4444");
        writeRow(1, 11, "44444444");
        writeRow(2, 9, "4444DDDD4444");
        writeRow(3, 5, "DDDDDDDDDDDDDDDDDDDD");
    } else if (cab.includes('CHAPEU_TRICORNE') || cab.includes('CHAPEU_BARDO') || cab.includes('CHAPEU_CACADOR')) {
        writeRow(0, 17, "RRRR");
        writeRow(1, 9, "4444444444RR");
        writeRow(2, 6, "DDDDDDDDDDDDDDDDDD");
    } else if (cab.includes('ELMO_VALQUIRIA')) {
        writeRow(0, 7, "WW..............WW");
        writeRow(1, 7, "WWD...DDDDDD...DWW");
        writeRow(2, 8, "WW..SSSSSSSS..WW");
        writeRow(3, 10, "SSSDDDDSSS");
    } else if (cab.includes('ELMO_GLADIADOR')) {
        writeRow(0, 12, "RRRRRR");
        writeRow(1, 11, "RRRRRRRR");
        writeRow(2, 10, "SSSSSSSSSS");
        writeRow(3, 10, "SSSDDDDSSS");
    } else if (cab.includes('ELMO')) {
        writeRow(1, 12, "DDDDDD");
        writeRow(2, 10, "SSSSSSSSSS");
        writeRow(3, 10, "SSSDDDDSSS");
        writeRow(4, 10, "SSSKKKKSSS");
    } else if (cab.includes('COROA_CHIFRES_DRUIDA')) {
        writeRow(0, 6, "LL....LL......LL....LL");
        writeRow(1, 7, "LLLLLL........LLLLLL");
        writeRow(2, 9, "LLL.HHHHHHHH.LLL");
    } else if (cab.includes('COROA') || cab.includes('TIARA') || cab.includes('DIADEMA') || cab.includes('LAUREL')) {
        writeRow(1, 10, "D.DD..DD.D");
        writeRow(2, 10, "DDDDDDDDDD");
    } else if (cab.includes('CAPUZ') || cab.includes('MASCARA')) {
        writeRow(1, 12, "444444");
        writeRow(2, 10, "4444444444");
        writeRow(3, 9, "444HHHHHH444");
        writeRow(4, 9, "44HKKKKKKH44");
        if (cab.includes('MASCARA')) {
            writeRow(7, 11, "44444444");
            writeRow(8, 12, "444444");
        }
    }

    // Barba Anã
    if (ehAnão) {
        writeRow(7, 10, "HHHHHHHHHH");
        writeRow(8, 10, "HHHHHHHHHH");
        writeRow(9, 10, "HHHHHHHHHH");
        writeRow(10, 11, "HHHHHHHH");
        writeRow(11, 12, "HHHHHH");
    }

    // Expressões
    if (expressaoSel === 'CICATRIZ_VETERANA' && !ehOsteon && !ehGolem) {
        grid[4][16] = 'R'; grid[7][16] = 'R';
    } else if (expressaoSel === 'TAPA_OLHO_CORSARIO') {
        grid[5][16] = '#'; grid[6][16] = '#';
    } else if (expressaoSel === 'MARCA_TORMENTA') {
        grid[4][14] = 'R'; grid[4][15] = 'R';
    } else if (expressaoSel === 'SORRISO_AUDACIOSO' && !ehOsteon && !ehGolem) {
        writeRow(7, 13, "WWWW");
    }

    // ALONGAMENTO ANATÔMICO DO TORSO DO HERÓI (v63):
    // Expande verticalmente as linhas do peitoral, costelas e abdômen/cintura (linhas 11..16 -> +6 linhas de tronco)
    // garantindo proporção heróica de 16-bit/32-bit sem jamais deixar o torso achatado!
    const gridTorsoProporcional = [];
    for (let y = 0; y < grid.length; y++) {
        gridTorsoProporcional.push(grid[y].slice());
        // Duplica de forma anatômica as linhas de peitoral superior (11, 12), peitoral médio (13), abdômen (14, 15) e quadril (17)
        if (y === 11 || y === 12 || y === 13 || y === 14 || y === 15 || y === 17) {
            gridTorsoProporcional.push(grid[y].slice());
        }
    }
    const matFinal = gridTorsoProporcional.map(r => r.join(''));
    const corOlho = (expressaoSel === 'OLHOS_INCANDESCENTES') ? '#FEF08A' : ((ehOsteon || ehGolem) ? '#38BDF8' : (ehChifrudo || ehMinotauro ? '#EF4444' : '#38BDF8'));
    const palHeroi = criarPaletaPixelArtPadraoT20(corArmadura, corCapa, corDetalhe, corOlho, ehOsteon ? '#F8FAFC' : corPele, corCabelo);
    const escalaRaca = (ehAnão || ehGoblin) ? 3.45 : (ehMinotauro || ehGolem || posturaSel === 'COLOSSO_IMPONENTE' ? 4.10 : 3.80);

    const uid = gerarUidUnicoSVGT20('hr');
    const classeRotulo = (st && st.classe && st.classe.nome) ? st.classe.nome.slice(0, 9).toUpperCase() : 'HERÓI';
    const baseMiniatura = construirBaseMiniaturaRPGDeMesaSVG(216, 260, 46, 11, corDetalhe, uid, false, classeRotulo);

    const montariaGlobal = (!ehMembroMesa && window.__MONTARIA_ATIVA_ARENA__) ? window.__MONTARIA_ATIVA_ARENA__ : ((st && st.montaria) || 'NENHUMA');
    const patMontaria = (!ehMembroMesa && window.__PATAMAR_MONTARIA_ARENA__) ? window.__PATAMAR_MONTARIA_ARENA__ : 'INICIANTE';
    const parceiroGlobal = (!ehMembroMesa && window.__PARCEIRO_ATIVO_ARENA__) ? window.__PARCEIRO_ATIVO_ARENA__ : ((st && st.parceiro) || 'NENHUM');
    const patParceiro = (!ehMembroMesa && window.__PATAMAR_PARCEIRO_ARENA__) ? window.__PATAMAR_PARCEIRO_ARENA__ : 'INICIANTE';

    const svgMontaria = construirSVGMontariaDarkFantasyT20(montariaGlobal, patMontaria, uid);
    const svgParceiro = construirSVGParceiroDarkFantasyT20(parceiroGlobal, patParceiro, uid);
    const dyPostura = posturaSel === 'CONJURACAO_ARCANA' ? -10 : 0;
    const dyMontado = ((montariaGlobal && montariaGlobal !== 'NENHUMA') ? -18 : 0) + dyPostura;
    const rotPostura = posturaSel === 'GUARDA_OFENSIVA' ? 'rotate(5 216 220)' : (posturaSel === 'DUELISTA_AGIL' ? 'rotate(-5 216 220)' : '');

    const maoSec = (!ehMembroMesa && apGlobal.maoSecundaria && apGlobal.maoSecundaria !== 'AUTO_FICHA')
        ? apGlobal.maoSecundaria
        : ((st && st.escudo && st.escudo.nome && st.escudo.nome !== 'Nenhum') ? 'ESCUDO_PESADO' : (ehConj ? 'ORBE_CRISTAL' : 'MAO_LIVRE'));

    const pixelHeroi = renderizarMatrizPixelArtSVG(matFinal, palHeroi, 216, 255, escalaRaca, true, true);
    const pixelArma = construirSVGArsenaisT20(arma, ehConj, corDetalhe, apGlobal.efeitoArma, apGlobal.materialEspecial, apGlobal.armaExemplar);
    const pixelOffhand = construirSVGMaoSecundariaT20(maoSec, corDetalhe, corArmadura, apGlobal.materialEspecial);
    const auraPixelSVG = construirAuraParticulasPixelArtSVG(apGlobal.auraParticulas || (ehConj ? 'LUZ_DIVINA' : 'NENHUMA'), 216, 185);

    return `
        <g id="jrpg-hero-sprite-group" class="jrpg-sprite-idle" shape-rendering="crispEdges">
            ${baseMiniatura}
            ${svgParceiro}
            <g transform="translate(0, ${dyMontado}) ${rotPostura}">
                ${auraPixelSVG}
                ${pixelHeroi}
                ${pixelOffhand}
                ${pixelArma}
            </g>
            ${svgMontaria}
        </g>
    `;
}

// =============================================================================
// CATÁLOGO VISUAL ÚNICO DAS 83 AMEAÇAS DO CAPÍTULO 7 + 25 MATRIZES PIXEL ART
// =============================================================================
const CATALOGO_VISUAL_83_AMEACAS_T20 = [
    // MASMORRAS & CONSTRUTOS
    { match: 'glop', rotuloCurto: 'GLOP', molde: 'SLIME', cor1: '#65A30D', cor2: '#365314', corDet: '#D9F99D', corOlho: '#FEF08A', corFundo: '#1A2E05', corAnel: '#84CC16', var: 'ACIDO_CRANIO', viewBoxToken: '555 82 180 175' },
    { match: 'rato gigante', rotuloCurto: 'RATO GIG.', molde: 'FERA_QUAD', cor1: '#57534E', cor2: '#292524', corDet: '#FDA4AF', corOlho: '#EF4444', corFundo: '#1C1917', corAnel: '#FB7185', var: 'RATO', viewBoxToken: '555 82 180 175' },
    { match: 'aranha gigante', rotuloCurto: 'ARANHA', molde: 'ARACNIDEO', cor1: '#3B0764', cor2: '#0F172A', corDet: '#DC2626', corOlho: '#22C55E', corFundo: '#1E1B4B', corAnel: '#A855F7', var: 'VIUVA_NEGRA', viewBoxToken: '555 82 180 175' },
    { match: 'centopeia-dragão', rotuloCurto: 'CENTOPEIA', molde: 'CENTOPEIA', cor1: '#B91C1C', cor2: '#450A0A', corDet: '#F59E0B', corOlho: '#FEF08A', corFundo: '#3B070B', corAnel: '#F97316', var: 'FOGO', viewBoxToken: '555 82 180 175' },
    { match: 'gárgula', rotuloCurto: 'GÁRGULA', molde: 'DEMONIO_ALADO', cor1: '#64748B', cor2: '#334155', corDet: '#94A3B8', corOlho: '#FACC15', corFundo: '#0F172A', corAnel: '#94A3B8', var: 'PEDRA', viewBoxToken: '555 82 180 175' },
    { match: 'guerreiro de chifres', rotuloCurto: 'G. CHIFRES', molde: 'DEMONIO_ALADO', cor1: '#991B1B', cor2: '#450A0A', corDet: '#EA580C', corOlho: '#FEF08A', corFundo: '#3B070B', corAnel: '#EF4444', var: 'ABISSAL', viewBoxToken: '555 82 180 175' },
    { match: 'mantícora', rotuloCurto: 'MANTÍCORA', molde: 'MANTICORA', cor1: '#B45309', cor2: '#7F1D1D', corDet: '#F59E0B', corOlho: '#EF4444', corFundo: '#291B12', corAnel: '#F97316', var: 'MANTICORA', viewBoxToken: '555 82 180 175' },
    { match: 'golem de ferro', rotuloCurto: 'GOLEM FER.', molde: 'COLOSSO_MECHA', cor1: '#64748B', cor2: '#1E293B', corDet: '#EA580C', corOlho: '#22C55E', corFundo: '#090D16', corAnel: '#38BDF8', var: 'GOLEM_GAS', viewBoxToken: '555 82 180 175' },

    // ERMOS, BANDIDOS, GUARDAS, FERAS E GIGANTES
    { match: 'chefe bandido', rotuloCurto: 'CH. BANDIDO', molde: 'HUMANOIDE', cor1: '#7F1D1D', cor2: '#1C1917', corDet: '#D97706', corOlho: '#F59E0B', corFundo: '#2A0408', corAnel: '#F59E0B', var: 'CHEFE_BANDIDO', viewBoxToken: '555 82 180 175' },
    { match: 'bandido', rotuloCurto: 'BANDIDO', molde: 'HUMANOIDE', cor1: '#78350F', cor2: '#291B12', corDet: '#A8A29E', corOlho: '#FBBF24', corFundo: '#1C1917', corAnel: '#D97706', var: 'BANDIDO_CAPUZ', viewBoxToken: '555 82 180 175' },
    { match: 'sargento da guarda', rotuloCurto: 'SARGENTO', molde: 'HUMANOIDE', cor1: '#1E40AF', cor2: '#94A3B8', corDet: '#FACC15', corOlho: '#38BDF8', corFundo: '#0F172A', corAnel: '#FACC15', var: 'SARGENTO_PLUMA', viewBoxToken: '555 82 180 175' },
    { match: 'guarda de cidade', rotuloCurto: 'GUARDA', molde: 'HUMANOIDE', cor1: '#1D4ED8', cor2: '#64748B', corDet: '#E2E8F0', corOlho: '#60A5FA', corFundo: '#172554', corAnel: '#38BDF8', var: 'GUARDA_ELMO', viewBoxToken: '555 82 180 175' },
    { match: 'gnoll filibusteiro', rotuloCurto: 'FILIBUST.', molde: 'GNOLL', cor1: '#92400E', cor2: '#7F1D1D', corDet: '#FACC15', corOlho: '#EF4444', corFundo: '#291B12', corAnel: '#FACC15', var: 'PIRATA_TRICORNE', viewBoxToken: '555 82 180 175' },
    { match: 'gnoll', rotuloCurto: 'GNOLL', molde: 'GNOLL', cor1: '#B45309', cor2: '#451A03', corDet: '#E7E5E4', corOlho: '#FACC15', corFundo: '#291B12', corAnel: '#F59E0B', var: 'SELVAGEM_LANCA', viewBoxToken: '555 82 180 175' },
    { match: 'lobo-das-cavernas', rotuloCurto: 'LOBO CAV.', molde: 'FERA_QUAD', cor1: '#334155', cor2: '#0F172A', corDet: '#94A3B8', corOlho: '#38BDF8', corFundo: '#090D16', corAnel: '#38BDF8', var: 'LOBO_GIGANTE', viewBoxToken: '555 82 180 175' },
    { match: 'cão do inferno', rotuloCurto: 'CÃO INF.', molde: 'FERA_QUAD', cor1: '#991B1B', cor2: '#450A0A', corDet: '#EA580C', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#F97316', var: 'CAO_MAGMA', viewBoxToken: '555 82 180 175' },
    { match: 'lobo', rotuloCurto: 'LOBO', molde: 'FERA_QUAD', cor1: '#64748B', cor2: '#1E293B', corDet: '#CBD5E1', corOlho: '#FACC15', corFundo: '#0F172A', corAnel: '#94A3B8', var: 'LOBO_COMUM', viewBoxToken: '555 82 180 175' },
    { match: 'centauro xamã', rotuloCurto: 'XAMÃ', molde: 'CENTAURO', cor1: '#15803D', cor2: '#78350F', corDet: '#4ADE80', corOlho: '#FEF08A', corFundo: '#052E16', corAnel: '#4ADE80', var: 'XAMA_GALHOS', viewBoxToken: '555 82 180 175' },
    { match: 'centauro', rotuloCurto: 'CENTAURO', molde: 'CENTAURO', cor1: '#92400E', cor2: '#451A03', corDet: '#D97706', corOlho: '#F97316', corFundo: '#291B12', corAnel: '#F59E0B', var: 'ARQUEIRO', viewBoxToken: '555 82 180 175' },
    { match: 'gorlogg', rotuloCurto: 'GORLOGG', molde: 'SAURIO', cor1: '#15803D', cor2: '#052E16', corDet: '#EAB308', corOlho: '#EF4444', corFundo: '#052E16', corAnel: '#4ADE80', var: 'DINO_CRISTA', viewBoxToken: '555 82 180 175' },
    { match: 'basilisco', rotuloCurto: 'BASILISCO', molde: 'SAURIO', cor1: '#0F766E', cor2: '#134E4A', corDet: '#38BDF8', corOlho: '#67E8F9', corFundo: '#042F2E', corAnel: '#2DD4BF', var: 'OITO_PATAS_CRISTAL', viewBoxToken: '555 82 180 175' },
    { match: 'trog', rotuloCurto: 'TROG', molde: 'SAURIO', cor1: '#4D7C0F', cor2: '#1A2E05', corDet: '#EA580C', corOlho: '#FEF08A', corFundo: '#1A2E05', corAnel: '#84CC16', var: 'TROG_MACHADO', viewBoxToken: '555 82 180 175' },
    { match: 'grifo', rotuloCurto: 'GRIFO', molde: 'GRIFO', cor1: '#D97706', cor2: '#F8FAFC', corDet: '#FACC15', corOlho: '#F59E0B', corFundo: '#0F172A', corAnel: '#FACC15', var: 'GRIFO_AGUIA', viewBoxToken: '555 82 180 175' },
    { match: 'urso-coruja', rotuloCurto: 'URSO-COR.', molde: 'URSO_CORUJA', cor1: '#78350F', cor2: '#451A03', corDet: '#FDE68A', corOlho: '#FACC15', corFundo: '#291B12', corAnel: '#F59E0B', var: 'URSO_CORUJA', viewBoxToken: '555 82 180 175' },
    { match: 'wyvern', rotuloCurto: 'WYVERN', molde: 'WYVERN', cor1: '#15803D', cor2: '#166534', corDet: '#84CC16', corOlho: '#FEF08A', corFundo: '#052E16', corAnel: '#22C55E', var: 'WYVERN_FERRAO', viewBoxToken: '555 82 180 175' },
    { match: 'ogro', rotuloCurto: 'OGRO', molde: 'TROLL_GIGANTE', cor1: '#B45309', cor2: '#78350F', corDet: '#E7E5E4', corOlho: '#EF4444', corFundo: '#291B12', corAnel: '#F97316', var: 'OGRO_TACAPE', viewBoxToken: '555 82 180 175' },

    // SUPREMACIA PURISTA
    { match: 'recruta purista', rotuloCurto: 'RECRUTA', molde: 'HUMANOIDE', cor1: '#64748B', cor2: '#7F1D1D', corDet: '#CBD5E1', corOlho: '#F87171', corFundo: '#1E293B', corAnel: '#EF4444', var: 'PURISTA_ALABARDA', viewBoxToken: '555 82 180 175' },
    { match: 'soldado purista', rotuloCurto: 'SOLDADO P.', molde: 'HUMANOIDE', cor1: '#475569', cor2: '#991B1B', corDet: '#E2E8F0', corOlho: '#EF4444', corFundo: '#0F172A', corAnel: '#DC2626', var: 'PURISTA_ESCUDO', viewBoxToken: '555 82 180 175' },
    { match: 'sargento-mor', rotuloCurto: 'SARG.-MOR', molde: 'HUMANOIDE', cor1: '#334155', cor2: '#B91C1C', corDet: '#F59E0B', corOlho: '#FACC15', corFundo: '#1E1B4B', corAnel: '#F59E0B', var: 'PURISTA_CRISTA', viewBoxToken: '555 82 180 175' },
    { match: 'capelão de guerra', rotuloCurto: 'CAPELÃO', molde: 'HUMANOIDE', cor1: '#7F1D1D', cor2: '#1E293B', corDet: '#FACC15', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#FACC15', var: 'CAPELAO_MARTELO', viewBoxToken: '555 82 180 175' },
    { match: 'capitão-baluarte', rotuloCurto: 'BALUARTE', molde: 'HUMANOIDE', cor1: '#94A3B8', cor2: '#7F1D1D', corDet: '#FACC15', corOlho: '#38BDF8', corFundo: '#0F172A', corAnel: '#FACC15', var: 'BALUARTE_TORRE', viewBoxToken: '555 82 180 175' },
    { match: 'cavaleiro do leopardo negro', rotuloCurto: 'LEOPARDO', molde: 'HUMANOIDE', cor1: '#18181B', cor2: '#581C87', corDet: '#C084FC', corOlho: '#E879F9', corFundo: '#090D16', corAnel: '#A855F7', var: 'LEOPARDO_MAGICO', viewBoxToken: '555 82 180 175' },
    { match: 'colosso supremo', rotuloCurto: 'COLOSSO', molde: 'COLOSSO_MECHA', cor1: '#991B1B', cor2: '#334155', corDet: '#FACC15', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#F59E0B', var: 'COLOSSO_FORNALHA', viewBoxToken: '555 82 180 175' },

    // REINO DOS MORTOS (ASLOTHIA)
    { match: 'turba de zumbis', rotuloCurto: 'TURBA Z.', molde: 'MORTO_VIVO', cor1: '#4D7C0F', cor2: '#365314', corDet: '#A3E635', corOlho: '#BEF264', corFundo: '#1A2E05', corAnel: '#84CC16', var: 'TURBA_ZUMBIS', viewBoxToken: '555 82 180 175' },
    { match: 'zumbi', rotuloCurto: 'ZUMBI', molde: 'MORTO_VIVO', cor1: '#65A30D', cor2: '#3F6212', corDet: '#991B1B', corOlho: '#A3E635', corFundo: '#1A2E05', corAnel: '#84CC16', var: 'ZUMBI_PODRE', viewBoxToken: '555 82 180 175' },
    { match: 'esqueleto de elite', rotuloCurto: 'ESQ. ELITE', molde: 'MORTO_VIVO', cor1: '#F8FAFC', cor2: '#581C87', corDet: '#FACC15', corOlho: '#38BDF8', corFundo: '#1E1B4B', corAnel: '#38BDF8', var: 'ESQUELETO_REI', viewBoxToken: '555 82 180 175' },
    { match: 'esqueleto', rotuloCurto: 'ESQUELETO', molde: 'MORTO_VIVO', cor1: '#E2E8F0', cor2: '#334155', corDet: '#94A3B8', corOlho: '#22D3EE', corFundo: '#0F172A', corAnel: '#22D3EE', var: 'ESQUELETO_COMUM', viewBoxToken: '555 82 180 175' },
    { match: 'falange', rotuloCurto: 'FALANGE', molde: 'MORTO_VIVO', cor1: '#CBD5E1', cor2: '#7F1D1D', corDet: '#D97706', corOlho: '#38BDF8', corFundo: '#1E1B4B', corAnel: '#F59E0B', var: 'FALANGE_ESQUELETOS', viewBoxToken: '555 82 180 175' },
    { match: 'necromante veterano', rotuloCurto: 'NECRO VET.', molde: 'NECRO_VAMP', cor1: '#581C87', cor2: '#1E1B4B', corDet: '#C084FC', corOlho: '#E879F9', corFundo: '#1E1B4B', corAnel: '#C084FC', var: 'ARQUINECROMANTE', viewBoxToken: '555 82 180 175' },
    { match: 'necromante', rotuloCurto: 'NECROMANTE', molde: 'NECRO_VAMP', cor1: '#3B0764', cor2: '#090D16', corDet: '#22C55E', corOlho: '#4ADE80', corFundo: '#052E16', corAnel: '#22C55E', var: 'NECRO_FOICE', viewBoxToken: '555 82 180 175' },
    { match: 'aparição', rotuloCurto: 'APARIÇÃO', molde: 'NECRO_VAMP', cor1: '#0EA5E9', cor2: '#1E3A8A', corDet: '#E0F2FE', corOlho: '#FFFFFF', corFundo: '#082F49', corAnel: '#38BDF8', var: 'ESPECTRO_FLUTUANTE', viewBoxToken: '555 82 180 175' },
    { match: 'vampiro', rotuloCurto: 'VAMPIRO', molde: 'NECRO_VAMP', cor1: '#991B1B', cor2: '#090D16', corDet: '#FACC15', corOlho: '#EF4444', corFundo: '#2A0408', corAnel: '#DC2626', var: 'LORDE_VAMPIRO', viewBoxToken: '555 82 180 175' },

    // DUYSHIDAKK (GOBLINOIDES)
    { match: 'goblin engenhoqueiro', rotuloCurto: 'ENGENHOQ.', molde: 'GOBLIN', cor1: '#16A34A', cor2: '#7C2D12', corDet: '#38BDF8', corOlho: '#FEF08A', corFundo: '#052E16', corAnel: '#38BDF8', var: 'GOBLIN_STEAMPUNK', viewBoxToken: '555 82 180 175' },
    { match: 'goblin salteador', rotuloCurto: 'GOBLIN', molde: 'GOBLIN', cor1: '#15803D', cor2: '#451A03', corDet: '#EAB308', corOlho: '#FACC15', corFundo: '#052E16', corAnel: '#4ADE80', var: 'GOBLIN_ADAGAS', viewBoxToken: '555 82 180 175' },
    { match: 'engenho de guerra goblin', rotuloCurto: 'ENGENHO', molde: 'ENGENHO_GUERRA', cor1: '#92400E', cor2: '#334155', corDet: '#F97316', corOlho: '#38BDF8', corFundo: '#291B12', corAnel: '#F59E0B', var: 'TANQUE_GOBLIN', viewBoxToken: '555 82 180 175' },
    { match: 'hobgoblin mago de batalha', rotuloCurto: 'HOB. MAGO', molde: 'GOBLIN', cor1: '#B91C1C', cor2: '#312E81', corDet: '#F97316', corOlho: '#FEF08A', corFundo: '#1E1B4B', corAnel: '#F97316', var: 'HOB_ARCANE', viewBoxToken: '555 82 180 175' },
    { match: 'hobgoblin soldado', rotuloCurto: 'HOBGOBLIN', molde: 'GOBLIN', cor1: '#9A3412', cor2: '#334155', corDet: '#CBD5E1', corOlho: '#FACC15', corFundo: '#291B12', corAnel: '#F97316', var: 'HOB_SOLDADO', viewBoxToken: '555 82 180 175' },
    { match: 'arauto do deus dos goblinoides', rotuloCurto: 'ARAUTO', molde: 'GOBLIN', cor1: '#7F1D1D', cor2: '#090D16', corDet: '#EF4444', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#EF4444', var: 'ARAUTO_THWOR', viewBoxToken: '555 82 180 175' },
    { match: 'devorador de medos', rotuloCurto: 'DEVORADOR', molde: 'TROLL_GIGANTE', cor1: '#573B26', cor2: '#3B0764', corDet: '#A855F7', corOlho: '#E879F9', corFundo: '#1E1B4B', corAnel: '#C084FC', var: 'BUGBEAR_TERROR', viewBoxToken: '555 82 180 175' },
    { match: 'sombra do deus dos goblinoides', rotuloCurto: 'SOMBRA', molde: 'GOBLIN', cor1: '#1E293B', cor2: '#090D16', corDet: '#A855F7', corOlho: '#F43F5E', corFundo: '#090D16', corAnel: '#A855F7', var: 'ASSASSINO_DUYSHIDAKK', viewBoxToken: '555 82 180 175' },

    // CULTISTAS DA TRAIÇÃO (SSZZAAS)
    { match: 'cascavel', rotuloCurto: 'CASCAVEL', molde: 'SERPENTE', cor1: '#A16207', cor2: '#451A03', corDet: '#FDE047', corOlho: '#EF4444', corFundo: '#291B12', corAnel: '#EAB308', var: 'CASCAVEL_GUIZO', viewBoxToken: '555 82 180 175' },
    { match: 'jiboia', rotuloCurto: 'JIBOIA', molde: 'SERPENTE', cor1: '#4D7C0F', cor2: '#1A2E05', corDet: '#D97706', corOlho: '#FACC15', corFundo: '#1A2E05', corAnel: '#84CC16', var: 'JIBOIA_CONSTRITORA', viewBoxToken: '555 82 180 175' },
    { match: 'naja', rotuloCurto: 'NAJA', molde: 'SERPENTE', cor1: '#047857', cor2: '#022C22', corDet: '#A855F7', corOlho: '#4ADE80', corFundo: '#022C22', corAnel: '#10B981', var: 'NAJA_CAPELO', viewBoxToken: '555 82 180 175' },
    { match: 'sucuri', rotuloCurto: 'SUCURI', molde: 'SERPENTE', cor1: '#15803D', cor2: '#052E16', corDet: '#FACC15', corOlho: '#BEF264', corFundo: '#052E16', corAnel: '#22C55E', var: 'SUCURI_GIGANTE', viewBoxToken: '555 82 180 175' },
    { match: 'nagah mística', rotuloCurto: 'NAGAH MÍS.', molde: 'NAGAH', cor1: '#0D9488', cor2: '#581C87', corDet: '#FACC15', corOlho: '#E879F9', corFundo: '#1E1B4B', corAnel: '#2DD4BF', var: 'NAGAH_ARCANISTA', viewBoxToken: '555 82 180 175' },
    { match: 'nagah guardião', rotuloCurto: 'NAGAH G.', molde: 'NAGAH', cor1: '#166534', cor2: '#B45309', corDet: '#E2E8F0', corOlho: '#FACC15', corFundo: '#052E16', corAnel: '#4ADE80', var: 'NAGAH_CIMITARRAS', viewBoxToken: '555 82 180 175' },
    { match: 'cultista da traição', rotuloCurto: 'CULTISTA', molde: 'HUMANOIDE', cor1: '#065F46', cor2: '#1E1B4B', corDet: '#22C55E', corOlho: '#4ADE80', corFundo: '#022C22', corAnel: '#22C55E', var: 'MEDUSA_SSZZAAS', viewBoxToken: '555 82 180 175' },
    { match: 'hidra', rotuloCurto: 'HIDRA', molde: 'POLICEFALO', cor1: '#0F766E', cor2: '#042F2E', corDet: '#4ADE80', corOlho: '#FEF08A', corFundo: '#042F2E', corAnel: '#14B8A6', var: 'HIDRA_5CABECAS', viewBoxToken: '555 82 180 175' },
    { match: 'lagash', rotuloCurto: 'LAGASH', molde: 'POLICEFALO', cor1: '#047857', cor2: '#3B0764', corDet: '#A3E635', corOlho: '#EF4444', corFundo: '#022C22', corAnel: '#A3E635', var: 'LAGASH_2CABECAS_ASAS', viewBoxToken: '555 82 180 175' },

    // TROLLS NOBRES (FINNTROLL) & GIGANTES SUBTERRÂNEOS
    { match: 'finntroll feitor', rotuloCurto: 'FEITOR', molde: 'HUMANOIDE', cor1: '#581C87', cor2: '#1E293B', corDet: '#22C55E', corOlho: '#A855F7', corFundo: '#1E1B4B', corAnel: '#A855F7', var: 'FINNTROLL_CHICOTE', viewBoxToken: '555 82 180 175' },
    { match: 'finntroll caçador', rotuloCurto: 'FINNTROLL', molde: 'HUMANOIDE', cor1: '#334155', cor2: '#064E3B', corDet: '#34D399', corOlho: '#4ADE80', corFundo: '#0F172A', corAnel: '#34D399', var: 'FINNTROLL_BESTA', viewBoxToken: '555 82 180 175' },
    { match: 'ganchador', rotuloCurto: 'GANCHADOR', molde: 'TROLL_GIGANTE', cor1: '#475569', cor2: '#1E1B4B', corDet: '#E2E8F0', corOlho: '#FACC15', corFundo: '#0F172A', corAnel: '#38BDF8', var: 'GANCHADOR_GARRAS', viewBoxToken: '555 82 180 175' },
    { match: 'troll das cavernas', rotuloCurto: 'TROLL CAV.', molde: 'TROLL_GIGANTE', cor1: '#3F3F46', cor2: '#18181B', corDet: '#EF4444', corOlho: '#EF4444', corFundo: '#090D16', corAnel: '#EF4444', var: 'TROLL_COLOSSAL', viewBoxToken: '555 82 180 175' },
    { match: 'troll glacioll', rotuloCurto: 'GLACIOLL', molde: 'TROLL_GIGANTE', cor1: '#0284C7', cor2: '#0C4A6E', corDet: '#E0F2FE', corOlho: '#67E8F9', corFundo: '#082F49', corAnel: '#38BDF8', var: 'TROLL_GELO', viewBoxToken: '555 82 180 175' },
    { match: 'troll vrakoll', rotuloCurto: 'VRAKOLL', molde: 'TROLL_GIGANTE', cor1: '#0D9488', cor2: '#134E4A', corDet: '#5EEAD4', corOlho: '#FDE047', corFundo: '#042F2E', corAnel: '#2DD4BF', var: 'TROLL_AQUATICO', viewBoxToken: '555 82 180 175' },
    { match: 'troll ghillanin', rotuloCurto: 'GHILLANIN', molde: 'TROLL_GIGANTE', cor1: '#57534E', cor2: '#292524', corDet: '#D6D3D1', corOlho: '#F87171', corFundo: '#1C1917', corAnel: '#A8A29E', var: 'TROLL_ROCHA', viewBoxToken: '555 82 180 175' },
    { match: 'troll', rotuloCurto: 'TROLL', molde: 'TROLL_GIGANTE', cor1: '#3F6212', cor2: '#1A2E05', corDet: '#84CC16', corOlho: '#FACC15', corFundo: '#1A2E05', corAnel: '#84CC16', var: 'TROLL_REGEN', viewBoxToken: '555 82 180 175' },

    // DRAGÕES E SERVOS DE KALLYADRANOCH
    { match: 'kobolds', rotuloCurto: 'KOBOLDS', molde: 'GOBLIN', cor1: '#B91C1C', cor2: '#78350F', corDet: '#FACC15', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#F97316', var: 'TRIO_KOBOLDS', viewBoxToken: '555 82 180 175' },
    { match: 'tirano do terceiro', rotuloCurto: 'TIRANO 3º', molde: 'POLICEFALO', cor1: '#18181B', cor2: '#991B1B', corDet: '#FACC15', corOlho: '#EF4444', corFundo: '#1E1B4B', corAnel: '#FACC15', var: 'TIRANO_KALLY_3DRAGOES', viewBoxToken: '555 82 180 175' },
    { match: 'dragão filhote', rotuloCurto: 'D. FILHOTE', molde: 'DRAGAO', cor1: '#EF4444', cor2: '#991B1B', corDet: '#FDE68A', corOlho: '#FEF08A', corFundo: '#3B070B', corAnel: '#FB923C', var: 'FILHOTE', viewBoxToken: '555 82 180 175' },
    { match: 'dragão jovem', rotuloCurto: 'D. JOVEM', molde: 'DRAGAO', cor1: '#DC2626', cor2: '#7F1D1D', corDet: '#F59E0B', corOlho: '#FEF08A', corFundo: '#3B070B', corAnel: '#F97316', var: 'JOVEM', viewBoxToken: '555 82 180 175' },
    { match: 'dragão adulto', rotuloCurto: 'D. ADULTO', molde: 'DRAGAO', cor1: '#B91C1C', cor2: '#450A0A', corDet: '#FACC15', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#EAB308', var: 'ADULTO', viewBoxToken: '555 82 180 175' },
    { match: 'dragão venerável', rotuloCurto: 'VENERÁVEL', molde: 'DRAGAO', cor1: '#7F1D1D', cor2: '#1E1B4B', corDet: '#38BDF8', corOlho: '#67E8F9', corFundo: '#1E1B4B', corAnel: '#38BDF8', var: 'VENERAVEL_OBSIDIANA', viewBoxToken: '555 82 180 175' },
    { match: 'dragão ancião', rotuloCurto: 'D. ANCIÃO', molde: 'DRAGAO', cor1: '#991B1B', cor2: '#18181B', corDet: '#FEF08A', corOlho: '#FFFFFF', corFundo: '#2A0408', corAnel: '#FACC15', var: 'ANCIAO_SOBERANO', viewBoxToken: '555 82 180 175' },

    // A TORMENTA & LEFEU
    { match: 'maníaco lefou', rotuloCurto: 'MANÍACO', molde: 'HUMANOIDE', cor1: '#991B1B', cor2: '#2A0408', corDet: '#FB7185', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#F43F5E', var: 'LEFOU_MACHADO', viewBoxToken: '555 82 180 175' },
    { match: 'sacerdote do deus da tormenta', rotuloCurto: 'SACERDOTE', molde: 'ABERRACAO_TORMENTA', cor1: '#7F1D1D', cor2: '#18181B', corDet: '#EF4444', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#EF4444', var: 'SACERDOTE_AHARADAK', viewBoxToken: '555 82 180 175' },
    { match: 'otyugh', rotuloCurto: 'OTYUGH', molde: 'ABERRACAO_TORMENTA', cor1: '#65A30D', cor2: '#451A03', corDet: '#A855F7', corOlho: '#FEF08A', corFundo: '#1A2E05', corAnel: '#A3E635', var: 'OTYUGH_TENTACULOS', viewBoxToken: '555 82 180 175' },
    { match: 'uktril', rotuloCurto: 'UKTRIL', molde: 'ABERRACAO_TORMENTA', cor1: '#DC2626', cor2: '#450A0A', corDet: '#FDA4AF', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#F43F5E', var: 'UKTRIL_PINCAS', viewBoxToken: '555 82 180 175' },
    { match: 'geraktril', rotuloCurto: 'GERAKTRIL', molde: 'ABERRACAO_TORMENTA', cor1: '#B91C1C', cor2: '#2A0408', corDet: '#FACC15', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#FB7185', var: 'GERAKTRIL_4FOICES', viewBoxToken: '555 82 180 175' },
    { match: 'reishid', rotuloCurto: 'REISHID', molde: 'ABERRACAO_TORMENTA', cor1: '#881337', cor2: '#1E1B4B', corDet: '#E879F9', corOlho: '#67E8F9', corFundo: '#1E1B4B', corAnel: '#E879F9', var: 'REISHID_SOMBRA', viewBoxToken: '555 82 180 175' },
    { match: 'thuwarokk', rotuloCurto: 'THUWAROKK', molde: 'ABERRACAO_TORMENTA', cor1: '#7F1D1D', cor2: '#090D16', corDet: '#22C55E', corOlho: '#FEF08A', corFundo: '#2A0408', corAnel: '#22C55E', var: 'THUWAROKK_COLOSSAL', viewBoxToken: '555 82 180 175' }
];

function obterPerfilVisualUnico83AmeacasCap7(nomeCriatura, grupoCap7) {
    const nm = String(nomeCriatura || 'Ameaça').replace(/ #\d+$/, '').trim().toLowerCase();
    const grp = String(grupoCap7 || '').toLowerCase();
    for (let i = 0; i < CATALOGO_VISUAL_83_AMEACAS_T20.length; i++) {
        const item = CATALOGO_VISUAL_83_AMEACAS_T20[i];
        if (nm === item.match || nm.includes(item.match)) {
            return item;
        }
    }
    if (grp.includes('drag')) return CATALOGO_VISUAL_83_AMEACAS_T20.find(x => x.match === 'dragão adulto');
    if (grp.includes('tormenta') || nm.includes('lefeu')) return CATALOGO_VISUAL_83_AMEACAS_T20.find(x => x.match === 'uktril');
    if (grp.includes('morto')) return CATALOGO_VISUAL_83_AMEACAS_T20.find(x => x.match === 'esqueleto de elite');
    if (grp.includes('troll')) return CATALOGO_VISUAL_83_AMEACAS_T20.find(x => x.match === 'troll');
    if (grp.includes('duyshidakk')) return CATALOGO_VISUAL_83_AMEACAS_T20.find(x => x.match === 'hobgoblin soldado');
    return {
        match: nm, rotuloCurto: nm.slice(0, 9).toUpperCase(), molde: 'HUMANOIDE',
        cor1: '#7F1D1D', cor2: '#1E293B', corDet: '#F59E0B', corOlho: '#FACC15',
        corFundo: '#1E1B4B', corAnel: '#EF4444', var: 'GUERREIRO_PADRAO', viewBoxToken: '555 82 180 175'
    };
}

function construirSpriteSVGCriaturaJRPG(priv) {
    const nm = String((priv && (priv.nomeCriatura || priv.nome)) || 'Ameaça').replace(/ #\d+$/, '').trim();
    const grp = String((priv && (priv.grupoCap7 || priv.grupo_cap7)) || '').toLowerCase();
    const p = obterPerfilVisualUnico83AmeacasCap7(nm, grp);
    const uid = gerarUidUnicoSVGT20('en');
    const pal = criarPaletaPixelArtPadraoT20(p.cor1, p.cor2, p.corDet, p.corOlho, '#D6D3D1', p.cor2);
    let mat = [];
    let ps = 5.0;

    // 1. DRAGÃO EM PIXEL ART 16-BIT/32-BIT (Boca aberta com presas superiores/inferiores, sopro incandescente, chifres, asas de morcego com nervuras, garras e cauda espinhosa!)
    if (p.molde === 'DRAGAO') {
        const ehFilhote = p.var === 'FILHOTE';
        const ehAnciao = p.var === 'ANCIAO_SOBERANO';
        const ehVeneravel = p.var === 'VENERAVEL_OBSIDIANA';
        ps = ehFilhote ? 4.3 : (ehAnciao ? 5.6 : (ehVeneravel ? 5.3 : 5.0));
        mat = [
            "...........DD..DD.....WW............", // 0: Chifres e garra da asa
            "............DDDD.....DDDDD..........", // 1: Crista real e braço da asa
            ".............DD....DDD444DDD........", // 2: Nervura superior da asa
            "......333111111...DD4446644DDD......", // 3: Topo do focinho e membrana
            "....331111EWW111.DD444D444664DD.....", // 4: Focinho dracônico e olho brilhante
            "...11#1111111111DD444D4444D444DD....", // 5: Narina (#) e nervuras D da asa
            "...2222222221111D444D44444D4444D....", // 6: Maxilar superior escamoso
            "....W.W.W.W.R111144D444444D4444D....", // 7: Presas superiores brancas (W)
            "..FFYYYYFFRRRR11114D445554D4455D....", // 8: Boca aberta com Sopro de Fogo (FY)
            "...FFYYFFRRRRR111DD4455..5D455......", // 9: Cavidade bucal rubra e labareda
            "....W.W.W.111111DDD111....D45.......", // 10: Presas inferiores brancas (W)
            ".....1111122211DDdd1111.............", // 11: Mandíbula inferior forte + garganta
            ".......DD....11DDdd113311...........", // 12: Barbela e placas peitorais douradas
            ".............1DDdd11133311D.........", // 13: Peito escamoso e espinho dorsal
            "............11DDdd111111111D........", // 14: Torso dracônico musculoso
            "...........111DDdd1112221111D...DD..", // 15: Ventre dourado e ponta da cauda
            "..........1122DDdd11222211111..D11..", // 16: Braço frontal e curva da cauda
            ".........1122.DDdd111221111111D112..", // 17: Antebraço e cauda espinhosa
            "........WW22...DDdd22221112211112...", // 18: Garras dianteiras e coxa
            "...............11222....11222222....", // 19: Pernas traseiras musculosas
            "..............1122.......1122.......", // 20: Canelas escamosas
            ".............WW22.......WW22........"  // 21: Garras traseiras cravadas na base
        ];
    }
    // 2. MANTÍCORA EM PIXEL ART (Juba leonina feroz, boca com presas, ASAS DE MORCEGO com nervuras nos ombros, corpo de leão em 4 patas e cauda de escorpião com ferrão venenoso!)
    else if (p.molde === 'MANTICORA') {
        ps = 5.0;
        mat = [
            "...............WW...................", // 0: Garra do topo da asa de morcego
            "..............DDDDDDD.......GGGG....", // 1: Borda superior da asa + Veneno (G)
            ".............DD44664DDD....GGWWdd...", // 2: Membrana da asa + Ferrão branco (W)
            ".....2222...DD444D4466DD......dd2...", // 3: Topo da juba + Nervura da asa + Cauda
            "...22444422DD444D444D44DD......dd2..", // 4: Juba leonina + 3 Nervuras de morcego
            "..244KKKK442D44D4444D444DD......dd2.", // 5: Rosto bestial na juba + Asa aberta
            "..24KKEWWK44244D4455D4455D......dd2.", // 6: Olho vermelho brilhante + Asa
            "..24KKKKKK4424D4455.D455........dd2.", // 7: Focinho + Recorte inferior da asa
            "..24W.RR.W4422D45...............dd2.", // 8: Boca rugindo com presas brancas (W)
            "...244WW4422211111111...........dd2.", // 9: Mandíbula + Costas leoninas
            "....2244222111333111111........dd2..", // 10: Juba no peito + Tronco de leão
            "......2221113331111113311.....dd2...", // 11: Peitoral e flanco musculoso
            "........1111111111111111111..dd2....", // 12: Corpo leonino + Base da cauda
            "........11221112222221112211dd2.....", // 13: Ombros e quadris do leão
            "........112.112.....112..1122.......", // 14: 4 Pernas leoninas
            ".......112..112.....112..112........", // 15: Canelas
            "......WW2..WW2.....WW2..WW2........."  // 16: 4 Patas com garras brancas (W)
        ];
    }
    // 3. GRIFO EM PIXEL ART (Cabeça de águia com bico dourado curvo, peito emplumado branco, grandes asas de águia e corpo de leão dourado)
    else if (p.molde === 'GRIFO') {
        ps = 5.0;
        mat = [
            "...............WWWWWW...............",
            ".............WWWW444WWW.............",
            "............WWW4444444WWW...........",
            ".....4444..WW444WWWW4444WW..........",
            "...444EWW44WW44WW444WW444WW....11...",
            "..DDD444444W44WW44444WW44WW...112...",
            ".DDDD.4444444WW444444.........12....",
            "..D...4444444441111111.......12.....",
            "......444444411133311111....12......",
            ".......4444411111111133111.12.......",
            "........44221122222221112212........",
            "........DD2.442.....112..112........",
            ".......DD2..442.....112..112........",
            "......WW2..WW2.....WW2..WW2........."
        ];
    }
    // 4. WYVERN EM PIXEL ART (Draco bípede alado com longo ferrão venenoso na cauda)
    else if (p.molde === 'WYVERN') {
        ps = 5.0;
        mat = [
            "..............WW....................",
            ".............DDDDDDD................",
            "....DD......DD44664DDD..............",
            "...31111...DD444D4466DDD............",
            "..111EWW11DD444D4444D44DDD..........",
            "..W.RR.W11D444D44555D4455D...GGGG...",
            "...WWWW111D4455.....D455....GGWWdd..",
            ".......11111111...............dd2...",
            "........1133311111...........dd2....",
            ".........11111112211........dd2.....",
            "..........221111222111.....dd2......",
            "...........1122..112211111dd2.......",
            "..........112.....112...............",
            ".........WW2.....WW2................"
        ];
    }
    // 5. URSO-CORUJA EM PIXEL ART (Corpo massivo de urso, face emplumada de coruja, grandes olhos amarelos, bico curvo e garras gigantes)
    else if (p.molde === 'URSO_CORUJA') {
        ps = 5.0;
        mat = [
            ".......DD..........DD.......",
            "......DDDD11111111DDDD......",
            ".....1111DDDDDDDDDD1111.....",
            "....111DDEEWWDDEEWWDD111....",
            "....111DD444DDDD444DD111....",
            "...11111111DDDDDD11111111...",
            "..1133111111DDDD1111113311..",
            ".1133111DDDDDDDDDDDD1113311.",
            ".1122111DDDDDDDDDDDD1112211.",
            ".11221111111111111111112211.",
            ".WWW..1111222222221111..WWW.",
            "......11122......22111......",
            "......1122........2211......",
            ".....WWWW..........WWWW....."
        ];
    }
    // 6. SLIME / GLOP EM PIXEL ART (Gota translúcida ácida com crânio e adaga dissolvendo dentro)
    else if (p.molde === 'SLIME') {
        ps = 5.2;
        mat = [
            "...........333333...........",
            ".........3311111133.........",
            ".......3311WW11111133.......",
            "......311WW11WWWW11113......",
            ".....3111111W#WW#W11113.....",
            "....31111111WWWWWW11S113....",
            "...3111331111W#W#11SS1113...",
            "...111331111111111SS11221...",
            "..111111111D11111DD1122221..",
            "..112221111111111112222221..",
            "..222222222222222222222222.."
        ];
    }
    // 7. ARACNÍDEO EM PIXEL ART (Aranha Gigante com 8 patas articuladas, abdômen ampulheta, 6 olhos verdes e quelíceras venenosas)
    else if (p.molde === 'ARACNIDEO') {
        ps = 4.9;
        mat = [
            "....44........44....111111......",
            "...4444......4444.111DDDD111....",
            "..44..44....44..4111DD11DD111...",
            ".44....44..44...11111DDDD11111..",
            "44..44..44444444111111DD111111..",
            "...44....44EEWWEE111111111111...",
            "..44....444EEWWEE41122222211....",
            ".44....44.4444444444222222......",
            "......44.GGWW..WWGG.44..44......",
            ".....44..GG......GG..44..44.....",
            "....44................44..44...."
        ];
    }
    // 8. CENTOPEIA-DRAGÃO EM PIXEL ART (Corpo segmentado em S com respiradouros de magma, dezenas de patas e mandíbulas dracônicas)
    else if (p.molde === 'CENTOPEIA') {
        ps = 4.9;
        mat = [
            ".....DD..DD.....................",
            "...33111111DD...................",
            "..11EWW1111111..................",
            "..W.FF.W11DD1111................",
            "...WWWW.D11FF11111..............",
            "........D1111DD11111............",
            ".........D1111FF111111....DD....",
            "..........D1111DD1111111.11D....",
            "...........D1111FF11111111D.....",
            "..........DD2222DD222222DD......",
            ".........D..D..D..D..D..D......."
        ];
    }
    // 9. SERPENTE EM PIXEL ART (Cascavel, Jiboia, Naja, Sucuri — bote espiralado com capelo/guizo e presas venenosas)
    else if (p.molde === 'SERPENTE') {
        ps = 5.0;
        mat = [
            ".......DDDDDDDDDD...............",
            ".....DD1113333111DD.............",
            "....D111EEWWEWWEE11D............",
            "....D11111111111111D............",
            "..RRRW..W11DD11111D.............",
            "....G....11dd1111D..........DD..",
            "..........11DD11D..........DDD..",
            "...........11dd1111111....DD....",
            "..........111DD111333111.11.....",
            ".........11331111111111111......",
            "........11111222222222112.......",
            "........2222222222222222........"
        ];
    }
    // 10. NAGAH EM PIXEL ART (Tronco humanoide armado + longa cauda ofídia espiralada)
    else if (p.molde === 'NAGAH') {
        ps = 4.9;
        mat = [
            "..........DDDDDD................",
            ".........11111111...............",
            "........11KKEKKE11..............",
            "...WW...11KKKKKK11...WW.........",
            "...SS..DD444DD444DD..SS.........",
            "...SS.444444DD444444.SS.........",
            "...DD.44..44DD44..44.DD.........",
            "..........11DD11................",
            "..........11dd111111......11....",
            ".........111DD11133111...112....",
            "........1133111111111111112.....",
            "........222222222222222222......"
        ];
    }
    // 11. FERA QUADRÚPEDE EM PIXEL ART (Lobo, Lobo-das-Cavernas, Cão do Inferno, Rato Gigante)
    else if (p.molde === 'FERA_QUAD') {
        const ehCaoInf = p.var === 'CAO_MAGMA';
        ps = 5.0;
        mat = [
            "......11..11....................",
            ".....11111111...................",
            "...1111EWW11111........" + (ehCaoInf ? "FF......." : "........."),
            "..111111111111111....." + (ehCaoInf ? "FFYY......" : "..111....."),
            "..W.RR.W11133311111111111133....",
            "...WWWW.1113331111111111111.....",
            "........111111111111111122......",
            "........112211222222112211......",
            "........112..112....112.112.....",
            ".......112...112....112..112....",
            "......WW2...WW2....WW2..WW2....."
        ];
    }
    // 12. SÁURIO / DINOSAURO / TROG EM PIXEL ART (Gorlogg, Basilisco, Trog)
    else if (p.molde === 'SAURIO') {
        ps = 5.0;
        mat = [
            "........D..D..D..D..............",
            "......331111111111DD............",
            "....33111EWW11111111D...........",
            "...111111111111133111D..........",
            "...W.W.W.R111113331111D.....DD..",
            "....W.W.1111DD1111111111...11...",
            "........1111DD111111111111112...",
            ".......1122.DD1112222111222.....",
            "......WW2....1122....1122.......",
            ".............112.....112........",
            "............WW2.....WW2........."
        ];
    }
    // 13. CENTAURO EM PIXEL ART (Corpo equino de 4 patas + torso guerreiro/xamã com arco longo)
    else if (p.molde === 'CENTAURO') {
        ps = 4.9;
        mat = [
            "..........HHHHHH................",
            "....DD...HHHHHHHH...............",
            "...LLW...HKKKEKKH...............",
            "..LL.W....KKKKKK................",
            "..DD.W..4411DD1144..............",
            "..LL.W..4411DD1144..............",
            "...LLW....11111122222222....22..",
            "....DD...22222223332222222.224..",
            "........222222222222222222224...",
            "........224.224.....224..224....",
            ".......224..224.....224..224....",
            "......dd4..dd4.....dd4..dd4....."
        ];
    }
    // 14. POLICÉFALO EM PIXEL ART (Hidra de 5 Cabeças, Lagash Alado, Tirano do Terceiro)
    else if (p.molde === 'POLICEFALO') {
        ps = 4.9;
        mat = [
            "....DD....DD....DD....DD....DD..",
            "..11E1..11E1..11E1..11E1..11E1..",
            "..W.RW..W.RW..W.RW..W.RW..W.RW..",
            "...11....11....11....11....11...",
            "....11...11....11....11...11....",
            ".....111..111..11..111..111.....",
            ".......111111111111111111.......",
            "......11133311DDDD11333111......",
            ".....111111111DDDD1111111111....",
            ".....22112222222222221122112....",
            ".....112..112......112..112.....",
            "....WW2..WW2......WW2..WW2......"
        ];
    }
    // 15. ABERRAÇÃO DA TORMENTA & LEFEU EM PIXEL ART (Uktril, Geraktril, Reishid, Thuwarokk, Otyugh, Sacerdote)
    else if (p.molde === 'ABERRACAO_TORMENTA') {
        ps = 5.0;
        mat = [
            "...........DD..EE..DD...........",
            "...WW.....1111EEEE1111.....WW...",
            "..WSSW...111EEWWWWEE111...WSSW..",
            ".WSS111..11111RRRR11111..111SSW.",
            "WSS..111111331DDDD133111111..SSW",
            "WW....11111331DDDD13311111....WW",
            "..WW...1122111DDDD1112211...WW..",
            ".WSS111..11112222221111..111SSW.",
            "..WSS111..1122....2211..111SSW..",
            ".........1122......2211.........",
            "........1122........2211........",
            ".......WW22..........22WW......."
        ];
    }
    // 16. ENGENHO DE GUERRA GOBLIN EM PIXEL ART (Tanque Steampunk com canhão, serra e rodas)
    else if (p.molde === 'ENGENHO_GUERRA') {
        ps = 5.0;
        mat = [
            "................FFYY.....ss.....",
            "........DDDD...111111....ss.....",
            "..SSSSS111111111EWW111..ssss....",
            ".SSSSSS111DDDDDDDDDD1111ssss....",
            "..SSSSS44444444444444444444.....",
            ".W..W.1111DDDDDDDDDDDD11111.....",
            "WSSSSW111144444444444411111.....",
            ".W..W.222222222222222222222.....",
            ".......DDDDD........DDDDD.......",
            "......DD444DD......DD444DD......",
            ".......DDDDD........DDDDD......."
        ];
    }
    // 17. TROLLS & GIGANTES EM PIXEL ART (Ogro, Troll, Ghillanin, Glacioll, Vrakoll, Ganchador, Troll das Cavernas)
    else if (p.molde === 'TROLL_GIGANTE') {
        ps = 5.2;
        mat = [
            "....LLLL.......111111...........",
            "...LLLLLL.....11133111..........",
            "...LLLLLL....11EEWWEE11.........",
            "....LLLL.....11W1111W11.........",
            ".....LL...111111WWWW111111......",
            "....111111133311111133311111....",
            "...1111111133311DDDD133111111...",
            "...1122.11111111DDDD11111.2211..",
            "........11112222LLLL22111.2211..",
            "........112222..LLLL..2211.WW...",
            ".......11222..........22211.....",
            "......11222............22211....",
            ".....WW222..............222WW..."
        ];
    }
    // 18. GOBLINS & HOBGOBLINS DUYSHIDAKK EM PIXEL ART
    else if (p.molde === 'GOBLIN') {
        ps = 4.7;
        mat = [
            "..........DDDDDDDD..............",
            "....111..1111331111..111........",
            "...11111111EEWWEE11111111.......",
            ".....11111111WW11111111.........",
            "..WW....44411DD11444....WW......",
            "..SS...444411DD114444...SS......",
            "..DD...44.44DDDD44.44...DD......",
            "..........44222244..............",
            ".........442....244.............",
            "........LL2......2LL............"
        ];
    }
    // 19. MORTOS-VIVOS (Esqueleto, Esqueleto de Elite, Falange, Zumbi) EM PIXEL ART
    else if (p.molde === 'MORTO_VIVO') {
        const ehZumbi = p.var.includes('ZUMBI');
        ps = 4.9;
        mat = [
            "..........DDDDDDDD..............",
            ".........1111111111.............",
            "...WW....11EE11EE11.............",
            "...SS....1111##1111.............",
            "...SS.....11W#W#11...DDDDDD.....",
            "...SS...4411DDDD1144D44DD44D....",
            "...DD...44.11##11.44D4DDDD4D....",
            "...........11##11...D44DD44D....",
            "..........11111111...DDDDDD.....",
            "........." + (ehZumbi ? "4422..2244" : "11......11") + ".............",
            "........." + (ehZumbi ? "442....244" : "11......11") + ".............",
            "........" + (ehZumbi ? "112......211" : "111......111") + "............"
        ];
    }
    // 20. NECROMANTE, VAMPIRO & APARIÇÃO EM PIXEL ART
    else if (p.molde === 'NECRO_VAMP') {
        ps = 4.9;
        mat = [
            "...DD.....44444444.....DD.......",
            "..DFFY...4411111144...YFFD......",
            "...DD...441KKEKKE144...DD.......",
            "....L..44411KKKK11444...........",
            "....L.444111DDDD111444..........",
            "....L.44.111DDDD111.44..........",
            "....L.44.1111DD1111.44..........",
            "....L....1114444111.............",
            "....L...111444444111............",
            "....L..111444..444111...........",
            ".......2244......4422..........."
        ];
    }
    // 21. DEMÔNIO ALADO & GÁRGULA EM PIXEL ART
    else if (p.molde === 'DEMONIO_ALADO') {
        ps = 5.0;
        mat = [
            ".....DD...DD..........DD...DD...",
            "....4444..DDD111111DDD..4444....",
            "...446644..11EEWWEE11..446644...",
            "..44445544.111WWWW111.44554444..",
            "..4455.4444111DDDD1114444.5544..",
            ".WWSS...4411133DD3311144........",
            "WSSSSW....11111DD11111..........",
            ".WWLL.....112222222211..........",
            "...LL....1122......2211.........",
            "...LL....112........211.........",
            "........WW2..........2WW........"
        ];
    }
    // 22. COLOSSO SUPREMO & GOLEM DE FERRO EM PIXEL ART
    else if (p.molde === 'COLOSSO_MECHA') {
        ps = 5.2;
        mat = [
            ".........DDDDDDDDDD.............",
            "...WW...111111111111............",
            "...SS...11DDDDDDDD11............",
            "...SS...11EEEEEEEE11............",
            "...SS.DDDD11111111DDDD..........",
            "...SSD111111FFFF111111D.........",
            "..DDDD113311FYYF113311D.........",
            "...LL.112211DDDD112211..........",
            "......1111222222221111..........",
            "......111222....222111..........",
            "......11222......22211..........",
            ".....DDDDD........DDDDD........."
        ];
    }
    // 23. GNOLLS E HUMANOIDES COMBATENTES EM PIXEL ART
    else {
        const ehGnoll = p.molde === 'GNOLL';
        ps = 4.9;
        mat = [
            "..........DDDDDDDD..............",
            "...WW...." + (ehGnoll ? "1111111111" : "4411111144") + ".............",
            "...SS...." + (ehGnoll ? "111EEWW111" : "44KKEKKE44") + ".............",
            "...SS...." + (ehGnoll ? "WW11111111" : "44KKKKKK44") + ".............",
            "...SS..DD1111DD1111DD.DDDDDD....",
            "...DD.4411331DD1331144D44DD4D...",
            "...LL.441111DDDD111144D4DDDDD...",
            "......44.1112222111.44.DDDDD....",
            ".........1122..2211.............",
            "........1122....2211............",
            ".......LLLL......LLLL..........."
        ];
    }

    // ALONGAMENTO ANATÔMICO DO TORSO DAS AMEAÇAS (v63):
    // Insere linhas intermediárias na faixa central do tronco (32% a 72% da altura da matriz)
    // para que humanoides, gigantes, dragões, mantícoras e feras tenham torso esbelto e proporcional!
    const matTorsoProporcional = [];
    const hOrig = mat.length;
    const yTorsoIni = Math.max(2, Math.floor(hOrig * 0.32));
    const yTorsoFim = Math.min(hOrig - 2, Math.ceil(hOrig * 0.72));
    for (let y = 0; y < hOrig; y++) {
        matTorsoProporcional.push(mat[y]);
        if (y >= yTorsoIni && y <= yTorsoFim) {
            matTorsoProporcional.push(mat[y]);
        }
    }
    const baseMiniaturaAmeaca = construirBaseMiniaturaRPGDeMesaSVG(645, 260, 52, 12, p.corAnel, uid, true, p.rotuloCurto);
    const artePixelMonstro = renderizarMatrizPixelArtSVG(matTorsoProporcional, pal, 645, 255, ps * 0.76, true, false);

    return `
        <g id="jrpg-enemy-sprite-group" class="jrpg-sprite-idle" shape-rendering="crispEdges">
            ${baseMiniaturaAmeaca}
            ${artePixelMonstro}
        </g>
    `;
}


function construirAuraParticulasPixelArtSVG(tipoAura, cx, cy) {
    if (!tipoAura || tipoAura === 'NENHUMA') return '';
    const t = String(tipoAura).toUpperCase();
    let c1 = '#FACC15', c2 = '#F97316';
    if (t.includes('RAIO')) { c1 = '#38BDF8'; c2 = '#E0F2FE'; }
    else if (t.includes('GELO')) { c1 = '#67E8F9'; c2 = '#0284C7'; }
    else if (t.includes('TREVAS')) { c1 = '#A855F7'; c2 = '#3B0764'; }
    else if (t.includes('TORMENTA')) { c1 = '#EF4444'; c2 = '#7F1D1D'; }
    else if (t.includes('FOLHAS')) { c1 = '#4ADE80'; c2 = '#15803D'; }
    else if (t.includes('LUZ')) { c1 = '#FEF08A'; c2 = '#F59E0B'; }
    return `
        <g class="t20-pixel-aura" shape-rendering="crispEdges" pointer-events="none">
            <rect x="${cx - 46}" y="${cy - 54}" width="6" height="6" fill="${c1}">
                <animate attributeName="y" values="${cy + 30};${cy - 65}" dur="1.1s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0.9;0.1" dur="1.1s" repeatCount="indefinite"/>
            </rect>
            <rect x="${cx + 40}" y="${cy - 30}" width="6" height="6" fill="${c2}">
                <animate attributeName="y" values="${cy + 40};${cy - 60}" dur="0.95s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0.9;0.1" dur="0.95s" repeatCount="indefinite"/>
            </rect>
            <rect x="${cx - 32}" y="${cy + 10}" width="5" height="5" fill="${c2}">
                <animate attributeName="y" values="${cy + 48};${cy - 48}" dur="1.3s" repeatCount="indefinite"/>
            </rect>
            <rect x="${cx + 28}" y="${cy + 18}" width="5" height="5" fill="${c1}">
                <animate attributeName="y" values="${cy + 50};${cy - 52}" dur="1.15s" repeatCount="indefinite"/>
            </rect>
        </g>
    `;
}

function aplicarPresetVisualRapidoHeroiJS(presetId) {
    window.__APARENCIA_HEROI__ = window.__APARENCIA_HEROI__ || {};
    const ap = window.__APARENCIA_HEROI__;
    if (presetId === 'CAVALEIRO_REAL') {
        ap.acessorioCabeca = 'ELMO_TEMPLARIO'; ap.estiloTraje = 'PLACAS_PESADAS'; ap.corTraje = '#1E3A8A|#1D4ED8';
        ap.materialEspecial = 'MITRAL'; ap.capaCostas = 'CAPA_REAL'; ap.efeitoArma = 'LUZ_PALADINO'; ap.auraParticulas = 'LUZ_DIVINA';
    } else if (presetId === 'ARQUIMAGO_ASTRAL') {
        ap.acessorioCabeca = 'CHAPEU_ARCANO'; ap.estiloTraje = 'MANTO_ARCANO'; ap.corTraje = '#4C1D95|#6D28D9';
        ap.materialEspecial = 'ACO_RUBI'; ap.capaCostas = 'HALO_DIVINO'; ap.efeitoArma = 'RAIO_TROVAO'; ap.auraParticulas = 'RAIOS_TEMPESTADE';
    } else if (presetId === 'BARBARO_RUBRO') {
        ap.acessorioCabeca = 'VETERANO_GUERRA'; ap.estiloTraje = 'PELES_BARBARAS'; ap.corTraje = '#7F1D1D|#991B1B';
        ap.materialEspecial = 'MATERIA_VERMELHA'; ap.capaCostas = 'MANTO_PELE_INVERNO'; ap.efeitoArma = 'FOGO_SOLAR'; ap.auraParticulas = 'CHAMAS_SOLARES';
    } else if (presetId === 'ASSASSINO_SOMBRIO') {
        ap.acessorioCabeca = 'CAPUZ_SOMBRIO'; ap.estiloTraje = 'COURO_FURTIVO'; ap.corTraje = '#334155|#0F172A';
        ap.materialEspecial = 'ADAMANTE'; ap.capaCostas = 'CAPA_RASGADA'; ap.efeitoArma = 'VENENO_ACIDO'; ap.auraParticulas = 'TREVAS_TENEBRA';
    } else if (presetId === 'PALADINO_SOLAR') {
        ap.acessorioCabeca = 'ELMO_VALQUIRIA'; ap.estiloTraje = 'COMPLETA_EX4'; ap.corTraje = '#CBD5E1|#B45309';
        ap.materialEspecial = 'OURO_AZGHER'; ap.capaCostas = 'ASAS_CELESTIAIS_DRACONICAS'; ap.efeitoArma = 'LUZ_PALADINO'; ap.auraParticulas = 'CHAMAS_SOLARES';
    }
    const mapSel = {
        'ap-sel-cabeca': ap.acessorioCabeca, 'ap-sel-traje': ap.estiloTraje, 'ap-sel-cor-traje': ap.corTraje,
        'ap-sel-material-especial': ap.materialEspecial, 'ap-sel-capa-costas': ap.capaCostas,
        'ap-sel-efeito-arma': ap.efeitoArma, 'ap-sel-aura-particulas': ap.auraParticulas
    };
    Object.keys(mapSel).forEach(id => {
        const el = document.getElementById(id);
        if (el && mapSel[id]) el.value = mapSel[id];
    });
    atualizarRetratoFichaPrincipalJS();
    if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
    if (typeof renderizarMesaOnlineCompletaUI === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) renderizarMesaOnlineCompletaUI();
}

function mudarEscalaPortePixelArtJS(modoPorte) {
    if (modoPorte === 'COMPACTO') {
        window.__ESCALA_PORTE_PIXEL_ART__ = 0.88;
        window.__PROPORCAO_VERTICAL_PIXEL_ART__ = 1.08;
    } else if (modoPorte === 'ALTO_IMPONENTE') {
        window.__ESCALA_PORTE_PIXEL_ART__ = 1.08;
        window.__PROPORCAO_VERTICAL_PIXEL_ART__ = 1.18;
    } else if (modoPorte === 'COLOSSAL') {
        window.__ESCALA_PORTE_PIXEL_ART__ = 1.18;
        window.__PROPORCAO_VERTICAL_PIXEL_ART__ = 1.22;
    } else {
        window.__ESCALA_PORTE_PIXEL_ART__ = 1.0;
        window.__PROPORCAO_VERTICAL_PIXEL_ART__ = 1.10;
    }
    atualizarRetratoFichaPrincipalJS();
    if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
    if (typeof renderizarMesaOnlineCompletaUI === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) renderizarMesaOnlineCompletaUI();
}

function construirEfeitoCoreografadoSVG(efeitoAtivo) {
    if (!efeitoAtivo) return '';
    const ef = String(efeitoAtivo).toUpperCase();
    // 1. CORTE DE ESPADA / MACHADO ANIMADO EM PIXEL ART
    if (ef === 'SLASH' || ef === 'ANIM_ESPADA_CORTE' || ef === 'CORTE') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <g transform="translate(645, 182)">
                    <path d="M -85 -75 L 85 75" stroke="#FEF08A" stroke-width="14" stroke-dasharray="260" stroke-dashoffset="260">
                        <animate attributeName="stroke-dashoffset" values="260;0;0" keyTimes="0;0.45;1" dur="0.55s" fill="freeze"/>
                    </path>
                    <path d="M -85 -75 L 85 75" stroke="#FFFFFF" stroke-width="6"/>
                    <path d="M 85 -75 L -85 75" stroke="#F97316" stroke-width="12" stroke-dasharray="260" stroke-dashoffset="260">
                        <animate attributeName="stroke-dashoffset" values="260;260;0" keyTimes="0;0.25;0.75" dur="0.65s" fill="freeze"/>
                    </path>
                    <rect x="-12" y="-12" width="24" height="24" fill="#FEF08A">
                        <animateTransform attributeName="transform" type="scale" values="0.2;2.6;0" dur="0.65s" fill="freeze"/>
                        <animate attributeName="opacity" values="1;0.9;0" dur="0.65s" fill="freeze"/>
                    </rect>
                </g>
            </g>
        `;
    }
    // 2. IMPACTO ESMAGADOR / MANOBRA / INVESTIDA ANIMADA
    if (ef === 'ANIM_IMPACTO_ESMAGADOR' || ef === 'IMPACTO' || ef === 'POISON' || ef === 'ANIM_VENENO_MANOBRA') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <line x1="645" y1="20" x2="645" y2="262" stroke="#FACC15" stroke-width="16">
                    <animate attributeName="stroke-width" values="28;4;0" dur="0.65s" fill="freeze"/>
                </line>
                <ellipse cx="645" cy="258" rx="20" ry="6" fill="none" stroke="#F97316" stroke-width="8">
                    <animate attributeName="rx" values="16;125" dur="0.65s" fill="freeze"/>
                    <animate attributeName="ry" values="5;28" dur="0.65s" fill="freeze"/>
                    <animate attributeName="opacity" values="1;0" dur="0.65s" fill="freeze"/>
                </ellipse>
                <rect x="615" y="160" width="60" height="60" fill="rgba(250,204,21,0.55)" stroke="#FFFFFF" stroke-width="4">
                    <animateTransform attributeName="transform" type="rotate" from="0 645 190" to="90 645 190" dur="0.6s"/>
                    <animate attributeName="opacity" values="1;0" dur="0.65s" fill="freeze"/>
                </rect>
            </g>
        `;
    }
    // 3. ESTOCADA / DISPARO À DISTÂNCIA COM PROJÉTIL EM VOO REAL (<animateMotion>)
    if (ef === 'ANIM_ESTOCADA_LANCEIRO' || ef === 'ANIM_DISPARO_DISTANCIA' || ef === 'DISPARO' || ef === 'ESTOCADA') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <line x1="245" y1="180" x2="645" y2="180" stroke="#38BDF8" stroke-width="4" stroke-dasharray="12 6"/>
                <g>
                    <rect x="-28" y="-4" width="44" height="8" fill="#FEF08A" stroke="#07040B" stroke-width="2"/>
                    <polygon points="16,-10 34,0 16,10" fill="#EF4444" stroke="#FFFFFF" stroke-width="1.5"/>
                    <animateMotion path="M 245 180 L 645 180" dur="0.36s" fill="freeze"/>
                </g>
                <circle cx="645" cy="180" r="10" fill="none" stroke="#FACC15" stroke-width="6">
                    <animate attributeName="r" values="8;64" begin="0.28s" dur="0.45s" fill="freeze"/>
                    <animate attributeName="opacity" values="1;0" begin="0.28s" dur="0.45s" fill="freeze"/>
                </circle>
            </g>
        `;
    }
    // 4. MAGIA DE FOGO / BOLA DE FOGO COM COMETA EM VOO + EXPLOSÃO PIXELADA
    if (ef === 'MAGIC' || ef === 'ANIM_MAGIA_FOGO' || ef === 'MAGIA_FOGO') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <ellipse cx="216" cy="258" rx="68" ry="16" fill="rgba(249,115,22,0.32)" stroke="#FDE047" stroke-width="3" stroke-dasharray="10 5">
                    <animate attributeName="rx" values="40;76;64" dur="0.8s"/>
                </ellipse>
                <g>
                    <rect x="-18" y="-18" width="36" height="36" fill="#EA580C" stroke="#FEF08A" stroke-width="4"/>
                    <rect x="-10" y="-10" width="20" height="20" fill="#FFFFFF"/>
                    <animateMotion path="M 236 165 Q 430 70 645 180" dur="0.42s" fill="freeze"/>
                </g>
                <g opacity="0">
                    <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.42;0.82;1" dur="0.88s" fill="freeze"/>
                    <rect x="595" y="95" width="100" height="165" fill="rgba(234,88,12,0.55)" stroke="#FEF08A" stroke-width="3"/>
                    <circle cx="645" cy="182" r="24" fill="#FEF08A" stroke="#DC2626" stroke-width="8">
                        <animate attributeName="r" values="18;72" begin="0.38s" dur="0.48s" fill="freeze"/>
                    </circle>
                </g>
            </g>
        `;
    }
    // 5. MAGIA DE RAIO / RELÂMPAGO E ARCANO
    if (ef === 'ANIM_MAGIA_RAIO' || ef === 'ANIM_MAGIA_ARCANA' || ef === 'MAGIA_RAIO') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <ellipse cx="216" cy="258" rx="68" ry="16" fill="rgba(56,189,248,0.32)" stroke="#38BDF8" stroke-width="3"/>
                <polyline points="236,165 360,120 450,195 555,130 645,180" fill="none" stroke="#38BDF8" stroke-width="12">
                    <animate attributeName="opacity" values="1;0.2;1;0.2;1;0" dur="0.8s" fill="freeze"/>
                </polyline>
                <polyline points="236,165 360,120 450,195 555,130 645,180" fill="none" stroke="#FFFFFF" stroke-width="5"/>
                <polyline points="645,5 615,80 665,115 620,180 655,258" fill="none" stroke="#7DD3FC" stroke-width="10">
                    <animate attributeName="opacity" values="0;1;0.3;1;0" dur="0.8s" fill="freeze"/>
                </polyline>
                <circle cx="645" cy="182" r="20" fill="rgba(56,189,248,0.45)" stroke="#FFFFFF" stroke-width="4">
                    <animate attributeName="r" values="15;65" dur="0.75s" fill="freeze"/>
                </circle>
            </g>
        `;
    }
    // 6. DEFESA / ESCUDO / COMBATE DEFENSIVO / REAÇÃO / CURA / BUFF
    if (ef === 'SHIELD' || ef === 'ANIM_BUFF_CURA_REACAO' || ef === 'DEFESA' || ef === 'CURA_BUFF') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <ellipse cx="216" cy="258" rx="74" ry="18" fill="rgba(56,189,248,0.38)" stroke="#FDE047" stroke-width="4">
                    <animate attributeName="rx" values="45;82;70" dur="0.85s" fill="freeze"/>
                </ellipse>
                <!-- Escudo Égide Pixel Art Expansivo -->
                <polygon points="160,125 216,95 272,125 272,215 216,258 160,215" fill="rgba(56,189,248,0.28)" stroke="#FEF08A" stroke-width="5">
                    <animate attributeName="opacity" values="0.2;1;0.85;0" dur="0.9s" fill="freeze"/>
                </polygon>
                <rect x="208" y="125" width="16" height="96" fill="#FEF08A" opacity="0.75"/>
                <rect x="176" y="162" width="80" height="16" fill="#FEF08A" opacity="0.75"/>
            </g>
        `;
    }
    // 7A. AÇÃO ESPECIAL ÚNICA: SOPRO DE FOGO / COSPE-CHAMAS / AURA DE CALOR / JATO DE CHAMAS
    if (ef === 'ANIM_AMEACA_SOPRO_FOGO' || ef === 'ANIM_INIMIGO_SOPRO' || ef === 'SOPRO_DRAGAO') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <polygon points="595,152 145,88 125,262 595,192" fill="rgba(234,88,12,0.58)" stroke="#FEF08A" stroke-width="4">
                    <animate attributeName="opacity" values="0.2;1;0.9;0" dur="0.95s" fill="freeze"/>
                </polygon>
                <g>
                    <rect x="-24" y="-20" width="48" height="40" fill="#EA580C" stroke="#FEF08A" stroke-width="5"/>
                    <rect x="-12" y="-10" width="24" height="20" fill="#FFFFFF"/>
                    <animateMotion path="M 585 168 L 216 185" dur="0.40s" fill="freeze"/>
                </g>
                <rect x="176" y="96" width="80" height="162" fill="rgba(239,68,68,0.52)" stroke="#FEF08A" stroke-width="4">
                    <animate attributeName="opacity" values="0;0;1;0" keyTimes="0;0.35;0.75;1" dur="0.95s" fill="freeze"/>
                </rect>
                <circle cx="216" cy="185" r="24" fill="rgba(254,240,138,0.75)" stroke="#DC2626" stroke-width="6">
                    <animate attributeName="r" values="16;76" begin="0.32s" dur="0.55s" fill="freeze"/>
                </circle>
            </g>
        `;
    }
    // 7B. AÇÃO ESPECIAL ÚNICA: SOPRO DE GELO / RAIO / CANHÃO ELÉTRICO / ABSORVER FRIO
    if (ef === 'ANIM_AMEACA_SOPRO_GELO_RAIO') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <polyline points="595,165 480,125 390,195 295,135 216,185" fill="none" stroke="#38BDF8" stroke-width="14">
                    <animate attributeName="opacity" values="1;0.2;1;0.2;1;0" dur="0.88s" fill="freeze"/>
                </polyline>
                <polyline points="595,165 480,125 390,195 295,135 216,185" fill="none" stroke="#FFFFFF" stroke-width="5"/>
                <polygon points="186,258 202,115 216,145 232,105 246,258" fill="rgba(56,189,248,0.65)" stroke="#E0F2FE" stroke-width="3">
                    <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.35;0.8;1" dur="0.9s" fill="freeze"/>
                </polygon>
            </g>
        `;
    }
    // 7C. AÇÃO ESPECIAL ÚNICA: JATO DE ÁCIDO / GÁS VENENOSO / MAU CHEIRO / CUSPE VENENOSO
    if (ef === 'ANIM_AMEACA_SOPRO_ACIDO_GAS') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <polygon points="595,158 155,105 145,258 595,190" fill="rgba(34,197,94,0.48)" stroke="#A3E635" stroke-width="3"/>
                <g>
                    <rect x="-18" y="-18" width="36" height="36" fill="#22C55E" stroke="#BEF264" stroke-width="4"/>
                    <animateMotion path="M 585 170 Q 400 130 216 185" dur="0.44s" fill="freeze"/>
                </g>
                <circle cx="200" cy="175" r="34" fill="rgba(22,163,74,0.62)" stroke="#BEF264" stroke-width="3">
                    <animate attributeName="r" values="18;58" dur="0.85s" fill="freeze"/>
                </circle>
                <circle cx="235" cy="195" r="28" fill="rgba(132,204,22,0.62)" stroke="#FEF08A" stroke-width="3">
                    <animate attributeName="r" values="14;48" dur="0.85s" fill="freeze"/>
                </circle>
            </g>
        `;
    }
    // 7D. AÇÃO ESPECIAL ÚNICA: RAJADA DE ESPINHOS (MANTÍCORA) / CAIXA COM PREGOS / ARTILHARIA
    if (ef === 'ANIM_AMEACA_ESPINHOS_ARTILHARIA') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                ${[-26, -12, 0, 14, 28].map((dy, i) => `
                    <g>
                        <polygon points="-22,-5 18,0 -22,5" fill="#FEF08A" stroke="#78350F" stroke-width="2"/>
                        <rect x="-30" y="-2" width="12" height="4" fill="#22C55E"/>
                        <animateMotion path="M 605 ${145 + dy} Q 410 ${110 + dy} 216 ${175 + dy}" begin="${(i * 0.06).toFixed(2)}s" dur="0.38s" fill="freeze"/>
                    </g>
                `).join('')}
                <circle cx="216" cy="182" r="16" fill="none" stroke="#F59E0B" stroke-width="5">
                    <animate attributeName="r" values="14;64" begin="0.32s" dur="0.48s" fill="freeze"/>
                    <animate attributeName="opacity" values="1;0" begin="0.32s" dur="0.48s" fill="freeze"/>
                </circle>
            </g>
        `;
    }
    // 7E. AÇÃO ESPECIAL ÚNICA: TEIA (ARANHA) / CONSTRIÇÃO (SERPENTES) / TENTÁCULOS (OTYUGH)
    if (ef === 'ANIM_AMEACA_TEIA_CONSTRICAO') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <line x1="600" y1="175" x2="216" y2="185" stroke="#E2E8F0" stroke-width="6" stroke-dasharray="14 6"/>
                <g transform="translate(216, 188)">
                    <ellipse cx="0" cy="-16" rx="52" ry="14" fill="none" stroke="#E2E8F0" stroke-width="5">
                        <animate attributeName="rx" values="78;34;38" dur="0.75s" fill="freeze"/>
                    </ellipse>
                    <ellipse cx="0" cy="4" rx="52" ry="14" fill="none" stroke="#94A3B8" stroke-width="5">
                        <animate attributeName="rx" values="78;32;36" dur="0.75s" fill="freeze"/>
                    </ellipse>
                    <ellipse cx="0" cy="24" rx="52" ry="14" fill="none" stroke="#E2E8F0" stroke-width="5">
                        <animate attributeName="rx" values="78;34;38" dur="0.75s" fill="freeze"/>
                    </ellipse>
                    <line x1="-42" y1="-38" x2="42" y2="42" stroke="#CBD5E1" stroke-width="3"/>
                    <line x1="42" y1="-38" x2="-42" y2="42" stroke="#CBD5E1" stroke-width="3"/>
                </g>
            </g>
        `;
    }
    // 7F. AÇÃO ESPECIAL ÚNICA: OLHAR PETRIFICANTE (BASILISCO) / OLHAR ATORDOANTE (MEDUSA)
    if (ef === 'ANIM_AMEACA_OLHAR_PETRIFICANTE') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <circle cx="595" cy="142" r="16" fill="#2DD4BF" stroke="#FFFFFF" stroke-width="3">
                    <animate attributeName="r" values="8;24;12" dur="0.75s"/>
                </circle>
                <polygon points="595,138 205,155 205,215 595,148" fill="rgba(45,212,191,0.45)" stroke="#67E8F9" stroke-width="3">
                    <animate attributeName="opacity" values="0.2;1;0.2;1;0" dur="0.88s" fill="freeze"/>
                </polygon>
                <rect x="180" y="120" width="72" height="135" fill="rgba(148,163,184,0.62)" stroke="#67E8F9" stroke-width="4">
                    <animate attributeName="opacity" values="0;0.9;0" dur="0.88s" fill="freeze"/>
                </rect>
            </g>
        `;
    }
    // 7G. AÇÃO ESPECIAL ÚNICA: DRENAR SANGUE (VAMPIRO) / TOQUE DRENANTE (APARIÇÃO) / NECROMANCIA
    if (ef === 'ANIM_AMEACA_DRENAR_NECROMANCIA') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <ellipse cx="216" cy="185" rx="54" ry="64" fill="rgba(136,19,55,0.48)" stroke="#F43F5E" stroke-width="4"/>
                ${[0, 1, 2].map(i => `
                    <g>
                        <rect x="-10" y="-10" width="20" height="20" fill="#DC2626" stroke="#FEF08A" stroke-width="2.5"/>
                        <animateMotion path="M 216 185 Q 430 ${105 + i * 28} 645 170" begin="${(i * 0.12).toFixed(2)}s" dur="0.52s" fill="freeze"/>
                    </g>
                `).join('')}
                <circle cx="645" cy="175" r="22" fill="none" stroke="#4ADE80" stroke-width="5">
                    <animate attributeName="r" values="14;56" begin="0.38s" dur="0.48s" fill="freeze"/>
                </circle>
            </g>
        `;
    }
    // 7H. AÇÃO ESPECIAL ÚNICA: INSANIDADE DA TORMENTA (LEFEU) / APAVORAR / AURA ATERRADORA
    if (ef === 'ANIM_AMEACA_INSANIDADE_TERROR') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <!-- Olho Colossal de Aharadak no centro do Palco -->
                <ellipse cx="430" cy="128" rx="84" ry="42" fill="rgba(127,29,29,0.85)" stroke="#FACC15" stroke-width="4"/>
                <circle cx="430" cy="128" r="26" fill="#EF4444" stroke="#FEF08A" stroke-width="3"/>
                <rect x="425" y="106" width="10" height="44" fill="#07040B"/>
                <circle cx="430" cy="128" r="30" fill="none" stroke="#F43F5E" stroke-width="5">
                    <animate attributeName="r" values="30;240" dur="0.82s" fill="freeze"/>
                    <animate attributeName="opacity" values="1;0" dur="0.82s" fill="freeze"/>
                </circle>
                <polyline points="430,128 330,155 216,185" fill="none" stroke="#FB7185" stroke-width="8"/>
            </g>
        `;
    }
    // 7I. AÇÃO ESPECIAL ÚNICA: INVESTIDA BRUTAL / MARRADA / BOTE AÉREO / GOLPE AVASSALADOR / PASSAR POR CIMA
    if (ef === 'ANIM_AMEACA_INVESTIDA_ESMAGAMENTO') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <line x1="645" y1="190" x2="216" y2="190" stroke="#F97316" stroke-width="18" stroke-dasharray="450" stroke-dashoffset="450">
                    <animate attributeName="stroke-dashoffset" values="450;0" dur="0.35s" fill="freeze"/>
                </line>
                <ellipse cx="216" cy="256" rx="20" ry="8" fill="none" stroke="#FEF08A" stroke-width="8">
                    <animate attributeName="rx" values="18;115" begin="0.25s" dur="0.55s" fill="freeze"/>
                    <animate attributeName="ry" values="6;28" begin="0.25s" dur="0.55s" fill="freeze"/>
                </ellipse>
                <rect x="165" y="195" width="22" height="22" fill="#78350F" stroke="#FACC15" stroke-width="2">
                    <animate attributeName="y" values="250;140" dur="0.6s" fill="freeze"/>
                </rect>
                <rect x="245" y="195" width="22" height="22" fill="#78350F" stroke="#FACC15" stroke-width="2">
                    <animate attributeName="y" values="250;135" dur="0.6s" fill="freeze"/>
                </rect>
            </g>
        `;
    }
    // 7J. AÇÃO ESPECIAL ÚNICA: ORDENS / FORMAÇÃO INVENCÍVEL / AÇOITAR ESCRAVOS / TROPAS / IRA DRACÔNICA
    if (ef === 'ANIM_AMEACA_COMANDO_INVOCACAO') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <rect x="595" y="45" width="100" height="215" fill="rgba(250,204,21,0.28)"/>
                <ellipse cx="645" cy="256" rx="30" ry="10" fill="none" stroke="#FACC15" stroke-width="5">
                    <animate attributeName="rx" values="24;96" dur="0.78s" fill="freeze"/>
                </ellipse>
                <polygon points="645,60 685,82 645,104" fill="#DC2626" stroke="#FEF08A" stroke-width="3"/>
                <line x1="645" y1="60" x2="645" y2="150" stroke="#FEF08A" stroke-width="5"/>
            </g>
        `;
    }
    // 7K. AÇÃO ESPECIAL ÚNICA: FÚRIA / FRENESI INSANO / DILACERAR / 5 MORDIDAS DA HIDRA / ASSASSINAR
    if (ef === 'ANIM_AMEACA_FURIA_DILACERAR') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <path d="M 145 110 L 285 245" stroke="#DC2626" stroke-width="12" stroke-dasharray="220" stroke-dashoffset="220">
                    <animate attributeName="stroke-dashoffset" values="220;0" dur="0.32s" fill="freeze"/>
                </path>
                <path d="M 285 110 L 145 245" stroke="#FEF08A" stroke-width="10" stroke-dasharray="220" stroke-dashoffset="220">
                    <animate attributeName="stroke-dashoffset" values="220;0" begin="0.12s" dur="0.32s" fill="freeze"/>
                </path>
                <path d="M 140 178 L 292 178" stroke="#F97316" stroke-width="10" stroke-dasharray="220" stroke-dashoffset="220">
                    <animate attributeName="stroke-dashoffset" values="220;0" begin="0.22s" dur="0.32s" fill="freeze"/>
                </path>
                <polygon points="175,135 190,170 205,135 220,170 235,135 250,170" fill="#FFFFFF" stroke="#991B1B" stroke-width="2.5"/>
                <polygon points="175,228 190,193 205,228 220,193 235,228 250,193" fill="#FFFFFF" stroke="#991B1B" stroke-width="2.5"/>
            </g>
        `;
    }

    // 8. ATAQUE DA AMEAÇA: GARRAS, MORDIDA OU OLHAR ARCANO
    if (ef === 'ANIM_INIMIGO_GARRAS_MORDIDA' || ef === 'ANIM_INIMIGO_MAGIA_OLHAR' || ef === 'GARRAS_MONSTRO') {
        return `
            <g shape-rendering="crispEdges" pointer-events="none">
                <path d="M 155 110 L 270 235" stroke="#EF4444" stroke-width="11" stroke-dasharray="200" stroke-dashoffset="200">
                    <animate attributeName="stroke-dashoffset" values="200;0" dur="0.4s" fill="freeze"/>
                </path>
                <path d="M 178 100 L 292 225" stroke="#FEF08A" stroke-width="8" stroke-dasharray="200" stroke-dashoffset="200">
                    <animate attributeName="stroke-dashoffset" values="200;0" dur="0.45s" fill="freeze"/>
                </path>
                <path d="M 200 90 L 312 215" stroke="#EF4444" stroke-width="11" stroke-dasharray="200" stroke-dashoffset="200">
                    <animate attributeName="stroke-dashoffset" values="200;0" dur="0.5s" fill="freeze"/>
                </path>
                <circle cx="216" cy="185" r="48" fill="none" stroke="#F87171" stroke-width="4">
                    <animate attributeName="r" values="18;62" dur="0.55s" fill="freeze"/>
                    <animate attributeName="opacity" values="1;0" dur="0.55s" fill="freeze"/>
                </circle>
            </g>
        `;
    }
    return '';
}

function dispararAnimacaoCoreografadaPalco2DJS(dadosAnim) {
    const durMs = 1550;
    try { tocarSomPorEfeitoAnimacaoJRPG(dadosAnim ? dadosAnim.tipo : 'SLASH'); } catch(e) {}
    window.__ANIMACAO_PALCO_ATIVA__ = Object.assign({ timestamp: Date.now() }, dadosAnim || {});
    window.__EFEITO_ARENA_ATIVO__ = {
        tipo: (dadosAnim && dadosAnim.tipo) ? dadosAnim.tipo : 'SLASH',
        ladoAlvo: (dadosAnim && dadosAnim.ladoAlvo) ? dadosAnim.ladoAlvo : 'INIMIGO',
        timestamp: Date.now()
    };
    if (typeof renderizarPalcoJRPG === 'function' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
        const st = garantirEstadoFichaParaArena();
        renderizarPalcoJRPG(st, __ARENA_STATE__, window.__EFEITO_ARENA_ATIVO__.tipo);
    }
    if (typeof renderizarPalcoEGrid2DMesaOnline === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) {
        renderizarPalcoEGrid2DMesaOnline();
    }
    setTimeout(() => {
        if (window.__ANIMACAO_PALCO_ATIVA__ && Date.now() - window.__ANIMACAO_PALCO_ATIVA__.timestamp >= durMs - 60) {
            window.__ANIMACAO_PALCO_ATIVA__ = null;
            window.__EFEITO_ARENA_ATIVO__ = null;
            if (typeof renderizarPalcoJRPG === 'function' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) {
                const st = garantirEstadoFichaParaArena();
                renderizarPalcoJRPG(st, __ARENA_STATE__, null);
            }
            if (typeof renderizarPalcoEGrid2DMesaOnline === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) {
                renderizarPalcoEGrid2DMesaOnline();
            }
        }
    }, durMs);
}

function construirCamadaAnimacaoTrajetoria2DSVG(cols, rows) {
    const anim = window.__ANIMACAO_PALCO_ATIVA__;
    if (!anim) return '';
    const orig = anim.origem || { gx: 2, gy: 2 };
    const dest = anim.destino || { gx: 5, gy: 2 };
    const p1 = mapearGridParaPalco2DSVG(orig.gx, orig.gy, cols || 8, rows || 5);
    const p2 = mapearGridParaPalco2DSVG(dest.gx, dest.gy, cols || 8, rows || 5);
    const x1 = p1.px, y1 = p1.py - 42;
    const x2 = p2.px, y2 = p2.py - 42;
    const mx = (x1 + x2) / 2, my = Math.min(y1, y2) - 36;
    const tp = String(anim.tipo || 'CORTE').toUpperCase();

    let vfx = '';
    if (tp.includes('DISPARO') || tp.includes('ARCO') || tp.includes('FLECHA') || tp.includes('ESTOCADA') || tp.includes('ESPINHOS') || tp.includes('ARTILHARIA')) {
        vfx = `
            <path d="M ${x1.toFixed(1)} ${y1.toFixed(1)} Q ${mx.toFixed(1)} ${my.toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}" fill="none" stroke="#FDE047" stroke-width="3" stroke-dasharray="10 4"/>
            <g shape-rendering="crispEdges">
                <rect x="-18" y="-4" width="32" height="8" fill="#FEF08A" stroke="#07040B" stroke-width="1.5"/>
                <polygon points="14,-9 28,0 14,9" fill="#EF4444"/>
                <animateMotion path="M ${x1.toFixed(1)} ${y1.toFixed(1)} Q ${mx.toFixed(1)} ${my.toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}" dur="0.38s" fill="freeze"/>
            </g>
            <circle cx="${x2.toFixed(1)}" cy="${y2.toFixed(1)}" r="12" fill="none" stroke="#F59E0B" stroke-width="4">
                <animate attributeName="r" values="8;44" dur="0.55s" fill="freeze"/>
                <animate attributeName="opacity" values="1;0" dur="0.55s" fill="freeze"/>
            </circle>
        `;
    } else if (tp.includes('ACIDO') || tp.includes('GAS') || tp.includes('VENENO')) {
        vfx = `
            <g shape-rendering="crispEdges">
                <rect x="-14" y="-14" width="28" height="28" fill="#22C55E" stroke="#BEF264" stroke-width="3"/>
                <animateMotion path="M ${x1.toFixed(1)} ${y1.toFixed(1)} Q ${mx.toFixed(1)} ${my.toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}" dur="0.40s" fill="freeze"/>
            </g>
            <circle cx="${x2.toFixed(1)}" cy="${y2.toFixed(1)}" r="16" fill="rgba(34, 197, 94, 0.55)" stroke="#BEF264" stroke-width="4">
                <animate attributeName="r" values="12;56" dur="0.65s" fill="freeze"/>
                <animate attributeName="opacity" values="1;0" dur="0.65s" fill="freeze"/>
            </circle>
        `;
    } else if (tp.includes('TEIA') || tp.includes('CONSTRICAO') || tp.includes('OLHAR') || tp.includes('DRENAR') || tp.includes('INSANIDADE')) {
        const corR = tp.includes('OLHAR') ? '#2DD4BF' : (tp.includes('TEIA') ? '#E2E8F0' : '#F43F5E');
        vfx = `
            <line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${corR}" stroke-width="6" stroke-dasharray="12 6"/>
            <circle cx="${x2.toFixed(1)}" cy="${y2.toFixed(1)}" r="18" fill="none" stroke="${corR}" stroke-width="5">
                <animate attributeName="r" values="14;60" dur="0.65s" fill="freeze"/>
                <animate attributeName="opacity" values="1;0" dur="0.65s" fill="freeze"/>
            </circle>
        `;
    } else if (tp.includes('FOGO') || tp.includes('SOPRO') || tp.includes('MAGIA')) {
        vfx = `
            <g shape-rendering="crispEdges">
                <rect x="-16" y="-16" width="32" height="32" fill="#EA580C" stroke="#FEF08A" stroke-width="3"/>
                <rect x="-8" y="-8" width="16" height="16" fill="#FFFFFF"/>
                <animateMotion path="M ${x1.toFixed(1)} ${y1.toFixed(1)} Q ${mx.toFixed(1)} ${my.toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}" dur="0.42s" fill="freeze"/>
            </g>
            <circle cx="${x2.toFixed(1)}" cy="${y2.toFixed(1)}" r="16" fill="rgba(234, 88, 12, 0.55)" stroke="#FEF08A" stroke-width="4">
                <animate attributeName="r" values="12;58" begin="0.32s" dur="0.52s" fill="freeze"/>
                <animate attributeName="opacity" values="1;0" begin="0.32s" dur="0.52s" fill="freeze"/>
            </circle>
        `;
    } else if (tp.includes('RAIO') || tp.includes('ELETRIC')) {
        vfx = `
            <polyline points="${x1.toFixed(1)},${y1.toFixed(1)} ${(mx - 15).toFixed(1)},${(my + 8).toFixed(1)} ${(mx + 14).toFixed(1)},${(my + 26).toFixed(1)} ${x2.toFixed(1)},${y2.toFixed(1)}" fill="none" stroke="#38BDF8" stroke-width="8">
                <animate attributeName="opacity" values="1;0.2;1;0.2;1;0" dur="0.75s" fill="freeze"/>
            </polyline>
            <polyline points="${x1.toFixed(1)},${y1.toFixed(1)} ${(mx - 15).toFixed(1)},${(my + 8).toFixed(1)} ${(mx + 14).toFixed(1)},${(my + 26).toFixed(1)} ${x2.toFixed(1)},${y2.toFixed(1)}" fill="none" stroke="#FFFFFF" stroke-width="3"/>
            <circle cx="${x2.toFixed(1)}" cy="${y2.toFixed(1)}" r="28" fill="rgba(56, 189, 248, 0.38)" stroke="#E0F2FE" stroke-width="3"/>
        `;
    } else if (tp.includes('CURA') || tp.includes('BUFF') || tp.includes('SAGRADO') || tp.includes('SHIELD') || tp.includes('DEFESA')) {
        vfx = `
            <rect x="${(x2 - 28).toFixed(1)}" y="0" width="56" height="${(y2 + 44).toFixed(1)}" fill="rgba(250, 204, 21, 0.28)">
                <animate attributeName="opacity" values="0.2;0.9;0" dur="0.85s" fill="freeze"/>
            </rect>
            <ellipse cx="${x2.toFixed(1)}" cy="${(y2 + 34).toFixed(1)}" rx="24" ry="10" fill="rgba(74, 222, 128, 0.42)" stroke="#FDE047" stroke-width="3">
                <animate attributeName="rx" values="20;56" dur="0.8s" fill="freeze"/>
            </ellipse>
            <polygon points="${(x2 - 28).toFixed(1)},${(y2 - 22).toFixed(1)} ${x2.toFixed(1)},${(y2 - 42).toFixed(1)} ${(x2 + 28).toFixed(1)},${(y2 - 22).toFixed(1)} ${(x2 + 28).toFixed(1)},${(y2 + 18).toFixed(1)} ${x2.toFixed(1)},${(y2 + 36).toFixed(1)} ${(x2 - 28).toFixed(1)},${(y2 + 18).toFixed(1)}" fill="rgba(56,189,248,0.28)" stroke="#FEF08A" stroke-width="3"/>
        `;
    } else {
        // Corte / Impacto / Garras / Investida com Golpe Cruzado Animado
        vfx = `
            <line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="rgba(250, 204, 21, 0.85)" stroke-width="4" stroke-dasharray="12 4"/>
            <path d="M ${(x2 - 38).toFixed(1)} ${(y2 - 36).toFixed(1)} L ${(x2 + 38).toFixed(1)} ${(y2 + 36).toFixed(1)}" stroke="#FEF08A" stroke-width="10" stroke-dasharray="140" stroke-dashoffset="140">
                <animate attributeName="stroke-dashoffset" values="140;0" dur="0.38s" fill="freeze"/>
            </path>
            <path d="M ${(x2 + 38).toFixed(1)} ${(y2 - 36).toFixed(1)} L ${(x2 - 38).toFixed(1)} ${(y2 + 36).toFixed(1)}" stroke="#EF4444" stroke-width="8" stroke-dasharray="140" stroke-dashoffset="140">
                <animate attributeName="stroke-dashoffset" values="140;0" begin="0.15s" dur="0.38s" fill="freeze"/>
            </path>
            <circle cx="${x2.toFixed(1)}" cy="${y2.toFixed(1)}" r="12" fill="none" stroke="#FEF08A" stroke-width="4">
                <animate attributeName="r" values="10;46" dur="0.55s" fill="freeze"/>
                <animate attributeName="opacity" values="1;0" dur="0.55s" fill="freeze"/>
            </circle>
        `;
    }

    const lbl = anim.label || '';
    const badgeLbl = lbl ? `
        <rect x="${(mx - 120).toFixed(1)}" y="${Math.max(12, my - 24).toFixed(1)}" width="240" height="21" rx="5" fill="rgba(9, 13, 22, 0.96)" stroke="#FACC15" stroke-width="1.8"/>
        <text x="${mx.toFixed(1)}" y="${Math.max(26, my - 10).toFixed(1)}" text-anchor="middle" font-size="10.2" font-weight="900" fill="#FEF08A">${lbl.slice(0, 36)}</text>
    ` : '';

    return `<g class="camada-animacao-trajetoria-2d" pointer-events="none">${vfx}${badgeLbl}</g>`;
}


function renderizarPalcoJRPG(st, a, efeitoAtivo) {
    const container = document.getElementById('jrpg-svg-scene-container');
    if (!container || !st || !a) return;
    const priv = a._privadoCriatura;
    const cenario = construirCenarioFundoJRPG(priv.grupoCap7);
    const cols = 120;
    const rows = 120;
    const gradeChao = construirGradePerspectivaChao2DSVG(cols, rows);
    const spriteHeroiBase = construirSpriteSVGHeroiJRPG(st);
    const fxSvg = construirEfeitoCoreografadoSVG(efeitoAtivo);
    const modoTokensLimpos = Boolean(window.__PALCO_MODO_TOKENS_LIMPOS__);

    const listaCriaturas = (Array.isArray(a.listaCriaturas) && a.listaCriaturas.length > 0)
        ? a.listaCriaturas
        : (a._tabuleiroSemAmeacas ? [] : [{
            indice: 0, rotulo: '#1', nomeCriatura: priv.nomeCriatura, grupoCap7: priv.grupoCap7,
            ndTexto: priv.ndTexto, papel: priv.papel || a.papelCriatura,
            pvAtual: priv.pvAtual, pvMax: priv.pvMax, defesa: priv.defesa,
            espacoQ: priv.espacoQ || 1, tamanhoCat: priv.tamanhoCat || 'Médio',
            gx: 4, gy: 2,
            condicoes: { caido: Boolean(a.criaturaCaida), desprevenido: Boolean(a.criaturaDesprevenida) }
        }]);
    const focoIdx = listaCriaturas.length > 0 ? Math.min(listaCriaturas.length - 1, Math.max(0, Number(a.alvoFocoIdx || 0))) : 0;
    const alvoFocoObj = listaCriaturas[focoIdx] || { gx: 5, gy: 2, espacoQ: 1, rotulo: '—', tamanhoCat: 'Nenhuma' };
    const posH = a.posHeroi || { gx: 56, gy: 60 };
    sincronizarCameraMapa120ComUnidadesJS([posH, a.aliadoFlanqueadorAtivo ? a.posAliadoFlanco : null], listaCriaturas, false);
    const flanqueandoAtivo = (listaCriaturas.length > 0 && typeof verificarFlanqueamentoAlvoArenaJS === 'function')
        ? verificarFlanqueamentoAlvoArenaJS(a, focoIdx) : false;

    const tamH = extrairTamanhoEEspacoT20((st.raca && st.raca.tamanho) ? st.raca.tamanho : 'Médio');
    const pegHeroi = construirPegadaIsometricaTamanhoSVG(posH.gx, posH.gy, tamH.espacoQ, cols, rows, '#4ADE80', 'rgba(34,197,94,0.28)');
    const qAlvo = Math.max(1, Number(alvoFocoObj.espacoQ || 1));
    const pegAlvoFoco = construirPegadaIsometricaTamanhoSVG(alvoFocoObj.gx, alvoFocoObj.gy, qAlvo, cols, rows, '#FACC15', 'rgba(239,68,68,0.25)');
    const heroiOlhaEsquerda = (posH.gx > alvoFocoObj.gx + (qAlvo - 1));

    const condH = a.condicoesHeroi || {};
    const overlayCondH = construirOverlayCondicoes2DSVG(216, 268, condH);
    const transfCaidoH = condH.caido ? 'translate(216, 262) rotate(-75) translate(-216, -262)' : '';
    const transfFlipH = heroiOlhaEsquerda ? 'translate(216, 0) scale(-1, 1) translate(-216, 0)' : '';

    const entidadesOrdenadas = [];
    let pegadasSVG = pegHeroi.svg;

    // 1. Herói (com escala proporcional a 1x1 ou Montaria 2x2/3x3)
    const infoMPHeroi = (typeof obterBonusMontariaEParceiroAtivosJS === 'function') ? obterBonusMontariaEParceiroAtivosJS(st) : { montado: false, espacoMontadoQ: 1, tamanhoMontadoCat: 'Médio' };
    const qHeroiReal = infoMPHeroi.montado ? Math.max(tamH.espacoQ, infoMPHeroi.espacoMontadoQ || 2) : tamH.espacoQ;
    const catHeroiReal = infoMPHeroi.montado ? (infoMPHeroi.tamanhoMontadoCat || 'Grande') : tamH.categoria;
    const pegHeroiReal = qHeroiReal !== tamH.espacoQ
        ? construirPegadaIsometricaTamanhoSVG(posH.gx, posH.gy, qHeroiReal, cols, rows, '#4ADE80', 'rgba(34,197,94,0.28)')
        : pegHeroi;
    pegadasSVG = pegHeroiReal.svg;
    const escHeroiPalco = calcularEscalaProporcionalUnidadePalco2D(pegHeroiReal, qHeroiReal, catHeroiReal, false);

    let yMinCamera = 0;
    const topHeroiEst = (pegHeroiReal.anchorY || pegHeroiReal.cy) - 165 * escHeroiPalco;
    if (topHeroiEst < 14) yMinCamera = Math.min(yMinCamera, Math.floor(topHeroiEst - 14));

    if (modoTokensLimpos) {
        const rTokH = Math.max(16, Math.round((pegHeroiReal.tileW || 38) * qHeroiReal * 0.48));
        entidadesOrdenadas.push({
            depthY: pegHeroiReal.pBotY || pegHeroiReal.cy,
            svg: `
                <g transform="translate(${pegHeroiReal.cx.toFixed(1)}, ${pegHeroiReal.cy.toFixed(1)})" style="cursor:pointer;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI', 'HEROI_PRINCIPAL', 'ARENA')">
                    <circle cx="0" cy="${(-rTokH * 0.45).toFixed(1)}" r="${rTokH}" fill="#0F172A" stroke="#4ADE80" stroke-width="2.8"/>
                    <svg x="${(-rTokH + 2).toFixed(1)}" y="${(-rTokH * 1.45 + 2).toFixed(1)}" width="${((rTokH - 2) * 2).toFixed(1)}" height="${((rTokH - 2) * 2).toFixed(1)}" viewBox="136 92 160 160" preserveAspectRatio="xMidYMid meet">${spriteHeroiBase}</svg>
                    <rect x="-32" y="${(-rTokH * 1.45 - 15).toFixed(1)}" width="64" height="13" rx="4" fill="rgba(9,13,22,0.92)" stroke="#4ADE80" stroke-width="1"/>
                    <text x="0" y="${(-rTokH * 1.45 - 5.5).toFixed(1)}" text-anchor="middle" font-size="8" font-weight="900" fill="#4ADE80">(${posH.gx + 1},${posH.gy + 1})${qHeroiReal > 1 ? ' ' + qHeroiReal + 'x' + qHeroiReal : ''}</text>
                </g>
            `
        });
    } else {
        const ayH = pegHeroiReal.anchorY || pegHeroiReal.cy;
        entidadesOrdenadas.push({
            depthY: pegHeroiReal.pBotY || pegHeroiReal.cy,
            svg: `
                <g style="cursor:pointer;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('HEROI', 'HEROI_PRINCIPAL', 'ARENA')">
                    <g transform="translate(${pegHeroiReal.cx.toFixed(1)}, ${ayH.toFixed(1)}) scale(${escHeroiPalco.toFixed(3)}) translate(-216, -262)">
                        <g transform="${transfFlipH} ${transfCaidoH}">
                            ${efeitoAtivo ? (
                                (String(efeitoAtivo).includes('INIMIGO') || String(efeitoAtivo).includes('AMEACA') || String(efeitoAtivo).includes('MONSTRO') || String(efeitoAtivo).includes('SOPRO')) ? `<animateTransform attributeName="transform" additive="sum" type="translate" values="0,0; 0,0; -18,6; 12,-4; -8,2; 0,0" dur="0.75s" repeatCount="1"/>` :
                                (String(efeitoAtivo).includes('SHIELD') || String(efeitoAtivo).includes('BUFF') || String(efeitoAtivo).includes('MAGIA') || String(efeitoAtivo) === 'MAGIC') ? `<animateTransform attributeName="transform" additive="sum" type="translate" values="0,0; 0,-18; 0,-12; 0,0" dur="0.78s" repeatCount="1"/>` :
                                `<animateTransform attributeName="transform" additive="sum" type="translate" values="0,0; 68,-10; 82,0; -8,-4; 0,0" dur="0.72s" repeatCount="1"/>`
                            ) : ''}
                            ${spriteHeroiBase}
                        </g>
                        ${overlayCondH}
                    </g>
                    <g transform="translate(${(pegHeroiReal.cx - 46).toFixed(1)}, ${(pegHeroiReal.pBotY + 2).toFixed(1)})">
                        <rect width="92" height="14" rx="4" fill="rgba(9,13,22,0.92)" stroke="#4ADE80" stroke-width="1.2"/>
                        <text x="46" y="10" text-anchor="middle" font-size="8.2" font-weight="900" fill="#4ADE80">VOCÊ (${posH.gx + 1},${posH.gy + 1})${qHeroiReal > 1 ? ' ' + qHeroiReal + 'x' + qHeroiReal : ''}</text>
                    </g>
                </g>
            `
        });
    }

    // 2. Aliado Flanqueador
    if (a.aliadoFlanqueadorAtivo && a.posAliadoFlanco) {
        const pegAli = construirPegadaIsometricaTamanhoSVG(a.posAliadoFlanco.gx, a.posAliadoFlanco.gy, 1, cols, rows, '#38BDF8', 'rgba(56,189,248,0.24)');
        pegadasSVG += pegAli.svg;
        const fakeAli = { nome: 'Aliado', nivel: 5, ehMembroPartyMesa: true, raca: { nome: 'Humano' }, classe: { nome: 'Cavaleiro' }, arma: { nome: 'Espada Longa' }, escudo: { nome: 'Escudo Pesado' }, poderes: [] };
        const spAli = construirSpriteSVGHeroiJRPG(fakeAli);
        const aliOlhaEsq = (a.posAliadoFlanco.gx >= alvoFocoObj.gx);
        const flipAli = aliOlhaEsq ? 'translate(216, 0) scale(-1, 1) translate(-216, 0)' : '';
        const escAli = calcularEscalaProporcionalUnidadePalco2D(pegAli, 1, 'Médio', false);
        if (modoTokensLimpos) {
            const rTokA = Math.max(15, Math.round((pegAli.tileW || 38) * 0.45));
            entidadesOrdenadas.push({
                depthY: pegAli.pBotY || pegAli.cy,
                svg: `
                    <g transform="translate(${pegAli.cx.toFixed(1)}, ${pegAli.cy.toFixed(1)})" style="cursor:pointer;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('ALIADO', 'ALIADO_FLANCO', 'ARENA')">
                        <circle cx="0" cy="-14" r="${rTokA}" fill="#0F172A" stroke="#38BDF8" stroke-width="2.4"/>
                        <svg x="${-rTokA + 2}" y="${-14 - rTokA + 2}" width="${(rTokA - 2) * 2}" height="${(rTokA - 2) * 2}" viewBox="136 92 160 160" preserveAspectRatio="xMidYMid meet">${spAli}</svg>
                        <text x="0" y="${-14 - rTokA - 4}" text-anchor="middle" font-size="8" font-weight="900" fill="#38BDF8">🛡️ (${a.posAliadoFlanco.gx + 1},${a.posAliadoFlanco.gy + 1})</text>
                    </g>
                `
            });
        } else {
            entidadesOrdenadas.push({
                depthY: pegAli.pBotY || pegAli.cy,
                svg: `
                    <g style="cursor:pointer;" onclick="selecionarPersonagemNoPalcoParaAcoesJS('ALIADO', 'ALIADO_FLANCO', 'ARENA')">
                        <g transform="translate(${pegAli.cx.toFixed(1)}, ${(pegAli.anchorY || pegAli.cy).toFixed(1)}) scale(${escAli.toFixed(3)}) translate(-216, -262)">
                            <g transform="${flipAli}">${spAli}</g>
                        </g>
                        <g transform="translate(${(pegAli.cx - 48).toFixed(1)}, ${(pegAli.pBotY + 2).toFixed(1)})">
                            <rect width="96" height="14" rx="4" fill="rgba(15,23,42,0.92)" stroke="#38BDF8" stroke-width="1.2"/>
                            <text x="48" y="10" text-anchor="middle" font-size="8" font-weight="900" fill="#38BDF8">🛡️ Aliado (${a.posAliadoFlanco.gx + 1},${a.posAliadoFlanco.gy + 1})</text>
                        </g>
                    </g>
                `
            });
        }
    }

    // 3. Todas as Criaturas do Encontro (com Escala Geométrica 100% Proporcional ao Espaço Ocupado: 1x1, 2x2 Grande, 3x3 Enorme e 6x6 Colossal!)
    listaCriaturas.forEach((crItem, idxC) => {
        const tamInfoItem = extrairTamanhoEEspacoT20(crItem.tamanhoCat || crItem.tipoTamanho || 'Médio');
        const qC = Math.max(1, Number(crItem.espacoQ || tamInfoItem.espacoQ || 1));
        const catC = crItem.tamanhoCat || tamInfoItem.categoria || 'Médio';
        const gxC = crItem.gx !== undefined ? crItem.gx : 4;
        const gyC = crItem.gy !== undefined ? crItem.gy : 2;
        const ehFoco = (idxC === focoIdx);
        const pegC = construirPegadaIsometricaTamanhoSVG(gxC, gyC, qC, cols, rows, ehFoco ? '#FACC15' : '#EF4444', ehFoco ? 'rgba(239,68,68,0.34)' : 'rgba(153,27,27,0.22)');
        pegadasSVG += pegC.svg;

        const morto = crItem.pvAtual <= 0;
        const condC = crItem.condicoes || {};
        const spriteBaseC = construirSpriteSVGCriaturaJRPG(crItem);
        const transfCaidoC = condC.caido ? 'translate(645, 260) rotate(76) translate(-645, -260)' : '';
        const overlayCondC = !morto ? construirOverlayCondicoes2DSVG(645, 260, condC) : '';
        const pctItem = Math.max(0, Math.min(100, (crItem.pvAtual / Math.max(1, crItem.pvMax)) * 100));
        const flipCriatura = (posH.gx > gxC + qC - 1) ? 'translate(645, 0) scale(-1, 1) translate(-645, 0)' : '';

        const escProporcionalC = calcularEscalaProporcionalUnidadePalco2D(pegC, qC, catC, true);
        const ayC = pegC.anchorY || pegC.cy;
        const opAntiOclusao = calcularOpacidadeAntiOclusaoCriatura2D(
            { gx: gxC, gy: gyC, espacoQ: qC },
            [posH, a.aliadoFlanqueadorAtivo ? a.posAliadoFlanco : null]
        );
        const layerPrioC = qC >= 2 ? 0 : 5;
        if (opAntiOclusao > 0) {
            const topCriaturaEst = ayC - 148 * escProporcionalC;
            if (topCriaturaEst < 14) {
                yMinCamera = Math.min(yMinCamera, Math.floor(topCriaturaEst - 16));
            }
        }

        if (modoTokensLimpos) {
            const rTok = Math.max(17, Math.min(48, Math.round((pegC.tileW || 38) * (qC >= 6 ? 1.55 : (qC === 3 ? 1.25 : (qC === 2 ? 1.0 : 0.52))))));
            const pfC = (typeof obterPerfilVisualUnico83AmeacasCap7 === 'function')
                ? obterPerfilVisualUnico83AmeacasCap7(crItem.nomeCriatura || crItem.nome, crItem.grupoCap7)
                : { corFundo: '#3B070B', corAnel: '#EF4444', rotuloCurto: 'AMEAÇA', viewBoxToken: '555 58 180 206' };
            entidadesOrdenadas.push({
                layerPriority: layerPrioC,
                depthY: pegC.pBotY || pegC.cy,
                svg: `
                    <g transform="translate(${pegC.cx.toFixed(1)}, ${pegC.cy.toFixed(1)})" style="cursor:pointer; ${morto ? 'opacity:0.32;filter:grayscale(1);' : ''}" onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA', ${idxC}, 'ARENA')">
                        ${opAntiOclusao > 0 ? `
                        <g opacity="${opAntiOclusao.toFixed(2)}">
                            <circle cx="0" cy="${(-rTok * 0.35).toFixed(1)}" r="${rTok}" fill="${pfC.corFundo}" stroke="${ehFoco ? '#FACC15' : pfC.corAnel}" stroke-width="${qC >= 2 ? 3.5 : 2.8}"/>
                            <svg x="${(-rTok + 3).toFixed(1)}" y="${(-rTok * 1.35 + 3).toFixed(1)}" width="${((rTok - 3) * 2).toFixed(1)}" height="${((rTok - 3) * 2).toFixed(1)}" viewBox="555 58 180 206" preserveAspectRatio="xMidYMid meet">${spriteBaseC}</svg>
                        </g>` : ''}
                        <rect x="-52" y="4" width="104" height="15" rx="4" fill="#140C1C" stroke="${ehFoco ? '#FACC15' : pfC.corAnel}" stroke-width="1.3"/>
                        <text x="0" y="14" text-anchor="middle" font-size="8.2" font-weight="900" fill="#FEF08A">${pfC.rotuloCurto} [${catC.slice(0,3).toUpperCase()} ${qC}x${qC}]</text>
                    </g>
                `
            });
        } else {
            const yPlacaC = Math.min(298, (pegC.pBotY || pegC.cy) + 2);
            entidadesOrdenadas.push({
                layerPriority: layerPrioC,
                depthY: pegC.pBotY || pegC.cy,
                svg: `
                    <g style="cursor:pointer; ${morto ? 'opacity:0.32;filter:grayscale(1);' : ''}"
                       onclick="selecionarPersonagemNoPalcoParaAcoesJS('AMEACA', ${idxC}, 'ARENA')">
                        ${opAntiOclusao > 0 ? `
                        <g opacity="${opAntiOclusao.toFixed(2)}" transform="translate(${pegC.cx.toFixed(1)}, ${ayC.toFixed(1)}) scale(${escProporcionalC.toFixed(3)}) translate(-645, -260)">
                            <g transform="${flipCriatura} ${transfCaidoC}">
                                ${(efeitoAtivo && ehFoco) ? (
                                    (String(efeitoAtivo).includes('INIMIGO') || String(efeitoAtivo).includes('AMEACA') || String(efeitoAtivo).includes('MONSTRO') || String(efeitoAtivo).includes('SOPRO')) ? `<animateTransform attributeName="transform" additive="sum" type="translate" values="0,0; -48,6; -58,0; 8,-4; 0,0" dur="0.75s" repeatCount="1"/>` :
                                    (!String(efeitoAtivo).includes('SHIELD') && !String(efeitoAtivo).includes('BUFF')) ? `<animateTransform attributeName="transform" additive="sum" type="translate" values="0,0; 0,0; 18,-6; -14,5; 10,-3; 0,0" dur="0.75s" repeatCount="1"/>` : ''
                                ) : ''}
                                ${spriteBaseC}
                            </g>
                            ${overlayCondC}
                        </g>` : ''}
                        <g transform="translate(${(pegC.cx - 78).toFixed(1)}, ${yPlacaC.toFixed(1)})">
                            <rect width="156" height="16" rx="4" fill="rgba(9,13,22,0.94)" stroke="${ehFoco ? '#FACC15' : '#EF4444'}" stroke-width="1.5"/>
                            <rect x="2" y="2" width="${Math.round(1.52 * pctItem)}" height="12" rx="3" fill="${morto ? '#475569' : '#DC2626'}"/>
                            <text x="78" y="11.5" text-anchor="middle" font-size="8.4" font-weight="900" fill="#FFF">${crItem.rotulo} ${catC} (${qC}x${qC}=${(qC*1.5).toFixed(1)}m) · ${Math.max(0, crItem.pvAtual)}/${crItem.pvMax}</text>
                        </g>
                    </g>
                `
            });
        }
    });

    // REGRA ANTI-OCLUSÃO (v64): Heróis e Aliados têm prioridade de camada sobre Criaturas Grandes/Enormes/Colossais,
    // garantindo que nenhuma ameaça colossal jamais tampe ou esconda um personagem na tela!
    entidadesOrdenadas.sort((e1, e2) => {
        const p1 = e1.layerPriority !== undefined ? e1.layerPriority : 10;
        const p2 = e2.layerPriority !== undefined ? e2.layerPriority : 10;
        if (p1 !== p2) return p1 - p2;
        return e1.depthY - e2.depthY;
    });
    const spritesOrdenadosSVG = entidadesOrdenadas.map(e => e.svg).join('\n');

    const distMetros = (typeof calcularDistanciaMetrosAlvoArenaJS === 'function')
        ? calcularDistanciaMetrosAlvoArenaJS(a, focoIdx) : 1.5;
    const corAlcance = distMetros <= 1.5 ? '#4ADE80' : (distMetros <= 9 ? '#38BDF8' : '#F59E0B');
    const txtAlcance = distMetros <= 1.5 ? '⚔️ Corpo a Corpo (1,5m)' : (distMetros <= 9 ? `🏹 Alcance Curto (${distMetros.toFixed(1)}m)` : `🔭 Alcance Médio (${distMetros.toFixed(1)}m)`);

    let svgLinhasTaticas = `
        <g opacity="0.88" pointer-events="none">
            <line x1="${pegHeroiReal.cx.toFixed(1)}" y1="${pegHeroiReal.cy.toFixed(1)}" x2="${pegAlvoFoco.cx.toFixed(1)}" y2="${pegAlvoFoco.cy.toFixed(1)}" stroke="${corAlcance}" stroke-width="2.2" stroke-dasharray="6 4"/>
            <rect x="${((pegHeroiReal.cx + pegAlvoFoco.cx) / 2 - 72).toFixed(1)}" y="${((pegHeroiReal.cy + pegAlvoFoco.cy) / 2 - 18).toFixed(1)}" width="144" height="17" rx="5" fill="rgba(9,13,22,0.92)" stroke="${corAlcance}" stroke-width="1.2"/>
            <text x="${((pegHeroiReal.cx + pegAlvoFoco.cx) / 2).toFixed(1)}" y="${((pegHeroiReal.cy + pegAlvoFoco.cy) / 2 - 6).toFixed(1)}" text-anchor="middle" font-size="9" font-weight="900" fill="${corAlcance}">${txtAlcance}</text>
        </g>
    `;
    if (flanqueandoAtivo && a.posAliadoFlanco) {
        const pegAli = construirPegadaIsometricaTamanhoSVG(a.posAliadoFlanco.gx, a.posAliadoFlanco.gy, 1, cols, rows, '#38BDF8', 'none');
        svgLinhasTaticas += `
            <g pointer-events="none">
                <line x1="${pegHeroiReal.cx.toFixed(1)}" y1="${(pegHeroiReal.cy - 10).toFixed(1)}" x2="${pegAli.cx.toFixed(1)}" y2="${(pegAli.cy - 10).toFixed(1)}" stroke="#FACC15" stroke-width="3" stroke-dasharray="9 4"/>
                <rect x="${(pegAlvoFoco.cx - 76).toFixed(1)}" y="${yMinCamera + 14}" width="152" height="18" rx="6" fill="rgba(180,83,9,0.95)" stroke="#FEF08A" stroke-width="1.5"/>
                <text x="${pegAlvoFoco.cx.toFixed(1)}" y="${yMinCamera + 26}" text-anchor="middle" font-size="9.5" font-weight="900" fill="#FEF08A">⚔️ FLANQUEADO (+2 ATQ)</text>
            </g>
        `;
    }

    const pctH = Math.max(0, Math.min(100, (a.pvHeroi / Math.max(1, a.pvHeroiMax)) * 100));
    const pctM = Math.max(0, Math.min(100, (a.pmHeroi / Math.max(1, a.pmHeroiMax)) * 100));
    const pctC = Math.max(0, Math.min(100, (priv.pvAtual / Math.max(1, priv.pvMax)) * 100));
    const defH = a.defHeroiBase + a.bonusDefTemp + (a.coberturaAtiva ? 5 : 0) - (a.investidaPenalidadeDef ? 2 : 0) - (condH.caido || condH.desprevenido ? 5 : 0) + (a.armaduraArcanaCenaBonus || (a.armaduraArcanaCena ? 5 : 0));
    const selVis = document.getElementById('arena-sel-estilo-visual');
    const modoVis = selVis ? selVis.value : 'HD2D';
    const filtroPixel = modoVis === 'PIXEL16' ? 'shape-rendering="crispEdges"' : '';
    const yHudTop = yMinCamera + 10;
    const vbHeight = 318 - yMinCamera;

    const placaHeroiSVG = `
        <g transform="translate(12, ${yHudTop})" ${filtroPixel}>
            <rect width="224" height="58" rx="8" fill="rgba(9,13,22,0.9)" stroke="#D4AF37" stroke-width="1.8"/>
            <text x="10" y="16" font-size="10.5" font-weight="900" fill="#FDE047">${st.nome.slice(0, 16)}</text>
            <text x="214" y="16" text-anchor="end" font-size="10" font-weight="900" fill="#93C5FD">🛡️ DEF ${defH}</text>
            <rect x="10" y="22" width="204" height="10" rx="4" fill="#1E293B"/>
            <rect x="10" y="22" width="${Math.round(2.04 * pctH)}" height="10" rx="4" fill="#16A34A"/>
            <text x="112" y="30" text-anchor="middle" font-size="8.2" font-weight="900" fill="#FFF">PV ${Math.round(a.pvHeroi)}/${a.pvHeroiMax}</text>
            <rect x="10" y="37" width="204" height="10" rx="4" fill="#1E293B"/>
            <rect x="10" y="37" width="${Math.round(2.04 * pctM)}" height="10" rx="4" fill="#0284C7"/>
            <text x="112" y="45" text-anchor="middle" font-size="8.2" font-weight="900" fill="#FFF">PM ${Math.round(a.pmHeroi)}/${a.pmHeroiMax} · ⚡${a.acoesPadraoRestantes}P 🦶${a.acoesMovimentoRestantes}M</text>
        </g>
    `;

    const vivosCount = listaCriaturas.filter(x => x.pvAtual > 0).length;
    const placaInimigoSVG = listaCriaturas.length === 0 ? `
        <g transform="translate(622, ${yHudTop})" shape-rendering="crispEdges">
            <rect width="226" height="44" rx="6" fill="rgba(24,9,14,0.92)" stroke="#64748B" stroke-width="1.8"/>
            <text x="113" y="19" text-anchor="middle" font-size="10" font-weight="900" fill="#FCA5A5">Tabuleiro Sem Ameaças</text>
            <text x="113" y="34" text-anchor="middle" font-size="8.5" font-weight="700" fill="#FDE047">Use ➕ Adicionar Ameaça na gaveta</text>
        </g>
    ` : `
        <g transform="translate(622, ${yHudTop})" ${filtroPixel}>
            <rect width="226" height="54" rx="8" fill="rgba(24,9,14,0.9)" stroke="#EF4444" stroke-width="1.8"/>
            <text x="10" y="16" font-size="10.5" font-weight="900" fill="#FCA5A5">${(priv.nomeCriatura || 'Ameaça').slice(0, 15)} (${vivosCount}/${listaCriaturas.length})</text>
            <text x="216" y="16" text-anchor="end" font-size="9.5" font-weight="900" fill="#FACC15">ND ${priv.ndTexto}</text>
            <rect x="10" y="22" width="206" height="10" rx="4" fill="#1E293B"/>
            <rect x="10" y="22" width="${Math.round(2.06 * pctC)}" height="10" rx="4" fill="#DC2626"/>
            <text x="113" y="30" text-anchor="middle" font-size="8.2" font-weight="900" fill="#FFF">${alvoFocoObj.rotulo}: ${Math.max(0, priv.pvAtual)}/${priv.pvMax} PV</text>
            <text x="10" y="46" font-size="8.5" font-weight="700" fill="#E2E8F0">${alvoFocoObj.tamanhoCat || 'Médio'} (${qAlvo}x${qAlvo} = ${(qAlvo*1.5).toFixed(1)}m)</text>
            <g style="cursor:pointer;" onclick="removerCriaturaDoEncontroArenaJS(${focoIdx})">
                <rect x="144" y="35" width="72" height="15" rx="4" fill="#7F1D1D" stroke="#FCA5A5" stroke-width="1"/>
                <text x="180" y="45.5" text-anchor="middle" font-size="8" font-weight="900" fill="#FEF08A">🗑️ EXCLUIR</text>
            </g>
        </g>
    `;

    const defsHD2D = `
        <defs>
            <filter id="hd2dSpriteGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#000000" flood-opacity="0.88"/>
            </filter>
            <radialGradient id="hd2dVignette" cx="50%" cy="50%" r="55%">
                <stop offset="60%" stop-color="#000000" stop-opacity="0"/>
                <stop offset="100%" stop-color="#000000" stop-opacity="0.52"/>
            </radialGradient>
        </defs>
    `;

    const ehFullscreenAtivo = Boolean(window.__TELA_CHEIA_COMBATE_ATIVA__ === 'ARENA');
    const maxHeightSvg = ehFullscreenAtivo ? 'calc(100vh - 185px)' : '350px';

    container.innerHTML = `
        <svg viewBox="0 ${yMinCamera} 860 ${vbHeight}" width="100%" xmlns="http://www.w3.org/2000/svg" shape-rendering="geometricPrecision" text-rendering="optimizeLegibility" preserveAspectRatio="xMidYMid meet" style="display:block;width:100%;height:auto;max-height:${maxHeightSvg};" ${filtroPixel}>
            ${defsHD2D}
            ${yMinCamera < 0 ? `<rect x="0" y="${yMinCamera}" width="860" height="${Math.abs(yMinCamera) + 20}" fill="#070510"/>` : ''}
            ${cenario}
            ${gradeChao}
            ${pegadasSVG}
            ${typeof construirTrilhaMovimentoAtivaSVG === "function" ? construirTrilhaMovimentoAtivaSVG(cols, rows, "ARENA") : ""}
            ${svgLinhasTaticas}
            <g shape-rendering="geometricPrecision" text-rendering="optimizeLegibility">
                ${spritesOrdenadosSVG}
            </g>
            ${fxSvg}
            ${typeof construirCamadaAnimacaoTrajetoria2DSVG === 'function' ? construirCamadaAnimacaoTrajetoria2DSVG(cols, rows) : ''}
            <rect x="0" y="${yMinCamera}" width="860" height="${vbHeight}" fill="url(#hd2dVignette)" pointer-events="none"/>
            ${placaHeroiSVG}
            ${placaInimigoSVG}
        </svg>
    `;
    if (typeof renderizarPainelTatico2DArenaJS === 'function') {
        renderizarPainelTatico2DArenaJS();
    }
}

function dispararPopupDanoJRPG(texto, corHex, ladoAlvo, tipoEfeito, textoBanner) {
    try { tocarSomPorEfeitoAnimacaoJRPG(tipoEfeito || 'SLASH'); } catch(e) {}
    const st = garantirEstadoFichaParaArena();
    if (__ARENA_STATE__) {
        const a = __ARENA_STATE__;
        const focoC = (Array.isArray(a.listaCriaturas) && a.listaCriaturas[a.alvoFocoIdx || 0]) ? a.listaCriaturas[a.alvoFocoIdx || 0] : { gx: 4, gy: 2 };
        const posH = a.posHeroi || { gx: 2, gy: 2 };
        window.__EFEITO_ARENA_ATIVO__ = { tipo: tipoEfeito || 'SLASH', ladoAlvo: ladoAlvo || 'INIMIGO', timestamp: Date.now() };
        dispararAnimacaoCoreografadaPalco2DJS({
            tipo: tipoEfeito || 'SLASH',
            ladoAlvo: ladoAlvo || 'INIMIGO',
            origem: ladoAlvo === 'HEROI' ? { gx: focoC.gx || 4, gy: focoC.gy || 2 } : { gx: posH.gx || 2, gy: posH.gy || 2 },
            destino: ladoAlvo === 'HEROI' ? { gx: posH.gx || 2, gy: posH.gy || 2 } : { gx: focoC.gx || 4, gy: focoC.gy || 2 },
            label: texto
        });
        const gHero = document.getElementById('jrpg-hero-sprite-group');
        const gEnemy = document.getElementById('jrpg-enemy-sprite-group');
        const stageWrap = document.getElementById('jrpg-battle-stage');

        if (ladoAlvo === 'INIMIGO' && gHero) {
            let clsAnimHero = 'jrpg-anim-sword';
            if (tipoEfeito === 'ANIM_IMPACTO_ESMAGADOR') clsAnimHero = 'jrpg-anim-slam';
            else if (tipoEfeito === 'ANIM_ESTOCADA_LANCEIRO') clsAnimHero = 'jrpg-anim-thrust';
            else if (tipoEfeito === 'ANIM_DISPARO_DISTANCIA') clsAnimHero = 'jrpg-anim-ranged';
            else if (tipoEfeito && (tipoEfeito.includes('MAGIA') || tipoEfeito === 'MAGIC')) clsAnimHero = 'jrpg-anim-cast';

            gHero.classList.add(clsAnimHero);
            setTimeout(() => gHero.classList.remove(clsAnimHero), 760);
        } else if (ladoAlvo === 'HEROI' && gEnemy) {
            const clsAnimEnemy = (tipoEfeito === 'ANIM_INIMIGO_SOPRO' || tipoEfeito === 'ANIM_INIMIGO_MAGIA_OLHAR')
                ? 'jrpg-anim-enemy-breath'
                : 'jrpg-anim-enemy-pounce';
            gEnemy.classList.add(clsAnimEnemy);
            setTimeout(() => gEnemy.classList.remove(clsAnimEnemy), 780);
        }

        if (stageWrap && (tipoEfeito === 'ANIM_IMPACTO_ESMAGADOR' || tipoEfeito === 'ANIM_INIMIGO_SOPRO' || tipoEfeito === 'ANIM_MAGIA_FOGO')) {
            stageWrap.classList.add('jrpg-stage-shake');
            setTimeout(() => stageWrap.classList.remove('jrpg-stage-shake'), 520);
        }
    }
    const banner = document.getElementById('jrpg-action-banner');
    if (banner && textoBanner) banner.innerHTML = textoBanner;

    const popBox = document.getElementById('jrpg-floating-popups');
    if (!popBox) return;
    const div = document.createElement('div');
    div.className = 'jrpg-dmg-popup';
    div.style.color = corHex || '#FACC15';
    div.style.left = ladoAlvo === 'INIMIGO' ? (60 + Math.floor(Math.random() * 14)) + '%' : (16 + Math.floor(Math.random() * 12)) + '%';
    div.style.top = (34 + Math.floor(Math.random() * 16)) + '%';
    div.innerHTML = texto;
    popBox.appendChild(div);
    setTimeout(() => { if (div.parentNode) div.parentNode.removeChild(div); }, 1450);
}

function calcularLimitePMMagiaFichaJS(st) {
    const todosPods = [
        ...((st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ].map(p => (p.nome || '').toLowerCase());
    const sigChave = (st.est && st.est.infoMagia && st.est.infoMagia.sigla) ? st.est.infoMagia.sigla : 'INT';
    const valChave = (st.est && st.est.finais && st.est.finais[sigChave] !== undefined) ? st.est.finais[sigChave] : 0;
    const bonusMagiaIlimitada = todosPods.includes('magia ilimitada') ? Math.max(0, valChave) : 0;
    const bonusCajado = (st.arma && (st.arma.nome || '').toLowerCase().includes('cajado arcano')) ? 1 : 0;
    return Math.max(1, (st.nivel || 1) + bonusMagiaIlimitada + bonusCajado);
}

function calcularOpcoesAprimoramentoMagiaJS(magiaObj, st, pmDisponivel) {
    if (!magiaObj) return [];
    const custoPorCirculo = { 1: 1, 2: 3, 3: 6, 4: 10, 5: 15 };
    const todosPods = [
        ...((st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ].map(p => (p.nome || '').toLowerCase());
    const nr = (st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : '';
    const redPM = (todosPods.includes('foco em magia') || nr === 'qareen') ? 1 : 0;
    const custoBaseBruto = custoPorCirculo[magiaObj.circulo] || 1;
    const custoBase = Math.max(1, custoBaseBruto - redPM);
    const limitePM = calcularLimitePMMagiaFichaJS(st);
    const maxExtras = Math.max(0, limitePM - custoBase);
    const nm = (magiaObj.nome || '').toLowerCase();
    const efTxt = magiaObj.efeito_e_aprimoramentos || '';

    // Extrai cláusulas oficiais "+X PM: ..." do texto da magia no livro
    const clausulas = [];
    const regexAprim = /\+(\d+)\s*PM\s*:\s*([^.;]+(?:\.[^+;]*)?)/gi;
    let match;
    while ((match = regexAprim.exec(efTxt)) !== null) {
        clausulas.push({ custo: parseInt(match[1], 10), desc: match[2].trim() });
    }

    const opcoes = [];
    for (let addPM = 0; addPM <= maxExtras; addPM++) {
        const custoTotal = custoBase + addPM;
        let descNivel = '';
        let qtdDados = 0;
        let facesDado = 6;
        let bonusFixo = 0;
        let ehCura = nm.includes('curar ferimentos') || nm.includes('sopro da salvação') || nm.includes('segunda chance');
        let ehBuffDefesa = nm.includes('armadura arcana') || nm.includes('escudo da fé') || nm.includes('vestimenta da fé');
        let ehBuffPVTemp = nm.includes('campo de força') || nm.includes('vitalidade fantasma');
        let ehVelocidade = nm.includes('velocidade');
        let ehConcentracao = nm.includes('concentração de combate');

        if (nm.includes('bola de fogo') || nm.includes('relâmpago')) {
            const passos2 = Math.floor(addPM / 2);
            qtdDados = 6 + passos2 * 2;
            facesDado = 6;
            descNivel = addPM === 0
                ? `Efeito Base (${qtdDados}d6 de dano, ${magiaObj.resistencia})`
                : `+${passos2}x Aprimoramento (+2d6/2 PM) ➔ ${qtdDados}d6 de dano (${magiaObj.resistencia})`;
        } else if (nm.includes('seta infalível')) {
            const setas = 2 + Math.floor(addPM / 2);
            qtdDados = setas;
            facesDado = 4;
            bonusFixo = setas;
            descNivel = addPM === 0
                ? `Efeito Base: 2 setas de energia (${qtdDados}d4+${bonusFixo} dano de essência, sem teste de resistência!)`
                : `Aprimorado: ${setas} setas/lanças de energia (${qtdDados}d4+${bonusFixo} dano garantido!)`;
        } else if (nm.includes('toque chocante')) {
            qtdDados = 2 + addPM;
            facesDado = 8;
            bonusFixo = 2 + addPM;
            descNivel = addPM === 0
                ? `Efeito Base: ${qtdDados}d8+${bonusFixo} dano de eletricidade`
                : `+${addPM}x Aprimoramento (+1d8+1/PM) ➔ ${qtdDados}d8+${bonusFixo} dano de eletricidade`;
        } else if (nm.includes('explosão de chamas')) {
            const passos1 = Math.floor(addPM / 1);
            qtdDados = 2 + passos1;
            facesDado = 6;
            descNivel = addPM === 0
                ? `Efeito Base: cone 6m causando 2d6 dano de fogo`
                : `+${addPM} PM: ${qtdDados}d6 dano de fogo em cone`;
        } else if (nm.includes('curar ferimentos')) {
            qtdDados = 2 + addPM;
            facesDado = 8;
            bonusFixo = 2 + addPM;
            descNivel = addPM === 0
                ? `Efeito Base: cura ${qtdDados}d8+${bonusFixo} PV`
                : `+${addPM}x Aprimoramento (+1d8+1/PM) ➔ cura ${qtdDados}d8+${bonusFixo} PV`;
        } else if (nm.includes('infligir ferimentos')) {
            qtdDados = 2 + addPM;
            facesDado = 8;
            bonusFixo = 2 + addPM;
            descNivel = addPM === 0
                ? `Efeito Base: ${qtdDados}d8+${bonusFixo} dano de trevas`
                : `+${addPM}x Aprimoramento (+1d8+1/PM) ➔ ${qtdDados}d8+${bonusFixo} dano de trevas`;
        } else if (nm.includes('armadura arcana')) {
            const bDef = 5 + Math.floor(addPM / 2);
            bonusFixo = bDef;
            descNivel = addPM === 0
                ? `Efeito Base (Cena): +5 na Defesa`
                : `Aprimorado (+${Math.floor(addPM / 2)}x +2 PM): +${bDef} na Defesa pela cena`;
        } else if (nm.includes('escudo da fé')) {
            const bDef = 2 + Math.floor(addPM / 2);
            bonusFixo = bDef;
            descNivel = addPM === 0
                ? `Efeito Base (Reação/Turno): +2 na Defesa`
                : `Aprimorado: +${bDef} na Defesa pela cena`;
        } else if (nm.includes('campo de força')) {
            const pvT = 30 + Math.floor(addPM / 2) * 10;
            bonusFixo = pvT;
            descNivel = addPM === 0
                ? `Efeito Base (Cena): Recebe 30 PV Temporários`
                : `Aprimorado: Recebe ${pvT} PV Temporários`;
        } else if (nm.includes('vitalidade fantasma')) {
            qtdDados = 2 + addPM;
            facesDado = 8;
            descNivel = addPM === 0
                ? `Efeito Base: Recebe 2d8 PV Temporários`
                : `+${addPM}x Aprimoramento (+1d8/PM): Recebe ${qtdDados}d8 PV Temporários`;
        } else if (nm.includes('concentração de combate')) {
            descNivel = addPM === 0
                ? `Efeito Base (Livre, 1 rodada): Rola 2d20 nos testes de ataque e usa o MELHOR resultado`
                : (addPM >= 2
                    ? `Aprimorado (+2 PM, Sustentada pela Cena): Rola 2d20 em todos os ataques na cena e usa o MELHOR resultado!`
                    : `Efeito Base +${addPM} PM: Rola 2d20 no ataque e usa o MELHOR resultado`);
        } else if (nm.includes('velocidade')) {
            descNivel = addPM === 0
                ? `Efeito Base (Sustentada): Recebe +1 Ação Padrão ou de Movimento extra por turno`
                : `Aprimorado (+${addPM} PM): +1 Ação Padrão ou de Movimento extra por turno`;
        } else {
            qtdDados = Math.max(2, magiaObj.circulo * 2 + Math.floor(addPM / 2));
            facesDado = 8;
            bonusFixo = magiaObj.circulo * 2 + addPM;
            const clMatch = clausulas.find(c => c.custo === addPM) || clausulas[0];
            descNivel = addPM === 0
                ? `Efeito Base (${qtdDados}d${facesDado}+${bonusFixo} — ${efTxt.slice(0, 68)}...)`
                : `Aprimorado (+${addPM} PM${clMatch ? ': ' + clMatch.desc.slice(0, 58) : ''}) ➔ ${qtdDados}d${facesDado}+${bonusFixo}`;
        }

        opcoes.push({
            addPM,
            custoBase,
            custoTotal,
            limitePM,
            disponivel: pmDisponivel >= custoTotal,
            qtdDados,
            facesDado,
            bonusFixo,
            ehCura,
            ehBuffDefesa,
            ehBuffPVTemp,
            ehVelocidade,
            ehConcentracao,
            descNivel,
            labelOption: `${addPM === 0 ? '0 Aprimoramentos (Base)' : '+' + addPM + ' PM em Aprimoramentos'} [Total: ${custoTotal} PM / Limite ${limitePM} PM] — ${descNivel}`
        });
    }
    return opcoes;
}

function aoMudarMagiaSelecionadaArenaJS() {
    if (!__ARENA_STATE__) return;
    const st = garantirEstadoFichaParaArena();
    const a = __ARENA_STATE__;
    const selMag = document.getElementById('arena-sel-magia-ficha');
    const selAprim = document.getElementById('arena-sel-aprimoramento-pm');
    const boxPrev = document.getElementById('arena-preview-magia-aprimorada');
    if (!selMag || !selAprim) return;

    const idMag = selMag.value;
    const magObj = (st.magias || []).find(m => m.id_magia === idMag || m.nome === idMag) || (st.magias || [])[0];
    if (!magObj) {
        selAprim.innerHTML = '<option value="0">Nenhuma magia na ficha</option>';
        if (boxPrev) boxPrev.innerHTML = 'Este personagem não possui magias na ficha.';
        return;
    }

    const opcoes = calcularOpcoesAprimoramentoMagiaJS(magObj, st, a.pmHeroi);
    const valAnterior = parseInt(selAprim.value || '0', 10);
    selAprim.innerHTML = opcoes.map(op =>
        `<option value="${op.addPM}" ${!op.disponivel ? 'disabled' : ''}>${op.labelOption}${!op.disponivel ? ' (PM Insuficiente)' : ''}</option>`
    ).join('');
    if (opcoes.some(o => o.addPM === valAnterior && o.disponivel)) {
        selAprim.value = String(valAnterior);
    } else {
        selAprim.value = '0';
    }
    atualizarPreviewAprimoramentoMagiaArenaJS();
}

function atualizarPreviewAprimoramentoMagiaArenaJS() {
    if (!__ARENA_STATE__) return;
    const st = garantirEstadoFichaParaArena();
    const a = __ARENA_STATE__;
    const selMag = document.getElementById('arena-sel-magia-ficha');
    const selAprim = document.getElementById('arena-sel-aprimoramento-pm');
    const boxPrev = document.getElementById('arena-preview-magia-aprimorada');
    const btnConjurar = document.getElementById('btn-arena-conjurar-selecionada');
    if (!selMag || !selAprim || !boxPrev) return;

    const magObj = (st.magias || []).find(m => m.id_magia === selMag.value || m.nome === selMag.value) || (st.magias || [])[0];
    if (!magObj) return;
    const addPM = parseInt(selAprim.value || '0', 10);
    const opcoes = calcularOpcoesAprimoramentoMagiaJS(magObj, st, a.pmHeroi);
    const op = opcoes.find(x => x.addPM === addPM) || opcoes[0];

    const chkAcelerada = document.getElementById('chk-arena-magia-acelerada');
    const usaAcelerada = Boolean(chkAcelerada && chkAcelerada.checked && chkAcelerada.offsetParent !== null);
    const custoFinal = op.custoTotal + (usaAcelerada ? 4 : 0);
    const acaoReal = usaAcelerada ? 'Ação Livre (Magia Acelerada +4 PM)' : `Ação ${magObj.execucao}`;

    boxPrev.innerHTML = `
        <strong>📜 ${magObj.nome}</strong> (${magObj.circulo}º Círculo · ${magObj.escola} · Execução: <strong>${acaoReal}</strong> · Alcance: ${magObj.alcance} · Resistência: <strong>${magObj.resistencia} [CD ${st.est.cdMagia}]</strong>)<br>
        <span style="color:#FDE047;">⚡ <strong>Configuração Escolhida:</strong> Custo Base ${op.custoBase} PM + <strong>${op.addPM} PM em Aprimoramentos</strong>${usaAcelerada ? ' + 4 PM (Magia Acelerada)' : ''} = <strong>${custoFinal} PM Total</strong> (Limite da Ficha: ${op.limitePM} PM) ➔ ${op.descNivel}</span><br>
        <span style="font-size:11px;color:#CBD5E1;">📖 <em>Texto Oficial do Livro: ${magObj.efeito_e_aprimoramentos}</em></span>
    `;
    if (btnConjurar) {
        btnConjurar.innerHTML = `🔮 Conjurar ${magObj.nome} (${op.addPM > 0 ? '+' + op.addPM + ' PM Aprim. · ' : ''}Total ${custoFinal} PM · ${usaAcelerada ? 'Livre' : magObj.execucao})`;
    }
}

// ==============================================================================
// LISTAGEM ESTRITA DE REAÇÕES QUE EXISTEM NA FICHA DO PERSONAGEM (LIVRO BÁSICO T20 JdA)
// ==============================================================================
function listarReacoesDisponiveisHeroiJS(st, a, ataquePendente) {
    const opcoes = [];
    const nc = (st.classe && st.classe.nome) ? st.classe.nome.toLowerCase() : '';
    const nr = (st.raca && st.raca.nome) ? st.raca.nome.toLowerCase() : '';
    const memOst = (st.est && st.est.racaAnteriorOsteon) ? st.est.racaAnteriorOsteon.toLowerCase() : '';
    const magias = (st.magias || []).map(m => (m.nome || '').toLowerCase());
    const todosPods = [
        ...((st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ].map(p => (p.nome || '').toLowerCase());

    const ehAtaqueFisico = ataquePendente && ataquePendente.tipo === 'ATAQUE_FISICO';
    const ehTesteResistencia = ataquePendente && ataquePendente.tipo === 'EFEITO_RESISTENCIA';
    const limitePM = calcularLimitePMMagiaFichaJS(st);

    // 1. Magia na Ficha: Armadura Arcana (Livro p. 179 — Aprimoramento +1 PM muda execução para Reação: +5 na Defesa; +2 PM aumenta em +1)
    if (magias.some(n => n.includes('armadura arcana'))) {
        const evitaBase = ehAtaqueFisico && ataquePendente.acertouOriginal && !ataquePendente.ehCrit20 && (ataquePendente.totAtq < (ataquePendente.defAlvoOriginal + 5));
        opcoes.push({
            id: 'REACAO_ARMADURA_ARCANA_2PM',
            nome: `🛡️ Armadura Arcana [Reação +1 PM = 2 PM] (Livro p. 179)`,
            custoPM: 2,
            disponivel: a.pmHeroi >= 2,
            destaque: evitaBase,
            efeitoResumo: `+5 na Defesa contra este ataque (${evitaBase ? '★ TRANSFORMA O ACERTO EM ERRO!' : 'Defesa sobe p/ ' + (ataquePendente ? ataquePendente.defAlvoOriginal + 5 : a.defHeroiBase + 5)})`
        });
        if (limitePM >= 4) {
            const pmMaxAA = Math.min(limitePM, a.pmHeroi, 6);
            const extras2 = Math.floor((pmMaxAA - 2) / 2);
            if (extras2 >= 1) {
                const custoAAAprim = 2 + extras2 * 2;
                const bDefAA = 5 + extras2;
                const evitaAprim = ehAtaqueFisico && ataquePendente.acertouOriginal && !ataquePendente.ehCrit20 && (ataquePendente.totAtq < (ataquePendente.defAlvoOriginal + bDefAA));
                opcoes.push({
                    id: `REACAO_ARMADURA_ARCANA_APRIM_${custoAAAprim}_${bDefAA}`,
                    nome: `🛡️ Armadura Arcana Aprimorada [Reação — ${custoAAAprim} PM] (Livro p. 179)`,
                    custoPM: custoAAAprim,
                    disponivel: a.pmHeroi >= custoAAAprim,
                    destaque: evitaAprim && !evitaBase,
                    efeitoResumo: `+${bDefAA} na Defesa contra este ataque (Reação +1 PM + ${extras2}x Aprimoramento +2 PM)`
                });
            }
        }
    }

    // 2. Magia na Ficha: Campo de Força (Livro p. 182 — Aprimoramento +1 PM muda execução para Reação: RD 30 contra o próximo dano; +3 PM [4º círc] muda p/ RD 50)
    if (magias.some(n => n.includes('campo de força'))) {
        opcoes.push({
            id: 'REACAO_CAMPO_DE_FORCA_30',
            nome: `🔮 Campo de Força [Reação +1 PM = 4 PM] (Livro p. 182)`,
            custoPM: 4,
            disponivel: a.pmHeroi >= 4 && limitePM >= 4,
            destaque: true,
            efeitoResumo: `Recebe RD 30 contra o próximo dano que sofrer (reduz de ${ataquePendente ? ataquePendente.danoPrevisto : 25} para ${ataquePendente ? Math.max(0, ataquePendente.danoPrevisto - 30) : 0}!)`
        });
        if (circuloMaximoPermitido(st.classe, st.nivel) >= 4 && limitePM >= 6) {
            opcoes.push({
                id: 'REACAO_CAMPO_DE_FORCA_50',
                nome: `🔮 Campo de Força Aprimorado [Reação — 6 PM] (Livro p. 182)`,
                custoPM: 6,
                disponivel: a.pmHeroi >= 6,
                destaque: false,
                efeitoResumo: `Aprimoramento 4º Círculo: Recebe RD 50 contra o próximo dano que sofrer!`
            });
        }
    }

    // 3. Magia na Ficha: Salto Dimensional (Livro p. 205 — Aprimoramento +1 PM muda execução para Reação: +5 na Defesa ou Reflexos e salta 1,5m)
    if (magias.some(n => n.includes('salto dimensional'))) {
        opcoes.push({
            id: 'REACAO_SALTO_DIMENSIONAL',
            nome: `🌀 Salto Dimensional [Reação +1 PM = 4 PM] (Livro p. 205)`,
            custoPM: 4,
            disponivel: a.pmHeroi >= 4 && limitePM >= 4,
            destaque: false,
            efeitoResumo: `Salta para espaço adjacente (1,5m) e recebe +5 na Defesa ou em Reflexos contra este ataque/efeito!`
        });
    }

    // 4. Magia na Ficha: Escudo da Fé (Livro p. 191 — Execução Nativa Reação, 1 PM: +2 na Defesa por 1 turno; +2 PM aumenta em +1)
    if (magias.some(n => n.includes('escudo da fé'))) {
        opcoes.push({
            id: 'REACAO_ESCUDO_DA_FE_BASE',
            nome: `✨ Escudo da Fé [Reação — 1 PM] (Livro p. 191)`,
            custoPM: 1,
            disponivel: a.pmHeroi >= 1,
            destaque: ehAtaqueFisico,
            efeitoResumo: `Execução Reação: Recebe +2 na Defesa por 1 turno!`
        });
        if (limitePM >= 3 && a.pmHeroi >= 3) {
            const extEF = Math.min(3, Math.floor((Math.min(limitePM, a.pmHeroi) - 1) / 2));
            const pmEF = 1 + extEF * 2;
            const bEF = 2 + extEF;
            opcoes.push({
                id: `REACAO_ESCUDO_DA_FE_APRIM_${pmEF}_${bEF}`,
                nome: `✨ Escudo da Fé Aprimorado [Reação — ${pmEF} PM] (Livro p. 191)`,
                custoPM: pmEF,
                disponivel: a.pmHeroi >= pmEF,
                destaque: false,
                efeitoResumo: `Com +${extEF}x Aprimoramento (+2 PM): Recebe +${bEF} na Defesa!`
            });
        }
    }

    // 5. Magia na Ficha: Proteção Divina (Livro p. 201 — Execução Nativa Reação, 1 PM: +2 em Testes de Resistência por 1 turno; +2 PM aumenta em +1)
    if (magias.some(n => n.includes('proteção divina'))) {
        opcoes.push({
            id: 'REACAO_PROTECAO_DIVINA_BASE',
            nome: `🙏 Proteção Divina [Reação — 1 PM] (Livro p. 201)`,
            custoPM: 1,
            disponivel: a.pmHeroi >= 1,
            destaque: ehTesteResistencia,
            efeitoResumo: `Execução Reação: Recebe +2 nos Testes de Resistência por 1 turno!`
        });
        if (limitePM >= 3 && a.pmHeroi >= 3) {
            const extPD = Math.min(3, Math.floor((Math.min(limitePM, a.pmHeroi) - 1) / 2));
            const pmPD = 1 + extPD * 2;
            const bPD = 2 + extPD;
            opcoes.push({
                id: `REACAO_PROTECAO_DIVINA_APRIM_${pmPD}_${bPD}`,
                nome: `🙏 Proteção Divina Aprimorada [Reação — ${pmPD} PM] (Livro p. 201)`,
                custoPM: pmPD,
                disponivel: a.pmHeroi >= pmPD,
                destaque: ehTesteResistencia,
                efeitoResumo: `Com +${extPD}x Aprimoramento (+2 PM): Recebe +${bPD} no Teste de Resistência!`
            });
        }
    }

    // 6. Magia na Ficha: Queda Suave (Livro p. 202 — Reação, 1 PM; Aprimoramento +1 PM reduz à metade o dano de um projétil/disparo)
    if (magias.some(n => n.includes('queda suave'))) {
        opcoes.push({
            id: 'REACAO_QUEDA_SUAVE_PROJETIL',
            nome: `🍃 Queda Suave c/ Aprimoramento [Reação — 2 PM] (Livro p. 202)`,
            custoPM: 2,
            disponivel: a.pmHeroi >= 2 && limitePM >= 2,
            destaque: false,
            efeitoResumo: `Aprimoramento +1 PM (alvo 1 projétil): Reduz à metade o dano do ataque/projétil!`
        });
    }

    // 7. Habilidade de Classe na Ficha: Durão (Guerreiro 3º nível+, Livro p. 65 — Reação, 3 PM: reduz o dano sofrido à metade)
    if (nc === 'guerreiro' && st.nivel >= 3) {
        opcoes.push({
            id: 'REACAO_DURAO',
            nome: `💪 Durão [Guerreiro 3º Nv · Reação — 3 PM] (Livro p. 65)`,
            custoPM: 3,
            disponivel: a.pmHeroi >= 3,
            destaque: true,
            efeitoResumo: `Reduz o dano sofrido à METADE (de ${ataquePendente ? ataquePendente.danoPrevisto : 20} para ${ataquePendente ? Math.floor(ataquePendente.danoPrevisto / 2) : 10}!)`
        });
    }

    // 8. Poder na Ficha: Rolamento Defensivo (Livro p. 74 / p. 126 — Reação, 2 PM: reduz o dano à metade e fica caído)
    if (todosPods.includes('rolamento defensivo')) {
        opcoes.push({
            id: 'REACAO_ROLAMENTO_DEFENSIVO',
            nome: `🤸 Rolamento Defensivo [Poder da Ficha · Reação — 2 PM] (Livro p. 74)`,
            custoPM: 2,
            disponivel: a.pmHeroi >= 2,
            destaque: true,
            efeitoResumo: `Sempre que sofre dano, gasta 2 PM para reduzir esse dano à METADE!`
        });
    }

    // 9. Poder na Ficha: Aparar (Bucaneiro, Livro p. 51 — Reação, 1 PM: teste de ataque oposto para evitar ataque corpo a corpo)
    if (todosPods.includes('aparar')) {
        opcoes.push({
            id: 'REACAO_APARAR',
            nome: `🤺 Aparar [Poder da Ficha · Reação — 1 PM] (Livro p. 51)`,
            custoPM: 1,
            disponivel: a.pmHeroi >= 1,
            destaque: ehAtaqueFisico,
            efeitoResumo: `Faz um teste de ataque oposto contra o ataque corpo a corpo; se maior, EVITA O ATAQUE!`
        });
    }

    // 10. Habilidade de Classe na Ficha: Baluarte (Cavaleiro 1º Nv+, Livro p. 56 — Reação, 1 PM: +2 na Defesa e nos Testes de Resistência, +2 a cada 4 níveis)
    if (nc === 'cavaleiro') {
        const bBal = 2 + 2 * Math.floor((st.nivel - 1) / 4);
        opcoes.push({
            id: 'REACAO_BALUARTE',
            nome: `🏰 Baluarte [Cavaleiro · Reação — 1 PM] (Livro p. 56)`,
            custoPM: 1,
            disponivel: a.pmHeroi >= 1,
            destaque: true,
            efeitoResumo: `Quando sofre um ataque ou faz um teste de resistência, recebe +${bBal} na Defesa e nos Testes de Resistência!`
        });
    }

    // 11. Habilidade de Classe na Ficha: Orgulho (Nobre 1º Nv+, Livro p. 79 — 1 a N PM: +2 por PM gasto no teste de perícia/resistência)
    if (nc === 'nobre' && ehTesteResistencia) {
        const pmOrg = Math.min(2, a.pmHeroi, st.nivel);
        if (pmOrg >= 1) {
            opcoes.push({
                id: 'REACAO_ORGULHO_NOBRE',
                nome: `👑 Orgulho [Nobre · Reação no Teste — ${pmOrg} PM] (Livro p. 79)`,
                custoPM: pmOrg,
                disponivel: a.pmHeroi >= pmOrg,
                destaque: true,
                efeitoResumo: `Soma +${pmOrg * 2} no Teste de Resistência contra o efeito da criatura!`
            });
        }
    }

    // 12. Habilidade Racial na Ficha: Engenhosidade (Kliren, Livro p. 23 — 2 PM: soma INT em um teste de perícia/resistência, exceto ataque)
    if ((nr === 'kliren' || (nr === 'osteon' && memOst.includes('kliren'))) && ehTesteResistencia) {
        const bInt = Math.max(1, st.est.finais.INT);
        opcoes.push({
            id: 'REACAO_ENGENHOSIDADE_KLIREN',
            nome: `🧠 Engenhosidade [Kliren · 2 PM] (Livro p. 23)`,
            custoPM: 2,
            disponivel: a.pmHeroi >= 2,
            destaque: true,
            efeitoResumo: `Soma sua Inteligência (+${bInt}) no Teste de Resistência recém-realizado!`
        });
    }

    // 13. Poder Geral na Ficha: Sortudo (Livro p. 129 — 3 PM: rola novamente um teste recém-realizado)
    if (todosPods.includes('sortudo') && ehTesteResistencia) {
        opcoes.push({
            id: 'REACAO_SORTUDO_2D20',
            nome: `🍀 Sortudo [Poder da Ficha · 3 PM] (Livro p. 129)`,
            custoPM: 3,
            disponivel: a.pmHeroi >= 3,
            destaque: !ataquePendente.passouOriginal,
            efeitoResumo: `Rola novamente o Teste de Resistência recém-realizado (2d20 — seleciona o MELHOR resultado)!`
        });
    }

    return opcoes;
}

function alternarEstiloVisualArenaJS(estiloEscolhido) {
    const wrapper = document.getElementById('jrpg-battle-stage');
    const arenaSection = document.querySelector('#tab-arena .arena-stage');
    if (wrapper) {
        wrapper.setAttribute('data-visual-mode', estiloEscolhido || 'HD2D');
    }
    if (arenaSection) {
        arenaSection.setAttribute('data-visual-mode', estiloEscolhido || 'HD2D');
    }
    atualizarPlacarVisualArena();
}


// =============================================================================


function construirPainelPersonalizacaoAparenciaFichaHTML(estado) {
    const racaNome = (estado && estado.raca && estado.raca.nome) ? estado.raca.nome : 'Humano';
    const paleta = obterPaletaRacialHeroiJS(racaNome.toLowerCase());
    const ap = window.__APARENCIA_HEROI__ || {};
    const selOpt = (atual, val) => (atual === val ? ' selected' : '');
    const optsPele = paleta.map((p, idx) => `<option value="${p.cor}" ${(ap.corPele === p.cor || (!ap.corPele && idx === 0)) ? 'selected' : ''}>${p.nome}</option>`).join('');
    const cabAt = ap.estiloCabeca || ap.acessorioCabeca || 'RACIAL_CLASSICO';
    const penAt = ap.penteado || 'HEROICO_CLASSICO';
    const corCabAt = ap.corCabelo || '#1E293B';
    const trajeAt = ap.estiloTraje || 'AUTO_CLASSE';
    const matAt = ap.materialEspecial || 'ACO_PADRAO';
    const corTrAt = ap.corTraje || '#7F1D1D|#991B1B';
    const costaAt = ap.capaCostas || 'CAPA_REAL';
    const ombAt = ap.ombreiras || 'AUTO_TRAJE';
    const postAt = ap.postura || 'HEROICA_CLASSICA';
    const expAt = ap.expressao || 'DETERMINADO';
    const secAt = ap.maoSecundaria || 'AUTO_FICHA';
    const efAt = ap.efeitoArma || 'ACO_FORJADO';
    const auraAt = ap.auraParticulas || 'NENHUMA';

    return `
        <div class="section-box" style="background:linear-gradient(135deg, rgba(15,23,42,0.96), rgba(30,27,75,0.94)); border:2px solid #D97706; border-radius:10px; padding:10px 12px; margin-top:10px; margin-bottom:12px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:8px;">
                <div>
                    <strong style="font-size:13px; color:#FDE047;">🎨 Estúdio de Aparência &amp; Silhueta Pixel Art na Ficha (Sincronizado c/ Arena &amp; Mesa Online)</strong>
                    <div style="font-size:11px; color:#CBD5E1;">Mude Capas, Asas, Armaduras, Ombreiras, Elmos, Armas e Auras — altera imediatamente a silhueta na Ficha e na Arena!</div>
                </div>
                <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center;">
                    <button type="button" class="btn-roll-inline" style="background:#D97706;border-color:#FEF08A;color:#111827;font-weight:900;padding:4px 9px;" onclick="window.__APARENCIA_CUSTOMIZADA_PELO_USUARIO__=true;sortearAparenciaAleatoriaRacialJS()">🎲 Sortear (${racaNome})</button>
                    <button type="button" class="btn-roll-inline" style="background:#1E3A8A;border-color:#60A5FA;padding:4px 8px;" onclick="window.__APARENCIA_CUSTOMIZADA_PELO_USUARIO__=true;aplicarPresetVisualRapidoHeroiJS('CAVALEIRO_REAL')">🛡️ Cavaleiro</button>
                    <button type="button" class="btn-roll-inline" style="background:#4C1D95;border-color:#C084FC;padding:4px 8px;" onclick="window.__APARENCIA_CUSTOMIZADA_PELO_USUARIO__=true;aplicarPresetVisualRapidoHeroiJS('ARQUIMAGO_ASTRAL')">🔮 Arquimago</button>
                    <button type="button" class="btn-roll-inline" style="background:#7F1D1D;border-color:#F87171;padding:4px 8px;" onclick="window.__APARENCIA_CUSTOMIZADA_PELO_USUARIO__=true;aplicarPresetVisualRapidoHeroiJS('BARBARO_RUBRO')">🪓 Bárbaro</button>
                    <button type="button" class="btn-roll-inline" style="background:#0F172A;border-color:#A855F7;padding:4px 8px;" onclick="window.__APARENCIA_CUSTOMIZADA_PELO_USUARIO__=true;aplicarPresetVisualRapidoHeroiJS('ASSASSINO_SOMBRIO')">🗡️ Assassino</button>
                    <button type="button" class="btn-roll-inline" style="background:#78350F;border-color:#FACC15;padding:4px 8px;" onclick="window.__APARENCIA_CUSTOMIZADA_PELO_USUARIO__=true;aplicarPresetVisualRapidoHeroiJS('PALADINO_SOLAR')">☀️ Paladino</button>
                    <button type="button" class="btn-roll-inline" style="background:#334155;border-color:#94A3B8;padding:4px 8px;" onclick="restaurarAparenciaPadraoRacialJS()">🔄 Padrão</button>
                </div>
            </div>
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(155px, 1fr)); gap:7px; font-size:11px; color:#E2E8F0;">
                <div>
                    <label style="color:#FDE047;font-size:10.5px;font-weight:800;">1. Silhueta de Costas / Capa / Asas</label>
                    <select id="ficha-ap-sel-capa-costas" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'capaCostas', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FEF08A;border:1px solid #F59E0B;">
                        <option value="CAPA_REAL"${selOpt(costaAt,'CAPA_REAL')}>🧣 Capa Heróica Longa Real</option>
                        <option value="SEM_CAPA"${selOpt(costaAt,'SEM_CAPA')}>🚫 Sem Capa (Silhueta Limpa)</option>
                        <option value="CAPA_RASGADA"${selOpt(costaAt,'CAPA_RASGADA')}>⚔️ Capa Rasgada de Veterano</option>
                        <option value="MANTO_GOLA_ALTA"${selOpt(costaAt,'MANTO_GOLA_ALTA')}>🧛 Manto Nobre de Gola Alta</option>
                        <option value="MANTO_PELE_INVERNO"${selOpt(costaAt,'MANTO_PELE_INVERNO')}>🐺 Manto Pesado de Pele de Lobo</option>
                        <option value="ASAS_CELESTIAIS_DRACONICAS"${selOpt(costaAt,'ASAS_CELESTIAIS_DRACONICAS')}>🪽 Grandes Asas Celestiais Abertas</option>
                        <option value="ASAS_MORCEGO_ABISSAL"${selOpt(costaAt,'ASAS_MORCEGO_ABISSAL')}>🦇 Grandes Asas de Morcego / Dragão</option>
                        <option value="HALO_DIVINO"${selOpt(costaAt,'HALO_DIVINO')}>😇 Roda Rúnica / Halo Solar nas Costas</option>
                        <option value="ESTANDARTE_GUERRA"${selOpt(costaAt,'ESTANDARTE_GUERRA')}>🚩 Estandarte de Guerra nas Costas</option>
                        <option value="PROPULSOR_AETHER"${selOpt(costaAt,'PROPULSOR_AETHER')}>🚀 Meca-Propulsor Steampunk Aether</option>
                        <option value="MOCHILA_AVENTUREIRO"${selOpt(costaAt,'MOCHILA_AVENTUREIRO')}>🎒 Mochila Pesada de Aventureiro</option>
                        <option value="ALJAVA_ARCO"${selOpt(costaAt,'ALJAVA_ARCO')}>🏹 Aljava Diagonal de Flechas</option>
                    </select>
                </div>
                <div>
                    <label style="color:#FDE047;font-size:10.5px;font-weight:800;">2. Silhueta da Armadura / Traje</label>
                    <select id="ficha-ap-sel-traje" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'estiloTraje', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FEF08A;border:1px solid #F59E0B;">
                        <option value="AUTO_CLASSE"${selOpt(trajeAt,'AUTO_CLASSE')}>🛡️ Sincronizado c/ Classe da Ficha</option>
                        <option value="PLACAS_PESADAS"${selOpt(trajeAt,'PLACAS_PESADAS')}>🏰 Armadura Completa Gótica Pesada</option>
                        <option value="MEIA_ARMADURA_EX1"${selOpt(trajeAt,'MEIA_ARMADURA_EX1')}>⚜️ Meia Armadura / Cota de Malha</option>
                        <option value="COURACA_EX1"${selOpt(trajeAt,'COURACA_EX1')}>🛡️ Couraça Real Esculturada</option>
                        <option value="PELES_BARBARAS"${selOpt(trajeAt,'PELES_BARBARAS')}>🐺 Gibão de Peles Bárbaro (Peito/Boldrié)</option>
                        <option value="COURO_FURTIVO"${selOpt(trajeAt,'COURO_FURTIVO')}>🗡️ Couro Furtivo Esguio de Assassino</option>
                        <option value="MANTO_ARCANO"${selOpt(trajeAt,'MANTO_ARCANO')}>🔮 Manto Longo de Arquimago</option>
                        <option value="VESTES_SAGRADAS"${selOpt(trajeAt,'VESTES_SAGRADAS')}>☀️ Batina &amp; Tabardo Sagrado Longo</option>
                        <option value="CASACO_CORSARIO"${selOpt(trajeAt,'CASACO_CORSARIO')}>🏴‍☠️ Casaco Longo Aberto de Corsário/Nobre</option>
                    </select>
                </div>
                <div>
                    <label style="color:#FDE047;font-size:10.5px;font-weight:800;">3. Silhueta das Ombreiras</label>
                    <select id="ficha-ap-sel-ombreiras" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'ombreiras', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FEF08A;border:1px solid #F59E0B;">
                        <option value="AUTO_TRAJE"${selOpt(ombAt,'AUTO_TRAJE')}>🛡️ Padrão da Armadura</option>
                        <option value="OMBREIRAS_COLOSSAIS_ESPINHOS"${selOpt(ombAt,'OMBREIRAS_COLOSSAIS_ESPINHOS')}>🦴 Ombreiras Colossais de Espinhos</option>
                        <option value="OMBREIRAS_ALADAS_PALADINO"${selOpt(ombAt,'OMBREIRAS_ALADAS_PALADINO')}>🪽 Ombreiras Aladas de Valquíria</option>
                        <option value="OMBREIRAS_CRANIO_NECRO"${selOpt(ombAt,'OMBREIRAS_CRANIO_NECRO')}>💀 Ombreiras de Crânios de Aslothia</option>
                        <option value="OMBREIRAS_PELES_FERA"${selOpt(ombAt,'OMBREIRAS_PELES_FERA')}>🦁 Ombreiras de Pelagem de Fera</option>
                        <option value="SEM_OMBREIRAS_LEVE"${selOpt(ombAt,'SEM_OMBREIRAS_LEVE')}>🤺 Sem Ombreiras (Silhueta Esguia)</option>
                    </select>
                </div>
                <div>
                    <label style="color:#FDE047;font-size:10.5px;font-weight:800;">4. Silhueta de Elmo / Chapéu / Coroa</label>
                    <select id="ficha-ap-sel-cabeca" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'estiloCabeca', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FEF08A;border:1px solid #F59E0B;">
                        <option value="RACIAL_CLASSICO"${selOpt(cabAt,'RACIAL_CLASSICO')}>👑 Clássico da Raça (Sem Elmo)</option>
                        <option value="ELMO_TEMPLARIO"${selOpt(cabAt,'ELMO_TEMPLARIO')}>🪖 Elmo Fechado de Templário</option>
                        <option value="ELMO_VALQUIRIA"${selOpt(cabAt,'ELMO_VALQUIRIA')}>🪽 Elmo Alado Alto de Valquíria</option>
                        <option value="ELMO_GLADIADOR"${selOpt(cabAt,'ELMO_GLADIADOR')}>🦁 Elmo Imperial c/ Crista Rubra Alta</option>
                        <option value="COROA_CHIFRES_DRUIDA"${selOpt(cabAt,'COROA_CHIFRES_DRUIDA')}>🌿 Grande Galhada Silvestre de Druida</option>
                        <option value="CHAPEU_ARCANO"${selOpt(cabAt,'CHAPEU_ARCANO')}>🧙 Chapéu Pontudo Largo de Arquimago</option>
                        <option value="CHAPEU_TRICORNE"${selOpt(cabAt,'CHAPEU_TRICORNE')}>🏴‍☠️ Tricorne Pirata c/ Pluma Rubra</option>
                        <option value="CAPUZ_SOMBRIO"${selOpt(cabAt,'CAPUZ_SOMBRIO')}>🥷 Capuz Sombrio de Assassino</option>
                        <option value="MASCARA_SSZZAAS"${selOpt(cabAt,'MASCARA_SSZZAAS')}>🎭 Capuz &amp; Máscara Furtiva</option>
                        <option value="COROA_ARTON"${selOpt(cabAt,'COROA_ARTON')}>👑 Coroa Real Dourada</option>
                    </select>
                </div>
                <div>
                    <label style="color:#93C5FD;font-size:10.5px;">5. Pele / Escamas / Chassi</label>
                    <select id="ficha-ap-sel-pele" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'corPele', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FFF;border:1px solid #475569;">${optsPele}</select>
                </div>
                <div>
                    <label style="color:#93C5FD;font-size:10.5px;">6. Penteado / Corte</label>
                    <select id="ficha-ap-sel-penteado" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'penteado', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FFF;border:1px solid #475569;">
                        <option value="HEROICO_CLASSICO"${selOpt(penAt,'HEROICO_CLASSICO')}>💇 Curto Heróico Clássico</option>
                        <option value="LONGO_ESVOACANTE"${selOpt(penAt,'LONGO_ESVOACANTE')}>🌬️ Longo Esvoaçante nos Ombros</option>
                        <option value="SAMURAI_COQUE"${selOpt(penAt,'SAMURAI_COQUE')}>🗡️ Coque Alto Samurai</option>
                        <option value="TRANCAS_GUERRA"${selOpt(penAt,'TRANCAS_GUERRA')}>🛡️ Tranças Longas de Guerra</option>
                        <option value="MOICANO_SELVAGEM"${selOpt(penAt,'MOICANO_SELVAGEM')}>🔥 Moicano Alto Selvagem</option>
                        <option value="MONGE_TATUADO"${selOpt(penAt,'MONGE_TATUADO')}>🧘 Calvo c/ Runa Astral</option>
                    </select>
                </div>
                <div>
                    <label style="color:#93C5FD;font-size:10.5px;">7. Cor do Cabelo / Barba</label>
                    <select id="ficha-ap-sel-cabelo" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'corCabelo', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FFF;border:1px solid #475569;">
                        <option value="#1E293B"${selOpt(corCabAt,'#1E293B')}>🖤 Negro-Corvo</option>
                        <option value="#78350F"${selOpt(corCabAt,'#78350F')}>🤎 Castanho-Tapista</option>
                        <option value="#DC2626"${selOpt(corCabAt,'#DC2626')}>❤️ Ruivo-Brasa</option>
                        <option value="#FACC15"${selOpt(corCabAt,'#FACC15')}>💛 Loiro-Solar</option>
                        <option value="#F8FAFC"${selOpt(corCabAt,'#F8FAFC')}>🤍 Branco-Prateado</option>
                        <option value="#38BDF8"${selOpt(corCabAt,'#38BDF8')}>💙 Azul-Astral</option>
                        <option value="#10B981"${selOpt(corCabAt,'#10B981')}>💚 Verde-Esmeralda</option>
                        <option value="#A855F7"${selOpt(corCabAt,'#A855F7')}>💜 Roxo-Místico</option>
                    </select>
                </div>
                <div>
                    <label style="color:#93C5FD;font-size:10.5px;">8. Paleta Heráldica do Traje</label>
                    <select id="ficha-ap-sel-cor-traje" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'corTraje', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FFF;border:1px solid #475569;">
                        <option value="#7F1D1D|#991B1B"${selOpt(corTrAt,'#7F1D1D|#991B1B')}>🔴 Carmesim &amp; Ouro</option>
                        <option value="#1E3A8A|#1D4ED8"${selOpt(corTrAt,'#1E3A8A|#1D4ED8')}>🔵 Azul Real &amp; Prata</option>
                        <option value="#334155|#0F172A"${selOpt(corTrAt,'#334155|#0F172A')}>⚫ Aço Negro &amp; Ferro</option>
                        <option value="#CBD5E1|#B45309"${selOpt(corTrAt,'#CBD5E1|#B45309')}>⚪ Prata &amp; Dourado Solar</option>
                        <option value="#065F46|#047857"${selOpt(corTrAt,'#065F46|#047857')}>🟢 Verde de Allihanna</option>
                        <option value="#4C1D95|#6D28D9"${selOpt(corTrAt,'#4C1D95|#6D28D9')}>🟣 Púrpura de Wynna</option>
                        <option value="#78350F|#451A03"${selOpt(corTrAt,'#78350F|#451A03')}>🟤 Bronze &amp; Couro</option>
                    </select>
                </div>
                <div>
                    <label style="color:#FDE047;font-size:10.5px;">9. Material Especial</label>
                    <select id="ficha-ap-sel-material-especial" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'materialEspecial', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FDE047;border:1px solid #D97706;">
                        <option value="ACO_PADRAO"${selOpt(matAt,'ACO_PADRAO')}>⚒️ Aço Forjado Padrão</option>
                        <option value="ACO_RUBI"${selOpt(matAt,'ACO_RUBI')}>💎 Aço-Rubi Carmesim</option>
                        <option value="ADAMANTE"${selOpt(matAt,'ADAMANTE')}>🌑 Adamante Negro</option>
                        <option value="MITRAL"${selOpt(matAt,'MITRAL')}>✨ Mitral Prateado</option>
                        <option value="MATERIA_VERMELHA"${selOpt(matAt,'MATERIA_VERMELHA')}>👁️ Matéria Vermelha</option>
                        <option value="GELO_ETERNO"${selOpt(matAt,'GELO_ETERNO')}>❄️ Gelo Eterno</option>
                        <option value="MADEIRA_TOLLON"${selOpt(matAt,'MADEIRA_TOLLON')}>🌿 Madeira Tollon</option>
                        <option value="OURO_AZGHER"${selOpt(matAt,'OURO_AZGHER')}>☀️ Ouro Solar de Azgher</option>
                    </select>
                </div>
                <div>
                    <label style="color:#93C5FD;font-size:10.5px;">10. Postura &amp; Porte Corporal</label>
                    <select id="ficha-ap-sel-postura" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'postura', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FFF;border:1px solid #475569;">
                        <option value="HEROICA_CLASSICA"${selOpt(postAt,'HEROICA_CLASSICA')}>🛡️ Postura Clássica Heróica</option>
                        <option value="GUARDA_OFENSIVA"${selOpt(postAt,'GUARDA_OFENSIVA')}>⚔️ Guarda Ofensiva Inclinada</option>
                        <option value="DUELISTA_AGIL"${selOpt(postAt,'DUELISTA_AGIL')}>🤺 Postura Ágil de Esgrimista</option>
                        <option value="CONJURACAO_ARCANA"${selOpt(postAt,'CONJURACAO_ARCANA')}>✨ Levitação Mística</option>
                        <option value="COLOSSO_IMPONENTE"${selOpt(postAt,'COLOSSO_IMPONENTE')}>💪 Porte Colosso (+15% Escala)</option>
                    </select>
                </div>
                <div>
                    <label style="color:#FDE047;font-size:10.5px;">11. Arma Principal (Silhueta)</label>
                    <select id="ficha-ap-sel-arma-custom" onchange="trocarArmaEquipadaVisualJS(this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FDE047;border:1px solid #D97706;">
                        <option value="AUTO_FICHA">🗡️ Arma Atual da Ficha</option>
                        <option value="Montante">⚔️ Montante (Espada de 2 Mãos)</option>
                        <option value="Espada longa">🗡️ Espada Longa</option>
                        <option value="Katana">🎌 Katana</option>
                        <option value="Florete">🤺 Florete</option>
                        <option value="Machado de guerra">🪓 Machado de Guerra</option>
                        <option value="Machado táurico">🐂 Machado Táurico</option>
                        <option value="Marreta">🔨 Marreta Colossal</option>
                        <option value="Martelo de guerra">🔨 Martelo de Guerra</option>
                        <option value="Alabarda">🔱 Alabarda de Haste</option>
                        <option value="Gadanho">🌙 Gadanho / Foice</option>
                        <option value="Arco longo">🏹 Arco Longo</option>
                        <option value="Mosquete">🔫 Mosquete</option>
                        <option value="Cajado arcano">🪄 Cajado Arcano</option>
                    </select>
                </div>
                <div>
                    <label style="color:#FDE047;font-size:10.5px;">12. Mão Secundária / Escudo</label>
                    <select id="ficha-ap-sel-mao-secundaria" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'maoSecundaria', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FDE047;border:1px solid #D97706;">
                        <option value="AUTO_FICHA"${selOpt(secAt,'AUTO_FICHA')}>🛡️ Automático da Ficha</option>
                        <option value="ESCUDO_PESADO"${selOpt(secAt,'ESCUDO_PESADO')}>🛡️ Escudo Pesado Real</option>
                        <option value="ESCUDO_LEVE"${selOpt(secAt,'ESCUDO_LEVE')}>💿 Escudo Leve</option>
                        <option value="ORBE_CRISTAL"${selOpt(secAt,'ORBE_CRISTAL')}>🔮 Orbe Cristalino</option>
                        <option value="GRIMORIO_ARCANO"${selOpt(secAt,'GRIMORIO_ARCANO')}>📖 Grimório Arcano</option>
                        <option value="SIMBOLO_SAGRADO"${selOpt(secAt,'SIMBOLO_SAGRADO')}>☀️ Símbolo Sagrado</option>
                        <option value="TOCHA_ACESA_SEC"${selOpt(secAt,'TOCHA_ACESA_SEC')}>🔥 Tocha Acesa</option>
                        <option value="MAO_LIVRE"${selOpt(secAt,'MAO_LIVRE')}>✋ Mão Livre (Sem Escudo)</option>
                    </select>
                </div>
                <div>
                    <label style="color:#FDE047;font-size:10.5px;">13. Encantamento da Arma</label>
                    <select id="ficha-ap-sel-efeito-arma" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'efeitoArma', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FDE047;border:1px solid #D97706;">
                        <option value="ACO_FORJADO"${selOpt(efAt,'ACO_FORJADO')}>✨ Sem Encantamento</option>
                        <option value="FOGO_SOLAR"${selOpt(efAt,'FOGO_SOLAR')}>🔥 Flamejante (+Fogo)</option>
                        <option value="RAIO_TROVAO"${selOpt(efAt,'RAIO_TROVAO')}>⚡ Chocante (+Raio)</option>
                        <option value="GELO_CRISTAL"${selOpt(efAt,'GELO_CRISTAL')}>❄️ Congelante (+Gelo)</option>
                        <option value="VENENO_ACIDO"${selOpt(efAt,'VENENO_ACIDO')}>🧪 Venenosa / Ácida</option>
                        <option value="LUZ_PALADINO"${selOpt(efAt,'LUZ_PALADINO')}>☀️ Sagrada (+Luz)</option>
                        <option value="TREVAS_PROFANA"${selOpt(efAt,'TREVAS_PROFANA')}>🌑 Profana (+Trevas)</option>
                    </select>
                </div>
                <div>
                    <label style="color:#34D399;font-size:10.5px;">14. Aura de Partículas Pixel</label>
                    <select id="ficha-ap-sel-aura-particulas" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'auraParticulas', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#6EE7B7;border:1px solid #10B981;">
                        <option value="NENHUMA"${selOpt(auraAt,'NENHUMA')}>🚫 Sem Aura</option>
                        <option value="CHAMAS_SOLARES"${selOpt(auraAt,'CHAMAS_SOLARES')}>🔥 Chamas Solares</option>
                        <option value="RAIOS_TEMPESTADE"${selOpt(auraAt,'RAIOS_TEMPESTADE')}>⚡ Raios Astrais</option>
                        <option value="CRISTAIS_GELO"${selOpt(auraAt,'CRISTAIS_GELO')}>❄️ Cristais de Gelo</option>
                        <option value="LUZ_DIVINA"${selOpt(auraAt,'LUZ_DIVINA')}>✨ Luz Divina</option>
                        <option value="TREVAS_TENEBRA"${selOpt(auraAt,'TREVAS_TENEBRA')}>🌑 Sombras de Tenebra</option>
                        <option value="CORRUPCAO_TORMENTA"${selOpt(auraAt,'CORRUPCAO_TORMENTA')}>👁️ Bio-Cristais Tormenta</option>
                        <option value="FOLHAS_ALLIHANNA"${selOpt(auraAt,'FOLHAS_ALLIHANNA')}>🍃 Folhas de Allihanna</option>
                    </select>
                </div>
                <div>
                    <label style="color:#93C5FD;font-size:10.5px;">15. Expressão &amp; Cicatrizes</label>
                    <select id="ficha-ap-sel-expressao" onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'expressao', this.value)" style="min-height:28px;padding:2px 6px;font-size:11px;background:#0F172A;color:#FFF;border:1px solid #475569;">
                        <option value="DETERMINADO"${selOpt(expAt,'DETERMINADO')}>😠 Olhar Determinado</option>
                        <option value="OLHOS_INCANDESCENTES"${selOpt(expAt,'OLHOS_INCANDESCENTES')}>🔥 Olhos Incandescentes</option>
                        <option value="CICATRIZ_VETERANA"${selOpt(expAt,'CICATRIZ_VETERANA')}>⚔️ Cicatriz de Batalha</option>
                        <option value="SORRISO_AUDACIOSO"${selOpt(expAt,'SORRISO_AUDACIOSO')}>😏 Sorriso Audacioso</option>
                        <option value="TAPA_OLHO_CORSARIO"${selOpt(expAt,'TAPA_OLHO_CORSARIO')}>🏴‍☠️ Tapa-Olho Corsário</option>
                        <option value="MARCA_TORMENTA"${selOpt(expAt,'MARCA_TORMENTA')}>👁️ Marca da Tormenta</option>
                    </select>
                </div>
            </div>
        </div>
    `;
}

if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
    window.addEventListener("DOMContentLoaded", function() {
        setTimeout(function() {
            try {
                const st = (typeof garantirEstadoFichaParaArena === "function") ? garantirEstadoFichaParaArena() : null;
                const slot = document.getElementById("ficha-estudio-aparencia-ssr-slot");
                if (slot && st && typeof construirPainelPersonalizacaoAparenciaFichaHTML === "function") {
                    slot.innerHTML = construirPainelPersonalizacaoAparenciaFichaHTML(st);
                }
                if (typeof sincronizarTodosSeletoresAparenciaFichaEArenaJS === "function") sincronizarTodosSeletoresAparenciaFichaEArenaJS();
                if (typeof atualizarRetratoFichaPrincipalJS === "function") atualizarRetratoFichaPrincipalJS();
            } catch(e) {}
        }, 40);
    });
}


// =============================================================================
// MODO TELA CHEIA (FULLSCREEN COMBAT HUD) & GAVETA DINÂMICA SEM POLUIÇÃO VISUAL (v62)
// =============================================================================
window.__ABA_HUD_DINAMICO_ARENA__ = 'ABA_ATAQUES';
window.__ABA_HUD_DINAMICO_MESA__ = 'ABA_MESA_ACOES';
window.__TELA_CHEIA_COMBATE_ATIVA__ = null;

function alternarAbaHudDinamicoArenaJS(idAba) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    if (window.__ABA_HUD_DINAMICO_ARENA__ === idAba && idAba !== 'ABA_ATAQUES') {
        window.__ABA_HUD_DINAMICO_ARENA__ = 'ABA_OCULTA';
    } else {
        window.__ABA_HUD_DINAMICO_ARENA__ = idAba || 'ABA_OCULTA';
    }
    const atual = window.__ABA_HUD_DINAMICO_ARENA__;
    const drawer = document.getElementById('arena-dynamic-hud-drawer');
    if (drawer) {
        drawer.style.display = (atual === 'ABA_OCULTA') ? 'none' : 'block';
    }
    document.querySelectorAll('#arena-dynamic-hud-tabs-bar [data-hud-tab]').forEach(btn => {
        const t = btn.getAttribute('data-hud-tab');
        if (t === atual) {
            btn.classList.add('active-hud-tab');
        } else {
            btn.classList.remove('active-hud-tab');
        }
    });
    document.querySelectorAll('#arena-dynamic-hud-drawer .t20-hud-pane').forEach(pane => {
        const pId = pane.getAttribute('data-pane-id');
        pane.style.display = (pId === atual) ? 'block' : 'none';
    });
}

function alternarAbaHudDinamicoMesaJS(idAba) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    if (window.__ABA_HUD_DINAMICO_MESA__ === idAba && idAba !== 'ABA_MESA_ACOES') {
        window.__ABA_HUD_DINAMICO_MESA__ = 'ABA_OCULTA';
    } else {
        window.__ABA_HUD_DINAMICO_MESA__ = idAba || 'ABA_OCULTA';
    }
    if (typeof renderizarPalcoEGrid2DMesaOnline === 'function') {
        renderizarPalcoEGrid2DMesaOnline();
    }
}

function alternarTelaCheiaCombateT20JS(modoAlvo) {
    try { if (typeof tocarSomJRPG === 'function') tocarSomJRPG('UI_CLICK'); } catch(e) {}
    const alvo = modoAlvo || 'ARENA';
    if (alvo === 'ARENA' && typeof mostrarAba === 'function') {
        mostrarAba('tab-arena');
        if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario();
    } else if (alvo === 'MESA' && typeof mostrarAba === 'function') {
        mostrarAba('tab-mesa-online');
        if (typeof inicializarAbaMesaOnlineUI === 'function') inicializarAbaMesaOnlineUI();
    }

    const shellId = (alvo === 'MESA') ? 'mesa-combat-screen-shell' : 'arena-combat-screen-shell';
    const shell = document.getElementById(shellId);
    if (!shell) return;

    const jaAtivo = (window.__TELA_CHEIA_COMBATE_ATIVA__ === alvo) || shell.classList.contains('t20-combat-fullscreen-active');
    if (jaAtivo) {
        shell.classList.remove('t20-combat-fullscreen-active');
        document.body.classList.remove('t20-body-lock-fullscreen');
        if (document.documentElement && document.documentElement.classList) {
            document.documentElement.classList.remove('t20-body-lock-fullscreen');
        }
        window.__TELA_CHEIA_COMBATE_ATIVA__ = null;
        try {
            const exitFn = document.exitFullscreen || document.webkitExitFullscreen || document.mozCancelFullScreen || document.msExitFullscreen;
            if ((document.fullscreenElement || document.webkitFullscreenElement) && exitFn) {
                exitFn.call(document).catch(() => {});
            }
        } catch(e) {}
    } else {
        document.querySelectorAll('.t20-combat-screen-shell.t20-combat-fullscreen-active').forEach(el => el.classList.remove('t20-combat-fullscreen-active'));
        shell.classList.add('t20-combat-fullscreen-active');
        document.body.classList.add('t20-body-lock-fullscreen');
        if (document.documentElement && document.documentElement.classList) {
            document.documentElement.classList.add('t20-body-lock-fullscreen');
        }
        window.__TELA_CHEIA_COMBATE_ATIVA__ = alvo;
        try {
            shell.scrollTop = 0;
            window.scrollTo(0, 0);
        } catch(e) {}
        try {
            const reqFn = shell.requestFullscreen || shell.webkitRequestFullscreen ||
                (document.documentElement && (document.documentElement.requestFullscreen || document.documentElement.webkitRequestFullscreen));
            if (reqFn) {
                const p = reqFn.call(shell.requestFullscreen || shell.webkitRequestFullscreen ? shell : document.documentElement);
                if (p && typeof p.catch === 'function') p.catch(() => {});
            }
        } catch(e) {}
    }

    const onA = (window.__TELA_CHEIA_COMBATE_ATIVA__ === 'ARENA');
    ['btn-arena-fullscreen-toggle', 'btn-arena-top-mobile-fullscreen'].forEach(idB => {
        const b = document.getElementById(idB);
        if (b) {
            b.innerHTML = onA ? '✕ SAIR DA TELA CHEIA' : '📱⛶ TELA CHEIA (CELULAR / PC)';
            b.style.background = onA ? '#991B1B' : 'linear-gradient(135deg, #059669, #047857)';
        }
    });
    const btnMesa = document.getElementById('btn-mesa-fullscreen-toggle');
    if (btnMesa) {
        const onM = (window.__TELA_CHEIA_COMBATE_ATIVA__ === 'MESA');
        btnMesa.innerHTML = onM ? '✕ SAIR DA TELA CHEIA' : '📱⛶ TELA CHEIA';
        btnMesa.style.background = onM ? '#991B1B' : 'linear-gradient(135deg, #059669, #047857)';
    }

    if (typeof atualizarPlacarVisualArena === 'function' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) atualizarPlacarVisualArena();
    if (typeof renderizarConsolePersonagemTelaCheiaArenaJS === 'function') renderizarConsolePersonagemTelaCheiaArenaJS();
    if (typeof renderizarPalcoEGrid2DMesaOnline === 'function' && typeof ESTADO_MESA_ONLINE_ATUAL !== 'undefined' && ESTADO_MESA_ONLINE_ATUAL) renderizarPalcoEGrid2DMesaOnline();
}

function ajustarRecursoRapidoPersonagemArenaJS(tipoRec, valor) {
    if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario();
    if (typeof __ARENA_STATE__ === 'undefined' || !__ARENA_STATE__) return;
    const a = __ARENA_STATE__;
    const st = garantirEstadoFichaParaArena();
    try { if (typeof tocarSomPorEfeitoAnimacaoJRPG === 'function') tocarSomPorEfeitoAnimacaoJRPG('CURA_BUFF'); } catch(e) {}

    if (tipoRec === 'POCAO_CURA') {
        const d1 = Math.floor(Math.random() * 8) + 1;
        const d2 = Math.floor(Math.random() * 8) + 1;
        const cura = d1 + d2 + 2;
        a.pvHeroi = Math.min(a.pvHeroiMax, a.pvHeroi + cura);
        if (typeof registrarLinhaLogArena === 'function') registrarLinhaLogArena(`<strong>[🧪 Poção de Curar Ferimentos]</strong> ${st.nome} recuperou <strong>+${cura} PV</strong> (2d8+2: [${d1}+${d2}+2]) ➔ ${a.pvHeroi}/${a.pvHeroiMax} PV!`);
        if (typeof dispararPopupDanoJRPG === 'function') dispararPopupDanoJRPG(`+${cura} PV`, '#4ADE80', 'HEROI', 'SHIELD', `🧪 Poção de Cura: +${cura} PV!`);
    } else if (tipoRec === 'ESSENCIA_MANA') {
        const dm = Math.floor(Math.random() * 4) + 1;
        a.pmHeroi = Math.min(a.pmHeroiMax, a.pmHeroi + dm);
        if (typeof registrarLinhaLogArena === 'function') registrarLinhaLogArena(`<strong>[💧 Essência de Mana]</strong> ${st.nome} recuperou <strong>+${dm} PM</strong> (1d4: [${dm}]) ➔ ${a.pmHeroi}/${a.pmHeroiMax} PM!`);
        if (typeof dispararPopupDanoJRPG === 'function') dispararPopupDanoJRPG(`+${dm} PM`, '#38BDF8', 'HEROI', 'SHIELD', `💧 Essência de Mana: +${dm} PM!`);
    } else if (tipoRec === 'DESCANSO_TOTAL') {
        a.pvHeroi = a.pvHeroiMax;
        a.pmHeroi = a.pmHeroiMax;
        a.acoesPadraoRestantes = a.acoesPadraoMax || 1;
        a.acoesMovimentoRestantes = a.acoesMovimentoMax || 1;
        a.reacaoDisponivel = true;
        if (a.condicoesHeroi) {
            Object.keys(a.condicoesHeroi).forEach(k => { a.condicoesHeroi[k] = false; });
        }
        if (typeof registrarLinhaLogArena === 'function') registrarLinhaLogArena(`<strong>[⛺ Descanso Completo]</strong> ${st.nome} restaurou 100% dos PV (${a.pvHeroiMax}), PM (${a.pmHeroiMax}), Ações e removeu condições negativas!`);
        if (typeof dispararPopupDanoJRPG === 'function') dispararPopupDanoJRPG('100% PV/PM', '#FACC15', 'HEROI', 'SHIELD', '⛺ Descanso Completo: 100% PV e PM restaurados!');
    } else if (tipoRec === 'DELTA_PV') {
        a.pvHeroi = Math.max(0, Math.min(a.pvHeroiMax, a.pvHeroi + Number(valor || 0)));
    } else if (tipoRec === 'DELTA_PM') {
        a.pmHeroi = Math.max(0, Math.min(a.pmHeroiMax, a.pmHeroi + Number(valor || 0)));
    }
    if (typeof atualizarPlacarVisualArena === 'function') atualizarPlacarVisualArena();
    renderizarConsolePersonagemTelaCheiaArenaJS();
}

function rolarTestePersonagemNaArenaTelaCheiaJS(rotuloTeste, bonusNum, usar2d20Melhor) {
    if (typeof inicializarArenaVisualSeNecessario === 'function') inicializarArenaVisualSeNecessario();
    const st = garantirEstadoFichaParaArena();
    const b = Number(bonusNum || 0);
    const d1 = Math.floor(Math.random() * 20) + 1;
    const d2 = Math.floor(Math.random() * 20) + 1;
    const dUsado = usar2d20Melhor ? Math.max(d1, d2) : d1;
    const total = dUsado + b;
    const strSinal = b >= 0 ? `+${b}` : `${b}`;
    const resumoDado = usar2d20Melhor
        ? `2d20(${d1}, ${d2} ➔ Maior: ${dUsado})${strSinal} = ${total}`
        : `1d20(${d1})${strSinal} = ${total}`;

    try {
        if (typeof animarBandejaDados3D === 'function') {
            animarBandejaDados3D(
                `🎲 ${rotuloTeste} (${st ? st.nome : 'Herói'})`,
                usar2d20Melhor
                    ? [{ faces: 20, valor: d1, label: 'd20 #1' }, { faces: 20, valor: d2, label: 'd20 #2 (Melhor)', crit: dUsado === 20, fumble: dUsado === 1 }]
                    : [{ faces: 20, valor: d1, label: rotuloTeste.slice(0, 12), crit: d1 === 20, fumble: d1 === 1 }],
                `<strong>${rotuloTeste}:</strong> ${resumoDado}`
            );
        }
    } catch(e) {}

    const pill = document.getElementById('arena-fullscreen-live-roll-pill');
    if (pill) {
        pill.innerHTML = `🎲 <strong>${rotuloTeste}:</strong> ${resumoDado}`;
    }
    if (typeof dispararPopupDanoJRPG === 'function') {
        dispararPopupDanoJRPG(`${rotuloTeste}: ${total}`, dUsado === 20 ? '#FACC15' : '#38BDF8', 'HEROI', 'SHIELD', `🎲 ${rotuloTeste}: ${resumoDado}`);
    }
    if (typeof registrarLinhaLogArena === 'function') {
        registrarLinhaLogArena(`<strong>[🎲 Teste de Personagem — ${rotuloTeste}]</strong> ${resumoDado}`);
    }
}

function renderizarConsolePersonagemTelaCheiaArenaJS() {
    const st = (typeof garantirEstadoFichaParaArena === 'function') ? garantirEstadoFichaParaArena() : window.__ULTIMO_ESTADO_FICHA__;
    if (!st || !st.est) return;
    const a = (typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) ? __ARENA_STATE__ : null;

    // 1. Atualiza a Barra Fixa Mobile de Tela Cheia (#arena-fullscreen-sticky-bar)
    const stickyInfo = document.getElementById('arena-fullscreen-sticky-hero-stats');
    if (stickyInfo && a) {
        const defH = a.defHeroiBase + (a.bonusDefTemp || 0) + (a.coberturaAtiva ? 5 : 0);
        stickyInfo.innerHTML = `
            <span style="color:#FDE047;font-weight:900;">🦸 ${st.nome.slice(0, 14)} (Nv ${st.nivel})</span>
            <span style="background:#065F46;color:#A7F3D0;padding:2px 6px;border-radius:5px;font-weight:900;">❤️ ${Math.round(a.pvHeroi)}/${a.pvHeroiMax} PV</span>
            <span style="background:#0369A1;color:#E0F2FE;padding:2px 6px;border-radius:5px;font-weight:900;">💧 ${Math.round(a.pmHeroi)}/${a.pmHeroiMax} PM</span>
            <span style="background:#1E293B;color:#93C5FD;padding:2px 6px;border-radius:5px;font-weight:900;">🛡️ Def ${defH}</span>
            <span style="background:#3B0764;color:#E9D5FF;padding:2px 6px;border-radius:5px;font-weight:900;">⚡ ${a.acoesPadraoRestantes}P · 🦶 ${a.acoesMovimentoRestantes}M</span>
        `;
    }

    // 2. Renderiza o Console Completo de Ficha, Atributos, Perícias, Recursos e Equipamentos dentro do HUD (#arena-hud-ficha-completa-box)
    const box = document.getElementById('arena-hud-ficha-completa-box');
    if (!box) return;

    const finais = (st.est && st.est.finais) ? st.est.finais : { FOR: 0, DES: 0, CON: 0, INT: 0, SAB: 0, CAR: 0 };
    const htmlAtributos = ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR'].map(sig => {
        const v = Number(finais[sig] || 0);
        const s = v >= 0 ? `+${v}` : `${v}`;
        return `
            <button type="button" class="btn-roll-inline" style="background:#1E293B;border-color:#D4AF37;color:#FEF08A;padding:5px 8px;font-weight:900;display:flex;flex-direction:column;align-items:center;min-width:56px;"
                    onclick="rolarTestePersonagemNaArenaTelaCheiaJS('Atributo ${sig}', ${v}, false)">
                <span style="font-size:9.5px;color:#93C5FD;">${sig}</span>
                <span style="font-size:12.5px;">🎲 ${s}</span>
            </button>
        `;
    }).join('');

    const mapaPer = (st.est && st.est.bonusPericias) ? st.est.bonusPericias : {};
    const treinadasSet = new Set((st.est && st.est.periciasTreinadas) ? st.est.periciasTreinadas : []);
    const listaPericiasOrdem = [
        'Luta', 'Pontaria', 'Iniciativa', 'Percepção', 'Furtividade', 'Misticismo',
        'Fortitude', 'Reflexos', 'Vontade', 'Atletismo', 'Acrobacia', 'Cura',
        'Diplomacia', 'Intimidação', 'Enganação', 'Intuição', 'Guerra', 'Ladinagem',
        'Nobreza', 'Religião', 'Sobrevivência', 'Cavalgar', 'Conhecimento', 'Atuação'
    ];
    const htmlPericias = listaPericiasOrdem.map(nomeP => {
        const b = mapaPer[nomeP] !== undefined ? Number(mapaPer[nomeP]) : Math.floor((st.nivel || 1) / 2);
        const s = b >= 0 ? `+${b}` : `${b}`;
        const ehTrein = treinadasSet.has(nomeP);
        return `
            <button type="button" class="btn-roll-inline"
                    style="background:${ehTrein ? 'linear-gradient(135deg,#064E3B,#047857)' : '#0F172A'};border-color:${ehTrein ? '#34D399' : '#334155'};color:${ehTrein ? '#ECFDF5' : '#CBD5E1'};padding:4px 7px;font-size:10.5px;font-weight:${ehTrein ? '900' : '700'};display:inline-flex;justify-content:space-between;gap:5px;"
                    onclick="rolarTestePersonagemNaArenaTelaCheiaJS('Perícia ${nomeP}', ${b}, false)">
                <span>${ehTrein ? '★ ' : ''}${nomeP}</span>
                <span style="color:#FDE047;">${s}</span>
            </button>
        `;
    }).join('');

    const todosPods = [
        ...((st.est.infoOrigem && st.est.infoOrigem.poderesExtras) || []),
        ...((st.est.infoDevocao && st.est.infoDevocao.poderes) || []),
        ...(st.poderes || [])
    ];
    const htmlPoderes = todosPods.length === 0
        ? '<span style="font-size:10.5px;color:#94A3B8;">Nenhum poder adicional.</span>'
        : todosPods.map(p => `<span style="background:rgba(180,83,9,0.28);border:1px solid #F59E0B;color:#FEF08A;border-radius:6px;padding:2px 6px;font-size:10px;font-weight:800;" title="${(p.efeito || '').replace(/"/g, '&quot;')}">⚡ ${p.nome}</span>`).join(' ');

    const armaNome = (st.arma && st.arma.nome) ? st.arma.nome : 'Espada Longa';
    const escNome = (st.escudo && st.escudo.nome) ? st.escudo.nome : 'Nenhum';

    box.innerHTML = `
        <div style="display:flex;flex-direction:column;gap:8px;">
            <!-- LINHA 1: RECURSOS DE COMBATE (PV, PM, POÇÕES, DESCANSO E AJUSTE FINO) -->
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;background:rgba(9,13,22,0.85);padding:6px 8px;border-radius:8px;border:1px solid rgba(52,211,153,0.4);">
                <div style="font-size:11px;font-weight:900;color:#6EE7B7;">
                    ❤️ Recursos &amp; Itens de Recuperação (${st.nome} · ${st.raca.nome} ${st.classe.nome} Nv ${st.nivel}):
                </div>
                <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                    <button type="button" class="btn-roll-inline" style="background:#047857;border-color:#34D399;color:#ECFDF5;font-weight:900;padding:4px 8px;" onclick="ajustarRecursoRapidoPersonagemArenaJS('POCAO_CURA')">🧪 Poção de Cura (+2d8+2 PV)</button>
                    <button type="button" class="btn-roll-inline" style="background:#0369A1;border-color:#38BDF8;color:#E0F2FE;font-weight:900;padding:4px 8px;" onclick="ajustarRecursoRapidoPersonagemArenaJS('ESSENCIA_MANA')">💧 Essência de Mana (+1d4 PM)</button>
                    <button type="button" class="btn-roll-inline" style="background:#B45309;border-color:#FACC15;color:#FEF08A;font-weight:900;padding:4px 8px;" onclick="ajustarRecursoRapidoPersonagemArenaJS('DESCANSO_TOTAL')">⛺ Descanso Total (100% PV/PM)</button>
                    <button type="button" class="btn-roll-inline" style="background:#14532D;padding:3px 6px;" onclick="ajustarRecursoRapidoPersonagemArenaJS('DELTA_PV', 5)">+5 PV</button>
                    <button type="button" class="btn-roll-inline" style="background:#7F1D1D;padding:3px 6px;" onclick="ajustarRecursoRapidoPersonagemArenaJS('DELTA_PV', -5)">-5 PV</button>
                    <button type="button" class="btn-roll-inline" style="background:#1E3A8A;padding:3px 6px;" onclick="ajustarRecursoRapidoPersonagemArenaJS('DELTA_PM', 2)">+2 PM</button>
                    <button type="button" class="btn-roll-inline" style="background:#312E81;padding:3px 6px;" onclick="ajustarRecursoRapidoPersonagemArenaJS('DELTA_PM', -2)">-2 PM</button>
                </div>
            </div>

            <!-- LINHA 2: 6 ATRIBUTOS CLICÁVEIS + TROCA RÁPIDA DE ARMA/ESCUDO/SILHUETA -->
            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(260px, 1fr));gap:8px;">
                <div style="background:rgba(15,23,42,0.85);padding:6px 8px;border-radius:8px;border:1px solid rgba(212,175,55,0.4);">
                    <div style="font-size:10.5px;font-weight:900;color:#FDE047;margin-bottom:4px;">🎲 1. Rolar Testes de Atributo (Toque p/ Rolar 1d20):</div>
                    <div style="display:flex;gap:5px;flex-wrap:wrap;">${htmlAtributos}</div>
                </div>
                <div style="background:rgba(15,23,42,0.85);padding:6px 8px;border-radius:8px;border:1px solid rgba(56,189,248,0.4);">
                    <div style="font-size:10.5px;font-weight:900;color:#93C5FD;margin-bottom:4px;">🗡️ 2. Arsenal Equipado (${armaNome} · 🛡️ ${escNome}) &amp; Silhueta:</div>
                    <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                        <select onchange="trocarArmaEquipadaVisualJS(this.value);renderizarConsolePersonagemTelaCheiaArenaJS();" style="flex:1;min-width:130px;min-height:28px;padding:2px 6px;font-size:11px;background:#090D16;color:#FDE047;border:1px solid #D97706;">
                            <option value="AUTO_FICHA">🗡️ Arma: ${armaNome}</option>
                            <option value="Montante">⚔️ Montante (2d6)</option>
                            <option value="Espada longa">🗡️ Espada Longa (1d8)</option>
                            <option value="Katana">🎌 Katana (1d8/1d10)</option>
                            <option value="Florete">🤺 Florete (1d6 Crít 18)</option>
                            <option value="Machado de guerra">🪓 Machado de Guerra (1d12)</option>
                            <option value="Machado táurico">🐂 Machado Táurico (2d8)</option>
                            <option value="Marreta">🔨 Marreta (3d4)</option>
                            <option value="Alabarda">🔱 Alabarda (1d10 Alcance)</option>
                            <option value="Arco longo">🏹 Arco Longo (1d8 Dist.)</option>
                            <option value="Mosquete">🔫 Mosquete (2d8 Crít 19/x3)</option>
                            <option value="Cajado arcano">🪄 Cajado Arcano (+1 Limite PM)</option>
                        </select>
                        <select onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'capaCostas', this.value)" style="flex:1;min-width:125px;min-height:28px;padding:2px 6px;font-size:11px;background:#090D16;color:#FEF08A;border:1px solid #475569;">
                            <option value="CAPA_REAL">🧣 Capa Real</option>
                            <option value="SEM_CAPA">🚫 Sem Capa</option>
                            <option value="ASAS_CELESTIAIS_DRACONICAS">🪽 Asas Celestiais</option>
                            <option value="ASAS_MORCEGO_ABISSAL">🦇 Asas Abissais</option>
                            <option value="MANTO_PELE_INVERNO">🐺 Manto de Lobo</option>
                            <option value="HALO_DIVINO">😇 Halo Solar</option>
                        </select>
                        <select onchange="aplicarMudancaAparenciaSincronizadaJS('FICHA', 'estiloTraje', this.value)" style="flex:1;min-width:125px;min-height:28px;padding:2px 6px;font-size:11px;background:#090D16;color:#FEF08A;border:1px solid #475569;">
                            <option value="AUTO_CLASSE">🛡️ Traje da Classe</option>
                            <option value="PLACAS_PESADAS">🏰 Placas Góticas</option>
                            <option value="PELES_BARBARAS">🐺 Peles Bárbaras</option>
                            <option value="COURO_FURTIVO">🗡️ Couro Furtivo</option>
                            <option value="MANTO_ARCANO">🔮 Manto Arcano</option>
                            <option value="VESTES_SAGRADAS">☀️ Vestes Sagradas</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- LINHA 3: TODAS AS PERÍCIAS DA FICHA CLICÁVEIS (★ = TREINADA) -->
            <div style="background:rgba(15,23,42,0.88);padding:6px 8px;border-radius:8px;border:1px solid rgba(16,185,129,0.35);">
                <div style="font-size:10.5px;font-weight:900;color:#6EE7B7;margin-bottom:4px;">📜 3. Perícias do Personagem (Toque em qualquer perícia para rolar na Arena · ★ = Treinada):</div>
                <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(128px, 1fr));gap:4px;">
                    ${htmlPericias}
                </div>
            </div>

            <!-- LINHA 4: PODERES ATIVOS DA FICHA -->
            <div style="background:rgba(9,13,22,0.8);padding:5px 8px;border-radius:8px;border:1px solid rgba(245,158,11,0.3);display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                <span style="font-size:10.5px;font-weight:900;color:#FACC15;">⚡ Poderes Ativos na Ficha (${todosPods.length}):</span>
                ${htmlPoderes}
            </div>
        </div>
    `;
}

if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
    window.addEventListener('keydown', function(ev) {
        if (ev.key === 'Escape' && window.__TELA_CHEIA_COMBATE_ATIVA__) {
            alternarTelaCheiaCombateT20JS(window.__TELA_CHEIA_COMBATE_ATIVA__);
        }
    });
    ['fullscreenchange', 'webkitfullscreenchange'].forEach(evtName => {
        window.addEventListener(evtName, function() {
            const fsEl = document.fullscreenElement || document.webkitFullscreenElement;
            if (!fsEl && window.__TELA_CHEIA_COMBATE_ATIVA__) {
                // Em dispositivos móveis que saem do fullscreen nativo pelo botão voltar, sincroniza o estado
                const ativo = window.__TELA_CHEIA_COMBATE_ATIVA__;
                const shellId = (ativo === 'MESA') ? 'mesa-combat-screen-shell' : 'arena-combat-screen-shell';
                const shell = document.getElementById(shellId);
                if (shell) shell.classList.remove('t20-combat-fullscreen-active');
                document.body.classList.remove('t20-body-lock-fullscreen');
                if (document.documentElement && document.documentElement.classList) {
                    document.documentElement.classList.remove('t20-body-lock-fullscreen');
                }
                window.__TELA_CHEIA_COMBATE_ATIVA__ = null;
                if (typeof atualizarPlacarVisualArena === 'function' && typeof __ARENA_STATE__ !== 'undefined' && __ARENA_STATE__) atualizarPlacarVisualArena();
            }
        });
    });
}
