# -*- coding: utf-8 -*-
from __future__ import annotations

import abc
import base64
import copy
import dataclasses
import datetime
from datetime import datetime as dt_cls
import gzip
import hashlib
import zlib
import functools
import html
import http.server
import inspect
import io
import json
import lzma
import math
import os
import pathlib
from pathlib import Path
import random
import re
import socketserver
import sqlite3
import statistics
import string
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import typing
import urllib.parse
import urllib.request
import uuid
import webbrowser
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import (
    Any, Callable, Dict, Generic, Iterable, Iterator, List,
    Literal, Mapping, NamedTuple, Optional, Protocol, Sequence,
    Set, Tuple, Type, TypeVar, Union
)

"""
Camada de Domínio () — Contratos e Interfaces Segregadas (ISP / DIP — SOLID).
"""
from .entities import *

class IFonteDadosCatalogo(ABC):
    @abstractmethod
    def carregar_tabelas_brutas(self) -> Dict[str, List[List[str]]]: pass


class IRepositorioCatalogoT20(ABC):
    @abstractmethod
    def listar_racas(self) -> List[Raca]: pass
    @abstractmethod
    def listar_classes(self) -> List[Classe]: pass
    @abstractmethod
    def listar_origens(self) -> List[Origem]: pass
    @abstractmethod
    def listar_deuses(self) -> List[Deus]: pass
    @abstractmethod
    def listar_pericias(self) -> List[Pericia]: pass
    @abstractmethod
    def listar_poderes_classe(self, classe: Optional[str] = None) -> List[Poder]: pass
    @abstractmethod
    def listar_poderes_gerais(self, categoria: Optional[str] = None) -> List[Poder]: pass
    @abstractmethod
    def listar_itens(self, categoria: Optional[str] = None) -> List[Item]: pass
    @abstractmethod
    def listar_magias(self, circulo_max: Optional[int] = None, tipo: Optional[str] = None) -> List[Magia]: pass


class IRepositorioPersonagem(ABC):
    @abstractmethod
    def salvar(self, ficha: FichaPersonagem) -> int: pass
    @abstractmethod
    def carregar(self, id_personagem: int) -> Optional[FichaPersonagem]: pass
    @abstractmethod
    def listar_resumo(self) -> List[Dict[str, Any]]: pass


class IEspecificacaoCSP(ABC):
    @abstractmethod
    def eh_satisfeita_por(self, ficha: FichaPersonagem) -> Tuple[bool, str]: pass


class IModificadorFicha(ABC):
    @abstractmethod
    def aplicar(self, ficha: FichaPersonagem) -> None: pass


class IRenderizadorFicha(ABC):
    @abstractmethod
    def renderizar(self, ficha: FichaPersonagem) -> str: pass


class IRenderizadorArvoreDecisao(ABC):
    """[SOLID ISP / GoF Strategy] Interface para renderizar a árvore de escolhas MCTS+CSP."""
    @abstractmethod
    def renderizar_arvore(self, ficha: FichaPersonagem) -> str: pass


class IEstrategiaAvaliacaoMCTS(ABC):
    @abstractmethod
    def nome_arquetipo(self) -> str: pass
    @abstractmethod
    def avaliar(self, ficha: FichaPersonagem) -> float: pass

