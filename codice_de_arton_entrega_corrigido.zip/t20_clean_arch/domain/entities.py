# -*- coding: utf-8 -*-
from __future__ import annotations

import abc
import base64
import copy
import dataclasses
import datetime
from datetime import datetime as dt_cls
import gzip
import hashlib
import zlib
import functools
import html
import http.server
import inspect
import io
import json
import lzma
import math
import os
import pathlib
from pathlib import Path
import random
import re
import socketserver
import sqlite3
import statistics
import string
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import typing
import urllib.parse
import urllib.request
import uuid
import webbrowser
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import (
    Any, Callable, Dict, Generic, Iterable, Iterator, List,
    Literal, Mapping, NamedTuple, Optional, Protocol, Sequence,
    Set, Tuple, Type, TypeVar, Union
)

"""
Camada de Domínio () — Entidades Puras, Tabelas Oficiais de Ameaças e Catálogo Cap. 7.
"""

ATRIBUTOS_NOMES: Tuple[str, ...] = ("FOR", "DES", "CON", "INT", "SAB", "CAR")

CUSTO_COMPRA_PONTOS_T20: Dict[int, int] = {
    -1: -1, 0: 0, 1: 1, 2: 2, 3: 4, 4: 7,
}

MAPA_SINONIMOS_ATRIBUTOS: Dict[str, str] = {
    "FOR": "FOR", "FORÇA": "FOR", "FORCA": "FOR",
    "DES": "DES", "DESTREZA": "DES",
    "CON": "CON", "CONSTITUIÇÃO": "CON", "CONSTITUICAO": "CON",
    "INT": "INT", "INTELIGÊNCIA": "INT", "INTELIGENCIA": "INT",
    "SAB": "SAB", "SABEDORIA": "SAB",
    "CAR": "CAR", "CARISMA": "CAR",
}


@dataclass
class Atributos:
    FOR: int = 0
    DES: int = 0
    CON: int = 0
    INT: int = 0
    SAB: int = 0
    CAR: int = 0

    def obter(self, sigla: str) -> int:
        chave = MAPA_SINONIMOS_ATRIBUTOS.get(sigla.strip().upper(), sigla.strip().upper())
        return int(getattr(self, chave, 0))

    def definir(self, sigla: str, valor: int) -> None:
        chave = MAPA_SINONIMOS_ATRIBUTOS.get(sigla.strip().upper(), sigla.strip().upper())
        if hasattr(self, chave):
            setattr(self, chave, int(valor))

    def somar(self, sigla: str, delta: int) -> None:
        self.definir(sigla, self.obter(sigla) + int(delta))

    def copiar(self) -> Atributos:
        return Atributos(self.FOR, self.DES, self.CON, self.INT, self.SAB, self.CAR)

    def para_dict(self) -> Dict[str, int]:
        return {a: self.obter(a) for a in ATRIBUTOS_NOMES}


@dataclass(frozen=True)
class Raca:
    id_raca: str
    nome: str
    categoria: str
    mod_for: int
    mod_des: int
    mod_con: int
    mod_int: int
    mod_sab: int
    mod_car: int
    mod_livre: str
    tamanho: str
    deslocamento_m: int
    tipo_criatura: str
    habilidades_raca: str


@dataclass(frozen=True)
class Classe:
    id_classe: str
    nome: str
    atributo_principal: str
    pv_inicial: int
    pv_por_nivel: int
    pm_por_nivel: int
    pericias_fixas: str
    qtd_pericias_escolha: int
    lista_pericias_escolha: str
    proficiencias: str
    habilidades_fixas: str


@dataclass(frozen=True)
class Origem:
    id_origem: str
    nome: str
    itens_iniciais: str
    pericias_disponiveis: str
    poderes_disponiveis: str
    poder_unico: str
    efeito_poder_unico: str


@dataclass(frozen=True)
class Deus:
    id_deus: str
    nome: str
    titulo: str
    energia: str
    arma_preferida: str
    devotos_permitidos: str
    poderes_concedidos: str
    obrigacoes_restricoes: str


@dataclass(frozen=True)
class Pericia:
    id_pericia: str
    nome: str
    atributo_chave: str
    somente_treinada: bool
    penalidade_armadura: bool
    usos_e_regras: str


@dataclass(frozen=True)
class Poder:
    id_poder: str
    categoria_ou_classe: str
    nome: str
    pre_requisitos: str
    custo_pm: str
    acao: str
    efeito_resumo: str
    eh_poder_classe: bool = False


@dataclass(frozen=True)
class Item:
    id_item: str
    categoria: str
    subcategoria: str
    nome: str
    preco: str
    dano_ou_defesa: str
    critico_ou_penalidade: str
    alcance: str
    tipo_dano: str
    espacos: float
    efeito_propriedades: str


@dataclass(frozen=True)
class Magia:
    id_magia: str
    nome: str
    tipo: str
    circulo: int
    escola: str
    execucao: str
    alcance: str
    alvo_area_efeito: str
    duracao: str
    resistencia: str
    efeito_e_aprimoramentos: str


@dataclass(frozen=True)
class AmeacaParametro:
    """
    Estatísticas oficiais de Ameaças de Tormenta20 (Jogo do Ano, p. 323 do livro / p. 329 do PDF
    e Manual de Criação de Ameaças por Rafael Dei Svaldi).
    """
    id_ameaca: str
    patamar: str
    nd: str
    papel: str          # 'Solo', 'Lacaio' ou 'Especial'
    bonus_ataque: int
    dano_medio: int
    defesa: int
    res_forte: int
    res_media: int
    res_fraca: int
    pv: int
    cd_efeito: int
    pm_por_nd: int
    regras_papel: str
    fonte_url: str = "https://pt.scribd.com/document/641977280/Manual-de-Criacao-de-Ameacas"


# Tabela Oficial de Parâmetros de Ameaças (Tormenta20 — Edição Jogo do Ano v1.3 / Regras de Ameaças Tabela 2-3 A/B/C)
TABELA_AMEACAS_OFICIAL_T20: Tuple[AmeacaParametro, ...] = (
    # PAPEL 1: SOLO (Tabela 2-3 A — Solos, ND 1/4 a 20)
    AmeacaParametro("AME_SOLO_025", "Iniciante", "1/4", "Solo", 6, 8, 11, 3, 0, -2, 7, 12, 1, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_050", "Iniciante", "1/2", "Solo", 7, 10, 14, 6, 3, -1, 15, 13, 2, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_01", "Iniciante", "1", "Solo", 9, 15, 16, 11, 5, 0, 35, 14, 3, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_02", "Iniciante", "2", "Solo", 12, 18, 19, 13, 7, 2, 70, 16, 6, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_03", "Iniciante", "3", "Solo", 14, 21, 21, 15, 9, 3, 105, 17, 9, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_04", "Iniciante", "4", "Solo", 16, 24, 23, 16, 10, 4, 140, 18, 12, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_05", "Veterano", "5", "Solo", 17, 40, 24, 17, 11, 5, 200, 20, 15, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_06", "Veterano", "6", "Solo", 20, 56, 27, 18, 12, 6, 240, 22, 18, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_07", "Veterano", "7", "Solo", 24, 62, 31, 20, 14, 7, 280, 24, 21, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_08", "Veterano", "8", "Solo", 26, 68, 33, 21, 15, 8, 320, 26, 24, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_09", "Veterano", "9", "Solo", 27, 74, 34, 21, 15, 9, 360, 28, 27, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_10", "Veterano", "10", "Solo", 29, 80, 36, 22, 16, 10, 400, 30, 30, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_11", "Campeão", "11", "Solo", 34, 130, 41, 24, 18, 11, 550, 31, 33, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_12", "Campeão", "12", "Solo", 36, 144, 43, 26, 20, 12, 600, 33, 36, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_13", "Campeão", "13", "Solo", 37, 158, 44, 26, 20, 13, 650, 35, 39, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_14", "Campeão", "14", "Solo", 39, 172, 46, 28, 22, 14, 700, 38, 42, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_15", "Campeão", "15", "Solo", 43, 186, 50, 28, 22, 15, 750, 40, 45, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_16", "Campeão", "16", "Solo", 46, 200, 53, 30, 24, 16, 800, 42, 48, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_17", "Lenda", "17", "Solo", 47, 270, 54, 30, 24, 17, 1020, 44, 51, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_18", "Lenda", "18", "Solo", 49, 288, 56, 32, 26, 18, 1080, 47, 54, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_19", "Lenda", "19", "Solo", 52, 306, 59, 32, 26, 19, 1140, 47, 57, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    AmeacaParametro("AME_SOLO_20", "Lenda", "20", "Solo", 54, 324, 61, 34, 28, 20, 1200, 49, 60, "Ameaça Solo oficial JdA (Tabela 2-3 A)"),
    # PAPEL 2: LACAIO (Tabela 2-3 B — Lacaios, ND 1/4 a 20)
    AmeacaParametro("AME_LAC_025", "Iniciante", "1/4", "Lacaio", 7, 9, 10, 2, 0, -1, 4, 12, 1, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_050", "Iniciante", "1/2", "Lacaio", 9, 11, 13, 5, 3, 0, 6, 13, 2, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_01", "Iniciante", "1", "Lacaio", 11, 17, 15, 10, 5, 1, 9, 14, 3, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_02", "Iniciante", "2", "Lacaio", 14, 21, 18, 12, 7, 3, 14, 16, 6, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_03", "Iniciante", "3", "Lacaio", 16, 24, 20, 14, 9, 4, 21, 17, 9, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_04", "Iniciante", "4", "Lacaio", 17, 32, 22, 15, 10, 5, 28, 18, 12, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_05", "Veterano", "5", "Lacaio", 20, 56, 23, 16, 11, 6, 40, 20, 15, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_06", "Veterano", "6", "Lacaio", 24, 62, 26, 17, 12, 7, 48, 22, 18, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_07", "Veterano", "7", "Lacaio", 26, 68, 30, 19, 14, 8, 56, 24, 21, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_08", "Veterano", "8", "Lacaio", 27, 74, 32, 20, 15, 9, 64, 26, 24, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_09", "Veterano", "9", "Lacaio", 29, 80, 33, 20, 15, 10, 72, 28, 27, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_10", "Veterano", "10", "Lacaio", 34, 105, 35, 21, 16, 11, 80, 30, 30, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_11", "Campeão", "11", "Lacaio", 36, 144, 40, 23, 18, 12, 110, 31, 33, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_12", "Campeão", "12", "Lacaio", 37, 158, 42, 25, 20, 13, 120, 33, 36, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_13", "Campeão", "13", "Lacaio", 39, 172, 43, 25, 20, 14, 130, 35, 39, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_14", "Campeão", "14", "Lacaio", 43, 186, 45, 27, 22, 15, 140, 38, 42, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_15", "Campeão", "15", "Lacaio", 46, 200, 49, 27, 22, 16, 150, 40, 45, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_16", "Campeão", "16", "Lacaio", 47, 235, 52, 29, 24, 17, 160, 42, 48, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_17", "Lenda", "17", "Lacaio", 49, 288, 53, 29, 24, 18, 204, 44, 51, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_18", "Lenda", "18", "Lacaio", 52, 306, 55, 31, 26, 19, 216, 47, 54, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_19", "Lenda", "19", "Lacaio", 54, 324, 58, 31, 26, 20, 228, 47, 57, "Lacaio oficial JdA (Tabela 2-3 B)"),
    AmeacaParametro("AME_LAC_20", "Lenda", "20", "Lacaio", 56, 344, 60, 33, 28, 21, 240, 49, 60, "Lacaio oficial JdA (Tabela 2-3 B)"),
    # PAPEL 3: ESPECIAL (Tabela 2-3 C — Especiais, ND 1/4 a 20)
    AmeacaParametro("AME_ESP_025", "Iniciante", "1/4", "Especial", 4, 8, 11, 3, 0, -2, 5, 14, 1, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_050", "Iniciante", "1/2", "Especial", 5, 10, 12, 6, 3, -1, 11, 15, 2, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_01", "Iniciante", "1", "Especial", 7, 15, 14, 11, 5, 0, 25, 16, 5, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_02", "Iniciante", "2", "Especial", 10, 18, 17, 13, 7, 2, 49, 18, 8, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_03", "Iniciante", "3", "Especial", 12, 21, 19, 15, 9, 3, 74, 19, 12, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_04", "Iniciante", "4", "Especial", 14, 24, 21, 16, 10, 4, 98, 20, 16, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_05", "Veterano", "5", "Especial", 15, 40, 22, 17, 11, 5, 140, 22, 20, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_06", "Veterano", "6", "Especial", 18, 56, 25, 18, 12, 6, 168, 24, 24, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_07", "Veterano", "7", "Especial", 22, 62, 29, 20, 14, 7, 196, 26, 28, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_08", "Veterano", "8", "Especial", 24, 68, 31, 21, 15, 8, 224, 28, 32, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_09", "Veterano", "9", "Especial", 25, 74, 32, 21, 15, 9, 252, 30, 36, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_10", "Veterano", "10", "Especial", 27, 80, 34, 22, 16, 10, 280, 32, 40, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_11", "Campeão", "11", "Especial", 32, 130, 39, 24, 18, 11, 385, 33, 44, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_12", "Campeão", "12", "Especial", 34, 144, 41, 26, 20, 12, 420, 35, 48, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_13", "Campeão", "13", "Especial", 35, 158, 42, 26, 20, 13, 455, 37, 52, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_14", "Campeão", "14", "Especial", 37, 172, 44, 28, 22, 14, 490, 40, 56, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_15", "Campeão", "15", "Especial", 41, 186, 48, 28, 22, 15, 525, 42, 60, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_16", "Campeão", "16", "Especial", 44, 200, 51, 30, 24, 16, 560, 44, 64, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_17", "Lenda", "17", "Especial", 45, 270, 52, 30, 24, 17, 714, 46, 68, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_18", "Lenda", "18", "Especial", 47, 288, 54, 32, 26, 18, 756, 49, 72, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_19", "Lenda", "19", "Especial", 50, 306, 57, 32, 26, 19, 798, 49, 76, "Especial oficial JdA (Tabela 2-3 C)"),
    AmeacaParametro("AME_ESP_20", "Lenda", "20", "Especial", 52, 324, 59, 34, 28, 20, 840, 51, 80, "Especial oficial JdA (Tabela 2-3 C)"),
)


def obter_estatisticas_ameaca_oficial(nd_nivel: int, papel: str = "Solo") -> AmeacaParametro:
    """Busca na Tabela Oficial de Ameaças (Tormenta20 JdA Tabela 2-3 A/B/C) os parâmetros exatos por ND e Papel."""
    nd_str = str(max(1, min(20, int(nd_nivel))))
    papel_norm = papel.strip().capitalize()
    for a in TABELA_AMEACAS_OFICIAL_T20:
        if a.nd == nd_str and a.papel.lower() == papel_norm.lower():
            return a
    for a in TABELA_AMEACAS_OFICIAL_T20:
        if a.nd == nd_str and a.papel == "Solo":
            return a
    return TABELA_AMEACAS_OFICIAL_T20[2]  # ND 1 Solo fallback


@dataclass(frozen=True)
class AmeacaCapitulo7:
    """Representa uma ficha oficial de Ameaça do Capítulo 7 (Tormenta20 — Edição Jogo do Ano v1.3, pp. 282-323)."""
    id_ameaca: str
    grupo_cap7: str
    nome: str
    nd: str
    nd_numerico: float
    tipo_nivel_tamanho: str
    papel: str
    iniciativa: int
    percepcao: int
    defesa: int
    fortitude: int
    reflexos: int
    vontade: int
    pv: int
    pm: int
    deslocamento: str
    bonus_ataque: int
    dano_medio: int
    ataques_e_acoes: str
    cd_efeito: int
    atributos: str
    habilidades_e_resistencias: str
    equipamento_e_tesouro: str
    pagina_livro_pdf: str
    fonte_url: str = "https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano"


RAW_AMEACAS_CAP7 = """ID_Ameaca|Grupo_Cap7|Nome|ND|Tipo_Nivel_Tamanho|Papel|Iniciativa|Percepcao|Defesa|Fortitude|Reflexos|Vontade|PV|PM|Deslocamento|Bonus_Ataque|Dano_Medio|Ataques_E_Acoes|CD_Efeito|Atributos|Habilidades_E_Resistencias|Equipamento_E_Tesouro|Pagina_Livro_PDF|Fonte_URL
CAP7_001|Masmorras|Glop|1/4|Monstro Pequeno|Lacaio|+2|+0|10|+0|+2|-5|12|0|6m (4q)|+7|9|Pancada +7 (1d4+2 mais 1d4 ácido)|12|For 0, Des 0, Con 2, Int —, Sab -5, Car -5|Percepção às cegas; Imunidade a ácido e acertos críticos|Tesouro: 1 dose de ácido (CD 15)|Livro JdA p. 285|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_002|Masmorras|Rato Gigante|1/4|Animal Pequeno|Lacaio|+5|+3|12|+0|+3|-2|4|0|12m (8q), escalar 6m|+7|5|Mordida +7 (1d4+3 mais doença)|12|For 0, Des 3, Con 1, Int -4, Sab 1, Car -3|Faro, visão na penumbra; Doença: Infecção do esgoto (Fort CD 12 evita)|Tesouro: Nenhum|Livro JdA p. 287|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_003|Ermos|Bandido|1/4|Humanoide (humano) Médio|Lacaio|+4|+1|13|+1|+3|-1|6|0|9m (6q)|+7|6|Clava +7 (1d6+3)|12|For 1, Des 2, Con 1, Int 0, Sab -1, Car 0|Perícias: Furtividade +5, Intimidação +2|Armadura de couro, clava; Tesouro: Metade|Livro JdA p. 288|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_004|Cultistas da Traição|Cascavel|1/4|Animal Minúsculo|Lacaio|+5|+1|13|+2|+5|-1|4|0|6m, escalar 6m, natação 6m|+7|8|Mordida +7 (1 perfuração mais veneno 1d12)|12|For -2, Des 3, Con 1, Int -4, Sab 1, Car -4|Faro, visão na penumbra; Veneno: perde 1d12 PV (Fort CD 12 evita); Furtividade +10|1 dose de peçonha comum (CD 15)|Livro JdA p. 304|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_005|Masmorras|Orc Combatente|1/2|Humanoide (orc) Médio|Lacaio|+4|+1|14|+5|+3|+0|8|0|9m (6q)|+9|11|Maça +9 (1d8+7)|13|For 4, Des 1, Con 2, Int -1, Sab -1, Car -1|Visão no escuro; Sensibilidade a Luz (ofuscado sob luz solar); Feroz (+2 dano)|Couro batido, maça; Tesouro: Metade|Livro JdA p. 287|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_006|Ermos|Guarda de Cidade|1/2|Humanoide (humano) Médio|Lacaio|+2|+3|15|+5|+2|+1|8|0|9m (6q)|+9|10|Maça +9 (1d8+6)|13|For 2, Des 1, Con 2, Int 0, Sab 0, Car 0|Perícias: Atletismo +5, Percepção +3|Apito, couro batido, escudo leve, maça; Tesouro: Nenhum|Livro JdA p. 291|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_007|Reino dos Mortos|Zumbi|1/4|Morto-vivo Médio|Lacaio|+0|+0|11|+3|-1|-1|10|0|6m (4q)|+6|7|Mordida +6 (1d6+4)|12|For 3, Des -1, Con 2, Int —, Sab -1, Car -5|Visão no escuro; Fraqueza Zumbi (sofre dobro de dano de acertos críticos); Imunidades de Morto-vivo|Tesouro: Nenhum|Livro JdA p. 299|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_008|Duyshidakk|Goblin Salteador|1/4|Humanoide (goblin) Pequeno|Lacaio|+4|+0|13|+2|+3|-1|5|0|9m, escalar 9m|+7|9|2 adagas +7 (1d4+2, 19)|12|For 0, Des 3, Con 1, Int 1, Sab -1, Car -2|Visão no escuro; Oportunista (+2 no ataque e dano contra alvos flanqueados ou que já sofreram dano na rodada)|Adagas x2, armadura de couro; Tesouro: Metade|Livro JdA p. 302|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_009|Ermos|Gnoll Saqueador|1|Humanoide (gnoll) Médio|Lacaio|+3|+5|15|+7|+7|+1|12|0|9m (6q)|+11|17|Lança +11 (1d6+5) e mordida +11 (1d6+5) ou Arco curto +9 (1d6+4, x3)|14|For 3, Des 2, Con 3, Int -2, Sab 0, Car -1|Faro; Rendição (inimigos adjacentes rendidos sofrem +1d6 dano)|Arco curto, couro batido, escudo leve, lança; Tesouro: Metade|Livro JdA p. 290|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_010|Ermos|Lobo|1/2|Animal Médio|Solo|+4|+6|14|+6|+3|+1|15|0|15m (10q)|+7|10|Mordida +7 (1d6+6)|13|For 3, Des 3, Con 3, Int -4, Sab 2, Car -2|Faro, visão na penumbra; Derrubar (livre ao acertar mordida, teste +9); Táticas de Alcateia (+2 ataque e dano quando flanqueia)|Tesouro: Nenhum|Livro JdA p. 291|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_011|Puristas|Recruta Purista|1/2|Humanoide (humano) Médio|Lacaio|+3|+0|16|+6|+2|+0|8|0|6m (4q)|+9|11|Alabarda +9 (1d10+6, x3)|13|For 3, Des 1, Con 3, Int -1, Sab -1, Car -1|Lutar em Formação (+1 ataque e Defesa adjacente a aliado); Ódio Puro (+5 Von sob ordens, +2 dano vs não-humanos)|Alabarda, cota de malha; Tesouro: Nenhum|Livro JdA p. 294|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_012|Cultistas da Traição|Jiboia|1/2|Animal Médio|Solo|+4|+2|14|+3|+5|+0|15|0|6m, escalar 6m, natação 6m|+7|10|Mordida +7 (1d4+4)|13|For 3, Des 3, Con 1, Int -4, Sab 1, Car -4|Faro, visão na penumbra; Agarrar Aprimorado (mordida, teste +9); Constrição (2d4+4 impacto no início do turno)|Tesouro: Nenhum|Livro JdA p. 304|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_013|Ermos|Chefe Bandido|1|Humanoide (humano) Médio|Solo|+4|+2|16|+5|+8|+3|30|0|9m (6q)|+9|15|Espada curta +9 (1d6+5, 19) ou Adaga +7 (1d4+3, 19)|14|For 3, Des 2, Con 2, Int 0, Sab 0, Car 1|Ataque Furtivo (+2d6 dano contra alvos desprevenidos ou flanqueados); Ordens (+2 perícias p/ aliados); Furtividade +7|Adaga, couro batido, espada curta; Tesouro: Padrão|Livro JdA p. 288|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_014|Ermos|Centauro Combatente|1|Humanoide (centauro) Grande|Solo|+3|+4|16|+9|+2|+5|35|0|12m (8q)|+9|15|Tacape +9 (1d10+5) e cascos +9 (1d6+3) ou Arco longo +7 (1d8+4, x3)|14|For 4, Des 1, Con 2, Int -2, Sab 1, Car -1|Medo de Altura (abalado adjacente a queda de 3m+); Investida Poderosa (+2d8 dano em investida)|Arco longo, gibão de peles, tacape; Tesouro: Metade|Livro JdA p. 289|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_015|Ermos|Gorlogg|1|Animal Grande|Solo|+4|+3|16|+8|+5|+3|36|0|12m (8q)|+11|15|Mordida +11 (2d6+8, x3)|14|For 5, Des 2, Con 5, Int -4, Sab 1, Car -2|Visão na penumbra; Agarrar Aprimorado (livre na mordida, teste +13); Atletismo +9|Tesouro: Nenhum (Parceiro Montaria Grande)|Livro JdA p. 290|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_016|Ermos|Sargento da Guarda|1|Humanoide (humano) Médio|Solo|+4|+5|17|+9|+4|+3|32|0|6m (4q)|+10|15|Maça +10 (1d8+10) ou Besta leve +8 (1d8+4, 19)|14|For 3, Des 1, Con 2, Int 0, Sab 0, Car 1|Ordens (Movimento: aliados em alcance médio recebem +2 em testes de perícia até o fim da cena); Atletismo +9|Besta leve, cota de malha, escudo pesado, maça; Tesouro: Metade|Livro JdA p. 291|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_017|Ermos|Trog|1|Monstro (trog) Médio|Lacaio|+3|+0|16|+10|+5|+1|11|0|9m (6q)|+11|17|Lança +11 (1d6+5) e mordida +11 (1d6+5) ou Azagaia +9 (1d6+5)|15|For 3, Des 1, Con 3, Int -2, Sab 0, Car -1|Visão no escuro; Mau Cheiro (Padrão: Fort CD 15 ou enjoado 1d6 rodadas); Sangue Frio (+1 dano por dado de frio); Furtividade +7|Azagaias x2, escudo leve, lança; Tesouro: Metade|Livro JdA p. 292|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_018|Puristas|Soldado Purista|1|Humanoide (humano) Médio|Lacaio|+3|+1|20|+10|+4|+1|12|0|6m (4q)|+11|17|Espada bastarda +11 (1d10+12, 19) ou Besta pesada +9 (1d12+4, 19)|14|For 4, Des 1, Con 3, Int -1, Sab 0, Car -1|Lutar em Formação (+1 ataque e Defesa adjacente a aliado); Ódio Puro (+5 Von sob ordens, +2 dano vs não-humanos)|Besta pesada, escudo pesado, espada bastarda, meia armadura; Tesouro: Metade|Livro JdA p. 294|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_019|Duyshidakk|Hobgoblin Soldado|2|Humanoide (hobgoblin) Médio|Lacaio|+5|+2|19|+12|+7|+3|18|0|6m (4q)|+14|21|Espada longa +14 (1d8+16, 19) ou Arco longo +12 (1d8+10, x3)|16|For 4, Des 2, Con 2, Int 0, Sab 0, Car -1|Visão no escuro; Tática Militar (+2 ataque e Defesa quando adjacente a outro hobgoblin)|Arco longo, cota de malha, escudo pesado, espada longa; Tesouro: Metade|Livro JdA p. 302|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_020|Cultistas da Traição|Naja|1|Animal Pequeno|Solo|+6|+3|17|+5|+10|+1|28|0|6m, escalar 6m, natação 6m|+10|15|Mordida +10 (1d4+2 mais veneno 1d12/rodada)|14|For 0, Des 4, Con 1, Int -4, Sab 1, Car -4|Faro, visão na penumbra; Veneno: perde 1d12 PV por 1d4 rodadas (Fort CD 14 reduz a 1 rodada); Furtividade +10|1 dose de peçonha concentrada (CD 16)|Livro JdA p. 304|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_021|Masmorras|Aranha Gigante|2|Monstro Grande|Solo|+7|+3|19|+8|+11|+3|70|0|12m, escalar 12m|+12|18|Mordida +12 (2d6+11 mais veneno)|16|For 5, Des 4, Con 2, Int -4, Sab 0, Car -4|Visão no escuro; Teia (Movimento: área 3m, Ref CD 16 evita enredado); Veneno: perde 1d12 PV e fica fraco (Fort CD 16 evita fraco)|1d4 doses de veneno de aranha gigante (CD 17)|Livro JdA p. 284|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_022|Masmorras|Gárgula|2|Construto Médio|Solo|+4|+4|19|+13|+7|+2|60|0|12m, voo 18m|+12|18|2 garras +12 (1d6+6)|16|For 5, Des 2, Con 4, Int -2, Sab 0, Car -2|Visão no escuro, RD 5; Imobilidade (Percepção CD 30 para notar que não é estátua); Imunidades de Construto|Tesouro: Padrão|Livro JdA p. 285|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_023|Masmorras|Orc Chefe|2|Humanoide (orc) Médio|Solo|+5|+3|19|+13|+7|+2|66|0|9m (6q)|+11|18|Machado de batalha +11 (1d8+12, x3)|16|For 5, Des 2, Con 4, Int 0, Sab 0, Car 0|Visão no escuro; Urro Selvagem (Movimento: +2 ataque e dano corpo a corpo até o fim da cena); Sensibilidade a Luz|Gibão de peles, machado de batalha; Tesouro: Padrão|Livro JdA p. 287|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_024|Ermos|Gnoll Filibusteiro|2|Humanoide (gnoll) Médio|Solo|+7|+6|19|+7|+11|+4|65|0|9m (6q)|+12|18|Mosquete +12 (2d8+9, 19/x3) ou Espada curta +12 (1d6+6, 19) e mordida +12 (1d6+6)|16|For 3, Des 3, Con 3, Int -1, Sab 1, Car -1|Faro; Saque Rápido (recarrega mosquete como movimento e saca livre)|Balas x20, couraça, espada curta, mosquete; Tesouro: Padrão|Livro JdA p. 290|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_025|Ermos|Lobo-das-Cavernas|2|Animal Grande|Solo|+5|+9|19|+11|+7|+6|70|0|15m (10q)|+14|18|Mordida +14 (2d6+11)|16|For 6, Des 2, Con 5, Int -4, Sab 2, Car -2|Faro, visão na penumbra; Derrubar (livre na mordida, teste +16); Táticas de Alcateia (+4 ataque e +2 dano ao flanquear)|Tesouro: Nenhum (Parceiro Montaria Grande)|Livro JdA p. 292|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_026|Reino dos Mortos|Esqueleto|2|Morto-vivo Médio|Lacaio|+6|+2|19|+3|+7|+12|16|0|6m (4q)|+14|21|Espada longa +14 (1d8+16, 19)|16|For 4, Des 2, Con 1, Int —, Sab 0, Car -5|Visão no escuro; RD 5/impacto, imunidade a frio; Imunidades de Morto-vivo|Cota de malha, espada longa, escudo pesado; Tesouro: Nenhum|Livro JdA p. 297|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_027|Reino dos Mortos|Turba Zumbi|2|Morto-vivo (bando) Grande|Solo|+0|+0|11|+5|+1|+1|85|0|6m (4q)|+14|18|[Bando] Mordida +14 (2d6+11)|16|For 3, Des -1, Con 2, Int —, Sab -1, Car -5|Bando (dobro do dano se exceder Def por 10+; metade se errar; +50% dano de área); Fraqueza Zumbi|Tesouro: Nenhum|Livro JdA p. 299|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_028|Trolls Nobres|Finntroll Caçador|2|Monstro (finntroll) Médio|Solo|+7|+7|19|+6|+12|+4|65|0|9m (6q)|+12|20|2 espadas curtas +12 (1d6+6, 19) ou Besta pesada +12 (1d12+6, 19) ou Rede +12|16|For 1, Des 4, Con 3, Int 2, Sab 2, Car -1|Natureza Vegetal, resistência a magia +2; Marca da Presa (Movimento: +1d8 dano); Regeneração Vegetal (5 PV sob luz)|Besta pesada, couraça, espada curta x2, rede; Tesouro: Padrão|Livro JdA p. 308|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_029|Dragões|Enxame Kobold|2|Humanoide (kobold, enxame) Médio|Solo|+7|+9|17|+7|+13|+2|60|0|9m (6q)|+12|18|Enxame (3d6+8 perfuração automático) + Caixa com Pregos (2d6 + atordoado, Ref CD 16)|16|For 0, Des 3, Con 0, Int -1, Sab 0, Car -2|Enxame (metade dano armas, +50% área); Unidos Venceremos (+10 PV no início do turno até 100 PV)|Tesouro: Metade|Livro JdA p. 313|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_030|Tormenta|Maníaco Lefou|2|Monstro (lefou) Médio|Solo|+4|+2|18|+12|+7|+3|75|0|9m (6q)|+12|18|Machado de guerra +12 (1d12+12, x3)|16|For 5, Des 1, Con 2, Int -1, Sab -1, Car -2|Frenesi Insano (sempre que causa ou sofre dano, recebe +2 cumulativo em ataque e dano até o fim da cena)|Gibão de peles, machado de guerra; Tesouro: Metade|Livro JdA p. 316|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_031|Masmorras|Guerreiro de Chifres|3|Espírito (abissal) Médio|Solo|+8|+5|21|+13|+11|+9|100|0|9m (6q)|+15|21|Machado de guerra +15 (1d12+10, x3) e chifres +15 (1d6+6)|17|For 5, Des 3, Con 4, Int -2, Sab 0, Car -1|Faro, visão no escuro; RD 5, resistência a fogo/frio 10, imune a ácido e veneno; Marrada (investida com machado e chifres)|Couraça, machado de guerra cruel; Tesouro: Padrão|Livro JdA p. 286|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_032|Ermos|Cão do Inferno|3|Espírito Grande|Solo|+8|+8|21|+11|+9|+7|95|0|12m (8q)|+14|21|Mordida +14 (2d6+8 mais 2d6 fogo); Sopro (Padrão: cone 6m, 4d6+4 fogo, Ref CD 17)|17|For 5, Des 3, Con 4, Int -2, Sab 1, Car -2|Faro, visão no escuro; Imunidade a fogo, RD 10/mágico, vulnerabilidade a frio|1d4 doses de essência abissal (CD 18)|Livro JdA p. 289|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_033|Ermos|Centauro Xamã|3|Humanoide (centauro) Grande|Especial|+4|+8|21|+9|+4|+15|74|18|12m (8q)|+12|21|Bordão +12 (1d8+6) e cascos +12 (1d8+6)|19|For 3, Des 1, Con 3, Int -1, Sab 5, Car 0|Magias Divinas (1º Armamento da Natureza, Controlar Plantas, Curar Ferimentos 3d8+3; 2º Enxame de Pestes 4d12, CD 19)|Bordão aumentado, gibão de peles reforçado; Tesouro: Metade|Livro JdA p. 289|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_034|Ermos|Grifo|3|Monstro Grande|Solo|+9|+9|19|+9|+15|+4|105|0|12m, voo 24m|+14|24|Mordida +14 (2d6+6) e 2 garras +14 (1d6+4)|17|For 5, Des 4, Con 3, Int -4, Sab 2, Car -1|Visão no escuro; Bote (Completa: investida atacando com mordida e 2 garras com +2 em todos os 3 ataques)|25% chance de 1d4 ovos de grifo (T$ 2.500 cada)|Livro JdA p. 290|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_035|Puristas|Sargento-mor|3|Humanoide (humano) Médio|Solo|+6|+4|24|+14|+9|+5|95|0|6m (4q)|+14|21|Espada bastarda +14 (1d12+14, 19) ou Besta pesada +12 (1d12+6, 19)|17|For 5, Des 1, Con 3, Int -1, Sab 0, Car 0|Lutar em Formação (+1 ataque/Def); Varrer (Livre: ataque extra ao reduzir alvo a 0 PV); Ódio Puro|Armadura completa, escudo pesado, espada bastarda aumentada certeira; Tesouro: Padrão|Livro JdA p. 294|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_036|Duyshidakk|Goblin Engenhoqueiro|3|Humanoide (goblin) Pequeno|Especial|+6|+3|19|+3|+15|+9|68|0|9m, escalar 9m|+12|21|Cospe-chamas (6d6 fogo em cone de 6m, Ref CD 19) ou Besta leve +12 (1d8+6, 19)|19|For 0, Des 3, Con 2, Int 4, Sab -1, Car -1|Engenhocas (Ofício +13): Asa de Bambu (voo 12m), Cospe-chamas (6d6 fogo, CD 19), Gritador (-2 ataque e dano em alcance curto)|Adaga, besta leve, couro batido, kit de engenhoqueiro; Tesouro: Metade|Livro JdA p. 301|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_037|Cultistas da Traição|Sucuri|3|Animal Grande|Solo|+7|+6|19|+9|+15|+3|110|0|6m, escalar 9m, natação 9m|+15|21|Mordida +15 (1d8+8) + Constrição (2d8+12 impacto)|17|For 7, Des 2, Con 4, Int -4, Sab 1, Car -4|Faro, visão na penumbra; Agarrar Aprimorado (livre na mordida, teste +19); Constrição (2d8+12 automático por turno)|Tesouro: Nenhum|Livro JdA p. 304|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_038|Cultistas da Traição|Nagah Guardião|3|Monstro (nagah) Médio|Solo|+7|+4|21|+6|+11|+9|105|0|9m (6q)|+14|21|2 cimitarras +14 (1d6+5, 18) e cauda +14 (1d6+4)|17|For 4, Des 2, Con 3, Int -1, Sab 0, Car 0|Resistência a veneno +5; Fraquezas Ofídias (-5 contra música e +1 dano por dado de frio)|Cimitarras x2, meia armadura; Tesouro: Padrão|Livro JdA p. 306|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_039|Dragões|Dragão Filhote|3|Monstro (dragão) Médio|Solo|+9|+8|22|+15|+3|+9|115|0|12m, voo 18m|+14|24|Mordida +14 (1d8+6) e 2 garras +14 (1d6+5); Sopro (Padrão: cone 6m, 4d12 fogo, Ref CD 17, recarga mov)|17|For 5, Des 3, Con 4, Int 0, Sab 1, Car 0|Percepção às cegas, visão no escuro; Imune a fogo/paralisia/sono, vulnerável a frio|Tesouro: Padrão|Livro JdA p. 310|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_040|Tormenta|Uktril|3|Monstro (lefeu) Médio|Lacaio|+9|+12|22|+12|+11|+6|32|0|9m (6q)|+16|24|Pinça +16 (2d6+8, 19) e garra +16 (1d6+6)|17|For 5, Des 4, Con 3, Int -1, Sab 2, Car -4|RD 5, Imunidades Lefeu (crítico, ácido, eletricidade, fogo, frio, luz, trevas, metamorfose); Insanidade da Tormenta 1d6 PM (Von CD 17)|Tesouro: Nenhum|Livro JdA p. 314|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_041|Ermos|Basilisco|4|Monstro Médio|Solo|+6|+9|23|+10|+9|+9|135|0|9m, natação 9m|+16|24|Mordida +16 (1d8+8 mais veneno 2d12)|18|For 4, Des 2, Con 4, Int -4, Sab 1, Car 0|RD 5; Olhar Petrificante (Início do turno em alcance curto: Ref CD 18 ou lento -> petrificado); Veneno 2d12 (Fort CD 18 reduz metade)|1d4 doses de veneno e couro de basilisco; Tesouro: Padrão|Livro JdA p. 288|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_042|Ermos|Ogro|4|Humanoide (gigante) Grande|Solo|+3|+1|23|+16|+10|+0|130|0|9m (6q)|+16|24|Tacape +16 (1d12+18)|18|For 7, Des 0, Con 4, Int -3, Sab -2, Car -2|Visão na penumbra; Burro Demais... (-5 Intuição/Vontade) ...Para Morrer! (reduz à metade todo dano de corte, impacto e perfuração)|Gibão de peles, tacape aumentado; Tesouro: Padrão|Livro JdA p. 292|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_043|Ermos|Urso-Coruja|4|Monstro Grande|Solo|+6|+8|23|+16|+10|+5|145|0|12m (8q)|+16|27|Mordida +16 (1d8+7) e 2 garras +16 (1d6+6)|18|For 7, Des 3, Con 5, Int -4, Sab 1, Car -2|Faro, visão no escuro; Agarrar Aprimorado (livre na garra, teste +18); Abraço Esmagador (2d6+10 impacto se acertar as 2 garras)|Tesouro: Nenhum|Livro JdA p. 293|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_044|Puristas|Capelão de Guerra|4|Humanoide (humano) Médio|Especial|+6|+10|21|+10|+5|+16|98|24|6m (4q)|+14|21|Martelo de guerra +14 (1d8+12, x3)|20|For 4, Des 0, Con 4, Int 1, Sab 5, Car -1|Coragem Total (imune a medo); Sangue de Ferro (+2 dano e RD 5); Magias Divinas (Oração, Soco de Arsenal 4d6+5, Curar Ferimentos, CD 20)|Armadura completa, escudo leve, martelo certeiro cruel; Tesouro: Padrão|Livro JdA p. 295|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_045|Reino dos Mortos|Esqueleto de Elite|4|Morto-vivo Médio|Lacaio|+10|+6|25|+4|+10|+16|36|0|6m (4q)|+18|32|Espada longa +18 (2d8+18, 19)|18|For 6, Des 2, Con 3, Int —, Sab 0, Car -5|Visão no escuro; RD 5/impacto, imunidade a frio; Estocada Cruel (+1d8 dano no crítico); Imunidades de Morto-vivo|Espada longa brutal, escudo pesado, meia armadura; Tesouro: Padrão|Livro JdA p. 297|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_046|Masmorras|Orc Mutante|5|Humanoide (orc) Médio|Lacaio|+8|+5|22|+15|+11|+7|55|0|9m (6q)|+20|56|Machado de guerra +20 (1d12+18, x3) e mordida +20 (1d6+18)|20|For 6, Des 2, Con 4, Int -2, Sab -2, Car -2|Visão no escuro, sensibilidade a luz; Terceiro Braço (Livre: se acertar machado e mordida no mesmo alvo, causa +1d6+9 corte)|Machado de guerra; Tesouro: Padrão|Livro JdA p. 287|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_047|Duyshidakk|Arauto de Thwor|4|Humanoide (humano) Médio|Especial|+6|+11|23|+10|+4|+16|98|24|6m (4q)|+15|24|Machado de guerra abençoado +15 (3d6+12, x3)|20|For 3, Des 1, Con 4, Int -1, Sab 5, Car 0|Fúria Divina (+2 ataque/dano); Prece de Combate; Tropas Duyshidakk (acompanhado por goblins salteadores); Magias Divinas (CD 20)|Machado de guerra cruel, meia armadura; Tesouro: Padrão|Livro JdA p. 300|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_048|Duyshidakk|Hobgoblin Mago de Batalha|5|Humanoide (hobgoblin) Médio|Especial|+9|+5|22|+15|+11|+7|140|30|9m (6q)|+15|40|Espada longa +15 (1d8+8, 19) ou Bola de Fogo (8d6+5 fogo, Ref CD 22)|22|For 3, Des 1, Con 3, Int 5, Sab 0, Car -2|Arcano de Batalha (+5 dano em magias); Magias 1º e 2º círculo (Armadura Arcana, Bola de Fogo, Seta Infalível, Toque Vampírico, CD 22)|Couraça, espada longa, essência de mana; Tesouro: Metade|Livro JdA p. 302|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_049|Trolls Nobres|Troll|5|Monstro Grande|Solo|+5|+4|23|+14|+10|+6|180|0|9m (6q)|+17|40|Mordida +17 (1d8+8) e 2 garras +17 (1d6+8) + Dilacerar (2d6+8)|20|For 6, Des 2, Con 5, Int -2, Sab -1, Car -2|Visão no escuro; Cura Acelerada 10/ácido ou fogo; Dilacerar (Livre: +2d6+8 se acertar as 2 garras no mesmo alvo)|Tesouro: Padrão|Livro JdA p. 309|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_050|Trolls Nobres|Troll Ghillanin (Variante Subterrânea)|5|Monstro Grande|Solo|+5|+4|25|+14|+10|+6|180|0|9m (6q)|+17|40|Mordida +17 (1d8+8) e 2 garras +17 (1d6+8) + Dilacerar (2d6+8)|20|For 6, Des 2, Con 5, Int -2, Sab -1, Car -2|Pele Dura (+2 Defesa); Cura Acelerada 10/ácido ou fogo; Sensibilidade a Luz (ofuscado e perde regeneração sob sol)|Tesouro: Padrão|Livro JdA p. 309|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_051|Trolls Nobres|Troll Glacioll (Variante do Gelo)|5|Monstro Grande|Solo|+5|+4|23|+14|+10|+6|180|0|9m (6q)|+17|40|Mordida +17 (1d8+8) e 2 garras +17 (1d6+8) + Dilacerar (2d6+8)|20|For 6, Des 2, Con 5, Int -2, Sab -1, Car -2|Imunidade a frio, vulnerabilidade a fogo; Absorver Frio (recebe PV temp igual ao dano de frio e +2 ataque/dano)|Tesouro: Padrão|Livro JdA p. 309|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_052|Trolls Nobres|Troll Vrakoll (Variante Aquática)|5|Monstro Grande|Solo|+5|+4|23|+14|+10|+6|180|0|9m, natação 12m|+17|40|Mordida +17 (1d8+8) e 2 garras +17 (1d6+8) + Dilacerar (2d6+8)|20|For 6, Des 2, Con 5, Int -2, Sab -1, Car -2|Aquático (respira n'água e natação 12m; -2 ataque fora d'água); Cura Acelerada 10/ácido ou fogo|Tesouro: Padrão|Livro JdA p. 309|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_053|Ermos|Serpe (Wyvern)|5|Monstro Grande|Solo|+6|+9|24|+17|+11|+5|200|0|9m, voo 18m|+17|40|Mordida +17 (2d6+10) e ferrão +17 (1d8+10 mais veneno 2d12)|20|For 6, Des 1, Con 5, Int -2, Sab 1, Car -1|Visão no escuro, imunidade a paralisia; Agarrar Aprimorado (mordida, teste +19); Veneno (perde 2d12 PV por 1d4 rodadas, Fort CD 20 reduz)|1d4 doses de peçonha de serpe (CD 20)|Livro JdA p. 293|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_054|Puristas|Capitão-Baluarte|5|Humanoide (humano) Médio|Especial|+10|+7|33|+15|+5|+13|140|15|6m (4q)|+17|24|Espada longa +17 (1d8+15, 19)|22|For 4, Des 0, Con 3, Int 1, Sab 0, Car 4|Formação Invencível (+2 Defesa p/ aliados em alcance curto); Estrategista (Movimento: aliados ganham +1 ação de movimento); Gritar Ordens (+4 perícias)|Armadura completa reforçada, escudo pesado reforçado, espada longa; Tesouro: Dobro|Livro JdA p. 295|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_055|Reino dos Mortos|Aparição|5|Morto-vivo Médio|Solo|+13|+11|23|+5|+17|+11|100|0|Voo 18m (12q)|+18|32|Toque drenante +18 (4d8+10 trevas mais drena 20 PV temp)|20|For —, Des 6, Con 2, Int 0, Sab 2, Car 2|Incorpóreo (só sofre dano de armas/efeitos mágicos); Toque Drenante (Fort CD 20 ou fica fraco e aparição recebe 20 PV temp); Vulnerabilidade à Luz Solar|Tesouro: Nenhum|Livro JdA p. 297|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_056|Trolls Nobres|Ganchador|5|Monstro Grande|Solo|+10|+10|26|+15|+11|+7|200|0|9m, escalar 9m|+17|40|Mordida +17 (2d6+8) e 2 garras +17 (1d8+8, 19/x3) + Dilacerar (2d8+8)|20|For 6, Des 3, Con 5, Int -2, Sab 1, Car -1|Percepção às cegas, visão no escuro; Dilacerar (+2d8+8); Quebrar Aprimorado (+20 ataque e +2d8 dano em objetos/armaduras); Sensibilidade a Luz|Tesouro: Metade|Livro JdA p. 308|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_057|Tormenta|Otyugh|5|Monstro Grande|Solo|+4|+9|24|+10|+16|+5|190|0|6m (4q)|+17|40|2 tentáculos +17 (1d8+9, alcance 4,5m) e mordida +17 (1d8+9 mais doença)|20|For 5, Des -1, Con 4, Int -2, Sab 1, Car -2|RD 5; Agarrar Aprimorado (tentáculo, teste +19); Constrição (2d6+9 impacto); Doença: Infecção do esgoto (Fort CD 20 evita)|Tesouro: Padrão|Livro JdA p. 316|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_058|Masmorras|Mantícora|6|Monstro Grande|Solo|+10|+11|26|+18|+7|+12|240|18|9m, voo 15m|+20|56|Mordida +20 (2d8+10) e 2 garras +20 (1d8+10); Espinhos (Movimento, 3 PM: 4 espinhos de 1d8+7, Ref CD 22)|22|For 6, Des 2, Con 6, Int -2, Sab 1, Car -1|Faro, visão no escuro; Espinhos Caudais (Movimento, 3 PM: dispara 4 espinhos em alcance médio causando 1d8+7 cada, Ref CD 22 reduz à metade)|Tesouro: Padrão mais espinhos de mantícora (CD 21)|Livro JdA p. 286|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_059|Duyshidakk|Engenho de Guerra Goblin|6|Construto Enorme|Solo|+6|+10|25|+18|+6|+12|240|0|12m (8q)|+20|56|Arsenal de Engenhocas (Padrão: Canhão 8d8 elét, Balestra 8d6 ácido, Foles 6d6 fogo e Lâmina +20 4d8+16, CD 22)|22|For 9, Des 0, Con 6, Int —, Sab 0, Car -5|RD 10, Imunidades de Construto; Arsenal de Engenhocas (CD 22); Tripulação (ao ser destruído, desembarcam 1d6 goblins salteadores)|Tesouro: Padrão|Livro JdA p. 301|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_060|Cultistas da Traição|Nagah Mística|6|Monstro (nagah) Médio|Especial|+12|+9|20|+6|+12|+18|168|42|9m (6q)|+18|56|Espada curta +18 (1d6+8, 19) e cauda +18 (1d6+8) + Magias Aceleradas (Relâmpago 8d6, Velocidade)|24|For 0, Des 3, Con 4, Int 5, Sab 2, Car 0|Magia Acelerada (+4 PM); Magias até 3º círculo (Armadura Arcana, Imagem Espelhada, Relâmpago, Transformação de Guerra, CD 24)|Essência de mana x2; Tesouro: Padrão|Livro JdA p. 306|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_061|Trolls Nobres|Finntroll Feitor|6|Monstro (finntroll) Médio|Especial|+11|+8|20|+8|+12|+16|168|36|9m (6q)|+18|48|Chicote +18 (1d4+12, alcance 4,5m) e espada curta +18 (1d6+12, 19)|24|For 0, Des 4, Con 4, Int 5, Sab 0, Car 1|Natureza Vegetal, resistência a magia +2; Açoitar Escravos (Movimento: aliados ganham ação mov e +2 atq/dano); Magias até 2º círculo (CD 24)|Chicote cruel, espada curta cruel, essência de mana; Tesouro: Dobro|Livro JdA p. 308|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_062|Tormenta|Geraktril|6|Monstro (lefeu) Grande|Solo|+13|+16|30|+18|+15|+6|230|0|9m (6q)|+22|56|2 pinças +22 (3d6+10, 19) e garra +22 (1d8+10)|22|For 7, Des 5, Con 4, Int 1, Sab 3, Car -1|RD 10, Imunidades Lefeu; Insanidade da Tormenta 2d4 PM (Von CD 22); Percepção Temporal (+3 Ataque, Defesa e Reflexos) e Visão Ampla|Tesouro: Nenhum|Livro JdA p. 314|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_063|Masmorras|Centopeia-Dragão|7|Monstro Enorme|Solo|+9|+11|27|+20|+14|+9|280|0|15m, escavar 6m|+24|62|Mordida +24 (3d8+16 mais 2d6 fogo) + Aura de Calor (4d6+9 fogo automático em alcance curto)|24|For 10, Des 3, Con 8, Int -4, Sab 1, Car 0|Agarrar Aprimorado (mordida, teste +29); Aura de Calor (4d6+9 fogo no início do turno); Engolir (2d8+12 impacto + 4d6+9 fogo, CD 24)|2d4 doses de essência abissal (CD 22)|Livro JdA p. 284|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_064|Reino dos Mortos|Necromante|7|Humanoide (elfo) Médio|Especial|+12|+10|23|+7|+14|+20|168|50|12m (8q)|+18|62|Adaga +18 (1d4+6, 19) + Magias de 4º Círculo (Ferver Sangue, Assassino Fantasmagórico, Toque Vampírico)|26|For 0, Des 2, Con 2, Int 6, Sab 0, Car -1|Mestre em Necromancia (+2 CD); Guardas Esqueletos (acompanhado por 2 esqueletos de elite); Magia Acelerada; Magias até 4º círculo (CD 26)|Adaga, essência de mana x2; Tesouro: Dobro|Livro JdA p. 298|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_065|Cultistas da Traição|Cultista de Sszzaas|7|Monstro (medusa) Médio|Especial|+15|+16|29|+7|+14|+20|196|42|9m (6q)|+22|62|Adaga +22 (1d4+8 mais veneno 2d12, 19) + Ataque Furtivo (+5d6)|26|For -1, Des 4, Con 1, Int 4, Sab 5, Car 5|Olhar Atordoante (Movimento: Fort CD 26 ou atordoado 1 rodada); Veneno 2d12 por 2d4 rodadas (Fort CD 26); Magias Divinas até 3º círculo (CD 26)|Adaga certeira, couraça, escudo leve; Tesouro: Padrão|Livro JdA p. 305|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_066|Dragões|Dragão Jovem|7|Monstro (dragão) Grande|Solo|+10|+12|32|+20|+9|+12|280|21|12m, voo 18m|+24|62|Mordida +24 (2d8+12, 19) e 2 garras +24 (1d8+10, 19); Sopro (Padrão: cone 9m, 8d12 fogo, Ref CD 24, recarga mov)|24|For 7, Des 2, Con 6, Int 2, Sab 2, Car 2|RD 5, resistência a magia +2, imune a fogo, vulnerável a frio; Sopro 8d12 fogo (Ref CD 24); Trespassar; Voo Pairado|Tesouro: Dobro|Livro JdA p. 310|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_067|Reino dos Mortos|Falange|8|Morto-vivo (bando) Médio|Solo|+12|+8|25|+6|+12|+18|360|0|6m (4q)|+28|68|[Bando] Espada longa +28 (4d8+32, 19)|26|For 6, Des 1, Con 3, Int —, Sab 0, Car -5|RD 5/impacto; Bando (dobro do dano se exceder Def por 10+; metade se errar; +50% dano de área); Muro de Escudos (+4 Defesa)|Espada longa, escudo pesado, meia armadura; Tesouro: Padrão|Livro JdA p. 297|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_068|Duyshidakk|Devorador de Medos|8|Humanoide (bugbear) Médio|Especial|+10|+8|31|+21|+15|+8|224|24|9m (6q)|+24|68|Machado de guerra +24 (3d12+24, x3)|28|For 6, Des 3, Con 3, Int 0, Sab 1, Car -2|Apavorar (Movimento, 2 PM: Intimidação +22 vs Vontade ou apavorado); Desprezo pelo Medo (sofre metade do dano de alvos abalados/apavorados)|Gibão de peles, machado de guerra atroz; Tesouro: Metade|Livro JdA p. 300|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_069|Tormenta|Reishid|8|Monstro (lefeu) Médio|Solo|+17|+19|37|+19|+21|+10|295|0|9m, escalar 9m, voo 15m|+30|68|Adaga da Tormenta +30 (1d4+18 mais 1d8 trevas, 19), garra +30 (1d6+18) e mordida +30 (1d6+18 mais veneno)|26|For 4, Des 7, Con 4, Int 4, Sab 4, Car 1|RD 10, Imunidades Lefeu; Ataque em Movimento; Ataque Reflexo; Sombra Rubra (2d20 Iniciativa/Furtividade); Veneno Paralisia (Fort CD 26); Insanidade 2d6 PM|Padrão mais Adaga da Tormenta|Livro JdA p. 315|https://pt.scribd.com/document/971020277/T20-Ameac-as-de-Arton-1
CAP7_070|Puristas|Cavaleiro do Leopardo Sangrento|9|Humanoide (humano) Médio|Solo|+14|+13|36|+21|+11|+17|360|54|9m (6q)|+27|74|Espada bastarda +27 (3d8+22, 19) + Cavaleiro Místico (Relâmpago / Toque Chocante livre)|28|For 6, Des 1, Con 6, Int 4, Sab 0, Car 1|Cavaleiro Místico (lança magia como ação livre ao acertar ataque); Magia Acelerada; Magias até 3º círculo (CD 28); Ódio Puro|Armadura completa reforçada, espada bastarda de adamante atroz pungente; Tesouro: Padrão|Livro JdA p. 295|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_071|Duyshidakk|Sombra de Thwor|9|Humanoide (hobgoblin) Médio|Solo|+17|+11|33|+15|+21|+9|320|27|9m (6q)|+27|74|2 machadinhas +27 (1d8+12, x3) + Ataque Furtivo (+7d6, ou +14d6 com Assassinar)|28|For 2, Des 7, Con 5, Int 1, Sab 1, Car -2|Assassinar (Movimento, 3 PM: dobra dados de Ataque Furtivo); Evasão Aprimorada; Olhos nas Costas; Rolamento Defensivo (Reação: metade dano)|Couro batido ajustado, machadinhas pungentes x2; Tesouro: Metade|Livro JdA p. 303|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_072|Trolls Nobres|Troll das Cavernas|9|Monstro Enorme|Solo|+7|+12|29|+21|+15|+9|400|0|12m, escalar 9m|+27|74|Tacape +27 (4d8+28) e mordida +27 (2d8+18)|28|For 10, Des 0, Con 11, Int -2, Sab -1, Car -2|Cura Acelerada 20/ácido ou fogo; Golpe Avassalador (arremessa 1d6x1,5m e derruba, Fort CD 28 evita); Varrer (ataque extra ao derrubar)|Tacape colossal; Tesouro: Metade|Livro JdA p. 309|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_073|Masmorras|Golem de Ferro|10|Construto Grande|Solo|+9|+10|36|+24|+14|+11|400|30|9m (6q)|+29|80|2 pancadas +29 (4d10+18); Sopro de Gás Venenoso (Movimento: cubo 6m, 8d12 veneno + enjoado, Fort CD 30)|30|For 12, Des -1, Con 10, Int —, Sab 0, Car -5|RD 15/adamante; Imunidade a Magia (eletricidade deixa lento; fogo cura 1 PV para cada 3 de dano); Sopro Venenoso (8d12, CD 30)|Tesouro: Padrão|Livro JdA p. 285|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_074|Dragões|Tirano do Terceiro|10|Humanoide (humano) Médio|Solo|+14|+11|37|+22|+10|+16|380|50|6m (4q)|+29|80|Machado de batalha +29 (2d10+20, x3) e garra +29 (2d6+16) + Magias (Lança Ígnea de Aleph 8d6)|30|For 7, Des 0, Con 7, Int 2, Sab 1, Car 4|RD 5; Ira Dracônica (Livre: +4 Defesa, +4 dano e +4 CD até o fim da cena); Magias até 3º círculo (CD 30)|Armadura completa reforçada de adamante, machado de adamante atroz; Tesouro: Dobro|Livro JdA p. 313|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_075|Tormenta|Sacerdote de Aharadak|10|Humanoide (humano) Médio|Especial|+16|+20|38|+16|+10|+22|280|60|9m (6q)|+27|80|2 correntes de espinhos macabras +27 (4d6+16) e mordida +27 (1d6+10)|32|For 4, Des 2, Con 5, Int 2, Sab 6, Car 0|Resistência elemental 10, +5 vs magias divinas; Percepção Temporal (+6 Atq/Def/Ref); Sangue Ácido (10 dano ácido); Magia Acelerada (CD 32)|Meia armadura de matéria vermelha, símbolo de Aharadak; Tesouro: Padrão|Livro JdA p. 316|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_076|Cultistas da Traição|Hidra|11|Monstro Enorme|Solo|+9|+15|35|+24|+18|+9|580|0|9m, natação 9m|+34|130|5 mordidas +34 (2d8+17)|31|For 10, Des 0, Con 11, Int -4, Sab 0, Car -1|Cura Acelerada 50/ácido ou fogo; Cortar Cabeças (ataque na cabeça com -2 e 25+ dano de corte decepa; nascem 2 cabeças em 1d4 rodadas salvo fogo/ácido)|Tesouro: Nenhum|Livro JdA p. 305|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_077|Dragões|Dragão Adulto|11|Monstro (dragão) Enorme|Solo|+13|+18|42|+24|+11|+18|550|33|12m, voo 24m|+34|130|Mordida +34 (4d8+22, 18) e 2 garras +34 (3d8+20, 18); Sopro (Padrão: cone 12m, 12d12 fogo, Ref CD 31, recarga mov)|31|For 11, Des 1, Con 8, Int 4, Sab 4, Car 3|RD 10, resistência a magia +3, imune a fogo; Aura Aterradora (alcance médio, Von CD 31); Magias até 3º círculo (CD 31); Varrer|Tesouro: Dobro|Livro JdA p. 311|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_078|Reino dos Mortos|Vampiro|12|Morto-vivo Médio|Solo|+20|+18|45|+12|+26|+20|560|67|9m, escalar 9m|+36|144|Espada longa +36 (2d8+28, 17) e 2 garras +36 (2d6+20) + Drenar Sangue (6d6 trevas e cura PV)|33|For 6, Des 5, Con 6, Int 2, Sab 2, Car 7|Cura Acelerada 20/luz, RD 10/prata ou luz; Presença Majestosa (Von CD 33 ou não pode atacar o vampiro); Magias até 4º círculo (CD 33)|Armadura completa delicada de mitral, espada longa de mitral; Tesouro: Dobro|Livro JdA p. 298|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_079|Cultistas da Traição|Lagash|13|Animal Enorme|Solo|+18|+19|41|+26|+20|+13|680|39|12m, escalar 12m, natação 12m|+37|158|Mordida +37 (4d10+36 mais veneno 4d12) + Constrição (6d10+36 impacto)|35|For 13, Des 4, Con 9, Int -4, Sab 1, Car -2|Imune a veneno; Agarrar Aprimorado (mordida, teste +42); Constrição (6d10+36); Cuspe Venenoso (cone 9m, 6d12 veneno + cego, Fort CD 35)|Tesouro: Padrão|Livro JdA p. 305|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_080|Puristas|Colosso Supremo|14|Construto Colossal|Solo|+15|+18|46|+31|+19|+20|750|0|12m (8q)|+39|172|Espada titânica x2 +39 (4d12+46, 19) + Jato de Chamas (Movimento: cone 9m, 10d8+20 fogo, Ref CD 38)|38|For 15, Des -1, Con 10, Int —, Sab 0, Car -5|Cura Acelerada 20 (Goblins Consertadores), RD 15, resistência a magia +5; Balistas (+32, 6d8); Fumos Tóxicos (4d6 veneno em alcance curto, Fort CD 38)|Tesouro: Nenhum|Livro JdA p. 296|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_081|Dragões|Dragão Venerável|15|Monstro (dragão) Enorme|Solo|+16|+23|52|+28|+15|+22|780|60|12m, voo 24m|+43|186|Mordida +43 (6d8+35, 17) e 2 garras +43 (4d8+30, 17); Sopro (Padrão: cone 15m, 16d12 fogo, Ref CD 40, recarga mov)|40|For 15, Des 0, Con 11, Int 6, Sab 7, Car 6|RD 15, resistência a magia +5, imune a fogo; Aura Aterradora (Von CD 40); Magia Acelerada; Magias até 4º círculo (CD 40)|Tesouro: Dobro|Livro JdA p. 311|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_082|Tormenta|Thuwarokk|16|Monstro (lefeu) Colossal|Solo|+13|+19|50|+30|+24|+16|850|0|12m (8q)|+46|200|4 pancadas +46 (4d8+32) + Jato de Ácido (Movimento: linha 18m, 12d8+20 ácido, Ref CD 42)|42|For 16, Des -2, Con 11, Int -3, Sab -1, Car -4|RD 15, Carapaça Suprema (metade dano físico e +10 resistência a magia, reflete magias se passar no teste); Passar por Cima (10d8+30, Ref CD 42)|Tesouro: Nenhum|Livro JdA p. 315|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano
CAP7_083|Dragões|Dragão-Rei (Sckhar / Ancião)|20|Monstro (dragão) Colossal|Solo|+21|+29|62|+34|+20|+28|1250|100|12m, voo 36m|+54|324|Mordida +54 (8d10+64, 16) e 2 garras +54 (6d8+50, 16); Sopro (Padrão: cone 18m, 24d12 fogo, Ref CD 49, recarga mov)|49|For 18, Des 0, Con 14, Int 8, Sab 9, Car 8|RD 20, resistência a magia +5, Maior que a Morte, imune a fogo; Durão (metade do dano); Magia Acelerada; Magias 5º círculo (Chuva de Meteoros, CD 49)|Tesouro: Dobro|Livro JdA p. 312|https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano"""


def _parse_nd_float(nd_str: str) -> float:
    t = nd_str.strip()
    if t == "1/4":
        return 0.25
    if t == "1/3":
        return 0.33
    if t == "1/2":
        return 0.5
    try:
        return float(t)
    except ValueError:
        return 1.0


def _construir_catalogo_ameacas_cap7() -> List[AmeacaCapitulo7]:
    linhas = [l.strip() for l in RAW_AMEACAS_CAP7.strip().splitlines() if l.strip()]
    lista: List[AmeacaCapitulo7] = []
    for l in linhas[1:]:
        cols = [c.strip() for c in l.split("|")]
        if len(cols) < 24:
            continue
        lista.append(AmeacaCapitulo7(
            id_ameaca=cols[0],
            grupo_cap7=cols[1],
            nome=cols[2],
            nd=cols[3],
            nd_numerico=_parse_nd_float(cols[3]),
            tipo_nivel_tamanho=cols[4],
            papel=cols[5],
            iniciativa=int(cols[6].replace("+", "")),
            percepcao=int(cols[7].replace("+", "")),
            defesa=int(cols[8]),
            fortitude=int(cols[9].replace("+", "")),
            reflexos=int(cols[10].replace("+", "")),
            vontade=int(cols[11].replace("+", "")),
            pv=int(cols[12]),
            pm=int(cols[13]),
            deslocamento=cols[14],
            bonus_ataque=int(cols[15].replace("+", "")),
            dano_medio=int(cols[16]),
            ataques_e_acoes=cols[17],
            cd_efeito=int(cols[18]),
            atributos=cols[19],
            habilidades_e_resistencias=cols[20],
            equipamento_e_tesouro=cols[21],
            pagina_livro_pdf=cols[22],
            fonte_url=cols[23],
        ))
    return lista


CATALOGO_AMEACAS_CAP7: List[AmeacaCapitulo7] = _construir_catalogo_ameacas_cap7()


def obter_criatura_capitulo7_por_id_ou_nd(id_ou_nome: Optional[str] = None, nd_alvo: float = 1.0, papel: str = "Solo") -> AmeacaCapitulo7:
    """Retorna a criatura oficial do Capítulo 7 pelo ID/Nome ou a mais próxima do ND e Papel solicitados."""
    if id_ou_nome and id_ou_nome != "AUTO":
        chave = id_ou_nome.strip().lower()
        for c in CATALOGO_AMEACAS_CAP7:
            if c.id_ameaca.lower() == chave or c.nome.lower() == chave:
                return c
    # Busca a criatura do Capítulo 7 com ND mais próximo e papel compatível
    candidatas_papel = [c for c in CATALOGO_AMEACAS_CAP7 if c.papel.lower() == papel.strip().lower()]
    pool = candidatas_papel if candidatas_papel else CATALOGO_AMEACAS_CAP7
    return min(pool, key=lambda c: (abs(c.nd_numerico - nd_alvo), 0 if c.papel == "Solo" else 1))


@dataclass
class RamoAlternativoArvore:
    """Representa uma escolha alternativa avaliada ou podada em um nível da árvore."""
    nome_escolha: str
    tipo_ramo: str          # 'EXPLORADO_MCTS' ou 'PODADO_CSP'
    visitas: int = 0
    score_medio: float = 0.0
    uct: float = 0.0
    motivo_descarte: str = ""


@dataclass
class PassoCaminhoArvore:
    """
    [GoF Composite Node] Representa um estágio de decisão no caminho traçado pelo
    algoritmo (tanto na fase de resolução de domínios CSP quanto na busca MCTS),
    junto com os ramos alternativos explorados ou podados naquele ponto.
    """
    ordem: int
    fase_algoritmo: str     # 'CSP (Consistência AC-3)' ou 'MCTS (Busca UCT)'
    categoria_decisao: str  # Ex: 'Raça', 'Classe', 'Divindade', 'Poder #1', 'Poder #2'
    escolha_vencedora: str
    detalhe_vencedora: str
    visitas_mcts: int = 1
    score_acumulado: float = 0.0
    uct_vencedor: float = 0.0
    alternativas_avaliadas: List[RamoAlternativoArvore] = field(default_factory=list)


@dataclass
class LinhaExperimentoIA2026:
    """Linha da tabela de avaliação comparativa exigida na Seção 3 e 4 do Roteiro IA I 2026."""
    nome_algoritmo: str
    hiperparametros: str
    score_final_medio: float
    dpr_medio: float
    winrate_ameaca_pct: float
    winrate_vs_aleatorio_pct: float
    nos_expandidos: int
    tempo_ms: float


@dataclass
class OpcaoDecisaoCombate:
    """Representa uma opção tática avaliada pela IA dentro de um turno de combate em Tormenta20."""
    ordem_prioridade: int
    tipo_acao: str              # 'Ação Padrão (Ofensiva)', 'Ação Livre / Setup', 'Reação Defensiva'
    nome_acao: str
    custo_pm: int
    chance_sucesso_pct: float   # Chance de acertar a Defesa da criatura ou de a criatura falhar no teste de resistência
    dano_ou_mitigacao_bruto: float
    valor_esperado_efetivo: float
    veredito_tatico: str        # '★ MELHOR DECISÃO PRINCIPAL', '⚡ BUFF / SETUP ÓTIMO', '🛡️ REAÇÃO ÓTIMA', '○ SUSTENTAÇÃO (0 PM)'
    justificativa: str


@dataclass
class PassoTurnoCombate:
    """Registra claramente todas as ações tomadas em um turno do combate (Herói vs. Ameaça p. 323)."""
    numero_turno: int
    acao_livre_movimento: str
    acao_padrao_principal: str
    rolagem_e_teste: str
    dano_causado: float
    pv_criatura_apos: str
    acao_criatura_e_reacao: str
    dano_sofrido: float
    saldo_heroi_pv_pm: str


@dataclass
class EstatisticaPapelAmeaca:
    """Linha da tabela comparativa dos 3 papéis de ameaça (Solo, Lacaio, Especial) da p. 323."""
    papel: str
    patamar: str
    nd: str
    ataque: int
    dano_medio: int
    defesa: int
    res_forte: int
    res_media: int
    res_fraca: int
    pv_grupo4: int
    pv_duelo_1v1: int
    cd_efeito: int
    winrate_heroi_pct: float
    ttk_heroi_turnos: float


@dataclass
class RelatorioSimulacaoCombate:
    """Resultado empírico do Simulador de Combate Monte Carlo contra Ameaça Oficial (p. 323 / PDF p. 329)."""
    nome_ameaca: str = "Ameaça Solo (ND 1)"
    patamar_ameaca: str = "Iniciante"
    papel_ameaca: str = "Solo"
    nd_ameaca: int = 1
    pv_ameaca_grupo4: int = 35
    pv_ameaca: int = 35
    defesa_ameaca: int = 16
    ataque_ameaca: int = 9
    dano_medio_ameaca: int = 15
    res_forte_ameaca: int = 11
    res_media_ameaca: int = 5
    res_fraca_ameaca: int = 0
    cd_efeito_ameaca: int = 15
    episodios_simulados: int = 25
    taxa_vitoria_pct: float = 100.0
    taxa_vitoria_lacaio_pct: float = 100.0
    taxa_vitoria_especial_pct: float = 100.0
    dano_efetivo_medio_rodada: float = 0.0
    rodadas_medias_combate: float = 3.0
    pv_restante_medio_pct: float = 80.0
    pm_restante_medio_pct: float = 60.0
    vitorias_contadas: int = 25
    ttk_heroi_medio: float = 2.5
    ttk_ameaca_medio: float = 4.5
    dano_sofrido_medio_rodada: float = 12.0
    iniciativa_heroi_bonus: int = 4
    iniciativa_ameaca_bonus: int = 5
    chance_vencer_iniciativa_pct: float = 50.0
    resumo_iniciativa_e_surpresa: str = ""
    limiar_morte_instantanea_pv: int = -30
    regra_ferimentos_sangramento: str = ""
    explicacao_calculo_vitoria: str = ""
    melhor_sequencia_decisoes: str = ""
    tabela_papeis_ameaca: List[EstatisticaPapelAmeaca] = field(default_factory=list)
    matriz_decisoes_taticas: List[OpcaoDecisaoCombate] = field(default_factory=list)
    turnos_detalhados: List[PassoTurnoCombate] = field(default_factory=list)
    log_combate_exemplo: List[str] = field(default_factory=list)


@dataclass
class MetricasTreinoML:
    """Métricas de Aprendizado por Reforço (Deep RL DQN / Policy-Value Network) segundo Roteiro IA I 2026."""
    algoritmo: str = "Deep RL (DQN / Policy-Value MLP 20->64->32->1) + MCTS PUCT com CSP Action Masking"
    arquitetura_rede: str = "Entrada(20) -> Dense(64, ReLU) -> Dense(32, ReLU) -> Cabeças Valor V_θ(s) & Política π_θ(a|s)"
    otimizador: str = "SGD com Momentum (β=0.9) + L2 Regularization (λ=0.001)"
    taxa_aprendizado: float = 0.045
    hiperparametro_exploracao: str = "C_PUCT = 1.414 | C_UCB1 = 1.414 | ε-greedy = 0.15"
    dimensao_tensor_ficha: int = 20
    epocas_self_play: int = 35
    loss_inicial: float = 0.0
    loss_final: float = 0.0
    valor_previsto_rede: float = 0.0
    vetor_ficha_resumo: List[float] = field(default_factory=list)
    top_priors_politica: List[Tuple[str, float]] = field(default_factory=list)
    experimentos_comparativos: List[LinhaExperimentoIA2026] = field(default_factory=list)


@dataclass
class RelatorioOtimizacaoIA:
    """Armazena métricas e a Árvore de Escolhas completa gerada pelo algoritmo."""
    modo_criacao: str = "Manual"
    arquetipo_alvo: str = "Balanceado"
    iteracoes_mcts: int = 0
    nos_expandidos: int = 0
    podas_csp_realizadas: int = 0
    recompensa_inicial: float = 0.0
    recompensa_final: float = 0.0
    trilha_decisoes: List[str] = field(default_factory=list)
    passos_arvore: List[PassoCaminhoArvore] = field(default_factory=list)
    simulacao_combate: RelatorioSimulacaoCombate = field(default_factory=RelatorioSimulacaoCombate)
    metricas_ml: MetricasTreinoML = field(default_factory=MetricasTreinoML)


@dataclass
class FichaPersonagem:
    """Agregado principal representando uma Ficha Completa de Tormenta20."""
    id_personagem: Optional[int] = None
    nome: str = "Novo Aventureiro"
    jogador: str = "Jogador"
    nivel: int = 1
    atributos_base: Atributos = field(default_factory=lambda: Atributos(3, 2, 2, 1, 0, -1))
    escolhas_atributos_livres: List[str] = field(default_factory=lambda: ["FOR", "DES", "CON"])
    raca: Optional[Raca] = None
    classe: Optional[Classe] = None
    classe_secundaria: Optional[Classe] = None
    nivel_classe_secundaria: int = 0
    classe_terciaria: Optional[Classe] = None
    nivel_classe_terciaria: int = 0
    caminho_arcanista: str = "Mago"  # 'Mago' (INT), 'Bruxo' (INT) ou 'Feiticeiro' (CAR)
    raca_anterior_osteon: str = "Anão (Duro como Pedra)"  # Usado pela Memória Póstuma do Osteon (p. 27)
    modo_ataque_especial: str = "ATAQUE"  # 'ATAQUE' (+B no ataque), 'DANO' (+B no dano) ou 'DIVIDIDO' (+B/2 atq e +B/2 dano, p. 65)
    config_golpe_pessoal: str = "Brutal (+1d) + Elemental (+2d6 Fogo) + Preciso (2d20 — escolhe o melhor)"  # Efeitos do Golpe Pessoal (p. 66-67)
    origem: Optional[Origem] = None
    deus: Optional[Deus] = None
    pericias_treinadas: List[str] = field(default_factory=list)
    pericia_beneficio_origem: str = ""
    poderes_beneficio_origem: List[Poder] = field(default_factory=list)
    resumo_regra_origem: str = ""
    poderes_concedidos_devocao: List[Poder] = field(default_factory=list)
    poderes_classe: List[Poder] = field(default_factory=list)
    poderes_gerais: List[Poder] = field(default_factory=list)
    itens_inventario: List[Item] = field(default_factory=list)
    arma_equipada: Optional[Item] = None
    armadura_equipada: Optional[Item] = None
    escudo_equipado: Optional[Item] = None
    magias_conhecidas: List[Magia] = field(default_factory=list)

    atributos_finais: Atributos = field(default_factory=Atributos)
    pv_maximos: int = 0
    pm_maximos: int = 0
    detalhe_pv: str = ""
    detalhe_pm: str = ""
    defesa_total: int = 10
    deslocamento_final: int = 9
    penalidade_armadura_total: int = 0
    carga_atual: float = 0.0
    carga_maxima: float = 10.0
    cd_magias: int = 10
    bonus_pericias: Dict[str, int] = field(default_factory=dict)
    validacoes_csp: List[str] = field(default_factory=list)
    pontuacao_mcts: float = 0.0
    relatorio_ia: RelatorioOtimizacaoIA = field(default_factory=RelatorioOtimizacaoIA)

    def poderes_escolhidos_progressao(self) -> List[Poder]:
        """Retorna apenas os poderes comprados nos níveis da classe (sem contar os concedidos automáticos)."""
        return list(self.poderes_classe) + list(self.poderes_gerais)

    def obter_classes_e_niveis(self) -> List[Tuple[Classe, int]]:
        """
        Retorna a lista ordenada `[(classe_primaria, nv_prim), (classe_sec, nv_sec), ...]`
        garantindo que a soma dos níveis de classe seja sempre igual ao Nível de Personagem (`self.nivel`),
        conforme as regras de Multiclasse de Tormenta20 Edição Jogo do Ano (Cap. 1, p. 34).
        """
        if not self.classe:
            return []
        nv_total = max(1, min(20, int(self.nivel)))
        nv_sec = max(0, int(self.nivel_classe_secundaria or 0)) if self.classe_secundaria else 0
        nv_terc = max(0, int(self.nivel_classe_terciaria or 0)) if self.classe_terciaria else 0
        if self.classe_secundaria and self.classe_secundaria.nome.lower() == self.classe.nome.lower():
            nv_sec = 0
        if self.classe_terciaria and (
            self.classe_terciaria.nome.lower() == self.classe.nome.lower()
            or (self.classe_secundaria and self.classe_terciaria.nome.lower() == self.classe_secundaria.nome.lower())
        ):
            nv_terc = 0
        # Garante que a Classe Primária tenha ao menos 1 nível (o 1º nível do personagem)
        if nv_sec + nv_terc >= nv_total:
            excesso = (nv_sec + nv_terc) - (nv_total - 1)
            if nv_terc >= excesso:
                nv_terc -= excesso
            else:
                resto = excesso - nv_terc
                nv_terc = 0
                nv_sec = max(0, nv_sec - resto)
        nv_prim = max(1, nv_total - nv_sec - nv_terc)
        res: List[Tuple[Classe, int]] = [(self.classe, nv_prim)]
        if self.classe_secundaria and nv_sec > 0:
            res.append((self.classe_secundaria, nv_sec))
        if self.classe_terciaria and nv_terc > 0:
            res.append((self.classe_terciaria, nv_terc))
        return res

    def eh_multiclasse(self) -> bool:
        """Retorna True se o personagem possui níveis em 2 ou mais classes (p. 34)."""
        return len(self.obter_classes_e_niveis()) > 1

    def nivel_na_classe(self, nome_classe: str) -> int:
        """Retorna o nível específico do personagem na classe informada (0 se não possuir a classe)."""
        alvo = (nome_classe or "").strip().lower()
        for cl_obj, nv_c in self.obter_classes_e_niveis():
            if cl_obj.nome.strip().lower() == alvo:
                return nv_c
        return 0

    def possui_classe(self, nome_classe: str) -> bool:
        """Verifica se o personagem possui pelo menos 1 nível na classe informada."""
        return self.nivel_na_classe(nome_classe) > 0

    def resumo_classes_multiclasse(self) -> str:
        """Formata a distribuição de classes e níveis (ex.: 'Guerreiro 4 / Bárbaro 2')."""
        pares = self.obter_classes_e_niveis()
        if not pares:
            return "Sem Classe"
        if len(pares) == 1:
            return f"{pares[0][0].nome} {pares[0][1]}"
        return " / ".join(f"{c.nome} {n}" for c, n in pares)

    def max_poderes_progressao(self) -> int:
        """
        Em Tormenta20 (Cap. 1, p. 34), cada classe concede 1 poder por nível a partir do 2º nível naquela classe.
        """
        pares = self.obter_classes_e_niveis()
        if not pares:
            return max(0, self.nivel - 1)
        return sum(max(0, nv_c - 1) for _, nv_c in pares)


    def possui_chifres(self) -> bool:
        """Verifica se o personagem possui a arma natural Chifres (Minotauro p. 25 ou Osteon Memória Póstuma Minotauro p. 27)."""
        if not self.raca:
            return False
        nr = self.raca.nome.strip().lower()
        if nr == "minotauro" or "chifres" in self.raca.habilidades_raca.lower():
            return True
        if nr == "osteon" and "minotauro" in (self.raca_anterior_osteon or "").lower():
            return True
        return False

    def possui_mordida(self) -> bool:
        """Verifica se o personagem possui a arma natural Mordida (Trog p. 31, Osteon ex-Trog p. 27, Presas Primordiais p. 134 ou Dentes Afiados p. 137)."""
        if self.raca:
            nr = self.raca.nome.strip().lower()
            if nr == "trog" or "mordida" in self.raca.habilidades_raca.lower():
                return True
            if nr == "osteon" and "trog" in (self.raca_anterior_osteon or "").lower():
                return True
        return self.possui_poder("Presas Primordiais") or self.possui_poder("Dentes Afiados")

    def possui_arma_natural_extra(self) -> bool:
        """Retorna True se o personagem possui Chifres (Minotauro) ou Mordida (Trog / Presas Primordiais / Dentes Afiados)."""
        return self.possui_chifres() or self.possui_mordida()

    def obter_info_arma_natural_extra(self) -> Optional[Dict[str, Any]]:
        """
        Retorna os metadados exatos da arma natural de ataque extra (1 PM, 1x/rodada ao usar Agredir):
        - Minotauro (p. 25): Chifres (1d6 perfuração, ou 1d8 se combinado com Presas Primordiais)
        - Trog (p. 31): Mordida (1d6 perfuração, ou 1d10 [+2 passos] se combinado com Presas Primordiais, p. 134)
        - Presas Primordiais (p. 134) / Dentes Afiados (p. 137): Mordida (1d6 perfuração)
        """
        tem_presas = self.possui_poder("Presas Primordiais")
        if self.possui_chifres():
            dado_str = "1d8" if tem_presas else "1d6"
            faces = 8 if tem_presas else 6
            med_base = 4.725 if tem_presas else 3.675
            return {
                "icone": "🐂",
                "nome_curto": "Chifres",
                "titulo": "🐂 Arma Natural & Ataque Extra — Chifres (Minotauro, Livro p. 25)" + (" + Presas Primordiais" if tem_presas else ""),
                "dado_str": dado_str,
                "faces": faces,
                "media_dado_crit": med_base,
                "custo_pm": 1,
                "pagina": "Livro p. 25 / PDF p. 31",
            }
        if self.possui_mordida():
            nr = self.raca.nome.strip().lower() if self.raca else ""
            eh_trog = (nr == "trog") or (nr == "osteon" and "trog" in (self.raca_anterior_osteon or "").lower())
            dado_str = "1d10" if (eh_trog and tem_presas) else "1d6"
            faces = 10 if (eh_trog and tem_presas) else 6
            med_base = 5.775 if (eh_trog and tem_presas) else 3.675
            origem_lbl = "Trog, Livro p. 31" if eh_trog else ("Presas Primordiais, p. 134" if tem_presas else "Dentes Afiados, p. 137")
            return {
                "icone": "🦎" if eh_trog else "🦷",
                "nome_curto": "Mordida",
                "titulo": f"{'🦎' if eh_trog else '🦷'} Arma Natural & Ataque Extra — Mordida ({origem_lbl})" + (" [+2 passos Presas Primordiais]" if (eh_trog and tem_presas) else ""),
                "dado_str": dado_str,
                "faces": faces,
                "media_dado_crit": med_base,
                "custo_pm": 1,
                "pagina": "Livro p. 31 / PDF p. 37" if eh_trog else "Livro p. 134",
            }
        return None

    def todos_os_poderes(self) -> List[Poder]:
        """Retorna todos os poderes ativos na ficha (incluindo Benefícios de Origem/Golem/Osteon e Poderes Concedidos)."""
        vistos = set()
        lista: List[Poder] = []
        for p in list(self.poderes_beneficio_origem) + list(self.poderes_concedidos_devocao) + list(self.poderes_classe) + list(self.poderes_gerais):
            nl = p.nome.strip().lower()
            if nl not in vistos:
                vistos.add(nl)
                lista.append(p)
        return lista

    def obter_atributo_chave_magia(self) -> Tuple[str, str]:
        """
        Retorna (sigla_atributo, explicacao) para conjuração de magias conforme Tormenta20 (p. 36-88):
        - Arcanista (Mago ou Bruxo): Inteligência (INT)
        - Arcanista (Feiticeiro): Carisma (CAR)
        - Bardo: Carisma (CAR)
        - Clérigo e Druida: Sabedoria (SAB)
        - Paladino (Orar): Sabedoria (SAB) [e soma CAR em PM via Abençoado]
        """
        if not self.classe:
            return "INT", "Padrão (INT)"
        nc = self.classe.nome.strip().lower()
        if "arcanista" in nc:
            cam = (self.caminho_arcanista or "Mago").strip().lower()
            if "feiticeiro" in cam:
                return "CAR", "Carisma (Caminho do Feiticeiro — Linhagem Sobrenatural)"
            if "bruxo" in cam:
                return "INT", "Inteligência (Caminho do Bruxo — Foco Arcano)"
            return "INT", "Inteligência (Caminho do Mago — Grimório)"
        if "bardo" in nc:
            return "CAR", "Carisma (Magias de Bardo)"
        if "clérigo" in nc or "clerigo" in nc:
            return "SAB", "Sabedoria (Magias Divinas de Clérigo)"
        if "druida" in nc:
            return "SAB", "Sabedoria (Magias Divinas de Druida)"
        if "paladino" in nc:
            return "SAB", "Sabedoria (Orar) & Carisma (Abençoado)"
        prim = self.classe.atributo_principal.split()[0].upper()
        if prim in ("INT", "SAB", "CAR"):
            return prim, f"{prim} (Habilidade de Classe)"
        return "INT", "Inteligência (Geral)"

    def quantidade_poderes_concedidos_devocao(self) -> Tuple[int, str]:
        """
        Retorna (qtd_poderes_concedidos, regra_aplicada):
        - Clérigo, Druida e Paladino possuem Devoto Fiel / Abençoado -> recebem DOIS (2) Poderes Concedidos!
        - Demais classes quando devotas de uma divindade -> recebem UM (1) Poder Concedido!
        - Sem divindade -> 0 Poderes Concedidos.
        """
        if not self.deus:
            return 0, "Não é devoto (0 Poderes Concedidos)"
        nc = self.classe.nome.strip().lower() if self.classe else ""
        if any(k in nc for k in ("clérigo", "clerigo", "druida", "paladino")):
            hab_nome = "Devoto Fiel" if "paladino" not in nc else "Devoto Fiel / Abençoado"
            return 2, f"{hab_nome} ({self.classe.nome} devoto de {self.deus.nome}: recebe 2 Poderes Concedidos)"
        return 1, f"Devoto de {self.deus.nome} (recebe 1 Poder Concedido)"

    def possui_poder(self, nome_poder: str) -> bool:
        alvo = nome_poder.strip().lower()
        for p in self.todos_os_poderes():
            if p.nome.strip().lower() == alvo or alvo in p.nome.strip().lower():
                return True
        if self.origem and self.origem.poder_unico.strip().lower() == alvo:
            return True
        return False

    def possui_pericia_treinada(self, nome_pericia: str) -> bool:
        alvo = nome_pericia.strip().lower()
        return any(alvo == p.strip().lower() or p.strip().lower().startswith(alvo)
                   for p in self.pericias_treinadas)

    def natureza_personagem(self) -> str:
        """Diferencia explicitamente entre Marcial, Conjurador e Híbrido."""
        if not self.classe:
            return "Marcial"
        nc = self.classe.nome.lower()
        if nc in ("arcanista", "clérigo", "druida"):
            return "Conjurador"
        if nc in ("bardo", "paladino", "inventor"):
            return "Híbrido (Marcial & Conjurador/Especialista)"
        return "Marcial"

    def eh_conjurador(self) -> bool:
        for cl_obj, nv_c in self.obter_classes_e_niveis():
            if nv_c > 0:
                hab = cl_obj.habilidades_fixas.lower()
                if "magias arcanas" in hab or "magias divinas" in hab or cl_obj.nome.lower() in ("arcanista", "bardo", "clérigo", "clerigo", "druida"):
                    return True
        return any("lançar" in p.efeito_resumo.lower() for p in self.todos_os_poderes())

    def obter_proficiencias_ativas(self) -> List[str]:
        """Retorna a lista exata de proficiências de armas, armaduras e escudos do personagem."""
        profs = ["Armas simples"]
        nc = self.classe.nome.lower() if self.classe else ""
        if nc != "arcanista":
            profs.append("Armaduras leves")
        if self.classe:
            p_str = self.classe.proficiencias.lower()
            if "armas marciais" in p_str and "Armas marciais" not in profs:
                profs.append("Armas marciais")
            if "armaduras pesadas" in p_str and "Armaduras pesadas" not in profs:
                profs.append("Armaduras pesadas")
            if "escudos" in p_str and "Escudos" not in profs:
                profs.append("Escudos")
        if self.raca and self.raca.nome.lower() == "anão":
            profs.append("Armas tradicionais anãs (Machado anão, etc.)")
        for p in self.todos_os_poderes():
            np = p.nome.lower()
            if np == "proficiência":
                for cat_p in ("Armas marciais", "Armas exóticas", "Armas de fogo", "Armaduras pesadas", "Escudos"):
                    if cat_p not in profs:
                        profs.append(cat_p)
            elif np == "armeiro" and "Armas marciais" not in profs:
                profs.append("Armas marciais")
            elif np == "couraceiro":
                if "Armaduras pesadas" not in profs:
                    profs.append("Armaduras pesadas")
                if "Escudos" not in profs:
                    profs.append("Escudos")
            elif np in ("balística", "pistoleiro") and "Armas de fogo" not in profs:
                profs.append("Armas de fogo")
        return profs

    def tem_proficiencia_item(self, item: Optional[Item]) -> Tuple[bool, str]:
        if not item:
            return True, "OK"
        profs = [x.lower() for x in self.obter_proficiencias_ativas()]
        cat = item.categoria.lower()
        sub = item.subcategoria.lower()
        nome_i = item.nome.lower()
        if cat == "arma":
            if "simples" in sub:
                return True, "Proficiência com armas simples"
            if "marcial" in sub:
                ok = any("marciais" in p for p in profs)
                return ok, "Requer proficiência com Armas Marciais"
            if "exótica" in sub:
                if self.raca and self.raca.nome.lower() == "anão" and ("machado" in nome_i or "martelo" in nome_i):
                    return True, "Tradição de Heredrimm (Anão)"
                if ("bastarda" in nome_i or "katana" in nome_i) and any("marciais" in p for p in profs) and not self.escudo_equipado:
                    return True, "Arma adaptável usada com duas mãos como marcial"
                ok = any("exóticas" in p for p in profs)
                return ok, f"Requer poder 'Proficiência' para usar arma exótica ({item.nome})"
            if "fogo" in sub:
                ok = any("fogo" in p for p in profs)
                return ok, f"Requer proficiência com Armas de Fogo para usar {item.nome}"
        elif cat == "armadura":
            if "leve" in sub:
                ok = any("armaduras leves" in p for p in profs)
                return ok, "Arcanista não possui proficiência com armaduras leves"
            if "pesada" in sub:
                ok = any("armaduras pesadas" in p for p in profs)
                return ok, f"Requer proficiência com Armaduras Pesadas para vestir {item.nome}"
        elif cat == "escudo":
            ok = any("escudos" in p for p in profs)
            return ok, f"Requer proficiência com Escudos para usar {item.nome}"
        return True, "OK"

    def patamar_atual(self) -> int:
        if self.nivel <= 4:
            return 1
        if self.nivel <= 10:
            return 2
        if self.nivel <= 16:
            return 3
        return 4

    @staticmethod
    def circulo_por_classe_e_nivel(classe_obj: Classe, nv_classe: int) -> int:
        """Calcula o círculo máximo de magias desbloqueado pelo nível específico em `classe_obj` (p. 34, 37, 44, 58, 61)."""
        if not classe_obj or nv_classe <= 0:
            return 0
        nc = classe_obj.nome.strip().lower()
        hab = classe_obj.habilidades_fixas.lower()
        if nc in ("druida", "bardo") or "4º círculo" in hab or "4o círculo" in hab:
            if nv_classe >= 14:
                return 4
            if nv_classe >= 10:
                return 3
            if nv_classe >= 6:
                return 2
            return 1
        if nc in ("arcanista", "clérigo", "clerigo") or "5º círculo" in hab or "5o círculo" in hab:
            return min(5, 1 + (nv_classe - 1) // 4)
        return 0

    def circulo_maximo_permitido(self) -> int:
        """
        Regra Oficial Tormenta20 Edição Jogo do Ano (Cap. 1, Multiclasse p. 34):
        - Círculos de magia são determinados individualmente pelo nível na classe conjuradora:
          * Arcanista (p. 37) e Clérigo (p. 58): 2º no Nv. 5 da classe, 3º no Nv. 9, 4º no Nv. 13, 5º no Nv. 17.
          * Bardo (p. 44) e Druida (p. 61): 2º no Nv. 6 da classe, 3º no Nv. 10, 4º no Nv. 14.
        """
        pares = self.obter_classes_e_niveis()
        if not pares:
            return 0
        melhor_circ = max((self.circulo_por_classe_e_nivel(c, nv) for c, nv in pares), default=0)
        if melhor_circ > 0:
            return melhor_circ
        for p in self.todos_os_poderes():
            if any(k in p.efeito_resumo.lower() for k in ("lançar", "aprende e pode lançar")):
                return 1
        return 0

