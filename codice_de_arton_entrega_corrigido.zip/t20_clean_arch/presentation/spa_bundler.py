# -*- coding: utf-8 -*-
"""
Camada de Apresentação — Empacotador Modular do Motor SPA (Bundler).
Lê os 5 módulos JavaScript independentes de `t20_clean_arch/frontend_spa/` e monta
`SPA_JS_ENGINE_TEMPLATE` em tempo de execução para manter a exportação de arquivo
HTML único (`tormenta20_mobile_app.html`) 100% funcional offline no celular e desktop.
"""
from __future__ import annotations
import pathlib
from pathlib import Path
from typing import Dict, List

FRONTEND_SPA_DIR = pathlib.Path(__file__).resolve().parent.parent / "frontend_spa"

MODULOS_JS_ORDENADOS: List[str] = [
    "01_core_rules_and_treasure.js",
    "02_monte_carlo_and_sheet_ui.js",
    "03_deep_rl_and_tree_ui.js",
    "04_hd2d_sprites_and_audio.js",
    "05_turn_arena_engine.js",
]


def listar_modulos_frontend_spa() -> Dict[str, int]:
    """Retorna um dicionário {nome_modulo: quantidade_linhas} para auditoria arquitetural."""
    res: Dict[str, int] = {}
    for nome in MODULOS_JS_ORDENADOS:
        caminho = FRONTEND_SPA_DIR / nome
        if caminho.exists():
            res[nome] = len(caminho.read_text(encoding="utf-8").splitlines())
    return res


def carregar_spa_js_engine_template() -> str:
    """Concatena os 5 módulos JavaScript do diretório `frontend_spa/` em um bundle unificado."""
    partes: List[str] = []
    for nome in MODULOS_JS_ORDENADOS:
        caminho = FRONTEND_SPA_DIR / nome
        if not caminho.exists():
            raise FileNotFoundError(f"Módulo JS ausente na arquitetura: {caminho}")
        partes.append(caminho.read_text(encoding="utf-8"))
    return "".join(partes)


SPA_JS_ENGINE_TEMPLATE: str = carregar_spa_js_engine_template()
