# -*- coding: utf-8 -*-
from __future__ import annotations

import abc
import base64
import copy
import dataclasses
import datetime
from datetime import datetime as dt_cls
import gzip
import hashlib
import zlib
import functools
import html
import http.server
import inspect
import io
import json
import lzma
import math
import os
import pathlib
from pathlib import Path
import random
import re
import socketserver
import sqlite3
import statistics
import string
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import typing
import urllib.parse
import urllib.request
import uuid
import webbrowser
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import (
    Any, Callable, Dict, Generic, Iterable, Iterator, List,
    Literal, Mapping, NamedTuple, Optional, Protocol, Sequence,
    Set, Tuple, Type, TypeVar, Union
)

"""
Camada de Apresentação — Renderizadores de Árvore de Decisão (SVG e ASCII) e Ficha HTML/CSS (ISP / Strategy).
"""
from ..domain import *
from ..application import *
from .styles_css import FolhaEstiloTemaTormenta20

class RenderizadorArvoreDecisaoHTMLSVG(IRenderizadorArvoreDecisao):
    """
    [GoF Strategy] Renderiza a Árvore de Escolhas do Algoritmo (CSP + MCTS) em
    dois componentes visuais complementares otimizados para celular e desktop:
    1) Diagrama Gráfico SVG de Nós e Arestas (com curvas Bézier, nós dourados para
       o Caminho Ótimo, nós azuis/cinzas para ramos MCTS descartados e nós vermelhos
       para podas CSP, com scroll touch horizontal no celular);
    2) Linha do Tempo Interativa em Cards CSS detalhando visitas N, UCT e motivos de poda.
    """
    def renderizar_arvore(self, ficha: FichaPersonagem) -> str:
        esc = html.escape
        rel = ficha.relatorio_ia
        passos = rel.passos_arvore

        if not passos:
            return (
                '<div class="sheet-card">'
                '<h3 style="color:var(--t20-ruby);margin-top:0;">🌳 Árvore de Decisões do Algoritmo (CSP + MCTS)</h3>'
                '<p style="font-size:14px;color:var(--t20-muted);">Esta ficha foi editada no modo manual. '
                'Toque na aba <strong>🤖 Criar c/ IA</strong> e execute o otimizador para visualizar a árvore completa '
                'com o caminho ótimo MCTS, os ramos explorados e as podas CSP!</p></div>'
            )

        # 1. Construção do Diagrama Gráfico SVG (Horizontal para Desktop / Touch-Scroll no Celular)
        larg_passo = 235
        larg_svg = max(760, len(passos) * larg_passo + 80)
        alt_svg = 360
        y_principal = 95

        elementos_svg: List[str] = []
        # Definição de gradiente e marcadores de seta
        elementos_svg.append("""
        <defs>
            <linearGradient id="gradVencedor" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#8B1E24;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#5A1014;stop-opacity:1" />
            </linearGradient>
        </defs>
        """)

        for idx, passo in enumerate(passos):
            x_centro = 115 + idx * larg_passo
            # Linha conectora para o próximo nó do Caminho Ótimo
            if idx < len(passos) - 1:
                x_prox = 115 + (idx + 1) * larg_passo
                elementos_svg.append(
                    f'<line x1="{x_centro + 85}" y1="{y_principal}" x2="{x_prox - 85}" y2="{y_principal}" '
                    f'stroke="#C89D54" stroke-width="4" />'
                )

            # Desenhar até 2 ramos alternativos (explorados MCTS ou podados CSP) abaixo do nó principal
            for idx_alt, alt in enumerate(passo.alternativas_avaliadas[:2]):
                y_alt = 215 + idx_alt * 82
                cor_borda = "#B42318" if alt.tipo_ramo == "PODADO_CSP" else "#64748B"
                cor_fundo = "#FDECEA" if alt.tipo_ramo == "PODADO_CSP" else "#F1F5F9"
                icone_alt = "✖ CSP" if alt.tipo_ramo == "PODADO_CSP" else f"○ N={alt.visitas}"
                # Curva Bézier do nó pai/atual para o ramo descartado
                x_origem = x_centro - 30
                elementos_svg.append(
                    f'<path d="M {x_origem} {y_principal + 34} C {x_origem} {y_alt}, {x_centro - 80} {y_alt}, {x_centro - 75} {y_alt}" '
                    f'fill="none" stroke="{cor_borda}" stroke-width="2" stroke-dasharray="5,4" />'
                )
                nome_curto_alt = esc(alt.nome_escolha[:21] + ("…" if len(alt.nome_escolha) > 21 else ""))
                elementos_svg.append(
                    f'<rect x="{x_centro - 78}" y="{y_alt - 24}" width="156" height="48" rx="7" '
                    f'fill="{cor_fundo}" stroke="{cor_borda}" stroke-width="1.8" />'
                    f'<text x="{x_centro}" y="{y_alt - 5}" text-anchor="middle" font-size="11" font-weight="bold" fill="{cor_borda}">{icone_alt}: {nome_curto_alt}</text>'
                    f'<text x="{x_centro}" y="{y_alt + 12}" text-anchor="middle" font-size="9.5" fill="#475569">'
                    f'{esc(alt.motivo_descarte[:26] + ("…" if len(alt.motivo_descarte) > 26 else ""))}</text>'
                )

            # Nó Principal Vencedor (Caminho Ótimo)
            nome_curto = esc(passo.escolha_vencedora[:20] + ("…" if len(passo.escolha_vencedora) > 20 else ""))
            cat_curta = esc(passo.categoria_decisao[:22])
            metrica_txt = (
                f"N={passo.visitas_mcts} | Score={passo.score_acumulado:.0f}"
                if "MCTS" in passo.fase_algoritmo else esc(passo.fase_algoritmo)
            )
            elementos_svg.append(
                f'<rect x="{x_centro - 85}" y="{y_principal - 36}" width="170" height="72" rx="10" '
                f'fill="url(#gradVencedor)" stroke="#C89D54" stroke-width="2.5" />'
                f'<text x="{x_centro}" y="{y_principal - 16}" text-anchor="middle" font-size="10" font-weight="bold" fill="#F3E5AB">★ {cat_curta}</text>'
                f'<text x="{x_centro}" y="{y_principal + 4}" text-anchor="middle" font-size="12" font-weight="bold" fill="#FFFFFF">{nome_curto}</text>'
                f'<text x="{x_centro}" y="{y_principal + 22}" text-anchor="middle" font-size="10" fill="#E2E8F0">{metrica_txt}</text>'
            )

        svg_completo = (
            f'<div class="tree-scroll-wrapper">'
            f'<svg width="{larg_svg}" height="{alt_svg}" viewBox="0 0 {larg_svg} {alt_svg}" '
            f'xmlns="http://www.w3.org/2000/svg" style="font-family:\'Segoe UI\',sans-serif;">'
            + "".join(elementos_svg) + "</svg></div>"
        )

        # 2. Cards Verticais Mobile-Friendly Detalhando Cada Passo do Caminho e Ramos Descartados
        cards_passos: List[str] = []
        for passo in passos:
            badge_fase = (
                f'<span class="tag" style="background:#8B1E24;color:#FFF;">{esc(passo.fase_algoritmo)}</span>'
                if "MCTS" in passo.fase_algoritmo
                else f'<span class="tag" style="background:#1E6F43;color:#FFF;">{esc(passo.fase_algoritmo)}</span>'
            )
            metrica_badge = (
                f'<span class="tag">Visitas N={passo.visitas_mcts} · Q/N={passo.score_acumulado:.1f} · UCT={passo.uct_vencedor:.1f}</span>'
                if "MCTS" in passo.fase_algoritmo else ""
            )

            ramos_html = []
            for alt in passo.alternativas_avaliadas:
                if alt.tipo_ramo == "PODADO_CSP":
                    ramos_html.append(
                        f'<div class="tree-branch-pruned">'
                        f'<strong>✖ [Podado pelo CSP] {esc(alt.nome_escolha)}</strong> — {esc(alt.motivo_descarte)}</div>'
                    )
                else:
                    info_vis = f" (N={alt.visitas}, Score={alt.score_medio:.1f})" if alt.visitas > 0 else ""
                    ramos_html.append(
                        f'<div class="tree-branch-alt">'
                        f'<strong>○ [Ramo Alternativo{info_vis}] {esc(alt.nome_escolha)}</strong> — {esc(alt.motivo_descarte)}</div>'
                    )

            cards_passos.append(f"""
            <div class="tree-step-card">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:6px;">
                    <div>{badge_fase} <strong>{esc(passo.categoria_decisao)}</strong></div>
                    <div>{metrica_badge}</div>
                </div>
                <div class="tree-winner-box">
                    ★ <strong>Escolha Vencedora: {esc(passo.escolha_vencedora)}</strong>
                    <div style="font-size:12px;color:#4A3F35;margin-top:3px;">{esc(passo.detalhe_vencedora)}</div>
                </div>
                {"".join(ramos_html)}
            </div>
            """)

        return f"""
        <div class="sheet-card">
            <div class="sheet-banner">
                <div>
                    <h2 class="sheet-title">🌳 Árvore de Escolhas do Algoritmo (CSP + MCTS)</h2>
                    <div style="font-size:13px;color:var(--t20-muted);">
                        Personagem: <strong>{esc(ficha.nome)}</strong> | Arquétipo: <strong>{esc(rel.arquetipo_alvo)}</strong> |
                        Iterações MCTS: <strong>{rel.iteracoes_mcts}</strong> | Nós Expandidos: <strong>{rel.nos_expandidos}</strong> |
                        Podas CSP (AC-3): <strong>{rel.podas_csp_realizadas}</strong>
                    </div>
                </div>
                <div>
                    <span class="tag" style="font-size:13px;padding:6px 10px;">Score: {rel.recompensa_inicial:.1f} → {rel.recompensa_final:.1f}</span>
                </div>
            </div>

            <div style="font-size:12px;color:var(--t20-muted);margin-bottom:8px;">
                💡 <strong>Dica Mobile:</strong> Deslize horizontalmente no diagrama abaixo para navegar pelos níveis da árvore.
                <span style="color:#8B1E24;font-weight:700;">■ Dourado/Rubi:</span> Caminho Ótimo Escolhido &nbsp;|&nbsp;
                <span style="color:#94A3B8;font-weight:700;">■ Cinza:</span> Ramo Explorado (Subótimo) &nbsp;|&nbsp;
                <span style="color:#B42318;font-weight:700;">■ Vermelho:</span> Podado pelo CSP
            </div>

            {svg_completo}

            <h3 style="color:#FDE047;margin:18px 0 10px 0;font-size:15px;text-transform:uppercase;">
                Detalhamento Nível a Nível do Caminho Traçado ({len(passos)} Decisões)
            </h3>
            {"".join(cards_passos)}
        </div>
        """


class RenderizadorArvoreDecisaoASCII(IRenderizadorArvoreDecisao):
    """[GoF Strategy] Renderiza a Árvore de Decisões em formato hierárquico ASCII para terminal."""
    def renderizar_arvore(self, ficha: FichaPersonagem) -> str:
        rel = ficha.relatorio_ia
        linhas = [
            f"ÁRVORE DE DECISÃO (CSP AC-3 + MCTS UCT) — {ficha.nome} [{rel.arquetipo_alvo}]",
            f"└── [RAIZ] Nível {ficha.nivel} | Score Inicial: {rel.recompensa_inicial:.1f} -> Final: {rel.recompensa_final:.1f} "
            f"({rel.nos_expandidos} nós MCTS, {rel.podas_csp_realizadas} podas CSP)",
        ]
        for idx, p in enumerate(rel.passos_arvore):
            pref = "    ├──" if idx < len(rel.passos_arvore) - 1 else "    └──"
            barra = "    │  " if idx < len(rel.passos_arvore) - 1 else "       "
            info_mcts = f" [N={p.visitas_mcts}, Q/N={p.score_acumulado:.1f}, UCT={p.uct_vencedor:.1f}]" if "MCTS" in p.fase_algoritmo else f" [{p.fase_algoritmo}]"
            linhas.append(f"{pref} ★ {p.categoria_decisao}: {p.escolha_vencedora}{info_mcts}")
            for alt in p.alternativas_avaliadas:
                simb = "✖ [Podado CSP]" if alt.tipo_ramo == "PODADO_CSP" else f"○ [Ramo MCTS N={alt.visitas}]"
                linhas.append(f"{barra}    ├─ {simb} {alt.nome_escolha} -> {alt.motivo_descarte}")
        return "\n".join(linhas)


class RenderizadorFichaHTMLCSS(IRenderizadorFicha):
    """[GoF Strategy] Renderiza a Ficha de Tormenta20 responsiva para celular e desktop."""
    def renderizar(self, ficha: FichaPersonagem) -> str:
        esc = html.escape
        raca_nome = esc(ficha.raca.nome) if ficha.raca else "Não definida"
        classe_nome = esc(f"{ficha.classe.nome} (Nv {ficha.nivel})") if ficha.classe else f"Nível {ficha.nivel}"
        if ficha.raca and ficha.raca.nome.lower() == "golem":
            origem_nome = esc("Sem Origem (Golem: Propósito de Criação — p. 22)")
        elif ficha.raca and ficha.raca.nome.lower() == "osteon":
            origem_nome = esc(f"Sem Origem (Osteon: Memória Póstuma [{ficha.raca_anterior_osteon.split('(')[0].strip()}] — p. 27)")
        else:
            origem_nome = esc(f"{ficha.origem.nome} ({ficha.origem.poder_unico})") if ficha.origem else "Sem Origem"
        deus_nome = esc(f"{ficha.deus.nome} ({ficha.deus.energia})") if ficha.deus else "Sem Divindade"

        atr = ficha.atributos_finais
        blocos_atributos = "".join(
            f'<div class="attr-badge"><div class="sigla">{sigla}</div>'
            f'<div class="mod">{atr.obter(sigla):+d}</div></div>'
            for sigla in ATRIBUTOS_NOMES
        )

        resumo_dano = AnalisadorSinergiaEDanoT20.calcular_resumo_dano_ficha(ficha)
        linhas_atk = [f'<div class="item-row"><strong>🗡️ Arma & Estilo:</strong> {esc(resumo_dano["desc_dano_arma"])}</div>']
        info_nat_box = ficha.obter_info_arma_natural_extra()
        if info_nat_box:
            for_c_box = max(0, atr.FOR) + (2 if ficha.possui_poder("Sangue de Ferro") else 0) + (2 if ficha.possui_poder("Valentão") else 0)
            luta_c_box = ficha.bonus_pericias.get("Luta", 0) + (2 if ficha.possui_poder("Valentão") else 0)
            linhas_atk.append(
                f'<div class="item-row" style="background:rgba(120,53,15,0.38);border-left:4px solid #F59E0B;color:#FEF08A;padding:6px 10px;">'
                f'<strong>{esc(info_nat_box["titulo"])}:</strong> '
                f'Ataque <strong>{luta_c_box:+d}</strong> (Luta) | Dano: <strong>{esc(info_nat_box["dado_str"])}+{for_c_box} perfuração</strong> (crítico 20/x2, média <strong>{info_nat_box["media_dado_crit"]+for_c_box:.1f}</strong>) | '
                f'<em>Regra Oficial ({esc(info_nat_box["pagina"])}): 1x por rodada, quando usa a ação Agredir para atacar com outra arma, gasta <strong>1 PM</strong> para fazer um ataque corpo a corpo extra com {esc(info_nat_box["nome_curto"].lower())}.</em></div>'
            )
        if ficha.raca and ficha.raca.nome.lower() == "trog":
            cd_mc_box = 10 + (ficha.nivel // 2) + atr.CON
            linhas_atk.append(
                f'<div class="item-row" style="background:rgba(6,78,59,0.48);border-left:4px solid #34D399;color:#ECFDF5;padding:6px 10px;">'
                f'<strong>🤢 Habilidade Racial Ativa — Mau Cheiro (Trog, Livro p. 31):</strong> '
                f'Gasta <strong>Ação Padrão e 2 PM</strong> para expelir gás fétido em alcance curto (9m). Todas as criaturas (exceto trogs) devem passar em <strong>Fortitude (CD {cd_mc_box})</strong> ou ficam <strong>Enjoadas por 1d6 rodadas</strong> (só podem realizar uma ação padrão ou de movimento por rodada).</div>'
            )
        if ficha.classe and ficha.classe.nome.lower() == "guerreiro":
            custo_ae_b = 1 + (ficha.nivel - 1) // 4
            val_ae_b = 4 * custo_ae_b
            linhas_atk.append(
                f'<div class="item-row" style="background:rgba(30,58,138,0.48);border-left:4px solid #60A5FA;color:#EFF6FF;padding:6px 10px;">'
                f'<strong>⚔️ Habilidade Ataque Especial (Guerreiro, Livro p. 65):</strong> '
                f'Ao fazer um ataque, gasta <strong>{custo_ae_b} PM</strong> para receber <strong>+{val_ae_b} no Teste de Ataque</strong> OU <strong>+{val_ae_b} na Rolagem de Dano</strong> '
                f'OU <strong>dividir igualmente (+{val_ae_b//2} no Ataque e +{val_ae_b//2} no Dano)</strong> naquele único ataque (nunca soma cheio em ambos nem entra no ataque básico de 0 PM).</div>'
            )
        if ficha.possui_poder("Golpe Pessoal"):
            linhas_atk.append(
                f'<div class="item-row" style="background:rgba(120,53,15,0.48);border-left:4px solid #FACC15;color:#FEF08A;padding:6px 10px;">'
                f'<strong>☄️ Poder Golpe Pessoal (Guerreiro 5º nível, Livro p. 66–67):</strong> '
                f'Configuração ativa para <strong>{esc(ficha.arma_equipada.nome if ficha.arma_equipada else "Arma")}</strong>: '
                f'<strong>{esc(ficha.config_golpe_pessoal)}</strong> — combina <em>Brutal (+1 PM: +1 dado de dano da arma)</em>, '
                f'<em>Elemental (+2 PM: +2d6 de dano elemental)</em> e <em>Preciso (+1 PM: rola 2d20 no teste de ataque e usa o melhor resultado)</em> [Custo: {min(ficha.nivel, 4)} PM | Máx: {ficha.nivel} PM].</div>'
            )
        linhas_atk.append(f'<div class="item-row"><strong>⚡ Limite de PM por Magia/Habilidade:</strong> {esc(resumo_dano["str_limite_pm"])}</div>')
        if resumo_dano["dano_medio_raio"] > 0:
            linhas_atk.append(f'<div class="item-row"><strong>✨ Combo Raio Arcano (0 PM):</strong> {esc(resumo_dano["desc_raio"])}</div>')
        if resumo_dano["melhor_magia_info"]:
            nm_m, inf_m = resumo_dano["melhor_magia_info"]
            linhas_atk.append(
                f'<div class="item-row"><strong>🔥 Maior Explosão Mágica ({esc(nm_m)}):</strong> '
                f'{esc(inf_m["formula_final"])} (Média: <strong>{inf_m["dano_medio"]:.1f}</strong> | {esc(inf_m["aprim_desc"])})</div>'
            )
        ataque_html = "".join(linhas_atk)

        poderes_rows = []
        for idx_p, p in enumerate(ficha.poderes_escolhidos_progressao()):
            nv_aq = idx_p + 2
            tipo_lbl = f"Classe:{p.categoria_ou_classe}" if p.eh_poder_classe else f"Geral:{p.categoria_ou_classe}"
            pm_lbl = f" · {p.custo_pm}" if p.custo_pm and p.custo_pm != "0" else ""
            poderes_rows.append(
                f'<div class="item-row"><span class="tag" style="background:var(--t20-ruby-dark);">Nv. {nv_aq}</span>'
                f'<span class="tag">{esc(tipo_lbl)}</span>'
                f'<strong>{esc(p.nome)}</strong> <small>({esc(p.acao)}{esc(pm_lbl)})</small>: '
                f'{esc(p.efeito_resumo)}</div>'
            )
        for p_or in ficha.poderes_beneficio_origem:
            poderes_rows.append(
                f'<div class="item-row" style="background:rgba(120,53,15,0.32);"><span class="tag" style="background:#B45309;">1º Nv · Origem</span>'
                f'<strong>{esc(p_or.nome)}</strong> <small>({esc(p_or.acao)})</small>: {esc(p_or.efeito_resumo)}</div>'
            )
        for p_dev in ficha.poderes_concedidos_devocao:
            poderes_rows.append(
                f'<div class="item-row" style="background:rgba(88,28,135,0.32);"><span class="tag" style="background:#6D28D9;">1º Nv · Concedido</span>'
                f'<strong>{esc(p_dev.nome)}</strong> <small>({esc(p_dev.acao)})</small>: {esc(p_dev.efeito_resumo)}</div>'
            )
        poderes_html = "".join(poderes_rows) or '<div class="item-row">Nenhum poder de nível (personagem de 1º nível).</div>'

        magias_rows = []
        for m in ficha.magias_conhecidas:
            inf_m = resumo_dano["detalhes_magias"].get(m.id_magia, {})
            dano_str = f" — Dano/Efeito Médio: {inf_m.get('dano_medio', 0):.1f}" if inf_m.get("dano_medio", 0) > 0 else ""
            magias_rows.append(
                f'<div class="item-row"><span class="tag">{m.circulo}º Círc · {esc(m.escola)}</span>'
                f'<strong>{esc(m.nome)}</strong> <small>({esc(m.execucao)}, {esc(m.alcance)}, Res: {esc(m.resistencia)})</small>: '
                f'{esc(m.efeito_e_aprimoramentos)}'
                f'<div style="background:rgba(30,41,59,0.88);border-left:3px solid #F59E0B;color:#F8FAFC;padding:5px 8px;margin-top:4px;font-size:12px;">'
                f'<strong>🔥 Aprimoramento Máximo (Limite {inf_m.get("limite_pm", ficha.nivel)} PM):</strong> '
                f'<span style="color:#FDE047;font-weight:700;">{esc(inf_m.get("formula_final", ""))}</span>{esc(dano_str)}<br>'
                f'<span style="color:#CBD5E1;">↳ {esc(inf_m.get("aprim_desc", ""))}</span></div></div>'
            )
        magias_html = "".join(magias_rows) or '<div class="item-row">Nenhuma magia conhecida.</div>'

        itens_rows = []
        for it in ficha.itens_inventario:
            itens_rows.append(
                f'<div class="item-row"><span class="tag">{esc(it.categoria)}</span>'
                f'<strong>{esc(it.nome)}</strong> ({esc(it.preco)} · {it.espacos} esp.): '
                f'{esc(it.efeito_propriedades)}</div>'
            )
        itens_html = "".join(itens_rows) or '<div class="item-row">Inventário vazio.</div>'

        pericias_linhas = []
        for nome_p, val_p in sorted(ficha.bonus_pericias.items()):
            tr_cls = ' class="trained"' if ficha.possui_pericia_treinada(nome_p) else ""
            marca = "✔ Treinada" if ficha.possui_pericia_treinada(nome_p) else "—"
            pericias_linhas.append(
                f"<tr{tr_cls}><td>{esc(nome_p)}</td><td>{marca}</td>"
                f"<td style='text-align:right;font-weight:700;'>{val_p:+d}</td></tr>"
            )
        tabela_pericias_html = (
            '<table class="skills-table"><thead><tr><th>Perícia</th><th>Status</th>'
            '<th style="text-align:right;">Bônus</th></tr></thead><tbody>'
            + "".join(pericias_linhas) + "</tbody></table>"
        )

        if not ficha.validacoes_csp:
            csp_html = '<div class="csp-ok">✔ FICHA 100% VÁLIDA NO MOTOR CSP — Todos os pré-requisitos, domínios de devoção, círculos de magia e limites de carga atendidos!</div>'
        else:
            itens_v = "".join(f"<li>{esc(v)}</li>" for v in ficha.validacoes_csp)
            csp_html = f'<div class="csp-err"><strong>⚠ Violações CSP Detectadas ({len(ficha.validacoes_csp)}):</strong><ul style="margin:6px 0 0 18px;padding:0;">{itens_v}</ul></div>'

        hab_raca = esc(ficha.raca.habilidades_raca) if ficha.raca else "—"
        hab_classe = esc(ficha.classe.habilidades_fixas) if ficha.classe else "—"
        obrig_deus = esc(ficha.deus.obrigacoes_restricoes) if ficha.deus else "Nenhuma obrigação ou restrição divina."

        return f"""
        <div class="sheet-card">
            <div class="sheet-banner">
                <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                    <div id="ficha-retrato-custom-svg"></div>
                    <div>
                        <h2 class="sheet-title">{esc(ficha.nome)}</h2>
                        <div style="font-size:12.5px;color:var(--t20-muted);">
                            Jogador: <strong>{esc(ficha.jogador)}</strong> | Modo: <strong>{esc(ficha.relatorio_ia.modo_criacao)}</strong>
                        </div>
                        <div style="margin-top:5px;display:flex;gap:6px;flex-wrap:wrap;">
                            <button type="button" class="btn btn-save" style="width:auto;padding:4px 10px;font-size:11px;" onclick="sortearAparenciaAleatoriaRacialJS()">🎲 Sortear Aparência ({raca_nome})</button>
                            <button type="button" class="btn btn-ai" style="width:auto;padding:4px 10px;font-size:11px;" onclick="mostrarAba('tab-arena')">🎨 Abrir Criador Visual & Arena JRPG</button>
                        </div>
                    </div>
                </div>
                <div>
                    <span class="tag" style="font-size:13px;padding:5px 10px;">Score MCTS: {ficha.pontuacao_mcts:.1f}</span>
                </div>
            </div>

            <div id="ficha-estudio-aparencia-ssr-slot"></div>
            {csp_html}
            <div style="height:10px;"></div>

            <div class="meta-grid">
                <div class="meta-box"><div class="k">Raça</div><div class="v">{raca_nome}</div></div>
                <div class="meta-box"><div class="k">Classe & Nível ({esc(ficha.natureza_personagem())})</div><div class="v">{classe_nome}{esc(f" — {ficha.caminho_arcanista}" if ficha.classe and "arcanista" in ficha.classe.nome.lower() else "")}</div></div>
                <div class="meta-box"><div class="k">Origem</div><div class="v">{origem_nome}</div></div>
                <div class="meta-box"><div class="k">Divindade ({esc(ficha.quantidade_poderes_concedidos_devocao()[1].split("(")[0].strip())})</div><div class="v">{deus_nome}</div></div>
            </div>
            <div class="section-box" style="background:rgba(30,41,59,0.78);border-left:4px solid #F59E0B;color:#F1F5F9;margin-bottom:12px;padding:8px 12px;">
                <div style="font-size:12px;margin-bottom:4px;"><strong>🛡️ Proficiências Ativas ({esc(ficha.natureza_personagem())}):</strong> {esc(", ".join(ficha.obter_proficiencias_ativas()))}</div>
                <div style="font-size:12px;margin-bottom:4px;"><strong>🔮 Atributo-Chave de Magias & Caminho:</strong> {esc(f"{ficha.obter_atributo_chave_magia()[0]} — {ficha.obter_atributo_chave_magia()[1]}")} (Regras: INT p/ Mago e Bruxo | CAR p/ Feiticeiro e Bardo | SAB p/ Clérigo e Druida)</div>
                <div style="font-size:12px;margin-bottom:4px;"><strong>🎒 Benefícios de Origem / Golem / Osteon:</strong> {esc(ficha.resumo_regra_origem)}</div>
                <div style="font-size:12px;"><strong>✨ Poderes Concedidos por Devoção ({esc(ficha.quantidade_poderes_concedidos_devocao()[1])}):</strong> {esc(", ".join(f"{p.nome} ({p.efeito_resumo})" for p in ficha.poderes_concedidos_devocao) or "Nenhum (Personagem sem divindade)")}</div>
            </div>

            <div class="attr-strip">{blocos_atributos}</div>

            <div class="stats-strip">
                <div class="stat-pill"><div class="num" id="ficha-pv-num">{ficha.pv_maximos}</div><div class="lbl">PV Máx</div></div>
                <div class="stat-pill"><div class="num" id="ficha-pm-num">{ficha.pm_maximos}</div><div class="lbl">PM Máx</div></div>
                <div class="stat-pill"><div class="num" id="ficha-def-num">{ficha.defesa_total}</div><div class="lbl">Defesa</div></div>
                <div class="stat-pill"><div class="num" id="ficha-desl-num">{ficha.deslocamento_final}m</div><div class="lbl">Desloc.</div></div>
                <div class="stat-pill"><div class="num" id="ficha-cd-num">{ficha.cd_magias}</div><div class="lbl">CD Magia</div></div>
                <div class="stat-pill"><div class="num" id="ficha-carga-num">{ficha.carga_atual:.1f}/{ficha.carga_maxima:.0f}</div><div class="lbl">Carga</div></div>
            </div>
            <div class="section-box" style="background:rgba(30,27,75,0.65);border:1.5px solid #F59E0B;margin-bottom:14px;">
                <h3>📐 Memória de Cálculo Oficial (PV & PM por Classe, Raça e Poderes)</h3>
                <div class="item-row" id="ficha-calc-pv"><strong>Cálculo de PV:</strong> {esc(ficha.detalhe_pv)}</div>
                <div class="item-row" id="ficha-calc-pm"><strong>Cálculo de PM:</strong> {esc(ficha.detalhe_pm)}</div>
            </div>
            <div id="barra-atalhos-algoritmos-ficha-ssr" class="section-box" style="background:linear-gradient(135deg, rgba(15,23,42,0.95), rgba(30,27,75,0.92));border:1.5px solid #D4AF37;border-radius:10px;padding:10px 12px;margin-bottom:12px;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
                    <div>
                        <strong style="font-size:13px;color:#FDE047;">📐 Cálculos, Simulações &amp; Demonstrações de Algoritmo (CSP · MCTS · POMDP)</strong>
                        <div style="font-size:11px;color:#CBD5E1;">A interface principal foi mantida limpa para o jogo. Acesse os cálculos matemáticos e a árvore de IA nos botões ao lado:</div>
                    </div>
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        <button type="button" class="btn-roll-inline" style="background:#1E3A8A;border-color:#60A5FA;color:#EFF6FF;padding:5px 10px;font-weight:800;" onclick="abrirModalAlgoritmosCalculosT20JS('AUDITORIA_MCTS')">📊 Auditoria Score MCTS &amp; PUCT</button>
                        <button type="button" class="btn-roll-inline" style="background:#065F46;border-color:#34D399;color:#ECFDF5;padding:5px 10px;font-weight:800;" onclick="abrirModalAlgoritmosCalculosT20JS('SIMULADOR_TATICO')">🧭 Simulador &amp; Guia Tático</button>
                        <button type="button" class="btn-roll-inline" style="background:#581C87;border-color:#C084FC;color:#F3E8FF;padding:5px 10px;font-weight:800;" onclick="abrirModalAlgoritmosCalculosT20JS('ARVORE_MCTS')">🌳 Árvore de Decisão (CSP + MCTS)</button>
                        <button type="button" class="btn-roll-inline" style="background:#78350F;border-color:#FACC15;color:#FEF08A;padding:5px 10px;font-weight:800;" onclick="mostrarAba('tab-arvore')">🔬 Ir p/ Aba de Algoritmos</button>
                    </div>
                </div>
            </div>
            <div id="ssr-painel-algoritmos-oculto" style="display:none;">
            <div class="section-box" style="background:rgba(15,23,42,0.88);border:2px solid #DC2626;margin-bottom:14px;">
                <h3>📊 Auditoria Matemática do Score MCTS & Fatores de Decisão (Arquétipo: {esc(ficha.relatorio_ia.arquetipo_alvo)})</h3>
                <table class="skills-table">
                    <thead><tr><th>Fator Avaliado pelo Algoritmo</th><th>Memória de Cálculo (Valor × Peso)</th><th style="text-align:right;">Pontos no Score</th></tr></thead>
                    <tbody>
                        {"".join(f"<tr><td><strong>{esc(f_nm)}</strong></td><td>{esc(f_mem)}</td><td style='text-align:right;font-weight:700;color:#FDE047;'>{f_pts:+.1f} pts</td></tr>" for f_nm, f_mem, f_pts in resumo_dano["parcelas_score"])}
                        <tr class="trained"><td colspan="2"><strong>SCORE TOTAL FINAL (RECOMPENSA MCTS Q + BÔNUS SIMULADOR)</strong></td><td style="text-align:right;font-size:14px;color:#FDE047;"><strong>{ficha.pontuacao_mcts:.1f} pts</strong></td></tr>
                    </tbody>
                </table>
            </div>
            <div class="section-box" style="background:rgba(6,78,59,0.42);border:2px solid #10B981;margin-bottom:14px;">
                <h3 style="color:#34D399;border-color:#A7D7C5;">🧠 Metodologia IA I 2026: Aprendizado por Reforço (Deep RL DQN/Policy-Value) + MCTS (UCB1 & PUCT)</h3>
                <div class="item-row"><strong>Enquadramento Estrito (Roteiro IA I 2026, p. 1 & 4):</strong> Rede Neural exclusiva para <strong>Aprendizado por Reforço (Deep RL)</strong> acoplada às 4 etapas do MCTS (<em>Seleção UCB1/PUCT → Expansão Mascarada CSP → Simulação Monte Carlo → Retropropagação</em>).</div>
                <div class="item-row"><strong>A Tríade MDP (Estado, Ação, Recompensa):</strong> <strong>Estado S:</strong> Tensor <code>x(s) ∈ ℝ<sup>{ficha.relatorio_ia.metricas_ml.dimensao_tensor_ficha}</sup></code> | <strong>Ação A:</strong> Escolha em <code>A_legal(s)</code> filtrada por AC-3 | <strong>Recompensa R:</strong> <code>+Score Sinergia + 35×WinRate - 200×ViolaçõesCSP</code>.</div>
                <div class="item-row"><strong>Arquitetura Deep RL & Hiperparâmetros:</strong> {esc(ficha.relatorio_ia.metricas_ml.arquitetura_rede)} | <strong>Otimizador:</strong> {esc(ficha.relatorio_ia.metricas_ml.otimizador)} | <strong>Taxa Aprendizado (α):</strong> {ficha.relatorio_ia.metricas_ml.taxa_aprendizado} | <strong>Exploração:</strong> {esc(ficha.relatorio_ia.metricas_ml.hiperparametro_exploracao)}</div>
                <div class="item-row"><strong>Treinamento Online (Self-Play — {ficha.relatorio_ia.metricas_ml.epocas_self_play} épocas):</strong> RMSE Loss Inicial: <strong>{ficha.relatorio_ia.metricas_ml.loss_inicial:.2f}</strong> → Loss Final: <strong>{ficha.relatorio_ia.metricas_ml.loss_final:.2f}</strong> | Valor Estimado V<sub>θ</sub>(s): <strong>{ficha.relatorio_ia.metricas_ml.valor_previsto_rede:.1f} pts</strong></div>
                <div class="item-row"><strong>Top Priors da Política π<sub>θ</sub>(a|s) (com Action Masking CSP):</strong> {esc(", ".join(f"{nm}: {pr*100:.1f}%" for nm, pr in ficha.relatorio_ia.metricas_ml.top_priors_politica) or "Calculado na expansão")}</div>
            </div>
            <div class="section-box" style="background:rgba(45,10,18,0.65);border:2px solid #F59E0B;margin-bottom:14px;">
                <h3>⚔️ Simulador de Combate, Estatísticas Médias da Criatura (p. 323) & Melhor Tomada de Decisões Táticas</h3>
                <div class="item-row" style="background:rgba(30,58,138,0.42);border-left:4px solid #38BDF8;color:#E0F2FE;padding:8px 10px;margin-bottom:8px;font-size:12px;">
                    <strong>⚡ Regras de Combate do Capítulo 5 (Livro p. 230–239 / PDF p. 236–245 — Iniciativa, Desprevenido, Manobras & Ferimentos):</strong><br>
                    • <strong>Iniciativa & Surpresa (p. 230):</strong> {esc(ficha.relatorio_ia.simulacao_combate.resumo_iniciativa_e_surpresa)}<br>
                    • <strong>Ferimentos, Sangramento & Morte (p. 235–236):</strong> {esc(ficha.relatorio_ia.simulacao_combate.regra_ferimentos_sangramento)}<br>
                    • <strong>Modificadores de Situação (Tabela 5-1, p. 231):</strong> Flanquear (+2 Atq corpo a corpo), Posição Elevada (+2 Atq), Alvo Desprevenido (-5 Def), Alvo Caído (-5 Def corpo a corpo / +5 Def à distância), Cobertura Leve (+5 Def), Camuflagem Leve/Total (20%/50% chance de falha), Investida (+2 Atq / -2 Def).
                </div>
                <div class="item-row" style="background:rgba(120,53,15,0.38);border-left:4px solid #FACC15;color:#FEF08A;padding:8px 10px;margin-bottom:8px;font-size:12.5px;">
                    <strong>🎯 Cálculo Claro da Porcentagem de Vitória ({ficha.relatorio_ia.simulacao_combate.vitorias_contadas}/{ficha.relatorio_ia.simulacao_combate.episodios_simulados} vitórias = {ficha.relatorio_ia.simulacao_combate.taxa_vitoria_pct:.1f}%):</strong><br>
                    {esc(ficha.relatorio_ia.simulacao_combate.explicacao_calculo_vitoria)}
                </div>

                <div style="font-weight:700;color:#FDE047;font-size:13px;margin:8px 0 4px 0;">
                    1️⃣ Estatísticas Médias Oficiais da Criatura por Papel (Tabela de Ameaças — Livro p. 323 / PDF p. 329 — ND {ficha.relatorio_ia.simulacao_combate.nd_ameaca} · {esc(ficha.relatorio_ia.simulacao_combate.patamar_ameaca)})
                </div>
                <table class="skills-table" style="margin-bottom:10px;">
                    <thead>
                        <tr>
                            <th>Papel da Ameaça (p. 323)</th>
                            <th style="text-align:center;">Ataque</th>
                            <th style="text-align:center;">Dano Médio</th>
                            <th style="text-align:center;">Defesa</th>
                            <th style="text-align:center;">Res. Forte / Média / Fraca</th>
                            <th style="text-align:center;">PV Oficial (4x / Cota 1v1)</th>
                            <th style="text-align:center;">CD Efeito</th>
                            <th style="text-align:right;">TTK / % Vitória</th>
                        </tr>
                    </thead>
                    <tbody>
                        {"".join(f"<tr><td><strong>{esc(pa.papel)}</strong></td><td style='text-align:center;font-weight:700;'>+{pa.ataque}</td><td style='text-align:center;'>{pa.dano_medio}/rod</td><td style='text-align:center;font-weight:700;'>{pa.defesa}</td><td style='text-align:center;'>+{pa.res_forte} / +{pa.res_media} / {pa.res_fraca:+d}</td><td style='text-align:center;'>{pa.pv_grupo4} PV <small>(1v1: {pa.pv_duelo_1v1} PV)</small></td><td style='text-align:center;'>{pa.cd_efeito}</td><td style='text-align:right;font-weight:700;color:#34D399;'>{pa.ttk_heroi_turnos:.1f} rod ({pa.winrate_heroi_pct:.1f}%)</td></tr>" for pa in ficha.relatorio_ia.simulacao_combate.tabela_papeis_ameaca)}
                    </tbody>
                </table>

                <div style="font-weight:700;color:#FDE047;font-size:13px;margin:10px 0 4px 0;">
                    2️⃣ Melhor Tomada de Decisões em Combate (Política Tática Ótima por Economia de Ações no Turno)
                </div>
                <div class="item-row" style="background:rgba(6,78,59,0.48);border-left:4px solid #34D399;color:#ECFDF5;padding:7px 10px;margin-bottom:6px;font-size:12px;">
                    <strong>🧠 Rota Tática Recomendada pela IA:</strong> {esc(ficha.relatorio_ia.simulacao_combate.melhor_sequencia_decisoes)}
                </div>
                <table class="skills-table" style="margin-bottom:10px;">
                    <thead>
                        <tr>
                            <th>Tipo de Ação no Turno</th>
                            <th>Ação / Habilidade Avaliada</th>
                            <th style="text-align:center;">Custo PM</th>
                            <th style="text-align:center;">Chance Sucesso</th>
                            <th style="text-align:right;">Valor Esperado (EV)</th>
                            <th>Veredito & Justificativa Tática</th>
                        </tr>
                    </thead>
                    <tbody>
                        {"".join(f"<tr><td><strong>{esc(op.tipo_acao)}</strong></td><td>{esc(op.nome_acao)}</td><td style='text-align:center;'>{op.custo_pm} PM</td><td style='text-align:center;'>{op.chance_sucesso_pct:.0f}%</td><td style='text-align:right;font-weight:700;color:#FDE047;'>{op.valor_esperado_efetivo:.1f}</td><td><strong>{esc(op.veredito_tatico)}</strong> — {esc(op.justificativa)}</td></tr>" for op in ficha.relatorio_ia.simulacao_combate.matriz_decisoes_taticas)}
                    </tbody>
                </table>

                <div style="font-weight:700;color:#FDE047;font-size:13px;margin:10px 0 4px 0;">
                    3️⃣ Ações Tomadas Turno a Turno no Combate (Simulação Passo a Passo vs. Ameaça Solo ND {ficha.relatorio_ia.simulacao_combate.nd_ameaca})
                </div>
                <table class="skills-table">
                    <thead>
                        <tr>
                            <th style="text-align:center;">Turno</th>
                            <th>Ação Livre / Movimento (Herói)</th>
                            <th>Ação Padrão (Principal) & Rolagem</th>
                            <th style="text-align:center;">Dano & PV Criatura</th>
                            <th>Turno da Criatura (p. 323) & Reação</th>
                            <th style="text-align:right;">Saldo do Herói</th>
                        </tr>
                    </thead>
                    <tbody>
                        {"".join(f"<tr><td style='text-align:center;font-weight:700;'>#{t.numero_turno}</td><td>{esc(t.acao_livre_movimento)}</td><td><strong>{esc(t.acao_padrao_principal)}</strong><br><small style='color:#444;'>{esc(t.rolagem_e_teste)}</small></td><td style='text-align:center;font-weight:700;color:#8B1E24;'>{t.dano_causado:.1f} dano<br><small style='color:#333;'>({esc(t.pv_criatura_apos)})</small></td><td><small>{esc(t.acao_criatura_e_reacao)}</small></td><td style='text-align:right;font-weight:700;'>{esc(t.saldo_heroi_pv_pm)}</td></tr>" for t in ficha.relatorio_ia.simulacao_combate.turnos_detalhados)}
                    </tbody>
                </table>
            </div>
            <div class="section-box" style="background:rgba(15,23,42,0.85);border:2px solid #38BDF8;margin-bottom:14px;">
                <h3 style="color:#2B5B84;border-color:#B8C7E0;">🔬 Avaliação Comparativa de Algoritmos & Hiperparâmetros (Seção 3 & 4 — Roteiro IA I 2026)</h3>
                <table class="skills-table">
                    <thead>
                        <tr>
                            <th>Algoritmo / Agente Avaliado</th>
                            <th>Parâmetros (N, C, α)</th>
                            <th style="text-align:right;">Score Médio</th>
                            <th style="text-align:right;">DPR Efetivo</th>
                            <th style="text-align:right;">Winrate vs. Ameaça</th>
                            <th style="text-align:right;">Winrate vs. Aleatório</th>
                            <th style="text-align:right;">Nós / Tempo</th>
                        </tr>
                    </thead>
                    <tbody>
                        {"".join(f"<tr><td><strong>{esc(exp.nome_algoritmo)}</strong></td><td>{esc(exp.hiperparametros)}</td><td style='text-align:right;font-weight:700;'>{exp.score_final_medio:.1f}</td><td style='text-align:right;'>{exp.dpr_medio:.1f}</td><td style='text-align:right;color:#34D399;font-weight:700;'>{exp.winrate_ameaca_pct:.1f}%</td><td style='text-align:right;color:#2B5B84;font-weight:700;'>{exp.winrate_vs_aleatorio_pct:.1f}%</td><td style='text-align:right;'>{exp.nos_expandidos} nós ({exp.tempo_ms:.1f} ms)</td></tr>" for exp in ficha.relatorio_ia.metricas_ml.experimentos_comparativos)}
                    </tbody>
                </table>
            </div>

            
            </div>
            <div class="sheet-columns">
                <div>
                    <div class="section-box">
                        <h3>⚔️ Ataque Principal, Passos de Dano & Crítico</h3>
                        {ataque_html}
                    </div>
                    <div class="section-box" style="background:rgba(30,41,59,0.75);border-left:4px solid #38BDF8;color:#E2E8F0;">
                        <h3 style="color:#2B5B84;">⏱️ Economia de Ações por Turno (Livro p. 232–235)</h3>
                        <div class="item-row"><strong>Orçamento de Ações:</strong> {esc(resumo_dano["economia_acoes"]["resumo_orcamento"])}</div>
                        <div class="item-row"><strong>🟢 Ação Padrão (1/turno):</strong> {esc(", ".join(resumo_dano["economia_acoes"]["acoes_padrao"]))}</div>
                        <div class="item-row"><strong>🔵 Ação de Movimento (1/turno):</strong> {esc(", ".join(resumo_dano["economia_acoes"]["acoes_movimento"]))}</div>
                        <div class="item-row"><strong>🟣 Ação Completa (Padrão + Movimento):</strong> {esc(", ".join(resumo_dano["economia_acoes"]["acoes_completas"]))}</div>
                        <div class="item-row"><strong>🟡 Ações Livres (No seu turno):</strong> {esc(", ".join(resumo_dano["economia_acoes"]["acoes_livres"]))}</div>
                        <div class="item-row"><strong>🔴 Reações (Fora do turno / Gatilho):</strong> {esc(", ".join(resumo_dano["economia_acoes"]["reacoes"]))}</div>
                    </div>
                    <div class="section-box">
                        <h3>Habilidades de Raça, Classe & Devoção</h3>
                        <div class="item-row"><strong>Raça:</strong> {hab_raca}</div>
                        <div class="item-row"><strong>Classe:</strong> {hab_classe}</div>
                        <div class="item-row"><strong>Devoção:</strong> {obrig_deus}</div>
                    </div>
                    <div class="section-box">
                        <h3>Poderes de Progressão de Nível ({len(ficha.poderes_escolhidos_progressao())}/{max(0, ficha.nivel - 1)} — Nv. 2 ao {ficha.nivel}) & Extras de 1º Nv</h3>
                        {poderes_html}
                    </div>
                    <div class="section-box">
                        <h3>Grimório de Magias ({len(ficha.magias_conhecidas)})</h3>
                        {magias_html}
                    </div>
                    <div class="section-box">
                        <h3>Inventário & Equipamento ({len(ficha.itens_inventario)})</h3>
                        {itens_html}
                    </div>
                </div>
                <div>
                    <div class="section-box">
                        <h3>Perícias ({len(ficha.pericias_treinadas)} Treinadas)</h3>
                        {tabela_pericias_html}
                    </div>
                </div>
            </div>
        </div>
        """

