# -*- coding: utf-8 -*-
from __future__ import annotations

import abc
import base64
import copy
import dataclasses
import datetime
from datetime import datetime as dt_cls
import gzip
import hashlib
import zlib
import functools
import html
import http.server
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
import socket
import inspect
import io
import json
import lzma
import math
import os
import pathlib
from pathlib import Path
import random
import re
import socketserver
import sqlite3
import statistics
import string
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import typing
import urllib.parse
import urllib.request
import uuid
import webbrowser
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import (
    Any, Callable, Dict, Generic, Iterable, Iterator, List,
    Literal, Mapping, NamedTuple, Optional, Protocol, Sequence,
    Set, Tuple, Type, TypeVar, Union
)

"""
Camada de Apresentação & Orquestração — Facade Unificada (GoF Facade), Exportador HTML Offline, Servidor HTTP e Suite de Testes.
"""
from ..domain import *
from ..infrastructure import *
from ..application import *
from .styles_css import FolhaEstiloTemaTormenta20
from .renderers_html import (
    RenderizadorArvoreDecisaoHTMLSVG,
    RenderizadorArvoreDecisaoASCII,
    RenderizadorFichaHTMLCSS,
)
from .spa_bundler import SPA_JS_ENGINE_TEMPLATE, listar_modulos_frontend_spa

class Tormenta20Facade:
    def __init__(self, caminho_db: str = "tormenta20.db",
                 fonte_dados: Optional[IFonteDadosCatalogo] = None) -> None:
        self.db = GerenciadorBancoSQLite(caminho_db)
        self.fonte_dados = fonte_dados or SementeEmbutidaAdapter()
        self.resumo_tabelas = self.db.sincronizar_catalogo(self.fonte_dados)
        self.catalogo = SQLiteCatalogoRepository(self.db)
        self.calculadora = CalculadoraEstatisticaT20(self.catalogo.listar_pericias(), catalogo_poderes_gerais=self.catalogo.listar_poderes_gerais())
        self.validador_csp = MotorValidacaoCSP()
        self.otimizador_ia = OtimizadorFichaCSP_MCTS(self.catalogo, self.calculadora, self.validador_csp)
        self.repositorio_personagens = RepositorioPersonagemSQLite(self.db)
        self.renderizador_html = RenderizadorFichaHTMLCSS()
        self.renderizador_arvore_html = RenderizadorArvoreDecisaoHTMLSVG()
        self.renderizador_arvore_ascii = RenderizadorArvoreDecisaoASCII()
        self.ficha_atual: FichaPersonagem = self.otimizador_ia.otimizar(
            nome="Valkir de Tapista",
            jogador="Jogador",
            nivel=6,
            arquetipo="Marcial: Duas Mãos Pesado",
            iteracoes_mcts=90,
            fixar_raca="Minotauro",
            fixar_classe="Guerreiro",
        )

    def construir_ficha_manual(
        self,
        nome: str,
        jogador: str,
        nivel: int,
        nome_raca: str,
        nome_classe: str,
        nome_origem: str,
        nome_deus: str,
        atributos_base: Dict[str, int],
        escolhas_livres: List[str],
        pericias_nomes: List[str],
        poderes_ids: List[str],
        nome_arma: str,
        nome_armadura: str,
        nome_escudo: str,
        itens_extras_ids: List[str],
        magias_ids: List[str],
    ) -> FichaPersonagem:
        ficha = FichaPersonagem(
            nome=nome.strip() or "Personagem Manual",
            jogador=jogador.strip() or "Jogador",
            nivel=max(1, min(20, int(nivel))),
            atributos_base=Atributos(**{k: int(atributos_base.get(k, 0)) for k in ATRIBUTOS_NOMES}),
            escolhas_atributos_livres=[a.upper() for a in escolhas_livres if a],
        )
        ficha.raca = next((r for r in self.catalogo.listar_racas() if r.nome == nome_raca or r.id_raca == nome_raca), None)
        ficha.classe = next((c for c in self.catalogo.listar_classes() if c.nome == nome_classe or c.id_classe == nome_classe), None)
        ficha.origem = next((o for o in self.catalogo.listar_origens() if o.nome == nome_origem or o.id_origem == nome_origem), None)
        ficha.deus = next((d for d in self.catalogo.listar_deuses() if d.nome == nome_deus or d.id_deus == nome_deus), None)

        pericias_finais: List[str] = []
        if ficha.classe:
            for parte in re.split(r"\s+e\s+|/|,", ficha.classe.pericias_fixas):
                p_limpa = parte.split("(")[0].strip()
                if " ou " in p_limpa.lower():
                    p_limpa = p_limpa.split(" ou ")[0].strip()
                if p_limpa and p_limpa not in pericias_finais:
                    pericias_finais.append(p_limpa)
        for p_sel in pericias_nomes:
            if p_sel and p_sel not in pericias_finais:
                pericias_finais.append(p_sel)
        ficha.pericias_treinadas = pericias_finais

        mapa_pod_classe = {p.id_poder: p for p in self.catalogo.listar_poderes_classe()}
        mapa_pod_geral = {p.id_poder: p for p in self.catalogo.listar_poderes_gerais()}
        for pid in poderes_ids:
            if pid in mapa_pod_classe:
                ficha.poderes_classe.append(mapa_pod_classe[pid])
            elif pid in mapa_pod_geral:
                ficha.poderes_gerais.append(mapa_pod_geral[pid])

        todos_itens = self.catalogo.listar_itens()
        mapa_itens_id = {i.id_item: i for i in todos_itens}
        mapa_itens_nome = {i.nome: i for i in todos_itens}

        for nome_eq, attr_slot in ((nome_arma, "arma_equipada"), (nome_armadura, "armadura_equipada"), (nome_escudo, "escudo_equipado")):
            if nome_eq and nome_eq != "Nenhum":
                it_obj = mapa_itens_nome.get(nome_eq) or mapa_itens_id.get(nome_eq)
                if it_obj:
                    setattr(ficha, attr_slot, it_obj)
                    ficha.itens_inventario.append(it_obj)

        for iid in itens_extras_ids:
            it_extra = mapa_itens_id.get(iid) or mapa_itens_nome.get(iid)
            if it_extra and it_extra not in ficha.itens_inventario:
                ficha.itens_inventario.append(it_extra)

        mapa_magias = {m.id_magia: m for m in self.catalogo.listar_magias()}
        for mid in magias_ids:
            if mid in mapa_magias:
                ficha.magias_conhecidas.append(mapa_magias[mid])

        self.calculadora.recalcular(ficha)
        self.validador_csp.validar_ficha_completa(ficha)
        ficha.pontuacao_mcts = AvaliadorArquetipoMCTS("Dano Marcial").avaliar(ficha)

        # Constrói também uma árvore das escolhas manuais para visualização
        passos_man = [
            PassoCaminhoArvore(1, "Manual (Validado CSP)", "1. Raça & Classe", f"{ficha.raca.nome if ficha.raca else '?'} {ficha.classe.nome if ficha.classe else '?'}", f"Nível {ficha.nivel}"),
            PassoCaminhoArvore(2, "Manual (Validado CSP)", "2. Origem & Divindade", f"{ficha.origem.nome if ficha.origem else '?'} / {ficha.deus.nome if ficha.deus else 'Nenhum'}", "Escolhido pelo usuário"),
        ]
        for idx_p, pod_m in enumerate(ficha.todos_os_poderes(), 3):
            ok_p, mot_p = InterpretadorPreRequisitosCSP.compilar(pod_m.pre_requisitos).eh_satisfeita_por(ficha)
            passos_man.append(PassoCaminhoArvore(
                ordem=idx_p,
                fase_algoritmo="Manual (Validado CSP)",
                categoria_decisao=f"{idx_p}. Poder Selecionado",
                escolha_vencedora=pod_m.nome,
                detalhe_vencedora=f"{'Pré-requisito OK' if ok_p else '' + mot_p} — {pod_m.efeito_resumo}",
            ))

        sim_man = SimuladorCombateT20.simular(ficha, episodios=25)
        tensor_man = CodificadorFichaTensor.transformar_ficha(ficha)
        ficha.relatorio_ia = RelatorioOtimizacaoIA(
            modo_criacao="Seleção Manual + Avaliador ML/Simulador",
            arquetipo_alvo="Personalizado",
            recompensa_inicial=ficha.pontuacao_mcts,
            recompensa_final=ficha.pontuacao_mcts,
            trilha_decisoes=[f"Ficha configurada manualmente com {len(ficha.todos_os_poderes())} poderes."],
            passos_arvore=passos_man,
            simulacao_combate=sim_man,
            metricas_ml=MetricasTreinoML(
                dimensao_tensor_ficha=len(tensor_man),
                vetor_ficha_resumo=tensor_man[:8],
                valor_previsto_rede=ficha.pontuacao_mcts,
            ),
        )
        self.ficha_atual = ficha
        return ficha

    def pagina_web_completa(self, mensagem_status: str = "", aba_ativa: str = "tab-ficha") -> str:
        f = self.ficha_atual
        esc = html.escape
        css = FolhaEstiloTemaTormenta20.gerar_css_web()

        def opts_entidades(lista: Sequence[Any], atual: Optional[str], incluir_auto: bool = False, incluir_nenhum: bool = False) -> str:
            partes = []
            if incluir_auto:
                partes.append('<option value="AUTO">Automático (Deixar o CSP decidir)</option>')
            if incluir_nenhum:
                sel = " selected" if not atual or atual == "Nenhum" else ""
                partes.append(f'<option value="Nenhum"{sel}>— Nenhum —</option>')
            for ent in lista:
                nome = ent.nome
                sel = " selected" if atual == nome else ""
                partes.append(f'<option value="{esc(nome)}"{sel}>{esc(nome)}</option>')
            return "".join(partes)

        opcoes_poderes = []
        ids_atuais_pod = {p.id_poder for p in f.todos_os_poderes()}
        candidatos_pod = self.catalogo.listar_poderes_classe(f.classe.nome if f.classe else None) + self.catalogo.listar_poderes_gerais()
        for pod in candidatos_pod:
            ok_csp, _ = InterpretadorPreRequisitosCSP.compilar(pod.pre_requisitos).eh_satisfeita_por(f)
            prefixo = "" if ok_csp else ""
            sel = " selected" if pod.id_poder in ids_atuais_pod else ""
            cat_lbl = f"Classe:{pod.categoria_ou_classe}" if pod.eh_poder_classe else pod.categoria_ou_classe
            opcoes_poderes.append(
                f'<option value="{esc(pod.id_poder)}"{sel}>{prefixo} [{esc(cat_lbl)}] {esc(pod.nome)} (Req: {esc(pod.pre_requisitos)})</option>'
            )

        opcoes_pericias = [
            f'<option value="{esc(per.nome)}"{" selected" if f.possui_pericia_treinada(per.nome) else ""}>{esc(per.nome)} ({esc(per.atributo_chave)})</option>'
            for per in self.catalogo.listar_pericias()
        ]

        armas = [i for i in self.catalogo.listar_itens() if i.categoria == "Arma"]
        armaduras = [i for i in self.catalogo.listar_itens() if i.categoria == "Armadura"]
        escudos = [i for i in self.catalogo.listar_itens() if i.categoria == "Escudo"]
        outros_itens = [i for i in self.catalogo.listar_itens() if i.categoria not in ("Arma", "Armadura", "Escudo")]

        ids_itens_atuais = {i.id_item for i in f.itens_inventario}
        opcoes_itens_extras = [
            f'<option value="{esc(i.id_item)}"{" selected" if i.id_item in ids_itens_atuais else ""}>[{esc(i.categoria)}] {esc(i.nome)} ({esc(i.preco)})</option>'
            for i in outros_itens
        ]

        ids_magias_atuais = {m.id_magia for m in f.magias_conhecidas}
        opcoes_magias = [
            f'<option value="{esc(m.id_magia)}"{" selected" if m.id_magia in ids_magias_atuais else ""}>[{m.circulo}º Círc · {esc(m.tipo)}] {esc(m.nome)} ({esc(m.escola)})</option>'
            for m in self.catalogo.listar_magias()
        ]

        inputs_atributos = "".join(
            f'<div><label>{sigla}</label><input type="number" name="atr_{sigla}" min="-2" max="6" value="{f.atributos_base.obter(sigla)}"></div>'
            for sigla in ATRIBUTOS_NOMES
        )

        resumo_salvas = self.repositorio_personagens.listar_resumo()
        linhas_salvas = "".join(
            f'<div class="item-row" style="display:flex;justify-content:space-between;align-items:center;">'
            f'<span><strong>#{r["id_personagem"]} {esc(r["nome"])}</strong> ({esc(str(r["id_raca"]))} {esc(str(r["id_classe"]))} Nv {r["nivel"]} · Score {r["pontuacao_mcts"]})</span>'
            f'<button type="button" onclick="carregarFichaSalvaHibrido({r["id_personagem"]})" style="background:none;border:1px solid var(--t20-ruby);border-radius:4px;color:var(--t20-ruby);font-weight:700;cursor:pointer;padding:4px 8px;">[Abrir]</button></div>'
            for r in resumo_salvas[:10]
        ) or '<div class="item-row">Nenhuma ficha salva ainda.</div>'

        alerta_topo = (
            f'<div class="container-app" style="margin-bottom:8px;">'
            f'<div class="csp-ok" style="background:#FFF8E7;border-color:var(--t20-gold);color:#5A1014;">{esc(mensagem_status)}</div></div>'
            if mensagem_status else ""
        )

        ficha_html = self.renderizador_html.renderizar(f)
        arvore_html = self.renderizador_arvore_html.renderizar_arvore(f)
        catalogo_inline = json.dumps({
            "racas": [asdict(x) for x in self.catalogo.listar_racas()],
            "classes": [asdict(x) for x in self.catalogo.listar_classes()],
            "origens": [asdict(x) for x in self.catalogo.listar_origens()],
            "deuses": [asdict(x) for x in self.catalogo.listar_deuses()],
            "pericias": [asdict(x) for x in self.catalogo.listar_pericias()],
            "poderes_classe": [asdict(x) for x in self.catalogo.listar_poderes_classe()],
            "poderes_gerais": [asdict(x) for x in self.catalogo.listar_poderes_gerais()],
            "itens": [asdict(x) for x in self.catalogo.listar_itens()],
            "magias": [asdict(x) for x in self.catalogo.listar_magias()],
            "ameacas": [asdict(x) for x in TABELA_AMEACAS_OFICIAL_T20],
            "ameacas_cap7": [asdict(x) for x in CATALOGO_AMEACAS_CAP7],
        }, ensure_ascii=False)
        js_hibrido = SPA_JS_ENGINE_TEMPLATE.replace("__CATALOGO_JSON_INLINE__", catalogo_inline)

        return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Tormenta20 Mobile & Desktop — Ficha & Árvore MCTS/CSP</title>
<style>{css}</style>
<script>{js_hibrido}</script>
</head>
<body>
<header class="topbar">
    <div style="display:flex;align-items:center;gap:12px;">
        <svg width="36" height="36" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;">
            <polygon points="32,4 40,22 60,32 40,42 32,60 24,42 4,32 24,22" fill="#6E1E1E" stroke="#C99B42" stroke-width="2"/>
            <circle cx="32" cy="32" r="11" fill="#151821" stroke="#C99B42" stroke-width="1.6"/>
            <ellipse cx="32" cy="32" rx="7.5" ry="4.5" fill="#A62C2B"/>
            <ellipse cx="32" cy="32" rx="2.2" ry="4.2" fill="#E3BE6D"/>
        </svg>
        <div>
            <h1>Códice de Arton</h1>
            <div class="subtitle">{esc(f.nome)} · {esc(f.raca.nome if f.raca else '')} {esc(f.classe.nome if f.classe else '')} Nv. {f.nivel} · Tormenta20 Jogo do Ano</div>
        </div>
    </div>
    <div class="mobile-quick-bar">
        <select id="global-theme-selector" class="theme-select" onchange="mudarTemaGlobalAppJS(this.value)" aria-label="Tema visual">
            <option value="OBSIDIAN" selected>Tema: Obsidiana</option>
            <option value="PIXEL16">Tema: Retrô 16-Bit</option>
            <option value="PARCHMENT">Tema: Pergaminho</option>
        </select>
        <span class="topbar-pill stat-pv"><span class="stat-label">PV</span><span class="stat-val">{f.pv_maximos}</span></span>
        <span class="topbar-pill stat-pm"><span class="stat-label">PM</span><span class="stat-val">{f.pm_maximos}</span></span>
        <span class="topbar-pill stat-def"><span class="stat-label">DEF</span><span class="stat-val">{f.defesa_total}</span></span>
        <span class="topbar-pill stat-score"><span class="stat-label">Score</span><span class="stat-val">{f.pontuacao_mcts:.0f}</span></span>
        <form method="POST" action="/salvar" onsubmit="submeterFormularioHibrido(event, '/salvar')" style="margin:0;">
            <button type="submit" class="t20-btn-primary">Salvar</button>
        </form>
    </div>
</header>
<div class="container-app" style="margin-top:12px;margin-bottom:6px;">
    <nav class="app-nav-bar" aria-label="Navegação principal">
        <button type="button" data-tab-target="tab-ficha" class="nav-btn {'active' if aba_ativa == 'tab-ficha' else ''}" onclick="mostrarAba('tab-ficha')">
            <svg class="nav-ico" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="13" y2="17"/></svg>
            <span>Ficha</span>
        </button>
        <button type="button" data-tab-target="tab-arena" class="nav-btn {'active' if aba_ativa == 'tab-arena' else ''}" onclick="mostrarAba('tab-arena');inicializarArenaVisualSeNecessario();">
            <svg class="nav-ico" viewBox="0 0 24 24"><path d="M14.5 17.5 3 6V3h3l11.5 11.5"/><path d="m13 19 6-6"/><path d="m16 16 4 4"/><path d="m19 21 2-2"/></svg>
            <span>Arena</span>
        </button>
        <button type="button" data-tab-target="tab-mesa-online" class="nav-btn {'active' if aba_ativa == 'tab-mesa-online' else ''}" onclick="mostrarAba('tab-mesa-online');inicializarAbaMesaOnlineUI();">
            <svg class="nav-ico" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
            <span>Mesas</span>
        </button>
        <button type="button" data-tab-target="tab-arvore" class="nav-btn {'active' if aba_ativa == 'tab-arvore' else ''}" onclick="mostrarAba('tab-arvore')">
            <svg class="nav-ico" viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
            <span>Análise</span>
        </button>
        <button type="button" data-tab-target="tab-ia" class="nav-btn {'active' if aba_ativa == 'tab-ia' else ''}" onclick="mostrarAba('tab-ia')">
            <svg class="nav-ico" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <span>Otimizador</span>
        </button>
        <button type="button" data-tab-target="tab-manual" class="nav-btn {'active' if aba_ativa == 'tab-manual' else ''}" onclick="mostrarAba('tab-manual')">
            <svg class="nav-ico" viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
            <span>Editor</span>
        </button>
        <button type="button" data-tab-target="tab-chat" class="nav-btn {'active' if aba_ativa == 'tab-chat' else ''}" onclick="mostrarAba('tab-chat')">
            <svg class="nav-ico" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <span>Assistente</span>
        </button>
        <button type="button" data-tab-target="tab-movimento" class="nav-btn {'active' if aba_ativa == 'tab-movimento' else ''}" onclick="mostrarAba('tab-movimento');if(window.T20Engine&&window.T20Engine.renderMovementTab)window.T20Engine.renderMovementTab();else if(typeof renderizarAbaMovimentoV88JS==='function')renderizarAbaMovimentoV88JS();">
            <svg class="nav-ico" viewBox="0 0 24 24"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>
            <span>Movimento</span>
        </button>
    </nav>
</div>
<div class="container-app" style="margin-bottom:8px;"><div id="status-banner-box" class="csp-ok" style="display:none;background:#FFF8E7;border-color:var(--t20-gold);color:#5A1014;"></div></div>

<main class="container-app">
    <!-- ABA 1: FICHA DE TORMENTA 20 + RESUMO DA ÁRVORE -->
    <section id="tab-ficha" class="tab-section {'active' if aba_ativa == 'tab-ficha' else ''}">
        <div id="container-ficha-principal">{ficha_html}</div>
        <div id="container-arvore-na-ficha" style="display:none;">{arvore_html}</div>
    </section>

    <!-- ABA 2: ÁRVORE DE ESCOLHAS DO ALGORITMO (MCTS + CSP) -->
    <section id="tab-arvore" class="tab-section {'active' if aba_ativa == 'tab-arvore' else ''}">
        {arvore_html}
    </section>

    <!-- ABA 3: CRIAR / OTIMIZAR COM ALGORITMO DE IA (MCTS + CSP) -->
    <section id="tab-ia" class="tab-section {'active' if aba_ativa == 'tab-ia' else ''}">
        <div class="panel">
            <div class="panel-header">Otimizador Híbrido de IA (CSP AC-3 + MCTS UCT)</div>
            <div class="panel-body">
                <form method="POST" action="/otimizar_ia" onsubmit="submeterFormularioHibrido(event, '/otimizar_ia')">
                    <div class="form-row">
                        <div>
                            <label>Nome do Personagem</label>
                            <input type="text" name="nome" value="{esc(f.nome)}">
                        </div>
                        <div>
                            <label>Nível Alvo (1–20)</label>
                            <input type="number" name="nivel" min="1" max="20" value="{f.nivel}">
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>1. Seletor de Tipo / Natureza</label>
                            <select name="tipo_personagem" id="sel-tipo-personagem" onchange="filtrarArquetiposPorTipoFuncaoJS()">
                                <option value="TODOS">Todos os Tipos (Marcial, Conjurador & Híbrido)</option>
                                <option value="MARCIAL">Marcial (Combatente Físico / Armas)</option>
                                <option value="CONJURADOR">Conjurador (Arcano & Divino)</option>
                                <option value="HIBRIDO">Híbrido / Especialista (Paladino, Bardo, Caçador, Bucaneiro)</option>
                            </select>
                        </div>
                        <div>
                            <label>2. Função Tática no Grupo (Role)</label>
                            <select name="funcao_tatica" id="sel-funcao-tatica">
                                <option value="DPS Sustentado">DPS / Dano Sustentado por Rodada</option>
                                <option value="Dano Explosivo (Burst / Crítico)">Dano Explosivo (Burst / Crítico Letal)</option>
                                <option value="Tanque / Linha de Frente">Tanque / Linha de Frente (Defesa, RD & PV)</option>
                                <option value="Suporte & Cura">Suporte, Buffs & Cura de Grupo</option>
                                <option value="Controle & Debuff">Controle de Área & Debuff (CD Alta)</option>
                                <option value="Equilibrado / Versátil">Equilibrado (Ataque, Defesa & Perícias)</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>3. Estilo de Combate ou Caminho Mágico (Função Objetivo MCTS)</label>
                            <select name="arquetipo" id="sel-arquetipo-ia">
                                <option value="Qualquer" selected>Qualquer Estilo (Escolha Automática Global MCTS)</option>
                                <option value="Marcial: Duas Mãos Pesado">[MARCIAL] Duas Mãos Pesado (Montante / Destruidor)</option>
                                <option value="Marcial: Armas de Haste">[MARCIAL] Armas de Haste / Alongadas (Alabarda / Piqueiro)</option>
                                <option value="Marcial: Uma Mão Duelista">[MARCIAL] Uma Mão / Duelista (Florete / Ataque Preciso)</option>
                                <option value="Marcial: Duas Armas">[MARCIAL] Duas Armas / Ambidestria (Volume de Ataques)</option>
                                <option value="Tanque: Arma e Escudo">[MARCIAL] Estilo de Arma e Escudo (Baluarte & Bloqueio)</option>
                                <option value="Marcial: Dano Arqueiro">[MARCIAL] Arqueria / Disparo à Distância (Arco Longo)</option>
                                <option value="Conjurador Arcano: Mago">[CONJURADOR] Arcanista — Caminho do Mago (Atrib. Chave: INT / Grimório)</option>
                                <option value="Conjurador Arcano: Bruxo">[CONJURADOR] Arcanista — Caminho do Bruxo (Atrib. Chave: INT / Foco Arcano)</option>
                                <option value="Conjurador Arcano: Feiticeiro">[CONJURADOR] Arcanista — Caminho do Feiticeiro (Atrib. Chave: CAR / Linhagem)</option>
                                <option value="Conjurador: Bardo">[CONJURADOR] Bardo Eclético (Atrib. Chave: CAR / Inspiração & Magias)</option>
                                <option value="Suporte Divino: Clérigo">[CONJURADOR] Clérigo Devoto Fiel (Atrib. Chave: SAB + 2 Poderes Concedidos)</option>
                                <option value="Suporte Divino: Druida">[CONJURADOR] Druida Devoto Fiel (Atrib. Chave: SAB + 2 Poderes Concedidos)</option>
                                <option value="Híbrido: Paladino Abençoado">[HÍBRIDO] Paladino Devoto Fiel (Golpe Divino, Égide & 2 Poderes Concedidos)</option>
                                <option value="Multiclasse: Guerreiro + Bárbaro">[MULTICLASSE p. 34] Guerreiro + Bárbaro (Ataque Especial + Fúria + Golpe Pessoal)</option>
                                <option value="Multiclasse: Guerreiro + Paladino">[MULTICLASSE p. 34] Guerreiro + Paladino (Ataque Especial + Golpe Divino)</option>
                                <option value="Multiclasse: Guerreiro + Arcanista">[MULTICLASSE p. 34] Guerreiro + Arcanista — Magus de Batalha</option>
                                <option value="Multiclasse: Caçador + Ladino">[MULTICLASSE p. 34] Caçador + Ladino (Marca da Presa + Ataque Furtivo)</option>
                                <option value="Multiclasse: Cavaleiro + Clérigo">[MULTICLASSE p. 34] Cavaleiro + Clérigo — Templário Imortal</option>
                            </select>
                        </div>
                        <div>
                            <label>Iterações MCTS (UCT)</label>
                            <input type="number" name="iteracoes" min="20" max="500" value="120">
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>Restrição de Raça (CSP)</label>
                            <select name="fixar_raca">{opts_entidades(self.catalogo.listar_racas(), None, incluir_auto=True)}</select>
                        </div>
                        <div>
                            <label>1ª Classe Primária (CSP)</label>
                            <select name="fixar_classe">{opts_entidades(self.catalogo.listar_classes(), None, incluir_auto=True)}</select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>Política de Multiclasse do Algoritmo (Livro Básico JdA, Cap. 1, p. 34)</label>
                            <select name="modo_multiclasse" id="sel-modo-multiclasse-ia">
                                <option value="AUTO_MCTS" selected>IA Decide Automaticamente (Testa Classe Pura vs. Multiclasses e escolhe a Campeã)</option>
                                <option value="SEM_MULTICLASSE">Sem Multiclasse (Apenas Classe Única / Monoclasse 100%)</option>
                                <option value="FORCAR_MULTICLASSE_OTIMA">Forçar Melhor Multiclasse pela IA (Sempre Híbrido Otimizado de 2 ou 3 Classes)</option>
                                <option value="DIP_1_NIVEL">"Dip" Tático de 1 Nível (Nv-1 na 1ª Classe + 1 Nv na Melhor 2ª Classe p/ Habilidade de 1º Nv)</option>
                                <option value="DIP_2_NIVEIS">"Dip" de 2 Níveis (Nv-2 na 1ª Classe + 2 Nv na Melhor 2ª Classe + Poder da 2ª Classe)</option>
                                <option value="EQUILIBRADA_50_50">Multiclasse Equilibrada (~50% / 50% entre 2 Classes Sinérgicas)</option>
                                <option value="TRICLASSE_OTIMA">Triclasse Sinérgica Otimizada pela IA (Combina 3 Classes Complementares, Nv ≥ 3)</option>
                                <option value="MANUAL_FIXA">Multiclasse Manual (Usar exatamente a 2ª Classe e Níveis abaixo)</option>
                            </select>
                        </div>
                        <div>
                            <label>2ª Classe Manual (se Política = Manual ou Restrição Específica)</label>
                            <select name="fixar_classe_secundaria">
                                <option value="NENHUMA" selected>— Automático pela Política Acima / Nenhuma —</option>
                                {opts_entidades(self.catalogo.listar_classes(), None, incluir_auto=False)}
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>Níveis na 2ª Classe (0 = Automático pela IA, ou 1 a 19 no modo Manual)</label>
                            <input type="number" name="nivel_classe_secundaria" min="0" max="19" value="0">
                        </div>
                        <div>
                            <label>3ª Classe Opcional (Triclasse Manual ou Automática)</label>
                            <select name="fixar_classe_terciaria">
                                <option value="NENHUMA" selected>— Nenhuma / Automático —</option>
                                {opts_entidades(self.catalogo.listar_classes(), None, incluir_auto=False)}
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>Restrição de Origem (CSP)</label>
                            <select name="fixar_origem">{opts_entidades(self.catalogo.listar_origens(), None, incluir_auto=True)}</select>
                        </div>
                        <div>
                            <label>Restrição de Divindade (CSP)</label>
                            <select name="fixar_deus">{opts_entidades(self.catalogo.listar_deuses(), None, incluir_auto=True, incluir_nenhum=True)}</select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>Personalizar Arma Preferida (Opcional — CSP/MCTS)</label>
                            <select name="fixar_arma" id="sel-fixar-arma-ia">
                                <option value="AUTO" selected>Automático (Melhor Arma p/ o Estilo & Proficiência)</option>
                                <option value="Montante">Montante (2d6, Crítico 19/x2 — Duas Mãos)</option>
                                <option value="Machado de guerra">Machado de Guerra (1d12, Crítico x3 — Duas Mãos)</option>
                                <option value="Machado táurico">Machado Táurico (2d8, Crítico x3 — Exótica 2 Mãos)</option>
                                <option value="Marreta">Marreta (3d4, Crítico x2 — Duas Mãos)</option>
                                <option value="Alabarda">Alabarda (1d10, Crítico x3 — Alongada)</option>
                                <option value="Gadanho">Gadanho (2d4, Crítico x4 — Duas Mãos)</option>
                                <option value="Katana">Katana (1d8/1d10, Crítico 19/x2 — Adaptável)</option>
                                <option value="Espada bastarda">Espada Bastarda (1d10/1d12, Crítico 19/x2)</option>
                                <option value="Espada longa">Espada Longa (1d8, Crítico 19/x2 — Uma Mão)</option>
                                <option value="Florete">Florete (1d6, Crítico 18/x2 — Ágil)</option>
                                <option value="Cimitarra">Cimitarra (1d6, Crítico 18/x2 — Uma Mão)</option>
                                <option value="Machado anão">Machado Anão (1d10, Crítico x3)</option>
                                <option value="Maça">Maça (1d8, Crítico x2)</option>
                                <option value="Tridente">Tridente (1d8, Crítico x2)</option>
                                <option value="Arco longo">Arco Longo (1d8, Crítico x3 — Disparo)</option>
                                <option value="Besta pesada">Besta Pesada (1d12, Crítico 19/x2 — Disparo)</option>
                                <option value="Mosquete">Mosquete (2d8, Crítico 19/x3 — Fogo)</option>
                                <option value="Cajado arcano">Cajado Arcano (+1 Limite de PM)</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-ai">Gerar Ficha & Traçar Árvore de Escolhas (CSP + MCTS)</button>
                </form>
            </div>
        </div>
    </section>

    <!-- ABA 4: SELEÇÃO MANUAL NA FICHA & BANCO DE DADOS SQLITE -->
    <section id="tab-manual" class="tab-section {'active' if aba_ativa == 'tab-manual' else ''}">
        <div class="panel">
            <div class="panel-header">Seleção Manual Completa na Ficha</div>
            <div class="panel-body">
                <form method="POST" action="/atualizar_manual" onsubmit="submeterFormularioHibrido(event, '/atualizar_manual')">
                    <div class="form-row">
                        <div>
                            <label>Nome do Personagem</label>
                            <input type="text" name="nome" value="{esc(f.nome)}">
                        </div>
                        <div>
                            <label>Jogador</label>
                            <input type="text" name="jogador" value="{esc(f.jogador)}">
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>Nível (1 a 20)</label>
                            <input type="number" name="nivel" min="1" max="20" value="{f.nivel}">
                        </div>
                        <div>
                            <label>Raça (18 opções)</label>
                            <select name="raca">{opts_entidades(self.catalogo.listar_racas(), f.raca.nome if f.raca else None)}</select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>1ª Classe (Primária — Nv. 1 do Personagem)</label>
                            <select name="classe">{opts_entidades(self.catalogo.listar_classes(), f.classe.nome if f.classe else None)}</select>
                        </div>
                        <div>
                            <label>Caminho do Arcanista (se Arcanista)</label>
                            <select name="caminho_arcanista">
                                <option value="Mago"{" selected" if f.caminho_arcanista == "Mago" else ""}>Mago (Atributo-Chave: Inteligência [INT])</option>
                                <option value="Bruxo"{" selected" if f.caminho_arcanista == "Bruxo" else ""}>Bruxo (Atributo-Chave: Inteligência [INT])</option>
                                <option value="Feiticeiro"{" selected" if f.caminho_arcanista == "Feiticeiro" else ""}>Feiticeiro (Atributo-Chave: Carisma [CAR])</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>2ª Classe — Multiclasse (Livro Básico JdA, Cap. 1, p. 34)</label>
                            <select name="classe_secundaria">
                                <option value="NENHUMA" selected>— Nenhuma (Classe Única) —</option>
                                {opts_entidades(self.catalogo.listar_classes(), None, incluir_auto=False)}
                            </select>
                        </div>
                        <div>
                            <label>Níveis na 2ª Classe (soma apenas PV/nível e não concede perícias iniciais, p. 34)</label>
                            <input type="number" name="nivel_classe_secundaria" min="0" max="19" value="0">
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label id="lbl-origem-manual">Origem (35 opções — Golem e Osteon não possuem Origem, p. 22/27)</label>
                            <select name="origem" id="sel-origem-manual">{opts_entidades(self.catalogo.listar_origens(), f.origem.nome if f.origem else None, incluir_nenhum=True)}</select>
                        </div>
                        <div>
                            <label>Memória Póstuma (se Raça = Osteon, p. 27) / Propósito Golem</label>
                            <select name="raca_anterior_osteon" id="sel-osteon-manual">
                                <option value="Anão (Duro como Pedra)"{" selected" if f.raca_anterior_osteon.startswith("Anão") else ""}>Osteon ex-Anão: Duro como Pedra (+3 PV 1º nv e +1 PV/nv)</option>
                                <option value="Elfo (Sangue Mágico)"{" selected" if f.raca_anterior_osteon.startswith("Elfo") else ""}>Osteon ex-Elfo: Sangue Mágico (+1 PM por nível)</option>
                                <option value="Humano (Versátil: +1 Poder Geral)"{" selected" if f.raca_anterior_osteon.startswith("Humano") else ""}>Osteon ex-Humano: +1 Poder Geral e +1 Perícia</option>
                                <option value="Qareen (Tatuagem Mística)"{" selected" if f.raca_anterior_osteon.startswith("Qareen") else ""}>Osteon ex-Qareen: Tatuagem Mística (+1 Magia 1º Círc)</option>
                                <option value="Trog (Mordida & Casca Grossa)">Osteon ex-Trog: Mordida (1d6) & Casca Grossa (+1 Def)</option>
                        <option value="Minotauro (Chifres & Faro)"{" selected" if f.raca_anterior_osteon.startswith("Minotauro") else ""}>Osteon ex-Minotauro: Chifres (1d6) & Faro</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>Papel de Ameaça no Simulador (p. 323)</label>
                            <select name="papel_ameaca">
                                <option value="Solo">Ameaça Solo (Combatente Chefe — p. 323)</option>
                                <option value="Lacaio">Ameaça Lacaio (+Ataque/Dano, -Defesa/PV — p. 323)</option>
                                <option value="Especial">Ameaça Especial (Conjurador/Líder +CD — p. 323)</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>Divindade (20 Deuses)</label>
                            <select name="deus">{opts_entidades(self.catalogo.listar_deuses(), f.deus.nome if f.deus else None, incluir_nenhum=True)}</select>
                        </div>
                        <div>
                            <label>3 Atributos Livres (Raça)</label>
                            <input type="text" name="livres" value="{esc(','.join(f.escolhas_atributos_livres))}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Atributos Base (Antes dos Modificadores Raciais)</label>
                        <div class="attr-input-grid">{inputs_atributos}</div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label>Arma Principal</label>
                            <select name="arma">{opts_entidades(armas, f.arma_equipada.nome if f.arma_equipada else None, incluir_nenhum=True)}</select>
                        </div>
                        <div>
                            <label>Armadura</label>
                            <select name="armadura">{opts_entidades(armaduras, f.armadura_equipada.nome if f.armadura_equipada else None, incluir_nenhum=True)}</select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Escudo</label>
                        <select name="escudo">{opts_entidades(escudos, f.escudo_equipado.nome if f.escudo_equipado else None, incluir_nenhum=True)}</select>
                    </div>
                    <div class="form-group">
                        <label>Perícias Treinadas</label>
                        <select name="pericias" multiple>{"".join(opcoes_pericias)}</select>
                    </div>
                    <div class="form-group">
                        <label>Poderes de Classe & Gerais (= Pré-requisito CSP OK)</label>
                        <select name="poderes" multiple>{"".join(opcoes_poderes)}</select>
                    </div>
                    <div class="form-group">
                        <label>Grimório de Magias (1º ao 5º Círculo)</label>
                        <select name="magias" multiple>{"".join(opcoes_magias)}</select>
                    </div>
                    <div class="form-group">
                        <label>Itens Gerais, Alquímicos, Esotéricos e Mágicos</label>
                        <select name="itens_extras" multiple>{"".join(opcoes_itens_extras)}</select>
                    </div>
                    <button type="submit" class="btn btn-manual">Aplicar Seleções Manuais & Validar CSP</button>
                </form>
            </div>
        </div>

        <div class="panel">
            <div class="panel-header">Fichas Salvas no Banco SQLite (tormenta20.db)</div>
            <div class="panel-body">{linhas_salvas}</div>
        </div>

        <div class="panel" style="margin-top:14px;">
            <div class="panel-header">Bestiário Oficial do Capítulo 7 — Ameaças (Págs. 282 a 323 do Livro / 288 a 329 do PDF — 65 Fichas)</div>
            <div class="panel-body">
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;align-items:center;">
                    <select id="filtro-grupo-bestiario-cap7" onchange="filtrarTabelaBestiarioCap7JS()" style="width:auto;min-width:220px;">
                        <option value="TODOS">Todos os 9 Grupos do Capítulo 7 (65 Ameaças)</option>
                        <option value="Masmorras">1. Masmorras (10 criaturas)</option>
                        <option value="Ermos">2. Ermos (18 criaturas)</option>
                        <option value="Puristas">3. Puristas (7 criaturas)</option>
                        <option value="Reino dos Mortos">4. Reino dos Mortos (9 criaturas)</option>
                        <option value="Duyshidakk">5. Duyshidakk (8 criaturas)</option>
                        <option value="Cultistas da Traição">6. Cultistas da Traição (9 criaturas)</option>
                        <option value="Trolls Nobres">7. Trolls Nobres & Variantes (8 criaturas)</option>
                        <option value="Dragões">8. Dragões & Servos (7 criaturas)</option>
                        <option value="Tormenta">9. A Tormenta & Lefeu (7 criaturas)</option>
                    </select>
                    <input type="text" id="busca-bestiario-cap7" oninput="filtrarTabelaBestiarioCap7JS()" placeholder="Buscar criatura por nome, habilidade, tipo ou ND..." style="flex:1;min-width:220px;">
                </div>
                <div style="overflow-x:auto;max-height:520px;overflow-y:auto;border:1px solid var(--t20-border);border-radius:8px;">
                    <table class="stat-table" style="width:100%;font-size:12px;">
                        <thead style="position:sticky;top:0;z-index:2;">
                            <tr>
                                <th>ID / Grupo</th>
                                <th>Criatura & Tipo (Cap. 7)</th>
                                <th>ND / Papel</th>
                                <th>Ini / Perc</th>
                                <th>Def / PV / PM</th>
                                <th>Resistências</th>
                                <th>Ataques & Dano Médio</th>
                                <th>Habilidades, RD & Atributos</th>
                                <th>Arena</th>
                            </tr>
                        </thead>
                        <tbody id="tbody-bestiario-cap7">
                            <tr class="row-cap7" data-grupo="Masmorras" data-busca="glop masmorras monstro pequeno percepção às cegas; imunidade a ácido e acertos críticos"><td><strong>CAP7_001</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Glop</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Pequeno · Livro JdA p. 285</span></td><td style="text-align:center;"><strong>ND 1/4</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +2<br>Perc +0</td><td style="text-align:center;"><strong>Def 10</strong><br><span style="font-size:11px;">PV 12 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +0<br>Ref +2 | Von -5</td><td style="font-size:11.5px;"><strong>+7</strong> (Dano méd: 9 | CD 12)<br>Pancada +7 (1d4+2 mais 1d4 ácido)</td><td style="font-size:11px;">Percepção às cegas; Imunidade a ácido e acertos críticos<br><em style="color:#94A3B8;">For 0, Des 0, Con 2, Int —, Sab -5, Car -5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_001')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="rato gigante masmorras animal pequeno faro, visão na penumbra; doença: infecção do esgoto (fort cd 12 evita)"><td><strong>CAP7_002</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Rato Gigante</a></strong><br><span style="font-size:11px;color:#64748B;">Animal Pequeno · Livro JdA p. 287</span></td><td style="text-align:center;"><strong>ND 1/4</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +5<br>Perc +3</td><td style="text-align:center;"><strong>Def 12</strong><br><span style="font-size:11px;">PV 4 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +0<br>Ref +3 | Von -2</td><td style="font-size:11.5px;"><strong>+7</strong> (Dano méd: 5 | CD 12)<br>Mordida +7 (1d4+3 mais doença)</td><td style="font-size:11px;">Faro, visão na penumbra; Doença: Infecção do esgoto (Fort CD 12 evita)<br><em style="color:#94A3B8;">For 0, Des 3, Con 1, Int -4, Sab 1, Car -3</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_002')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="bandido ermos humanoide (humano) médio perícias: furtividade +5, intimidação +2"><td><strong>CAP7_003</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Bandido</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 288</span></td><td style="text-align:center;"><strong>ND 1/4</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +4<br>Perc +1</td><td style="text-align:center;"><strong>Def 13</strong><br><span style="font-size:11px;">PV 6 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +1<br>Ref +3 | Von -1</td><td style="font-size:11.5px;"><strong>+7</strong> (Dano méd: 6 | CD 12)<br>Clava +7 (1d6+3)</td><td style="font-size:11px;">Perícias: Furtividade +5, Intimidação +2<br><em style="color:#94A3B8;">For 1, Des 2, Con 1, Int 0, Sab -1, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_003')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Cultistas da Traição" data-busca="cascavel cultistas da traição animal minúsculo faro, visão na penumbra; veneno: perde 1d12 pv (fort cd 12 evita); furtividade +10"><td><strong>CAP7_004</strong><br><span class="tag">Cultistas da Traição</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Cascavel</a></strong><br><span style="font-size:11px;color:#64748B;">Animal Minúsculo · Livro JdA p. 304</span></td><td style="text-align:center;"><strong>ND 1/4</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +5<br>Perc +1</td><td style="text-align:center;"><strong>Def 13</strong><br><span style="font-size:11px;">PV 4 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +2<br>Ref +5 | Von -1</td><td style="font-size:11.5px;"><strong>+7</strong> (Dano méd: 8 | CD 12)<br>Mordida +7 (1 perfuração mais veneno 1d12)</td><td style="font-size:11px;">Faro, visão na penumbra; Veneno: perde 1d12 PV (Fort CD 12 evita); Furtividade +10<br><em style="color:#94A3B8;">For -2, Des 3, Con 1, Int -4, Sab 1, Car -4</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_004')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="orc combatente masmorras humanoide (orc) médio visão no escuro; sensibilidade a luz (ofuscado sob luz solar); feroz (+2 dano)"><td><strong>CAP7_005</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Orc Combatente</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (orc) Médio · Livro JdA p. 287</span></td><td style="text-align:center;"><strong>ND 1/2</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +4<br>Perc +1</td><td style="text-align:center;"><strong>Def 14</strong><br><span style="font-size:11px;">PV 8 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +5<br>Ref +3 | Von +0</td><td style="font-size:11.5px;"><strong>+9</strong> (Dano méd: 11 | CD 13)<br>Maça +9 (1d8+7)</td><td style="font-size:11px;">Visão no escuro; Sensibilidade a Luz (ofuscado sob luz solar); Feroz (+2 dano)<br><em style="color:#94A3B8;">For 4, Des 1, Con 2, Int -1, Sab -1, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_005')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="guarda de cidade ermos humanoide (humano) médio perícias: atletismo +5, percepção +3"><td><strong>CAP7_006</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Guarda de Cidade</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 291</span></td><td style="text-align:center;"><strong>ND 1/2</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +2<br>Perc +3</td><td style="text-align:center;"><strong>Def 15</strong><br><span style="font-size:11px;">PV 8 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +5<br>Ref +2 | Von +1</td><td style="font-size:11.5px;"><strong>+9</strong> (Dano méd: 10 | CD 13)<br>Maça +9 (1d8+6)</td><td style="font-size:11px;">Perícias: Atletismo +5, Percepção +3<br><em style="color:#94A3B8;">For 2, Des 1, Con 2, Int 0, Sab 0, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_006')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Reino dos Mortos" data-busca="zumbi reino dos mortos morto-vivo médio visão no escuro; fraqueza zumbi (sofre dobro de dano de acertos críticos); imunidades de morto-vivo"><td><strong>CAP7_007</strong><br><span class="tag">Reino dos Mortos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Zumbi</a></strong><br><span style="font-size:11px;color:#64748B;">Morto-vivo Médio · Livro JdA p. 299</span></td><td style="text-align:center;"><strong>ND 1/4</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +0<br>Perc +0</td><td style="text-align:center;"><strong>Def 11</strong><br><span style="font-size:11px;">PV 10 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +3<br>Ref -1 | Von -1</td><td style="font-size:11.5px;"><strong>+6</strong> (Dano méd: 7 | CD 12)<br>Mordida +6 (1d6+4)</td><td style="font-size:11px;">Visão no escuro; Fraqueza Zumbi (sofre dobro de dano de acertos críticos); Imunidades de Morto-vivo<br><em style="color:#94A3B8;">For 3, Des -1, Con 2, Int —, Sab -1, Car -5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_007')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Duyshidakk" data-busca="goblin salteador duyshidakk humanoide (goblin) pequeno visão no escuro; oportunista (+2 no ataque e dano contra alvos flanqueados ou que já sofreram dano na rodada)"><td><strong>CAP7_008</strong><br><span class="tag">Duyshidakk</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Goblin Salteador</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (goblin) Pequeno · Livro JdA p. 302</span></td><td style="text-align:center;"><strong>ND 1/4</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +4<br>Perc +0</td><td style="text-align:center;"><strong>Def 13</strong><br><span style="font-size:11px;">PV 5 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +2<br>Ref +3 | Von -1</td><td style="font-size:11.5px;"><strong>+7</strong> (Dano méd: 9 | CD 12)<br>2 adagas +7 (1d4+2, 19)</td><td style="font-size:11px;">Visão no escuro; Oportunista (+2 no ataque e dano contra alvos flanqueados ou que já sofreram dano na rodada)<br><em style="color:#94A3B8;">For 0, Des 3, Con 1, Int 1, Sab -1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_008')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="gnoll saqueador ermos humanoide (gnoll) médio faro; rendição (inimigos adjacentes rendidos sofrem +1d6 dano)"><td><strong>CAP7_009</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Gnoll Saqueador</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (gnoll) Médio · Livro JdA p. 290</span></td><td style="text-align:center;"><strong>ND 1</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +3<br>Perc +5</td><td style="text-align:center;"><strong>Def 15</strong><br><span style="font-size:11px;">PV 12 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +7<br>Ref +7 | Von +1</td><td style="font-size:11.5px;"><strong>+11</strong> (Dano méd: 17 | CD 14)<br>Lança +11 (1d6+5) e mordida +11 (1d6+5) ou Arco curto +9 (1d6+4, x3)</td><td style="font-size:11px;">Faro; Rendição (inimigos adjacentes rendidos sofrem +1d6 dano)<br><em style="color:#94A3B8;">For 3, Des 2, Con 3, Int -2, Sab 0, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_009')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="lobo ermos animal médio faro, visão na penumbra; derrubar (livre ao acertar mordida, teste +9); táticas de alcateia (+2 ataque e dano quando flanqueia)"><td><strong>CAP7_010</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Lobo</a></strong><br><span style="font-size:11px;color:#64748B;">Animal Médio · Livro JdA p. 291</span></td><td style="text-align:center;"><strong>ND 1/2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +4<br>Perc +6</td><td style="text-align:center;"><strong>Def 14</strong><br><span style="font-size:11px;">PV 15 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +6<br>Ref +3 | Von +1</td><td style="font-size:11.5px;"><strong>+7</strong> (Dano méd: 10 | CD 13)<br>Mordida +7 (1d6+6)</td><td style="font-size:11px;">Faro, visão na penumbra; Derrubar (livre ao acertar mordida, teste +9); Táticas de Alcateia (+2 ataque e dano quando flanqueia)<br><em style="color:#94A3B8;">For 3, Des 3, Con 3, Int -4, Sab 2, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_010')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Puristas" data-busca="recruta purista puristas humanoide (humano) médio lutar em formação (+1 ataque e defesa adjacente a aliado); ódio puro (+5 von sob ordens, +2 dano vs não-humanos)"><td><strong>CAP7_011</strong><br><span class="tag">Puristas</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Recruta Purista</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 294</span></td><td style="text-align:center;"><strong>ND 1/2</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +3<br>Perc +0</td><td style="text-align:center;"><strong>Def 16</strong><br><span style="font-size:11px;">PV 8 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +6<br>Ref +2 | Von +0</td><td style="font-size:11.5px;"><strong>+9</strong> (Dano méd: 11 | CD 13)<br>Alabarda +9 (1d10+6, x3)</td><td style="font-size:11px;">Lutar em Formação (+1 ataque e Defesa adjacente a aliado); Ódio Puro (+5 Von sob ordens, +2 dano vs não-humanos)<br><em style="color:#94A3B8;">For 3, Des 1, Con 3, Int -1, Sab -1, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_011')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Cultistas da Traição" data-busca="jiboia cultistas da traição animal médio faro, visão na penumbra; agarrar aprimorado (mordida, teste +9); constrição (2d4+4 impacto no início do turno)"><td><strong>CAP7_012</strong><br><span class="tag">Cultistas da Traição</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Jiboia</a></strong><br><span style="font-size:11px;color:#64748B;">Animal Médio · Livro JdA p. 304</span></td><td style="text-align:center;"><strong>ND 1/2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +4<br>Perc +2</td><td style="text-align:center;"><strong>Def 14</strong><br><span style="font-size:11px;">PV 15 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +3<br>Ref +5 | Von +0</td><td style="font-size:11.5px;"><strong>+7</strong> (Dano méd: 10 | CD 13)<br>Mordida +7 (1d4+4)</td><td style="font-size:11px;">Faro, visão na penumbra; Agarrar Aprimorado (mordida, teste +9); Constrição (2d4+4 impacto no início do turno)<br><em style="color:#94A3B8;">For 3, Des 3, Con 1, Int -4, Sab 1, Car -4</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_012')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="chefe bandido ermos humanoide (humano) médio ataque furtivo (+2d6 dano contra alvos desprevenidos ou flanqueados); ordens (+2 perícias p/ aliados); furtividade +7"><td><strong>CAP7_013</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Chefe Bandido</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 288</span></td><td style="text-align:center;"><strong>ND 1</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +4<br>Perc +2</td><td style="text-align:center;"><strong>Def 16</strong><br><span style="font-size:11px;">PV 30 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +5<br>Ref +8 | Von +3</td><td style="font-size:11.5px;"><strong>+9</strong> (Dano méd: 15 | CD 14)<br>Espada curta +9 (1d6+5, 19) ou Adaga +7 (1d4+3, 19)</td><td style="font-size:11px;">Ataque Furtivo (+2d6 dano contra alvos desprevenidos ou flanqueados); Ordens (+2 perícias p/ aliados); Furtividade +7<br><em style="color:#94A3B8;">For 3, Des 2, Con 2, Int 0, Sab 0, Car 1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_013')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="centauro combatente ermos humanoide (centauro) grande medo de altura (abalado adjacente a queda de 3m+); investida poderosa (+2d8 dano em investida)"><td><strong>CAP7_014</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Centauro Combatente</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (centauro) Grande · Livro JdA p. 289</span></td><td style="text-align:center;"><strong>ND 1</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +3<br>Perc +4</td><td style="text-align:center;"><strong>Def 16</strong><br><span style="font-size:11px;">PV 35 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +9<br>Ref +2 | Von +5</td><td style="font-size:11.5px;"><strong>+9</strong> (Dano méd: 15 | CD 14)<br>Tacape +9 (1d10+5) e cascos +9 (1d6+3) ou Arco longo +7 (1d8+4, x3)</td><td style="font-size:11px;">Medo de Altura (abalado adjacente a queda de 3m+); Investida Poderosa (+2d8 dano em investida)<br><em style="color:#94A3B8;">For 4, Des 1, Con 2, Int -2, Sab 1, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_014')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="gorlogg ermos animal grande visão na penumbra; agarrar aprimorado (livre na mordida, teste +13); atletismo +9"><td><strong>CAP7_015</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Gorlogg</a></strong><br><span style="font-size:11px;color:#64748B;">Animal Grande · Livro JdA p. 290</span></td><td style="text-align:center;"><strong>ND 1</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +4<br>Perc +3</td><td style="text-align:center;"><strong>Def 16</strong><br><span style="font-size:11px;">PV 36 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +8<br>Ref +5 | Von +3</td><td style="font-size:11.5px;"><strong>+11</strong> (Dano méd: 15 | CD 14)<br>Mordida +11 (2d6+8, x3)</td><td style="font-size:11px;">Visão na penumbra; Agarrar Aprimorado (livre na mordida, teste +13); Atletismo +9<br><em style="color:#94A3B8;">For 5, Des 2, Con 5, Int -4, Sab 1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_015')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="sargento da guarda ermos humanoide (humano) médio ordens (movimento: aliados em alcance médio recebem +2 em testes de perícia até o fim da cena); atletismo +9"><td><strong>CAP7_016</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Sargento da Guarda</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 291</span></td><td style="text-align:center;"><strong>ND 1</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +4<br>Perc +5</td><td style="text-align:center;"><strong>Def 17</strong><br><span style="font-size:11px;">PV 32 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +9<br>Ref +4 | Von +3</td><td style="font-size:11.5px;"><strong>+10</strong> (Dano méd: 15 | CD 14)<br>Maça +10 (1d8+10) ou Besta leve +8 (1d8+4, 19)</td><td style="font-size:11px;">Ordens (Movimento: aliados em alcance médio recebem +2 em testes de perícia até o fim da cena); Atletismo +9<br><em style="color:#94A3B8;">For 3, Des 1, Con 2, Int 0, Sab 0, Car 1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_016')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="trog ermos monstro (trog) médio visão no escuro; mau cheiro (padrão: fort cd 15 ou enjoado 1d6 rodadas); sangue frio (+1 dano por dado de frio); furtividade +7"><td><strong>CAP7_017</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Trog</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (trog) Médio · Livro JdA p. 292</span></td><td style="text-align:center;"><strong>ND 1</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +3<br>Perc +0</td><td style="text-align:center;"><strong>Def 16</strong><br><span style="font-size:11px;">PV 11 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +10<br>Ref +5 | Von +1</td><td style="font-size:11.5px;"><strong>+11</strong> (Dano méd: 17 | CD 15)<br>Lança +11 (1d6+5) e mordida +11 (1d6+5) ou Azagaia +9 (1d6+5)</td><td style="font-size:11px;">Visão no escuro; Mau Cheiro (Padrão: Fort CD 15 ou enjoado 1d6 rodadas); Sangue Frio (+1 dano por dado de frio); Furtividade +7<br><em style="color:#94A3B8;">For 3, Des 1, Con 3, Int -2, Sab 0, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_017')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Puristas" data-busca="soldado purista puristas humanoide (humano) médio lutar em formação (+1 ataque e defesa adjacente a aliado); ódio puro (+5 von sob ordens, +2 dano vs não-humanos)"><td><strong>CAP7_018</strong><br><span class="tag">Puristas</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Soldado Purista</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 294</span></td><td style="text-align:center;"><strong>ND 1</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +3<br>Perc +1</td><td style="text-align:center;"><strong>Def 20</strong><br><span style="font-size:11px;">PV 12 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +10<br>Ref +4 | Von +1</td><td style="font-size:11.5px;"><strong>+11</strong> (Dano méd: 17 | CD 14)<br>Espada bastarda +11 (1d10+12, 19) ou Besta pesada +9 (1d12+4, 19)</td><td style="font-size:11px;">Lutar em Formação (+1 ataque e Defesa adjacente a aliado); Ódio Puro (+5 Von sob ordens, +2 dano vs não-humanos)<br><em style="color:#94A3B8;">For 4, Des 1, Con 3, Int -1, Sab 0, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_018')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Duyshidakk" data-busca="hobgoblin soldado duyshidakk humanoide (hobgoblin) médio visão no escuro; tática militar (+2 ataque e defesa quando adjacente a outro hobgoblin)"><td><strong>CAP7_019</strong><br><span class="tag">Duyshidakk</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Hobgoblin Soldado</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (hobgoblin) Médio · Livro JdA p. 302</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +5<br>Perc +2</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 18 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +12<br>Ref +7 | Von +3</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 21 | CD 16)<br>Espada longa +14 (1d8+16, 19) ou Arco longo +12 (1d8+10, x3)</td><td style="font-size:11px;">Visão no escuro; Tática Militar (+2 ataque e Defesa quando adjacente a outro hobgoblin)<br><em style="color:#94A3B8;">For 4, Des 2, Con 2, Int 0, Sab 0, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_019')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Cultistas da Traição" data-busca="naja cultistas da traição animal pequeno faro, visão na penumbra; veneno: perde 1d12 pv por 1d4 rodadas (fort cd 14 reduz a 1 rodada); furtividade +10"><td><strong>CAP7_020</strong><br><span class="tag">Cultistas da Traição</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Naja</a></strong><br><span style="font-size:11px;color:#64748B;">Animal Pequeno · Livro JdA p. 304</span></td><td style="text-align:center;"><strong>ND 1</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +6<br>Perc +3</td><td style="text-align:center;"><strong>Def 17</strong><br><span style="font-size:11px;">PV 28 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +5<br>Ref +10 | Von +1</td><td style="font-size:11.5px;"><strong>+10</strong> (Dano méd: 15 | CD 14)<br>Mordida +10 (1d4+2 mais veneno 1d12/rodada)</td><td style="font-size:11px;">Faro, visão na penumbra; Veneno: perde 1d12 PV por 1d4 rodadas (Fort CD 14 reduz a 1 rodada); Furtividade +10<br><em style="color:#94A3B8;">For 0, Des 4, Con 1, Int -4, Sab 1, Car -4</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_020')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="aranha gigante masmorras monstro grande visão no escuro; teia (movimento: área 3m, ref cd 16 evita enredado); veneno: perde 1d12 pv e fica fraco (fort cd 16 evita fraco)"><td><strong>CAP7_021</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Aranha Gigante</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 284</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +7<br>Perc +3</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 70 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +8<br>Ref +11 | Von +3</td><td style="font-size:11.5px;"><strong>+12</strong> (Dano méd: 18 | CD 16)<br>Mordida +12 (2d6+11 mais veneno)</td><td style="font-size:11px;">Visão no escuro; Teia (Movimento: área 3m, Ref CD 16 evita enredado); Veneno: perde 1d12 PV e fica fraco (Fort CD 16 evita fraco)<br><em style="color:#94A3B8;">For 5, Des 4, Con 2, Int -4, Sab 0, Car -4</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_021')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="gárgula masmorras construto médio visão no escuro, rd 5; imobilidade (percepção cd 30 para notar que não é estátua); imunidades de construto"><td><strong>CAP7_022</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Gárgula</a></strong><br><span style="font-size:11px;color:#64748B;">Construto Médio · Livro JdA p. 285</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +4<br>Perc +4</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 60 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +13<br>Ref +7 | Von +2</td><td style="font-size:11.5px;"><strong>+12</strong> (Dano méd: 18 | CD 16)<br>2 garras +12 (1d6+6)</td><td style="font-size:11px;">Visão no escuro, RD 5; Imobilidade (Percepção CD 30 para notar que não é estátua); Imunidades de Construto<br><em style="color:#94A3B8;">For 5, Des 2, Con 4, Int -2, Sab 0, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_022')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="orc chefe masmorras humanoide (orc) médio visão no escuro; urro selvagem (movimento: +2 ataque e dano corpo a corpo até o fim da cena); sensibilidade a luz"><td><strong>CAP7_023</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Orc Chefe</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (orc) Médio · Livro JdA p. 287</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +5<br>Perc +3</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 66 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +13<br>Ref +7 | Von +2</td><td style="font-size:11.5px;"><strong>+11</strong> (Dano méd: 18 | CD 16)<br>Machado de batalha +11 (1d8+12, x3)</td><td style="font-size:11px;">Visão no escuro; Urro Selvagem (Movimento: +2 ataque e dano corpo a corpo até o fim da cena); Sensibilidade a Luz<br><em style="color:#94A3B8;">For 5, Des 2, Con 4, Int 0, Sab 0, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_023')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="gnoll filibusteiro ermos humanoide (gnoll) médio faro; saque rápido (recarrega mosquete como movimento e saca livre)"><td><strong>CAP7_024</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Gnoll Filibusteiro</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (gnoll) Médio · Livro JdA p. 290</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +7<br>Perc +6</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 65 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +7<br>Ref +11 | Von +4</td><td style="font-size:11.5px;"><strong>+12</strong> (Dano méd: 18 | CD 16)<br>Mosquete +12 (2d8+9, 19/x3) ou Espada curta +12 (1d6+6, 19) e mordida +12 (1d6+6)</td><td style="font-size:11px;">Faro; Saque Rápido (recarrega mosquete como movimento e saca livre)<br><em style="color:#94A3B8;">For 3, Des 3, Con 3, Int -1, Sab 1, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_024')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="lobo-das-cavernas ermos animal grande faro, visão na penumbra; derrubar (livre na mordida, teste +16); táticas de alcateia (+4 ataque e +2 dano ao flanquear)"><td><strong>CAP7_025</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Lobo-das-Cavernas</a></strong><br><span style="font-size:11px;color:#64748B;">Animal Grande · Livro JdA p. 292</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +5<br>Perc +9</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 70 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +11<br>Ref +7 | Von +6</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 18 | CD 16)<br>Mordida +14 (2d6+11)</td><td style="font-size:11px;">Faro, visão na penumbra; Derrubar (livre na mordida, teste +16); Táticas de Alcateia (+4 ataque e +2 dano ao flanquear)<br><em style="color:#94A3B8;">For 6, Des 2, Con 5, Int -4, Sab 2, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_025')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Reino dos Mortos" data-busca="esqueleto reino dos mortos morto-vivo médio visão no escuro; rd 5/impacto, imunidade a frio; imunidades de morto-vivo"><td><strong>CAP7_026</strong><br><span class="tag">Reino dos Mortos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Esqueleto</a></strong><br><span style="font-size:11px;color:#64748B;">Morto-vivo Médio · Livro JdA p. 297</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +6<br>Perc +2</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 16 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +3<br>Ref +7 | Von +12</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 21 | CD 16)<br>Espada longa +14 (1d8+16, 19)</td><td style="font-size:11px;">Visão no escuro; RD 5/impacto, imunidade a frio; Imunidades de Morto-vivo<br><em style="color:#94A3B8;">For 4, Des 2, Con 1, Int —, Sab 0, Car -5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_026')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Reino dos Mortos" data-busca="turba zumbi reino dos mortos morto-vivo (bando) grande bando (dobro do dano se exceder def por 10+; metade se errar; +50% dano de área); fraqueza zumbi"><td><strong>CAP7_027</strong><br><span class="tag">Reino dos Mortos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Turba Zumbi</a></strong><br><span style="font-size:11px;color:#64748B;">Morto-vivo (bando) Grande · Livro JdA p. 299</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +0<br>Perc +0</td><td style="text-align:center;"><strong>Def 11</strong><br><span style="font-size:11px;">PV 85 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +5<br>Ref +1 | Von +1</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 18 | CD 16)<br>[Bando] Mordida +14 (2d6+11)</td><td style="font-size:11px;">Bando (dobro do dano se exceder Def por 10+; metade se errar; +50% dano de área); Fraqueza Zumbi<br><em style="color:#94A3B8;">For 3, Des -1, Con 2, Int —, Sab -1, Car -5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_027')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Trolls Nobres" data-busca="finntroll caçador trolls nobres monstro (finntroll) médio natureza vegetal, resistência a magia +2; marca da presa (movimento: +1d8 dano); regeneração vegetal (5 pv sob luz)"><td><strong>CAP7_028</strong><br><span class="tag">Trolls Nobres</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Finntroll Caçador</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (finntroll) Médio · Livro JdA p. 308</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +7<br>Perc +7</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 65 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +6<br>Ref +12 | Von +4</td><td style="font-size:11.5px;"><strong>+12</strong> (Dano méd: 20 | CD 16)<br>2 espadas curtas +12 (1d6+6, 19) ou Besta pesada +12 (1d12+6, 19) ou Rede +12</td><td style="font-size:11px;">Natureza Vegetal, resistência a magia +2; Marca da Presa (Movimento: +1d8 dano); Regeneração Vegetal (5 PV sob luz)<br><em style="color:#94A3B8;">For 1, Des 4, Con 3, Int 2, Sab 2, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_028')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Dragões" data-busca="enxame kobold dragões humanoide (kobold, enxame) médio enxame (metade dano armas, +50% área); unidos venceremos (+10 pv no início do turno até 100 pv)"><td><strong>CAP7_029</strong><br><span class="tag">Dragões</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Enxame Kobold</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (kobold, enxame) Médio · Livro JdA p. 313</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +7<br>Perc +9</td><td style="text-align:center;"><strong>Def 17</strong><br><span style="font-size:11px;">PV 60 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +7<br>Ref +13 | Von +2</td><td style="font-size:11.5px;"><strong>+12</strong> (Dano méd: 18 | CD 16)<br>Enxame (3d6+8 perfuração automático) + Caixa com Pregos (2d6 + atordoado, Ref CD 16)</td><td style="font-size:11px;">Enxame (metade dano armas, +50% área); Unidos Venceremos (+10 PV no início do turno até 100 PV)<br><em style="color:#94A3B8;">For 0, Des 3, Con 0, Int -1, Sab 0, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_029')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Tormenta" data-busca="maníaco lefou tormenta monstro (lefou) médio frenesi insano (sempre que causa ou sofre dano, recebe +2 cumulativo em ataque e dano até o fim da cena)"><td><strong>CAP7_030</strong><br><span class="tag">Tormenta</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Maníaco Lefou</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (lefou) Médio · Livro JdA p. 316</span></td><td style="text-align:center;"><strong>ND 2</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +4<br>Perc +2</td><td style="text-align:center;"><strong>Def 18</strong><br><span style="font-size:11px;">PV 75 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +12<br>Ref +7 | Von +3</td><td style="font-size:11.5px;"><strong>+12</strong> (Dano méd: 18 | CD 16)<br>Machado de guerra +12 (1d12+12, x3)</td><td style="font-size:11px;">Frenesi Insano (sempre que causa ou sofre dano, recebe +2 cumulativo em ataque e dano até o fim da cena)<br><em style="color:#94A3B8;">For 5, Des 1, Con 2, Int -1, Sab -1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_030')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="guerreiro de chifres masmorras espírito (abissal) médio faro, visão no escuro; rd 5, resistência a fogo/frio 10, imune a ácido e veneno; marrada (investida com machado e chifres)"><td><strong>CAP7_031</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Guerreiro de Chifres</a></strong><br><span style="font-size:11px;color:#64748B;">Espírito (abissal) Médio · Livro JdA p. 286</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +8<br>Perc +5</td><td style="text-align:center;"><strong>Def 21</strong><br><span style="font-size:11px;">PV 100 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +13<br>Ref +11 | Von +9</td><td style="font-size:11.5px;"><strong>+15</strong> (Dano méd: 21 | CD 17)<br>Machado de guerra +15 (1d12+10, x3) e chifres +15 (1d6+6)</td><td style="font-size:11px;">Faro, visão no escuro; RD 5, resistência a fogo/frio 10, imune a ácido e veneno; Marrada (investida com machado e chifres)<br><em style="color:#94A3B8;">For 5, Des 3, Con 4, Int -2, Sab 0, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_031')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="cão do inferno ermos espírito grande faro, visão no escuro; imunidade a fogo, rd 10/mágico, vulnerabilidade a frio"><td><strong>CAP7_032</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Cão do Inferno</a></strong><br><span style="font-size:11px;color:#64748B;">Espírito Grande · Livro JdA p. 289</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +8<br>Perc +8</td><td style="text-align:center;"><strong>Def 21</strong><br><span style="font-size:11px;">PV 95 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +11<br>Ref +9 | Von +7</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 21 | CD 17)<br>Mordida +14 (2d6+8 mais 2d6 fogo); Sopro (Padrão: cone 6m, 4d6+4 fogo, Ref CD 17)</td><td style="font-size:11px;">Faro, visão no escuro; Imunidade a fogo, RD 10/mágico, vulnerabilidade a frio<br><em style="color:#94A3B8;">For 5, Des 3, Con 4, Int -2, Sab 1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_032')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="centauro xamã ermos humanoide (centauro) grande magias divinas (1º armamento da natureza, controlar plantas, curar ferimentos 3d8+3; 2º enxame de pestes 4d12, cd 19)"><td><strong>CAP7_033</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Centauro Xamã</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (centauro) Grande · Livro JdA p. 289</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +4<br>Perc +8</td><td style="text-align:center;"><strong>Def 21</strong><br><span style="font-size:11px;">PV 74 | PM 18</span></td><td style="text-align:center;font-size:11.5px;">Fort +9<br>Ref +4 | Von +15</td><td style="font-size:11.5px;"><strong>+12</strong> (Dano méd: 21 | CD 19)<br>Bordão +12 (1d8+6) e cascos +12 (1d8+6)</td><td style="font-size:11px;">Magias Divinas (1º Armamento da Natureza, Controlar Plantas, Curar Ferimentos 3d8+3; 2º Enxame de Pestes 4d12, CD 19)<br><em style="color:#94A3B8;">For 3, Des 1, Con 3, Int -1, Sab 5, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_033')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="grifo ermos monstro grande visão no escuro; bote (completa: investida atacando com mordida e 2 garras com +2 em todos os 3 ataques)"><td><strong>CAP7_034</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Grifo</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 290</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +9<br>Perc +9</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 105 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +9<br>Ref +15 | Von +4</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 24 | CD 17)<br>Mordida +14 (2d6+6) e 2 garras +14 (1d6+4)</td><td style="font-size:11px;">Visão no escuro; Bote (Completa: investida atacando com mordida e 2 garras com +2 em todos os 3 ataques)<br><em style="color:#94A3B8;">For 5, Des 4, Con 3, Int -4, Sab 2, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_034')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Puristas" data-busca="sargento-mor puristas humanoide (humano) médio lutar em formação (+1 ataque/def); varrer (livre: ataque extra ao reduzir alvo a 0 pv); ódio puro"><td><strong>CAP7_035</strong><br><span class="tag">Puristas</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Sargento-mor</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 294</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +6<br>Perc +4</td><td style="text-align:center;"><strong>Def 24</strong><br><span style="font-size:11px;">PV 95 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +14<br>Ref +9 | Von +5</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 21 | CD 17)<br>Espada bastarda +14 (1d12+14, 19) ou Besta pesada +12 (1d12+6, 19)</td><td style="font-size:11px;">Lutar em Formação (+1 ataque/Def); Varrer (Livre: ataque extra ao reduzir alvo a 0 PV); Ódio Puro<br><em style="color:#94A3B8;">For 5, Des 1, Con 3, Int -1, Sab 0, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_035')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Duyshidakk" data-busca="goblin engenhoqueiro duyshidakk humanoide (goblin) pequeno engenhocas (ofício +13): asa de bambu (voo 12m), cospe-chamas (6d6 fogo, cd 19), gritador (-2 ataque e dano em alcance curto)"><td><strong>CAP7_036</strong><br><span class="tag">Duyshidakk</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Goblin Engenhoqueiro</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (goblin) Pequeno · Livro JdA p. 301</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +6<br>Perc +3</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 68 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +3<br>Ref +15 | Von +9</td><td style="font-size:11.5px;"><strong>+12</strong> (Dano méd: 21 | CD 19)<br>Cospe-chamas (6d6 fogo em cone de 6m, Ref CD 19) ou Besta leve +12 (1d8+6, 19)</td><td style="font-size:11px;">Engenhocas (Ofício +13): Asa de Bambu (voo 12m), Cospe-chamas (6d6 fogo, CD 19), Gritador (-2 ataque e dano em alcance curto)<br><em style="color:#94A3B8;">For 0, Des 3, Con 2, Int 4, Sab -1, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_036')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Cultistas da Traição" data-busca="sucuri cultistas da traição animal grande faro, visão na penumbra; agarrar aprimorado (livre na mordida, teste +19); constrição (2d8+12 automático por turno)"><td><strong>CAP7_037</strong><br><span class="tag">Cultistas da Traição</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Sucuri</a></strong><br><span style="font-size:11px;color:#64748B;">Animal Grande · Livro JdA p. 304</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +7<br>Perc +6</td><td style="text-align:center;"><strong>Def 19</strong><br><span style="font-size:11px;">PV 110 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +9<br>Ref +15 | Von +3</td><td style="font-size:11.5px;"><strong>+15</strong> (Dano méd: 21 | CD 17)<br>Mordida +15 (1d8+8) + Constrição (2d8+12 impacto)</td><td style="font-size:11px;">Faro, visão na penumbra; Agarrar Aprimorado (livre na mordida, teste +19); Constrição (2d8+12 automático por turno)<br><em style="color:#94A3B8;">For 7, Des 2, Con 4, Int -4, Sab 1, Car -4</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_037')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Cultistas da Traição" data-busca="nagah guardião cultistas da traição monstro (nagah) médio resistência a veneno +5; fraquezas ofídias (-5 contra música e +1 dano por dado de frio)"><td><strong>CAP7_038</strong><br><span class="tag">Cultistas da Traição</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Nagah Guardião</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (nagah) Médio · Livro JdA p. 306</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +7<br>Perc +4</td><td style="text-align:center;"><strong>Def 21</strong><br><span style="font-size:11px;">PV 105 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +6<br>Ref +11 | Von +9</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 21 | CD 17)<br>2 cimitarras +14 (1d6+5, 18) e cauda +14 (1d6+4)</td><td style="font-size:11px;">Resistência a veneno +5; Fraquezas Ofídias (-5 contra música e +1 dano por dado de frio)<br><em style="color:#94A3B8;">For 4, Des 2, Con 3, Int -1, Sab 0, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_038')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Dragões" data-busca="dragão filhote dragões monstro (dragão) médio percepção às cegas, visão no escuro; imune a fogo/paralisia/sono, vulnerável a frio"><td><strong>CAP7_039</strong><br><span class="tag">Dragões</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Dragão Filhote</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (dragão) Médio · Livro JdA p. 310</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +9<br>Perc +8</td><td style="text-align:center;"><strong>Def 22</strong><br><span style="font-size:11px;">PV 115 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +15<br>Ref +3 | Von +9</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 24 | CD 17)<br>Mordida +14 (1d8+6) e 2 garras +14 (1d6+5); Sopro (Padrão: cone 6m, 4d12 fogo, Ref CD 17, recarga mov)</td><td style="font-size:11px;">Percepção às cegas, visão no escuro; Imune a fogo/paralisia/sono, vulnerável a frio<br><em style="color:#94A3B8;">For 5, Des 3, Con 4, Int 0, Sab 1, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_039')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Tormenta" data-busca="uktril tormenta monstro (lefeu) médio rd 5, imunidades lefeu (crítico, ácido, eletricidade, fogo, frio, luz, trevas, metamorfose); insanidade da tormenta 1d6 pm (von cd 17)"><td><strong>CAP7_040</strong><br><span class="tag">Tormenta</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Uktril</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (lefeu) Médio · Livro JdA p. 314</span></td><td style="text-align:center;"><strong>ND 3</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +9<br>Perc +12</td><td style="text-align:center;"><strong>Def 22</strong><br><span style="font-size:11px;">PV 32 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +12<br>Ref +11 | Von +6</td><td style="font-size:11.5px;"><strong>+16</strong> (Dano méd: 24 | CD 17)<br>Pinça +16 (2d6+8, 19) e garra +16 (1d6+6)</td><td style="font-size:11px;">RD 5, Imunidades Lefeu (crítico, ácido, eletricidade, fogo, frio, luz, trevas, metamorfose); Insanidade da Tormenta 1d6 PM (Von CD 17)<br><em style="color:#94A3B8;">For 5, Des 4, Con 3, Int -1, Sab 2, Car -4</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_040')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="basilisco ermos monstro médio rd 5; olhar petrificante (início do turno em alcance curto: ref cd 18 ou lento -> petrificado); veneno 2d12 (fort cd 18 reduz metade)"><td><strong>CAP7_041</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Basilisco</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Médio · Livro JdA p. 288</span></td><td style="text-align:center;"><strong>ND 4</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +6<br>Perc +9</td><td style="text-align:center;"><strong>Def 23</strong><br><span style="font-size:11px;">PV 135 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +10<br>Ref +9 | Von +9</td><td style="font-size:11.5px;"><strong>+16</strong> (Dano méd: 24 | CD 18)<br>Mordida +16 (1d8+8 mais veneno 2d12)</td><td style="font-size:11px;">RD 5; Olhar Petrificante (Início do turno em alcance curto: Ref CD 18 ou lento -> petrificado); Veneno 2d12 (Fort CD 18 reduz metade)<br><em style="color:#94A3B8;">For 4, Des 2, Con 4, Int -4, Sab 1, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_041')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="ogro ermos humanoide (gigante) grande visão na penumbra; burro demais... (-5 intuição/vontade) ...para morrer! (reduz à metade todo dano de corte, impacto e perfuração)"><td><strong>CAP7_042</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Ogro</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (gigante) Grande · Livro JdA p. 292</span></td><td style="text-align:center;"><strong>ND 4</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +3<br>Perc +1</td><td style="text-align:center;"><strong>Def 23</strong><br><span style="font-size:11px;">PV 130 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +16<br>Ref +10 | Von +0</td><td style="font-size:11.5px;"><strong>+16</strong> (Dano méd: 24 | CD 18)<br>Tacape +16 (1d12+18)</td><td style="font-size:11px;">Visão na penumbra; Burro Demais... (-5 Intuição/Vontade) ...Para Morrer! (reduz à metade todo dano de corte, impacto e perfuração)<br><em style="color:#94A3B8;">For 7, Des 0, Con 4, Int -3, Sab -2, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_042')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="urso-coruja ermos monstro grande faro, visão no escuro; agarrar aprimorado (livre na garra, teste +18); abraço esmagador (2d6+10 impacto se acertar as 2 garras)"><td><strong>CAP7_043</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Urso-Coruja</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 293</span></td><td style="text-align:center;"><strong>ND 4</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +6<br>Perc +8</td><td style="text-align:center;"><strong>Def 23</strong><br><span style="font-size:11px;">PV 145 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +16<br>Ref +10 | Von +5</td><td style="font-size:11.5px;"><strong>+16</strong> (Dano méd: 27 | CD 18)<br>Mordida +16 (1d8+7) e 2 garras +16 (1d6+6)</td><td style="font-size:11px;">Faro, visão no escuro; Agarrar Aprimorado (livre na garra, teste +18); Abraço Esmagador (2d6+10 impacto se acertar as 2 garras)<br><em style="color:#94A3B8;">For 7, Des 3, Con 5, Int -4, Sab 1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_043')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Puristas" data-busca="capelão de guerra puristas humanoide (humano) médio coragem total (imune a medo); sangue de ferro (+2 dano e rd 5); magias divinas (oração, soco de arsenal 4d6+5, curar ferimentos, cd 20)"><td><strong>CAP7_044</strong><br><span class="tag">Puristas</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Capelão de Guerra</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 295</span></td><td style="text-align:center;"><strong>ND 4</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +6<br>Perc +10</td><td style="text-align:center;"><strong>Def 21</strong><br><span style="font-size:11px;">PV 98 | PM 24</span></td><td style="text-align:center;font-size:11.5px;">Fort +10<br>Ref +5 | Von +16</td><td style="font-size:11.5px;"><strong>+14</strong> (Dano méd: 21 | CD 20)<br>Martelo de guerra +14 (1d8+12, x3)</td><td style="font-size:11px;">Coragem Total (imune a medo); Sangue de Ferro (+2 dano e RD 5); Magias Divinas (Oração, Soco de Arsenal 4d6+5, Curar Ferimentos, CD 20)<br><em style="color:#94A3B8;">For 4, Des 0, Con 4, Int 1, Sab 5, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_044')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Reino dos Mortos" data-busca="esqueleto de elite reino dos mortos morto-vivo médio visão no escuro; rd 5/impacto, imunidade a frio; estocada cruel (+1d8 dano no crítico); imunidades de morto-vivo"><td><strong>CAP7_045</strong><br><span class="tag">Reino dos Mortos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Esqueleto de Elite</a></strong><br><span style="font-size:11px;color:#64748B;">Morto-vivo Médio · Livro JdA p. 297</span></td><td style="text-align:center;"><strong>ND 4</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +10<br>Perc +6</td><td style="text-align:center;"><strong>Def 25</strong><br><span style="font-size:11px;">PV 36 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +4<br>Ref +10 | Von +16</td><td style="font-size:11.5px;"><strong>+18</strong> (Dano méd: 32 | CD 18)<br>Espada longa +18 (2d8+18, 19)</td><td style="font-size:11px;">Visão no escuro; RD 5/impacto, imunidade a frio; Estocada Cruel (+1d8 dano no crítico); Imunidades de Morto-vivo<br><em style="color:#94A3B8;">For 6, Des 2, Con 3, Int —, Sab 0, Car -5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_045')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="orc mutante masmorras humanoide (orc) médio visão no escuro, sensibilidade a luz; terceiro braço (livre: se acertar machado e mordida no mesmo alvo, causa +1d6+9 corte)"><td><strong>CAP7_046</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Orc Mutante</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (orc) Médio · Livro JdA p. 287</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Lacaio</span></td><td style="text-align:center;">Ini +8<br>Perc +5</td><td style="text-align:center;"><strong>Def 22</strong><br><span style="font-size:11px;">PV 55 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +15<br>Ref +11 | Von +7</td><td style="font-size:11.5px;"><strong>+20</strong> (Dano méd: 56 | CD 20)<br>Machado de guerra +20 (1d12+18, x3) e mordida +20 (1d6+18)</td><td style="font-size:11px;">Visão no escuro, sensibilidade a luz; Terceiro Braço (Livre: se acertar machado e mordida no mesmo alvo, causa +1d6+9 corte)<br><em style="color:#94A3B8;">For 6, Des 2, Con 4, Int -2, Sab -2, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_046')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Duyshidakk" data-busca="arauto de thwor duyshidakk humanoide (humano) médio fúria divina (+2 ataque/dano); prece de combate; tropas duyshidakk (acompanhado por goblins salteadores); magias divinas (cd 20)"><td><strong>CAP7_047</strong><br><span class="tag">Duyshidakk</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Arauto de Thwor</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 300</span></td><td style="text-align:center;"><strong>ND 4</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +6<br>Perc +11</td><td style="text-align:center;"><strong>Def 23</strong><br><span style="font-size:11px;">PV 98 | PM 24</span></td><td style="text-align:center;font-size:11.5px;">Fort +10<br>Ref +4 | Von +16</td><td style="font-size:11.5px;"><strong>+15</strong> (Dano méd: 24 | CD 20)<br>Machado de guerra abençoado +15 (3d6+12, x3)</td><td style="font-size:11px;">Fúria Divina (+2 ataque/dano); Prece de Combate; Tropas Duyshidakk (acompanhado por goblins salteadores); Magias Divinas (CD 20)<br><em style="color:#94A3B8;">For 3, Des 1, Con 4, Int -1, Sab 5, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_047')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Duyshidakk" data-busca="hobgoblin mago de batalha duyshidakk humanoide (hobgoblin) médio arcano de batalha (+5 dano em magias); magias 1º e 2º círculo (armadura arcana, bola de fogo, seta infalível, toque vampírico, cd 22)"><td><strong>CAP7_048</strong><br><span class="tag">Duyshidakk</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Hobgoblin Mago de Batalha</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (hobgoblin) Médio · Livro JdA p. 302</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +9<br>Perc +5</td><td style="text-align:center;"><strong>Def 22</strong><br><span style="font-size:11px;">PV 140 | PM 30</span></td><td style="text-align:center;font-size:11.5px;">Fort +15<br>Ref +11 | Von +7</td><td style="font-size:11.5px;"><strong>+15</strong> (Dano méd: 40 | CD 22)<br>Espada longa +15 (1d8+8, 19) ou Bola de Fogo (8d6+5 fogo, Ref CD 22)</td><td style="font-size:11px;">Arcano de Batalha (+5 dano em magias); Magias 1º e 2º círculo (Armadura Arcana, Bola de Fogo, Seta Infalível, Toque Vampírico, CD 22)<br><em style="color:#94A3B8;">For 3, Des 1, Con 3, Int 5, Sab 0, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_048')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Trolls Nobres" data-busca="troll trolls nobres monstro grande visão no escuro; cura acelerada 10/ácido ou fogo; dilacerar (livre: +2d6+8 se acertar as 2 garras no mesmo alvo)"><td><strong>CAP7_049</strong><br><span class="tag">Trolls Nobres</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Troll</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 309</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +5<br>Perc +4</td><td style="text-align:center;"><strong>Def 23</strong><br><span style="font-size:11px;">PV 180 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +14<br>Ref +10 | Von +6</td><td style="font-size:11.5px;"><strong>+17</strong> (Dano méd: 40 | CD 20)<br>Mordida +17 (1d8+8) e 2 garras +17 (1d6+8) + Dilacerar (2d6+8)</td><td style="font-size:11px;">Visão no escuro; Cura Acelerada 10/ácido ou fogo; Dilacerar (Livre: +2d6+8 se acertar as 2 garras no mesmo alvo)<br><em style="color:#94A3B8;">For 6, Des 2, Con 5, Int -2, Sab -1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_049')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Trolls Nobres" data-busca="troll ghillanin (variante subterrânea) trolls nobres monstro grande pele dura (+2 defesa); cura acelerada 10/ácido ou fogo; sensibilidade a luz (ofuscado e perde regeneração sob sol)"><td><strong>CAP7_050</strong><br><span class="tag">Trolls Nobres</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Troll Ghillanin (Variante Subterrânea)</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 309</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +5<br>Perc +4</td><td style="text-align:center;"><strong>Def 25</strong><br><span style="font-size:11px;">PV 180 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +14<br>Ref +10 | Von +6</td><td style="font-size:11.5px;"><strong>+17</strong> (Dano méd: 40 | CD 20)<br>Mordida +17 (1d8+8) e 2 garras +17 (1d6+8) + Dilacerar (2d6+8)</td><td style="font-size:11px;">Pele Dura (+2 Defesa); Cura Acelerada 10/ácido ou fogo; Sensibilidade a Luz (ofuscado e perde regeneração sob sol)<br><em style="color:#94A3B8;">For 6, Des 2, Con 5, Int -2, Sab -1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_050')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Trolls Nobres" data-busca="troll glacioll (variante do gelo) trolls nobres monstro grande imunidade a frio, vulnerabilidade a fogo; absorver frio (recebe pv temp igual ao dano de frio e +2 ataque/dano)"><td><strong>CAP7_051</strong><br><span class="tag">Trolls Nobres</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Troll Glacioll (Variante do Gelo)</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 309</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +5<br>Perc +4</td><td style="text-align:center;"><strong>Def 23</strong><br><span style="font-size:11px;">PV 180 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +14<br>Ref +10 | Von +6</td><td style="font-size:11.5px;"><strong>+17</strong> (Dano méd: 40 | CD 20)<br>Mordida +17 (1d8+8) e 2 garras +17 (1d6+8) + Dilacerar (2d6+8)</td><td style="font-size:11px;">Imunidade a frio, vulnerabilidade a fogo; Absorver Frio (recebe PV temp igual ao dano de frio e +2 ataque/dano)<br><em style="color:#94A3B8;">For 6, Des 2, Con 5, Int -2, Sab -1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_051')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Trolls Nobres" data-busca="troll vrakoll (variante aquática) trolls nobres monstro grande aquático (respira n'água e natação 12m; -2 ataque fora d'água); cura acelerada 10/ácido ou fogo"><td><strong>CAP7_052</strong><br><span class="tag">Trolls Nobres</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Troll Vrakoll (Variante Aquática)</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 309</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +5<br>Perc +4</td><td style="text-align:center;"><strong>Def 23</strong><br><span style="font-size:11px;">PV 180 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +14<br>Ref +10 | Von +6</td><td style="font-size:11.5px;"><strong>+17</strong> (Dano méd: 40 | CD 20)<br>Mordida +17 (1d8+8) e 2 garras +17 (1d6+8) + Dilacerar (2d6+8)</td><td style="font-size:11px;">Aquático (respira n'água e natação 12m; -2 ataque fora d'água); Cura Acelerada 10/ácido ou fogo<br><em style="color:#94A3B8;">For 6, Des 2, Con 5, Int -2, Sab -1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_052')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Ermos" data-busca="serpe (wyvern) ermos monstro grande visão no escuro, imunidade a paralisia; agarrar aprimorado (mordida, teste +19); veneno (perde 2d12 pv por 1d4 rodadas, fort cd 20 reduz)"><td><strong>CAP7_053</strong><br><span class="tag">Ermos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Serpe (Wyvern)</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 293</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +6<br>Perc +9</td><td style="text-align:center;"><strong>Def 24</strong><br><span style="font-size:11px;">PV 200 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +17<br>Ref +11 | Von +5</td><td style="font-size:11.5px;"><strong>+17</strong> (Dano méd: 40 | CD 20)<br>Mordida +17 (2d6+10) e ferrão +17 (1d8+10 mais veneno 2d12)</td><td style="font-size:11px;">Visão no escuro, imunidade a paralisia; Agarrar Aprimorado (mordida, teste +19); Veneno (perde 2d12 PV por 1d4 rodadas, Fort CD 20 reduz)<br><em style="color:#94A3B8;">For 6, Des 1, Con 5, Int -2, Sab 1, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_053')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Puristas" data-busca="capitão-baluarte puristas humanoide (humano) médio formação invencível (+2 defesa p/ aliados em alcance curto); estrategista (movimento: aliados ganham +1 ação de movimento); gritar ordens (+4 perícias)"><td><strong>CAP7_054</strong><br><span class="tag">Puristas</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Capitão-Baluarte</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 295</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +10<br>Perc +7</td><td style="text-align:center;"><strong>Def 33</strong><br><span style="font-size:11px;">PV 140 | PM 15</span></td><td style="text-align:center;font-size:11.5px;">Fort +15<br>Ref +5 | Von +13</td><td style="font-size:11.5px;"><strong>+17</strong> (Dano méd: 24 | CD 22)<br>Espada longa +17 (1d8+15, 19)</td><td style="font-size:11px;">Formação Invencível (+2 Defesa p/ aliados em alcance curto); Estrategista (Movimento: aliados ganham +1 ação de movimento); Gritar Ordens (+4 perícias)<br><em style="color:#94A3B8;">For 4, Des 0, Con 3, Int 1, Sab 0, Car 4</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_054')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Reino dos Mortos" data-busca="aparição reino dos mortos morto-vivo médio incorpóreo (só sofre dano de armas/efeitos mágicos); toque drenante (fort cd 20 ou fica fraco e aparição recebe 20 pv temp); vulnerabilidade à luz solar"><td><strong>CAP7_055</strong><br><span class="tag">Reino dos Mortos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Aparição</a></strong><br><span style="font-size:11px;color:#64748B;">Morto-vivo Médio · Livro JdA p. 297</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +13<br>Perc +11</td><td style="text-align:center;"><strong>Def 23</strong><br><span style="font-size:11px;">PV 100 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +5<br>Ref +17 | Von +11</td><td style="font-size:11.5px;"><strong>+18</strong> (Dano méd: 32 | CD 20)<br>Toque drenante +18 (4d8+10 trevas mais drena 20 PV temp)</td><td style="font-size:11px;">Incorpóreo (só sofre dano de armas/efeitos mágicos); Toque Drenante (Fort CD 20 ou fica fraco e aparição recebe 20 PV temp); Vulnerabilidade à Luz Solar<br><em style="color:#94A3B8;">For —, Des 6, Con 2, Int 0, Sab 2, Car 2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_055')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Trolls Nobres" data-busca="ganchador trolls nobres monstro grande percepção às cegas, visão no escuro; dilacerar (+2d8+8); quebrar aprimorado (+20 ataque e +2d8 dano em objetos/armaduras); sensibilidade a luz"><td><strong>CAP7_056</strong><br><span class="tag">Trolls Nobres</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Ganchador</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 308</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +10<br>Perc +10</td><td style="text-align:center;"><strong>Def 26</strong><br><span style="font-size:11px;">PV 200 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +15<br>Ref +11 | Von +7</td><td style="font-size:11.5px;"><strong>+17</strong> (Dano méd: 40 | CD 20)<br>Mordida +17 (2d6+8) e 2 garras +17 (1d8+8, 19/x3) + Dilacerar (2d8+8)</td><td style="font-size:11px;">Percepção às cegas, visão no escuro; Dilacerar (+2d8+8); Quebrar Aprimorado (+20 ataque e +2d8 dano em objetos/armaduras); Sensibilidade a Luz<br><em style="color:#94A3B8;">For 6, Des 3, Con 5, Int -2, Sab 1, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_056')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Tormenta" data-busca="otyugh tormenta monstro grande rd 5; agarrar aprimorado (tentáculo, teste +19); constrição (2d6+9 impacto); doença: infecção do esgoto (fort cd 20 evita)"><td><strong>CAP7_057</strong><br><span class="tag">Tormenta</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Otyugh</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 316</span></td><td style="text-align:center;"><strong>ND 5</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +4<br>Perc +9</td><td style="text-align:center;"><strong>Def 24</strong><br><span style="font-size:11px;">PV 190 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +10<br>Ref +16 | Von +5</td><td style="font-size:11.5px;"><strong>+17</strong> (Dano méd: 40 | CD 20)<br>2 tentáculos +17 (1d8+9, alcance 4,5m) e mordida +17 (1d8+9 mais doença)</td><td style="font-size:11px;">RD 5; Agarrar Aprimorado (tentáculo, teste +19); Constrição (2d6+9 impacto); Doença: Infecção do esgoto (Fort CD 20 evita)<br><em style="color:#94A3B8;">For 5, Des -1, Con 4, Int -2, Sab 1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_057')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="mantícora masmorras monstro grande faro, visão no escuro; espinhos caudais (movimento, 3 pm: dispara 4 espinhos em alcance médio causando 1d8+7 cada, ref cd 22 reduz à metade)"><td><strong>CAP7_058</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Mantícora</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Grande · Livro JdA p. 286</span></td><td style="text-align:center;"><strong>ND 6</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +10<br>Perc +11</td><td style="text-align:center;"><strong>Def 26</strong><br><span style="font-size:11px;">PV 240 | PM 18</span></td><td style="text-align:center;font-size:11.5px;">Fort +18<br>Ref +7 | Von +12</td><td style="font-size:11.5px;"><strong>+20</strong> (Dano méd: 56 | CD 22)<br>Mordida +20 (2d8+10) e 2 garras +20 (1d8+10); Espinhos (Movimento, 3 PM: 4 espinhos de 1d8+7, Ref CD 22)</td><td style="font-size:11px;">Faro, visão no escuro; Espinhos Caudais (Movimento, 3 PM: dispara 4 espinhos em alcance médio causando 1d8+7 cada, Ref CD 22 reduz à metade)<br><em style="color:#94A3B8;">For 6, Des 2, Con 6, Int -2, Sab 1, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_058')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Duyshidakk" data-busca="engenho de guerra goblin duyshidakk construto enorme rd 10, imunidades de construto; arsenal de engenhocas (cd 22); tripulação (ao ser destruído, desembarcam 1d6 goblins salteadores)"><td><strong>CAP7_059</strong><br><span class="tag">Duyshidakk</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Engenho de Guerra Goblin</a></strong><br><span style="font-size:11px;color:#64748B;">Construto Enorme · Livro JdA p. 301</span></td><td style="text-align:center;"><strong>ND 6</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +6<br>Perc +10</td><td style="text-align:center;"><strong>Def 25</strong><br><span style="font-size:11px;">PV 240 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +18<br>Ref +6 | Von +12</td><td style="font-size:11.5px;"><strong>+20</strong> (Dano méd: 56 | CD 22)<br>Arsenal de Engenhocas (Padrão: Canhão 8d8 elét, Balestra 8d6 ácido, Foles 6d6 fogo e Lâmina +20 4d8+16, CD 22)</td><td style="font-size:11px;">RD 10, Imunidades de Construto; Arsenal de Engenhocas (CD 22); Tripulação (ao ser destruído, desembarcam 1d6 goblins salteadores)<br><em style="color:#94A3B8;">For 9, Des 0, Con 6, Int —, Sab 0, Car -5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_059')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Cultistas da Traição" data-busca="nagah mística cultistas da traição monstro (nagah) médio magia acelerada (+4 pm); magias até 3º círculo (armadura arcana, imagem espelhada, relâmpago, transformação de guerra, cd 24)"><td><strong>CAP7_060</strong><br><span class="tag">Cultistas da Traição</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Nagah Mística</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (nagah) Médio · Livro JdA p. 306</span></td><td style="text-align:center;"><strong>ND 6</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +12<br>Perc +9</td><td style="text-align:center;"><strong>Def 20</strong><br><span style="font-size:11px;">PV 168 | PM 42</span></td><td style="text-align:center;font-size:11.5px;">Fort +6<br>Ref +12 | Von +18</td><td style="font-size:11.5px;"><strong>+18</strong> (Dano méd: 56 | CD 24)<br>Espada curta +18 (1d6+8, 19) e cauda +18 (1d6+8) + Magias Aceleradas (Relâmpago 8d6, Velocidade)</td><td style="font-size:11px;">Magia Acelerada (+4 PM); Magias até 3º círculo (Armadura Arcana, Imagem Espelhada, Relâmpago, Transformação de Guerra, CD 24)<br><em style="color:#94A3B8;">For 0, Des 3, Con 4, Int 5, Sab 2, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_060')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Trolls Nobres" data-busca="finntroll feitor trolls nobres monstro (finntroll) médio natureza vegetal, resistência a magia +2; açoitar escravos (movimento: aliados ganham ação mov e +2 atq/dano); magias até 2º círculo (cd 24)"><td><strong>CAP7_061</strong><br><span class="tag">Trolls Nobres</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Finntroll Feitor</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (finntroll) Médio · Livro JdA p. 308</span></td><td style="text-align:center;"><strong>ND 6</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +11<br>Perc +8</td><td style="text-align:center;"><strong>Def 20</strong><br><span style="font-size:11px;">PV 168 | PM 36</span></td><td style="text-align:center;font-size:11.5px;">Fort +8<br>Ref +12 | Von +16</td><td style="font-size:11.5px;"><strong>+18</strong> (Dano méd: 48 | CD 24)<br>Chicote +18 (1d4+12, alcance 4,5m) e espada curta +18 (1d6+12, 19)</td><td style="font-size:11px;">Natureza Vegetal, resistência a magia +2; Açoitar Escravos (Movimento: aliados ganham ação mov e +2 atq/dano); Magias até 2º círculo (CD 24)<br><em style="color:#94A3B8;">For 0, Des 4, Con 4, Int 5, Sab 0, Car 1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_061')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Tormenta" data-busca="geraktril tormenta monstro (lefeu) grande rd 10, imunidades lefeu; insanidade da tormenta 2d4 pm (von cd 22); percepção temporal (+3 ataque, defesa e reflexos) e visão ampla"><td><strong>CAP7_062</strong><br><span class="tag">Tormenta</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Geraktril</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (lefeu) Grande · Livro JdA p. 314</span></td><td style="text-align:center;"><strong>ND 6</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +13<br>Perc +16</td><td style="text-align:center;"><strong>Def 30</strong><br><span style="font-size:11px;">PV 230 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +18<br>Ref +15 | Von +6</td><td style="font-size:11.5px;"><strong>+22</strong> (Dano méd: 56 | CD 22)<br>2 pinças +22 (3d6+10, 19) e garra +22 (1d8+10)</td><td style="font-size:11px;">RD 10, Imunidades Lefeu; Insanidade da Tormenta 2d4 PM (Von CD 22); Percepção Temporal (+3 Ataque, Defesa e Reflexos) e Visão Ampla<br><em style="color:#94A3B8;">For 7, Des 5, Con 4, Int 1, Sab 3, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_062')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="centopeia-dragão masmorras monstro enorme agarrar aprimorado (mordida, teste +29); aura de calor (4d6+9 fogo no início do turno); engolir (2d8+12 impacto + 4d6+9 fogo, cd 24)"><td><strong>CAP7_063</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Centopeia-Dragão</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Enorme · Livro JdA p. 284</span></td><td style="text-align:center;"><strong>ND 7</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +9<br>Perc +11</td><td style="text-align:center;"><strong>Def 27</strong><br><span style="font-size:11px;">PV 280 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +20<br>Ref +14 | Von +9</td><td style="font-size:11.5px;"><strong>+24</strong> (Dano méd: 62 | CD 24)<br>Mordida +24 (3d8+16 mais 2d6 fogo) + Aura de Calor (4d6+9 fogo automático em alcance curto)</td><td style="font-size:11px;">Agarrar Aprimorado (mordida, teste +29); Aura de Calor (4d6+9 fogo no início do turno); Engolir (2d8+12 impacto + 4d6+9 fogo, CD 24)<br><em style="color:#94A3B8;">For 10, Des 3, Con 8, Int -4, Sab 1, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_063')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Reino dos Mortos" data-busca="necromante reino dos mortos humanoide (elfo) médio mestre em necromancia (+2 cd); guardas esqueletos (acompanhado por 2 esqueletos de elite); magia acelerada; magias até 4º círculo (cd 26)"><td><strong>CAP7_064</strong><br><span class="tag">Reino dos Mortos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Necromante</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (elfo) Médio · Livro JdA p. 298</span></td><td style="text-align:center;"><strong>ND 7</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +12<br>Perc +10</td><td style="text-align:center;"><strong>Def 23</strong><br><span style="font-size:11px;">PV 168 | PM 50</span></td><td style="text-align:center;font-size:11.5px;">Fort +7<br>Ref +14 | Von +20</td><td style="font-size:11.5px;"><strong>+18</strong> (Dano méd: 62 | CD 26)<br>Adaga +18 (1d4+6, 19) + Magias de 4º Círculo (Ferver Sangue, Assassino Fantasmagórico, Toque Vampírico)</td><td style="font-size:11px;">Mestre em Necromancia (+2 CD); Guardas Esqueletos (acompanhado por 2 esqueletos de elite); Magia Acelerada; Magias até 4º círculo (CD 26)<br><em style="color:#94A3B8;">For 0, Des 2, Con 2, Int 6, Sab 0, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_064')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Cultistas da Traição" data-busca="cultista de sszzaas cultistas da traição monstro (medusa) médio olhar atordoante (movimento: fort cd 26 ou atordoado 1 rodada); veneno 2d12 por 2d4 rodadas (fort cd 26); magias divinas até 3º círculo (cd 26)"><td><strong>CAP7_065</strong><br><span class="tag">Cultistas da Traição</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Cultista de Sszzaas</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (medusa) Médio · Livro JdA p. 305</span></td><td style="text-align:center;"><strong>ND 7</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +15<br>Perc +16</td><td style="text-align:center;"><strong>Def 29</strong><br><span style="font-size:11px;">PV 196 | PM 42</span></td><td style="text-align:center;font-size:11.5px;">Fort +7<br>Ref +14 | Von +20</td><td style="font-size:11.5px;"><strong>+22</strong> (Dano méd: 62 | CD 26)<br>Adaga +22 (1d4+8 mais veneno 2d12, 19) + Ataque Furtivo (+5d6)</td><td style="font-size:11px;">Olhar Atordoante (Movimento: Fort CD 26 ou atordoado 1 rodada); Veneno 2d12 por 2d4 rodadas (Fort CD 26); Magias Divinas até 3º círculo (CD 26)<br><em style="color:#94A3B8;">For -1, Des 4, Con 1, Int 4, Sab 5, Car 5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_065')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Dragões" data-busca="dragão jovem dragões monstro (dragão) grande rd 5, resistência a magia +2, imune a fogo, vulnerável a frio; sopro 8d12 fogo (ref cd 24); trespassar; voo pairado"><td><strong>CAP7_066</strong><br><span class="tag">Dragões</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Dragão Jovem</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (dragão) Grande · Livro JdA p. 310</span></td><td style="text-align:center;"><strong>ND 7</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +10<br>Perc +12</td><td style="text-align:center;"><strong>Def 32</strong><br><span style="font-size:11px;">PV 280 | PM 21</span></td><td style="text-align:center;font-size:11.5px;">Fort +20<br>Ref +9 | Von +12</td><td style="font-size:11.5px;"><strong>+24</strong> (Dano méd: 62 | CD 24)<br>Mordida +24 (2d8+12, 19) e 2 garras +24 (1d8+10, 19); Sopro (Padrão: cone 9m, 8d12 fogo, Ref CD 24, recarga mov)</td><td style="font-size:11px;">RD 5, resistência a magia +2, imune a fogo, vulnerável a frio; Sopro 8d12 fogo (Ref CD 24); Trespassar; Voo Pairado<br><em style="color:#94A3B8;">For 7, Des 2, Con 6, Int 2, Sab 2, Car 2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_066')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Reino dos Mortos" data-busca="falange reino dos mortos morto-vivo (bando) médio rd 5/impacto; bando (dobro do dano se exceder def por 10+; metade se errar; +50% dano de área); muro de escudos (+4 defesa)"><td><strong>CAP7_067</strong><br><span class="tag">Reino dos Mortos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Falange</a></strong><br><span style="font-size:11px;color:#64748B;">Morto-vivo (bando) Médio · Livro JdA p. 297</span></td><td style="text-align:center;"><strong>ND 8</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +12<br>Perc +8</td><td style="text-align:center;"><strong>Def 25</strong><br><span style="font-size:11px;">PV 360 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +6<br>Ref +12 | Von +18</td><td style="font-size:11.5px;"><strong>+28</strong> (Dano méd: 68 | CD 26)<br>[Bando] Espada longa +28 (4d8+32, 19)</td><td style="font-size:11px;">RD 5/impacto; Bando (dobro do dano se exceder Def por 10+; metade se errar; +50% dano de área); Muro de Escudos (+4 Defesa)<br><em style="color:#94A3B8;">For 6, Des 1, Con 3, Int —, Sab 0, Car -5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_067')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Duyshidakk" data-busca="devorador de medos duyshidakk humanoide (bugbear) médio apavorar (movimento, 2 pm: intimidação +22 vs vontade ou apavorado); desprezo pelo medo (sofre metade do dano de alvos abalados/apavorados)"><td><strong>CAP7_068</strong><br><span class="tag">Duyshidakk</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Devorador de Medos</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (bugbear) Médio · Livro JdA p. 300</span></td><td style="text-align:center;"><strong>ND 8</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +10<br>Perc +8</td><td style="text-align:center;"><strong>Def 31</strong><br><span style="font-size:11px;">PV 224 | PM 24</span></td><td style="text-align:center;font-size:11.5px;">Fort +21<br>Ref +15 | Von +8</td><td style="font-size:11.5px;"><strong>+24</strong> (Dano méd: 68 | CD 28)<br>Machado de guerra +24 (3d12+24, x3)</td><td style="font-size:11px;">Apavorar (Movimento, 2 PM: Intimidação +22 vs Vontade ou apavorado); Desprezo pelo Medo (sofre metade do dano de alvos abalados/apavorados)<br><em style="color:#94A3B8;">For 6, Des 3, Con 3, Int 0, Sab 1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_068')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Tormenta" data-busca="reishid tormenta monstro (lefeu) médio rd 10, imunidades lefeu; ataque em movimento; ataque reflexo; sombra rubra (2d20 iniciativa/furtividade); veneno paralisia (fort cd 26); insanidade 2d6 pm"><td><strong>CAP7_069</strong><br><span class="tag">Tormenta</span></td><td><strong><a href="https://pt.scribd.com/document/971020277/T20-Ameac-as-de-Arton-1" target="_blank" style="color:var(--t20-ruby);">Reishid</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (lefeu) Médio · Livro JdA p. 315</span></td><td style="text-align:center;"><strong>ND 8</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +17<br>Perc +19</td><td style="text-align:center;"><strong>Def 37</strong><br><span style="font-size:11px;">PV 295 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +19<br>Ref +21 | Von +10</td><td style="font-size:11.5px;"><strong>+30</strong> (Dano méd: 68 | CD 26)<br>Adaga da Tormenta +30 (1d4+18 mais 1d8 trevas, 19), garra +30 (1d6+18) e mordida +30 (1d6+18 mais veneno)</td><td style="font-size:11px;">RD 10, Imunidades Lefeu; Ataque em Movimento; Ataque Reflexo; Sombra Rubra (2d20 Iniciativa/Furtividade); Veneno Paralisia (Fort CD 26); Insanidade 2d6 PM<br><em style="color:#94A3B8;">For 4, Des 7, Con 4, Int 4, Sab 4, Car 1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_069')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Puristas" data-busca="cavaleiro do leopardo sangrento puristas humanoide (humano) médio cavaleiro místico (lança magia como ação livre ao acertar ataque); magia acelerada; magias até 3º círculo (cd 28); ódio puro"><td><strong>CAP7_070</strong><br><span class="tag">Puristas</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Cavaleiro do Leopardo Sangrento</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 295</span></td><td style="text-align:center;"><strong>ND 9</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +14<br>Perc +13</td><td style="text-align:center;"><strong>Def 36</strong><br><span style="font-size:11px;">PV 360 | PM 54</span></td><td style="text-align:center;font-size:11.5px;">Fort +21<br>Ref +11 | Von +17</td><td style="font-size:11.5px;"><strong>+27</strong> (Dano méd: 74 | CD 28)<br>Espada bastarda +27 (3d8+22, 19) + Cavaleiro Místico (Relâmpago / Toque Chocante livre)</td><td style="font-size:11px;">Cavaleiro Místico (lança magia como ação livre ao acertar ataque); Magia Acelerada; Magias até 3º círculo (CD 28); Ódio Puro<br><em style="color:#94A3B8;">For 6, Des 1, Con 6, Int 4, Sab 0, Car 1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_070')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Duyshidakk" data-busca="sombra de thwor duyshidakk humanoide (hobgoblin) médio assassinar (movimento, 3 pm: dobra dados de ataque furtivo); evasão aprimorada; olhos nas costas; rolamento defensivo (reação: metade dano)"><td><strong>CAP7_071</strong><br><span class="tag">Duyshidakk</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Sombra de Thwor</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (hobgoblin) Médio · Livro JdA p. 303</span></td><td style="text-align:center;"><strong>ND 9</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +17<br>Perc +11</td><td style="text-align:center;"><strong>Def 33</strong><br><span style="font-size:11px;">PV 320 | PM 27</span></td><td style="text-align:center;font-size:11.5px;">Fort +15<br>Ref +21 | Von +9</td><td style="font-size:11.5px;"><strong>+27</strong> (Dano méd: 74 | CD 28)<br>2 machadinhas +27 (1d8+12, x3) + Ataque Furtivo (+7d6, ou +14d6 com Assassinar)</td><td style="font-size:11px;">Assassinar (Movimento, 3 PM: dobra dados de Ataque Furtivo); Evasão Aprimorada; Olhos nas Costas; Rolamento Defensivo (Reação: metade dano)<br><em style="color:#94A3B8;">For 2, Des 7, Con 5, Int 1, Sab 1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_071')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Trolls Nobres" data-busca="troll das cavernas trolls nobres monstro enorme cura acelerada 20/ácido ou fogo; golpe avassalador (arremessa 1d6x1,5m e derruba, fort cd 28 evita); varrer (ataque extra ao derrubar)"><td><strong>CAP7_072</strong><br><span class="tag">Trolls Nobres</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Troll das Cavernas</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Enorme · Livro JdA p. 309</span></td><td style="text-align:center;"><strong>ND 9</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +7<br>Perc +12</td><td style="text-align:center;"><strong>Def 29</strong><br><span style="font-size:11px;">PV 400 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +21<br>Ref +15 | Von +9</td><td style="font-size:11.5px;"><strong>+27</strong> (Dano méd: 74 | CD 28)<br>Tacape +27 (4d8+28) e mordida +27 (2d8+18)</td><td style="font-size:11px;">Cura Acelerada 20/ácido ou fogo; Golpe Avassalador (arremessa 1d6x1,5m e derruba, Fort CD 28 evita); Varrer (ataque extra ao derrubar)<br><em style="color:#94A3B8;">For 10, Des 0, Con 11, Int -2, Sab -1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_072')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Masmorras" data-busca="golem de ferro masmorras construto grande rd 15/adamante; imunidade a magia (eletricidade deixa lento; fogo cura 1 pv para cada 3 de dano); sopro venenoso (8d12, cd 30)"><td><strong>CAP7_073</strong><br><span class="tag">Masmorras</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Golem de Ferro</a></strong><br><span style="font-size:11px;color:#64748B;">Construto Grande · Livro JdA p. 285</span></td><td style="text-align:center;"><strong>ND 10</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +9<br>Perc +10</td><td style="text-align:center;"><strong>Def 36</strong><br><span style="font-size:11px;">PV 400 | PM 30</span></td><td style="text-align:center;font-size:11.5px;">Fort +24<br>Ref +14 | Von +11</td><td style="font-size:11.5px;"><strong>+29</strong> (Dano méd: 80 | CD 30)<br>2 pancadas +29 (4d10+18); Sopro de Gás Venenoso (Movimento: cubo 6m, 8d12 veneno + enjoado, Fort CD 30)</td><td style="font-size:11px;">RD 15/adamante; Imunidade a Magia (eletricidade deixa lento; fogo cura 1 PV para cada 3 de dano); Sopro Venenoso (8d12, CD 30)<br><em style="color:#94A3B8;">For 12, Des -1, Con 10, Int —, Sab 0, Car -5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_073')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Dragões" data-busca="tirano do terceiro dragões humanoide (humano) médio rd 5; ira dracônica (livre: +4 defesa, +4 dano e +4 cd até o fim da cena); magias até 3º círculo (cd 30)"><td><strong>CAP7_074</strong><br><span class="tag">Dragões</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Tirano do Terceiro</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 313</span></td><td style="text-align:center;"><strong>ND 10</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +14<br>Perc +11</td><td style="text-align:center;"><strong>Def 37</strong><br><span style="font-size:11px;">PV 380 | PM 50</span></td><td style="text-align:center;font-size:11.5px;">Fort +22<br>Ref +10 | Von +16</td><td style="font-size:11.5px;"><strong>+29</strong> (Dano méd: 80 | CD 30)<br>Machado de batalha +29 (2d10+20, x3) e garra +29 (2d6+16) + Magias (Lança Ígnea de Aleph 8d6)</td><td style="font-size:11px;">RD 5; Ira Dracônica (Livre: +4 Defesa, +4 dano e +4 CD até o fim da cena); Magias até 3º círculo (CD 30)<br><em style="color:#94A3B8;">For 7, Des 0, Con 7, Int 2, Sab 1, Car 4</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_074')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Tormenta" data-busca="sacerdote de aharadak tormenta humanoide (humano) médio resistência elemental 10, +5 vs magias divinas; percepção temporal (+6 atq/def/ref); sangue ácido (10 dano ácido); magia acelerada (cd 32)"><td><strong>CAP7_075</strong><br><span class="tag">Tormenta</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Sacerdote de Aharadak</a></strong><br><span style="font-size:11px;color:#64748B;">Humanoide (humano) Médio · Livro JdA p. 316</span></td><td style="text-align:center;"><strong>ND 10</strong><br><span style="font-size:11px;">Especial</span></td><td style="text-align:center;">Ini +16<br>Perc +20</td><td style="text-align:center;"><strong>Def 38</strong><br><span style="font-size:11px;">PV 280 | PM 60</span></td><td style="text-align:center;font-size:11.5px;">Fort +16<br>Ref +10 | Von +22</td><td style="font-size:11.5px;"><strong>+27</strong> (Dano méd: 80 | CD 32)<br>2 correntes de espinhos macabras +27 (4d6+16) e mordida +27 (1d6+10)</td><td style="font-size:11px;">Resistência elemental 10, +5 vs magias divinas; Percepção Temporal (+6 Atq/Def/Ref); Sangue Ácido (10 dano ácido); Magia Acelerada (CD 32)<br><em style="color:#94A3B8;">For 4, Des 2, Con 5, Int 2, Sab 6, Car 0</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_075')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Cultistas da Traição" data-busca="hidra cultistas da traição monstro enorme cura acelerada 50/ácido ou fogo; cortar cabeças (ataque na cabeça com -2 e 25+ dano de corte decepa; nascem 2 cabeças em 1d4 rodadas salvo fogo/ácido)"><td><strong>CAP7_076</strong><br><span class="tag">Cultistas da Traição</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Hidra</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro Enorme · Livro JdA p. 305</span></td><td style="text-align:center;"><strong>ND 11</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +9<br>Perc +15</td><td style="text-align:center;"><strong>Def 35</strong><br><span style="font-size:11px;">PV 580 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +24<br>Ref +18 | Von +9</td><td style="font-size:11.5px;"><strong>+34</strong> (Dano méd: 130 | CD 31)<br>5 mordidas +34 (2d8+17)</td><td style="font-size:11px;">Cura Acelerada 50/ácido ou fogo; Cortar Cabeças (ataque na cabeça com -2 e 25+ dano de corte decepa; nascem 2 cabeças em 1d4 rodadas salvo fogo/ácido)<br><em style="color:#94A3B8;">For 10, Des 0, Con 11, Int -4, Sab 0, Car -1</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_076')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Dragões" data-busca="dragão adulto dragões monstro (dragão) enorme rd 10, resistência a magia +3, imune a fogo; aura aterradora (alcance médio, von cd 31); magias até 3º círculo (cd 31); varrer"><td><strong>CAP7_077</strong><br><span class="tag">Dragões</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Dragão Adulto</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (dragão) Enorme · Livro JdA p. 311</span></td><td style="text-align:center;"><strong>ND 11</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +13<br>Perc +18</td><td style="text-align:center;"><strong>Def 42</strong><br><span style="font-size:11px;">PV 550 | PM 33</span></td><td style="text-align:center;font-size:11.5px;">Fort +24<br>Ref +11 | Von +18</td><td style="font-size:11.5px;"><strong>+34</strong> (Dano méd: 130 | CD 31)<br>Mordida +34 (4d8+22, 18) e 2 garras +34 (3d8+20, 18); Sopro (Padrão: cone 12m, 12d12 fogo, Ref CD 31, recarga mov)</td><td style="font-size:11px;">RD 10, resistência a magia +3, imune a fogo; Aura Aterradora (alcance médio, Von CD 31); Magias até 3º círculo (CD 31); Varrer<br><em style="color:#94A3B8;">For 11, Des 1, Con 8, Int 4, Sab 4, Car 3</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_077')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Reino dos Mortos" data-busca="vampiro reino dos mortos morto-vivo médio cura acelerada 20/luz, rd 10/prata ou luz; presença majestosa (von cd 33 ou não pode atacar o vampiro); magias até 4º círculo (cd 33)"><td><strong>CAP7_078</strong><br><span class="tag">Reino dos Mortos</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Vampiro</a></strong><br><span style="font-size:11px;color:#64748B;">Morto-vivo Médio · Livro JdA p. 298</span></td><td style="text-align:center;"><strong>ND 12</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +20<br>Perc +18</td><td style="text-align:center;"><strong>Def 45</strong><br><span style="font-size:11px;">PV 560 | PM 67</span></td><td style="text-align:center;font-size:11.5px;">Fort +12<br>Ref +26 | Von +20</td><td style="font-size:11.5px;"><strong>+36</strong> (Dano méd: 144 | CD 33)<br>Espada longa +36 (2d8+28, 17) e 2 garras +36 (2d6+20) + Drenar Sangue (6d6 trevas e cura PV)</td><td style="font-size:11px;">Cura Acelerada 20/luz, RD 10/prata ou luz; Presença Majestosa (Von CD 33 ou não pode atacar o vampiro); Magias até 4º círculo (CD 33)<br><em style="color:#94A3B8;">For 6, Des 5, Con 6, Int 2, Sab 2, Car 7</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_078')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Cultistas da Traição" data-busca="lagash cultistas da traição animal enorme imune a veneno; agarrar aprimorado (mordida, teste +42); constrição (6d10+36); cuspe venenoso (cone 9m, 6d12 veneno + cego, fort cd 35)"><td><strong>CAP7_079</strong><br><span class="tag">Cultistas da Traição</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Lagash</a></strong><br><span style="font-size:11px;color:#64748B;">Animal Enorme · Livro JdA p. 305</span></td><td style="text-align:center;"><strong>ND 13</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +18<br>Perc +19</td><td style="text-align:center;"><strong>Def 41</strong><br><span style="font-size:11px;">PV 680 | PM 39</span></td><td style="text-align:center;font-size:11.5px;">Fort +26<br>Ref +20 | Von +13</td><td style="font-size:11.5px;"><strong>+37</strong> (Dano méd: 158 | CD 35)<br>Mordida +37 (4d10+36 mais veneno 4d12) + Constrição (6d10+36 impacto)</td><td style="font-size:11px;">Imune a veneno; Agarrar Aprimorado (mordida, teste +42); Constrição (6d10+36); Cuspe Venenoso (cone 9m, 6d12 veneno + cego, Fort CD 35)<br><em style="color:#94A3B8;">For 13, Des 4, Con 9, Int -4, Sab 1, Car -2</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_079')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Puristas" data-busca="colosso supremo puristas construto colossal cura acelerada 20 (goblins consertadores), rd 15, resistência a magia +5; balistas (+32, 6d8); fumos tóxicos (4d6 veneno em alcance curto, fort cd 38)"><td><strong>CAP7_080</strong><br><span class="tag">Puristas</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Colosso Supremo</a></strong><br><span style="font-size:11px;color:#64748B;">Construto Colossal · Livro JdA p. 296</span></td><td style="text-align:center;"><strong>ND 14</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +15<br>Perc +18</td><td style="text-align:center;"><strong>Def 46</strong><br><span style="font-size:11px;">PV 750 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +31<br>Ref +19 | Von +20</td><td style="font-size:11.5px;"><strong>+39</strong> (Dano méd: 172 | CD 38)<br>Espada titânica x2 +39 (4d12+46, 19) + Jato de Chamas (Movimento: cone 9m, 10d8+20 fogo, Ref CD 38)</td><td style="font-size:11px;">Cura Acelerada 20 (Goblins Consertadores), RD 15, resistência a magia +5; Balistas (+32, 6d8); Fumos Tóxicos (4d6 veneno em alcance curto, Fort CD 38)<br><em style="color:#94A3B8;">For 15, Des -1, Con 10, Int —, Sab 0, Car -5</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_080')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Dragões" data-busca="dragão venerável dragões monstro (dragão) enorme rd 15, resistência a magia +5, imune a fogo; aura aterradora (von cd 40); magia acelerada; magias até 4º círculo (cd 40)"><td><strong>CAP7_081</strong><br><span class="tag">Dragões</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Dragão Venerável</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (dragão) Enorme · Livro JdA p. 311</span></td><td style="text-align:center;"><strong>ND 15</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +16<br>Perc +23</td><td style="text-align:center;"><strong>Def 52</strong><br><span style="font-size:11px;">PV 780 | PM 60</span></td><td style="text-align:center;font-size:11.5px;">Fort +28<br>Ref +15 | Von +22</td><td style="font-size:11.5px;"><strong>+43</strong> (Dano méd: 186 | CD 40)<br>Mordida +43 (6d8+35, 17) e 2 garras +43 (4d8+30, 17); Sopro (Padrão: cone 15m, 16d12 fogo, Ref CD 40, recarga mov)</td><td style="font-size:11px;">RD 15, resistência a magia +5, imune a fogo; Aura Aterradora (Von CD 40); Magia Acelerada; Magias até 4º círculo (CD 40)<br><em style="color:#94A3B8;">For 15, Des 0, Con 11, Int 6, Sab 7, Car 6</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_081')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Tormenta" data-busca="thuwarokk tormenta monstro (lefeu) colossal rd 15, carapaça suprema (metade dano físico e +10 resistência a magia, reflete magias se passar no teste); passar por cima (10d8+30, ref cd 42)"><td><strong>CAP7_082</strong><br><span class="tag">Tormenta</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Thuwarokk</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (lefeu) Colossal · Livro JdA p. 315</span></td><td style="text-align:center;"><strong>ND 16</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +13<br>Perc +19</td><td style="text-align:center;"><strong>Def 50</strong><br><span style="font-size:11px;">PV 850 | PM 0</span></td><td style="text-align:center;font-size:11.5px;">Fort +30<br>Ref +24 | Von +16</td><td style="font-size:11.5px;"><strong>+46</strong> (Dano méd: 200 | CD 42)<br>4 pancadas +46 (4d8+32) + Jato de Ácido (Movimento: linha 18m, 12d8+20 ácido, Ref CD 42)</td><td style="font-size:11px;">RD 15, Carapaça Suprema (metade dano físico e +10 resistência a magia, reflete magias se passar no teste); Passar por Cima (10d8+30, Ref CD 42)<br><em style="color:#94A3B8;">For 16, Des -2, Con 11, Int -3, Sab -1, Car -4</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_082')">Desafiar</button></td></tr><tr class="row-cap7" data-grupo="Dragões" data-busca="dragão-rei (sckhar / ancião) dragões monstro (dragão) colossal rd 20, resistência a magia +5, maior que a morte, imune a fogo; durão (metade do dano); magia acelerada; magias 5º círculo (chuva de meteoros, cd 49)"><td><strong>CAP7_083</strong><br><span class="tag">Dragões</span></td><td><strong><a href="https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano" target="_blank" style="color:var(--t20-ruby);">Dragão-Rei (Sckhar / Ancião)</a></strong><br><span style="font-size:11px;color:#64748B;">Monstro (dragão) Colossal · Livro JdA p. 312</span></td><td style="text-align:center;"><strong>ND 20</strong><br><span style="font-size:11px;">Solo</span></td><td style="text-align:center;">Ini +21<br>Perc +29</td><td style="text-align:center;"><strong>Def 62</strong><br><span style="font-size:11px;">PV 1250 | PM 100</span></td><td style="text-align:center;font-size:11.5px;">Fort +34<br>Ref +20 | Von +28</td><td style="font-size:11.5px;"><strong>+54</strong> (Dano méd: 324 | CD 49)<br>Mordida +54 (8d10+64, 16) e 2 garras +54 (6d8+50, 16); Sopro (Padrão: cone 18m, 24d12 fogo, Ref CD 49, recarga mov)</td><td style="font-size:11px;">RD 20, resistência a magia +5, Maior que a Morte, imune a fogo; Durão (metade do dano); Magia Acelerada; Magias 5º círculo (Chuva de Meteoros, CD 49)<br><em style="color:#94A3B8;">For 18, Des 0, Con 14, Int 8, Sab 9, Car 8</em></td><td style="text-align:center;"><button type="button" class="btn btn-ai" style="padding:4px 8px;font-size:11px;width:auto;" onclick="desafiarCriaturaCap7NaArena('CAP7_083')">Desafiar</button></td></tr>
</tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <!-- ABA 5: CHAT DE IA INTEGRADO (CONSULTOR DE REGRAS & EDITOR DE FICHA EM LINGUAGEM NATURAL) -->
    <section id="tab-chat" class="tab-section {'active' if aba_ativa == 'tab-chat' else ''}">
        <div class="panel">
            <div class="panel-header">Assistente de IA Tormenta20 (Dúvidas de Score, Regras & Edição da Ficha por Comando)</div>
            <div class="panel-body">
                <div style="font-size:12.5px;color:var(--t20-muted);margin-bottom:10px;">
                    Pergunte sobre os cálculos do Score, o motivo de cada escolha da árvore, ou peça edições diretas na ficha em português (ex.: <em>"Mude para armas de haste"</em>, <em>"Troque para estilo de arma e escudo"</em>, <em>"Suba para o nível 10"</em>, <em>"Mude a raça para Anão"</em>, <em>"Adicione o poder Vitalidade"</em>, <em>"Explique o motivo de cada escolha"</em>).
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;">
                    <button type="button" class="tag" style="padding:6px 10px;cursor:pointer;border:1px solid var(--t20-ruby);" onclick="enviarComandoRapidoChat('Explique o motivo de cada score e de cada escolha da minha ficha')">Explicar Score & Escolhas</button>
                    <button type="button" class="tag" style="padding:6px 10px;cursor:pointer;border:1px solid var(--t20-ruby);" onclick="enviarComandoRapidoChat('Mude o estilo para Armas de Haste com Alabarda')">Build Armas de Haste</button>
                    <button type="button" class="tag" style="padding:6px 10px;cursor:pointer;border:1px solid var(--t20-ruby);" onclick="enviarComandoRapidoChat('Mude o estilo para Arma e Escudo')">Build Arma e Escudo</button>
                    <button type="button" class="tag" style="padding:6px 10px;cursor:pointer;border:1px solid var(--t20-ruby);" onclick="enviarComandoRapidoChat('Mude o estilo para Duas Armas com Ambidestria')">Build Duas Armas</button>
                    <button type="button" class="tag" style="padding:6px 10px;cursor:pointer;border:1px solid var(--t20-ruby);" onclick="enviarComandoRapidoChat('Mude o estilo para Uma Mão Duelista')">Build Uma Mão (Duelista)</button>
                    <button type="button" class="tag" style="padding:6px 10px;cursor:pointer;border:1px solid var(--t20-ruby);" onclick="enviarComandoRapidoChat('Mude para Feiticeiro com atributo-chave Carisma')">Build Feiticeiro (CAR)</button>
                    <button type="button" class="tag" style="padding:6px 10px;cursor:pointer;border:1px solid var(--t20-ruby);" onclick="enviarComandoRapidoChat('Mude para Bruxo com atributo-chave Inteligência')">Build Bruxo (INT)</button>
                    <button type="button" class="tag" style="padding:6px 10px;cursor:pointer;border:1px solid var(--t20-ruby);" onclick="enviarComandoRapidoChat('Mude para Clérigo Devoto Fiel com 2 Poderes Concedidos')">Clérigo Devoto Fiel (2 Concedidos)</button>
                    <button type="button" class="tag" style="padding:6px 10px;cursor:pointer;border:1px solid var(--t20-ruby);" onclick="enviarComandoRapidoChat('Mude o nível para 10')">⬆Subir para Nível 10</button>
                </div>
                <div id="chat-ia-mensagens" style="background:#090D16;border:1px solid rgba(201,155,66,0.28);border-radius:10px;height:360px;color:#F8FAFC;overflow-y:auto;padding:12px;margin-bottom:10px;font-size:13.5px;line-height:1.45;">
                    <div style="background:#191D26;border-left:3px solid #C99B42;color:#F8FAFC;padding:10px 12px;border-radius:6px;margin-bottom:10px;">
                        <strong>Assistente IA Tormenta20:</strong> Olá! Estou conectado em tempo real à sua ficha atual e ao catálogo de 1.014 registros de <em>Tormenta20 (Jogo do Ano v1.3)</em>.<br><br>
                        Você pode me perguntar <strong>"Por que você escolheu esses poderes?"</strong>, <strong>"Como o Score foi calculado?"</strong> ou mandar comandos diretos para editar sua ficha, como:<br>
                        • <code>"Mude o estilo para armas de haste"</code> / <code>"duas armas"</code> / <code>"arma e escudo"</code> / <code>"uma mão"</code><br>
                        • <code>"Mude o nível para 8"</code> ou <code>"Mude a raça para Minotauro"</code> ou <code>"Mude a classe para Paladino"</code><br>
                        • <code>"Adicione o poder Vitalidade"</code> ou <code>"Equipe a arma Alabarda"</code> ou <code>"Aprenda a magia Campo de Força"</code>
                    </div>
                </div>
                <form onsubmit="processarMensagemChatIA(event)" style="display:grid;grid-template-columns:1fr auto;gap:8px;">
                    <input type="text" id="chat-ia-input" placeholder="Digite sua pergunta ou comando de edição na ficha..." required>
                    <button type="submit" class="btn btn-ai" style="width:auto;margin:0;padding:0 18px;">Enviar </button>
                </form>
            </div>
        </div>
    </section>

    <!-- ABA 6: ARENA VISUAL DE COMBATE, ROLADOR DINÂMICO DE DADOS 3D/SVG & APRENDIZADO POR REFORÇO CAIXA-PRETA -->
    <section id="tab-arena" class="tab-section {'active' if aba_ativa == 'tab-arena' else ''}">
        <div class="arena-stage">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px;border-bottom:1px solid rgba(200,157,84,0.4);padding-bottom:10px;">
                <div>
                    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                        <h2 style="margin:0;font-size:19px;color:#E8E5DC;">ARENA VISUAL DE COMBATE &amp; APRENDIZADO CAIXA-PRETA</h2>
                        <button type="button" id="btn-arena-top-mobile-fullscreen" class="btn btn-gold" style="width:auto;margin:0;min-height:36px;padding:6px 14px;font-size:12.5px;font-weight:900;background:linear-gradient(135deg, #059669, #047857);color:#E8E5DC;border:2px solid #FACC15;box-shadow:0 4px 12px rgba(0,0,0,0.6);" onclick="alternarTelaCheiaCombateT20JS('ARENA')">
                            JOGAR EM TELA CHEIA (CELULAR / PC)
                        </button>
                    </div>
                    <div style="font-size:12px;color:#E2E8F0;margin-top:2px;">
                        A ficha da criatura fica <strong>OCULTA (Fog of War)</strong>. Tanto você quanto a IA descobrem a Defesa, Resistências e PV reais da criatura <strong>apenas através das rolagens de dados</strong>!
                    </div>
                </div>
                <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                    <select id="arena-sel-grupo-cap7" onchange="filtrarCriaturasArenaCap7JS()" style="width:auto;min-height:36px;background:#1E293B;color:#FFF;border:1px solid var(--t20-gold);font-weight:700;">
                        <option value="TODOS" selected>Cap. 7: Todos os 9 Grupos (65 Ameaças)</option>
                        <option value="Masmorras">1. Masmorras (p. 284–287 / PDF 290–293)</option>
                        <option value="Ermos">2. Ermos (p. 288–293 / PDF 294–299)</option>
                        <option value="Puristas">3. Puristas (p. 294–296 / PDF 300–302)</option>
                        <option value="Reino dos Mortos">4. Reino dos Mortos (p. 297–299 / PDF 303–305)</option>
                        <option value="Duyshidakk">5. Duyshidakk (p. 300–303 / PDF 306–309)</option>
                        <option value="Cultistas da Traição">6. Cultistas da Traição (p. 304–306 / PDF 310–312)</option>
                        <option value="Trolls Nobres">7. Trolls Nobres (p. 307–309 / PDF 313–315)</option>
                        <option value="Dragões">8. Dragões (p. 310–313 / PDF 316–319)</option>
                        <option value="Tormenta">9. Tormenta / Lefeu (p. 314–316 / PDF 320–322)</option>
                        <option value="TABELA_ND">Tabela Genérica por ND (p. 323 / PDF 329)</option>
                    </select>
                    <select id="arena-sel-criatura-cap7" onchange="aoSelecionarCriaturaCap7ArenaJS()" style="width:auto;max-width:360px;min-height:36px;background:#1E293B;color:#E8E5DC;border:1px solid var(--t20-gold);font-weight:700;">
                        <option value="AUTO">Automático pelo ND / Tabela (p. 285)</option>
                        <option value="CAP7_001" data-grupo="Masmorras" data-nd="1/4">[Masmorras · ND 1/4 · Lacaio] Glop (Def 10 · 12 PV · Atq +7)</option>
                        <option value="CAP7_002" data-grupo="Masmorras" data-nd="1/4">[Masmorras · ND 1/4 · Lacaio] Rato Gigante (Def 12 · 4 PV · Atq +7)</option>
                        <option value="CAP7_003" data-grupo="Ermos" data-nd="1/4">[Ermos · ND 1/4 · Lacaio] Bandido (Def 13 · 6 PV · Atq +7)</option>
                        <option value="CAP7_004" data-grupo="Cultistas da Traição" data-nd="1/4">[Cultistas da Traição · ND 1/4 · Lacaio] Cascavel (Def 13 · 4 PV · Atq +7)</option>
                        <option value="CAP7_005" data-grupo="Masmorras" data-nd="1/2">[Masmorras · ND 1/2 · Lacaio] Orc Combatente (Def 14 · 8 PV · Atq +9)</option>
                        <option value="CAP7_006" data-grupo="Ermos" data-nd="1/2">[Ermos · ND 1/2 · Lacaio] Guarda de Cidade (Def 15 · 8 PV · Atq +9)</option>
                        <option value="CAP7_007" data-grupo="Reino dos Mortos" data-nd="1/4">[Reino dos Mortos · ND 1/4 · Lacaio] Zumbi (Def 11 · 10 PV · Atq +6)</option>
                        <option value="CAP7_008" data-grupo="Duyshidakk" data-nd="1/4">[Duyshidakk · ND 1/4 · Lacaio] Goblin Salteador (Def 13 · 5 PV · Atq +7)</option>
                        <option value="CAP7_009" data-grupo="Ermos" data-nd="1">[Ermos · ND 1 · Lacaio] Gnoll Saqueador (Def 15 · 12 PV · Atq +11)</option>
                        <option value="CAP7_010" data-grupo="Ermos" data-nd="1/2">[Ermos · ND 1/2 · Solo] Lobo (Def 14 · 15 PV · Atq +7)</option>
                        <option value="CAP7_011" data-grupo="Puristas" data-nd="1/2">[Puristas · ND 1/2 · Lacaio] Recruta Purista (Def 16 · 8 PV · Atq +9)</option>
                        <option value="CAP7_012" data-grupo="Cultistas da Traição" data-nd="1/2">[Cultistas da Traição · ND 1/2 · Solo] Jiboia (Def 14 · 15 PV · Atq +7)</option>
                        <option value="CAP7_013" data-grupo="Ermos" data-nd="1">[Ermos · ND 1 · Solo] Chefe Bandido (Def 16 · 30 PV · Atq +9)</option>
                        <option value="CAP7_014" data-grupo="Ermos" data-nd="1">[Ermos · ND 1 · Solo] Centauro Combatente (Def 16 · 35 PV · Atq +9)</option>
                        <option value="CAP7_015" data-grupo="Ermos" data-nd="1">[Ermos · ND 1 · Solo] Gorlogg (Def 16 · 36 PV · Atq +11)</option>
                        <option value="CAP7_016" data-grupo="Ermos" data-nd="1">[Ermos · ND 1 · Solo] Sargento da Guarda (Def 17 · 32 PV · Atq +10)</option>
                        <option value="CAP7_017" data-grupo="Ermos" data-nd="1">[Ermos · ND 1 · Lacaio] Trog (Def 16 · 11 PV · Atq +11)</option>
                        <option value="CAP7_018" data-grupo="Puristas" data-nd="1">[Puristas · ND 1 · Lacaio] Soldado Purista (Def 20 · 12 PV · Atq +11)</option>
                        <option value="CAP7_019" data-grupo="Duyshidakk" data-nd="2">[Duyshidakk · ND 2 · Lacaio] Hobgoblin Soldado (Def 19 · 18 PV · Atq +14)</option>
                        <option value="CAP7_020" data-grupo="Cultistas da Traição" data-nd="1">[Cultistas da Traição · ND 1 · Solo] Naja (Def 17 · 28 PV · Atq +10)</option>
                        <option value="CAP7_021" data-grupo="Masmorras" data-nd="2">[Masmorras · ND 2 · Solo] Aranha Gigante (Def 19 · 70 PV · Atq +12)</option>
                        <option value="CAP7_022" data-grupo="Masmorras" data-nd="2">[Masmorras · ND 2 · Solo] Gárgula (Def 19 · 60 PV · Atq +12)</option>
                        <option value="CAP7_023" data-grupo="Masmorras" data-nd="2">[Masmorras · ND 2 · Solo] Orc Chefe (Def 19 · 66 PV · Atq +11)</option>
                        <option value="CAP7_024" data-grupo="Ermos" data-nd="2">[Ermos · ND 2 · Solo] Gnoll Filibusteiro (Def 19 · 65 PV · Atq +12)</option>
                        <option value="CAP7_025" data-grupo="Ermos" data-nd="2">[Ermos · ND 2 · Solo] Lobo-das-Cavernas (Def 19 · 70 PV · Atq +14)</option>
                        <option value="CAP7_026" data-grupo="Reino dos Mortos" data-nd="2">[Reino dos Mortos · ND 2 · Lacaio] Esqueleto (Def 19 · 16 PV · Atq +14)</option>
                        <option value="CAP7_027" data-grupo="Reino dos Mortos" data-nd="2">[Reino dos Mortos · ND 2 · Solo] Turba Zumbi (Def 11 · 85 PV · Atq +14)</option>
                        <option value="CAP7_028" data-grupo="Trolls Nobres" data-nd="2">[Trolls Nobres · ND 2 · Solo] Finntroll Caçador (Def 19 · 65 PV · Atq +12)</option>
                        <option value="CAP7_029" data-grupo="Dragões" data-nd="2">[Dragões · ND 2 · Solo] Enxame Kobold (Def 17 · 60 PV · Atq +12)</option>
                        <option value="CAP7_030" data-grupo="Tormenta" data-nd="2">[Tormenta · ND 2 · Solo] Maníaco Lefou (Def 18 · 75 PV · Atq +12)</option>
                        <option value="CAP7_031" data-grupo="Masmorras" data-nd="3">[Masmorras · ND 3 · Solo] Guerreiro de Chifres (Def 21 · 100 PV · Atq +15)</option>
                        <option value="CAP7_032" data-grupo="Ermos" data-nd="3">[Ermos · ND 3 · Solo] Cão do Inferno (Def 21 · 95 PV · Atq +14)</option>
                        <option value="CAP7_033" data-grupo="Ermos" data-nd="3">[Ermos · ND 3 · Especial] Centauro Xamã (Def 21 · 74 PV · Atq +12)</option>
                        <option value="CAP7_034" data-grupo="Ermos" data-nd="3">[Ermos · ND 3 · Solo] Grifo (Def 19 · 105 PV · Atq +14)</option>
                        <option value="CAP7_035" data-grupo="Puristas" data-nd="3">[Puristas · ND 3 · Solo] Sargento-mor (Def 24 · 95 PV · Atq +14)</option>
                        <option value="CAP7_036" data-grupo="Duyshidakk" data-nd="3">[Duyshidakk · ND 3 · Especial] Goblin Engenhoqueiro (Def 19 · 68 PV · Atq +12)</option>
                        <option value="CAP7_037" data-grupo="Cultistas da Traição" data-nd="3">[Cultistas da Traição · ND 3 · Solo] Sucuri (Def 19 · 110 PV · Atq +15)</option>
                        <option value="CAP7_038" data-grupo="Cultistas da Traição" data-nd="3">[Cultistas da Traição · ND 3 · Solo] Nagah Guardião (Def 21 · 105 PV · Atq +14)</option>
                        <option value="CAP7_039" data-grupo="Dragões" data-nd="3">[Dragões · ND 3 · Solo] Dragão Filhote (Def 22 · 115 PV · Atq +14)</option>
                        <option value="CAP7_040" data-grupo="Tormenta" data-nd="3">[Tormenta · ND 3 · Lacaio] Uktril (Def 22 · 32 PV · Atq +16)</option>
                        <option value="CAP7_041" data-grupo="Ermos" data-nd="4">[Ermos · ND 4 · Solo] Basilisco (Def 23 · 135 PV · Atq +16)</option>
                        <option value="CAP7_042" data-grupo="Ermos" data-nd="4">[Ermos · ND 4 · Solo] Ogro (Def 23 · 130 PV · Atq +16)</option>
                        <option value="CAP7_043" data-grupo="Ermos" data-nd="4">[Ermos · ND 4 · Solo] Urso-Coruja (Def 23 · 145 PV · Atq +16)</option>
                        <option value="CAP7_044" data-grupo="Puristas" data-nd="4">[Puristas · ND 4 · Especial] Capelão de Guerra (Def 21 · 98 PV · Atq +14)</option>
                        <option value="CAP7_045" data-grupo="Reino dos Mortos" data-nd="4">[Reino dos Mortos · ND 4 · Lacaio] Esqueleto de Elite (Def 25 · 36 PV · Atq +18)</option>
                        <option value="CAP7_046" data-grupo="Masmorras" data-nd="5">[Masmorras · ND 5 · Lacaio] Orc Mutante (Def 22 · 55 PV · Atq +20)</option>
                        <option value="CAP7_047" data-grupo="Duyshidakk" data-nd="4">[Duyshidakk · ND 4 · Especial] Arauto de Thwor (Def 23 · 98 PV · Atq +15)</option>
                        <option value="CAP7_048" data-grupo="Duyshidakk" data-nd="5">[Duyshidakk · ND 5 · Especial] Hobgoblin Mago de Batalha (Def 22 · 140 PV · Atq +15)</option>
                        <option value="CAP7_049" data-grupo="Trolls Nobres" data-nd="5">[Trolls Nobres · ND 5 · Solo] Troll (Def 23 · 180 PV · Atq +17)</option>
                        <option value="CAP7_050" data-grupo="Trolls Nobres" data-nd="5">[Trolls Nobres · ND 5 · Solo] Troll Ghillanin (Variante Subterrânea) (Def 25 · 180 PV · Atq +17)</option>
                        <option value="CAP7_051" data-grupo="Trolls Nobres" data-nd="5">[Trolls Nobres · ND 5 · Solo] Troll Glacioll (Variante do Gelo) (Def 23 · 180 PV · Atq +17)</option>
                        <option value="CAP7_052" data-grupo="Trolls Nobres" data-nd="5">[Trolls Nobres · ND 5 · Solo] Troll Vrakoll (Variante Aquática) (Def 23 · 180 PV · Atq +17)</option>
                        <option value="CAP7_053" data-grupo="Ermos" data-nd="5">[Ermos · ND 5 · Solo] Serpe (Wyvern) (Def 24 · 200 PV · Atq +17)</option>
                        <option value="CAP7_054" data-grupo="Puristas" data-nd="5">[Puristas · ND 5 · Especial] Capitão-Baluarte (Def 33 · 140 PV · Atq +17)</option>
                        <option value="CAP7_055" data-grupo="Reino dos Mortos" data-nd="5">[Reino dos Mortos · ND 5 · Solo] Aparição (Def 23 · 100 PV · Atq +18)</option>
                        <option value="CAP7_056" data-grupo="Trolls Nobres" data-nd="5">[Trolls Nobres · ND 5 · Solo] Ganchador (Def 26 · 200 PV · Atq +17)</option>
                        <option value="CAP7_057" data-grupo="Tormenta" data-nd="5">[Tormenta · ND 5 · Solo] Otyugh (Def 24 · 190 PV · Atq +17)</option>
                        <option value="CAP7_058" data-grupo="Masmorras" data-nd="6" selected>[Masmorras · ND 6 · Solo] Mantícora (Def 26 · 240 PV · Atq +20)</option>
                        <option value="CAP7_059" data-grupo="Duyshidakk" data-nd="6">[Duyshidakk · ND 6 · Solo] Engenho de Guerra Goblin (Def 25 · 240 PV · Atq +20)</option>
                        <option value="CAP7_060" data-grupo="Cultistas da Traição" data-nd="6">[Cultistas da Traição · ND 6 · Especial] Nagah Mística (Def 20 · 168 PV · Atq +18)</option>
                        <option value="CAP7_061" data-grupo="Trolls Nobres" data-nd="6">[Trolls Nobres · ND 6 · Especial] Finntroll Feitor (Def 20 · 168 PV · Atq +18)</option>
                        <option value="CAP7_062" data-grupo="Tormenta" data-nd="6">[Tormenta · ND 6 · Solo] Geraktril (Def 30 · 230 PV · Atq +22)</option>
                        <option value="CAP7_063" data-grupo="Masmorras" data-nd="7">[Masmorras · ND 7 · Solo] Centopeia-Dragão (Def 27 · 280 PV · Atq +24)</option>
                        <option value="CAP7_064" data-grupo="Reino dos Mortos" data-nd="7">[Reino dos Mortos · ND 7 · Especial] Necromante (Def 23 · 168 PV · Atq +18)</option>
                        <option value="CAP7_065" data-grupo="Cultistas da Traição" data-nd="7">[Cultistas da Traição · ND 7 · Especial] Cultista de Sszzaas (Def 29 · 196 PV · Atq +22)</option>
                        <option value="CAP7_066" data-grupo="Dragões" data-nd="7">[Dragões · ND 7 · Solo] Dragão Jovem (Def 32 · 280 PV · Atq +24)</option>
                        <option value="CAP7_067" data-grupo="Reino dos Mortos" data-nd="8">[Reino dos Mortos · ND 8 · Solo] Falange (Def 25 · 360 PV · Atq +28)</option>
                        <option value="CAP7_068" data-grupo="Duyshidakk" data-nd="8">[Duyshidakk · ND 8 · Especial] Devorador de Medos (Def 31 · 224 PV · Atq +24)</option>
                        <option value="CAP7_069" data-grupo="Tormenta" data-nd="8">[Tormenta · ND 8 · Solo] Reishid (Def 37 · 295 PV · Atq +30)</option>
                        <option value="CAP7_070" data-grupo="Puristas" data-nd="9">[Puristas · ND 9 · Solo] Cavaleiro do Leopardo Sangrento (Def 36 · 360 PV · Atq +27)</option>
                        <option value="CAP7_071" data-grupo="Duyshidakk" data-nd="9">[Duyshidakk · ND 9 · Solo] Sombra de Thwor (Def 33 · 320 PV · Atq +27)</option>
                        <option value="CAP7_072" data-grupo="Trolls Nobres" data-nd="9">[Trolls Nobres · ND 9 · Solo] Troll das Cavernas (Def 29 · 400 PV · Atq +27)</option>
                        <option value="CAP7_073" data-grupo="Masmorras" data-nd="10">[Masmorras · ND 10 · Solo] Golem de Ferro (Def 36 · 400 PV · Atq +29)</option>
                        <option value="CAP7_074" data-grupo="Dragões" data-nd="10">[Dragões · ND 10 · Solo] Tirano do Terceiro (Def 37 · 380 PV · Atq +29)</option>
                        <option value="CAP7_075" data-grupo="Tormenta" data-nd="10">[Tormenta · ND 10 · Especial] Sacerdote de Aharadak (Def 38 · 280 PV · Atq +27)</option>
                        <option value="CAP7_076" data-grupo="Cultistas da Traição" data-nd="11">[Cultistas da Traição · ND 11 · Solo] Hidra (Def 35 · 580 PV · Atq +34)</option>
                        <option value="CAP7_077" data-grupo="Dragões" data-nd="11">[Dragões · ND 11 · Solo] Dragão Adulto (Def 42 · 550 PV · Atq +34)</option>
                        <option value="CAP7_078" data-grupo="Reino dos Mortos" data-nd="12">[Reino dos Mortos · ND 12 · Solo] Vampiro (Def 45 · 560 PV · Atq +36)</option>
                        <option value="CAP7_079" data-grupo="Cultistas da Traição" data-nd="13">[Cultistas da Traição · ND 13 · Solo] Lagash (Def 41 · 680 PV · Atq +37)</option>
                        <option value="CAP7_080" data-grupo="Puristas" data-nd="14">[Puristas · ND 14 · Solo] Colosso Supremo (Def 46 · 750 PV · Atq +39)</option>
                        <option value="CAP7_081" data-grupo="Dragões" data-nd="15">[Dragões · ND 15 · Solo] Dragão Venerável (Def 52 · 780 PV · Atq +43)</option>
                        <option value="CAP7_082" data-grupo="Tormenta" data-nd="16">[Tormenta · ND 16 · Solo] Thuwarokk (Def 50 · 850 PV · Atq +46)</option>
                        <option value="CAP7_083" data-grupo="Dragões" data-nd="20">[Dragões · ND 20 · Solo] Dragão-Rei (Sckhar / Ancião) (Def 62 · 1250 PV · Atq +54)</option>
                    </select>
                    <select id="arena-sel-nd" onchange="reiniciarCombateArenaVisual()" style="width:auto;min-height:36px;background:#1E293B;color:#FFF;border:1px solid var(--t20-gold);font-weight:700;">
                        <option value="1">ND 1 (Iniciante)</option>
                        <option value="2">ND 2 (Iniciante)</option>
                        <option value="3">ND 3 (Iniciante)</option>
                        <option value="4">ND 4 (Iniciante)</option>
                        <option value="5">ND 5 (Veterano)</option>
                        <option value="6" selected>ND 6 (Veterano)</option>
                        <option value="7">ND 7 (Veterano)</option>
                        <option value="8">ND 8 (Veterano)</option>
                        <option value="9">ND 9 (Veterano)</option>
                        <option value="10">ND 10 (Veterano)</option>
                        <option value="11">ND 11 (Campeão)</option>
                        <option value="12">ND 12 (Campeão)</option>
                        <option value="13">ND 13 (Campeão)</option>
                        <option value="14">ND 14 (Campeão)</option>
                        <option value="15">ND 15 (Campeão)</option>
                        <option value="16">ND 16 (Campeão)</option>
                        <option value="20">ND 20 (Lenda)</option>
                    </select>
                    <select id="arena-sel-papel" onchange="reiniciarCombateArenaVisual()" style="width:auto;min-height:36px;background:#1E293B;color:#FFF;border:1px solid var(--t20-gold);font-weight:700;">
                        <option value="Solo" selected>Papel: Solo (Chefe Combatente)</option>
                        <option value="Lacaio">Papel: Lacaio (+Ataque/Dano, -Def/PV)</option>
                        <option value="Especial">Papel: Especial (Conjurador / CD Alta)</option>
                    </select>
                    <select id="arena-sel-qtd-criaturas" onchange="reiniciarCombateArenaVisual()" style="width:auto;min-height:36px;background:#1E293B;color:#C99B42;border:1px solid #4ADE80;font-weight:800;">
                        <option value="1" selected>1x Criatura (Duelo / Solo)</option>
                        <option value="2">2x Criaturas (Dupla Tática)</option>
                        <option value="3">3x Criaturas (Matilha / Bando)</option>
                        <option value="4">4x Criaturas (Esquadrão / Horda)</option>
                    </select>
                    <button type="button" class="btn btn-save" onclick="reiniciarCombateArenaVisual()">Novo Duelo</button>
                </div>
            </div>

            <!-- BARRA RÁPIDA DE ÁUDIO E SORTEIO VISUAL + GAVETA RETRÁTIL DO ESTÚDIO DE APARÊNCIA (SEM POLUIR A ARENA!) -->
            <div style="margin-top:8px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;background:rgba(15,23,42,0.85);border:1px solid rgba(212,175,55,0.45);border-radius:8px;padding:6px 10px;">
                <div style="font-size:12px;font-weight:800;color:#D8B465;">
                    Áudio & Visual Rápido da Arena:
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                    <button type="button" id="btn-toggle-bgm-jrpg" class="btn btn-manual" style="width:auto;min-height:30px;margin:0;padding:4px 10px;font-size:11px;background:linear-gradient(135deg, #4C1D95, #6D28D9);border:1px solid rgba(201,155,66,0.35);color:#E8E5DC;" onclick="alternarTrilhaSonoraJRPG()">
                        Trilha (BGM): ▶TOCAR
                    </button>
                    <button type="button" id="btn-toggle-som-jrpg" class="btn btn-manual" style="width:auto;min-height:30px;margin:0;padding:4px 10px;font-size:11px;background:#065F46;border:1px solid #34D399;" onclick="alternarSomArenaJRPG()">
                        Efeitos (SFX): ON
                    </button>
                    <button type="button" class="btn btn-save" style="width:auto;min-height:30px;margin:0;padding:4px 10px;font-size:11px;background:linear-gradient(135deg, #D97706, #F59E0B);color:#111827;font-weight:800;" onclick="sortearAparenciaAleatoriaRacialJS()">
                        Sortear Visual (${esc(f.raca.nome if f.raca else 'Raça')})
                    </button>
                    <button type="button" class="btn btn-manual" style="width:auto;min-height:30px;margin:0;padding:4px 10px;font-size:11px;" onclick="restaurarAparenciaPadraoRacialJS()">
                        Padrão da Raça
                    </button>
                    <select id="ap-sel-porte-rapido" onchange="mudarEscalaPortePixelArtJS(this.value)" style="width:auto;min-height:30px;padding:2px 8px;font-size:11px;background:#1E293B;color:#C99B42;border:1px solid #38BDF8;font-weight:800;">
                        <option value="PADRAO" selected>Token Pixel: Proporção Heroica 1:1</option>
                        <option value="ALTO_IMPONENTE">Token Pixel: Alto Imponente (+Altura)</option>
                        <option value="COLOSSAL">Token Pixel: Porte Colossal</option>
                        <option value="COMPACTO">Token Pixel: Miniatura Compacta</option>
                    </select>
                </div>
            </div>
            <!-- BARRA RÁPIDA DE PRESETS DE PERSONALIZAÇÃO PIXEL ART & TESTE DE ANIMAÇÕES (v59) -->
            <div style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;background:rgba(17,24,39,0.9);border:1px solid rgba(56,189,248,0.38);border-radius:8px;padding:6px 10px;">
                <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                    <span style="font-size:11px;font-weight:900;color:#D8B465;">Presets Pixel Art:</span>
                    <button type="button" class="btn-roll-inline" style="background:#1E3A8A;border-color:#60A5FA;padding:3px 8px;" onclick="aplicarPresetVisualRapidoHeroiJS('CAVALEIRO_REAL')">Cavaleiro Real</button>
                    <button type="button" class="btn-roll-inline" style="background:#4C1D95;border-color:#C084FC;padding:3px 8px;" onclick="aplicarPresetVisualRapidoHeroiJS('ARQUIMAGO_ASTRAL')">Arquimago</button>
                    <button type="button" class="btn-roll-inline" style="background:#7F1D1D;border-color:#F87171;padding:3px 8px;" onclick="aplicarPresetVisualRapidoHeroiJS('BARBARO_RUBRO')">Bárbaro Rubro</button>
                    <button type="button" class="btn-roll-inline" style="background:#11141C;border-color:#A855F7;padding:3px 8px;" onclick="aplicarPresetVisualRapidoHeroiJS('ASSASSINO_SOMBRIO')">Assassino</button>
                    <button type="button" class="btn-roll-inline" style="background:#78350F;border-color:#E8E5DC;padding:3px 8px;" onclick="aplicarPresetVisualRapidoHeroiJS('PALADINO_SOLAR')">Paladino Solar</button>
                </div>
                <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                    <span style="font-size:11px;font-weight:900;color:#D8B465;">Testar Animação:</span>
                    <button type="button" class="btn-roll-inline" style="background:#991B1B;border-color:#E8E5DC;padding:3px 7px;" onclick="dispararPopupDanoJRPG('CORTE CRÍTICO!', '#FEF08A', 'INIMIGO', 'ANIM_ESPADA_CORTE', 'Animação de Ataque Corpo a Corpo!')">Ataque</button>
                    <button type="button" class="btn-roll-inline" style="background:#0369A1;border-color:#C99B42;padding:3px 7px;" onclick="dispararPopupDanoJRPG('DEFESA ÉGIDE (+5)!', '#38BDF8', 'HEROI', 'SHIELD', 'Animação de Defesa / Escudo Égide!')">Defesa</button>
                    <button type="button" class="btn-roll-inline" style="background:#C2410C;border-color:#D8B465;padding:3px 7px;" onclick="dispararPopupDanoJRPG('BOLA DE FOGO!', '#F97316', 'INIMIGO', 'ANIM_MAGIA_FOGO', 'Animação de Magia de Fogo!')">Magia</button>
                    <button type="button" class="btn-roll-inline" style="background:#1D4ED8;border-color:#7DD3FC;padding:3px 7px;" onclick="dispararPopupDanoJRPG('RELÂMPAGO!', '#38BDF8', 'INIMIGO', 'ANIM_MAGIA_RAIO', 'Animação de Relâmpago Arcano!')">Raio</button>
                    <button type="button" class="btn-roll-inline" style="background:#450A0A;border-color:#EF4444;padding:3px 7px;" onclick="dispararPopupDanoJRPG('SOPRO DRACÔNICO!', '#EF4444', 'HEROI', 'ANIM_INIMIGO_SOPRO', 'Animação de Sopro do Dragão!')">Sopro</button>
                </div>
            </div>
            <details class="t20-collapsible" style="margin-top:8px;margin-bottom:8px;">
                <summary style="padding:8px 12px;font-size:12px;">
                    <span>Abrir Estúdio Completo de Customização Visual (4+ Exemplares de Cada Arma, Armadura, Escudo, Esotérico, Elmo e Capa do Livro)</span>
                    <span style="font-size:11px;opacity:0.85;">Expandir ▼</span>
                </summary>
                <div class="collapsible-body" style="background:linear-gradient(135deg, #0F172A, #1E1B4B);padding:10px 12px;">
                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(155px, 1fr));gap:8px;font-size:11.5px;color:#E2E8F0;">
                    <div>
                        <label style="color:#D8B465;font-size:11px;">1. Pele / Pelagem / Escamas / Chassi</label>
                        <select id="ap-sel-pele" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FFF;border:1px solid #475569;"></select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">2. Elmo, Chapéu, Capuz & Coroa (4+ Exemplares/Tipo)</label>
                        <select id="ap-sel-cabeca" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FFF;border:1px solid #475569;">
                            <optgroup label="Naturais & Raciais (4 Exemplares)">
                                <option value="RACIAL_CLASSICO">Exemplar I: Clássico da Raça (Chifres / Crista / Orelhas)</option>
                                <option value="VETERANO_GUERRA">Exemplar II: Veterano de Guerra (Chifre/Crista Marcada)</option>
                                <option value="COROA_CHIFRES_DRUIDA">Exemplar III: Galhada Silvestre de Allihanna</option>
                                <option value="AURA_TESTA_CELESTIAL">Exemplar IV: Halo & Marca Solar Celestial</option>
                            </optgroup>
                            <optgroup label="Elmos de Combate — Cap. 3 (4 Exemplares)">
                                <option value="ELMO_TEMPLARIO">Exemplar I: Elmo Fechado de Templário / Cavaleiro</option>
                                <option value="ELMO_VALQUIRIA">Exemplar II: Elmo Alado de Valquíria / Paladino</option>
                                <option value="ELMO_GLADIADOR">Exemplar III: Elmo Imperial com Crista Rubra</option>
                                <option value="ELMO_DOHERIMM">Exemplar IV: Elmo Anão Runificado de Doherimm</option>
                            </optgroup>
                            <optgroup label="Chapéus — Cap. 3 p. 158 (4 Exemplares)">
                                <option value="CHAPEU_ARCANO">Exemplar I: Chapéu Arcano Pontudo de Arquimago</option>
                                <option value="CHAPEU_TRICORNE">Exemplar II: Chapéu Tricorne de Capitão Bucaneiro</option>
                                <option value="CHAPEU_BARDO_PLUMA">Exemplar III: Chapéu Emplumado Galante de Bardo</option>
                                <option value="CHAPEU_CACADOR">Exemplar IV: Chapéu de Couro de Caçador de Ermos</option>
                            </optgroup>
                            <optgroup label="Capuzes, Máscaras & Bandanas (4 Exemplares)">
                                <option value="CAPUZ_SOMBRIO">Exemplar I: Capuz Sombrio de Assassino / Ladino</option>
                                <option value="CAPUZ_SILVESTRE">Exemplar II: Capuz de Folhas de Patrulheiro / Druida</option>
                                <option value="MASCARA_SSZZAAS">Exemplar III: Máscara Furtiva de Sombra</option>
                                <option value="BANDANA_SAMURAI">Exemplar IV: Bandana Marcial de Tamu-ra / Lutador</option>
                            </optgroup>
                            <optgroup label="Coroas, Tiaras & Diademas Mágicos — Cap. 8 p. 343 (4 Exemplares)">
                                <option value="COROA_ARTON">Exemplar I: Coroa Majestosa Real de Deheon</option>
                                <option value="TIARA_SAPIENCIA">Exemplar II: Tiara da Sapiência com Safira Astral</option>
                                <option value="DIADEMA_MENTE">Exemplar III: Diadema da Mente de Cristal</option>
                                <option value="LAUREL_CAMPEAO">Exemplar IV: Laurel Dourado de Campeão da Arena</option>
                            </optgroup>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">3. Penteado / Juba / Corte</label>
                        <select id="ap-sel-penteado" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FFF;border:1px solid #475569;">
                            <option value="HEROICO_CLASSICO">Curto Heróico em Mechas (Mangá T20)</option>
                            <option value="LONGO_ESVOACANTE">Longo Esvoaçante Élfico / Nobre</option>
                            <option value="SAMURAI_COQUE">Coque Samurai de Lin-Wu</option>
                            <option value="TRANCAS_GUERRA">Tranças de Guerra de Tapista / Bárbaro</option>
                            <option value="MOICANO_SELVAGEM">Moicano Selvagem de Gladiador</option>
                            <option value="CACHEADO_VOLUMOSO">Cacheado / Juba Volumosa</option>
                            <option value="MONGE_TATUADO">Calvo com Tatuagem Astral</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">4. Cor do Cabelo / Juba / Crista</label>
                        <select id="ap-sel-cabelo" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FFF;border:1px solid #475569;">
                            <option value="#1E293B">Negro-Corvo / Ébano</option>
                            <option value="#78350F">Castanho-Tapista / Couro</option>
                            <option value="#DC2626">Ruivo-Brasa / Rubro Tormenta</option>
                            <option value="#FACC15">Loiro-Solar / Crista Dourada</option>
                            <option value="#F8FAFC">Branco-Prateado / Invernal</option>
                            <option value="#38BDF8">Azul-Astral / Relâmpago</option>
                            <option value="#10B981">Verde-Esmeralda / Veneno</option>
                            <option value="#A855F7">Roxo-Místico / Abissal</option>
                            <option value="#F97316">Laranja-Chama de Tauron</option>
                            <option value="#EC4899">Rosa-Fada de Wynna</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">5. Armaduras & Trajes do Livro (4 Exemplares de Cada Item — p. 152)</label>
                        <select id="ap-sel-traje" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FFF;border:1px solid #475569;">
                            <option value="AUTO_CLASSE">Sincronizado com a Classe / Armadura da Ficha</option>
                            <optgroup label="Armadura Acolchoada (+1 Def, Leve — 4 Exemplares)">
                                <option value="ACOLCHOADA_EX1">Acolchoada I: Gambeson de Milícia de Deheon</option>
                                <option value="ACOLCHOADA_EX2">Acolchoada II: Jaqueta Estofada de Duelista</option>
                                <option value="ACOLCHOADA_EX3">Acolchoada III: Túnica Acolchoada de Arqueiro</option>
                                <option value="ACOLCHOADA_EX4">Acolchoada IV: Acolchoado Real com Fios de Ouro</option>
                            </optgroup>
                            <optgroup label="Armadura de Couro (+2 Def, Leve — 4 Exemplares)">
                                <option value="COURO_EX1">Armadura de Couro I: Couro Curtido de Patrulheiro</option>
                                <option value="COURO_EX2">Armadura de Couro II: Couro Silvestre de Allihanna</option>
                                <option value="COURO_FURTIVO">Armadura de Couro III: Colete Negro de Assassino</option>
                                <option value="COURO_EX4">Armadura de Couro IV: Couro de Caçador de Monstros</option>
                            </optgroup>
                            <optgroup label="Couro Batido (+3 Def, Leve — 4 Exemplares)">
                                <option value="COURO_BATIDO">Couro Batido I: Rebites de Aço Clássico</option>
                                <option value="COURO_BATIDO_EX2">Couro Batido II: Brigandina de Mercenário</option>
                                <option value="COURO_BATIDO_EX3">Couro Batido III: Gibão Cravejado de Bucaneiro</option>
                                <option value="COURO_BATIDO_EX4">Couro Batido IV: Couraça de Couro Sombrio de Tenebra</option>
                            </optgroup>
                            <optgroup label="Gibão de Peles (+4 Def, Leve — 4 Exemplares)">
                                <option value="PELES_BARBARAS">Gibão de Peles I: Peles de Urso das Montanhas Uivantes</option>
                                <option value="GIBAO_PELES_EX2">Gibão de Peles II: Couro Escamoso de Wyvern</option>
                                <option value="GIBAO_PELES_EX3">Gibão de Peles III: Peitoral Selvagem de Bárbaro</option>
                                <option value="GIBAO_PELES_EX4">Gibão de Peles IV: Pelagem Tribal de Galrasia</option>
                            </optgroup>
                            <optgroup label="Couraça (+5 Def, Leve — 4 Exemplares)">
                                <option value="COURACA_EX1">Couraça I: Peitoral de Aço Real de Deheon</option>
                                <option value="COURACA_EX2">Couraça II: Couraça Solar Dourada de Azgher</option>
                                <option value="COURACA_EX3">Couraça III: Couraça Esculturada de Oficial</option>
                                <option value="COURACA_EX4">Couraça IV: Couraça Élfica de Mitral de Lenórienn</option>
                            </optgroup>
                            <optgroup label="Brunea (+5 Def, Pesada — 4 Exemplares)">
                                <option value="BRUNEA_ESCAMAS">Brunea I: Escamas Dracônicas Carmesim</option>
                                <option value="BRUNEA_EX2">Brunea II: Escamas de Aço Polido</option>
                                <option value="BRUNEA_EX3">Brunea III: Armadura Lamelar de Tamu-ra</option>
                                <option value="BRUNEA_EX4">Brunea IV: Brunea Pesada Anã de Doherimm</option>
                            </optgroup>
                            <optgroup label="Cota de Malha (+6 Def, Pesada — 4 Exemplares)">
                                <option value="COTA_MALHA">Cota de Malha I: Malha Anã de Heredrimm</option>
                                <option value="COTA_MALHA_EX2">Cota de Malha II: Hauberk Longo de Cruzado</option>
                                <option value="COTA_MALHA_EX3">Cota de Malha III: Malha Templária com Tabardo</option>
                                <option value="COTA_MALHA_EX4">Cota de Malha IV: Malha Élfica Prateada</option>
                            </optgroup>
                            <optgroup label="Loriga Segmentada (+7 Def, Pesada — 4 Exemplares)">
                                <option value="LORIGA_EX1">Loriga Segmentada I: Loriga Imperial de Tauron</option>
                                <option value="LORIGA_EX2">Loriga Segmentada II: Loriga de Gladiador Campeão</option>
                                <option value="LORIGA_EX3">Loriga Segmentada III: Bandas de Aço Reforçadas</option>
                                <option value="LORIGA_EX4">Loriga Segmentada IV: Loriga de Legionário</option>
                            </optgroup>
                            <optgroup label="Meia Armadura (+8 Def, Pesada — 4 Exemplares)">
                                <option value="MEIA_ARMADURA_EX1">Meia Armadura I: Placas e Malha de Cavaleiro</option>
                                <option value="MEIA_ARMADURA_EX2">Meia Armadura II: Meia Armadura Real de Bielefeld</option>
                                <option value="MEIA_ARMADURA_EX3">Meia Armadura III: Meia Armadura de Guerra de Arsenal</option>
                                <option value="MEIA_ARMADURA_EX4">Meia Armadura IV: Meia Armadura Sagrada de Khalmyr</option>
                            </optgroup>
                            <optgroup label="Armadura Completa (+10 Def, Pesada — 4 Exemplares)">
                                <option value="PLACAS_PESADAS">Armadura Completa I: Placas Góticas Imperiais</option>
                                <option value="COMPLETA_EX2">Armadura Completa II: Placas de Baluarte Inexpugnável</option>
                                <option value="COMPLETA_EX3">Armadura Completa III: Placas Colossais Dracônicas</option>
                                <option value="COMPLETA_EX4">Armadura Completa IV: Armadura Real de Campeão de Arton</option>
                            </optgroup>
                            <optgroup label="Vestuário & Trajes de Classe — p. 158 (6 Exemplares)">
                                <option value="MANTO_ARCANO">Vestuário I: Manto Rúnico de Arquimago de Wynna</option>
                                <option value="VESTES_SAGRADAS">Vestuário II: Batina & Tabardo Sagrado Clerical</option>
                                <option value="CASACO_CORSARIO">Vestuário III: Casaco Galante de Capitão Bucaneiro</option>
                                <option value="TRAJE_INVENTOR">Vestuário IV: Traje Steampunk de Engenhoqueiro</option>
                                <option value="VESTE_CORTE_NOBRE">Vestuário V: Traje da Corte Real de Nobre</option>
                                <option value="KIMONO_SAMURAI">Vestuário VI: Kimono Marcial de Lin-Wu</option>
                            </optgroup>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">6. Material Especial (Livro p. 166)</label>
                        <select id="ap-sel-material-especial" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#D8B465;border:1px solid var(--t20-gold);">
                            <option value="ACO_PADRAO">Aço Forjado & Couro Padrão</option>
                            <option value="ACO_RUBI">Aço-Rubi (Reflexos Carmesim — Ignora RD)</option>
                            <option value="ADAMANTE">Adamante (Metal Negro-Estelar Pesado)</option>
                            <option value="MITRAL">Mitral (Prata Élfica Reluzente)</option>
                            <option value="MATERIA_VERMELHA">Matéria Vermelha (Quitina Rubra da Tormenta)</option>
                            <option value="GELO_ETERNO">Gelo Eterno (Cristal das Montanhas Uivantes)</option>
                            <option value="MADEIRA_TOLLON">Madeira Tollon (Madeira Viva Esmeralda)</option>
                            <option value="OURO_AZGHER">Ouro Solar de Azgher</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">7. Paleta Heráldica do Traje</label>
                        <select id="ap-sel-cor-traje" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FFF;border:1px solid #475569;">
                            <option value="#7F1D1D|#991B1B">Carmesim de Guerra & Ouro</option>
                            <option value="#1E3A8A|#1D4ED8">Azul Real de Bielefeld & Prata</option>
                            <option value="#334155|#0F172A">Aço Negro de Arsenal & Ferro</option>
                            <option value="#CBD5E1|#B45309">Prata Paladínica & Dourado Solar</option>
                            <option value="#065F46|#047857">Verde Floresta de Allihanna</option>
                            <option value="#4C1D95|#6D28D9">Púrpura Arcana de Wynna</option>
                            <option value="#78350F|#451A03">Bronze Antigo & Couro Curtido</option>
                            <option value="#0F766E|#115E59">Turquesa Oceânica de Oceano</option>
                            <option value="#831843|#BE185D">Vinho Real de Valkaria</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">8. Capas, Mochilas, Aljavas & Costas (4 Exemplares/Tipo)</label>
                        <select id="ap-sel-capa-costas" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FFF;border:1px solid #475569;">
                            <optgroup label="Capas & Mantos — Cap. 3 p. 158 (4 Exemplares)">
                                <option value="CAPA_REAL">Exemplar I: Capa Heróica Longa com Bordado Dourado</option>
                                <option value="CAPA_RASGADA">Exemplar II: Capa Rasgada de Veterano de Batalha</option>
                                <option value="MANTO_GOLA_ALTA">Exemplar III: Manto do Fascínio / Nobre com Gola Alta</option>
                                <option value="MANTO_PELE_INVERNO">Exemplar IV: Manto Pesado de Pele de Lobo das Uivantes</option>
                            </optgroup>
                            <optgroup label="Mochilas & Equipamento de Aventura — p. 155 (4 Exemplares)">
                                <option value="MOCHILA_AVENTUREIRO">Exemplar I: Mochila de Aventureiro & Saco de Dormir</option>
                                <option value="MOCHILA_CARGA_TOCHA">Exemplar II: Mochila de Carga Pesada c/ Corda e Tocha</option>
                                <option value="BANDOLEIRA_POCOES">Exemplar III: Bandoleira Alquímica de Poções e Bálsamos</option>
                                <option value="MALETA_FERRAMENTAS">Exemplar IV: Maleta de Medicamentos / Ferramentas de Ofício</option>
                            </optgroup>
                            <optgroup label="Aljavas & Municiadores — p. 146 (4 Exemplares)">
                                <option value="ALJAVA_ARCO">Exemplar I: Aljava de Couro com 20 Flechas</option>
                                <option value="ALJAVA_ELFICA_DOURADA">Exemplar II: Aljava Élfica Dourada de Lenórienn</option>
                                <option value="CAIXA_VIROTES_BESTA">Exemplar III: Estoque Militar de Virotes de Besta</option>
                                <option value="CARTUCHEIRA_POLVORA">Exemplar IV: Bandoleira de Pólvora e Balas de Mosquete</option>
                            </optgroup>
                            <optgroup label="Estandartes, Halos & Asas Mágicas — Cap. 8 (4 Exemplares)">
                                <option value="ESTANDARTE_GUERRA">Exemplar I: Estandarte de Guerra Cravado nas Costas</option>
                                <option value="HALO_DIVINO">Exemplar II: Círculo Rúnico / Halo Divino Radiante</option>
                                <option value="PROPULSOR_AETHER">Exemplar III: Meca-Propulsor Steampunk de Inventor</option>
                                <option value="ASAS_CELESTIAIS_DRACONICAS">Exemplar IV: Grandes Asas Celestiais Abertas</option>
                                <option value="ASAS_MORCEGO_ABISSAL">Exemplar V: Grandes Asas de Morcego / Dragão</option>
                            </optgroup>
                            <option value="SEM_CAPA">Sem Acessório de Costas (Silhueta Limpa)</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">8B. Silhueta das Ombreiras</label>
                        <select id="ap-sel-ombreiras" onchange="aplicarMudancaAparenciaSincronizadaJS('ARENA', 'ombreiras', this.value)" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#E8E5DC;border:1px solid var(--t20-gold);">
                            <option value="AUTO_TRAJE">Padrão da Armadura</option>
                            <option value="OMBREIRAS_COLOSSAIS_ESPINHOS">Ombreiras Colossais de Espinhos</option>
                            <option value="OMBREIRAS_ALADAS_PALADINO">Ombreiras Aladas de Valquíria</option>
                            <option value="OMBREIRAS_CRANIO_NECRO">Ombreiras de Crânios de Aslothia</option>
                            <option value="OMBREIRAS_PELES_FERA">Ombreiras de Pelagem de Fera</option>
                            <option value="SEM_OMBREIRAS_LEVE">Sem Ombreiras (Silhueta Esguia)</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">9. Postura de Combate & Porte</label>
                        <select id="ap-sel-postura" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FFF;border:1px solid #475569;">
                            <option value="HEROICA_CLASSICA">Postura Clássica Heróica ¾</option>
                            <option value="GUARDA_OFENSIVA">Guarda Ofensiva Inclinada p/ Ataque</option>
                            <option value="DUELISTA_AGIL">Postura Ágil de Esgrimista / Assassino</option>
                            <option value="CONJURACAO_ARCANA">Levitação Mística de Arquimago</option>
                            <option value="COLOSSO_IMPONENTE">Porte Colosso Musculoso</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">10. Expressão, Cicatriz & Marcas</label>
                        <select id="ap-sel-expressao" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FFF;border:1px solid #475569;">
                            <option value="DETERMINADO">Olhar Determinado Heróico</option>
                            <option value="OLHOS_INCANDESCENTES">Olhos Incandescentes em Fúria</option>
                            <option value="CICATRIZ_VETERANA">Cicatriz de Batalha no Olho</option>
                            <option value="PINTURA_TRIBAL">Pintura de Guerra Rubra</option>
                            <option value="SORRISO_AUDACIOSO">Sorriso Audacioso de Duelista</option>
                            <option value="TAPA_OLHO_CORSARIO">Tapa-Olho de Veterano / Corsário</option>
                            <option value="MARCA_TORMENTA">Marca Aberrante na Testa</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">11. Arma Principal (4 Exemplares Visuais de Cada Arma do Livro — p. 146)</label>
                        <select id="ap-sel-arma-custom" onchange="trocarArmaEquipadaVisualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#D8B465;border:1px solid var(--t20-gold);">
                            <option value="AUTO_FICHA">Arma Atual da Ficha (Sincronizada)</option>
                            <optgroup label="Montante (2d6, 19/x2 — 4 Exemplares)">
                                <option value="Montante">Montante I: Claymore Clássica de Deheon</option>
                                <option value="Montante#EX2">Montante II: Zweihänder Imperial Flamberge</option>
                                <option value="Montante#EX3">Montante III: Grande Espada Rúnica de Doherimm</option>
                                <option value="Montante#EX4">Montante IV: Colosso Dracônico de Arsenal</option>
                            </optgroup>
                            <optgroup label="Espada Longa (1d8, 19/x2 — 4 Exemplares)">
                                <option value="Espada longa">Espada Longa I: Cruciforme de Cavaleiro</option>
                                <option value="Espada longa#EX2">Espada Longa II: Lâmina Real de Bielefeld</option>
                                <option value="Espada longa#EX3">Espada Longa III: Lâmina Élfica de Lenórienn</option>
                                <option value="Espada longa#EX4">Espada Longa IV: Espada Justiceira de Khalmyr</option>
                            </optgroup>
                            <optgroup label="Espada Bastarda & Katana (1d10, 19/x2 — 8 Exemplares)">
                                <option value="Espada bastarda">Espada Bastarda I: Mão-e-Meia de Guerra</option>
                                <option value="Espada bastarda#EX2">Espada Bastarda II: Lâmina Real de Valkaria</option>
                                <option value="Espada bastarda#EX3">Espada Bastarda III: Forja Pesada de Heredrimm</option>
                                <option value="Espada bastarda#EX4">Espada Bastarda IV: Lâmina Negra de Aslothia</option>
                                <option value="Katana">Katana I: Uchigatana Tradicional de Tamu-ra</option>
                                <option value="Katana#EX2">Katana II: Lâmina Celestial de Lin-Wu</option>
                                <option value="Katana#EX3">Katana III: Tachi Imperial Dourada</option>
                                <option value="Katana#EX4">Katana IV: Lâmina Carmesim da Tormenta</option>
                            </optgroup>
                            <optgroup label="Florete, Cimitarra, Espada Curta & Adaga (16 Exemplares)">
                                <option value="Florete">Florete I: Taça Rendilhada de Esgrimista</option>
                                <option value="Florete#EX2">Florete II: Rapieira Real de Ahlen</option>
                                <option value="Florete#EX3">Florete III: Estoque Prateado de Bardo</option>
                                <option value="Florete#EX4">Florete IV: Aguilhão Escarlate de Duelista</option>
                                <option value="Cimitarra">Cimitarra I: Sabre Curvo do Deserto da Perdição</option>
                                <option value="Cimitarra#EX2">Cimitarra II: Lâmina Solar Dourada de Azgher</option>
                                <option value="Cimitarra#EX3">Cimitarra III: Cutelo de Abordagem Pirata</option>
                                <option value="Cimitarra#EX4">Cimitarra IV: Shamshir dos Ventos de Qareen</option>
                                <option value="Espada curta">Espada Curta I: Gládio Militar de Tauron</option>
                                <option value="Espada curta#EX2">Espada Curta II: Cinquedea Nobre</option>
                                <option value="Espada curta#EX3">Espada Curta III: Lâmina de Patrulheiro</option>
                                <option value="Espada curta#EX4">Espada Curta IV: Wakizashi Sombria</option>
                                <option value="Adaga">Adaga I: Punhal Curvo de Assassino</option>
                                <option value="Adaga#EX2">Adaga II: Kris Ondulada de Sszzaas</option>
                                <option value="Adaga#EX3">Adaga III: Estilete Real Cravejado</option>
                                <option value="Adaga#EX4">Adaga IV: Presa Ritualística de Sangue</option>
                            </optgroup>
                            <optgroup label="Machados: Batalha, Guerra, Anão & Táurico (16 Exemplares)">
                                <option value="Machado de guerra">Machado de Guerra I: Bipene Colossal de Duas Mãos</option>
                                <option value="Machado de guerra#EX2">Machado de Guerra II: Carrasco das Montanhas Uivantes</option>
                                <option value="Machado de guerra#EX3">Machado de Guerra III: Cortador Rúnico de Doherimm</option>
                                <option value="Machado de guerra#EX4">Machado de Guerra IV: Fúria Rubra de Megalokk</option>
                                <option value="Machado táurico">Machado Táurico I: Lâmina Pesada de Tapista</option>
                                <option value="Machado táurico#EX2">Machado Táurico II: Campeão da Arena Imperial</option>
                                <option value="Machado táurico#EX3">Machado Táurico III: Forja de Adamante</option>
                                <option value="Machado táurico#EX4">Machado Táurico IV: Carniceiro de Guerra</option>
                                <option value="Machado anão">Machado Anão I: Tradição de Heredrimm</option>
                                <option value="Machado anão#EX2">Machado Anão II: Guarda Real de Doherimm</option>
                                <option value="Machado anão#EX3">Machado Anão III: Forja Vulcânica Runificada</option>
                                <option value="Machado anão#EX4">Machado Anão IV: Gume de Mitral Anão</option>
                                <option value="Machado de batalha">Machado de Batalha I: Barbudo de Uma Mão</option>
                                <option value="Machado de batalha#EX2">Machado de Batalha II: Machado Nórdico de Escudeiro</option>
                                <option value="Machado de batalha#EX3">Machado de Batalha III: Lenhador de Galrasia</option>
                                <option value="Machado de batalha#EX4">Machado de Batalha IV: Faiscante de Guerra</option>
                            </optgroup>
                            <optgroup label="Martelos, Marretas, Maças, Mangual & Bordão (20 Exemplares)">
                                <option value="Marreta">Marreta I: Malho Colossal de Pedra e Aço</option>
                                <option value="Marreta#EX2">Marreta II: Bigorna de Guerra de Doherimm</option>
                                <option value="Marreta#EX3">Marreta III: Quebra-Crânios de Titã</option>
                                <option value="Marreta#EX4">Marreta IV: Martelo Vulcânico de Tauron</option>
                                <option value="Martelo de guerra">Martelo de Guerra I: Bico-de-Corvo Militar</option>
                                <option value="Martelo de guerra#EX2">Martelo de Guerra II: Martelo Sagrado de Khalmyr</option>
                                <option value="Martelo de guerra#EX3">Martelo de Guerra III: Forjador Anão Runificado</option>
                                <option value="Martelo de guerra#EX4">Martelo de Guerra IV: Martelo Trovejante</option>
                                <option value="Maça">Maça I: Maça Estrelada Clerical</option>
                                <option value="Maça#EX2">Maça II: Maça Solar Dourada</option>
                                <option value="Maça#EX3">Maça III: Maça de Flanges de Templário</option>
                                <option value="Maça#EX4">Maça IV: Maça Negra de Osso e Ferro</option>
                                <option value="Mangual">Mangual I: Corrente e Esfera Cravejada</option>
                                <option value="Mangual#EX2">Mangual II: Turíbulo de Batalha Inquisidor</option>
                                <option value="Mangual#EX3">Mangual III: Mangual de Três Cabeças</option>
                                <option value="Mangual#EX4">Mangual IV: Flagelo de Aço de Arsenal</option>
                                <option value="Bordão">Bordão I: Cajado Ferrado de Monge/Druida</option>
                                <option value="Bordão#EX2">Bordão II: Galho Vivo de Madeira Tollon</option>
                                <option value="Bordão#EX3">Bordão III: Bo Marcial Anelado de Tamu-ra</option>
                                <option value="Bordão#EX4">Bordão IV: Bastão Runificado de Sábio</option>
                            </optgroup>
                            <optgroup label="Armas de Haste, Alongadas & Exóticas (20 Exemplares)">
                                <option value="Alabarda">Alabarda I: Alabarda Real com Flâmula</option>
                                <option value="Alabarda#EX2">Alabarda II: Guarda Suíça de Bielefeld</option>
                                <option value="Alabarda#EX3">Alabarda III: Naginata / Glaive de Lin-Wu</option>
                                <option value="Alabarda#EX4">Alabarda IV: Alabarda Rubra de Guerra</option>
                                <option value="Lança">Lança I: Pique Longo de Falange</option>
                                <option value="Lança#EX2">Lança II: Lança de Justa de Cavaleiro</option>
                                <option value="Lança#EX3">Lança III: Lança Tribal de Caça</option>
                                <option value="Lança#EX4">Lança IV: Dardo Relâmpago</option>
                                <option value="Tridente">Tridente I: Tridente Oceânico do Mar Negro</option>
                                <option value="Tridente#EX2">Tridente II: Cetro-Tridente Real de Tritão</option>
                                <option value="Tridente#EX3">Tridente III: Tridente de Gladiador Retiarius</option>
                                <option value="Tridente#EX4">Tridente IV: Tridente de Coral e Gelo Eterno</option>
                                <option value="Gadanho">Gadanho I: Foice Ceifadora de Duas Mãos</option>
                                <option value="Gadanho#EX2">Gadanho II: Ceifador de Tenebra / Osteon</option>
                                <option value="Gadanho#EX3">Gadanho III: Gadanho Silvestre de Colheita</option>
                                <option value="Gadanho#EX4">Gadanho IV: Lâmina Curva da Tormenta</option>
                                <option value="Corrente de espinhos">Corrente de Espinhos I: Grilhão de Gladiador</option>
                                <option value="Corrente de espinhos#EX2">Corrente de Espinhos II: Corrente Incandescente</option>
                                <option value="Corrente de espinhos#EX3">Corrente de Espinhos III: Kusarigama de Tamu-ra</option>
                                <option value="Corrente de espinhos#EX4">Corrente de Espinhos IV: Corrente Sombria</option>
                            </optgroup>
                            <optgroup label="Arcos, Bestas & Armas de Fogo (20 Exemplares)">
                                <option value="Arco longo">Arco Longo I: Composto de Teixo</option>
                                <option value="Arco longo#EX2">Arco Longo II: Arco Élfico Dourado de Lenórienn</option>
                                <option value="Arco longo#EX3">Arco Longo III: Arco de Chifre de Dragão</option>
                                <option value="Arco longo#EX4">Arco Longo IV: Arco Vivo de Madeira Tollon</option>
                                <option value="Arco curto">Arco Curto I: Arco de Caça de Patrulheiro</option>
                                <option value="Arco curto#EX2">Arco Curto II: Arco Recurvo de Cavalaria</option>
                                <option value="Arco curto#EX3">Arco Curto III: Arco Silvestre de Galrasia</option>
                                <option value="Arco curto#EX4">Arco Curto IV: Arco Rápido de Escaramuça</option>
                                <option value="Besta pesada">Besta Pesada I: Arbaleste de Manivela</option>
                                <option value="Besta pesada#EX2">Besta Pesada II: Besta de Cerco Anã de Doherimm</option>
                                <option value="Besta pesada#EX3">Besta Pesada III: Besta de Repetição de Inventor</option>
                                <option value="Besta pesada#EX4">Besta Pesada IV: Besta Franca de Precisão</option>
                                <option value="Mosquete">Mosquete I: Mosquete de Pólvora c/ Baioneta</option>
                                <option value="Mosquete#EX2">Mosquete II: Rifle Aether de Kliren / Inventor</option>
                                <option value="Mosquete#EX3">Mosquete III: Arcabuz Real Dourado</option>
                                <option value="Mosquete#EX4">Mosquete IV: Canhão de Mão Dracônico</option>
                                <option value="Pistola">Pistola I: Pederneira de Capitão Bucaneiro</option>
                                <option value="Pistola#EX2">Pistola II: Pistola de Tambor de Engenhoqueiro</option>
                                <option value="Pistola#EX3">Pistola III: Pistola de Duelo Prateada</option>
                                <option value="Pistola#EX4">Pistola IV: Bacamarte Boca-de-Sino</option>
                            </optgroup>
                            <optgroup label="Cajados, Varinhas & Manoplas (12 Exemplares)">
                                <option value="Cajado arcano">Cajado Arcano I: Orbe de Dragão de Wynna</option>
                                <option value="Cajado arcano#EX2">Cajado Arcano II: Báculo Solar de Clérigo</option>
                                <option value="Cajado arcano#EX3">Cajado Arcano III: Cajado Raiz de Druida</option>
                                <option value="Cajado arcano#EX4">Cajado Arcano IV: Cajado Necromântico de Crânio</option>
                                <option value="Varinha">Varinha I: Cetro Real Arcano</option>
                                <option value="Varinha#EX2">Varinha II: Varinha de Madeira Tollon</option>
                                <option value="Varinha#EX3">Varinha III: Bastão de Cristal Astral</option>
                                <option value="Varinha#EX4">Varinha IV: Varinha Rubra de Evocação</option>
                                <option value="Manopla">Manopla I: Manopla de Ferro de Lutador</option>
                                <option value="Manopla#EX2">Manopla II: Katar / Garra de Tigre</option>
                                <option value="Manopla#EX3">Manopla III: Punho Mecânico de Inventor</option>
                                <option value="Manopla#EX4">Manopla IV: Manopla Dracônica Cravejada</option>
                            </optgroup>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">12. Mão Secundária, Escudos & Esotéricos (4 Exemplares/Tipo)</label>
                        <select id="ap-sel-mao-secundaria" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#D8B465;border:1px solid var(--t20-gold);">
                            <option value="AUTO_FICHA">Automático da Ficha (Escudo ou Esotérico)</option>
                            <optgroup label="Escudo Leve (+1 Def, p. 154 — 4 Exemplares)">
                                <option value="ESCUDO_LEVE">Escudo Leve I: Broquel de Aço de Duelista</option>
                                <option value="ESCUDO_LEVE_MADEIRA">Escudo Leve II: Redondo de Madeira Reforçada</option>
                                <option value="ESCUDO_LEVE_TARGE">Escudo Leve III: Targe Tribal de Bárbaro</option>
                                <option value="ESCUDO_LEVE_ELFICO">Escudo Leve IV: Escudo Élfico em Folha Dourada</option>
                            </optgroup>
                            <optgroup label="Escudo Pesado (+2 Def, p. 154 — 4 Exemplares)">
                                <option value="ESCUDO_PESADO">Escudo Pesado I: Heráldico de Bielefeld</option>
                                <option value="ESCUDO_TORRE">Escudo Pesado II: Escudo Torre de Baluarte</option>
                                <option value="ESCUDO_PESADO_DOHERIMM">Escudo Pesado III: Muralha Anã de Doherimm</option>
                                <option value="ESCUDO_ESPINHOS">Escudo Pesado IV: Escudo Cravejado de Espinhos</option>
                            </optgroup>
                            <optgroup label="Orbe Cristalino — p. 159 (4 Exemplares)">
                                <option value="ORBE_CRISTAL">Orbe I: Cristal Astral Levitante</option>
                                <option value="ORBE_FOGO_DRAGAO">Orbe II: Esfera de Fogo Dracônico</option>
                                <option value="ORBE_TREVAS_ABISSAL">Orbe III: Orbe Abissal de Tenebra</option>
                                <option value="ORBE_ESMERALDA_WYNNA">Orbe IV: Orbe Esmeralda de Wynna</option>
                            </optgroup>
                            <optgroup label="Tomo Hermético / Grimório — p. 159 (4 Exemplares)">
                                <option value="GRIMORIO_ARCANO">Grimório I: Tomo Real de Couro e Ouro</option>
                                <option value="GRIMORIO_NECRO_CORRENTES">Grimório II: Tomo Acorrentado de Necromante</option>
                                <option value="GRIMORIO_SOLAR_DOURADO">Grimório III: Códice Iluminado de Talude</option>
                                <option value="PERGAMINHO_ANCESTRAL">Grimório IV: Pergaminho Ancestral Flutuante</option>
                            </optgroup>
                            <optgroup label="Símbolo Sagrado — p. 157 (4 Exemplares)">
                                <option value="SIMBOLO_SAGRADO">Símbolo Sagrado I: Sol Radiante de Azgher</option>
                                <option value="SIMBOLO_ESPADA_KHALMYR">Símbolo Sagrado II: Espada da Justiça de Khalmyr</option>
                                <option value="SIMBOLO_FOLHA_ALLIHANNA">Símbolo Sagrado III: Folha Viva de Allihanna</option>
                                <option value="SIMBOLO_CHAMA_THYATIS">Símbolo Sagrado IV: Fênix / Chama de Thyatis</option>
                            </optgroup>
                            <optgroup label="Instrumento Musical de Bardo — p. 157 (4 Exemplares)">
                                <option value="ALAUDE_BARDO">Instrumento I: Alaúde Clássico de Salão</option>
                                <option value="HARPA_ELFICA_BARDO">Instrumento II: Harpa Élfica Dourada</option>
                                <option value="FLAUTA_MISTICA_BARDO">Instrumento III: Flauta Transversal de Marfim</option>
                                <option value="TAMBOR_GUERRA_BARDO">Instrumento IV: Tambor de Guerra Marcial</option>
                            </optgroup>
                            <optgroup label="Armas Secundárias / Ambidestria (4 Exemplares)">
                                <option value="DUAS_ARMAS_ADAGA">Mão Inábil I: Adaga Assassina Curva</option>
                                <option value="DUAS_ARMAS_ESPADA">Mão Inábil II: Espada Curta / Gládio</option>
                                <option value="DUAS_ARMAS_PISTOLA">Mão Inábil III: Pistola Pederneira Secundária</option>
                                <option value="DUAS_ARMAS_MACHADINHA">Mão Inábil IV: Machadinha / Katar Secundário</option>
                            </optgroup>
                            <optgroup label="Engenhocas, Tochas & Alquímicos — p. 156 (4 Exemplares)">
                                <option value="ENGENHOCA_INVENTOR">Item I: Engenhoca Mecânica Aether</option>
                                <option value="TOCHA_ACESA_SEC">Item II: Tocha Acesa de Masmorra</option>
                                <option value="LANTERNA_FURTA_FOGO">Item III: Lanterna Furta-Fogo Direcional</option>
                                <option value="FRASCO_FOGO_ALQUIMICO">Item IV: Frasco de Fogo Alquímico / Ácido</option>
                            </optgroup>
                            <option value="MAO_LIVRE">Mão Livre (Duas Mãos / Esgrima Pura)</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#D8B465;font-size:11px;">13. Encantamento Elemental da Arma</label>
                        <select id="ap-sel-efeito-arma" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#D8B465;border:1px solid var(--t20-gold);">
                            <option value="ACO_FORJADO">Sem Encantamento (Brilho Metálico Puro)</option>
                            <option value="FOGO_SOLAR">Flamejante (+1d6 Fogo / Labaredas)</option>
                            <option value="RAIO_TROVAO">Chocante (+1d6 Eletricidade / Raios)</option>
                            <option value="GELO_CRISTAL">Congelante (+1d6 Frio / Cristais)</option>
                            <option value="VENENO_ACIDO">Corrosiva / Venenosa (+1d6 Ácido)</option>
                            <option value="LUZ_PALADINO">Sagrada (+2d6 Luz vs Mal)</option>
                            <option value="TREVAS_PROFANA">Profana / Tumular (+1d6 Trevas)</option>
                            <option value="RUBRO_TORMENTA">Aberrante da Tormenta</option>
                            <option value="ESSENCIA_ASTRAL">Energética / Essência Pura</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#C99B42;font-size:11px;">14. Estilo de Arte & Renderizador</label>
                        <select id="ap-sel-estilo-arte" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#7DD3FC;border:1px solid #38BDF8;">
                            <option value="HQ_TORMENTA20">HQ Oficial Tormenta 20 (Nanquim + Cel-Shading)</option>
                            <option value="PINTURA_DIGITAL">Pintura Digital Épica (Luz & Bloom Dramático)</option>
                            <option value="MANGA_SHONEN">Mangá P&B + Rubro (Reticulado & Alto Contraste)</option>
                            <option value="VITRAL_GOTICO"> stained-glass Vitral Gótico de Catedral</option>
                            <option value="PERGAMINHO_ARTON">Iluminura de Grimório Antigo (Sépia & Ouro)</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#C99B42;font-size:11px;">16. Aura &amp; Partículas Pixel Art</label>
                        <select id="ap-sel-aura-particulas" onchange="window.__APARENCIA_HEROI__=window.__APARENCIA_HEROI__||{{}};window.__APARENCIA_HEROI__.auraParticulas=this.value;aplicarMudancaAparenciaManualJS();" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#6EE7B7;border:1px solid rgba(201,155,66,0.30);">
                            <option value="NENHUMA">Sem Aura de Partículas</option>
                            <option value="CHAMAS_SOLARES">Labaredas Solares de Azgher/Tauron</option>
                            <option value="RAIOS_TEMPESTADE">Relâmpagos Astrais de Wynna</option>
                            <option value="CRISTAIS_GELO">Cristais de Gelo das Uivantes</option>
                            <option value="LUZ_DIVINA">Partículas Sagradas de Khalmyr</option>
                            <option value="TREVAS_TENEBRA">Chamas Negras de Tenebra</option>
                            <option value="CORRUPCAO_TORMENTA">Bio-Cristais Rubros da Tormenta</option>
                            <option value="FOLHAS_ALLIHANNA">Espiral Silvestre de Allihanna</option>
                        </select>
                    </div>
                    <div>
                        <label style="color:#F87171;font-size:11px;">15. Cenário de Arton (Fundo da Arena)</label>
                        <select id="ap-sel-cenario-arton" onchange="aplicarMudancaAparenciaManualJS()" style="min-height:30px;padding:2px 6px;font-size:11.5px;background:#1E293B;color:#FECDD3;border:1px solid #F43F5E;">
                            <option value="AUTO_AMEACA">Automático pela Ameaça do Cap. 7</option>
                            <option value="Tormenta">Área de Tormenta (Olho de Aharadak & Coral Rubro)</option>
                            <option value="Dragões">Covil de Sckharshantallas (Vulcão & Tesouro de Tibares)</option>
                            <option value="Mortos-Vivos">Catedral de Aslothia (Lua Espectral & Necrópole)</option>
                            <option value="Puristas">Fortaleza da Supremacia Purista (Muralhas de Ferro)</option>
                            <option value="Duyshidakk">Acampamento Duyshidakk (Eclipse de Thwor & Fogueiras)</option>
                            <option value="Cultistas">Santuário de Sszzaas (Altar da Naja & Chamas Verdes)</option>
                            <option value="Ermos">Selva de Galrasia (Cristais de Mana & Flora Primordial)</option>
                            <option value="Masmorras">Masmorras de Heredrimm (Arcos Anões & Braseiros)</option>
                        </select>
                    </div>
                </div>
                <div style="margin-top:8px;padding:6px 10px;background:#171B24;border:1px solid rgba(232,229,220,0.12);border-radius:8px;font-size:11px;color:#E2E8F0;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px;">
                    <span><strong>Referências Visuais Conectadas da sua Pasta <a href="https://drive.google.com/drive/folders/1KjyDZ0nwe3BCC9jACPn-dV5IEj-LSuBB" target="_blank" style="color:#D8B465;text-decoration:underline;">Tormenta_20 no Google Drive</a>:</strong></span>
                    <span style="display:flex;gap:8px;flex-wrap:wrap;">
                        <a href="https://drive.google.com/file/d/1nGbJuF6ugQNqjIuECBFqrnoWPkq5Hx_7/view?usp=drivesdk" target="_blank" style="color:#FCA5A5;">Covil Dracônico</a> ·
                        <a href="https://drive.google.com/file/d/1IiaF-V4n8dsIXhWIE5jJzm4NEIw6XNFw/view?usp=drivesdk" target="_blank" style="color:#6EE7B7;">Cemitério Assombrado</a> ·
                        <a href="https://drive.google.com/file/d/14sC8zJF0iNu4LmuTY8BClaMtQmPa7mvc/view?usp=drivesdk" target="_blank" style="color:#86EFAC;">Estrada na Selva</a> ·
                        <a href="https://drive.google.com/file/d/1xVpvzZ_tt06V2pI-_hqfcViv4xQ1Iqti/view?usp=drivesdk" target="_blank" style="color:#D8B465;">Câmara do Templo</a> ·
                        <a href="https://drive.google.com/file/d/1rSwSA96F-3IX9TRziDxbrXELiz8jxakJ/view?usp=drivesdk" target="_blank" style="color:#D8B465;">Golem Arcanológico</a> ·
                        <a href="https://drive.google.com/file/d/14d8-sJZp229tDOHWXkb6QtFEtec3ST_p/view?usp=drivesdk" target="_blank" style="color:#FDBA74;">Rhyemom Mavhrekky</a>
                    </span>
                </div>
                </div>
            </details>

            <!-- SHELL DE TELA CHEIA DA ARENA DE COMBATE + HUD DINÂMICO DE BAIXA POLUIÇÃO VISUAL (v62) -->
            <div id="arena-combat-screen-shell" class="t20-combat-screen-shell">
                <!-- BARRA SUPERIOR FIXA DO MODO TELA CHEIA MOBILE (STATUS DO HERÓI + ÚLTIMA ROLAGEM + BOTÃO SAIR) -->
                <div id="arena-fullscreen-sticky-bar">
                    <div id="arena-fullscreen-sticky-hero-stats" style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;font-size:11px;"></div>
                    <div id="arena-fullscreen-live-roll-pill" style="background:#151821;border:1px solid rgba(201,155,66,0.35);color:#E8E5DC;padding:3px 8px;border-radius:6px;font-size:11px;font-weight:800;">
                        Toque em qualquer ataque, magia ou perícia para rolar!
                    </div>
                    <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;">
                        <button type="button" class="btn-roll-inline" style="background:#047857;border-color:#C99B42;color:#ECFDF5;font-weight:900;padding:4px 8px;" onclick="ajustarRecursoRapidoPersonagemArenaJS('POCAO_CURA')">+PV</button>
                        <button type="button" class="btn-roll-inline" style="background:#0369A1;border-color:#C99B42;color:#E0F2FE;font-weight:900;padding:4px 8px;" onclick="ajustarRecursoRapidoPersonagemArenaJS('ESSENCIA_MANA')">+PM</button>
                        <button type="button" class="btn-roll-inline" style="background:#1E3A8A;border-color:#C99B42;color:#E0F2FE;font-weight:900;padding:4px 8px;" onclick="alternarMenuLateralPassivasJS('ARENA')">Passivas</button>
                        <button type="button" class="btn-roll-inline" style="background:#B45309;border-color:#E8E5DC;color:#E8E5DC;font-weight:900;padding:4px 8px;" onclick="reiniciarCombateArenaVisual()">Novo Duelo</button>
                        <button type="button" class="btn-roll-inline" style="background:#991B1B;border-color:#FCA5A5;color:#E8E5DC;font-weight:900;padding:5px 11px;font-size:11.5px;" onclick="alternarTelaCheiaCombateT20JS('ARENA')">SAIR DA TELA CHEIA</button>
                    </div>
                </div>
                <!-- PALCO VISUAL INTERATIVO DE BATALHA EM TURNOS (BARRA SUPERIOR SEPARADA DO SVG — ZERO SOBREPOSIÇÃO!) -->
                <div id="jrpg-battle-stage" class="jrpg-stage-wrapper">
                    <div class="jrpg-top-hud">
                        <div id="jrpg-turn-order-bar" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;font-size:11.5px;">
                            <span style="color:#D8B465;font-weight:800;">INICIATIVA:</span>
                            <span class="jrpg-turn-pill active-turn">1º Herói</span>
                            <span style="color:#CBD5E1;"></span>
                            <span class="jrpg-turn-pill">2º Ameaça</span>
                        </div>
                        <div id="jrpg-action-banner" style="font-size:12px;font-weight:800;color:#E8E5DC;text-align:center;flex:1;min-width:180px;">
                            Batalha em Turnos Iniciada — Escolha o comando no HUD Dinâmico abaixo!
                        </div>
                        <div style="display:flex;align-items:center;gap:4px;flex-wrap:wrap;">
                            <span style="font-size:10px;font-weight:900;color:#C99B42;background:#1A1F2B;border:1px solid rgba(201,155,66,0.30);border-radius:5px;padding:2px 6px;" title="Mapa Tático 120x120 (180m x 180m) — Clique nos ladrilhos do chão ou use as setas para navegar!">120×120</span>
                            <button type="button" class="btn-roll-inline" style="background:#1E3A8A;padding:2px 6px;font-size:10px;" onclick="moverCameraMapa120JS(-5, 0)" title="Mover Câmera p/ Oeste">⬅</button>
                            <button type="button" class="btn-roll-inline" style="background:#1E3A8A;padding:2px 6px;font-size:10px;" onclick="moverCameraMapa120JS(0, -4)" title="Mover Câmera p/ Norte">⬆</button>
                            <button type="button" class="btn-roll-inline" style="background:#1E3A8A;padding:2px 6px;font-size:10px;" onclick="moverCameraMapa120JS(0, 4)" title="Mover Câmera p/ Sul">⬇</button>
                            <button type="button" class="btn-roll-inline" style="background:#1E3A8A;padding:2px 6px;font-size:10px;" onclick="moverCameraMapa120JS(5, 0)" title="Mover Câmera p/ Leste"></button>
                            <button type="button" class="btn-roll-inline" style="background:#B45309;border-color:#E8E5DC;color:#E8E5DC;padding:2px 6px;font-size:10px;" onclick="centralizarCameraMapa120JS('AUTO')" title="Centralizar Câmera no Combate"></button>
                            <select id="arena-sel-estilo-visual" onchange="alternarEstiloVisualArenaJS(this.value)" style="width:auto;min-height:26px;padding:2px 6px;font-size:10.5px;background:#1E293B;color:#E8E5DC;border:1px solid var(--t20-gold);border-radius:6px;" title="Alternar Estilo de Renderização do Palco">
                                <option value="HD2D" selected>2D Dark Fantasy</option>
                                <option value="PIXEL16">Pixel-Art 16-Bit</option>
                                <option value="CLASSIC">Pergaminho</option>
                            </select>
                            <button type="button" class="btn-roll-inline" style="background:#7C2D12;border-color:#E8E5DC;color:#E8E5DC;padding:4px 8px;font-size:10.5px;font-weight:900;" onclick="alternarModoOclusaoAmeacaGiganteJS()" title="Alterna entre Anti-Oclusão Automática, Token Fantasma (35%) e Ocultar Token da Ameaça">
                                Ocultar/Fantasma Ameaça
                            </button>
                            <button type="button" class="btn-roll-inline" style="background:#0284C7;border-color:#C99B42;padding:4px 8px;font-size:10.5px;" onclick="alternarModoVisibilidadePalco2DJS()">
                                Sprites/Tokens
                            </button>
                            <button type="button" id="btn-toggle-grid2d-arena-inline" class="btn-roll-inline" style="background:#1E293B;border-color:#C99B42;color:#C99B42;padding:4px 8px;font-size:10.5px;" onclick="alternarPainelGrid2DArenaVisivelJS()">
                                Grid 2D &amp; Radar
                            </button>
                            <button type="button" class="btn-roll-inline" style="background:#0369A1;border-color:#C99B42;color:#E0F2FE;padding:4px 8px;font-size:10.5px;" onclick="mostrarAba('tab-mesa-online');inicializarAbaMesaOnlineUI();">
                                Mesas Online
                            </button>
                            <button type="button" id="btn-arena-fullscreen-toggle" class="btn-roll-inline" style="background:linear-gradient(135deg, #059669, #047857);border-color:#E8E5DC;color:#E8E5DC;font-weight:900;padding:4px 11px;font-size:11px;box-shadow:0 2px 8px rgba(0,0,0,0.6);" onclick="alternarTelaCheiaCombateT20JS('ARENA')">
                                Tela Cheia
                            </button>
                        </div>
                    </div>
                    <div style="position:relative;width:100%;line-height:0;">
                        <div id="jrpg-floating-popups" style="position:absolute;inset:0;pointer-events:none;z-index:9;overflow:hidden;"></div>
                        <div id="jrpg-svg-scene-container" style="width:100%;line-height:0;"></div>
                    </div>
                </div>

                <!-- BARRA DE AÇÕES CONTEXTUAIS DO PERSONAGEM CLICADO NO PALCO (HERÓI, ALIADO OU AMEAÇA — v66) -->
                <div id="arena-clicked-character-actions-bar" style="margin-top:6px;"></div>
                <!-- BARRA COMPACTA DE AMEAÇAS NO TABULEIRO + ECONOMIA DE AÇÕES + MODAL DE REAÇÃO IMEDIATA -->
                <div style="display:flex;justify-content:space-between;align-items:stretch;flex-wrap:wrap;gap:6px;margin-top:5px;">
                    <div id="arena-stage-threats-quickbar" style="flex:1.3;min-width:260px;"></div>
                    <div id="arena-turn-economy-hud" style="flex:1;min-width:240px;"></div>
                </div>
                <div id="arena-reaction-modal-box" style="display:none;margin-top:6px;"></div>

                <!-- HUD DINÂMICO DE COMBATE POR CATEGORIAS (ZERO POLUIÇÃO VISUAL — FUNCIONA NA TELA NORMAL E EM TELA CHEIA!) -->
                <div id="arena-dynamic-hud-dock" class="t20-dynamic-hud-shell" style="margin-top:6px;background:linear-gradient(180deg, rgba(14,19,31,0.97), rgba(7,10,18,0.99));border:2px solid var(--t20-gold);border-radius:11px;padding:8px 10px;box-shadow:0 8px 24px rgba(0,0,0,0.65);">
                    <!-- BARRA PRINCIPAL DE ABAS DINÂMICAS DO HUD -->
                    <div id="arena-dynamic-hud-tabs-bar" class="t20-hud-tabs-bar" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                        <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                            <button type="button" class="t20-hud-tab-btn active-hud-tab" data-hud-tab="ABA_ATAQUES" onclick="alternarAbaHudDinamicoArenaJS('ABA_ATAQUES')">
                                Atacar &amp; Hab.
                            </button>
                            <button type="button" id="btn-hud-tab-magias" class="t20-hud-tab-btn" data-hud-tab="ABA_MAGIAS" onclick="alternarAbaHudDinamicoArenaJS('ABA_MAGIAS')">
                                Magias &amp; +PM
                            </button>
                            <button type="button" class="t20-hud-tab-btn" data-hud-tab="ABA_MOVIMENTO" onclick="alternarAbaHudDinamicoArenaJS('ABA_MOVIMENTO')">
                                Mover &amp; Manobras
                            </button>
                            <button type="button" class="t20-hud-tab-btn" data-hud-tab="ABA_FICHA_COMPLETA" onclick="renderizarConsolePersonagemTelaCheiaArenaJS();alternarAbaHudDinamicoArenaJS('ABA_FICHA_COMPLETA')">
                                Ficha, Perícias &amp; Equip.
                            </button>
                            <button type="button" class="t20-hud-tab-btn" data-hud-tab="ABA_COMBO_MODS" onclick="alternarAbaHudDinamicoArenaJS('ABA_COMBO_MODS')">
                                Combo &amp; Situação
                            </button>
                            <button type="button" class="t20-hud-tab-btn" data-hud-tab="ABA_AMEACA" onclick="alternarAbaHudDinamicoArenaJS('ABA_AMEACA')">
                                Ameaça, Encontros &amp; ND
                            </button>
                            <button type="button" class="t20-hud-tab-btn" data-hud-tab="ABA_GRID_2D" onclick="alternarAbaHudDinamicoArenaJS('ABA_GRID_2D')">
                                Montarias &amp; Parceiros
                            </button>
                            <button type="button" class="t20-hud-tab-btn" data-hud-tab="ABA_OCULTA" onclick="alternarAbaHudDinamicoArenaJS('ABA_OCULTA')" title="Recolher gaveta para visualização limpa do palco">
                                ▾ Ocultar Gaveta
                            </button>
                        </div>
                        <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                            <button type="button" class="btn btn-save" style="margin:0;padding:6px 12px;background:#8C2323;color:#FFFFFF;font-size:11.5px;font-weight:900;width:auto;border:1.5px solid #FACC15;" onclick="encerrarTurnoJogadorArenaJS()">
                                ⏭Encerrar Turno Ameaça
                            </button>
                            <button type="button" class="btn btn-save" style="margin:0;padding:6px 10px;background:#FACC15;color:#1F1A17;font-size:11.5px;font-weight:800;width:auto;" onclick="simularCombateInteiroAnimado()">
                                ▶Auto-Duelo
                            </button>
                        </div>
                    </div>

                    <!-- GAVETA CONTEXTUAL DINÂMICA (EXIBE APENAS A CATEGORIA SELECIONADA!) -->
                    <div id="arena-dynamic-hud-drawer" style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(200,157,84,0.35);">
                        <!-- PANE 1: ATAQUES E HABILIDADES ATIVAS DA FICHA -->
                        <div class="t20-hud-pane" data-pane-id="ABA_ATAQUES" style="display:block;">
                            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(185px, 1fr));gap:6px;">
                                <button type="button" id="btn-arena-atq-padrao" class="btn btn-ai" style="margin:0;padding:7px 9px;font-size:11.5px;" onclick="executarAcaoCombateVisual('ATAQUE_PADRAO')">
                                    Agredir c/ Arma [Padrão — p. 233]
                                </button>
                                <button type="button" id="btn-arena-hab-classe" class="btn btn-ai" style="margin:0;padding:7px 9px;font-size:11.5px;background:linear-gradient(135deg, #9A3412, #C2410C);" onclick="executarAcaoCombateVisual('ATAQUE_ESPECIAL_COMBO')">
                                    Ataque Especial [Padrão — p. 65]
                                </button>
                                <button type="button" id="btn-arena-golpe-pessoal" class="btn btn-ai" style="margin:0;padding:7px 9px;font-size:11.5px;background:linear-gradient(135deg, #B45309, #D97706);display:none;" onclick="executarAcaoCombateVisual('GOLPE_PESSOAL')">
                                    Golpe Pessoal [Padrão — p. 66]
                                </button>
                                <button type="button" id="btn-arena-combate-defensivo" class="btn btn-ai" style="margin:0;padding:7px 9px;font-size:11.5px;background:linear-gradient(135deg, #065F46, #047857);display:none;" onclick="executarAcaoCombateVisual('COMBATE_DEFENSIVO_ATAQUE')">
                                    Combate Defensivo [-2 Atq/+5 Def]
                                </button>
                                <button type="button" id="btn-arena-hab-racial" class="btn btn-ai" style="margin:0;padding:7px 9px;font-size:11.5px;background:linear-gradient(135deg, #065F46, #059669);display:none;" onclick="executarAcaoCombateVisual('HABILIDADE_RACIAL_ATIVA')">
                                    Habilidade Racial Ativa
                                </button>
                                <button type="button" id="btn-arena-investida" class="btn btn-ai" style="margin:0;padding:7px 9px;font-size:11.5px;background:linear-gradient(135deg, #7C2D12, #B45309);" onclick="executarAcaoCombateVisual('INVESTIDA_COMPLETA')">
                                    Investida [Completa: +2 Atq/-2 Def]
                                </button>
                                <button type="button" id="btn-arena-executar-combo-total" class="btn btn-ai" style="margin:0;padding:7px 9px;font-size:11.5px;background:linear-gradient(135deg,#B45309,#DC2626);border:1.5px solid #FEF08A;" onclick="executarAcaoCombateVisual('COMBO_OFENSIVO_TOTAL')">
                                    Executar Combo Ofensivo!
                                </button>
                            </div>
                            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-top:6px;font-size:11px;color:#CBD5E1;">
                                <span>Dica: Use a aba <strong>Combo &amp; Situação</strong> para configurar habilidades acumuladas ou <strong>Ameaça</strong> para testar os ataques do monstro!</span>
                                <div style="display:flex;gap:10px;flex-wrap:wrap;">
                                    <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#B8B2A6;">
                                        <input type="checkbox" id="chk-arena-auto-reacao" style="width:auto;min-height:auto;"> Auto-Reação IA
                                    </label>
                                    <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#FDE68A;">
                                        <input type="checkbox" id="chk-arena-auto-passar-turno" style="width:auto;min-height:auto;"> Auto-Passar Turno
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- PANE 2: GRIMÓRIO ATIVO E APRIMORAMENTOS DE MAGIA -->
                        <div class="t20-hud-pane" data-pane-id="ABA_MAGIAS" style="display:none;">
                            <div id="arena-msg-sem-magias-hud" style="display:none;padding:8px 10px;background:rgba(30,41,59,0.7);border:1px solid #475569;border-radius:8px;font-size:11.5px;color:#CBD5E1;">
                                ℹEste personagem não possui magias cadastradas na ficha atual. Selecione uma classe conjuradora ou adicione magias na aba de Ficha!
                            </div>
                            <div id="arena-box-conjuracao-ficha" style="display:none;background:#171B24;border:1.5px solid #A855F7;border-radius:10px;padding:8px 10px;">
                                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:6px;">
                                    <div style="font-size:11.5px;font-weight:900;color:#E9D5FF;">
                                        GRIMÓRIO ATIVO DA FICHA &amp; SELETOR DE APRIMORAMENTOS (CAP. 4 — MAGIA, PP. 170–171):
                                    </div>
                                    <label id="lbl-arena-magia-acelerada" style="display:none;align-items:center;gap:5px;cursor:pointer;margin:0;font-size:11px;color:#D8B465;font-weight:800;">
                                        <input type="checkbox" id="chk-arena-magia-acelerada" onchange="atualizarPreviewAprimoramentoMagiaArenaJS()" style="width:auto;min-height:auto;"> Magia Acelerada (+4 PM: Ação Livre — p. 131)
                                    </label>
                                </div>
                                <div style="display:grid;grid-template-columns:1fr 1.25fr auto;gap:8px;align-items:end;">
                                    <div>
                                        <label style="color:#D8B4FE;font-size:10.5px;">1. Magia Conhecida na Ficha</label>
                                        <select id="arena-sel-magia-ficha" onchange="aoMudarMagiaSelecionadaArenaJS()" style="background:#11141C;color:#F8FAFC;border:1px solid rgba(201,155,66,0.30);min-height:34px;font-size:12px;"></select>
                                    </div>
                                    <div>
                                        <label style="color:#D8B465;font-size:10.5px;">2. Quantidade de Aprimoramentos (+PM até o Limite)</label>
                                        <select id="arena-sel-aprimoramento-pm" onchange="atualizarPreviewAprimoramentoMagiaArenaJS()" style="background:#11141C;color:#E8E5DC;border:1px solid rgba(201,155,66,0.35);min-height:34px;font-size:12px;"></select>
                                    </div>
                                    <div>
                                        <button type="button" id="btn-arena-conjurar-selecionada" class="btn btn-ai" style="margin:0;min-height:34px;padding:6px 12px;background:linear-gradient(135deg, #6D28D9, #9333EA);border:1.5px solid #FACC15;white-space:nowrap;font-size:12px;" onclick="conjurarMagiaComAprimoramentosArenaJS()">
                                            Conjurar Magia
                                        </button>
                                    </div>
                                </div>
                                <div id="arena-preview-magia-aprimorada" style="margin-top:6px;background:rgba(9,13,22,0.75);border-left:3px solid #C99B42;padding:6px 8px;border-radius:6px;font-size:11.5px;color:#F1F5F9;line-height:1.35;"></div>
                            </div>
                        </div>

                        <!-- PANE 3: MOVIMENTO, POSICIONAMENTO RÁPIDO E MANOBRAS -->
                        <div class="t20-hud-pane" data-pane-id="ABA_MOVIMENTO" style="display:none;">
                            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(175px, 1fr));gap:6px;margin-bottom:6px;">
                                <button type="button" id="btn-arena-mov-deslocar" class="btn btn-ai" style="margin:0;padding:7px;background:linear-gradient(135deg, #1E3A8A, #0284C7);font-size:11.5px;" onclick="executarAcaoCombateVisual('MOVIMENTO_POSICIONAR_FLANQUEAR')">
                                    Movimentar / Flanquear [Mov — p. 235]
                                </button>
                                <button type="button" class="btn btn-ai" style="margin:0;padding:7px;background:linear-gradient(135deg, #065F46, #059669);font-size:11.5px;" onclick="posicionarRapidoArena2DJS('AVANCAR_CAC')">
                                    Avançar Corpo a Corpo (1,5m)
                                </button>
                                <button type="button" class="btn btn-ai" style="margin:0;padding:7px;background:linear-gradient(135deg, #9A3412, #D97706);font-size:11.5px;" onclick="posicionarRapidoArena2DJS('FLANQUEAR_ALIADO')">
                                    Cercar c/ Aliado (+2 Flanco)
                                </button>
                                <button type="button" class="btn btn-ai" style="margin:0;padding:7px;background:linear-gradient(135deg, #1E40AF, #2563EB);font-size:11.5px;" onclick="posicionarRapidoArena2DJS('COBERTURA')">
                                    Ir p/ Cobertura (+5 Defesa)
                                </button>
                                <button type="button" id="btn-arena-mov-mirar" class="btn btn-ai" style="margin:0;padding:7px;background:linear-gradient(135deg, #1E40AF, #1D4ED8);font-size:11.5px;display:none;" onclick="executarAcaoCombateVisual('MOVIMENTO_MIRAR')">
                                    Mirar [Movimento — p. 235]
                                </button>
                                <button type="button" id="btn-arena-mov-item" class="btn btn-ai" style="margin:0;padding:7px;background:linear-gradient(135deg, #047857, #059669);font-size:11.5px;display:none;" onclick="executarAcaoCombateVisual('MOVIMENTO_POCAO_MANA')">
                                    Poção de Mana [Mov — p. 235]
                                </button>
                                <button type="button" id="btn-arena-surto-heroico" class="btn btn-ai" style="margin:0;padding:7px;background:linear-gradient(135deg, #9A3412, #EA580C);font-size:11.5px;display:none;" onclick="executarAcaoCombateVisual('SURTO_HEROICO_LIVRE')">
                                    Surto Heroico [5 PM: +1 Padrão]
                                </button>
                            </div>
                            <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                                <select id="sel-cap5-manobra" style="flex:1;min-width:220px;min-height:32px;padding:2px 8px;font-size:11.5px;background:#1E293B;color:#E8E5DC;border:1px solid var(--t20-gold);">
                                    <option value="Derrubar">Manobra: Derrubar (Caído: -5 Atq; -5 Def C.a.C — p. 234)</option>
                                    <option value="Agarrar">Manobra: Agarrar (Desprevenido -5 Def, Imóvel — p. 234)</option>
                                    <option value="Desarmar">Manobra: Desarmar (Derruba arma: -5 Atq/Dano — p. 234)</option>
                                    <option value="Empurrar">Manobra: Empurrar (Afasta 1,5m — p. 234)</option>
                                    <option value="Quebrar">Manobra: Quebrar (Dano na couraça: -2 Def — p. 234)</option>
                                </select>
                                <button type="button" class="btn btn-ai" style="width:auto;margin:0;padding:6px 12px;background:linear-gradient(135deg, #1E3A8A, #2563EB);font-size:11.5px;" onclick="executarAcaoCombateVisual('MANOBRA_DERRUBAR')">
                                    Executar Manobra [p. 234]
                                </button>
                                <button type="button" id="btn-arena-fintar" class="btn btn-ai" style="width:auto;margin:0;padding:6px 12px;background:linear-gradient(135deg, #701A75, #9333EA);font-size:11.5px;" onclick="executarAcaoCombateVisual('FINTAR_DESPREVENIDO')">
                                    Fintar (Alvo Desprev.) [p. 234]
                                </button>
                            </div>
                        </div>

                        <!-- PANE 3B: FICHA COMPLETA, ATRIBUTOS, PERÍCIAS CLICÁVEIS, POÇÕES E EQUIPAMENTO NA TELA CHEIA (v65) -->
                        <div class="t20-hud-pane" data-pane-id="ABA_FICHA_COMPLETA" style="display:none;">
                            <div id="arena-hud-ficha-completa-box"></div>
                        </div>

                        <!-- PANE 4: CONSTRUTOR DE COMBO E MODIFICADORES DE SITUAÇÃO CAP. 5 -->
                        <div class="t20-hud-pane" data-pane-id="ABA_COMBO_MODS" style="display:none;">
                            <div id="arena-row-habilidades-dinamicas" style="display:flex;flex-direction:column;gap:6px;">
                                <div id="arena-lbl-hab-especificas" style="font-size:11.5px;font-weight:900;color:#E8E5DC;">
                                    CONSTRUTOR DE COMBO OFENSIVO ACUMULÁVEL &amp; MODIFICADORES DO CAP. 5 (TABELA 5-1, P. 238):
                                </div>
                                <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;font-size:11px;background:rgba(9,13,22,0.72);padding:6px 8px;border-radius:7px;border:1px solid rgba(250,204,21,0.3);">
                                    <label id="lbl-chk-combo-hab-classe" style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#D8B465;font-weight:800;">
                                        <input type="checkbox" id="chk-combo-hab-classe" checked style="width:auto;min-height:auto;"> <span id="txt-chk-combo-hab-classe">Ataque Especial / Hab. Classe</span>
                                    </label>
                                    <label id="lbl-chk-combo-golpe-pessoal" style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#D8B465;font-weight:800;">
                                        <input type="checkbox" id="chk-combo-golpe-pessoal" checked style="width:auto;min-height:auto;"> <span>Golpe Pessoal</span>
                                    </label>
                                    <label id="lbl-chk-combo-atq-poderoso" style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#FCA5A5;font-weight:800;">
                                        <input type="checkbox" id="chk-combo-ataque-poderoso" style="width:auto;min-height:auto;"> <span>Ataque Poderoso (-2/+5)</span>
                                    </label>
                                    <label id="lbl-chk-combo-comb-def" style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#6EE7B7;font-weight:800;">
                                        <input type="checkbox" id="chk-combo-combate-defensivo" style="width:auto;min-height:auto;"> <span>Combate Defensivo (-2/+5 Def)</span>
                                    </label>
                                    <label id="lbl-chk-combo-atq-extra" style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#C4B5FD;font-weight:800;">
                                        <input type="checkbox" id="chk-combo-ataque-extra" checked style="width:auto;min-height:auto;"> <span>Ataque Extra (2 PM)</span>
                                    </label>
                                    <label id="lbl-chk-arma-natural" style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#FDE68A;font-weight:800;">
                                        <input type="checkbox" id="chk-minotauro-chifres" checked style="width:auto;min-height:auto;"> <span id="txt-chk-arma-natural">Arma Natural (1 PM)</span>
                                    </label>
                                </div>
                                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                                    <select id="arena-sel-modo-ae" style="width:auto;min-height:28px;padding:2px 6px;font-size:11px;background:#1E293B;color:#D8B465;border:1px solid #3B82F6;">
                                        <option value="ATAQUE">Ataque Especial: 100% no Ataque</option>
                                        <option value="DANO">Ataque Especial: 100% no Dano</option>
                                        <option value="DIVIDIDO" selected>Ataque Especial: Dividido (+B/2 Atq e Dano)</option>
                                    </select>
                                    <select id="arena-sel-golpe-pessoal" style="flex:1;min-width:220px;min-height:28px;padding:2px 6px;font-size:11px;background:#1E293B;color:#D8B465;border:1px solid var(--t20-gold);">
                                        <option value="BRUTAL_ELEM_PRECISO" selected>GP Padrão (4 PM): Brutal + Elemental (+2d6) + Preciso (2d20)</option>
                                        <option value="LETAL_DESTRUIDOR_BRUTAL_LENTO">GP Otimizado (4 PM): Destruidor + Letal + Brutal + Preciso</option>
                                        <option value="BRUTAL_PRECISO">GP Econômico (2 PM): Brutal + Preciso (2d20)</option>
                                        <option value="LETAL_DESTRUIDOR_PRECISO">GP Crítico (5 PM): Letal + Destruidor + Preciso</option>
                                        <option value="ATORDOANTE_PENETRANTE_BRUTAL">GP Controle (4 PM): Atordoante + Penetrante + Brutal</option>
                                        <option value="CONJURADOR_TOQUE_BRUTAL">GP Arcano (3 PM): Conjurador + Brutal</option>
                                    </select>
                                </div>
                                <div style="display:flex;gap:8px;flex-wrap:wrap;font-size:11px;color:#E2E8F0;align-items:center;padding-top:4px;border-top:1px dashed rgba(200,157,84,0.3);">
                                    <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#B8B2A6;">
                                        <input type="checkbox" id="chk-cap5-aliado-oposto" onchange="document.getElementById('chk-cap5-flanqueando').checked = this.checked; atualizarPlacarVisualArena();" style="width:auto;min-height:auto;"> Flanqueando (+2 CaC)
                                        <input type="checkbox" id="chk-cap5-flanqueando" onchange="atualizarPlacarVisualArena()" style="display:none;">
                                    </label>
                                    <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;">
                                        <input type="checkbox" id="chk-cap5-elevado" onchange="atualizarPlacarVisualArena()" style="width:auto;min-height:auto;"> Pos. Elevada (+2 Atq)
                                    </label>
                                    <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;">
                                        <input type="checkbox" id="chk-cap5-invisivel" onchange="atualizarPlacarVisualArena()" style="width:auto;min-height:auto;"> Invisível (+2 Atq)
                                    </label>
                                    <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#FCA5A5;">
                                        <input type="checkbox" id="chk-cap5-vulneravel" onchange="atualizarPlacarVisualArena()" style="width:auto;min-height:auto;"> Alvo Vulnerável (-2 Def)
                                    </label>
                                    <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#D8B465;">
                                        <input type="checkbox" id="chk-cap5-disparo-engajado" onchange="atualizarPlacarVisualArena()" style="width:auto;min-height:auto;"> Disparo Engajado (-5)
                                    </label>
                                    <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;color:#D8B465;">
                                        <input type="checkbox" id="chk-cap5-mira" onchange="atualizarPlacarVisualArena()" style="width:auto;min-height:auto;"> Ação Mirar Ativa
                                    </label>
                                    <label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;margin:0;">
                                        <input type="checkbox" id="chk-cap5-cobertura" onchange="atualizarPlacarVisualArena()" style="width:auto;min-height:auto;"> Cobertura (+5 Def)
                                    </label>
                                    <select id="sel-cap5-camuflagem" onchange="atualizarPlacarVisualArena()" style="width:auto;min-height:26px;padding:2px 6px;font-size:10.5px;background:#1E293B;color:#E2E8F0;border:1px solid #475569;">
                                        <option value="NENHUMA">Sem Camuflagem (0%)</option>
                                        <option value="LEVE_20">Camuflagem Leve (20%)</option>
                                        <option value="TOTAL_50">Camuflagem Total (50%)</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- PANE 5: AÇÕES ESPECIAIS DA AMEAÇA, CONSTRUTOR DE ENCONTROS E CALCULADORA DE ND -->
                        <div class="t20-hud-pane" data-pane-id="ABA_AMEACA" style="display:none;">
                            <div id="arena-creature-actions-bar" style="margin-bottom:8px;"></div>
                            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); gap:8px;">
                                <div style="background:rgba(0,0,0,0.35); padding:6px 8px; border-radius:8px; border:1px solid rgba(232,229,220,0.12);">
                                    <div style="font-size:11px; font-weight:800; color:#C99B42; margin-bottom:4px;">Encontros Mistos (Adicionar / Excluir Ameaças)</div>
                                    <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center;">
                                        <select id="arena-static-sel-add-criatura" style="flex:1; min-width:150px; min-height:30px; padding:2px 6px; font-size:11px; background:#090D16; color:#F8FAFC; border:1px solid #475569;"></select>
                                        <button type="button" class="btn btn-gold" style="width:auto; margin:0; min-height:30px; padding:3px 10px; font-size:11px;" onclick="adicionarCriaturaAoEncontroArenaJS(document.getElementById('arena-static-sel-add-criatura').value)">Adicionar</button>
                                        <button type="button" class="btn btn-danger" style="width:auto; margin:0; min-height:30px; padding:3px 10px; font-size:11px; background:#991B1B; border:1px solid #FCA5A5; color:#E8E5DC;" onclick="removerCriaturaDoEncontroArenaJS()">Excluir</button>
                                    </div>
                                </div>
                                <div style="background:rgba(0,0,0,0.35); padding:6px 8px; border-radius:8px; border:1px solid rgba(232,229,220,0.12);">
                                    <div style="font-size:11px; font-weight:800; color:#D8B465; margin-bottom:4px;">Calculadora de ND &amp; Tamanho Ocupado (1x1, 2x2, 3x3, 6x6)</div>
                                    <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center;">
                                        <select id="arena-calc-nd-valor" onchange="atualizarPreviewCalculadoraNDArenaJS()" style="width:auto; min-height:30px; padding:2px 6px; font-size:11px; background:#090D16; color:#D8B465; border:1px solid #D4AF37; font-weight:800;">
                                            <option value="1/4">ND 1/4</option><option value="1/3">ND 1/3</option><option value="1/2">ND 1/2</option>
                                            <option value="1">ND 1</option><option value="2">ND 2</option><option value="3">ND 3</option><option value="4">ND 4</option>
                                            <option value="5">ND 5</option><option value="6">ND 6</option><option value="7" selected>ND 7</option><option value="8">ND 8</option>
                                            <option value="9">ND 9</option><option value="10">ND 10</option><option value="11">ND 11</option><option value="12">ND 12</option>
                                            <option value="13">ND 13</option><option value="14">ND 14</option><option value="15">ND 15</option><option value="16">ND 16</option>
                                            <option value="17">ND 17</option><option value="18">ND 18</option><option value="19">ND 19</option><option value="20">ND 20</option>
                                        </select>
                                        <select id="arena-calc-nd-papel" onchange="atualizarPreviewCalculadoraNDArenaJS()" style="width:auto; min-height:30px; padding:2px 6px; font-size:11px; background:#090D16; color:#F8FAFC; border:1px solid #475569;">
                                            <option value="MANTER" selected>Papel: Manter</option>
                                            <option value="Solo">Solo</option><option value="Lacaio">Lacaio</option><option value="Especial">Especial</option>
                                        </select>
                                        <select id="arena-calc-nd-tamanho" onchange="atualizarPreviewCalculadoraNDArenaJS()" style="width:auto; min-height:30px; padding:2px 6px; font-size:11px; background:#090D16; color:#C99B42; border:1px solid #475569;">
                                            <option value="MANTER" selected>Tamanho: Original</option>
                                            <option value="PEQUENO">Pequeno (1x1)</option>
                                            <option value="MEDIO">Médio (1x1)</option>
                                            <option value="GRANDE">Grande (2x2 = 3m)</option>
                                            <option value="ENORME">Enorme (3x3 = 4,5m)</option>
                                            <option value="COLOSSAL">Colossal (6x6 = 9m)</option>
                                        </select>
                                        <button type="button" class="btn btn-gold" style="width:auto; margin:0; min-height:30px; padding:2px 8px; font-size:10.5px;" onclick="aplicarCalculadoraNDArenaJS(false)">Aplicar</button>
                                        <button type="button" class="btn btn-outline" style="width:auto; margin:0; min-height:30px; padding:2px 8px; font-size:10.5px; border-color:#E8E5DC !important; color:#E8E5DC !important;" onclick="aplicarCalculadoraNDArenaJS(true)">Todos</button>
                                    </div>
                                    <div id="arena-calc-nd-preview" style="font-size:10px; color:#CBD5E1; margin-top:4px;"></div>
                                </div>
                            </div>
                        </div>

                        <!-- PANE 6: GRID TÁTICO 2D INTERATIVO E MONTARIAS/PARCEIROS -->
                        <div class="t20-hud-pane" data-pane-id="ABA_GRID_2D" style="display:none;">
                            <div style="margin-bottom:6px; background:rgba(0,0,0,0.36); padding:6px 8px; border-radius:8px; border:1px solid rgba(16,185,129,0.4);">
                                <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                                    <span style="font-size:11px; font-weight:800; color:#C99B42;">Montaria &amp; Parceiro:</span>
                                    <select id="arena-sel-montaria" onchange="mudarMontariaOuParceiroGlobalJS('ARENA')" style="flex:1; min-width:155px; min-height:30px; padding:2px 6px; font-size:11px; background:#090D16; color:#D8B465; border:1px solid #D4AF37; font-weight:700;">
                                        <option value="NENHUMA" selected>Sem Montaria (1x1)</option>
                                        <option value="CAVALO_GUERRA">Cavalo de Guerra (Grande 2x2)</option>
                                        <option value="GRIFO">Grifo Real (Grande 2x2)</option>
                                        <option value="LOBO_CAVERNAS">Lobo das Cavernas (Grande 2x2)</option>
                                        <option value="GORLOGG">Gorlogg Selvagem (Grande 2x2)</option>
                                        <option value="LEAO_SAGRADO">Leão de Keenn (Grande 2x2)</option>
                                        <option value="DRAGAO_WYVERN">Wyvern / Dragão Menor (Enorme 3x3)</option>
                                    </select>
                                    <select id="arena-sel-patamar-montaria" onchange="mudarMontariaOuParceiroGlobalJS('ARENA')" style="width:auto; min-height:30px; padding:2px 6px; font-size:11px; background:#090D16; color:#F8FAFC; border:1px solid #475569;">
                                        <option value="INICIANTE" selected>Montaria: Iniciante</option>
                                        <option value="VETERANO">Montaria: Veterano</option>
                                        <option value="MESTRE">Montaria: Mestre</option>
                                    </select>
                                    <select id="arena-sel-parceiro" onchange="mudarMontariaOuParceiroGlobalJS('ARENA')" style="flex:1; min-width:155px; min-height:30px; padding:2px 6px; font-size:11px; background:#090D16; color:#C99B42; border:1px solid #0284C7; font-weight:700;">
                                        <option value="NENHUM" selected>Sem Parceiro</option>
                                        <option value="COMBATENTE">Combatente (+Atq/Flanco)</option>
                                        <option value="FORTAO">Fortão (+Dano CaC)</option>
                                        <option value="GUARDIAO">Guardião (+Def/Res)</option>
                                        <option value="ASSASSINO">Assassino (Flanco + Furtivo)</option>
                                        <option value="ATIRADOR">Atirador (+Dano Dist.)</option>
                                        <option value="ADEPTO">Adepto (-1 PM Magia)</option>
                                        <option value="DESTRUIDOR">Destruidor (+Dano Magia)</option>
                                        <option value="MAGIVOCADOR">Magivocador (+CD Magia)</option>
                                        <option value="MEDICO">Médico (Cura 1 PM)</option>
                                        <option value="VIGILANTE">Vigilante (+Iniciativa)</option>
                                    </select>
                                    <select id="arena-sel-patamar-parceiro" onchange="mudarMontariaOuParceiroGlobalJS('ARENA')" style="width:auto; min-height:30px; padding:2px 6px; font-size:11px; background:#090D16; color:#F8FAFC; border:1px solid #475569;">
                                        <option value="INICIANTE" selected>Parceiro: Iniciante</option>
                                        <option value="VETERANO">Parceiro: Veterano</option>
                                        <option value="MESTRE">Parceiro: Mestre</option>
                                    </select>
                                    <button type="button" class="btn btn-save" style="width:auto; margin:0; min-height:30px; padding:2px 8px; font-size:10.5px;" onclick="usarCuraParceiroMedicoArenaJS()">Cura Médico</button>
                                </div>
                                <div id="arena-resumo-montaria-parceiro" style="font-size:10px; color:#B8B2A6; margin-top:4px;"></div>
                            </div>
                            <div style="font-size:11px;color:#B8B2A6;">O <strong>Grid Tático 2D (120×120)</strong> agora está sempre visível logo abaixo desta barra de ações! Use o botão <strong>Ocultar/Mostrar Grid 2D</strong> no topo caso deseje recolhê-lo.</div>
                        </div>
                    </div>
                </div>
                <!-- SISTEMA DE GRID TÁTICO 2D (120x120) SEMPRE VISÍVEL NA ARENA (IGUAL À MESA ONLINE - v64) -->
                <div id="arena-tactical-2d-panel" style="margin-top:8px;display:none;"></div>

            <!-- PAINEL DUPLO DE STATUS (DENTRO DO SHELL DE TELA CHEIA PARA ACESSO INTEGRAL NO CELULAR!) -->
            <div class="arena-vs-grid" style="margin-top:10px;grid-template-columns:1fr 1fr;gap:12px;">
                <!-- CARD DO HERÓI -->
                <div id="arena-card-heroi" class="combatant-card" style="padding:10px 12px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div id="arena-svg-heroi" style="width:42px;height:42px;background:rgba(200,157,84,0.18);border:2px solid var(--t20-gold);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;"></div>
                            <div>
                                <div id="arena-nome-heroi" style="font-size:15px;font-weight:800;color:#E8E5DC;">Herói Atual</div>
                                <div id="arena-sub-heroi" style="font-size:11px;color:#CBD5E1;">Classe & Estilo</div>
                            </div>
                        </div>
                        <span id="arena-badge-def-heroi" class="quick-pill" style="background:#1E293B;font-size:12px;">Def 18</span>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px;">
                        <div>
                            <div style="font-size:10.5px;font-weight:700;color:#86EFAC;">PONTOS DE VIDA (PV)</div>
                            <div class="hp-bar-outer" style="margin:3px 0;">
                                <div id="arena-bar-pv-heroi" class="hp-bar-inner" style="width:100%;"></div>
                                <div id="arena-txt-pv-heroi" class="bar-label">63 / 63 PV</div>
                            </div>
                        </div>
                        <div>
                            <div style="font-size:10.5px;font-weight:700;color:#7DD3FC;">PONTOS DE MANA (PM)</div>
                            <div class="mp-bar-outer" style="margin:3px 0;">
                                <div id="arena-bar-pm-heroi" class="mp-bar-inner" style="width:100%;"></div>
                                <div id="arena-txt-pm-heroi" class="bar-label">18 / 18 PM</div>
                            </div>
                        </div>
                    </div>
                    <div id="arena-buffs-heroi" style="font-size:11px;color:#FDE68A;margin-top:4px;"></div>
                </div>

                <!-- CARD DA CRIATURA -->
                <div id="arena-card-criatura" class="combatant-card" style="padding:10px 12px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div id="arena-svg-criatura" style="width:42px;height:42px;background:rgba(239,68,68,0.18);border:2px solid #EF4444;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;"></div>
                            <div>
                                <div id="arena-nome-criatura" style="font-size:15px;font-weight:800;color:#FCA5A5;">Ameaça (ND 6)</div>
                                <div id="arena-sub-criatura" style="font-size:11px;color:#CBD5E1;">Tipo & Referência</div>
                            </div>
                        </div>
                        <span id="arena-badge-def-criatura" class="quick-pill" style="background:#3B0764;border-color:#C084FC;font-size:12px;" title="Defesa deduzida empiricamente através dos seus ataques">Def: ???</span>
                    </div>
                    <div style="margin-top:8px;">
                        <div style="font-size:10.5px;font-weight:700;color:#FCA5A5;">VITALIDADE & DANO SOFRIDO</div>
                        <div class="hp-bar-outer" style="margin:3px 0;">
                            <div id="arena-bar-pv-criatura" class="hp-bar-enemy" style="width:100%;"></div>
                            <div id="arena-txt-pv-criatura" class="bar-label">100% Vitalidade (0 dano sofrido)</div>
                        </div>
                    </div>
                    <div id="arena-fog-box" style="margin-top:5px;font-size:11px;color:#CBD5E1;display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;">
                        <span id="fog-def-est" style="display:none;"></span>
                        <span><strong>Resistência:</strong> <span id="fog-res-est">Não testada</span></span>
                        <span><strong>Dano Obs.:</strong> <span id="fog-dano-est">Aguardando turno</span></span>
                    </div>
                </div>
            </div>

        <!-- MESA VISUAL E DINÂMICA DE ROLAGEM DE DADOS 3D/SVG (DENTRO DA TELA CHEIA!) -->
        <div class="dice-felt-table">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;border-bottom:1px solid rgba(255,255,255,0.2);padding-bottom:8px;margin-bottom:8px;">
                <div>
                    <strong style="font-size:15px;color:#E8E5DC;">MESA VISUAL DE ROLAGEM DE DADOS (ANIMAÇÃO DINÂMICA 3D/SVG)</strong>
                    <div id="dice-banner-titulo" style="font-size:12px;color:#D1FAE5;">Clique em uma ação de combate acima ou nos dados abaixo para rolar com física visual!</div>
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:5px;">
                    <button type="button" class="quick-pill" style="cursor:pointer;background:#11141C;" onclick="rolarDadosLivresMesa('1d20', 'Teste de Perícia / Ataque Puro')">1d20</button>
                    <button type="button" class="quick-pill" style="cursor:pointer;background:#14532D;border-color:#C99B42;color:#ECFDF5;" onclick="rolarDadosLivresMesa('2d20', 'Golpe Pessoal Preciso / Concentração de Combate (2d20 — Escolhe o Melhor!)')">2d20 (Melhor Resultado)</button>
                    <button type="button" class="quick-pill" style="cursor:pointer;background:#11141C;" onclick="rolarDadosLivresMesa('2d6', 'Espada Montante / Marreta (2d6)')">2d6</button>
                    <button type="button" class="quick-pill" style="cursor:pointer;background:#11141C;" onclick="rolarDadosLivresMesa('3d6', 'Montante Aumentada (3d6)')">3d6</button>
                    <button type="button" class="quick-pill" style="cursor:pointer;background:#11141C;" onclick="rolarDadosLivresMesa('6d6', 'Bola de Fogo Base (6d6)')">6d6</button>
                    <button type="button" class="quick-pill" style="cursor:pointer;background:#11141C;" onclick="rolarDadosLivresMesa('10d6', 'Bola de Fogo Aprimorada (10d6)')">10d6</button>
                    <button type="button" id="btn-dado-arma-atual" class="quick-pill" style="cursor:pointer;background:#7F1D1D;border-color:#E8E5DC;color:#E8E5DC;" onclick="rolarDanoArmaEquipadaLivreJS()">Dano da Arma Equipada</button>
                    <button type="button" class="quick-pill" style="cursor:pointer;background:#11141C;" onclick="rolarDadosLivresMesa('1d10', 'Alabarda / Espada Sagrada (1d10)')">1d10</button>
                    <button type="button" class="quick-pill" style="cursor:pointer;background:#11141C;" onclick="rolarDadosLivresMesa('1d12', 'Machado de Guerra / Raio Poderoso (1d12)')">1d12</button>
                </div>
            </div>

            <div id="dice-tray-visual" class="dice-tray-row">
                <div style="color:#B8B2A6;font-size:13px;">Os dados poligonais SVG aparecerão girando aqui a cada rolagem de ataque, resistência e dano!</div>
            </div>
            <div id="dice-math-breakdown" style="background:rgba(0,0,0,0.45);border:1px solid rgba(200,157,84,0.5);border-radius:8px;padding:10px 12px;text-align:center;font-size:13.5px;color:#E8E5DC;font-weight:700;">
                Aguardando a primeira rolagem de dados...
            </div>
        </div>

        <!-- LOG VISUAL DO COMBATE PASSO A PASSO + APRENDIZADO POR REFORÇO CAIXA-PRETA -->
        <div class="sheet-columns">
            <div class="panel">
                <div class="panel-header">Registro Visual Turno a Turno do Combate Atual</div>
                <div class="panel-body">
                    <div id="arena-combat-log" style="max-height:340px;overflow-y:auto;font-size:12.5px;line-height:1.45;">
                        <div class="item-row">Inicie o combate clicando em um dos botões de ação acima!</div>
                    </div>
                </div>
            </div>

            <div class="panel">
                <details class="t20-collapsible" style="margin:0;border:none;">
                <summary style="background:#1E6F43;color:#FFF;padding:10px 14px;font-weight:800;border-radius:8px;cursor:pointer;">Abrir Laboratório de Aprendizado por Reforço Caixa-Preta (POMDP / Treinar Agente RL)</summary>
                <div class="panel-body">
                    <div style="font-size:12px;color:var(--t20-muted);margin-bottom:10px;">
                        Escolha abaixo <strong>qual Tipo de Aventureiro</strong> o Agente de RL deve treinar contra a ameaça atual (permitindo tanto <strong>Competição Geral</strong> entre todas as classes quanto <strong>Otimização Específica</strong> de Conjuradores Arcanos, Conjuradores Divinos, Marciais Pesados, Arqueiros/Ágeis, Tanques ou a Classe Atual da sua ficha):
                    </div>
                    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(210px, 1fr));gap:8px;margin-bottom:10px;background:rgba(15,23,42,0.78);padding:10px;border-radius:8px;border:1px solid rgba(52,211,153,0.4);">
                        <div>
                            <label style="color:#6EE7B7;font-size:11px;font-weight:800;">1. Tipo de Aventureiro / Escopo da Build</label>
                            <select id="arena-sel-tipo-aventureiro-rl" style="min-height:34px;padding:4px 8px;font-size:12px;background:#11141C;color:#ECFDF5;border:1px solid rgba(201,155,66,0.30);">
                                <option value="GERAL_EQUILIBRADO">Build Geral — Todos os Tipos (12 Arquétipos)</option>
                                <option value="MULTICLASSE_OTIMIZADA">Apenas Builds Multiclasse (Cap. 1, p. 34 — Guerreiro/Bárbaro, Guerreiro/Paladino, Magus, etc.)</option>
                                <option value="CONJURADORES_TODOS">Apenas Conjuradores (Arcanista, Clérigo, Druida & Bardo)</option>
                                <option value="CONJURADOR_ARCANO_ESPECIFICO">Específico — Conjurador Arcano (Mago, Feiticeiro & Bruxo)</option>
                                <option value="CONJURADOR_DIVINO_ESPECIFICO">Específico — Conjurador Divino (Clérigo, Druida & Bardo)</option>
                                <option value="MARCIAIS_TODOS">Apenas Combatentes Marciais (Corpo a Corpo & Distância)</option>
                                <option value="MARCIAL_PESADO_ESPECIFICO">Específico — Marcial Pesado (Guerreiro, Bárbaro & Lutador)</option>
                                <option value="MARCIAL_AGIL_DISTANCIA">Específico — Marcial Ágil & Distância (Caçador, Bucaneiro, Ladino & Inventor)</option>
                                <option value="TANQUE_BALUARTE_ESPECIFICO">Específico — Tanque & Baluarte (Cavaleiro, Paladino, Guerreiro & Clérigo)</option>
                                <option value="HIBRIDO_ESPECIALISTA">Específico — Híbrido & Especialista (Paladino, Bardo, Inventor & Nobre)</option>
                                <option value="CLASSE_ATUAL_FICHA">Otimizar a Classe Atual da Minha Ficha (6 Variações)</option>
                            </select>
                        </div>
                        <div>
                            <label style="color:#D8B465;font-size:11px;font-weight:800;">2. Filtro de Raça no Treinamento</label>
                            <select id="arena-sel-raca-rl" style="min-height:34px;padding:4px 8px;font-size:12px;background:#11141C;color:#E0F2FE;border:1px solid #38BDF8;">
                                <option value="AUTO_OTIMA">Raça Ideal por Sinergia (Padrão)</option>
                                <option value="MANTER_RACA_FICHA">Manter a Raça Atual da Minha Ficha</option>
                                <option value="Humano">Apenas Humano</option>
                                <option value="Minotauro">Apenas Minotauro</option>
                                <option value="Elfo">Apenas Elfo</option>
                                <option value="Qareen">Apenas Qareen</option>
                                <option value="Anão">Apenas Anão</option>
                                <option value="Golem">Apenas Golem</option>
                                <option value="Osteon">Apenas Osteon</option>
                                <option value="Kliren">Apenas Kliren</option>
                                <option value="Trog">Apenas Trog</option>
                                <option value="Goblin">Apenas Goblin</option>
                                <option value="Lefou">Apenas Lefou</option>
                                <option value="Dahllan">Apenas Dahllan</option>
                                <option value="Medusa">Apenas Medusa</option>
                                <option value="Suraggel (Aggelus)">Apenas Suraggel (Aggelus)</option>
                                <option value="Suraggel (Sulfure)">Apenas Suraggel (Sulfure)</option>
                            </select>
                        </div>
                        <div>
                            <label style="color:#D8B465;font-size:11px;font-weight:800;">3. Doutrina Tática da Recompensa Q</label>
                            <select id="arena-sel-doutrina-rl" style="min-height:34px;padding:4px 8px;font-size:12px;background:#11141C;color:#E8E5DC;border:1px solid rgba(201,155,66,0.35);">
                                <option value="EQUILIBRADA_COMPLETA">Equilibrada (Burst + Reações Campo de Força/Durão)</option>
                                <option value="EXPLOSAO_DANO_BURST">Explosão de Dano / Menor TTK (Magia Acelerada / GP)</option>
                                <option value="SOBREVIVENCIA_MITIGACAO">Sobrevivência Máxima (Prioriza maior % de PV final)</option>
                            </select>
                        </div>
                    </div>
                    <button type="button" class="btn btn-ai" style="background:linear-gradient(135deg, #1E6F43, #15803D);margin-bottom:12px;" onclick="treinarAgenteRLCaixaPretaArenaJS()">
                        Treinar Agente RL no Escopo Selecionado (Descobrir & Aplicar Build Campeã!)
                    </button>
                    <div id="arena-rl-resultados">
                        <div class="item-row">Selecione o <strong>Tipo de Aventureiro</strong> acima (ex.: <em>Apenas Conjuradores</em>, <em>Conjurador Arcano</em> ou <em>Build Geral</em>) e clique no botão verde para treinar!</div>
                    </div>
                </div></details>
            </div>
        </div>
        </div><!-- FIM #arena-combat-screen-shell -->
        </div><!-- FIM .arena-stage -->
    </section>


        <!-- ABA 7: MESAS ONLINE (GRUPO MULTIPLAYER & CO-OP BOSS) -->
        <section id="tab-mesa-online" class="tab-section {'active' if aba_ativa == 'tab-mesa-online' else ''}">
            <div class="card" style="border:1px solid rgba(56,189,248,0.45); background:linear-gradient(145deg, rgba(15,23,42,0.96), rgba(9,13,22,0.98));">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <div>
                        <div class="card-title" style="margin-bottom:2px; color:#38bdf8;">Mesas Online em Grupo (Co-op Multiplayer &amp; Mestre)</div>
                        <div style="font-size:0.78rem; color:var(--text-muted);">
                            Forme um grupo de <strong>1 a 6 Heróis</strong> para enfrentar as <strong>83 Ameaças Oficiais do Cap. 7</strong> com <strong>100% dos PV e Dano integrais do livro</strong> (p. 282), Fila de Iniciativa compartilhada, sinergias de grupo (<em>Oração</em>, <em>Inspiração</em>, <em>Provocar</em>, <em>Curar Ferimentos</em>) e sincronização multi-dispositivo!
                        </div>
                    </div>
                    <div id="mesa-online-badge-conexao" style="padding:6px 12px; border-radius:999px; font-size:0.75rem; font-weight:800; background:rgba(56,189,248,0.14); border:1px solid rgba(56,189,248,0.45); color:#38bdf8;">
                        Verificando Modo de Conexão...
                    </div>
                </div>

                <!-- MATRIZ COMPARATIVA: ARQUIVO HTML PURO VS SERVIDORES -->
                <details style="margin-top:10px; background:rgba(0,0,0,0.35); border:1px solid rgba(255,255,255,0.1); border-radius:10px; padding:8px 12px;">
                    <summary style="cursor:pointer; font-size:0.8rem; font-weight:700; color:#fbbf24;">
                        Paridade de Capacidades: Abrir pelo Arquivo .HTML Local vs. Servidor Python / Google Apps Script (Clique para expandir)
                    </summary>
                    <div style="margin-top:8px; font-size:0.76rem; color:var(--text-main); overflow-x:auto;">
                        <table style="width:100%; border-collapse:collapse; font-size:0.74rem;">
                            <thead>
                                <tr style="background:rgba(255,255,255,0.06); text-align:left;">
                                    <th style="padding:6px; border:1px solid rgba(255,255,255,0.1);">Capacidade do Sistema</th>
                                    <th style="padding:6px; border:1px solid rgba(255,255,255,0.1); color:#fbbf24;">Arquivo .HTML Direto (<code>file://</code>)</th>
                                    <th style="padding:6px; border:1px solid rgba(255,255,255,0.1); color:#38bdf8;">Google Apps Script Web App</th>
                                    <th style="padding:6px; border:1px solid rgba(255,255,255,0.1); color:#4ade80;">Servidor Python SQL (WAL / PostgreSQL)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);"><strong>Motor de Regras, Multiclasse, MCTS, CSP e Deep RL</strong></td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">100% Idêntico (Roda na CPU/RAM do navegador)</td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">100% Idêntico</td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">100% Idêntico (+ Motor Python Nativo)</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);"><strong>Catálogo Oficial (83 Ameaças, Magias, Poderes, 4+ Visuais)</strong></td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">100% Embutido Offline</td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">100% Embutido + Planilha</td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">100% Embutido + Tabelas SQLite/Postgres</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);"><strong>Salvamento de Fichas &amp; Mesas entre Celular e PC</strong></td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">Isolado no navegador local (<code>localStorage</code>) + Exportação por Token/JSON</td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">Sincronizado na Nuvem Google (Abas <code>Fichas_Salvas</code> e <code>Mesas_Online</code>)</td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">Sincronizado via API REST (<code>/api/fichas</code> e <code>/api/mesas</code>)</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);"><strong>Mesas Online em Grupo (Multiplayer)</strong></td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">Tempo real entre abas do mesmo aparelho (<code>BroadcastChannel</code>) + <strong>Código de Sincronização (WhatsApp/Discord)</strong> entre aparelhos</td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">Tempo real via Nuvem entre celulares/PCs em qualquer rede</td>
                                    <td style="padding:6px; border:1px solid rgba(255,255,255,0.08);">Baixa latência (2.5s polling + SQLite WAL ACID) na rede ou VPS</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </details>

                <!-- CONTROLES DA SALA / LOBBY -->
                <div class="form-grid" style="margin-top:12px;">
                    <div class="form-group">
                        <label>Código da Sala (Compartilhe com o Grupo)</label>
                        <input type="text" id="mesa-input-codigo" value="VALKARIA-2026" style="font-weight:800; color:#38bdf8; letter-spacing:0.5px; text-transform:uppercase;">
                    </div>
                    <div class="form-group">
                        <label>Nome da Campanha / Mesa</label>
                        <input type="text" id="mesa-input-nome" value="Coração de Rubi — Incursão Co-op">
                    </div>
                    <div class="form-group">
                        <label>Nome do Mestre / Líder da Sala</label>
                        <input type="text" id="mesa-input-mestre" value="Bruno (Mestre T20)">
                    </div>
                    <div class="form-group">
                        <label>Chefe / Ameaça do Encontro (Cap. 7, p. 282 — Status 100% Integrais de Grupo)</label>
                        <select id="mesa-select-chefe" onchange="trocarChefeMesaOnlineJS(this.value)"></select>
                    </div>
                </div>

                <!-- BARRA DE AÇÕES RÁPIDAS DO LOBBY -->
                <div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:10px;">
                    <button type="button" class="btn btn-gold" style="flex:1; min-width:210px;" onclick="entrarNaMesaComFichaAtualJS()">
                        Entrar / Atualizar Minha Ficha na Mesa
                    </button>
                    <button type="button" class="btn btn-outline" style="flex:1; min-width:220px; border-color:#4ade80; color:#4ade80;" onclick="gerarGrupoEquilibrado4HeroisMesaJS()">
                        Gerar Party Equilibrada (4 Heróis: Tanque + DPS + Arcano + Clérigo)
                    </button>
                    <button type="button" class="btn btn-outline" style="flex:1; min-width:170px; border-color:#38bdf8; color:#38bdf8;" onclick="sincronizarMesaOnlineManualJS()">
                        Sincronizar Sala Agora
                    </button>
                    <button type="button" class="btn btn-outline" style="flex:1; min-width:170px; border-color:#c084fc; color:#c084fc;" onclick="recomendarChefeIdealGrupoMesaJS()">
                        Recomendar Chefe p/ Nível do Grupo
                    </button>
                </div>

                <!-- SINCRONIZAÇÃO POR TOKEN (PARA QUEM ABRE O ARQUIVO HTML PURO PELO WHATSAPP/DISCORD) -->
                <div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:8px; align-items:center; background:rgba(255,255,255,0.03); padding:8px 10px; border-radius:8px; border:1px dashed rgba(255,255,255,0.14);">
                    <span style="font-size:0.74rem; color:var(--text-muted);"><strong>Jogando via Arquivo .HTML Offline?</strong> Sincronize com amigos pelo WhatsApp/Discord:</span>
                    <button type="button" class="btn btn-outline" style="padding:5px 10px; font-size:0.73rem;" onclick="copiarTokenConviteMesaOnlineJS()">
                        Copiar Código de Estado da Mesa
                    </button>
                    <button type="button" class="btn btn-outline" style="padding:5px 10px; font-size:0.73rem;" onclick="importarTokenConviteMesaOnlinePromptJS()">
                        Colar Código Recebido do Mestre/Grupo
                    </button>
                    <label style="font-size:0.73rem; color:#94a3b8; display:flex; align-items:center; gap:4px; margin-left:auto;">
                        <input type="checkbox" id="mesa-chk-autopolling" checked onchange="alternarAutoPollingMesaOnlineJS(this.checked)">
                        Auto-Sync (2.5s)
                    </label>
                </div>
            </div>

            
            <!-- PALCO & MAPA TÁTICO 2D DA MESA ONLINE (MOVIMENTAÇÃO, FLANQUEAMENTO, CONDIÇÕES & MÚLTIPLAS CRIATURAS) -->
            <div class="card t20-combat-screen-shell" id="mesa-combat-screen-shell" style="margin-top:12px; border:1px solid rgba(201,155,66,0.28); background:linear-gradient(160deg, #121624 0%, #090C14 100%); padding:12px;">
                <!-- BARRA SUPERIOR FIXA DE TELA CHEIA DA MESA ONLINE (STATUS DO PERSONAGEM SELECIONADO + ÚLTIMA ROLAGEM + SAIR) -->
                <div id="mesa-fullscreen-sticky-bar">
                    <div id="mesa-fullscreen-sticky-hero-stats" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;font-size:11px;"></div>
                    <div id="mesa-fullscreen-live-roll-pill" style="background:#151821;border:1px solid rgba(201,155,66,0.35);color:#E8E5DC;padding:3px 8px;border-radius:6px;font-size:11px;font-weight:800;">
                        Clique em qualquer personagem no mapa para ver e executar suas ações únicas!
                    </div>
                    <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;">
                        <button type="button" class="btn-roll-inline" style="background:#047857;border-color:#C99B42;color:#ECFDF5;font-weight:900;padding:4px 8px;" onclick="executarAcaoHeroiSelecionadoMesaRapidoJS('CURAR_ALIADO')">Curar</button>
                        <button type="button" class="btn-roll-inline" style="background:#B45309;border-color:#D8B465;color:#E8E5DC;font-weight:900;padding:4px 8px;" onclick="executarAcaoHeroiSelecionadoMesaRapidoJS('BUFF_GRUPO')">Buff Grupo</button>
                        <button type="button" class="btn-roll-inline" style="background:#334155;border-color:#94A3B8;color:#F8FAFC;font-weight:900;padding:4px 8px;" onclick="avancarProximoTurnoMesaOnlineJS()">⏭Próx. Turno</button>
                        <button type="button" class="btn-roll-inline" style="background:#991B1B;border-color:#FCA5A5;color:#E8E5DC;font-weight:900;padding:5px 11px;font-size:11.5px;" onclick="alternarTelaCheiaCombateT20JS('MESA')">SAIR DA TELA CHEIA</button>
                    </div>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:8px;">
                    <div>
                        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;"><div class="card-title" style="margin:0; color:#D8B465;">Palco &amp; Mapa Tático 2D da Mesa Online (Clique no Personagem p/ Ações &amp; Clique no Chão p/ Mover)</div><button type="button" id="btn-mesa-top-mobile-fullscreen" class="btn btn-gold" style="width:auto;margin:0;min-height:34px;padding:5px 12px;font-size:12px;font-weight:900;background:linear-gradient(135deg, #059669, #047857);color:#E8E5DC;border:2px solid #FACC15;" onclick="alternarTelaCheiaCombateT20JS('MESA')">JOGAR EM TELA CHEIA (MESA ONLINE)</button></div>
                        <div style="font-size:0.75rem; color:#CBD5E1;">
                            Clique em um quadrado <code>(1,5m)</code> do grid para mover o herói selecionado • Posicione 2 heróis em lados opostos de uma ameaça para ativar <strong>Flanquear (+2 Ataque CaC &amp; Furtivo, p. 239)</strong>!
                        </div>
                    </div>
                    <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                        <select id="mesa-select-qtd-criaturas" onchange="alterarQuantidadeCriaturasMesaOnlineJS(this.value)" style="width:auto; min-height:34px; padding:4px 8px; font-size:0.75rem; border-radius:8px; background:#11141C; color:#C99B42; border:1px solid #4ADE80; font-weight:800;">
                            <option value="1" selected>1x Ameaça (Chefe Solo)</option>
                            <option value="2">2x Ameaças (Dupla Tática)</option>
                            <option value="3">3x Ameaças (Matilha / Bando)</option>
                            <option value="4">4x Ameaças (Esquadrão / Horda)</option>
                        </select>
                        <button type="button" class="btn btn-outline" style="width:auto; min-height:34px; margin:0; padding:4px 10px; font-size:0.74rem; border-color:#E8E5DC !important; color:#D8B465 !important;" onclick="posicionarGrupoFlanqueamentoAutomaticoMesaJS()">
                            Posicionar Grupo p/ Flanquear Alvo (+2 Atq)
                        </button>
                    </div>
                </div>

                <!-- PALCO ILUSTRADO 2D DE GRUPO + CONDIÇÕES VISUAIS -->
                <div id="mesa-2d-stage-svg-box" style="width:100%; border-radius:10px; overflow:hidden; border:1px solid rgba(201,155,66,0.32); background:#070A12; margin-bottom:8px;"></div>
                <!-- BARRA DE AÇÕES RÁPIDAS & EXCLUSÃO DE AMEAÇAS COLADA AO PALCO VISUAL DA MESA ONLINE (v58) -->
                <div id="mesa-clicked-character-actions-bar" style="margin-bottom:8px;"></div>
                <div id="mesa-stage-quick-actions-dock"></div>
                <!-- GRID TÁTICO 2D LOGO ABAIXO DO PALCO E DAS AÇÕES -->
                <div id="mesa-2d-grid-interactive-box" style="margin-bottom:10px;"></div>

                <!-- GRID TÁTICO 2D DE POSICIONAMENTO (10x5 QUADRADOS DE 1,5m) E CONDIÇÕES -->
                
                <!-- 3. TREINADOR POR APRENDIZADO POR REFORÇO DE GRUPO (MULTI-AGENT CO-OP RL & MELHOR PARTY BUILD) -->
                <div style="background:#171B24; border:1px solid rgba(201,155,66,0.28); padding:10px 12px; border-radius:10px; border:1.5px solid #10B981; margin-bottom:10px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:6px;">
                        <div>
                            <div style="font-size:12.5px; font-weight:900; color:#C99B42;">
                                Aprendizado por Reforço de Grupo (Multi-Agent Co-op RL — Otimizador da Melhor Party)
                            </div>
                            <div style="font-size:10.5px; color:#B8B2A6;">
                                Simula centenas de combates cooperativos contra o encontro atual da Mesa (respeitando NDs customizados, múltiplas criaturas e flanqueamento) e monta o <strong>Pódio Top 3 Melhores Grupos (4 Heróis)</strong>!
                            </div>
                        </div>
                    </div>
                    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                        <select id="mesa-rl-doutrina-grupo" style="flex:1; min-width:200px; min-height:36px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#E8E5DC; border:1px solid rgba(201,155,66,0.30); font-weight:700;">
                            <option value="TODOS_RANKING" selected>Testar Todas as Doutrinas e Eleger o Melhor Grupo</option>
                            <option value="TRINDADE_CLASSICA">Quarteto Clássico (Tanque + Striker Flanqueador + Arcano + Clérigo)</option>
                            <option value="BLITZ_FLANQUEAMENTO">Blitzkrieg de Flanqueamento &amp; Crítico (Dupla Flanqueadora + Bardo + Arcano)</option>
                            <option value="FORTALEZA_IMORTAL">Fortaleza Imortal (Paladino Égide + Cavaleiro Baluarte + Clérigo + Arcanista)</option>
                            <option value="SUPREMACIA_ARCANA">Supremacia de Área &amp; Distância (Guardião + 2 Conjuradores AoE + Arqueiro)</option>
                        </select>
                        <select id="mesa-rl-multiclasse" style="width:auto; min-height:36px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#F8FAFC; border:1px solid #475569;">
                            <option value="AUTO_MCTS" selected>Multiclasse: IA Decide Melhor Sinergia</option>
                            <option value="SEM_MULTICLASSE">Classes Puras (Sem Multiclasse)</option>
                            <option value="FORCAR_MULTICLASSE_OTIMA">Forçar Multiclasse Otimizada</option>
                        </select>
                        <button type="button" class="btn btn-save" style="width:auto; margin:0; min-height:36px; padding:6px 14px; font-size:12px; font-weight:900; background:linear-gradient(135deg,#059669,#10B981); border:1.5px solid #A7F3D0;" onclick="treinarMelhorGrupoRLMesaOnlineJS()">
                            Treinar &amp; Eleger Melhor Grupo (RL)
                        </button>
                    </div>
                    <div id="mesa-rl-podium-results-box" style="margin-top:8px;"></div>
                </div>


                <!-- GAVETA RETRÁTIL DE FERRAMENTAS DO MESTRE, CALCULADORA DE ND, MONTARIAS E IA DE GRUPO (SEM POLUIR A MESA!) -->
                <details class="t20-collapsible" style="margin-top:8px;">
                    <summary style="padding:8px 12px;font-size:12px;color:#D8B465;font-weight:800;">Abrir Ferramentas do Mestre, Encontros Múltiplos, Calculadora de ND &amp; Montarias</summary>
                    <div class="collapsible-body" style="padding:10px;">
<!-- BARRA PERSISTENTE DE ENCONTROS ILIMITADOS, CALCULADORA DE ND & TREINADOR RL DE GRUPO DA MESA ONLINE (SELECTS ESTÁTICOS NUNCA FECHAM SOZINHOS!) -->
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:10px; margin-bottom:10px;">
                    <!-- 1. CONSTRUTOR DE ENCONTRO MISTO ILIMITADO -->
                    <div style="background:rgba(15,23,42,0.85); padding:9px 10px; border-radius:10px; border:1px solid rgba(56,189,248,0.4);">
                        <div style="font-size:11.5px; font-weight:800; color:#C99B42; margin-bottom:6px;">
                            Adicionar Criaturas ao Encontro da Mesa (Sem Limite)
                        </div>
                        <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                            <select id="mesa-static-sel-add-criatura" style="flex:1; min-width:180px; min-height:34px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#F8FAFC; border:1px solid #475569;"></select>
                            <button type="button" class="btn btn-gold" style="width:auto; margin:0; min-height:34px; padding:4px 12px; font-size:11.5px;" onclick="adicionarCriaturaAoEncontroMesaOnlineJS(document.getElementById('mesa-static-sel-add-criatura').value)">
                                Adicionar
                            </button>
                            <button type="button" class="btn btn-danger" style="width:auto; margin:0; min-height:34px; padding:4px 12px; font-size:11.5px; background:#991B1B; border:1px solid #FCA5A5; color:#E8E5DC;" onclick="removerCriaturaDoEncontroMesaOnlineJS()">
                                Excluir Ameaça
                            </button>
                            <button type="button" class="btn-roll-inline" style="background:#0284C7;border-color:#C99B42;padding:6px 10px;" onclick="alternarModoVisibilidadePalco2DJS()">
                                Sprites / Tokens
                            </button>
                        </div>
                    </div>

                    <!-- 2. CALCULADORA OFICIAL DE ND NA MESA ONLINE -->
                    <div style="background:rgba(15,23,42,0.85); padding:9px 10px; border-radius:10px; border:1px solid rgba(250,204,21,0.45);">
                        <div style="font-size:11.5px; font-weight:800; color:#D8B465; margin-bottom:6px;">
                            Calculadora de ND da Mesa (Reescalona PV, Defesa, Ataque, Dano e CD — p. 323)
                        </div>
                        <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                            <select id="mesa-calc-nd-valor" onchange="atualizarPreviewCalculadoraNDMesaJS()" style="width:auto; min-height:34px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#D8B465; border:1px solid #D4AF37; font-weight:800;">
                                
                            <option value="1/4">ND 1/4 (Iniciante · Lacaio)</option>
                            <option value="1/3">ND 1/3 (Iniciante · Lacaio)</option>
                            <option value="1/2">ND 1/2 (Iniciante)</option>
                            <option value="1">ND 1 (Iniciante)</option>
                            <option value="2">ND 2 (Iniciante)</option>
                            <option value="3">ND 3 (Iniciante)</option>
                            <option value="4">ND 4 (Iniciante)</option>
                            <option value="5">ND 5 (Veterano)</option>
                            <option value="6">ND 6 (Veterano)</option>
                            <option value="7" selected>ND 7 (Veterano)</option>
                            <option value="8">ND 8 (Veterano)</option>
                            <option value="9">ND 9 (Veterano)</option>
                            <option value="10">ND 10 (Veterano)</option>
                            <option value="11">ND 11 (Campeão)</option>
                            <option value="12">ND 12 (Campeão)</option>
                            <option value="13">ND 13 (Campeão)</option>
                            <option value="14">ND 14 (Campeão)</option>
                            <option value="15">ND 15 (Campeão)</option>
                            <option value="16">ND 16 (Campeão)</option>
                            <option value="17">ND 17 (Lenda)</option>
                            <option value="18">ND 18 (Lenda)</option>
                            <option value="19">ND 19 (Lenda)</option>
                            <option value="20">ND 20 (Lenda)</option>

                            </select>
                            <select id="mesa-calc-nd-papel" onchange="atualizarPreviewCalculadoraNDMesaJS()" style="width:auto; min-height:34px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#F8FAFC; border:1px solid #475569;">
                                <option value="MANTER" selected>Papel: Manter</option>
                                <option value="Solo">Solo</option>
                                <option value="Lacaio">Lacaio</option>
                                <option value="Especial">Especial</option>
                            </select>
                            <select id="mesa-calc-nd-tamanho" onchange="atualizarPreviewCalculadoraNDMesaJS()" style="width:auto; min-height:34px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#C99B42; border:1px solid #475569;">
                                <option value="MANTER" selected>Tamanho: Manter</option>
                                <option value="PEQUENO">Pequeno (1x1)</option>
                                <option value="MEDIO">Médio (1x1)</option>
                                <option value="GRANDE">Grande (2x2)</option>
                                <option value="ENORME">Enorme (3x3)</option>
                                <option value="COLOSSAL">Colossal (6x6)</option>
                            </select>
                            <button type="button" class="btn btn-gold" style="width:auto; margin:0; min-height:34px; padding:4px 10px; font-size:11px;" onclick="aplicarCalculadoraNDMesaOnlineJS(false)">
                                Aplicar no Foco
                            </button>
                            <button type="button" class="btn btn-outline" style="width:auto; margin:0; min-height:34px; padding:4px 10px; font-size:11px; border-color:#E8E5DC !important; color:#E8E5DC !important;" onclick="aplicarCalculadoraNDMesaOnlineJS(true)">
                                Aplicar em Todos
                            </button>
                        </div>
                        <div id="mesa-calc-nd-preview" style="font-size:10.5px; color:#CBD5E1; margin-top:5px;"></div>
                    </div>
                </div>

                <!-- 4. MONTARIAS & PARCEIROS DO HERÓI SELECIONADO NA MESA ONLINE (CAP. 6, P. 260-263) -->
                <div style="background:#171B24; padding:9px 12px; border-radius:10px; border:1px solid rgba(212,175,55,0.45); margin-bottom:10px;">
                    <div style="font-size:11.5px; font-weight:800; color:#D8B465; margin-bottom:6px;">
                        Montaria &amp; Parceiro do Herói Selecionado na Mesa (Aplica Espaço 2x2/3x3, +1 Mov, Flanqueamento, Defesa e Dados Extras)
                    </div>
                    <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                        <select id="mesa-sel-montaria" onchange="mudarMontariaOuParceiroGlobalJS('MESA')" style="flex:1; min-width:170px; min-height:34px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#D8B465; border:1px solid #D4AF37; font-weight:700;">
                            
                            <option value="NENHUMA" selected>Sem Montaria (A pé · Espaço 1x1)</option>
                            <option value="CAVALO_GUERRA">Cavalo de Guerra (Grande 2x2 · Desl. 15m + Investida)</option>
                            <option value="GRIFO">Grifo Real (Grande 2x2 · Voo 18m + Dano CaC)</option>
                            <option value="LOBO_CAVERNAS">Lobo das Cavernas / Trobo (Grande 2x2 · +Res &amp; Derrubar)</option>
                            <option value="GORLOGG">Gorlogg Selvagem (Grande 2x2 · +1d6 a +3d6 Dano CaC)</option>
                            <option value="LEAO_SAGRADO">Leão de Keenn / Montaria Sagrada (Grande 2x2 · +Def &amp; +Dano)</option>
                            <option value="DRAGAO_WYVERN">Wyvern / Dragão Menor (Enorme 3x3 · Voo 18m +Def &amp; Fogo)</option>

                        </select>
                        <select id="mesa-sel-patamar-montaria" onchange="mudarMontariaOuParceiroGlobalJS('MESA')" style="width:auto; min-height:34px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#F8FAFC; border:1px solid #475569;">
                            <option value="INICIANTE" selected>Montaria: Iniciante</option>
                            <option value="VETERANO">Montaria: Veterano</option>
                            <option value="MESTRE">Montaria: Mestre</option>
                        </select>
                        <select id="mesa-sel-parceiro" onchange="mudarMontariaOuParceiroGlobalJS('MESA')" style="flex:1; min-width:170px; min-height:34px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#C99B42; border:1px solid #0284C7; font-weight:700;">
                            
                            <option value="NENHUM" selected>Sem Parceiro Aliado</option>
                            <option value="COMBATENTE">Combatente (+2/+4 Ataque, Dano &amp; Flanqueia no Mestre)</option>
                            <option value="FORTAO">Fortão (+1d8 / +1d12 / +3d6 Dano Corpo a Corpo)</option>
                            <option value="GUARDIAO">Guardião (+2 / +3 / +4 Defesa e +2 Resistências)</option>
                            <option value="ASSASSINO">Assassino (Flanqueia o Alvo +2 Atq &amp; +1d6 a +2d8 Furtivo)</option>
                            <option value="ATIRADOR">Atirador (+1d6 / +1d10 / +2d8 Dano à Distância)</option>
                            <option value="ADEPTO">Adepto (-1 PM no Custo de Magias)</option>
                            <option value="DESTRUIDOR">Destruidor (+1d6 / +2d6 / +4d6 Dano Elemental em Magias)</option>
                            <option value="MAGIVOCADOR">Magivocador (+1/+2 CD das Magias e Dano Mágico)</option>
                            <option value="MEDICO">Médico (Cura 1d8+1 / 3d8+3 / 6d8+6 PV por 1 PM)</option>
                            <option value="VIGILANTE">Vigilante (+2/+4/+6 Iniciativa e Esquiva Sobrenatural)</option>

                        </select>
                        <select id="mesa-sel-patamar-parceiro" onchange="mudarMontariaOuParceiroGlobalJS('MESA')" style="width:auto; min-height:34px; padding:4px 8px; font-size:11.5px; background:#090D16; color:#F8FAFC; border:1px solid #475569;">
                            <option value="INICIANTE" selected>Parceiro: Iniciante</option>
                            <option value="VETERANO">Parceiro: Veterano</option>
                            <option value="MESTRE">Parceiro: Mestre</option>
                        </select>
                    </div>
                    <div id="mesa-resumo-montaria-parceiro" style="font-size:10.5px; color:#B8B2A6; margin-top:5px;"></div>
                </div>
                    </div>
                </details>


            </div>

            <!-- PAINEL DO CHEFE DE GRUPO E FILA DE INICIATIVA COMPARTILHADA -->
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(310px, 1fr)); gap:12px; margin-top:12px;">
                <!-- CARD DO CHEFE (100% INTEGRAL DO LIVRO) -->
                <div class="card" style="border:1px solid rgba(239,68,68,0.45); background:linear-gradient(160deg, rgba(40,12,18,0.9), rgba(15,18,28,0.96));">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">
                        <div>
                            <span style="font-size:0.68rem; text-transform:uppercase; letter-spacing:1px; color:#f87171; font-weight:800;">AMEAÇA DE GRUPO (STATUS 100% INTEGRAIS DO CAP. 7)</span>
                            <h3 id="mesa-boss-nome" style="margin:2px 0 4px 0; font-size:1.15rem; color:#fecaca;">Dragão Jovem</h3>
                            <div id="mesa-boss-subtitulo" style="font-size:0.75rem; color:#fca5a5;">ND 7 • Solo • Patamar Veterano</div>
                        </div>
                        <div style="text-align:right;">
                            <div style="font-size:0.72rem; color:#fde047; font-weight:800;" id="mesa-rodada-badge">Rodada 1</div>
                            <button type="button" class="btn btn-outline" style="padding:4px 8px; font-size:0.7rem; margin-top:4px;" onclick="reiniciarCombateGrupoMesaOnlineJS()">Resetar Chefe &amp; Rolar Iniciativa</button>
                        </div>
                    </div>

                    <!-- BARRA DE PV DO CHEFE -->
                    <div style="margin-top:10px;">
                        <div style="display:flex; justify-content:space-between; font-size:0.76rem; font-weight:800; margin-bottom:4px;">
                            <span>PV do Chefe (Escala Grupo 4 Jogadores)</span>
                            <span id="mesa-boss-pv-texto">280 / 280 PV (100%)</span>
                        </div>
                        <div style="width:100%; height:14px; background:rgba(0,0,0,0.55); border-radius:999px; overflow:hidden; border:1px solid rgba(239,68,68,0.4);">
                            <div id="mesa-boss-pv-bar" style="width:100%; height:100%; background:linear-gradient(90deg, #dc2626, #ef4444, #f97316); transition:width 0.3s ease;"></div>
                        </div>
                    </div>

                    <!-- MÉTRICAS OFICIAIS DO CHEFE -->
                    <div id="mesa-boss-metricas-grid" style="display:grid; grid-template-columns:repeat(4, 1fr); gap:6px; margin-top:10px; font-size:0.73rem; text-align:center;"></div>

                    <!-- CONTROLES DO MESTRE PARA O CHEFE -->
                    <div style="margin-top:10px; padding-top:8px; border-top:1px solid rgba(255,255,255,0.1); display:flex; flex-wrap:wrap; gap:6px;">
                        <button type="button" class="btn btn-danger" style="flex:1; min-width:145px; font-size:0.75rem; padding:7px 10px;" onclick="executarTurnoDoChefeMesaOnlineJS('FOCO_TANQUE')">
                            Ataque do Chefe (No Alvo/Tanque)
                        </button>
                        <button type="button" class="btn btn-outline" style="flex:1; min-width:145px; font-size:0.75rem; padding:7px 10px; border-color:#f97316; color:#fdba74;" onclick="executarTurnoDoChefeMesaOnlineJS('AREA_GRUPO')">
                            Habilidade de Área / Sopro (Todo o Grupo)
                        </button>
                    </div>
                </div>

                <!-- FILA DE INICIATIVA E BUFFS DE GRUPO ATIVOS -->
                <div class="card" style="border:1px solid rgba(212,175,55,0.4);">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div class="card-title" style="margin:0;">Fila de Iniciativa &amp; Sinergias Ativas</div>
                        <button type="button" class="btn btn-outline" style="padding:4px 10px; font-size:0.73rem;" onclick="avancarProximoTurnoMesaOnlineJS()">
                            ⏭Próximo Turno da Iniciativa
                        </button>
                    </div>
                    <div id="mesa-buffs-grupo-box" style="margin-top:8px; padding:8px; border-radius:8px; background:rgba(212,175,55,0.08); border:1px solid rgba(212,175,55,0.25); font-size:0.75rem;">
                        <strong>Buffs Coletivos Ativos no Grupo:</strong> Nenhum buff de grupo ativo. Use <em>Oração</em>, <em>Inspiração</em> ou <em>Benção</em>!
                    </div>
                    <div id="mesa-iniciativa-lista" style="margin-top:10px; display:flex; flex-direction:column; gap:6px; max-height:220px; overflow-y:auto;"></div>
                </div>
            </div>

            <!-- GRID DE HERÓIS DO GRUPO (CARDS INTERATIVOS DE CADA JOGADOR) -->
            <div class="card" style="margin-top:12px;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                    <div class="card-title" style="margin:0;">Heróis na Mesa Online (<span id="mesa-count-herois">0</span>/6 Jogadores)</div>
                    <div style="font-size:0.75rem; color:var(--text-muted);">
                        Cada jogador pode executar sua ação de turno, ativar buffs para todo o grupo ou curar aliados feridos!
                    </div>
                </div>
                <div id="mesa-herois-grid" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(270px, 1fr)); gap:10px; margin-top:10px;"></div>
            </div>

            <!-- ROLADOR DE DADOS COMPARTILHADO & LOG TÁTICO MULTIPLAYER -->
            <div class="card" style="margin-top:12px;">
                <div class="card-title" style="margin-bottom:8px;">Rolador de Dados da Mesa &amp; Chat Tático Compartilhado</div>
                <div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:10px;">
                    <button type="button" class="btn btn-outline" style="padding:5px 10px; font-size:0.75rem;" onclick="rolarDadoCompartilhadoMesaJS('1d20', 'Teste de Perícia (1d20)')">1d20</button>
                    <button type="button" class="btn btn-outline" style="padding:5px 10px; font-size:0.75rem; border-color:#fbbf24; color:#fbbf24;" onclick="rolarDadoCompartilhadoMesaJS('2d20_melhor', '2d20 (Melhor Resultado)')">2d20 (Melhor)</button>
                    <button type="button" class="btn btn-outline" style="padding:5px 10px; font-size:0.75rem;" onclick="rolarDadoCompartilhadoMesaJS('1d8+4', 'Dano Arma (1d8+4)')">1d8+4</button>
                    <button type="button" class="btn btn-outline" style="padding:5px 10px; font-size:0.75rem;" onclick="rolarDadoCompartilhadoMesaJS('2d6+6', 'Dano Pesado (2d6+6)')">2d6+6</button>
                    <button type="button" class="btn btn-outline" style="padding:5px 10px; font-size:0.75rem; border-color:#4ade80; color:#4ade80;" onclick="rolarDadoCompartilhadoMesaJS('2d8+2', 'Curar Ferimentos (2d8+2)')">2d8+2 (Cura)</button>
                    <button type="button" class="btn btn-outline" style="padding:5px 10px; font-size:0.75rem; border-color:#f87171; color:#f87171;" onclick="rolarDadoCompartilhadoMesaJS('6d6', 'Bola de Fogo (6d6)')">6d6 (Magia)</button>
                    <div style="display:flex; flex:1; min-width:220px; gap:6px;">
                        <input type="text" id="mesa-chat-input" placeholder="Digite uma mensagem tática ou ação para o grupo..." style="flex:1; padding:6px 10px; font-size:0.78rem;">
                        <button type="button" class="btn btn-gold" style="padding:6px 12px; font-size:0.75rem;" onclick="enviarMensagemChatMesaOnlineJS()">Enviar</button>
                    </div>
                </div>
                <div id="mesa-log-eventos" style="background:rgba(0,0,0,0.45); border:1px solid rgba(255,255,255,0.1); border-radius:10px; padding:10px; max-height:280px; overflow-y:auto; font-family:monospace; font-size:0.76rem; display:flex; flex-direction:column; gap:5px;"></div>
            </div>
        </section>

        <!-- ABA 8: SISTEMA SEPARADO DE MOVIMENTO, ALCANCE & VIABILIDADE ESPACIAL (v88) -->
        <section id="tab-movimento" class="tab-section {'active' if aba_ativa == 'tab-movimento' else ''}">
            <div class="card" style="background:linear-gradient(135deg,#18121E,#111827);border:2px solid var(--t20-gold);padding:16px;border-radius:12px;">
                <h2 style="margin:0 0 6px 0;color:#FCD34D;">Simulador de Movimento, Alcance &amp; Viabilidade em Mapa Real</h2>
                <p style="margin:0 0 12px 0;font-size:13px;color:#CBD5E1;">
                    Sistema independente do otimizador intrínseco: inicia em <b>Alcance Curto (9 m)</b>. Combatentes à distância/conjuradores buscam sempre a <b>distância máxima efetiva</b> (respeitando recarga de armas de fogo/bestas), enquanto combatentes corpo a corpo buscam <b>adjacência (1,5 m ou 3 m com haste)</b>.
                </p>
                <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:end;margin-bottom:14px;background:rgba(0,0,0,0.28);padding:10px;border-radius:8px;">
                    <label style="font-size:12px;color:#E2E8F0;display:flex;flex-direction:column;gap:4px;">
                        Perfil do Alvo
                        <select id="mov-sel-alvo" onchange="renderizarAbaMovimentoV88JS()" style="padding:6px 10px;border-radius:6px;background:#11141C;color:#F8FAFC;border:1px solid #475569;">
                            <option value="CORPO_9M">Combatente Corpo a Corpo (9 m)</option>
                            <option value="AGIL_12M">Escaramuçador Ágil (12 m)</option>
                            <option value="LENTO_6M">Brutamontes Lento (6 m)</option>
                            <option value="ATIRADOR_9M">Atirador / Conjurador (recua 9 m)</option>
                        </select>
                    </label>
                    <label style="font-size:12px;color:#E2E8F0;display:flex;flex-direction:column;gap:4px;">
                        Tamanho do Mapa
                        <select id="mov-sel-mapa" onchange="renderizarAbaMovimentoV88JS()" style="padding:6px 10px;border-radius:6px;background:#11141C;color:#F8FAFC;border:1px solid #475569;">
                            <option value="30">Sala / Corredor (30 m)</option>
                            <option value="45" selected>Arena Padrão (45 m)</option>
                            <option value="60">Campo Aberto (60 m)</option>
                        </select>
                    </label>
                    <label style="font-size:12px;color:#E2E8F0;display:flex;flex-direction:column;gap:4px;">
                        Rodadas
                        <select id="mov-sel-rodadas" onchange="renderizarAbaMovimentoV88JS()" style="padding:6px 10px;border-radius:6px;background:#11141C;color:#F8FAFC;border:1px solid #475569;">
                            <option value="4">4 rodadas</option>
                            <option value="6" selected>6 rodadas</option>
                            <option value="8">8 rodadas</option>
                        </select>
                    </label>
                    <button type="button" class="btn btn-ai" onclick="renderizarAbaMovimentoV88JS()" style="width:auto;padding:8px 14px;margin:0;">
                        ▶ Simular Viabilidade Espacial
                    </button>
                </div>
                <div id="movimento-v88-resultado"></div>
            </div>
        </section>

    </main>

<!-- BARRA DE NAVEGAÇÃO INFERIOR ESTILO APP DE CELULAR (6 ABAS) -->
<nav class="bottom-nav" aria-label="Navegação móvel">
    <button id="btn-tab-ficha" data-tab-target="tab-ficha" type="button" class="nav-btn {'active' if aba_ativa == 'tab-ficha' else ''}" onclick="mostrarAba('tab-ficha')"><span>Ficha</span></button>
    <button id="btn-tab-arena" data-tab-target="tab-arena" type="button" class="nav-btn {'active' if aba_ativa == 'tab-arena' else ''}" onclick="mostrarAba('tab-arena');inicializarArenaVisualSeNecessario();"><span>Arena</span></button>
    <button id="btn-tab-mesa-online" data-tab-target="tab-mesa-online" type="button" class="nav-btn {'active' if aba_ativa == 'tab-mesa-online' else ''}" onclick="mostrarAba('tab-mesa-online');inicializarAbaMesaOnlineUI();"><span>Mesas</span></button>
    <button id="btn-tab-arvore" data-tab-target="tab-arvore" type="button" class="nav-btn {'active' if aba_ativa == 'tab-arvore' else ''}" onclick="mostrarAba('tab-arvore')"><span>Análise</span></button>
    <button id="btn-tab-ia" data-tab-target="tab-ia" type="button" class="nav-btn {'active' if aba_ativa == 'tab-ia' else ''}" onclick="mostrarAba('tab-ia')"><span>Otimizador</span></button>
    <button id="btn-tab-manual" data-tab-target="tab-manual" type="button" class="nav-btn {'active' if aba_ativa == 'tab-manual' else ''}" onclick="mostrarAba('tab-manual')"><span>Editor</span></button>
    <button id="btn-tab-chat" data-tab-target="tab-chat" type="button" class="nav-btn {'active' if aba_ativa == 'tab-chat' else ''}" onclick="mostrarAba('tab-chat')"><span>Assistente</span></button>
    <button id="btn-tab-movimento" data-tab-target="tab-movimento" type="button" class="nav-btn {'active' if aba_ativa == 'tab-movimento' else ''}" onclick="mostrarAba('tab-movimento');if(window.T20Engine&&window.T20Engine.renderMovementTab)window.T20Engine.renderMovementTab();else if(typeof renderizarAbaMovimentoV88JS==='function')renderizarAbaMovimentoV88JS();"><span>Movimento</span></button>
</nav>
</body>
</html>"""


class ServidorGUIWebPython:
    """
    Servidor Web Mobile-First em Python puro. Escuta em `0.0.0.0` para permitir
    acesso imediato tanto no próprio computador quanto pelo navegador do celular via Wi-Fi.
    """
    def __init__(self, facade: Tormenta20Facade, host: str = "0.0.0.0", porta: int = 8765) -> None:
        self.facade = facade
        self.host = host
        self.porta = porta

    @staticmethod
    def descobrir_ip_rede_local() -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def processar_post(self, caminho: str, dados_form: Dict[str, List[str]]) -> str:
        def primeiro(chave: str, padrao: str = "") -> str:
            vals = dados_form.get(chave, [])
            return vals[0] if vals else padrao

        if caminho == "/otimizar_ia":
            nome = primeiro("nome", "Herói Otimizado (IA)")
            nivel = int(primeiro("nivel", "6") or 6)
            arquetipo = primeiro("arquetipo", "Dano Marcial")
            iteracoes = int(primeiro("iteracoes", "120") or 120)
            fix_r = primeiro("fixar_raca", "AUTO")
            fix_c = primeiro("fixar_classe", "AUTO")
            fix_o = primeiro("fixar_origem", "AUTO")
            fix_d = primeiro("fixar_deus", "AUTO")

            ficha_otim = self.facade.otimizador_ia.otimizar(
                nome=nome,
                jogador="MCTS_CSP_Optimizer",
                nivel=nivel,
                arquetipo=arquetipo,
                iteracoes_mcts=iteracoes,
                fixar_raca=None if fix_r == "AUTO" else fix_r,
                fixar_classe=None if fix_c == "AUTO" else fix_c,
                fixar_origem=None if fix_o == "AUTO" else fix_o,
                fixar_deus=None if fix_d == "AUTO" else fix_d,
            )
            self.facade.ficha_atual = ficha_otim
            # Após otimizar com IA, abre diretamente na aba da Árvore de Escolhas (ou Ficha)
            return self.facade.pagina_web_completa(
                f"Ficha e Árvore geradas pelo algoritmo CSP + MCTS ({iteracoes} iterações, Score {ficha_otim.pontuacao_mcts:.1f})!",
                aba_ativa="tab-ficha",
            )

        if caminho == "/atualizar_manual":
            atributos_dict = {
                sigla: int(primeiro(f"atr_{sigla}", "0") or 0)
                for sigla in ATRIBUTOS_NOMES
            }
            livres = [x.strip().upper() for x in primeiro("livres", "FOR,DES,CON").split(",") if x.strip()]
            ficha_man = self.facade.construir_ficha_manual(
                nome=primeiro("nome", "Aventureiro Manual"),
                jogador=primeiro("jogador", "Jogador"),
                nivel=int(primeiro("nivel", "1") or 1),
                nome_raca=primeiro("raca", "Humano"),
                nome_classe=primeiro("classe", "Guerreiro"),
                nome_origem=primeiro("origem", "Soldado"),
                nome_deus=primeiro("deus", "Nenhum"),
                atributos_base=atributos_dict,
                escolhas_livres=livres,
                pericias_nomes=dados_form.get("pericias", []),
                poderes_ids=dados_form.get("poderes", []),
                nome_arma=primeiro("arma", "Nenhum"),
                nome_armadura=primeiro("armadura", "Nenhum"),
                nome_escudo=primeiro("escudo", "Nenhum"),
                itens_extras_ids=dados_form.get("itens_extras", []),
                magias_ids=dados_form.get("magias", []),
            )
            return self.facade.pagina_web_completa(
                f"Ficha '{ficha_man.nome}' atualizada manualmente e validada pelo motor CSP!",
                aba_ativa="tab-ficha",
            )

        if caminho == "/salvar":
            id_salvo = self.facade.repositorio_personagens.salvar(self.facade.ficha_atual)
            return self.facade.pagina_web_completa(
                f"Ficha '{self.facade.ficha_atual.nome}' salva no banco SQLite (tormenta20.db) com ID #{id_salvo}!",
                aba_ativa="tab-ficha",
            )

        return self.facade.pagina_web_completa()

    def iniciar(self, abrir_navegador: bool = True) -> None:
        servidor_ref = self

        class Handler(BaseHTTPRequestHandler):
            def _enviar_json(self, status_code: int, payload: Any) -> None:
                corpo = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                self.send_response(status_code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type")
                self.send_header("Content-Length", str(len(corpo)))
                self.end_headers()
                self.wfile.write(corpo)

            def do_OPTIONS(self) -> None:
                self._enviar_json(204, {})

            def do_GET(self) -> None:
                try:
                    parsed = urllib.parse.urlparse(self.path)
                    if parsed.path == "/api/health":
                        wal_mode = servidor_ref.facade.db.conn.execute("PRAGMA journal_mode;").fetchone()[0]
                        fichas = servidor_ref.facade.repositorio_personagens.listar_para_api_rest()
                        self._enviar_json(200, {
                            "status": "ok",
                            "sqlite_journal_mode": wal_mode,
                            "itens_catalogo": len(servidor_ref.facade.catalogo.listar_itens()),
                            "ameacas_cap7": len(CATALOGO_AMEACAS_CAP7),
                            "fichas_salvas": len(fichas),
                        })
                        return
                    if parsed.path == "/api/fichas":
                        fichas = servidor_ref.facade.repositorio_personagens.listar_para_api_rest()
                        self._enviar_json(200, {"ok": True, "fichas": fichas})
                        return
                    if parsed.path == "/api/mesas":
                        qs = urllib.parse.parse_qs(parsed.query)
                        cod = qs.get("codigo", [""])[0].strip()
                        if cod:
                            mesa = servidor_ref.facade.repositorio_personagens.obter_mesa_online(cod)
                            if mesa:
                                self._enviar_json(200, {"ok": True, "mesa": mesa})
                            else:
                                self._enviar_json(404, {"ok": False, "erro": f"Sala {cod} não encontrada."})
                        else:
                            mesas = servidor_ref.facade.repositorio_personagens.listar_mesas_online()
                            self._enviar_json(200, {"ok": True, "mesas": mesas})
                        return
                    msg = ""
                    aba = "tab-ficha"
                    if parsed.path == "/carregar":
                        qs = urllib.parse.parse_qs(parsed.query)
                        id_str = qs.get("id", [""])[0]
                        if id_str.isdigit():
                            f_carregada = servidor_ref.facade.repositorio_personagens.carregar(int(id_str))
                            if f_carregada:
                                servidor_ref.facade.ficha_atual = f_carregada
                                msg = f"Ficha #{id_str} ({f_carregada.nome}) carregada do banco SQLite!"
                    corpo = servidor_ref.facade.pagina_web_completa(msg, aba_ativa=aba).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(corpo)))
                    self.end_headers()
                    self.wfile.write(corpo)
                except Exception as exc:
                    self._enviar_json(500, {"ok": False, "erro": str(exc)})

            def do_POST(self) -> None:
                try:
                    parsed = urllib.parse.urlparse(self.path)
                    tamanho = int(self.headers.get("Content-Length", "0"))
                    bruto = self.rfile.read(tamanho).decode("utf-8")
                    if parsed.path == "/api/fichas":
                        registro = json.loads(bruto or "{}")
                        id_sql = servidor_ref.facade.repositorio_personagens.salvar_payload_json_externo(registro)
                        total = len(servidor_ref.facade.repositorio_personagens.listar_para_api_rest())
                        self._enviar_json(200, {"ok": True, "id_sql": id_sql, "totalFichas": total})
                        return
                    if parsed.path == "/api/mesas":
                        payload_mesa = json.loads(bruto or "{}")
                        mesa_salva = servidor_ref.facade.repositorio_personagens.salvar_ou_atualizar_mesa_online(payload_mesa)
                        self._enviar_json(200, {"ok": True, "mesa": mesa_salva})
                        return
                    dados = urllib.parse.parse_qs(bruto, keep_blank_values=True)
                    corpo = servidor_ref.processar_post(self.path, dados).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(corpo)))
                    self.end_headers()
                    self.wfile.write(corpo)
                except Exception as exc:
                    self._enviar_json(400, {"ok": False, "erro": str(exc)})

            def do_DELETE(self) -> None:
                try:
                    parsed = urllib.parse.urlparse(self.path)
                    if parsed.path == "/api/fichas":
                        qs = urllib.parse.parse_qs(parsed.query)
                        id_val = qs.get("id", [""])[0]
                        ok = servidor_ref.facade.repositorio_personagens.excluir_por_id(id_val)
                        self._enviar_json(200, {"ok": ok})
                        return
                    self._enviar_json(404, {"ok": False, "erro": "Rota não encontrada"})
                except Exception as exc:
                    self._enviar_json(500, {"ok": False, "erro": str(exc)})

            def log_message(self, format: str, *args: Any) -> None:
                return

        class ReusableThreadingHTTPServer(ThreadingHTTPServer):
            allow_reuse_address = True
            daemon_threads = True

        Path("ficha_tormenta20_mobile.html").write_text(
            self.facade.pagina_web_completa("App Mobile-First Pronto (Funciona Online e Offline)!", aba_ativa="tab-ficha"),
            encoding="utf-8"
        )
        httpd = ReusableThreadingHTTPServer((self.host, self.porta), Handler)
        ip_lan = self.descobrir_ip_rede_local()
        print("\n" + "=" * 88)
        print(" INTERFACE MOBILE-FIRST & DESKTOP INICIADA COM SUCESSO!")
        print("=" * 88)
        print(f"  * Acesso neste dispositivo : http://127.0.0.1:{self.porta}")
        print(f"  * Acesso no Celular (Wi-Fi): http://{ip_lan}:{self.porta}")
        print("  * Pressione Ctrl+C para encerrar o servidor.")
        print("=" * 88)
        if abrir_navegador:
            threading.Timer(0.4, lambda: webbrowser.open(f"http://127.0.0.1:{self.porta}")).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            httpd.server_close()


def iniciar_janela_desktop_qt_qss(facade: Tormenta20Facade) -> bool:
    QtWidgets = None
    for modulo_qt in ("PyQt6.QtWidgets", "PySide6.QtWidgets", "PyQt5.QtWidgets"):
        try:
            QtWidgets = __import__(modulo_qt, fromlist=["QApplication"])
            break
        except ImportError:
            continue
    if QtWidgets is None:
        return False

    app = QtWidgets.QApplication(sys.argv)
    app.setStyleSheet(FolhaEstiloTemaTormenta20.gerar_qss_qt())

    janela = QtWidgets.QMainWindow()
    janela.setWindowTitle("Tormenta20 — Ficha & Árvore de Escolhas MCTS + CSP [Qt QSS]")
    janela.resize(1400, 880)

    central = QtWidgets.QWidget()
    layout_principal = QtWidgets.QHBoxLayout(central)

    painel_esq = QtWidgets.QVBoxLayout()
    box_ia = QtWidgets.QGroupBox("Otimizar com IA (CSP + MCTS) e Gerar Árvore")
    form_ia = QtWidgets.QFormLayout(box_ia)
    in_nome = QtWidgets.QLineEdit(facade.ficha_atual.nome)
    in_nivel = QtWidgets.QSpinBox()
    in_nivel.setRange(1, 20)
    in_nivel.setValue(facade.ficha_atual.nivel)
    cb_arq = QtWidgets.QComboBox()
    cb_arq.addItems(["Dano Marcial", "Tanque / Defesa", "Conjurador Arcano", "Suporte Divino"])
    btn_otimizar = QtWidgets.QPushButton("Otimizar & Mostrar Árvore MCTS/CSP")
    form_ia.addRow("Nome:", in_nome)
    form_ia.addRow("Nível:", in_nivel)
    form_ia.addRow("Arquétipo:", cb_arq)
    form_ia.addRow(btn_otimizar)
    painel_esq.addWidget(box_ia)

    abas_qt = QtWidgets.QTabWidget()
    visor_ficha = QtWidgets.QTextBrowser()
    visor_arvore = QtWidgets.QTextBrowser()
    abas_qt.addTab(visor_ficha, "Ficha Tormenta20")
    abas_qt.addTab(visor_arvore, "Árvore de Escolhas (MCTS + CSP)")

    css_inline = f"<style>{FolhaEstiloTemaTormenta20.gerar_css_web()}</style>"

    def atualizar_visores() -> None:
        visor_ficha.setHtml(css_inline + facade.renderizador_html.renderizar(facade.ficha_atual))
        visor_arvore.setHtml(css_inline + facade.renderizador_arvore_html.renderizar_arvore(facade.ficha_atual))

    def acao_otimizar() -> None:
        facade.ficha_atual = facade.otimizador_ia.otimizar(
            nome=in_nome.text(),
            nivel=in_nivel.value(),
            arquetipo=cb_arq.currentText(),
            iteracoes_mcts=120,
        )
        atualizar_visores()
        abas_qt.setCurrentIndex(1)

    btn_otimizar.clicked.connect(acao_otimizar)
    layout_principal.addLayout(painel_esq, 1)
    layout_principal.addWidget(abas_qt, 3)
    janela.setCentralWidget(central)
    atualizar_visores()
    janela.show()
    app.exec()
    return True


def executar_demonstracao_e_testes() -> None:
    facade = Tormenta20Facade("tormenta20.db")
    facade.db.conn.execute("DELETE FROM personagem_escolhas")
    facade.db.conn.execute("DELETE FROM personagens")
    facade.db.conn.commit()

    servidor = ServidorGUIWebPython(facade)

    print("=" * 94)
    print(" 1. EXECUÇÃO DO ALGORITMO (CSP + MCTS) E ÁRVORE DO CAMINHO DE ESCOLHAS")
    print("=" * 94)
    servidor.processar_post("/otimizar_ia", {
        "nome": ["Kaelen Fúria-Rubra"],
        "nivel": ["6"],
        "arquetipo": ["Dano Marcial"],
        "iteracoes": ["140"],
        "fixar_raca": ["AUTO"],
        "fixar_classe": ["Guerreiro"],
        "fixar_origem": ["AUTO"],
        "fixar_deus": ["AUTO"],
    })
    f_guerreiro = facade.ficha_atual
    facade.repositorio_personagens.salvar(f_guerreiro)
    print(facade.renderizador_arvore_ascii.renderizar_arvore(f_guerreiro))
    sim_g = f_guerreiro.relatorio_ia.simulacao_combate
    print("\n  [ESTATÍSTICAS MÉDIAS DA CRIATURA (LIVRO p. 323 / PDF p. 329) — ND", sim_g.nd_ameaca, "]:")
    for pa in sim_g.tabela_papeis_ameaca:
        print(f"    * {pa.papel:<32} | Atq +{pa.ataque:<2} | Dano {pa.dano_medio:<3}/rod | Def {pa.defesa:<2} | Res +{pa.res_forte}/+{pa.res_media}/{pa.res_fraca:+d} | PV 4x={pa.pv_grupo4} (1v1={pa.pv_duelo_1v1}) | CD {pa.cd_efeito} | WinRate={pa.winrate_heroi_pct:.1f}%")
    print("\n  [MELHOR TOMADA DE DECISÕES EM COMBATE (POLÍTICA TÁTICA ÓTIMA)]:")
    print(f"    -> Rota Ótima: {sim_g.melhor_sequencia_decisoes}")
    for op in sim_g.matriz_decisoes_taticas:
        print(f"    * [{op.tipo_acao}] {op.nome_acao} ({op.custo_pm} PM) | Sucesso={op.chance_sucesso_pct:.0f}% | EV={op.valor_esperado_efetivo:.1f} -> {op.veredito_tatico}")
    print("\n  [AÇÕES TOMADAS TURNO A TURNO & CÁLCULO DA % DE VITÓRIA]:")
    print(f"    -> {sim_g.explicacao_calculo_vitoria}")
    for t in sim_g.turnos_detalhados:
        print(f"    * Turno #{t.numero_turno}: [Livre] {t.acao_livre_movimento} | [Padrão] {t.acao_padrao_principal} ({t.rolagem_e_teste}) => {t.dano_causado:.1f} dano (Criatura: {t.pv_criatura_apos}) | [Inimigo] {t.acao_criatura_e_reacao} | Herói: {t.saldo_heroi_pv_pm}")
    print()

    servidor.processar_post("/otimizar_ia", {
        "nome": ["Ignis Arquimago"],
        "nivel": ["6"],
        "arquetipo": ["Conjurador Arcano"],
        "iteracoes": ["140"],
        "fixar_raca": ["Elfo"],
        "fixar_classe": ["Arcanista"],
        "fixar_origem": ["AUTO"],
        "fixar_deus": ["AUTO"],
    })
    f_arcanista = facade.ficha_atual
    facade.repositorio_personagens.salvar(f_arcanista)
    print(facade.renderizador_arvore_ascii.renderizar_arvore(f_arcanista))
    sim_a = f_arcanista.relatorio_ia.simulacao_combate
    print("\n  [MELHOR TOMADA DE DECISÕES EM COMBATE — CONJURADOR ARCANO]:")
    print(f"    -> Rota Ótima: {sim_a.melhor_sequencia_decisoes}")
    for op in sim_a.matriz_decisoes_taticas:
        print(f"    * [{op.tipo_acao}] {op.nome_acao} ({op.custo_pm} PM) | Sucesso={op.chance_sucesso_pct:.0f}% | EV={op.valor_esperado_efetivo:.1f} -> {op.veredito_tatico}")
    print("\n  [AÇÕES TOMADAS TURNO A TURNO & CÁLCULO DA % DE VITÓRIA — CONJURADOR]:")
    print(f"    -> {sim_a.explicacao_calculo_vitoria}")
    for t in sim_a.turnos_detalhados:
        print(f"    * Turno #{t.numero_turno}: [Livre] {t.acao_livre_movimento} | [Padrão] {t.acao_padrao_principal} ({t.rolagem_e_teste}) => {t.dano_causado:.1f} dano (Criatura: {t.pv_criatura_apos}) | [Inimigo] {t.acao_criatura_e_reacao} | Herói: {t.saldo_heroi_pv_pm}")
    print()

    print("=" * 94)
    print(" 1.5 VERIFICAÇÃO DE REGRAS ESPECIAIS: ORIGEM, GOLEM (SEM ORIGEM) & OSTEON (MEMÓRIA PÓSTUMA)")
    print("=" * 94)
    f_golem = facade.otimizador_ia.otimizar(nome="Titanus Golem", nivel=6, arquetipo="Tanque: Arma e Escudo", iteracoes_mcts=45, fixar_raca="Golem", fixar_classe="Cavaleiro")
    f_osteon = facade.otimizador_ia.otimizar(nome="Malakor Osteon", nivel=6, arquetipo="Conjurador Arcano: Mago", iteracoes_mcts=45, fixar_raca="Osteon", fixar_classe="Arcanista")
    print(f"  * [Normal - {f_guerreiro.raca.nome}]: {f_guerreiro.resumo_regra_origem}")
    print(f"  * [Golem  - {f_golem.raca.nome}]: Origem={f_golem.origem} | {f_golem.resumo_regra_origem} | Deslocamento={f_golem.deslocamento_final}m")
    print(f"  * [Osteon - {f_osteon.raca.nome}]: Origem={f_osteon.origem} | Livres={f_osteon.escolhas_atributos_livres} (sem CON!) | {f_osteon.resumo_regra_origem}")
    print()
    print("=" * 94)
    print(" 2. APRENDIZADO POR REFORÇO CAIXA-PRETA (DESCOBERTA DA MELHOR BUILD SEM LER A FICHA DA CRIATURA)")
    print("=" * 94)
    ranking_rl, resumo_rl = AgenteRLCaixaPretaT20.descobrir_melhor_build_sem_ler_ficha(
        facade.otimizador_ia, nivel=6, papel_criatura="Solo", episodios_por_build=12
    )
    print(" ", resumo_rl)
    for idx_r, r_item in enumerate(ranking_rl, 1):
        marca = "CAMPEÃ" if idx_r == 1 else f"  #{idx_r:<5}"
        print(f"    {marca} | {r_item.arquetipo:<28} ({r_item.raca_nome} {r_item.classe_nome}) | Q={r_item.recompensa_media_q:>6.1f} | WinRate={r_item.winrate_empirico_pct:>5.1f}% | DPR={r_item.dano_medio_por_turno:>5.1f} | {r_item.defesa_estimada_intervalo}")
    print()

    html_mobile = facade.pagina_web_completa("App Mobile-First, Arena Visual de Combate & Dados 3D Prontos!", aba_ativa="tab-ficha")
    Path("ficha_tormenta20_mobile.html").write_text(html_mobile, encoding="utf-8")
    print("=" * 94)
    print(f" 2. INTERFACE MOBILE-FIRST + DIAGRAMA SVG DA ÁRVORE GERADOS ({len(html_mobile)} bytes)")
    print("    Para usar no navegador (PC ou Celular via Wi-Fi): python3 tormenta20_character_system.py")
    print("=" * 94)

