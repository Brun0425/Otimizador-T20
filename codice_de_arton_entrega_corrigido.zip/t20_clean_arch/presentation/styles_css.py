# -*- coding: utf-8 -*-
"""Design System Editorial — Códice de Arton (Tormenta20)."""

from __future__ import annotations


class FolhaEstiloTemaTormenta20:
    """
    Folha de Estilo CSS Responsiva (Mobile-First + Desktop Grid + Bottom Navigation App Bar).
    Em telas de celular (<= 860px), transforma o layout em um aplicativo móvel nativo com
    cabeçalho fixo de status, cartões empilhados de toque amplo e barra de abas inferior!
    """
    @classmethod
    def gerar_css_web(cls) -> str:
        return """
        @import url('https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@700;900&family=Cinzel:wght@600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Press+Start+2P&display=swap');

        :root {
            --t20-ruby: #A62C2B;
            --t20-ruby-dark: #5C1818;
            --t20-gold: #C99B42;
            --t20-gold-bright: #E3BE6D;
            --t20-gold-border: rgba(201, 155, 66, 0.42);
            --t20-bg-deep: #0E1015;
            --t20-bg-card: #151821;
            --t20-bg-section: #1B1F2B;
            --t20-bg-row-alt: #202534;
            --t20-parchment: #151821;
            --t20-ink: #E8E5DC;
            --t20-muted: #9399A8;
            --t20-border: rgba(232, 229, 220, 0.11);
            --t20-valid: #3D9970;
            --t20-info: #5B9BD5;
            --t20-arcane: #9E7CC1;
            --t20-error: #EF4444;
        }

        /* Tema Alternativo 2: Pixel-Art 16-Bit Retro CRT */
        body[data-app-theme="PIXEL16"] {
            --t20-ruby: #E11D48;
            --t20-ruby-dark: #881337;
            --t20-gold: #FACC15;
            --t20-gold-bright: #FEF08A;
            --t20-bg-deep: #050714;
            --t20-bg-card: #0B1338;
            --t20-bg-section: #111D4A;
            --t20-parchment: #0B1338;
            --t20-ink: #FFFFFF;
            --t20-muted: #93C5FD;
            --t20-border: #60A5FA;
            font-family: 'Courier New', Consolas, monospace !important;
        }

        /* Tema Alternativo 3: Pergaminho Real Clássico de Arton */
        body[data-app-theme="PARCHMENT"] {
            --t20-ruby: #8B1E24;
            --t20-ruby-dark: #4A0D11;
            --t20-gold: #B45309;
            --t20-gold-bright: #92400E;
            --t20-bg-deep: #261714;
            --t20-bg-card: #FBF6EC;
            --t20-bg-section: #F4EBDC;
            --t20-parchment: #FBF6EC;
            --t20-ink: #1F1612;
            --t20-muted: #5C4E46;
            --t20-border: #C8B598;
        }

        *, *::before, *::after { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }

        body {
            margin: 0;
            padding: 0 0 88px 0;
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--t20-bg-deep);
            background-image:
                radial-gradient(circle at 15% 15%, rgba(185, 28, 28, 0.16) 0%, transparent 45%),
                radial-gradient(circle at 85% 20%, rgba(217, 119, 6, 0.12) 0%, transparent 45%),
                radial-gradient(circle at 50% 85%, rgba(88, 28, 135, 0.16) 0%, transparent 50%),
                linear-gradient(180deg, #07090E 0%, #0E111B 50%, #08090F 100%);
            background-attachment: fixed;
            color: var(--t20-ink);
        }

        h1, h2, .sheet-title, .panel-header, .section-box h3 {
            font-family: 'Cinzel', Georgia, serif;
            letter-spacing: 0.6px;
        }

        .topbar {
            background: linear-gradient(135deg, #1E0508 0%, #580D14 48%, #1A0812 100%);
            color: #FFFFFF;
            padding: 12px 20px;
            border-bottom: 1px solid rgba(201, 155, 66, 0.35);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            position: sticky;
            top: 0;
            z-index: 95;
            box-shadow: 0 8px 28px rgba(0,0,0,0.8), inset 0 -1px 0 rgba(253,224,71,0.4);
        }
        .topbar h1 {
            margin: 0;
            font-size: 17.5px;
            font-family: 'Cinzel Decorative', 'Cinzel', serif;
            background: linear-gradient(90deg, #FFFBEB, #FDE047, #F59E0B);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 2px 10px rgba(245, 158, 11, 0.35);
        }
        .topbar .subtitle { font-size: 12px; color: #FDE68A; margin-top: 2px; font-weight: 600; }
        .mobile-quick-bar { display: flex; gap: 7px; align-items: center; flex-wrap: wrap; }

        .quick-pill {
            background: linear-gradient(180deg, rgba(30, 41, 59, 0.92), rgba(15, 23, 42, 0.96));
            border: 1px solid rgba(201, 155, 66, 0.24);
            color: #FEF08A;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11.5px;
            font-weight: 800;
            box-shadow: 0 2px 6px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.18);
        }

        .container-app { max-width: 1480px; margin: 14px auto; padding: 0 12px; }
        .tab-section { display: none; }
        .tab-section.active { display: block; animation: fadeIn 0.22s ease-out; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        /* Cartões e Painéis com Estética de Códice Obsidiana & Ouro Forjado */
        .panel, .sheet-card {
            background: linear-gradient(160deg, var(--t20-bg-card) 0%, #0C0E17 100%);
            border: 1px solid rgba(201, 155, 66, 0.28);
            border-radius: 14px;
            box-shadow: 0 12px 32px rgba(0,0,0,0.65), inset 0 0 0 1px rgba(253, 224, 71, 0.16);
            overflow: hidden;
            margin-bottom: 18px;
            color: var(--t20-ink);
            position: relative;
        }
        body[data-app-theme="PARCHMENT"] .panel,
        body[data-app-theme="PARCHMENT"] .sheet-card {
            background: linear-gradient(160deg, #FBF6EC 0%, #F2E6D0 100%);
            border: 1px solid rgba(166, 44, 43, 0.45);
            color: #1F1612;
        }
        body[data-app-theme="PIXEL16"] .panel,
        body[data-app-theme="PIXEL16"] .sheet-card {
            background: linear-gradient(180deg, #101E5A 0%, #070D2D 100%);
            border: 3px double #F8FAFC;
            border-radius: 4px;
            box-shadow: 4px 4px 0 #000000;
        }

        .sheet-card { padding: 18px; }
        .panel-header {
            background: linear-gradient(90deg, #580D14 0%, #8B1E24 50%, #3F0A0F 100%);
            color: #FEF08A;
            padding: 13px 18px;
            font-weight: 800;
            font-size: 14px;
            text-transform: uppercase;
            border-bottom: 1px solid rgba(201, 155, 66, 0.28);
            text-shadow: 0 2px 4px rgba(0,0,0,0.8);
        }
        .panel-body { padding: 16px; }
        .form-group { margin-bottom: 12px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px; }

        label {
            display: block;
            font-size: 11.5px;
            font-weight: 800;
            color: #FDE047;
            margin-bottom: 4px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }
        body[data-app-theme="PARCHMENT"] label { color: #7F1D1D; }

        input[type='text'], input[type='number'], select {
            width: 100%;
            min-height: 42px;
            padding: 8px 12px;
            border: 1.5px solid #475569;
            border-radius: 8px;
            background: #0F172A;
            font-size: 13.5px;
            color: #F8FAFC;
            font-weight: 600;
            box-shadow: inset 0 2px 5px rgba(0,0,0,0.5);
        }
        input[type='text']:focus, input[type='number']:focus, select:focus {
            outline: none;
            border-color: #FACC15;
            box-shadow: 0 0 10px rgba(250, 204, 21, 0.35);
        }
        body[data-app-theme="PARCHMENT"] input[type='text'],
        body[data-app-theme="PARCHMENT"] input[type='number'],
        body[data-app-theme="PARCHMENT"] select {
            background: #FFFFFF;
            color: #1F1612;
            border-color: #B8A486;
            box-shadow: none;
        }

        select[multiple] { height: 140px; }
        .attr-input-grid { display: grid; grid-template-columns: repeat(7, minmax(0, 1fr)); gap: 8px; text-align: center; }

        .btn {
            display: inline-block;
            width: 100%;
            min-height: 44px;
            padding: 10px 16px;
            border: 1.5px solid rgba(201, 155, 66, 0.28);
            border-radius: 9px;
            font-weight: 800;
            font-size: 13.5px;
            cursor: pointer;
            text-align: center;
            margin-top: 6px;
            transition: transform 0.14s ease, box-shadow 0.14s ease, filter 0.14s ease;
            box-shadow: 0 4px 12px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.25);
            text-shadow: 0 1px 2px rgba(0,0,0,0.8);
        }
        .btn:hover:not(:disabled) {
            transform: translateY(-2px);
            filter: brightness(1.10);
            box-shadow: 0 7px 18px rgba(0,0,0,0.6), 0 0 12px rgba(245, 158, 11, 0.3);
        }
        .btn:active:not(:disabled) { transform: translateY(1px); }
        .btn-manual { background: linear-gradient(135deg, #1E3A8A, #2563EB); color: #FFFFFF; }
        .btn-ai {
            background: linear-gradient(135deg, #7F1D1D 0%, #B91C1C 55%, #991B1B 100%);
            color: #FEF08A;
            border: 1px solid rgba(201, 155, 66, 0.30);
        }
        .btn-save {
            background: linear-gradient(135deg, #065F46, #059669);
            color: #FFFFFF;
            min-height: 36px;
            padding: 7px 14px;
            font-size: 12.5px;
            margin: 0;
        }

        .sheet-banner {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            background: linear-gradient(90deg, rgba(127, 29, 29, 0.38) 0%, rgba(30, 41, 59, 0.45) 100%);
            border: 1.5px solid rgba(212, 175, 55, 0.55);
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 16px;
        }
        .sheet-title {
            font-size: 22px;
            font-weight: 900;
            color: #FDE047;
            margin: 0;
            text-shadow: 0 2px 8px rgba(0,0,0,0.8);
        }
        body[data-app-theme="PARCHMENT"] .sheet-title { color: #7F1D1D; text-shadow: none; }

        .meta-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px; }
        .meta-box {
            background: linear-gradient(180deg, #1A2033 0%, #101420 100%);
            border: 1px solid #334155;
            border-left: 3px solid #C99B42;
            border-radius: 8px;
            padding: 9px 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.35);
        }
        body[data-app-theme="PARCHMENT"] .meta-box { background: #FFFFFF; border-color: #D5C4AC; border-left-color: #8B1E24; }
        .meta-box .k { font-size: 10.5px; color: #94A3B8; text-transform: uppercase; font-weight: 800; letter-spacing: 0.4px; }
        .meta-box .v { font-size: 14px; font-weight: 800; color: #F8FAFC; margin-top: 3px; }
        body[data-app-theme="PARCHMENT"] .meta-box .v { color: #1F1612; }

        /* Medalhões de Estatísticas e Atributos Estilo Brasão de RPG */
        .stats-strip { display: grid; grid-template-columns: repeat(7, minmax(0, 1fr)); gap: 10px; margin-bottom: 16px; }
        .stat-pill {
            background: radial-gradient(circle at top, #271722 0%, #111522 100%);
            border: 1px solid rgba(201, 155, 66, 0.28);
            border-radius: 12px;
            padding: 10px 6px;
            text-align: center;
            box-shadow: 0 6px 14px rgba(0,0,0,0.5), inset 0 0 12px rgba(245, 158, 11, 0.15);
            position: relative;
        }
        body[data-app-theme="PARCHMENT"] .stat-pill { background: linear-gradient(180deg, #FFFFFF, #F5EBDC); }
        .stat-pill .num { font-size: 21px; font-weight: 900; color: #FDE047; font-family: 'Cinzel', serif; text-shadow: 0 2px 6px rgba(0,0,0,0.8); }
        body[data-app-theme="PARCHMENT"] .stat-pill .num { color: #7F1D1D; text-shadow: none; }
        .stat-pill .lbl { font-size: 10px; font-weight: 800; color: #CBD5E1; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 2px; }
        body[data-app-theme="PARCHMENT"] .stat-pill .lbl { color: #5C4E46; }

        .attr-strip { display: grid; grid-template-columns: repeat(7, minmax(0, 1fr)); gap: 10px; margin-bottom: 16px; }
        .attr-badge {
            background: linear-gradient(160deg, #4A0D13 0%, #1F070A 100%);
            color: #FFFFFF;
            border: 1px solid rgba(201, 155, 66, 0.35);
            border-radius: 12px;
            padding: 8px 6px;
            text-align: center;
            box-shadow: 0 5px 14px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.25);
        }
        .attr-badge .sigla { font-size: 11px; color: #FDE047; font-weight: 900; letter-spacing: 0.8px; font-family: 'Cinzel', serif; }
        .attr-badge .mod { font-size: 20px; font-weight: 900; color: #FFFFFF; text-shadow: 0 2px 4px #000; }

        .sheet-columns { display: grid; grid-template-columns: 1.32fr 1fr; gap: 16px; }

        /* =====================================================================
           LAYOUT FIEL À FICHA OFICIAL DE TORMENTA 20 (`Ficha_T20.pdf`)
           ===================================================================== */
        .t20-sheet-toolbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            padding: 8px 12px;
            margin-bottom: 12px;
            background: rgba(127, 29, 29, 0.25);
            border: 1px solid rgba(212, 175, 55, 0.45);
            border-radius: 10px;
        }
        .t20-header-grid {
            display: grid;
            grid-template-columns: auto 1.4fr 1fr 1fr;
            gap: 10px;
            align-items: stretch;
            margin-bottom: 14px;
            background: linear-gradient(135deg, rgba(127, 29, 29, 0.35), rgba(15, 23, 42, 0.72));
            border: 1px solid rgba(166, 44, 43, 0.45);
            border-radius: 12px;
            padding: 12px;
        }
        body[data-app-theme="PARCHMENT"] .t20-header-grid {
            background: linear-gradient(180deg, #FDF9F1 0%, #F4E9D8 100%);
            border: 1px solid rgba(166, 44, 43, 0.55);
        }
        .t20-field-box {
            border: 1.5px solid rgba(212, 175, 55, 0.55);
            border-top: 2px solid #8C2323;
            border-radius: 6px;
            padding: 6px 10px;
            background: rgba(9, 13, 22, 0.55);
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        body[data-app-theme="PARCHMENT"] .t20-field-box {
            background: #FFFFFF;
            border-color: #8B1E24;
        }
        .t20-field-box .lbl-t20 {
            font-size: 9.5px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 0.7px;
            color: #FDE047;
            font-family: 'Cinzel', serif;
        }
        body[data-app-theme="PARCHMENT"] .t20-field-box .lbl-t20 { color: #8B1E24; }
        .t20-field-box .val-t20 {
            font-size: 14.5px;
            font-weight: 800;
            color: var(--t20-ink);
            margin-top: 2px;
        }
        .t20-attr-shield-row {
            display: grid;
            grid-template-columns: repeat(7, minmax(0, 1fr));
            gap: 8px;
            margin-bottom: 14px;
        }
        .t20-attr-shield {
            background: linear-gradient(180deg, #6B141A 0%, #2A080C 100%);
            border: 1px solid rgba(201, 155, 66, 0.28);
            border-radius: 10px 10px 22px 22px;
            padding: 7px 4px 10px 4px;
            text-align: center;
            box-shadow: 0 5px 12px rgba(0,0,0,0.45);
            position: relative;
        }
        body[data-app-theme="PARCHMENT"] .t20-attr-shield {
            background: linear-gradient(180deg, #FFFFFF 0%, #F5E8D3 100%);
            border: 1px solid rgba(166, 44, 43, 0.55);
            color: #1F1612;
        }
        .t20-attr-shield .sig {
            font-family: 'Cinzel', serif;
            font-size: 12px;
            font-weight: 900;
            color: #FDE047;
            background: #8B1E24;
            border-radius: 5px;
            padding: 2px 6px;
            display: inline-block;
            margin-bottom: 3px;
        }
        .t20-attr-shield .val {
            font-family: 'Cinzel', serif;
            font-size: 24px;
            font-weight: 900;
            color: #FFFFFF;
            line-height: 1.1;
        }
        body[data-app-theme="PARCHMENT"] .t20-attr-shield .val { color: #5A1014; }
        .t20-attr-shield .sub-calc {
            font-size: 9.5px;
            color: #CBD5E1;
            margin-top: 2px;
        }
        body[data-app-theme="PARCHMENT"] .t20-attr-shield .sub-calc { color: #5C4E46; }

        .t20-pv-pm-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 14px;
        }
        .t20-vital-box {
            border: 1px solid rgba(166, 44, 43, 0.45);
            border-radius: 10px;
            overflow: hidden;
            background: var(--t20-bg-section);
        }
        .t20-vital-box .vital-hdr {
            background: linear-gradient(90deg, #7F1D1D, #991B1B);
            color: #FEF08A;
            padding: 6px 12px;
            font-family: 'Cinzel', serif;
            font-size: 12px;
            font-weight: 900;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .t20-vital-box.pm-box .vital-hdr {
            background: linear-gradient(90deg, #1E3A8A, #1D4ED8);
        }
        .t20-vital-cells {
            display: grid;
            grid-template-columns: 1fr 1.2fr;
            gap: 8px;
            padding: 8px 10px;
            align-items: center;
        }
        .t20-vital-cell {
            text-align: center;
            border: 1px solid rgba(212, 175, 55, 0.4);
            border-radius: 7px;
            padding: 5px;
            background: rgba(9, 13, 22, 0.38);
        }
        body[data-app-theme="PARCHMENT"] .t20-vital-cell {
            background: #FFFFFF;
            border-color: #C8B598;
        }
        .t20-defesa-equation {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 6px;
            padding: 10px;
            background: rgba(9, 13, 22, 0.48);
            border: 1.5px solid #8B1E24;
            border-radius: 9px;
            margin-bottom: 10px;
        }
        body[data-app-theme="PARCHMENT"] .t20-defesa-equation {
            background: #FFFFFF;
        }
        .t20-def-box {
            text-align: center;
            border: 1px solid rgba(201, 155, 66, 0.24);
            border-radius: 7px;
            padding: 5px 8px;
            min-width: 58px;
            background: rgba(30, 41, 59, 0.65);
        }
        body[data-app-theme="PARCHMENT"] .t20-def-box {
            background: #FDF8EE;
            border-color: #8B1E24;
        }
        .t20-def-box.total {
            background: #8B1E24;
            color: #FEF08A;
            border-width: 2px;
            min-width: 74px;
        }
        .t20-def-box .n { font-size: 17px; font-weight: 900; font-family: 'Cinzel', serif; }
        .t20-def-box .l { font-size: 9px; text-transform: uppercase; font-weight: 800; opacity: 0.9; }

        details.t20-collapsible {
            border: 1.5px solid rgba(212, 175, 55, 0.55);
            border-radius: 10px;
            background: var(--t20-bg-section);
            margin-bottom: 12px;
            overflow: hidden;
        }
        details.t20-collapsible > summary {
            cursor: pointer;
            padding: 11px 15px;
            background: linear-gradient(90deg, rgba(127, 29, 29, 0.55), rgba(30, 41, 59, 0.75));
            color: #FDE047;
            font-family: 'Cinzel', serif;
            font-weight: 800;
            font-size: 13px;
            list-style: none;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        body[data-app-theme="PARCHMENT"] details.t20-collapsible > summary {
            background: linear-gradient(90deg, #8B1E24, #5A1014);
            color: #FEF08A;
        }
        details.t20-collapsible > .collapsible-body {
            padding: 12px;
        }
        .btn-roll-inline {
            background: linear-gradient(135deg, #8B1E24, #B91C1C);
            color: #FEF08A;
            border: 1px solid rgba(201, 155, 66, 0.32);
            border-radius: 5px;
            padding: 2px 7px;
            font-size: 11px;
            font-weight: 800;
            cursor: pointer;
            white-space: nowrap;
        }
        .btn-roll-inline:hover { filter: brightness(1.18); transform: scale(1.04); }
        .section-box {
            background: var(--t20-bg-section) !important;
            border: 1.5px solid rgba(212, 175, 55, 0.38) !important;
            border-radius: 10px;
            padding: 13px;
            margin-bottom: 14px;
            color: var(--t20-ink) !important;
            box-shadow: 0 4px 14px rgba(0,0,0,0.35);
        }
        .section-box h3 {
            margin: 0 0 10px 0;
            font-size: 13px;
            color: #FDE047 !important;
            text-transform: uppercase;
            border-bottom: 1.5px solid rgba(212, 175, 55, 0.45);
            padding-bottom: 6px;
        }
        body[data-app-theme="PARCHMENT"] .section-box h3 { color: #8B1E24 !important; }

        .item-row {
            padding: 7px 8px;
            border-bottom: 1px dashed rgba(148, 163, 184, 0.25);
            font-size: 13px;
            line-height: 1.48;
            color: var(--t20-ink) !important;
            background: transparent !important;
            border-radius: 6px;
        }
        .item-row strong { color: #FEF08A; }
        body[data-app-theme="PARCHMENT"] .item-row strong { color: #5A1014; }
        .item-row em, .item-row small, .item-row span { color: #CBD5E1; }
        body[data-app-theme="PARCHMENT"] .item-row em, body[data-app-theme="PARCHMENT"] .item-row small { color: #4A3F35; }
        .item-row:last-child { border-bottom: none; }

        .tag {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 5px;
            font-size: 11px;
            font-weight: 800;
            background: linear-gradient(135deg, #78350F, #B45309);
            color: #FEF08A;
            border: 1px solid rgba(201, 155, 66, 0.25);
            margin-right: 5px;
        }

        .skills-table { width: 100%; border-collapse: collapse; font-size: 12.5px; color: var(--t20-ink); }
        .skills-table th {
            padding: 7px 8px;
            background: rgba(15, 23, 42, 0.85);
            color: #FDE047;
            border-bottom: 1px solid rgba(201, 155, 66, 0.28);
            text-align: left;
            font-family: 'Cinzel', serif;
            font-size: 11.5px;
        }
        body[data-app-theme="PARCHMENT"] .skills-table th { background: #E6D7C3; color: #5A1014; }
        .skills-table td { padding: 6px 8px; border-bottom: 1px solid rgba(148, 163, 184, 0.18); text-align: left; }
        .skills-table tr.trained {
            background: rgba(217, 119, 6, 0.18) !important;
            font-weight: 800;
            color: #FEF08A;
        }
        body[data-app-theme="PARCHMENT"] .skills-table tr.trained { background: #FDF3E7 !important; color: #5A1014; }

        .csp-ok {
            background: linear-gradient(90deg, rgba(6, 78, 59, 0.9), rgba(4, 120, 87, 0.85)) !important;
            border: 1px solid rgba(201, 155, 66, 0.35) !important;
            color: #ECFDF5 !important;
            padding: 10px 14px;
            border-radius: 9px;
            font-weight: 800;
            font-size: 12.5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
        }
        .csp-err {
            background: linear-gradient(90deg, rgba(127, 29, 29, 0.92), rgba(153, 27, 27, 0.88)) !important;
            border: 1.5px solid #F87171 !important;
            color: #FEF2F2 !important;
            padding: 10px 14px;
            border-radius: 9px;
            font-size: 12.5px;
        }

        /* Árvore MCTS + CSP */
        .tree-scroll-wrapper {
            width: 100%;
            overflow-x: auto;
            background: #0B0F19;
            border: 1px solid rgba(201, 155, 66, 0.28);
            border-radius: 12px;
            padding: 12px;
            margin-bottom: 14px;
            box-shadow: inset 0 0 24px rgba(0,0,0,0.8);
        }
        .tree-step-card {
            background: #151B2B;
            border: 1px solid #334155;
            border-left: 3px solid #C99B42;
            border-radius: 9px;
            padding: 12px;
            margin-bottom: 10px;
            color: #F1F5F9;
        }
        .tree-winner-box {
            background: rgba(180, 83, 9, 0.22);
            border: 1px solid #F59E0B;
            border-radius: 7px;
            padding: 8px 12px;
            font-size: 13.5px;
            color: #FEF08A;
            margin-bottom: 6px;
        }
        .tree-branch-alt {
            background: rgba(30, 41, 59, 0.75);
            border-left: 3px solid #60A5FA;
            padding: 5px 10px;
            margin-top: 4px;
            font-size: 12px;
            color: #E2E8F0;
            border-radius: 0 5px 5px 0;
        }
        .tree-branch-pruned {
            background: rgba(127, 29, 29, 0.35);
            border-left: 3px solid #F87171;
            padding: 5px 10px;
            margin-top: 4px;
            font-size: 12px;
            color: #FECACA;
            border-radius: 0 5px 5px 0;
        }

        /* Barra Inferior Mobile-First */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 68px;
            background: linear-gradient(180deg, #1E070B 0%, #0D0406 100%);
            border-top: 1px solid rgba(201, 155, 66, 0.28);
            display: grid;
            grid-template-columns: repeat(7, minmax(0, 1fr));
            z-index: 100;
            box-shadow: 0 -6px 20px rgba(0,0,0,0.75);
        }

        /* =====================================================================
           PALCO DE BATALHA JRPG HD-2D & ANIMAÇÕES COREOGRAFADAS POR TIPO DE AÇÃO
           ===================================================================== */
        .arena-stage {
            background: radial-gradient(circle at 50% 20%, #241118 0%, #0E0B14 65%, #07060B 100%);
            border: 1px solid rgba(201, 155, 66, 0.35);
            border-radius: 16px;
            padding: 16px;
            color: #F8FAFC;
            margin-bottom: 18px;
            box-shadow: 0 14px 36px rgba(0,0,0,0.75), inset 0 0 32px rgba(212, 175, 55, 0.12);
        }
        .arena-vs-grid {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            gap: 14px;
            align-items: stretch;
        }
        .combatant-card {
            background: linear-gradient(160deg, rgba(24, 30, 48, 0.92), rgba(11, 15, 25, 0.96));
            border: 1.5px solid rgba(212, 175, 55, 0.65);
            border-radius: 12px;
            padding: 14px;
            position: relative;
            transition: transform 0.25s ease, box-shadow 0.25s ease;
            box-shadow: 0 6px 18px rgba(0,0,0,0.5);
        }
        .combatant-card.hit-shake {
            animation: cardHitShake 0.45s ease;
            border-color: #EF4444;
            box-shadow: 0 0 24px rgba(239, 68, 68, 0.75);
        }
        .combatant-card.attack-lunge {
            animation: cardAttackLunge 0.42s ease;
            border-color: #FACC15;
            box-shadow: 0 0 24px rgba(250, 204, 21, 0.75);
        }

        /* Animações Coreografadas Exclusivas de Cada Tipo de Ação no Palco JRPG */
        @keyframes jrpgIdleFloat {
            0%, 100% { transform: translateY(0px) scaleY(1); }
            50% { transform: translateY(-5px) scaleY(1.015); }
        }
        /* 1. Corte de Espada / Lâmina (Avanço Rápido c/ Golpe Horizontal) */
        @keyframes jrpgHeroSwordSlash {
            0% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(-18px, 4px) rotate(-8deg) scale(0.96); }
            55% { transform: translate(240px, -10px) rotate(12deg) scale(1.18); filter: drop-shadow(0 0 16px #FACC15); }
            80% { transform: translate(210px, -4px) rotate(4deg) scale(1.12); }
            100% { transform: translate(0, 0) scale(1); }
        }
        /* 2. Salto Esmagador de Machado / Marreta / Impacto */
        @keyframes jrpgHeroJumpSlam {
            0% { transform: translate(0, 0) scale(1); }
            35% { transform: translate(115px, -85px) rotate(-22deg) scale(1.15); }
            62% { transform: translate(235px, 12px) rotate(18deg) scale(1.24, 0.88); filter: drop-shadow(0 0 22px #F97316); }
            82% { transform: translate(220px, 0px) scale(1.08); }
            100% { transform: translate(0, 0) scale(1); }
        }
        /* 3. Estocada Tripla de Lança / Alabarda / Florete / Chifres */
        @keyframes jrpgHeroMultiThrust {
            0% { transform: translate(0, 0); }
            25% { transform: translate(185px, -6px) scale(1.10); }
            42% { transform: translate(145px, 2px); }
            60% { transform: translate(225px, -8px) scale(1.15); }
            78% { transform: translate(250px, -4px) scale(1.18); filter: drop-shadow(0 0 16px #38BDF8); }
            100% { transform: translate(0, 0); }
        }
        /* 4. Postura de Disparo de Arco / Besta / Mosquete (Recuo Tático no Lugar) */
        @keyframes jrpgHeroRangedRecoil {
            0% { transform: translate(0, 0); }
            30% { transform: translate(-12px, -4px) scale(1.05); filter: drop-shadow(0 0 14px #FDE047); }
            55% { transform: translate(-26px, 0px) rotate(-5deg); }
            100% { transform: translate(0, 0); }
        }
        /* 5. Levitação Mística de Conjuração de Magia */
        @keyframes jrpgHeroCastLevitate {
            0% { transform: translate(0, 0) scale(1); }
            35% { transform: translate(15px, -28px) scale(1.12); filter: drop-shadow(0 0 24px #C084FC); }
            75% { transform: translate(15px, -32px) scale(1.15); filter: drop-shadow(0 0 30px #FACC15); }
            100% { transform: translate(0, 0) scale(1); }
        }
        /* 6. Investida Selvagem da Criatura (Mordida & Garras) */
        @keyframes jrpgEnemySavagePounce {
            0% { transform: translate(0, 0) scale(1); }
            30% { transform: translate(22px, -35px) rotate(10deg) scale(1.12); }
            60% { transform: translate(-235px, 8px) rotate(-12deg) scale(1.22); filter: drop-shadow(0 0 22px #EF4444); }
            100% { transform: translate(0, 0) scale(1); }
        }
        /* 7. Sopro de Dragão / Ataque de Área da Criatura */
        @keyframes jrpgEnemyBreathRear {
            0% { transform: translate(0, 0) scale(1); }
            30% { transform: translate(25px, -22px) rotate(14deg) scale(1.16); filter: drop-shadow(0 0 24px #F97316); }
            65% { transform: translate(-35px, 4px) rotate(-8deg) scale(1.18); filter: drop-shadow(0 0 32px #FEF08A); }
            100% { transform: translate(0, 0) scale(1); }
        }
        /* 8. Tremor de Tela em Impactos Pesados / Críticos / Sopro */
        @keyframes jrpgScreenShake {
            0%, 100% { transform: translate(0, 0); }
            15% { transform: translate(-9px, -6px); }
            30% { transform: translate(9px, 5px); }
            45% { transform: translate(-7px, 6px); }
            60% { transform: translate(7px, -5px); }
            75% { transform: translate(-4px, 3px); }
        }
        @keyframes jrpgFloatDamage {
            0% { opacity: 1; transform: translateY(0) scale(0.65); }
            22% { opacity: 1; transform: translateY(-22px) scale(1.25); }
            80% { opacity: 1; transform: translateY(-48px) scale(1.02); }
            100% { opacity: 0; transform: translateY(-66px) scale(0.88); }
        }
        @keyframes vfxSpinRune {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        @keyframes vfxPulseFlash {
            0% { opacity: 0.2; transform: scale(0.75); }
            45% { opacity: 1; transform: scale(1.12); }
            100% { opacity: 0; transform: scale(1.35); }
        }
        @keyframes vfxProjectileFlyRight {
            0% { transform: translateX(0px); opacity: 1; }
            85% { transform: translateX(380px); opacity: 1; }
            100% { transform: translateX(410px); opacity: 0; }
        }
        @keyframes vfxBreathConePulse {
            0% { opacity: 0.1; transform: scaleX(0.2); transform-origin: 600px 180px; }
            35% { opacity: 0.95; transform: scaleX(1.05); transform-origin: 600px 180px; }
            80% { opacity: 0.9; transform: scaleX(1.0); transform-origin: 600px 180px; }
            100% { opacity: 0; transform: scaleX(1.08); transform-origin: 600px 180px; }
        }

        .jrpg-stage-wrapper {
            position: relative;
            margin-top: 12px;
            border-radius: 14px;
            overflow: hidden;
            border: 1px solid rgba(201, 155, 66, 0.35);
            box-shadow: 0 14px 34px rgba(0,0,0,0.8), inset 0 0 32px rgba(0,0,0,0.85);
            background: #060911;
        }
        .jrpg-stage-shake {
            animation: jrpgScreenShake 0.48s cubic-bezier(0.36, 0.07, 0.19, 0.97) !important;
        }
        .jrpg-top-hud {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: linear-gradient(90deg, rgba(9, 13, 22, 0.98), rgba(24, 9, 14, 0.98));
            border-bottom: 1px solid rgba(201, 155, 66, 0.28);
            z-index: 6;
            flex-wrap: wrap;
        }
        .jrpg-ff-window {
            background: linear-gradient(180deg, rgba(14, 28, 78, 0.93) 0%, rgba(6, 12, 38, 0.96) 100%);
            border: 1px solid rgba(201, 155, 66, 0.35);
            box-shadow: 0 0 0 2px #0F172A, 0 6px 16px rgba(0,0,0,0.75);
            border-radius: 8px;
            padding: 6px 13px;
            color: #FFFFFF;
            text-shadow: 1px 1px 2px #000;
        }
        .jrpg-turn-pill {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 3px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 800;
            background: rgba(15, 23, 42, 0.92);
            border: 1px solid #D4AF37;
            color: #FDE68A;
        }
        .jrpg-turn-pill.active-turn {
            background: linear-gradient(135deg, #B45309, #EA580C);
            color: #FFF;
            border-color: #FEF08A;
            box-shadow: 0 0 12px rgba(250, 204, 21, 0.75);
        }
        .jrpg-sprite-idle {
            animation: jrpgIdleFloat 2.4s ease-in-out infinite;
            transform-origin: center bottom;
        }
        .jrpg-anim-sword { animation: jrpgHeroSwordSlash 0.68s cubic-bezier(0.22, 1, 0.36, 1) forwards !important; }
        .jrpg-anim-slam { animation: jrpgHeroJumpSlam 0.74s cubic-bezier(0.22, 1, 0.36, 1) forwards !important; }
        .jrpg-anim-thrust { animation: jrpgHeroMultiThrust 0.68s ease-out forwards !important; }
        .jrpg-anim-ranged { animation: jrpgHeroRangedRecoil 0.58s ease-out forwards !important; }
        .jrpg-anim-cast { animation: jrpgHeroCastLevitate 0.78s ease-in-out forwards !important; }
        .jrpg-anim-enemy-pounce { animation: jrpgEnemySavagePounce 0.68s cubic-bezier(0.22, 1, 0.36, 1) forwards !important; }
        .jrpg-anim-enemy-breath { animation: jrpgEnemyBreathRear 0.82s ease-in-out forwards !important; }

        .jrpg-dmg-popup {
            position: absolute;
            font-weight: 900;
            font-size: 22px;
            font-family: 'Cinzel', serif;
            pointer-events: none;
            z-index: 12;
            text-shadow: 0 3px 6px #000, 0 0 14px rgba(0,0,0,0.95);
            animation: jrpgFloatDamage 1.45s ease-out forwards;
            white-space: nowrap;
        }
        @keyframes cardHitShake {
            0%, 100% { transform: translateX(0); }
            20% { transform: translateX(-8px) rotate(-1.5deg); }
            45% { transform: translateX(8px) rotate(1.5deg); }
            70% { transform: translateX(-5px); }
        }
        @keyframes cardAttackLunge {
            0%, 100% { transform: scale(1); }
            40% { transform: scale(1.04) translateY(-4px); }
        }
        .hp-bar-outer, .mp-bar-outer {
            width: 100%;
            height: 19px;
            background: rgba(0, 0, 0, 0.65);
            border: 1.5px solid rgba(212, 175, 55, 0.45);
            border-radius: 999px;
            overflow: hidden;
            margin: 5px 0 8px 0;
            position: relative;
            box-shadow: inset 0 2px 5px rgba(0,0,0,0.8);
        }
        .hp-bar-inner {
            height: 100%;
            background: linear-gradient(90deg, #15803D, #22C55E, #4ADE80);
            transition: width 0.45s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .hp-bar-enemy {
            height: 100%;
            background: linear-gradient(90deg, #7F1D1D, #DC2626, #F87171);
            transition: width 0.45s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .mp-bar-inner {
            height: 100%;
            background: linear-gradient(90deg, #1E40AF, #0284C7, #38BDF8);
            transition: width 0.45s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .bar-label {
            position: absolute;
            inset: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 900;
            color: #FFFFFF;
            text-shadow: 0 1px 3px rgba(0,0,0,0.95);
        }
        .dice-felt-table {
            background: radial-gradient(circle at center, #0F3826 0%, #071911 100%);
            border: 1px solid rgba(201, 155, 66, 0.35);
            border-radius: 14px;
            padding: 16px;
            color: #FFFFFF;
            margin-bottom: 18px;
            box-shadow: 0 10px 26px rgba(0,0,0,0.65), inset 0 0 32px rgba(0,0,0,0.75);
        }
        .dice-tray-row {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            justify-content: center;
            min-height: 116px;
            padding: 10px;
        }
        .die-3d-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            transition: transform 0.2s ease;
        }
        .die-3d-wrapper.rolling svg {
            animation: dieSpin3D 0.48s cubic-bezier(0.36, 0.07, 0.19, 0.97) infinite;
        }
        .die-3d-wrapper.crit-hit svg {
            filter: drop-shadow(0 0 12px #FACC15) drop-shadow(0 0 22px #F59E0B);
            transform: scale(1.14);
        }
        .die-3d-wrapper.fumble-miss svg {
            filter: drop-shadow(0 0 12px #EF4444);
        }
        @keyframes dieSpin3D {
            0% { transform: rotate(0deg) scale(0.92); }
            35% { transform: rotate(145deg) scale(1.10) translateY(-6px); }
            70% { transform: rotate(285deg) scale(0.96) translateY(3px); }
            100% { transform: rotate(360deg) scale(1.0); }
        }
        .fog-of-war-box {
            background: rgba(9, 13, 22, 0.85);
            border: 1px dashed #FACC15;
            border-radius: 8px;
            padding: 9px 11px;
            margin-top: 8px;
            font-size: 11.5px;
            color: #E2E8F0;
        }
        .nav-btn {
            background: none;
            border: none;
            color: #CBD5E1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 11.5px;
            font-weight: 800;
            cursor: pointer;
            padding: 6px 4px;
            transition: all 0.15s ease;
        }
        .nav-btn .ico { font-size: 19px; margin-bottom: 2px; }
        .nav-btn.active {
            color: #FDE047;
            background: linear-gradient(180deg, rgba(212, 175, 55, 0.28), rgba(127, 29, 29, 0.45));
            border-top: 3px solid #FDE047;
            box-shadow: inset 0 0 12px rgba(250, 204, 21, 0.25);
        }

        @media (max-width: 768px) {
            .arena-vs-grid { grid-template-columns: 1fr; }
            .meta-grid { grid-template-columns: repeat(2, 1fr); }
            .stats-strip { grid-template-columns: repeat(3, 1fr); }
            .attr-strip { grid-template-columns: repeat(3, 1fr); }
            .attr-input-grid { grid-template-columns: repeat(3, 1fr); }
            .sheet-columns { grid-template-columns: 1fr; }
            .form-row { grid-template-columns: 1fr; gap: 8px; }
            .topbar h1 { font-size: 14.5px; }
            .sheet-title { font-size: 18px; }
        }
        

        /* =====================================================================
           ESTILOS UNIFICADOS 3D VOLUMÉTRICO & OTIMIZAÇÃO MOBILE-FIRST (v45)
           ===================================================================== */
        .card {
            background: linear-gradient(160deg, var(--t20-bg-card) 0%, #0C0E17 100%);
            border: 1.5px solid rgba(212, 175, 55, 0.55);
            border-radius: 14px;
            padding: 14px;
            margin-bottom: 14px;
            box-shadow: 0 10px 26px rgba(0,0,0,0.6), inset 0 0 0 1px rgba(253, 224, 71, 0.12);
            color: var(--t20-ink);
        }
        .card-title {
            font-family: 'Cinzel', Georgia, serif;
            font-size: 15px;
            font-weight: 800;
            color: #FDE047;
            margin-bottom: 8px;
            letter-spacing: 0.4px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }
        .btn-gold {
            background: linear-gradient(135deg, #B45309 0%, #D97706 50%, #F59E0B 100%) !important;
            color: #090D16 !important;
            border: 1.5px solid #FEF08A !important;
            font-weight: 900 !important;
            text-shadow: none !important;
        }
        .btn-outline {
            background: rgba(15, 23, 42, 0.88) !important;
            color: #F8FAFC !important;
            border: 1.5px solid rgba(212, 175, 55, 0.55) !important;
        }
        .btn-danger {
            background: linear-gradient(135deg, #7F1D1D 0%, #DC2626 100%) !important;
            color: #FEF2F2 !important;
            border: 1.5px solid #FCA5A5 !important;
        }

        /* Vitrine 3D na Ficha, Arena e Mesas Online */
        .t20-3d-viewport {
            perspective: 900px;
            transform-style: preserve-3d;
        }
        .t20-3d-rotatable {
            transition: transform 0.38s cubic-bezier(0.22, 1, 0.36, 1);
            transform-style: preserve-3d;
            will-change: transform;
        }
        @keyframes t20Turntable3D {
            0% { transform: perspective(850px) rotateX(6deg) rotateY(-18deg) scale(1.02); }
            50% { transform: perspective(850px) rotateX(10deg) rotateY(18deg) scale(1.05); }
            100% { transform: perspective(850px) rotateX(6deg) rotateY(-18deg) scale(1.02); }
        }
        .t20-3d-auto-orbit {
            animation: t20Turntable3D 7s ease-in-out infinite !important;
        }

        /* Ajustes Finos Mobile-First para Telas de Celular */
        @media (max-width: 768px) {
            body { padding-bottom: 76px !important; }
            .topbar { padding: 8px 12px !important; gap: 6px !important; }
            .topbar h1 { font-size: 14px !important; line-height: 1.2 !important; }
            .topbar .subtitle { font-size: 10.5px !important; }
            .quick-pill { padding: 3px 8px !important; font-size: 10.5px !important; }
            .container-app { margin: 8px auto !important; padding: 0 8px !important; }
            .sheet-card, .panel-body, .card, .arena-stage { padding: 10px !important; border-radius: 12px !important; }
            .t20-header-grid {
                grid-template-columns: 1fr !important;
                gap: 8px !important;
                padding: 10px !important;
            }
            .t20-attr-shield-row {
                grid-template-columns: repeat(3, 1fr) !important;
                gap: 6px !important;
            }
            .t20-attr-shield .val { font-size: 20px !important; }
            .t20-pv-pm-grid {
                grid-template-columns: 1fr !important;
                gap: 8px !important;
            }
            .t20-defesa-equation {
                justify-content: center !important;
                gap: 4px !important;
                padding: 8px 6px !important;
            }
            .t20-def-box { min-width: 48px !important; padding: 4px 5px !important; }
            .t20-def-box .n { font-size: 14.5px !important; }
            .arena-vs-grid {
                grid-template-columns: 1fr !important;
                gap: 10px !important;
            }
            .form-grid, .form-row {
                grid-template-columns: 1fr !important;
                gap: 8px !important;
            }
            .bottom-nav {
                height: 64px !important;
                grid-template-columns: repeat(7, minmax(0, 1fr)) !important;
            }
            .nav-btn {
                font-size: 9.5px !important;
                padding: 4px 1px !important;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .nav-btn .ico { font-size: 16px !important; margin-bottom: 1px !important; }
        }

        
        /* === Design System Editorial — Códice de Arton === */
        body {
            background-color: var(--t20-bg-deep);
            color: var(--t20-ink);
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            -webkit-font-smoothing: antialiased;
        }
        .topbar {
            background: linear-gradient(180deg, #161922 0%, #11141C 100%) !important;
            border-bottom: 1px solid var(--t20-border) !important;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.35) !important;
            padding: 11px 20px !important;
        }
        .topbar h1 {
            font-family: 'Cinzel', Georgia, serif !important;
            font-size: 19px !important;
            font-weight: 700 !important;
            letter-spacing: 0.04em !important;
            background: none !important;
            -webkit-background-clip: border-box !important;
            -webkit-text-fill-color: var(--t20-ink) !important;
            color: var(--t20-ink) !important;
            text-shadow: none !important;
        }
        .topbar .subtitle {
            color: var(--t20-muted) !important;
            font-size: 12px !important;
            font-weight: 500 !important;
            letter-spacing: 0.01em;
        }
        .app-nav-bar {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(105px, 1fr));
            gap: 4px;
            background: var(--t20-bg-card);
            padding: 5px;
            border-radius: 10px;
            border: 1px solid var(--t20-border);
        }
        .app-nav-bar .nav-btn {
            display: inline-flex !important;
            flex-direction: row !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 7px;
            padding: 8px 10px !important;
            border-radius: 7px !important;
            border: 1px solid transparent !important;
            background: transparent !important;
            color: var(--t20-muted) !important;
            font-size: 12.5px !important;
            font-weight: 600 !important;
            box-shadow: none !important;
            transition: background 0.15s ease, color 0.15s ease, border-color 0.15s ease;
        }
        .app-nav-bar .nav-btn:hover {
            background: rgba(232, 229, 220, 0.06) !important;
            color: var(--t20-ink) !important;
        }
        .app-nav-bar .nav-btn.active {
            background: var(--t20-bg-section) !important;
            color: var(--t20-gold-bright) !important;
            border: 1px solid var(--t20-gold-border) !important;
            box-shadow: none !important;
        }
        .nav-ico {
            width: 15px;
            height: 15px;
            stroke: currentColor;
            fill: none;
            stroke-width: 1.75;
            stroke-linecap: round;
            stroke-linejoin: round;
            flex-shrink: 0;
        }
        .theme-select {
            width: auto;
            min-height: 32px;
            padding: 4px 10px;
            font-size: 12px;
            background: var(--t20-bg-section);
            color: var(--t20-ink);
            border: 1px solid var(--t20-border);
            border-radius: 7px;
            font-weight: 600;
            cursor: pointer;
        }
        .topbar-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 10px;
            border-radius: 6px;
            background: var(--t20-bg-section);
            border: 1px solid var(--t20-border);
            font-size: 12px;
            font-weight: 600;
            color: var(--t20-ink);
            font-variant-numeric: tabular-nums;
        }
        .topbar-pill .stat-label {
            color: var(--t20-muted);
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .topbar-pill.stat-pv .stat-val { color: #6CC296; }
        .topbar-pill.stat-pm .stat-val { color: #79B4E2; }
        .topbar-pill.stat-def .stat-val { color: var(--t20-gold-bright); }
        .topbar-pill.stat-score .stat-val { color: #C5A8E0; }

        /* Harmonização dos cartões principais, cabeçalhos e medalhões da Ficha */
        body:not([data-app-theme="PARCHMENT"]):not([data-app-theme="PIXEL16"]) .panel,
        body:not([data-app-theme="PARCHMENT"]):not([data-app-theme="PIXEL16"]) .sheet-card {
            background: var(--t20-bg-card);
            border: 1px solid var(--t20-border);
            border-radius: 11px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.30);
        }
        body:not([data-app-theme="PARCHMENT"]):not([data-app-theme="PIXEL16"]) .panel-header {
            background: linear-gradient(90deg, #221519 0%, #191C26 100%);
            color: var(--t20-ink);
            border-bottom: 1px solid var(--t20-border);
            text-shadow: none;
            letter-spacing: 0.04em;
        }
        body:not([data-app-theme="PARCHMENT"]):not([data-app-theme="PIXEL16"]) .stat-pill {
            background: var(--t20-bg-section);
            border: 1px solid var(--t20-border);
            border-radius: 9px;
            box-shadow: none;
        }
        body:not([data-app-theme="PARCHMENT"]):not([data-app-theme="PIXEL16"]) .stat-pill .num {
            color: var(--t20-gold-bright);
            text-shadow: none;
        }
        body:not([data-app-theme="PARCHMENT"]):not([data-app-theme="PIXEL16"]) .attr-badge {
            background: linear-gradient(180deg, #241519 0%, #171A24 100%);
            border: 1px solid var(--t20-gold-border);
            border-radius: 9px;
            box-shadow: none;
        }
        body:not([data-app-theme="PARCHMENT"]):not([data-app-theme="PIXEL16"]) .attr-badge .sigla {
            color: var(--t20-gold-bright);
        }

        /* Painéis e tabelas semânticas (Movimento, Equipamentos, Matriz e Simulador) */
        .t20-panel {
            margin-top: 16px;
            background: var(--t20-bg-card);
            border: 1px solid var(--t20-border);
            border-radius: 10px;
            padding: 16px;
        }
        .t20-panel-header {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        .t20-panel-title {
            margin: 0;
            font-family: 'Cinzel', Georgia, serif;
            font-size: 14.5px;
            font-weight: 700;
            color: var(--t20-ink);
            letter-spacing: 0.02em;
        }
        .t20-panel-subtitle {
            margin: 0 0 12px 0;
            font-size: 12px;
            line-height: 1.5;
            color: var(--t20-muted);
        }
        .t20-filter-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
        }
        .t20-calc-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(145px, 1fr));
            gap: 8px;
            margin-bottom: 10px;
        }
        .t20-select {
            background: var(--t20-bg-section);
            color: var(--t20-ink);
            border: 1px solid var(--t20-border);
            border-radius: 6px;
            padding: 6px 10px;
            font-size: 12px;
            font-weight: 500;
        }
        .t20-select:focus { outline: none; border-color: var(--t20-gold-border); }
        .t20-btn-primary {
            background: var(--t20-ruby);
            color: #F8F6F0;
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 6px;
            padding: 7px 14px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.15s ease;
        }
        .t20-btn-primary:hover { background: #8E2423; }
        .t20-table-wrap {
            overflow-x: auto;
            border: 1px solid var(--t20-border);
            border-radius: 8px;
        }
        .t20-table-scroll { max-height: 430px; overflow-y: auto; }
        .t20-data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
            color: var(--t20-ink);
            font-variant-numeric: tabular-nums;
        }
        .t20-data-table thead th {
            position: sticky;
            top: 0;
            background: var(--t20-bg-section);
            color: var(--t20-muted);
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            padding: 9px 10px;
            border-bottom: 1px solid var(--t20-border);
            text-align: right;
        }
        .t20-data-table thead th:first-child,
        .t20-data-table tbody td:first-child { text-align: left; }
        .t20-data-table tbody td {
            padding: 8px 10px;
            border-bottom: 1px solid rgba(232, 229, 220, 0.06);
            text-align: right;
        }
        .t20-data-table tbody tr:hover { background: rgba(232, 229, 220, 0.03); }
        .t20-tier-base { color: var(--t20-ink); font-weight: 500; }
        .t20-tier-sup { color: var(--t20-info); font-weight: 600; }
        .t20-tier-mag { color: var(--t20-arcane); font-weight: 600; }
        .t20-tier-both { color: #6CC296; font-weight: 700; }
        .t20-delta-pos { color: #6CC296; font-weight: 600; }
        .t20-delta-muted { color: var(--t20-muted); }
        .t20-score-col { color: var(--t20-gold-bright); font-weight: 700; }
        .t20-meta-line {
            padding: 9px 12px;
            background: var(--t20-bg-section);
            border: 1px solid var(--t20-border);
            border-radius: 7px;
            font-size: 12px;
            color: var(--t20-muted);
            margin-bottom: 10px;
        }
        .t20-meta-line strong { color: var(--t20-ink); }
        
        /* === Refino Editorial de Controles & Otimização Mobile-First === */
        .t20-hud-tab-btn {
            background: var(--t20-bg-section) !important;
            color: var(--t20-muted) !important;
            border: 1px solid var(--t20-border) !important;
            border-radius: 7px !important;
            font-weight: 600 !important;
            box-shadow: none !important;
            text-shadow: none !important;
        }
        .t20-hud-tab-btn.active-hud-tab {
            background: var(--t20-bg-card) !important;
            color: var(--t20-gold-bright) !important;
            border-color: var(--t20-gold-border) !important;
        }
        .btn-primary, .btn-opt, .btn-ia {
            background: var(--t20-ruby) !important;
            color: #F8F6F0 !important;
            border: 1px solid rgba(255, 255, 255, 0.12) !important;
            box-shadow: none !important;
            text-shadow: none !important;
        }
        .btn-primary:hover, .btn-opt:hover, .btn-ia:hover {
            background: #8E2423 !important;
        }
        .arena-stage, #mesa-2d-stage-svg-box, #arena-2d-grid-interactive-box, #mesa-2d-grid-interactive-box {
            max-width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            touch-action: manipulation;
        }

        /* Mobile-First: navegação única, alvos de toque confortáveis e zero auto-zoom no iOS */
        @media (max-width: 860px) {
            body {
                padding-bottom: calc(74px + env(safe-area-inset-bottom, 0px)) !important;
            }
            .app-nav-bar {
                display: none !important;
            }
            .topbar {
                padding: 10px 12px !important;
                gap: 8px !important;
            }
            .topbar h1 {
                font-size: 16px !important;
            }
            .topbar .subtitle {
                font-size: 11px !important;
            }
            .mobile-quick-bar {
                width: 100%;
                gap: 5px !important;
                justify-content: flex-start;
            }
            .topbar-pill {
                padding: 4px 8px;
                font-size: 11px;
            }
            .theme-select {
                font-size: 12px;
                min-height: 34px;
            }
            .bottom-nav {
                display: flex !important;
                align-items: stretch;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                gap: 2px;
                background: #12151E !important;
                border-top: 1px solid var(--t20-border) !important;
                padding: 5px 6px calc(5px + env(safe-area-inset-bottom, 0px)) !important;
                box-shadow: 0 -4px 16px rgba(0, 0, 0, 0.45) !important;
            }
            .bottom-nav .nav-btn {
                flex: 1 0 auto;
                min-width: 66px;
                min-height: 44px;
                padding: 6px 8px !important;
                border-radius: 7px !important;
                border-top: 2px solid transparent !important;
                background: transparent !important;
                color: var(--t20-muted) !important;
                font-size: 11px !important;
                font-weight: 600 !important;
                box-shadow: none !important;
            }
            .bottom-nav .nav-btn.active {
                background: var(--t20-bg-section) !important;
                color: var(--t20-gold-bright) !important;
                border-top: 2px solid var(--t20-gold) !important;
            }
            input[type='text'], input[type='number'], select, textarea, .t20-select {
                font-size: 16px !important;
                min-height: 42px;
            }
            button, .t20-btn-primary {
                min-height: 40px;
                touch-action: manipulation;
            }
            .t20-panel {
                padding: 12px;
                margin-top: 12px;
            }
            .t20-data-table {
                font-size: 11px;
            }
            .t20-data-table thead th,
            .t20-data-table tbody td {
                padding: 6px 7px;
            }
        }
        @media (max-width: 640px) {
            .t20-calc-grid,
            .sheet-columns,
            .arena-vs-grid,
            .form-row {
                grid-template-columns: 1fr !important;
            }
            .stats-strip,
            .attr-strip {
                grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
                gap: 6px !important;
            }
        }

        
/* Editorial Craftsmanship Polish */
body { font-feature-settings: "cv02", "cv03", "cv04", "cv11"; -webkit-font-smoothing: antialiased; }
table, .t20-data-table, .stat-val, .kpi-value { font-variant-numeric: tabular-nums; }
.card, .t20-panel {
    background: #151821 !important;
    border: 1px solid rgba(232, 229, 220, 0.09) !important;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.28) !important;
}
button:focus-visible, select:focus-visible, input:focus-visible {
    outline: 2px solid #C99B42 !important;
    outline-offset: 2px !important;
}
.btn-save, .btn-primary {
    background: #8C2323 !important;
    border: 1px solid rgba(201, 155, 66, 0.45) !important;
    color: #F4F1EA !important;
    box-shadow: none !important;
    transition: background 0.16s ease, border-color 0.16s ease !important;
}
.btn-save:hover, .btn-primary:hover {
    background: #A62C2B !important;
    border-color: #C99B42 !important;
}
details.t20-collapsible {
    background: #141720 !important;
    border: 1px solid rgba(232, 229, 220, 0.10) !important;
    border-radius: 8px !important;
}
details.t20-collapsible > summary {
    cursor: pointer;
    list-style: none;
    color: #D8B465 !important;
    font-weight: 600 !important;
    letter-spacing: 0.01em;
}


/* Arena & Mesa Online Button Polish (v100) */
#tab-arena button,
#tab-mesa-online button,
#arena-combat-screen-shell button,
#mesa-combat-screen-shell button {
    background: #1B202C;
    color: #E8E5DC;
    border: 1px solid rgba(201, 155, 66, 0.28);
    border-radius: 7px;
    font-weight: 600;
    letter-spacing: 0.01em;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.26);
    transition: background 0.15s ease, border-color 0.15s ease, transform 0.1s ease, color 0.15s ease;
    cursor: pointer;
}
#tab-arena button:hover:not(:disabled),
#tab-mesa-online button:hover:not(:disabled),
#arena-combat-screen-shell button:hover:not(:disabled),
#mesa-combat-screen-shell button:hover:not(:disabled) {
    background: #242B3B;
    border-color: rgba(201, 155, 66, 0.60);
    color: #F6F3EC;
}
#tab-arena button:active:not(:disabled),
#tab-mesa-online button:active:not(:disabled) {
    transform: translateY(1px);
}
#tab-arena .btn-outline,
#tab-mesa-online .btn-outline {
    background: #181C26 !important;
    color: #E2DDD2 !important;
    border: 1px solid rgba(232, 229, 220, 0.22) !important;
}
#tab-arena .btn-outline:hover:not(:disabled),
#tab-mesa-online .btn-outline:hover:not(:disabled) {
    background: #232938 !important;
    border-color: #C99B42 !important;
    color: #F6F3EC !important;
}
#tab-arena .btn-manual,
#tab-mesa-online .btn-manual {
    background: #1F2636 !important;
    color: #E8E5DC !important;
    border: 1px solid rgba(201, 155, 66, 0.34) !important;
}
#tab-arena .btn-manual:hover:not(:disabled),
#tab-mesa-online .btn-manual:hover:not(:disabled) {
    background: #293247 !important;
    border-color: #C99B42 !important;
}
#tab-arena .btn-gold,
#tab-mesa-online .btn-gold {
    background: #2A2316 !important;
    color: #E9C77B !important;
    border: 1px solid rgba(201, 155, 66, 0.58) !important;
}
#tab-arena .btn-gold:hover:not(:disabled),
#tab-mesa-online .btn-gold:hover:not(:disabled) {
    background: #382E1B !important;
    border-color: #E3BE6D !important;
    color: #FAF3DF !important;
}
#tab-arena .btn-ai,
#tab-mesa-online .btn-ai {
    background: #251B2E !important;
    color: #E8E2F4 !important;
    border: 1px solid rgba(201, 155, 66, 0.42) !important;
}
#tab-arena .btn-ai:hover:not(:disabled),
#tab-mesa-online .btn-ai:hover:not(:disabled) {
    background: #332440 !important;
    border-color: #C99B42 !important;
}
#tab-arena .btn-danger,
#tab-mesa-online .btn-danger {
    background: #36181A !important;
    color: #F5CECE !important;
    border: 1px solid rgba(196, 68, 68, 0.55) !important;
}
#tab-arena .btn-danger:hover:not(:disabled),
#tab-mesa-online .btn-danger:hover:not(:disabled) {
    background: #4C1F22 !important;
    border-color: #DC5C5C !important;
}
#tab-arena .btn-save,
#tab-mesa-online .btn-save {
    background: #8C2323 !important;
    color: #F6F3EC !important;
    border: 1px solid rgba(201, 155, 66, 0.50) !important;
}
#tab-arena .btn-save:hover:not(:disabled),
#tab-mesa-online .btn-save:hover:not(:disabled) {
    background: #A62C2B !important;
    border-color: #E3BE6D !important;
}
#tab-arena button:disabled,
#tab-mesa-online button:disabled {
    opacity: 0.48;
    cursor: not-allowed;
}


/* Dynamic Inline Passives & Action Cards Mobile-First (v100) */
#t20-passives-side-drawer,
#t20-passives-drawer-backdrop {
    display: none !important;
}
.t20-passives-toggle-btn {
    background: #1C2230 !important;
    color: #E3BE6D !important;
    border: 1px solid rgba(201, 155, 66, 0.48) !important;
    border-radius: 7px !important;
    padding: 5px 11px !important;
    min-height: 34px !important;
    font-size: 11.5px !important;
    font-weight: 700 !important;
    letter-spacing: 0.01em;
    cursor: pointer;
    transition: background 0.15s ease, border-color 0.15s ease;
}
.t20-passives-toggle-btn:hover,
.t20-passives-toggle-btn.is-active {
    background: #2A2316 !important;
    border-color: #E3BE6D !important;
    color: #FAF3DF !important;
}
.t20-passive-inline-panel {
    margin-top: 8px;
    padding: 10px;
    background: #12151E;
    border: 1px solid rgba(201, 155, 66, 0.28);
    border-radius: 8px;
    animation: t20FadeIn 0.16s ease;
}
@keyframes t20FadeIn {
    from { opacity: 0; transform: translateY(-3px); }
    to { opacity: 1; transform: translateY(0); }
}
.t20-passive-inline-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
    padding-bottom: 6px;
    border-bottom: 1px solid rgba(232, 229, 220, 0.10);
    font-size: 12px;
    font-weight: 700;
    color: #E3BE6D;
}
.t20-passive-close-btn {
    background: #1B202C !important;
    color: #C8C2B4 !important;
    border: 1px solid rgba(232, 229, 220, 0.18) !important;
    border-radius: 6px !important;
    padding: 3px 9px !important;
    min-height: 28px !important;
    font-size: 11px !important;
}
.t20-passive-cards-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 7px;
}
.t20-passive-card {
    background: #171B25;
    border: 1px solid rgba(232, 229, 220, 0.09);
    border-left: 2px solid #C99B42;
    border-radius: 6px;
    padding: 8px 10px;
}
.t20-passive-card-head {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    gap: 6px;
    margin-bottom: 3px;
}
.t20-passive-card-title {
    font-size: 12px;
    font-weight: 700;
    color: #F0ECE1;
}
.t20-passive-card-origin {
    font-size: 10px;
    color: #C99B42;
    background: rgba(201, 155, 66, 0.12);
    padding: 1px 6px;
    border-radius: 4px;
    white-space: nowrap;
}
.t20-passive-card-desc {
    font-size: 11px;
    line-height: 1.38;
    color: #B4AEA2;
}
.t20-passive-empty {
    font-size: 11.5px;
    color: #9A9488;
    padding: 6px 2px;
}
.t20-v67-cat-tabs {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-bottom: 8px;
}
.t20-v67-cat-tabs button {
    min-height: 36px;
    padding: 5px 10px;
    font-size: 11.5px;
}
.t20-v68-skills-grid,
.t20-v67-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(195px, 1fr));
    gap: 7px;
}
@media (max-width: 640px) {
    .t20-passive-cards-grid,
    .t20-v68-skills-grid,
    .t20-v67-actions-grid {
        grid-template-columns: 1fr;
    }
    #tab-arena button,
    #tab-mesa-online button {
        min-height: 40px;
    }
    .t20-v67-cat-tabs {
        flex-wrap: nowrap;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        padding-bottom: 4px;
    }
    .t20-v67-cat-tabs button {
        flex: 0 0 auto;
        white-space: nowrap;
    }
}

"""

    @classmethod
    def gerar_qss_qt(cls) -> str:
        return """
        QMainWindow, QWidget { background-color: #EFE8DC; color: #1F1A17; font-family: 'Segoe UI', Arial; font-size: 13px; }
        QGroupBox { background-color: #FBF7F0; border: 1px solid rgba(166, 44, 43, 0.45); border-radius: 8px; margin-top: 10px; font-weight: bold; color: #5A1014; padding: 10px; }
        QPushButton { background-color: #8B1E24; color: #FFFFFF; border: 1px solid #C89D54; border-radius: 6px; padding: 8px 12px; font-weight: bold; }
        QComboBox, QLineEdit, QSpinBox { background-color: #FFFFFF; border: 1px solid #C5B6A2; border-radius: 4px; padding: 4px; }
        QTextBrowser { background-color: #FBF7F0; border: 1px solid rgba(166, 44, 43, 0.45); border-radius: 8px; padding: 12px; }
        
/* === MODO TELA CHEIA DE COMBATE & HUD DINÂMICO DE BAIXA POLUIÇÃO VISUAL (v62) === */
body.t20-body-lock-fullscreen {
    overflow: hidden !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active {
    position: fixed !important;
    inset: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    max-width: 100vw !important;
    max-height: 100vh !important;
    z-index: 99999 !important;
    background: radial-gradient(circle at 50% 30%, #111827 0%, #05070E 100%) !important;
    padding: 8px 12px !important;
    margin: 0 !important;
    border-radius: 0 !important;
    border: 1px solid rgba(201, 155, 66, 0.28) !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    overflow-y: auto !important;
    box-sizing: border-box !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active #jrpg-battle-stage,
.t20-combat-screen-shell.t20-combat-fullscreen-active #mesa-2d-stage-svg-box {
    flex: 1 1 auto !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: center !important;
    min-height: 0 !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-dynamic-hud-drawer {
    max-height: 29vh !important;
    overflow-y: auto !important;
}
.t20-hud-tab-btn {
    background: #1E293B;
    color: #E2E8F0;
    border: 1.5px solid #475569;
    border-radius: 8px;
    padding: 5px 10px;
    font-size: 11px;
    font-weight: 800;
    cursor: pointer;
    transition: all 0.16s ease;
}
.t20-hud-tab-btn:hover {
    border-color: #FACC15;
    color: #FEF08A;
    background: #334155;
}
.t20-hud-tab-btn.active-hud-tab {
    background: linear-gradient(135deg, #9A3412, #D97706);
    color: #FEF08A;
    border-color: #FEF08A;
    box-shadow: 0 0 10px rgba(245, 158, 11, 0.45);
}


/* === CORREÇÃO DEFINITIVA DE TELA CHEIA NO CELULAR (ANDROID / iOS) & HUD COMPLETO (v65) === */
html.t20-body-lock-fullscreen,
body.t20-body-lock-fullscreen {
    overflow: hidden !important;
    width: 100vw !important;
    height: 100vh !important;
    height: 100dvh !important;
    margin: 0 !important;
    padding: 0 !important;
    background: #05070E !important;
    transform: none !important;
    filter: none !important;
    perspective: none !important;
}
body.t20-body-lock-fullscreen > header,
body.t20-body-lock-fullscreen > .topbar,
body.t20-body-lock-fullscreen > .container-app,
body.t20-body-lock-fullscreen > nav.bottom-nav,
body.t20-body-lock-fullscreen .arena-hide-on-fullscreen {
    display: none !important;
}
body.t20-body-lock-fullscreen main,
body.t20-body-lock-fullscreen .tab-section.active,
body.t20-body-lock-fullscreen .arena-stage {
    animation: none !important;
    transform: none !important;
    filter: none !important;
    perspective: none !important;
    will-change: auto !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
    border-radius: 0 !important;
    max-width: 100vw !important;
    background: #05070E !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active {
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    height: 100dvh !important;
    max-width: 100vw !important;
    max-height: 100dvh !important;
    z-index: 2147483647 !important;
    background: radial-gradient(circle at 50% 20%, #111827 0%, #05070E 100%) !important;
    padding: 6px 8px 28px 8px !important;
    margin: 0 !important;
    border-radius: 0 !important;
    border: none !important;
    display: block !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    -webkit-overflow-scrolling: touch !important;
    box-sizing: border-box !important;
}
#arena-fullscreen-sticky-bar {
    display: none;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-fullscreen-sticky-bar {
    display: flex !important;
    position: sticky !important;
    top: 0 !important;
    z-index: 9999 !important;
    background: linear-gradient(90deg, #1E0508 0%, #0F172A 55%, #1E0508 100%) !important;
    border: 1.5px solid #FACC15 !important;
    border-radius: 8px !important;
    padding: 6px 8px !important;
    margin-bottom: 6px !important;
    align-items: center !important;
    justify-content: space-between !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
    box-shadow: 0 6px 18px rgba(0,0,0,0.85) !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-dynamic-hud-drawer {
    max-height: none !important;
    overflow-y: visible !important;
}
@media (max-width: 860px) {
    .t20-combat-screen-shell.t20-combat-fullscreen-active #jrpg-svg-scene-container svg {
        max-height: 44dvh !important;
    }
    .t20-hud-tab-btn {
        padding: 6px 8px !important;
        font-size: 10.5px !important;
        flex: 1 1 auto !important;
        text-align: center !important;
    }
}


/* === UPGRADE v66: STICKY BAR MESA ONLINE FULLSCREEN + PAINEL DE AÇÕES POR CLIQUE + MODAL DE ALGORITMOS === */
#mesa-fullscreen-sticky-bar {
    display: none;
}
.t20-combat-fullscreen-active #mesa-fullscreen-sticky-bar {
    display: flex !important;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
    position: sticky;
    top: 0;
    z-index: 2147483647;
    background: linear-gradient(90deg, #090D16 0%, #1E1B4B 55%, #090D16 100%);
    border-bottom: 2px solid #FACC15;
    padding: 6px 10px;
    margin: -8px -8px 8px -8px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.88);
}
.t20-clicked-char-dock {
    background: linear-gradient(180deg, rgba(15,23,42,0.97) 0%, rgba(7,10,19,0.99) 100%);
    border: 2px solid #FACC15;
    border-radius: 10px;
    padding: 8px 10px;
    box-shadow: 0 8px 22px rgba(0,0,0,0.75);
}
.t20-action-chip-btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 9px;
    border-radius: 7px;
    font-size: 11px;
    font-weight: 800;
    cursor: pointer;
    border: 1.5px solid rgba(250,204,21,0.55);
    color: #FEF08A;
    background: #1E293B;
    transition: transform 0.12s ease, box-shadow 0.12s ease, filter 0.12s ease;
}
.t20-action-chip-btn:hover, .t20-action-chip-btn:active {
    transform: translateY(-1px) scale(1.02);
    filter: brightness(1.14);
    box-shadow: 0 3px 10px rgba(250,204,21,0.35);
}


/* === UPGRADE v67: TELA CHEIA EXCLUSIVA DA CENA DE COMBATE + DOCK CATEGORIZADO + MENU LATERAL DE PASSIVAS === */
.t20-combat-screen-shell.t20-combat-fullscreen-active {
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    padding: 4px 6px 6px 6px !important;
    overflow: hidden !important;
    background: #04070E !important;
}
/* Ocultar painéis externos na Tela Cheia da ARENA para exibir APENAS a cena de combate + ações categorizadas */
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-dynamic-hud-dock,
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-stage-threats-quickbar,
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-turn-economy-hud,
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-grid2d-panel-wrap,
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-placar-cards,
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-log-combate-card,
.t20-combat-screen-shell.t20-combat-fullscreen-active .t20-hide-in-fullscreen {
    display: none !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active #jrpg-battle-stage {
    margin-top: 0 !important;
    flex: 1 1 auto !important;
    min-height: 0 !important;
    display: flex !important;
    flex-direction: column !important;
    border-width: 2px !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active #jrpg-battle-stage > div:last-child {
    flex: 1 1 auto !important;
    min-height: 0 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    background: #050811 !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active #jrpg-svg-scene-container {
    width: 100% !important;
    height: 100% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active #jrpg-svg-scene-container svg {
    width: 100% !important;
    height: 100% !important;
    max-height: 60dvh !important;
    object-fit: contain !important;
}
.t20-combat-screen-shell.t20-combat-fullscreen-active #arena-clicked-character-actions-bar,
.t20-combat-screen-shell.t20-combat-fullscreen-active #mesa-clicked-character-actions-bar {
    flex: 0 0 auto !important;
    margin-top: 4px !important;
    max-height: 31dvh !important;
    overflow-y: auto !important;
    z-index: 40 !important;
}
/* Ocultar cartões de configuração/log na Tela Cheia da MESA ONLINE para exibir APENAS a cena + ações */
#mesa-combat-screen-shell.t20-combat-fullscreen-active > :not(#mesa-fullscreen-sticky-bar):not(#mesa-palco-grid2d-card):not(#mesa-palco-hd2d-wrapper):not(#mesa-clicked-character-actions-bar):not(#t20-passives-side-drawer):not(#mesa-online-grid2d-container):not(#mesa-online-palco-wrapper) {
    display: none !important;
}
#mesa-combat-screen-shell.t20-combat-fullscreen-active #mesa-online-grid2d-container svg,
#mesa-combat-screen-shell.t20-combat-fullscreen-active #mesa-palco-hd2d-svg-box svg {
    max-height: 58dvh !important;
    width: 100% !important;
    object-fit: contain !important;
}

/* Barra de Categorias de Ações Ativas (Ofensivo, Defensivo, Buff, Debuffs, Cura) */
.t20-v67-cat-tabs {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
    margin-bottom: 7px;
    padding-bottom: 6px;
    border-bottom: 1px solid rgba(148, 163, 184, 0.25);
}
.t20-v67-cat-btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 10px;
    border-radius: 8px;
    font-size: 11px;
    font-weight: 900;
    cursor: pointer;
    border: 1.5px solid rgba(148, 163, 184, 0.35);
    background: rgba(15, 23, 42, 0.85);
    color: #CBD5E1;
    transition: all 0.14s ease;
}
.t20-v67-cat-btn:hover { filter: brightness(1.18); transform: translateY(-1px); }
.t20-v67-cat-btn.cat-active-OFENSIVO { background: linear-gradient(135deg,#991B1B,#DC2626); border-color: #FCA5A5; color: #FFF; box-shadow: 0 0 12px rgba(239,68,68,0.55); }
.t20-v67-cat-btn.cat-active-DEFENSIVO { background: linear-gradient(135deg,#1E3A8A,#2563EB); border-color: #93C5FD; color: #FFF; box-shadow: 0 0 12px rgba(59,130,246,0.55); }
.t20-v67-cat-btn.cat-active-BUFF { background: linear-gradient(135deg,#B45309,#D97706); border-color: #FDE047; color: #FFF; box-shadow: 0 0 12px rgba(245,158,11,0.55); }
.t20-v67-cat-btn.cat-active-DEBUFFS { background: linear-gradient(135deg,#581C87,#9333EA); border-color: #D8B4FE; color: #FFF; box-shadow: 0 0 12px rgba(168,85,247,0.55); }
.t20-v67-cat-btn.cat-active-CURA { background: linear-gradient(135deg,#065F46,#10B981); border-color: #6EE7B7; color: #FFF; box-shadow: 0 0 12px rgba(16,185,129,0.55); }
.t20-v67-cat-count {
    background: rgba(0,0,0,0.45);
    padding: 1px 5px;
    border-radius: 999px;
    font-size: 9.5px;
    color: #FEF08A;
}

/* Cards de Ação Ativa Estilizados */
.t20-v67-actions-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    align-items: stretch;
}
.t20-v67-action-card {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 11px;
    border-radius: 9px;
    font-size: 11.5px;
    font-weight: 800;
    cursor: pointer;
    color: #F8FAFC;
    border: 1.5px solid rgba(255,255,255,0.22);
    box-shadow: 0 3px 10px rgba(0,0,0,0.45);
    transition: transform 0.12s ease, box-shadow 0.12s ease, filter 0.12s ease;
}
.t20-v67-action-card:hover, .t20-v67-action-card:active {
    transform: translateY(-2px) scale(1.02);
    filter: brightness(1.16);
    box-shadow: 0 5px 16px rgba(250,204,21,0.35);
}
.t20-v67-pm-badge {
    background: rgba(2, 6, 23, 0.72);
    color: #38BDF8;
    border: 1px solid rgba(56, 189, 248, 0.45);
    padding: 1px 5px;
    border-radius: 5px;
    font-size: 9.5px;
    font-weight: 900;
}

/* Menu Lateral Retrátil de Habilidades Passivas */
#t20-passives-side-drawer {
    position: fixed;
    top: 0;
    right: -380px;
    width: min(350px, 88vw);
    height: 100vh;
    height: 100dvh;
    z-index: 2147483647;
    background: linear-gradient(180deg, rgba(10, 15, 30, 0.98) 0%, rgba(5, 8, 18, 0.99) 100%);
    border-left: 2.5px solid #D4AF37;
    box-shadow: -12px 0 34px rgba(0, 0, 0, 0.85);
    transition: right 0.24s cubic-bezier(0.22, 1, 0.36, 1);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    color: #E2E8F0;
}
#t20-passives-side-drawer.drawer-open {
    right: 0;
}
.t20-passive-item-card {
    background: rgba(30, 41, 59, 0.72);
    border: 1px solid rgba(148, 163, 184, 0.32);
    border-left: 3.5px solid #38BDF8;
    border-radius: 8px;
    padding: 8px 10px;
    margin-bottom: 7px;
    font-size: 11.5px;
    line-height: 1.4;
}


/* === UPGRADE v68: POLIMENTO DE CARDS DE HABILIDADES, BARRA VTT & FIX PASSIVAS EM TELA CHEIA === */
#t20-passives-backdrop {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(2, 6, 23, 0.62);
    backdrop-filter: blur(2px);
    z-index: 2147483645;
}
#t20-passives-backdrop.drawer-open {
    display: block !important;
}
#t20-passives-side-drawer {
    display: flex !important;
    visibility: hidden;
    pointer-events: none;
    z-index: 2147483647 !important;
}
#t20-passives-side-drawer.drawer-open {
    right: 0 !important;
    visibility: visible !important;
    pointer-events: auto !important;
}
/* Garantir que o drawer e o backdrop nunca sejam escondidos pela regra de fullscreen da Mesa Online */
#mesa-combat-screen-shell.t20-combat-fullscreen-active #t20-passives-side-drawer.drawer-open,
#arena-combat-screen-shell.t20-combat-fullscreen-active #t20-passives-side-drawer.drawer-open {
    display: flex !important;
    visibility: visible !important;
    right: 0 !important;
}
#mesa-combat-screen-shell.t20-combat-fullscreen-active #t20-passives-backdrop.drawer-open,
#arena-combat-screen-shell.t20-combat-fullscreen-active #t20-passives-backdrop.drawer-open {
    display: block !important;
}

/* Cards de Habilidade v68 em Grid Responsivo (2 linhas: Nome + Pílulas Mecânicas) */
.t20-v68-skills-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(185px, 1fr));
    gap: 7px;
    align-items: stretch;
}
.t20-v68-skill-card {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 7px 10px;
    border-radius: 10px;
    text-align: left;
    cursor: pointer;
    border: 1.5px solid rgba(255, 255, 255, 0.16);
    background: linear-gradient(155deg, rgba(22, 31, 52, 0.96), rgba(10, 14, 26, 0.98));
    color: #F8FAFC;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.48);
    transition: transform 0.13s ease, border-color 0.13s ease, box-shadow 0.13s ease;
    position: relative;
    overflow: hidden;
}
.t20-v68-skill-card:hover, .t20-v68-skill-card:active {
    transform: translateY(-2px);
    border-color: #FACC15;
    box-shadow: 0 6px 16px rgba(250, 204, 21, 0.28);
}
.t20-v68-skill-icon {
    width: 32px;
    height: 32px;
    flex: 0 0 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    box-shadow: inset 0 0 10px rgba(0,0,0,0.45);
    border: 1px solid rgba(255,255,255,0.22);
}
.t20-v68-skill-body {
    flex: 1 1 auto;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 3px;
}
.t20-v68-skill-title {
    font-size: 11.5px;
    font-weight: 900;
    color: #FEF9C3;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.t20-v68-skill-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    align-items: center;
}
.t20-v68-pill {
    font-size: 9.5px;
    font-weight: 800;
    padding: 1px 5px;
    border-radius: 4px;
    background: rgba(15, 23, 42, 0.9);
    border: 1px solid rgba(148, 163, 184, 0.35);
    color: #CBD5E1;
}
.t20-v68-pill-pm { color: #38BDF8; border-color: rgba(56, 189, 248, 0.5); }
.t20-v68-pill-atk { color: #FCA5A5; border-color: rgba(248, 113, 113, 0.5); }
.t20-v68-pill-cd { color: #D8B4FE; border-color: rgba(192, 132, 252, 0.5); }
.t20-v68-pill-heal { color: #6EE7B7; border-color: rgba(52, 211, 153, 0.5); }

/* Barra VTT Integrada (Arena e Mesa Online — Normal e Tela Cheia) */
.t20-vtt-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 5px;
    padding: 5px 8px;
    margin-bottom: 6px;
    border-radius: 8px;
    background: linear-gradient(90deg, rgba(15, 23, 42, 0.96), rgba(30, 27, 75, 0.94));
    border: 1px solid rgba(56, 189, 248, 0.45);
}
.t20-vtt-btn {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 10.5px;
    font-weight: 800;
    cursor: pointer;
    border: 1px solid rgba(148, 163, 184, 0.38);
    background: rgba(15, 23, 42, 0.88);
    color: #E2E8F0;
    transition: all 0.12s ease;
}
.t20-vtt-btn:hover { border-color: #FACC15; color: #FEF08A; }
.t20-vtt-btn.vtt-active {
    background: linear-gradient(135deg, #0284C7, #2563EB);
    border-color: #7DD3FC;
    color: #FFF;
    box-shadow: 0 0 10px rgba(56, 189, 248, 0.55);
}
.t20-vtt-cond-chip {
    padding: 2px 6px;
    border-radius: 5px;
    font-size: 9.5px;
    font-weight: 800;
    cursor: pointer;
    border: 1px solid rgba(250, 204, 21, 0.35);
    background: rgba(30, 41, 59, 0.85);
    color: #CBD5E1;
}
.t20-vtt-cond-chip.cond-on {
    background: #991B1B;
    border-color: #FCA5A5;
    color: #FEF08A;
}
@media (max-width: 720px) {
    .t20-v68-skills-grid {
        grid-template-columns: repeat(auto-fill, minmax(148px, 1fr));
    }
}


/* === UPGRADE v69: VISUAL UNIFICADO DE HABILIDADES ESTILO MESA ONLINE (HERÓIS E CRIATURAS) === */
.t20-v69-mesa-skills-wrap {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    align-items: center;
}
.t20-v69-mesa-action-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 11px;
    border-radius: 8px;
    font-size: 11.5px;
    font-weight: 800;
    cursor: pointer;
    color: #FEF9C3;
    border: 1.5px solid rgba(250, 204, 21, 0.55);
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.50);
    transition: transform 0.12s ease, filter 0.12s ease, box-shadow 0.12s ease;
    line-height: 1.25;
}
.t20-v69-mesa-action-btn:hover, .t20-v69-mesa-action-btn:active {
    transform: translateY(-1px) scale(1.02);
    filter: brightness(1.15);
    border-color: #FEF08A;
    box-shadow: 0 5px 14px rgba(250, 204, 21, 0.35);
}
.t20-v69-mesa-stat-badge {
    background: rgba(2, 6, 23, 0.62);
    color: #E2E8F0;
    border: 1px solid rgba(255, 255, 255, 0.22);
    padding: 1px 6px;
    border-radius: 5px;
    font-size: 9.5px;
    font-weight: 900;
}
.t20-v69-mesa-pm-badge {
    background: rgba(2, 6, 23, 0.72);
    color: #7DD3FC;
    border: 1px solid rgba(56, 189, 248, 0.5);
    padding: 1px 5px;
    border-radius: 5px;
    font-size: 9.5px;
    font-weight: 900;
}
        """
