# -*- coding: utf-8 -*-
from __future__ import annotations

import abc
import base64
import copy
import dataclasses
import datetime
from datetime import datetime as dt_cls
import gzip
import hashlib
import zlib
import functools
import html
import http.server
import inspect
import io
import json
import lzma
import math
import os
import pathlib
from pathlib import Path
import random
import re
import socketserver
import sqlite3
import statistics
import string
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import typing
import urllib.parse
import urllib.request
import uuid
import webbrowser
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import (
    Any, Callable, Dict, Generic, Iterable, Iterator, List,
    Literal, Mapping, NamedTuple, Optional, Protocol, Sequence,
    Set, Tuple, Type, TypeVar, Union
)

"""
Camada de Aplicação — Decorators de Modificadores de Ficha (GoF Decorator) e Calculadora Estatística T20.
"""
from ..domain import *



# ==============================================================================


# ==============================================================================
# 3.9 TABELA OFICIAL DE PASSOS DE DANO (p. 142), CRÍTICO & ECONOMIA DE AÇÕES (p. 232)
# ==============================================================================

SEQUENCIA_PASSOS_DANO_T20: Tuple[str, ...] = (
    "1d2", "1d3", "1d4", "1d6", "1d8", "1d10", "1d12", "3d6", "4d6", "4d8", "4d10", "4d12"
)

EQUIVALENCIA_PASSOS_DANO_T20: Dict[str, str] = {
    "2d4": "1d8",
    "2d6": "1d12",
    "2d8": "3d6",
}


def avancar_passos_dano_t20(dano_base_str: str, passos: int) -> Tuple[str, int, int, float]:
    """
    Aplica a Tabela 3-2: Passos de Dano de Armas (Tormenta20 Jogo do Ano, p. 142).
    Retorna (string_dano_final, qtd_dados, faces_dado, media_dados_base).
    """
    limpo = dano_base_str.strip().lower()
    m = re.match(r"(\d+)d(\d+)", limpo)
    if not m:
        return "1d6", 1, 6, 3.5
    dado_orig = f"{m.group(1)}d{m.group(2)}"
    if passos <= 0:
        q, f = int(m.group(1)), int(m.group(2))
        return dado_orig, q, f, q * ((f + 1) / 2.0)

    dado_norm = EQUIVALENCIA_PASSOS_DANO_T20.get(dado_orig, dado_orig)
    try:
        idx = SEQUENCIA_PASSOS_DANO_T20.index(dado_norm)
    except ValueError:
        idx = 3  # 1d6 fallback
    novo_idx = max(0, min(len(SEQUENCIA_PASSOS_DANO_T20) - 1, idx + passos))
    novo_dado = SEQUENCIA_PASSOS_DANO_T20[novo_idx]
    m2 = re.match(r"(\d+)d(\d+)", novo_dado)
    q2 = int(m2.group(1)) if m2 else 1
    f2 = int(m2.group(2)) if m2 else 6
    return novo_dado, q2, f2, q2 * ((f2 + 1) / 2.0)


def extrair_critico_base_arma(critico_str: str) -> Tuple[int, int]:
    """
    Interpreta a notação oficial de crítico de Tormenta20 (p. 142):
    - '19' -> (19, 2)
    - '18' -> (18, 2)
    - 'x3' -> (20, 3)
    - 'x4' -> (20, 4)
    - '19/x3' -> (19, 3)
    - '18/x3' -> (18, 3)
    """
    s = (critico_str or "").strip().lower()
    if not s or s == "—" or s == "-":
        return 20, 2
    margem = 20
    mult = 2
    m_ambos = re.search(r"(\d+)\s*/\s*x(\d+)", s)
    if m_ambos:
        return int(m_ambos.group(1)), int(m_ambos.group(2))
    m_mult = re.search(r"x(\d+)", s)
    if m_mult:
        mult = int(m_mult.group(1))
    m_marg = re.match(r"^(\d+)$", s)
    if m_marg:
        margem = int(m_marg.group(1))
    return max(1, min(20, margem)), max(2, mult)


def pontuar_sinergia_poder_concedido(nome_poder: str, ficha: FichaPersonagem) -> float:
    """
    Otimiza matematicamente a escolha dos Poderes Concedidos pela divindade conforme o Tipo
    (Marcial vs Conjurador), Função Tática (DPS, Burst, Tanque, Suporte), Arma e Raça da ficha.
    """
    nl = nome_poder.strip().lower()
    arq = (ficha.relatorio_ia.arquetipo_alvo or "Dano Marcial").lower()
    eh_conj = ficha.eh_conjurador()
    eh_tanque = any(k in arq for k in ("tanque", "escudo", "defesa"))
    eh_suporte = any(k in arq for k in ("suporte", "cura", "clérigo", "clerigo", "druida"))
    eh_dist = any(k in arq for k in ("arqueiro", "disparo", "distância"))
    tem_espada = bool(ficha.arma_equipada and ("espada" in ficha.arma_equipada.nome.lower() or "montante" in ficha.arma_equipada.nome.lower() or "florete" in ficha.arma_equipada.nome.lower()))
    tem_mordida_ou_chifres = ficha.possui_chifres() or (ficha.raca and ficha.raca.nome.lower() == "trog")

    if "espada justiceira" in nl:
        return 99.0 if (not eh_conj and tem_espada) else 52.0
    if "sangue de ferro" in nl:
        return 98.0 if (not eh_conj and not eh_dist) else 45.0
    if "armas da ambição" in nl:
        return 97.0 if not eh_conj else 42.0
    if "presas primordiais" in nl:
        return 96.5 if (not eh_conj and tem_mordida_ou_chifres) else (88.0 if not eh_conj else 35.0)
    if "fúria divina" in nl:
        return 94.0 if (not eh_conj and not eh_dist) else 30.0
    if "kiai divino" in nl:
        return 93.5 if not eh_conj else 30.0
    if "espada solar" in nl or "arma sagrada" in nl:
        return 95.0 if not eh_conj else 45.0
    if "almejar o impossível" in nl:
        return 91.0 if not eh_conj else 68.0
    if "mente vazia" in nl:
        return 89.0  # +2 Iniciativa, +2 Percepção e +2 Vontade!
    if "coragem total" in nl:
        return 92.0 if (ficha.raca and ficha.raca.nome.lower() == "minotauro") else (88.0 if eh_tanque else 74.0)
    if "escamas dracônicas" in nl:
        return 96.0 if eh_tanque else 82.0

    # Poderes Concedidos Ofensivos / Marciais de Topo
    if "armas da ambição" in nl:
        return 95.0 if not eh_conj else 40.0  # +1 ataque e +1 margem de ameaça!
    if "sangue de ferro" in nl:
        return 92.0 if not eh_conj else 35.0  # +2 dano e RD 5!
    if any(k in nl for k in ("arma sagrada", "espada justiceira", "espada solar")):
        return 98.0 if not eh_conj else 45.0  # +1 passo de dano / +1d6 luz!
    if "kiai divino" in nl or "tradição de lin-wu" in nl:
        return 91.0 if not eh_conj else 30.0  # Maximiza dados de dano / +1 margem katana!
    if "fé guerreira" in nl or "fúria divina" in nl or "ataque piedoso" in nl:
        return 85.0 if not eh_conj else 25.0
    if "presas primordiais" in nl or "arsenal das profundezas" in nl or "tropas de ragnar" in nl:
        return 82.0 if not eh_conj else 35.0

    # Poderes Concedidos Defensivos / Tanque
    if "escamas dracônicas" in nl:
        return 94.0 if eh_tanque else 75.0    # +2 Defesa e +2 Fortitude!
    if "coragem total" in nl or "dom da imortalidade" in nl or "manto da penumbra" in nl:
        return 88.0 if eh_tanque else 70.0
    if "dom da esperança" in nl or "reparar injustiça" in nl:
        return 86.0 if (eh_tanque or eh_suporte) else 60.0

    # Poderes Concedidos para Conjuradores & Suporte
    if "bênção do mana" in nl:
        return 96.0 if (eh_conj or eh_suporte) else 55.0  # +1 PM a cada 2 níveis!
    if "teurgista místico" in nl or "centelha mágica" in nl or "escudo mágico" in nl or "magia oculta" in nl:
        return 90.0 if eh_conj else 35.0
    if "cura gentil" in nl or "dom da ressurreição" in nl or "dom da profecia" in nl:
        return 93.0 if eh_suporte else 50.0
    if "dedo verde" in nl or "descanso natural" in nl or "compreender os ermos" in nl:
        return 89.0 if eh_suporte else 55.0
    if "mente analítica" in nl or "conhecimento enciclopédico" in nl or "visão nas trevas" in nl:
        return 80.0
    return 65.0

# 4. PADRÃO DECORATOR & OCP: CALCULADORA DE ESTATÍSTICAS T20
# ==============================================================================

class ModificadorRacialDecorator(IModificadorFicha):
    def aplicar(self, ficha: FichaPersonagem) -> None:
        if not ficha.raca:
            return
        nome_raca = ficha.raca.nome.lower()
        hab = ficha.raca.habilidades_raca.lower()
        mem_ost = (ficha.raca_anterior_osteon or "").lower() if nome_raca == "osteon" else ""

        if "duro como pedra" in hab or nome_raca == "anão" or (nome_raca == "osteon" and "anão" in mem_ost):
            ganho_pv = 3 + (ficha.nivel - 1)
            ficha.pv_maximos += ganho_pv
            lbl_pv = "Osteon [Memória Póstuma Anão]: Duro como Pedra" if nome_raca == "osteon" else "Anão: Duro como Pedra"
            ficha.detalhe_pv += f" + {ganho_pv} ({lbl_pv})"
        if "sangue mágico" in hab or nome_raca == "elfo" or (nome_raca == "osteon" and "elfo" in mem_ost):
            ganho_pm = ficha.nivel
            ficha.pm_maximos += ganho_pm
            lbl_pm = "Osteon [Memória Póstuma Elfo]: Sangue Mágico" if nome_raca == "osteon" else "Elfo: Sangue Mágico"
            ficha.detalhe_pm += f" + {ganho_pm} ({lbl_pm})"
        # Bônus exatos de Defesa racial conforme o Livro Básico Edição Jogo do Ano (pp. 22, 25 e 31):
        # - Golem (Chassi, p. 22): +2 na Defesa, penalidade de armadura -2 e deslocamento fixo 6m
        # - Minotauro (Couro Rígido, p. 25) e Trog (Casca Grossa, p. 31): +1 na Defesa
        if "chassi" in hab or nome_raca == "golem":
            ficha.defesa_total += 2
            ficha.deslocamento_final = 6
            ficha.penalidade_armadura_total -= 2
            for k_pen in ("Acrobacia", "Furtividade", "Ladinagem"):
                if k_pen in ficha.bonus_pericias:
                    ficha.bonus_pericias[k_pen] -= 2
        elif any(k in hab for k in ("couro rígido", "casca grossa", "armadura natural")) or nome_raca in ("minotauro", "trog") or (nome_raca == "osteon" and "minotauro" in mem_ost):
            ficha.defesa_total += 1

        # Bônus raciais de perícias do Capítulo 1 (Livro Básico JdA, pp. 18–31):
        if nome_raca == "elfo":
            for k_el in ("Misticismo", "Percepção"):
                if k_el in ficha.bonus_pericias:
                    ficha.bonus_pericias[k_el] += 2
        elif nome_raca == "goblin":
            if "Fortitude" in ficha.bonus_pericias:
                ficha.bonus_pericias["Fortitude"] += 2
        elif nome_raca == "hynne":
            if "Enganação" in ficha.bonus_pericias:
                ficha.bonus_pericias["Enganação"] += 2
            if "Atletismo" in ficha.bonus_pericias and ficha.atributos_finais.DES > ficha.atributos_finais.FOR:
                ficha.bonus_pericias["Atletismo"] += (ficha.atributos_finais.DES - ficha.atributos_finais.FOR)
        elif nome_raca == "kliren":
            if "Ofício" in ficha.bonus_pericias:
                ficha.bonus_pericias["Ofício"] += 2
        elif "aggelus" in nome_raca:
            for k_ag in ("Diplomacia", "Intuição"):
                if k_ag in ficha.bonus_pericias:
                    ficha.bonus_pericias[k_ag] += 2
        elif "sulfure" in nome_raca:
            for k_su in ("Enganação", "Furtividade"):
                if k_su in ficha.bonus_pericias:
                    ficha.bonus_pericias[k_su] += 2
        elif nome_raca == "lefou":
            for k_lf in ("Luta", "Fortitude"):
                if k_lf in ficha.bonus_pericias:
                    ficha.bonus_pericias[k_lf] += 2


class ModificadorPoderesPassivosDecorator(IModificadorFicha):
    def aplicar(self, ficha: FichaPersonagem) -> None:
        for poder in ficha.todos_os_poderes():
            nome = poder.nome.strip().lower()
            if nome == "vitalidade":
                ficha.pv_maximos += ficha.nivel
                ficha.detalhe_pv += f" + {ficha.nivel} (Vitalidade)"
                if "Fortitude" in ficha.bonus_pericias:
                    ficha.bonus_pericias["Fortitude"] += 2
            elif nome == "vontade de ferro":
                ganho = ficha.nivel // 2
                if ganho > 0:
                    ficha.pm_maximos += ganho
                    ficha.detalhe_pm += f" + {ganho} (Vontade de Ferro)"
                if "Vontade" in ficha.bonus_pericias:
                    ficha.bonus_pericias["Vontade"] += 2
            elif nome == "bênção do mana":
                ganho = ficha.nivel // 2
                if ganho > 0:
                    ficha.pm_maximos += ganho
                    ficha.detalhe_pm += f" + {ganho} (Bênção do Mana)"
            elif nome == "poder mágico":
                ficha.pm_maximos += ficha.nivel
                ficha.detalhe_pm += f" + {ficha.nivel} (Poder Mágico)"
            elif nome == "esquiva":
                ficha.defesa_total += 2
                if "Reflexos" in ficha.bonus_pericias:
                    ficha.bonus_pericias["Reflexos"] += 2
            elif nome == "encouraçado" and ficha.armadura_equipada:
                if "pesada" in ficha.armadura_equipada.subcategoria.lower():
                    ficha.defesa_total += 2
            elif nome == "inexpugnável" and ficha.armadura_equipada:
                if "pesada" in ficha.armadura_equipada.subcategoria.lower():
                    for k in ("Fortitude", "Reflexos", "Vontade"):
                        if k in ficha.bonus_pericias:
                            ficha.bonus_pericias[k] += 2
            elif nome == "estilo de arma e escudo" and ficha.escudo_equipado:
                ficha.defesa_total += 2
            elif nome == "solidez" and ficha.escudo_equipado:
                bonus_esc = 2 if "pesado" in ficha.escudo_equipado.nome.lower() else 1
                if ficha.possui_poder("Estilo de Arma e Escudo"):
                    bonus_esc += 2
                for k_res in ("Fortitude", "Reflexos", "Vontade"):
                    if k_res in ficha.bonus_pericias:
                        ficha.bonus_pericias[k_res] += bonus_esc
            elif nome == "estilo de uma arma" and ficha.arma_equipada and not ficha.escudo_equipado:
                if "duas mãos" not in ficha.arma_equipada.subcategoria.lower():
                    ficha.defesa_total += 2
            elif nome == "en garde" and ficha.arma_equipada and not ficha.escudo_equipado:
                ficha.defesa_total += 2
            elif nome == "mente analítica":
                for k_int in ("Intuição", "Investigação", "Vontade"):
                    if k_int in ficha.bonus_pericias:
                        ficha.bonus_pericias[k_int] += 2
            elif nome == "costas largas":
                ficha.carga_maxima += 5.0
            elif nome == "inventário organizado":
                ficha.carga_maxima += max(0, ficha.atributos_finais.INT)
            elif nome == "atlético":
                ficha.deslocamento_final += 3
                if "Atletismo" in ficha.bonus_pericias:
                    ficha.bonus_pericias["Atletismo"] += 2
            elif nome == "escamas dracônicas":
                ficha.defesa_total += 2
                if "Fortitude" in ficha.bonus_pericias:
                    ficha.bonus_pericias["Fortitude"] += 2
            elif nome == "mente vazia":
                for k_mv in ("Iniciativa", "Percepção", "Vontade"):
                    if k_mv in ficha.bonus_pericias:
                        ficha.bonus_pericias[k_mv] += 2
            elif nome == "coragem total":
                if "Vontade" in ficha.bonus_pericias:
                    ficha.bonus_pericias["Vontade"] += 2
            elif nome == "escudo mágico" and ficha.eh_conjurador():
                ficha.defesa_total += 2
            elif nome == "sentidos aguçados":
                if "Percepção" in ficha.bonus_pericias:
                    ficha.bonus_pericias["Percepção"] += 2
            elif nome == "fortalecimento arcano":
                ficha.cd_magias += (2 if ficha.circulo_maximo_permitido() >= 4 else 1)
            elif nome == "carapaça":
                qtd_tor = sum(1 for p in ficha.todos_os_poderes() if p.categoria_ou_classe.lower() == "tormenta")
                ficha.defesa_total += 1 + max(0, (qtd_tor - 1) // 2)

        # Habilidades de classe/poderes na Defesa (respeitando bloqueio em Armadura Pesada — JdA pp. 46, 68, 69, 76, 79, 152)
        if ficha.classe:
            nc_def = ficha.classe.nome.lower()
            usa_pesada = bool(ficha.armadura_equipada and "pesada" in ficha.armadura_equipada.subcategoria.lower())
            usa_leve = bool(ficha.armadura_equipada and not usa_pesada)
            usou_car_def = False
            if not usa_pesada:
                # Autoconfiança (Nobre, p. 79): substitui DES por CAR
                if nc_def == "nobre" and ficha.atributos_finais.CAR > ficha.atributos_finais.DES:
                    ficha.defesa_total += (ficha.atributos_finais.CAR - ficha.atributos_finais.DES)
                    usou_car_def = True
                # Couraceiro (Inventor, p. 69): substitui DES por INT com armadura leve
                if ficha.possui_poder("Couraceiro") and usa_leve and ficha.atributos_finais.INT > ficha.atributos_finais.DES:
                    ficha.defesa_total += (ficha.atributos_finais.INT - ficha.atributos_finais.DES)
                # Insolência (Bucaneiro, p. 46): +CAR limitado ao nível, sem armadura pesada
                if nc_def == "bucaneiro" and not usou_car_def:
                    insolencia = min(ficha.nivel, max(0, ficha.atributos_finais.CAR))
                    ficha.defesa_total += insolencia
                # Casca Grossa (Lutador, p. 76, nv. 2+): +CON (+1 a cada 4 nv. a partir do 5º), sem armadura pesada
                if nc_def == "lutador" and ficha.nivel >= 2:
                    esc_casca = (1 + (ficha.nivel - 5) // 4) if ficha.nivel >= 5 else 0
                    ficha.defesa_total += max(0, ficha.atributos_finais.CON) + esc_casca
                if ficha.possui_poder("Braços Calejados"):
                    ficha.defesa_total += max(0, ficha.atributos_finais.FOR)
            elif ficha.possui_poder("Blindagem"):
                # Blindagem (Inventor, p. 68): soma INT na Defesa mesmo com armadura pesada
                ficha.defesa_total += max(0, ficha.atributos_finais.INT)
            if False:
                pass
            elif nc_def == "cavaleiro":
                baluarte = 2 * (1 + (ficha.nivel - 1) // 4)
                ficha.defesa_total += baluarte
                for k_r in ("Fortitude", "Reflexos", "Vontade"):
                    if k_r in ficha.bonus_pericias:
                        ficha.bonus_pericias[k_r] += baluarte
            elif nc_def == "paladino" and ficha.nivel >= 3:
                aura_car = max(0, ficha.atributos_finais.CAR)
                for k_r in ("Fortitude", "Reflexos", "Vontade"):
                    if k_r in ficha.bonus_pericias:
                        ficha.bonus_pericias[k_r] += aura_car
                if ficha.escudo_equipado:
                    ficha.defesa_total += aura_car

        # Verifica itens de PM (ex: Chapéu arcano para Arcanistas)
        if ficha.classe and "arcanista" in ficha.classe.nome.lower():
            for it in ficha.itens_inventario:
                if it.nome.strip().lower() == "chapéu arcano":
                    ficha.pm_maximos += 1
                    ficha.detalhe_pm += " + 1 (Chapéu Arcano)"
                    break


class CalculadoraEstatisticaT20:
    def __init__(self, catalogo_pericias: Sequence[Pericia],
                 modificadores_extras: Optional[List[IModificadorFicha]] = None,
                 catalogo_poderes_gerais: Optional[Sequence[Poder]] = None) -> None:
        self.catalogo_pericias = list(catalogo_pericias)
        self.catalogo_poderes_gerais = list(catalogo_poderes_gerais or [])
        self.modificadores: List[IModificadorFicha] = modificadores_extras or [
            ModificadorRacialDecorator(),
            ModificadorPoderesPassivosDecorator(),
        ]

    def _sincronizar_beneficios_origem_golem_osteon(self, ficha: FichaPersonagem) -> None:
        """
        Implementa estritamente as regras de Origem, Golem e Osteon de Tormenta20 (p. 22, 27 e 88):
        1) Raça Golem (p. 22 — 'Sem Origem' & 'Propósito de Criação'):
           - Golem NÃO tem Origem (`ficha.origem = None`), mas recebe +1 Poder Geral gratuito via Propósito de Criação.
        2) Raça Osteon (p. 27 — 'Memória Póstuma'):
           - Osteon NÃO recebe benefícios de uma Origem (`ficha.origem = None`).
           - Seus +1 em 3 atributos livres NUNCA podem ser aplicados em CON ('exceto CON').
           - Via Memória Póstuma, recebe uma habilidade de sua raça humanoide anterior (ex.: Anão 'Duro como Pedra',
             Elfo 'Sangue Mágico') ou +1 Poder Geral + 1 Perícia caso sua raça anterior seja Humano.
        3) Demais Raças (p. 88 — 'Benefícios de Origem'):
           - Recebem 2 benefícios da Origem selecionada: +1 Perícia Treinada da lista da origem e +1 Poder da Origem
             (o Poder Único da origem ou o Poder Geral de maior sinergia listado na origem).
        """
        nome_raca = ficha.raca.nome.strip().lower() if ficha.raca else "humano"
        ficha.poderes_beneficio_origem = []
        ficha.pericia_beneficio_origem = ""

        # Regra de Atributos Livres do Osteon: nunca permite CON nos 3 atributos livres!
        if nome_raca == "osteon":
            novos_livres: List[str] = []
            for s in ficha.escolhas_atributos_livres:
                sig = s.strip().upper()
                if sig == "CON":
                    substituto = next((a for a in ("DES", "INT", "SAB", "CAR", "FOR") if a not in novos_livres and a not in ficha.escolhas_atributos_livres), "DES")
                    novos_livres.append(substituto)
                else:
                    novos_livres.append(sig)
            ficha.escolhas_atributos_livres = novos_livres[:3]

        arq_orig = (ficha.relatorio_ia.arquetipo_alvo or "Dano Marcial").lower()
        eh_conj_o = ficha.eh_conjurador()
        eh_tanque_o = any(k in arq_orig for k in ("tanque", "escudo", "defesa"))
        eh_arq_o = any(k in arq_orig for k in ("arqueiro", "disparo", "distância"))
        eh_haste_o = any(k in arq_orig for k in ("haste", "alongada"))
        eh_duas_armas_o = "duas armas" in arq_orig
        eh_uma_mao_o = any(k in arq_orig for k in ("uma mão", "duelista"))

        if eh_conj_o:
            ordem_pref_combate = ("vontade de ferro", "vitalidade", "esquiva", "reflexos de combate", "sortudo", "surto heroico")
        elif eh_tanque_o:
            ordem_pref_combate = ("estilo de arma e escudo", "encouraçado", "vitalidade", "esquiva", "bloqueio com escudo", "combate defensivo")
        elif eh_arq_o:
            ordem_pref_combate = ("estilo de disparo", "disparo preciso", "foco em arma", "reflexos de combate", "saque rápido", "vitalidade")
        elif eh_haste_o:
            ordem_pref_combate = ("estilo de arma longa", "piqueiro", "estilo de duas mãos", "ataque poderoso", "foco em arma", "vitalidade")
        elif eh_duas_armas_o:
            ordem_pref_combate = ("estilo de duas armas", "acuidade com arma", "foco em arma", "reflexos de combate", "vitalidade", "esquiva")
        elif eh_uma_mao_o:
            ordem_pref_combate = ("estilo de uma arma", "ataque preciso", "acuidade com arma", "foco em arma", "esquiva", "vitalidade")
        else:
            ordem_pref_combate = ("estilo de duas mãos", "ataque poderoso", "foco em arma", "vitalidade", "reflexos de combate", "esquiva")

        # CASO 1: Raça GOLEM — Sem Origem + Propósito de Criação (+1 Poder Geral Otimizado por Arquétipo!)
        if nome_raca == "golem":
            ficha.origem = None
            nomes_atuais_p = {p.nome.lower() for p in ficha.poderes_classe + ficha.poderes_gerais}
            cand_golem = next(
                (p for nm_pref in ordem_pref_combate
                 for p in self.catalogo_poderes_gerais
                 if p.nome.lower() == nm_pref and p.nome.lower() not in nomes_atuais_p),
                None
            )
            if cand_golem:
                ficha.poderes_beneficio_origem = [cand_golem]
            ficha.resumo_regra_origem = (
                f"Sem Origem (Regra de Golem, p. 22) ➔ Propósito de Criação concedeu o Poder Geral Otimizado: "
                f"'{cand_golem.nome if cand_golem else 'Vitalidade'}' ({cand_golem.efeito_resumo if cand_golem else ''})"
            )
            return

        # CASO 2: Raça OSTEON — Sem Origem + Memória Póstuma (Raça Anterior ou Poder Geral Otimizado)
        if nome_raca == "osteon":
            ficha.origem = None
            mem = (ficha.raca_anterior_osteon or "Minotauro (Chifres & Couro Rígido)").strip()
            if "humano" in mem.lower():
                nomes_atuais_p = {p.nome.lower() for p in ficha.poderes_classe + ficha.poderes_gerais}
                cand_ost = next(
                    (p for nm_pref in ordem_pref_combate
                     for p in self.catalogo_poderes_gerais
                     if p.nome.lower() == nm_pref and p.nome.lower() not in nomes_atuais_p),
                    None
                )
                if cand_ost:
                    ficha.poderes_beneficio_origem = [cand_ost]
                ficha.resumo_regra_origem = (
                    f"Sem Origem (Regra de Osteon, p. 27) ➔ Memória Póstuma (Humano) concedeu Poder Geral Otimizado: "
                    f"'{cand_ost.nome if cand_ost else 'Vontade de Ferro'}'"
                )
            else:
                ficha.resumo_regra_origem = (
                    f"Sem Origem (Regra de Osteon, p. 27) ➔ Memória Póstuma ({mem}): "
                    f"herda habilidade racial da raça anterior e Armadura Óssea (RD 5 corte/frio/perfuração)"
                )
            return

        # CASO 3: Raças Normais com Origem (2 Benefícios Otimizados: [1] Perícia Não-Repetida + [2] Poder de Maior Sinergia)
        if not ficha.origem:
            ficha.resumo_regra_origem = "Nenhuma Origem selecionada."
            return

        orig = ficha.origem
        prioridade_pericias_orig = ("Percepção", "Iniciativa", "Fortitude", "Vontade", "Reflexos", "Atletismo", "Acrobacia", "Guerra", "Misticismo", "Religião", "Cura", "Intimidação", "Furtividade", "Pontaria", "Luta", "Atuação", "Diplomacia", "Enganação")
        pericias_orig = [p.strip().split("(")[0].strip() for p in re.split(r"/|,", orig.pericias_disponiveis) if p.strip() and "escolhida" not in p.lower()]
        pericias_orig.sort(key=lambda x: prioridade_pericias_orig.index(x) if x in prioridade_pericias_orig else 99)
        for p_or in pericias_orig:
            if p_or and not ficha.possui_pericia_treinada(p_or):
                ficha.pericias_treinadas.append(p_or)
                ficha.pericia_beneficio_origem = p_or
                break
        if not ficha.pericia_beneficio_origem:
            # Se todas as perícias da origem já vieram da classe, libera um slot da classe para Percepção/Iniciativa/Vontade!
            for p_fallback in ("Percepção", "Iniciativa", "Vontade", "Reflexos", "Atletismo"):
                if not ficha.possui_pericia_treinada(p_fallback):
                    ficha.pericias_treinadas.append(p_fallback)
                    break
            ficha.pericia_beneficio_origem = pericias_orig[0] if pericias_orig else "Percepção"

        # Escolhe o Poder de Origem de maior sinergia com o arquétipo e estilo da ficha!
        nomes_atuais_p = {p.nome.lower() for p in ficha.poderes_classe + ficha.poderes_gerais}
        nomes_pod_orig = [p.strip() for p in re.split(r"/|,", orig.poderes_disponiveis) if p.strip()]
        melhor_pod_orig: Optional[Poder] = None
        for nm_po in sorted(nomes_pod_orig, key=lambda x: 0 if "poder de combate" in x.lower() else (1 if x.lower() in ordem_pref_combate else 2)):
            if "poder de combate" in nm_po.lower():
                achou_comb = next(
                    (p for nm_c in ordem_pref_combate
                     for p in self.catalogo_poderes_gerais
                     if p.nome.lower() == nm_c and p.nome.lower() not in nomes_atuais_p),
                    None
                )
                if achou_comb:
                    melhor_pod_orig = achou_comb
                    break
            achou_po = next(
                (p for p in self.catalogo_poderes_gerais if p.nome.strip().lower() == nm_po.lower()),
                None
            )
            if achou_po and achou_po.nome.lower() not in nomes_atuais_p:
                melhor_pod_orig = achou_po
                break

        if not melhor_pod_orig:
            melhor_pod_orig = Poder(
                id_poder=f"ORIG_{orig.id_origem}",
                categoria_ou_classe=f"Origem ({orig.nome})",
                nome=orig.poder_unico,
                pre_requisitos=f"Origem {orig.nome}",
                custo_pm="Passivo/Variável",
                acao="Livre/Passivo",
                efeito_resumo=orig.efeito_poder_unico,
                eh_poder_classe=False,
            )

        ficha.poderes_beneficio_origem = [melhor_pod_orig]
        ficha.resumo_regra_origem = (
            f"Origem '{orig.nome}' (p. 88 — 2 Benefícios): "
            f"[1] Perícia '{ficha.pericia_beneficio_origem}' + [2] Poder de Origem '{melhor_pod_orig.nome}' ({melhor_pod_orig.efeito_resumo})"
        )

    def _sincronizar_poderes_concedidos_devocao(self, ficha: FichaPersonagem) -> None:
        """
        Garante que todo personagem devoto receba automaticamente 1 Poder Concedido
        (ou 2 Poderes Concedidos se tiver a habilidade Devoto Fiel: Clérigo, Druida ou Paladino)
        da lista oficial de `ficha.deus.poderes_concedidos`.
        """
        if not ficha.deus:
            ficha.poderes_concedidos_devocao = []
            return
        qtd_alvo, _ = ficha.quantidade_poderes_concedidos_devocao()
        nomes_concedidos_deus = [
            p.strip() for p in re.split(r"/|,|\s+e\s+", ficha.deus.poderes_concedidos) if p.strip()
        ]
        concedidos_encontrados: List[Poder] = []
        for nome_c in nomes_concedidos_deus:
            achou = next(
                (p for p in self.catalogo_poderes_gerais
                 if p.nome.strip().lower() == nome_c.lower() or nome_c.lower() in p.nome.strip().lower()),
                None
            )
            if not achou:
                achou = Poder(
                    id_poder=f"CONC_{nome_c[:6].upper()}",
                    categoria_ou_classe="Concedido",
                    nome=nome_c,
                    pre_requisitos=f"Devoto de {ficha.deus.nome}",
                    custo_pm="Passivo/Ativo",
                    acao="Livre/Padrão",
                    efeito_resumo=f"Poder Concedido por {ficha.deus.nome} ({ficha.deus.titulo}).",
                    eh_poder_classe=False,
                )
            if achou and all(x.nome.lower() != achou.nome.lower() for x in concedidos_encontrados):
                concedidos_encontrados.append(achou)
        # Ordena todos os poderes concedidos disponíveis da divindade pela maior sinergia com a ficha!
        concedidos_encontrados.sort(key=lambda p: pontuar_sinergia_poder_concedido(p.nome, ficha), reverse=True)
        ficha.poderes_concedidos_devocao = concedidos_encontrados[:qtd_alvo]

    @staticmethod
    def _extrair_int(texto: str) -> int:
        m = re.search(r"-?\d+", str(texto))
        return int(m.group(0)) if m else 0

    def recalcular(self, ficha: FichaPersonagem) -> None:
        # 1. Calcula Atributos Finais PRIMEIRO (incluindo Raça, Livres, Aumento de Atributo e Tormenta)
        finais = ficha.atributos_base.copiar()
        if ficha.raca:
            finais.FOR += ficha.raca.mod_for
            finais.DES += ficha.raca.mod_des
            finais.CON += ficha.raca.mod_con
            finais.INT += ficha.raca.mod_int
            finais.SAB += ficha.raca.mod_sab
            finais.CAR += ficha.raca.mod_car
            if "atributos" in ficha.raca.mod_livre.lower() or "qualquer" in ficha.raca.mod_livre.lower():
                qtd_livres = 3 if "3" in ficha.raca.mod_livre else (2 if "2" in ficha.raca.mod_livre else 1)
                vistos_livres: List[str] = []
                for atr_l in ficha.escolhas_atributos_livres:
                    sig = atr_l.strip().upper()
                    if sig in ATRIBUTOS_NOMES and sig not in vistos_livres and len(vistos_livres) < qtd_livres:
                        vistos_livres.append(sig)
                        finais.somar(sig, 1)

        # 0. Sincroniza Benefícios de Origem / Golem (Sem Origem) / Osteon (Memória Póstuma) e Poderes Concedidos
        self._sincronizar_beneficios_origem_golem_osteon(ficha)
        self._sincronizar_poderes_concedidos_devocao(ficha)

        # Aplica Aumento de Atributo antes de calcular PV, PM, Perícias e CD!
        if ficha.classe:
            if "arcanista" in ficha.classe.nome.lower():
                atrib_p, _ = ficha.obter_atributo_chave_magia()
            else:
                atrib_p = ficha.classe.atributo_principal.split()[0].upper()
            for poder in ficha.todos_os_poderes():
                if poder.nome.strip().lower() == "aumento de atributo":
                    finais.somar(atrib_p, 1)

        qtd_tormenta = sum(1 for p in ficha.todos_os_poderes() if p.categoria_ou_classe.lower() == "tormenta")
        if qtd_tormenta > 0:
            efetivos = max(0, qtd_tormenta - 1) if ficha.possui_poder("Afinidade com a Tormenta") else qtd_tormenta
            if efetivos > 0:
                finais.CAR -= (1 + (efetivos - 1) // 2)

        ficha.atributos_finais = finais

        # 2. Cálculo Exato de PV e PM por Classe (Tormenta20 Jogo do Ano v1.3)
        usa_sab_pv = ficha.possui_poder("Dom da Esperança")
        mod_pv = finais.SAB if usa_sab_pv else finais.CON
        sigla_pv = "SAB" if usa_sab_pv else "CON"

        pares_classes = ficha.obter_classes_e_niveis()
        if pares_classes:
            cl_prim, nv_prim = pares_classes[0]
            pv_1 = max(1, cl_prim.pv_inicial + mod_pv)
            pv_por_nv_prim = max(1, cl_prim.pv_por_nivel + mod_pv)
            pv_sub_prim = (nv_prim - 1) * pv_por_nv_prim
            pv_total = pv_1 + pv_sub_prim
            partes_det_pv = []
            if nv_prim == 1:
                partes_det_pv.append(f"{pv_1} (1º nv {cl_prim.nome}: {cl_prim.pv_inicial}+{mod_pv} {sigla_pv})")
            else:
                partes_det_pv.append(
                    f"{pv_1} (1º nv {cl_prim.nome}: {cl_prim.pv_inicial}+{mod_pv} {sigla_pv}) + "
                    f"{pv_sub_prim} ({nv_prim - 1} nv {cl_prim.nome} × [{cl_prim.pv_por_nivel}+{mod_pv} {sigla_pv}])"
                )
            # Regra Oficial de Multiclasse (Cap. 1, p. 34): níveis em classes secundárias concedem APENAS o PV por nível (nunca o PV inicial da 2ª classe!)
            for cl_sec, nv_sec in pares_classes[1:]:
                pv_por_nv_sec = max(1, cl_sec.pv_por_nivel + mod_pv)
                ganho_sec = nv_sec * pv_por_nv_sec
                pv_total += ganho_sec
                partes_det_pv.append(
                    f"{ganho_sec} (Multiclasse {cl_sec.nome} {nv_sec} nv × [{cl_sec.pv_por_nivel}+{mod_pv} {sigla_pv}] — p. 34)"
                )
            ficha.pv_maximos = pv_total
            ficha.detalhe_pv = " + ".join(partes_det_pv)

            # PM em Multiclasse (p. 34): soma os PM por nível de cada classe + atributo-chave de classes conjuradoras/Abençoado
            pm_total = 0
            partes_det_pm = []
            atrib_pm_ja_somados = set()
            for cl_item, nv_item in pares_classes:
                pm_c = cl_item.pm_por_nivel * nv_item
                pm_total += pm_c
                partes_det_pm.append(f"{pm_c} ({cl_item.nome} {nv_item} nv × {cl_item.pm_por_nivel} PM)")
                nc_low = cl_item.nome.lower()
                if any(k in nc_low for k in ("arcanista", "bardo", "clérigo", "clerigo", "druida")):
                    if "arcanista" in nc_low:
                        cam = (ficha.caminho_arcanista or "Mago").lower()
                        sig_m = "CAR" if "feiticeiro" in cam else "INT"
                    elif "bardo" in nc_low:
                        sig_m = "CAR"
                    else:
                        sig_m = "SAB"
                    if sig_m not in atrib_pm_ja_somados:
                        atrib_pm_ja_somados.add(sig_m)
                        b_atr = max(0, finais.obter(sig_m))
                        if b_atr > 0:
                            pm_total += b_atr
                            partes_det_pm.append(f"{b_atr} (Atrib. Magias {sig_m} de {cl_item.nome})")
                elif "paladino" in nc_low and "CAR_ABENCOADO" not in atrib_pm_ja_somados:
                    atrib_pm_ja_somados.add("CAR_ABENCOADO")
                    b_car = max(0, finais.CAR)
                    if b_car > 0:
                        pm_total += b_car
                        partes_det_pm.append(f"{b_car} (Abençoado Paladino: +CAR)")
            ficha.pm_maximos = pm_total
            ficha.detalhe_pm = " + ".join(partes_det_pm)
        else:
            ficha.pv_maximos = max(1, 10 + mod_pv)
            ficha.pm_maximos = 0
            ficha.detalhe_pv = f"10 + {mod_pv} ({sigla_pv})"
            ficha.detalhe_pm = "0"

        # 3. Defesa, Penalidade de Armadura e Deslocamento
        ficha.deslocamento_final = ficha.raca.deslocamento_m if ficha.raca else 9
        bonus_armadura = 0
        penalidade_arm = 0
        limita_des = False

        if ficha.armadura_equipada:
            bonus_armadura += self._extrair_int(ficha.armadura_equipada.dano_ou_defesa)
            penalidade_arm += abs(self._extrair_int(ficha.armadura_equipada.critico_ou_penalidade))
            if "pesada" in ficha.armadura_equipada.subcategoria.lower():
                limita_des = True
                if not (ficha.raca and ficha.raca.nome.lower() == "anão") and not ficha.possui_poder("Fanático"):
                    ficha.deslocamento_final = max(3, ficha.deslocamento_final - 3)

        if ficha.escudo_equipado:
            bonus_armadura += self._extrair_int(ficha.escudo_equipado.dano_ou_defesa)
            penalidade_arm += abs(self._extrair_int(ficha.escudo_equipado.critico_ou_penalidade))

        des_defesa = 0 if limita_des else finais.DES
        ficha.defesa_total = 10 + des_defesa + bonus_armadura
        ficha.penalidade_armadura_total = -penalidade_arm

        # 4. Carga e Perícias
        ficha.carga_maxima = 10.0 + (2.0 * finais.FOR if finais.FOR >= 0 else float(finais.FOR))
        ficha.carga_atual = round(sum(i.espacos for i in ficha.itens_inventario), 2)

        metade_nivel = ficha.nivel // 2
        bonus_treino = 2 if ficha.nivel <= 6 else (4 if ficha.nivel <= 14 else 6)
        pericias_calc: Dict[str, int] = {}
        for per in self.catalogo_pericias:
            treinada = ficha.possui_pericia_treinada(per.nome)
            mod_atrib = finais.obter(per.atributo_chave)
            total = metade_nivel + mod_atrib + (bonus_treino if treinada else 0)
            if per.penalidade_armadura:
                total += ficha.penalidade_armadura_total
            pericias_calc[per.nome] = total
        ficha.bonus_pericias = pericias_calc

        sigla_magia_cd, _ = ficha.obter_atributo_chave_magia()
        atrib_magia = finais.obter(sigla_magia_cd)
        ficha.cd_magias = 10 + metade_nivel + atrib_magia

        # 5. Aplica Decorators (Raça, Poderes Passivos e Itens Mágicos/Vestuário)
        for mod in self.modificadores:
            mod.aplicar(ficha)

        ficha.detalhe_pv += f" = {ficha.pv_maximos} PV"
        ficha.detalhe_pm += f" = {ficha.pm_maximos} PM"



def resolver_acumulo_fontes_t20(bonus_lista):
    """Regra oficial de acúmulo de bônus por fonte (Tormenta20 JdA, Cap. 5, p. 226).
    Bônus de mesma fonte (ITEM, MAGIA, PARCEIRO, AMBIENTE) não acumulam — prevalece o maior.
    Bônus de HABILIDADE acumulam entre si, exceto vindos da mesma habilidade.
    """
    por_fonte = {"ITEM": 0.0, "MAGIA": 0.0, "PARCEIRO": 0.0, "AMBIENTE": 0.0}
    habs_vistas = {}
    for b in (bonus_lista or []):
        if not isinstance(b, dict):
            continue
        val = float(b.get("valor", 0) or 0)
        fonte = str(b.get("fonte", "ITEM")).upper()
        if fonte == "HABILIDADE":
            chave = str(b.get("nome", "")).strip().lower()
            if chave not in habs_vistas or val > habs_vistas[chave]:
                habs_vistas[chave] = val
        elif fonte in por_fonte:
            if val > por_fonte[fonte]:
                por_fonte[fonte] = val
    total_hab = sum(habs_vistas.values())
    total = total_hab + sum(por_fonte.values())
    return {"total": total, "por_fonte": {"HABILIDADE": total_hab, **por_fonte}}
