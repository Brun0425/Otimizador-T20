# -*- coding: utf-8 -*-
from __future__ import annotations

import abc
import base64
import copy
import dataclasses
import datetime
from datetime import datetime as dt_cls
import gzip
import hashlib
import zlib
import functools
import html
import http.server
import inspect
import io
import json
import lzma
import math
import os
import pathlib
from pathlib import Path
import random
import re
import socketserver
import sqlite3
import statistics
import string
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import typing
import urllib.parse
import urllib.request
import uuid
import webbrowser
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import (
    Any, Callable, Dict, Generic, Iterable, Iterator, List,
    Literal, Mapping, NamedTuple, Optional, Protocol, Sequence,
    Set, Tuple, Type, TypeVar, Union
)

"""
Camada de Aplicação — Analisador de Sinergia Multicritério, Dano Médio (Máx+Mín)/2, Crítico, DPR e Magias em Área (AoE).
"""
from ..domain import *
from .calculators_decorators import *
from .csp_specifications import EspecificacaoAtributoMinimo, EspecificacaoNivelMinimo, EspecificacaoPericiaTreinada, EspecificacaoPoderPossuido, EspecificacaoDevotoDeus, EspecificacaoCompostaAND, EspecificacaoCompostaOR, EspecificacaoFuncaoCustomizada, NOMES_PERICIAS_RADICAIS, InterpretadorPreRequisitosCSP, GRUPOS_ESTILO_EXCLUSIVOS, PODERES_EXCLUSIVOS_CORPO_A_CORPO

class AnalisadorSinergiaEDanoT20:
    """
    [SOLID SRP] Analisa:
    1) Conflitos de estilo de combate (ex: Arqueiro + Destruidor, ou Ambidestria com arma de 2 mãos);
    2) Limite de PM por magia (Nível + Magia Ilimitada + Esotérico);
    3) Detalhamento dos aprimoramentos ótimos de cada magia para dano/cura máxima;
    4) Cálculo de DPR (Dano Médio por Rodada) de Combatentes e Conjuradores (Raio Arcano + Magias).
    """

    @staticmethod
    def identificar_estilo_arma(ficha: FichaPersonagem) -> str:
        arq = (ficha.relatorio_ia.arquetipo_alvo or "").lower()
        if ficha.escudo_equipado or "escudo" in arq:
            return "ARMA_E_ESCUDO"
        if ficha.arma_equipada:
            prop_a = ficha.arma_equipada.efeito_propriedades.lower()
            sub_a = ficha.arma_equipada.subcategoria.lower()
            if "distância" in sub_a or "fogo" in sub_a:
                return "ARREMESSO" if "arremesso" in prop_a else "ARQUERIA_DISPARO"
            if "alongada" in prop_a or "haste" in arq:
                return "ARMA_LONGA_HASTE"
            if "duas mãos" in sub_a and "duas armas" not in arq:
                return "DUAS_MAOS"
        if "duas armas" in arq or ficha.possui_poder("Estilo de Duas Armas") or ficha.possui_poder("Ambidestria"):
            return "DUAS_ARMAS"
        if not ficha.arma_equipada:
            return "CONJURADOR_OU_DESARMADO"
        sub = ficha.arma_equipada.subcategoria.lower()
        prop = ficha.arma_equipada.efeito_propriedades.lower()
        if "distância" in sub or "fogo" in sub:
            if "arremesso" in prop:
                return "ARREMESSO"
            return "ARQUERIA_DISPARO"
        if "alongada" in prop or "haste" in arq:
            return "ARMA_LONGA_HASTE"
        if "duas mãos" in sub:
            return "DUAS_MAOS"
        if "uma mão" in arq or "duelista" in arq or "leve" in sub or "ágil" in prop:
            return "UMA_ARMA_ESGRIMA"
        return "UMA_ARMA_ESGRIMA"

    @classmethod
    def verificar_conflito_estilo_poder(cls, ficha: FichaPersonagem, candidato: Poder) -> Tuple[bool, str]:
        """
        Verifica se `candidato` entra em conflito com a arma equipada ou com outros
        poderes de estilo já presentes na ficha (Exclusão Mútua CSP).
        """
        nome_c = candidato.nome.strip().lower()
        possuidos = {p.nome.strip().lower() for p in ficha.todos_os_poderes()}

        # 1. Dependências diretas do Combo Raio Arcano
        if nome_c in ("raio elemental", "raio poderoso") and "raio arcano" not in possuidos:
            return False, "Requer o poder base 'Raio Arcano' para aprimorar seus dados/elementos"

        # 2. Ambidestria exige Estilo de Duas Armas (ou não usar arma de 2 mãos/escudo)
        if nome_c == "ambidestria" and "estilo de duas armas" not in possuidos:
            return False, "Requer 'Estilo de Duas Armas' para combater com duas armas sem penalidade"

        # 3. Identifica a qual grupo de estilo o candidato pertence
        grupo_cand: Optional[str] = None
        for nome_g, lista_p in GRUPOS_ESTILO_EXCLUSIVOS.items():
            if nome_c in lista_p:
                grupo_cand = nome_g
                break

        estilo_arma = cls.identificar_estilo_arma(ficha)

        if grupo_cand:
            # Armas de haste (Alabarda/Pique) são de duas mãos e alongadas, logo ARMA_LONGA_HASTE e DUAS_MAOS são compatíveis entre si!
            if nome_c.startswith("estilo de "):
                for p_pos in possuidos:
                    if p_pos.startswith("estilo de ") and p_pos != nome_c:
                        return False, f"Conflito de Postura: já possui {p_pos}, não acumula com {candidato.nome}"
            grupos_compativeis = {grupo_cand}

            for outro_g, lista_outros in GRUPOS_ESTILO_EXCLUSIVOS.items():
                if outro_g in grupos_compativeis:
                    continue
                conflitantes = possuidos.intersection(lista_outros)
                if conflitantes:
                    exemplo = next(iter(conflitantes)).title()
                    return (
                        False,
                        f"Conflito de Estilo CSP: '{candidato.nome}' ({grupo_cand}) não combina com '{exemplo}' ({outro_g})"
                    )

            # Verifica compatibilidade com a arma/escudo equipados
            if grupo_cand == "ARMA_LONGA_HASTE" and estilo_arma != "ARMA_LONGA_HASTE":
                return False, f"'{candidato.nome}' exige arma alongada/de haste como Alabarda, Pique ou Lança Montada (atual: {estilo_arma})"
            if grupo_cand == "DUAS_MAOS" and estilo_arma not in ("DUAS_MAOS", "ARMA_LONGA_HASTE", "CONJURADOR_OU_DESARMADO"):
                return False, f"'{candidato.nome}' exige arma corpo a corpo de duas mãos (atual: {estilo_arma})"
            if grupo_cand == "ARQUERIA_DISPARO" and estilo_arma != "ARQUERIA_DISPARO":
                return False, f"'{candidato.nome}' exige arma de ataque à distância/disparo (atual: {estilo_arma})"
            if grupo_cand == "ARREMESSO" and estilo_arma not in ("ARREMESSO", "UMA_ARMA_ESGRIMA"):
                return False, f"'{candidato.nome}' exige arma de arremesso"
            if grupo_cand == "DUAS_ARMAS" and estilo_arma in ("DUAS_MAOS", "ARMA_LONGA_HASTE", "ARMA_E_ESCUDO", "ARQUERIA_DISPARO"):
                return False, f"'{candidato.nome}' é incompatível com empunhadura {estilo_arma}"
            if grupo_cand == "ARMA_E_ESCUDO" and not ficha.escudo_equipado:
                return False, f"'{candidato.nome}' exige um escudo equipado"
            if grupo_cand == "UMA_ARMA_ESGRIMA" and estilo_arma in ("DUAS_MAOS", "ARMA_LONGA_HASTE", "ARMA_E_ESCUDO", "ARQUERIA_DISPARO"):
                return False, f"'{candidato.nome}' exige arma leve/ágil ou uma mão sem escudo"

        # 4. Se o personagem usa arco/disparo, bloqueia poderes estritamente corpo a corpo
        if estilo_arma == "ARQUERIA_DISPARO" and nome_c in PODERES_EXCLUSIVOS_CORPO_A_CORPO:
            return False, f"'{candidato.nome}' é exclusivo para ataques corpo a corpo (arma atual é à distância)"

        # 5. Se o personagem é Conjurador puro (sem arma marcial), evita poderes de arma pesada/arqueria
        if ficha.classe and ficha.classe.nome.lower() == "arcanista":
            if nome_c in PODERES_EXCLUSIVOS_CORPO_A_CORPO or grupo_cand in ("DUAS_MAOS", "ARQUERIA_DISPARO", "DUAS_ARMAS", "ARMA_E_ESCUDO"):
                return False, f"'{candidato.nome}' é poder marcial sem sinergia com conjuração arcana"

        return True, "Sinergia de estilo válida"

    @staticmethod
    def calcular_limite_pm_magia(ficha: FichaPersonagem) -> Tuple[int, str]:
        """Calcula o Limite de PM que o personagem pode gastar em uma única magia."""
        base = ficha.nivel
        partes = [f"{base} (Nível)"]
        atrib_chave, _ = ficha.obter_atributo_chave_magia()
        val_atrib = max(0, ficha.atributos_finais.obter(atrib_chave))

        if ficha.possui_poder("Magia Ilimitada"):
            base += val_atrib
            partes.append(f"{val_atrib} (Magia Ilimitada: +{atrib_chave})")

        for it in ficha.itens_inventario:
            nl = it.nome.lower()
            if nl in ("cajado arcano", "orbe cristalino"):
                base += 1
                partes.append(f"1 ({it.nome})")
                break

        return base, " + ".join(partes) + f" = {base} PM/magia"

    @classmethod
    def detalhar_aprimoramento_magia(cls, ficha: FichaPersonagem, magia: Magia) -> Dict[str, Any]:
        """
        Calcula o maior dano (ou efeito máximo) de `magia` aplicando seus aprimoramentos
        até o Limite de PM atual do conjurador, somando Arcano de Batalha e itens esotéricos.
        """
        custo_circulo = {1: 1, 2: 3, 3: 6, 4: 10, 5: 15}.get(magia.circulo, 1)
        limite_pm, _ = cls.calcular_limite_pm_magia(ficha)
        redutor_foco = 1 if ficha.possui_poder("Foco em Magia") else 0
        orcamento_aprim = max(0, limite_pm - max(1, custo_circulo - redutor_foco))

        atrib_chave, _ = ficha.obter_atributo_chave_magia()
        val_atrib = max(0, ficha.atributos_finais.obter(atrib_chave))
        tem_arcano_batalha = ficha.possui_poder("Arcano de Batalha")
        bonus_fixo = val_atrib if tem_arcano_batalha else 0
        str_arc = f" + {val_atrib} (Arcano de Batalha)" if bonus_fixo > 0 else ""

        nl = magia.nome.strip().lower()
        pm_gasto = min(limite_pm, custo_circulo)
        formula_final = "Efeito utilitário / controle"
        aprim_desc = f"Custo Base: {custo_circulo} PM (Limite atual: {limite_pm} PM)"
        dano_medio = 0.0

        if "seta infalível" in nl:
            # Base 1 PM: 2 setas de 1d4+1. +2 PM: muda para lanças de 1d8+1. +2 PM por lança adicional.
            if orcamento_aprim >= 2:
                extras = (orcamento_aprim - 2) // 2
                qtd_lancas = 2 + extras
                pm_aprim = 2 + extras * 2
                pm_gasto = custo_circulo + pm_aprim - redutor_foco
                dano_medio = qtd_lancas * 5.5 + bonus_fixo
                formula_final = f"{qtd_lancas}d8 + {qtd_lancas + bonus_fixo} essência (Acerto Automático!)"
                aprim_desc = (
                    f"Base {custo_circulo} PM (2 setas) + 2 PM (muda p/ lanças 1d8+1) + "
                    f"{extras * 2} PM (+{extras} lanças extras){str_arc} [Total: {pm_gasto} PM]"
                )
            else:
                dano_medio = 2 * 3.5 + bonus_fixo
                formula_final = f"2d4 + {2 + bonus_fixo} essência"
                aprim_desc = f"Base {custo_circulo} PM (2 setas 1d4+1){str_arc}"

        elif "toque chocante" in nl or "infligir ferimentos" in nl:
            # Base 1 PM: 2d8+2. Aprimoramento: +1 PM aumenta +1d8+1.
            dados = 2 + orcamento_aprim
            fixo = 2 + orcamento_aprim + bonus_fixo
            pm_gasto = custo_circulo + orcamento_aprim - redutor_foco
            dano_medio = dados * 4.5 + fixo
            tipo_d = "eletricidade" if "toque" in nl else "trevas"
            formula_final = f"{dados}d8 + {fixo} ({tipo_d})"
            aprim_desc = f"Base 1 PM (2d8+2) + {orcamento_aprim} PM (+{orcamento_aprim}d8+{orcamento_aprim}){str_arc} [Total: {pm_gasto} PM]"

        elif "explosão de chamas" in nl or "jato corrosivo" in nl:
            # Base 1 PM: 2d6. Aprimoramento: +1 PM aumenta +1d6.
            dados = 2 + orcamento_aprim
            pm_gasto = custo_circulo + orcamento_aprim - redutor_foco
            dano_medio = dados * 3.5 + bonus_fixo
            tipo_d = "fogo" if "chamas" in nl else "ácido"
            formula_final = f"{dados}d6" + (f" + {bonus_fixo}" if bonus_fixo else "") + f" ({tipo_d} em área)"
            aprim_desc = f"Base 1 PM (2d6) + {orcamento_aprim} PM (+{orcamento_aprim}d6){str_arc} [Total: {pm_gasto} PM]"

        elif "adaga mental" in nl:
            # Base 1 PM: 2d6 psíquico + atordoa. Aprimoramento: +2 PM aumenta +1d6 (ou +1 PM: +1d6).
            aplicacoes = orcamento_aprim // 2
            dados = 2 + aplicacoes
            pm_gasto = custo_circulo + aplicacoes * 2 - redutor_foco
            dano_medio = dados * 3.5 + bonus_fixo
            formula_final = f"{dados}d6" + (f" + {bonus_fixo}" if bonus_fixo else "") + " psíquico + Atordoado 1 rod."
            aprim_desc = f"Base 1 PM (2d6) + {aplicacoes * 2} PM (+{aplicacoes}d6){str_arc} [Total: {pm_gasto} PM]"

        elif "bola de fogo" in nl or "relâmpago" == nl or "toque vampírico" in nl or "toque vampirico" in nl:
            # Base 3 PM: 6d6. Aprimoramento: +2 PM aumenta +2d6.
            aplicacoes = orcamento_aprim // 2
            dados = 6 + aplicacoes * 2
            pm_gasto = custo_circulo + aplicacoes * 2 - redutor_foco
            dano_medio = dados * 3.5 + bonus_fixo
            tipo_d = "fogo em esfera 6m" if "bola" in nl else ("eletricidade em linha 30m" if "relâmpago" in nl else "trevas (cura metade)")
            formula_final = f"{dados}d6" + (f" + {bonus_fixo}" if bonus_fixo else "") + f" ({tipo_d})"
            aprim_desc = f"Base 3 PM (6d6) + {aplicacoes * 2} PM (+{aplicacoes * 2}d6 via +{aplicacoes}×[+2 PM]){str_arc} [Total: {pm_gasto} PM]"

        elif "flecha ácida" in nl or "sopro das uivantes" in nl:
            aplicacoes = orcamento_aprim // 2
            dados = 4 + aplicacoes * 2
            pm_gasto = custo_circulo + aplicacoes * 2 - redutor_foco
            dano_medio = dados * 3.5 + (4 * 3.5 if "flecha" in nl else 0) + bonus_fixo
            formula_final = f"{dados}d6" + (" + 4d6 contínuo" if "flecha" in nl else " frio + empurrão") + (f" + {bonus_fixo}" if bonus_fixo else "")
            aprim_desc = f"Base 3 PM (4d6) + {aplicacoes * 2} PM (+{aplicacoes * 2}d6){str_arc} [Total: {pm_gasto} PM]"

        elif "crânio voador" in nl or "raio solar" in nl:
            aplicacoes = orcamento_aprim // 2
            dados = 4 + aplicacoes * 2
            fixo_c = (4 + aplicacoes * 2 if "crânio" in nl else 0) + bonus_fixo
            pm_gasto = custo_circulo + aplicacoes * 2 - redutor_foco
            dano_medio = dados * 4.5 + fixo_c
            formula_final = f"{dados}d8" + (f" + {fixo_c}" if fixo_c else "")
            aprim_desc = f"Base 3 PM (4d8) + {aplicacoes * 2} PM (+{aplicacoes * 2}d8){str_arc} [Total: {pm_gasto} PM]"

        elif "lança ígnea" in nl or "erupções glaciais" in nl:
            # Base 6 PM: 8d6. Aprimoramento: +2 PM aumenta +2d6.
            aplicacoes = orcamento_aprim // 2
            dados = 8 + aplicacoes * 2
            pm_gasto = custo_circulo + aplicacoes * 2 - redutor_foco
            dano_medio = dados * 3.5 + bonus_fixo
            formula_final = f"{dados}d6" + (f" + {bonus_fixo}" if bonus_fixo else "") + " (fogo/perfuração ou frio/corte)"
            aprim_desc = f"Base 6 PM (8d6) + {aplicacoes * 2} PM (+{aplicacoes * 2}d6){str_arc} [Total: {pm_gasto} PM]"

        elif "coluna de chamas" in nl:
            # Base 6 PM: 6d6 fogo + 6d6 luz (12d6). Aprimoramento: +1 PM (+1d6).
            dados = 12 + orcamento_aprim
            pm_gasto = custo_circulo + orcamento_aprim - redutor_foco
            dano_medio = dados * 3.5 + bonus_fixo
            formula_final = f"{dados}d6" + (f" + {bonus_fixo}" if bonus_fixo else "") + " (fogo + luz sagrada)"
            aprim_desc = f"Base 6 PM (12d6) + {orcamento_aprim} PM (+{orcamento_aprim}d6){str_arc} [Total: {pm_gasto} PM]"

        elif "curar ferimentos" in nl:
            # Base 1 PM: 2d8+2 PV. +1 PM: +1d8+1 PV.
            dados = 2 + orcamento_aprim
            fixo_cura = 2 + orcamento_aprim + (ficha.atributos_finais.CAR if ficha.possui_poder("Cura Gentil") else 0)
            pm_gasto = custo_circulo + orcamento_aprim - redutor_foco
            dano_medio = dados * 4.5 + fixo_cura
            formula_final = f"Cura {dados}d8 + {fixo_cura} PV (Média: {dano_medio:.1f} PV)"
            aprim_desc = f"Base 1 PM (2d8+2) + {orcamento_aprim} PM (+{orcamento_aprim}d8+{orcamento_aprim} PV) [Total: {pm_gasto} PM]"

        elif "armadura arcana" in nl:
            # Base 1 PM: +5 Defesa. Aprimoramento: +2 PM (+1 Defesa por +2 PM) e reação +5.
            extras_def = orcamento_aprim // 2
            def_total = 5 + extras_def
            pm_gasto = custo_circulo + extras_def * 2 - redutor_foco
            formula_final = f"+{def_total} na Defesa pela cena (ou +{def_total + 5} como reação)"
            aprim_desc = f"Base 1 PM (+5 Def) + {extras_def * 2} PM (+{extras_def} Def adicional) [Total: {pm_gasto} PM]"

        elif "campo de força" in nl:
            # Base 3 PM: 30 PV temporários (ou RD 30 como reação por +1 PM). +1 PM: +5 PV temp / RD.
            pv_temp = 30 + orcamento_aprim * 5
            pm_gasto = custo_circulo + orcamento_aprim - redutor_foco
            formula_final = f"{pv_temp} PV temporários (ou RD {pv_temp} contra 1 dano como reação)"
            aprim_desc = f"Base 3 PM (30 PV/RD) + {orcamento_aprim} PM (+{orcamento_aprim * 5} PV/RD) [Total: {pm_gasto} PM]"

        elif "velocidade" in nl or "concentração de combate" in nl or "oração" in nl or "bênção" in nl:
            pm_gasto = min(limite_pm, custo_circulo + 2)
            formula_final = "Multiplicador de Ações / Precisão / Buff de Grupo"
            aprim_desc = f"Aprimoramento de Cena/Alcance até {pm_gasto} PM (Limite: {limite_pm} PM)"

        else:
            # Regra geral para magias de 3º a 5º círculo com dados no texto
            m_dado = re.search(r"(\d+)d(\d+)", magia.efeito_e_aprimoramentos)
            if m_dado:
                qtd_d = int(m_dado.group(1))
                faces_d = int(m_dado.group(2))
                aplicacoes = orcamento_aprim // 2
                qtd_final = qtd_d + aplicacoes * 2
                pm_gasto = custo_circulo + aplicacoes * 2 - redutor_foco
                dano_medio = qtd_final * ((faces_d + 1) / 2.0) + bonus_fixo
                formula_final = f"{qtd_final}d{faces_d}" + (f" + {bonus_fixo}" if bonus_fixo else "")
                aprim_desc = f"Base {custo_circulo} PM ({qtd_d}d{faces_d}) + {aplicacoes * 2} PM (+{aplicacoes * 2}d{faces_d}){str_arc} [Total: {pm_gasto} PM]"

        # Cálculo de Dano Mínimo, Máximo, Médio = (Máx + Mín)/2 em 1 Alvo e Dano Médio em Área (Múltiplos Alvos - Cap. 4 p. 172)
        alc_low = (magia.alcance or "").lower()
        ef_low = (magia.efeito_e_aprimoramentos or "").lower()
        eh_area = False
        alvos_area_padrao = 1
        geometria_area = "Alvo Único (1 criatura)"
        if any(k in nl for k in ("bola de fogo", "chuva de meteoros", "terremoto", "cólera de azgher", "colera de azgher", "barragem elemental", "tempestade divina")):
            eh_area = True
            alvos_area_padrao = 4
            geometria_area = "Esfera 6m / Área Ampla (4 alvos)"
        elif any(k in nl for k in ("explosão de chamas", "explosao de chamas", "sopro das uivantes", "mata-dragão", "mata-dragao", "erupções glaciais", "erupcoes glaciais", "coluna de chamas", "relâmpago", "relampago", "raio solar", "jato corrosivo", "trovão", "trovao")):
            eh_area = True
            alvos_area_padrao = 3
            geometria_area = "Cone / Cilindro / Linha (3 alvos)"
        elif any(k in ef_low or k in alc_low for k in ("esfera", "cone", "cilindro", "linha", "área", "area", "explosão", "explosao", " criaturas")):
            if dano_medio > 0 and "cura " not in formula_final.lower():
                eh_area = True
                alvos_area_padrao = 3
                geometria_area = "Área de Efeito (3 alvos)"

        dano_min_1alvo = 0
        dano_max_1alvo = 0
        dano_medio_1alvo = round(dano_medio, 1)
        m_form_d = re.search(r"(\d+)d(\d+)(?:\s*\+\s*(\d+))?", formula_final)
        if m_form_d and dano_medio > 0:
            q_m = int(m_form_d.group(1))
            f_m = int(m_form_d.group(2))
            fix_m = int(m_form_d.group(3)) if m_form_d.group(3) else 0
            dano_min_1alvo = q_m * 1 + fix_m
            dano_max_1alvo = q_m * f_m + fix_m
            dano_medio_1alvo = round((dano_max_1alvo + dano_min_1alvo) / 2.0, 1)

        dano_min_area = dano_min_1alvo * alvos_area_padrao
        dano_max_area = dano_max_1alvo * alvos_area_padrao
        dano_medio_area = round(dano_medio_1alvo * alvos_area_padrao, 1)

        return {
            "pm_gasto": pm_gasto,
            "limite_pm": limite_pm,
            "formula_final": formula_final,
            "aprim_desc": aprim_desc,
            "dano_min_1alvo": dano_min_1alvo,
            "dano_max_1alvo": dano_max_1alvo,
            "dano_medio": dano_medio_1alvo,
            "eh_area": eh_area,
            "alvos_area": alvos_area_padrao,
            "geometria_area": geometria_area,
            "dano_min_area": dano_min_area,
            "dano_max_area": dano_max_area,
            "dano_medio_area": dano_medio_area,
        }

    @classmethod
    def calcular_economia_acoes_ficha(cls, ficha: FichaPersonagem) -> Dict[str, Any]:
        """
        Calcula a Economia de Ações por Turno segundo o Capítulo 5 de Tormenta20 (p. 232-235):
        - Quantidade de Ações por Turno: 1 Ação Padrão + 1 Ação de Movimento (ou 1 Ação Completa),
          mais ações extras concedidas por poderes/magias (Reflexos de Combate, Surto Heroico,
          Magia Acelerada, Velocidade, Ataque Extra).
        - Classifica todas as capacidades do personagem em: Ação Padrão, Ação de Movimento,
          Ação Completa, Ação Livre e Reação.
        """
        qtd_padrao = 1
        qtd_movimento = 1
        extras_turno: List[str] = []

        if ficha.possui_poder("Reflexos de Combate"):
            extras_turno.append("+1 Ação de Movimento extra no 1º turno (Reflexos de Combate)")
        if ficha.possui_poder("Surto Heroico"):
            extras_turno.append("+1 Ação Padrão ou de Movimento extra (Surto Heroico, 5 PM, 1x/rodada)")
        if ficha.possui_poder("Magia Acelerada"):
            extras_turno.append("+1 Magia como Ação Livre (Magia Acelerada, +4 PM, 1x/rodada)")
        if any("velocidade" in m.nome.lower() for m in ficha.magias_conhecidas):
            extras_turno.append("+1 Ação Padrão ou de Movimento extra por turno (Magia Velocidade)")
        if ficha.possui_chifres():
            extras_turno.append("🐂 +1 Ataque Extra c/ Chifres ao Agredir (Minotauro p. 25: 1 PM, 1x/rodada, 1d6+FOR perfuração)")
        if ficha.nivel_na_classe("Guerreiro") >= 6:
            extras_turno.append("+1 Ataque Extra como Ação Livre ao Agredir (Guerreiro Nv 6, 2 PM)")
        if ficha.possui_poder("Golpe Pessoal"):
            extras_turno.append(f"☄️ Golpe Pessoal Customizado ({ficha.config_golpe_pessoal} — Guerreiro p. 66)")

        resumo_orcamento = (
            f"Orçamento Base por Turno: {qtd_padrao} Ação Padrão + {qtd_movimento} Ação de Movimento "
            f"(ou 1 Ação Completa = Padrão + Movimento; ou 2 Ações de Movimento) + Ações Livres + Reações fora do turno"
            + (f" | Extras da Build: {' ; '.join(extras_turno)}" if extras_turno else "")
        )

        acoes_padrao: List[str] = []
        acoes_movimento: List[str] = ["Deslocar-se até " + f"{ficha.deslocamento_final}m"]
        acoes_completas: List[str] = ["Investida (Desloca até o dobro + Ataque c/ +2 Atq e -2 Def)"]
        acoes_livres: List[str] = []
        reacoes: List[str] = []

        if ficha.arma_equipada:
            acoes_padrao.append(f"Agredir com {ficha.arma_equipada.nome}")
        for p in ficha.todos_os_poderes():
            ac_l = p.acao.lower()
            item_str = f"{p.nome} ({p.custo_pm} PM)" if p.custo_pm and p.custo_pm not in ("0", "Passivo") else p.nome
            if "completa" in ac_l:
                acoes_completas.append(item_str)
            elif "movimento" in ac_l:
                acoes_movimento.append(item_str)
            elif "reação" in ac_l or "reacao" in ac_l:
                reacoes.append(item_str)
            elif "livre" in ac_l:
                acoes_livres.append(item_str)
            elif "padrão" in ac_l or "padrao" in ac_l:
                acoes_padrao.append(item_str)

        for m in ficha.magias_conhecidas[:8]:
            ex_l = m.execucao.lower()
            nm_l = m.nome.lower()
            if "armadura arcana" in nm_l:
                acoes_padrao.append("Magia: Armadura Arcana (Padrão, 1 PM: +5 Defesa na cena — p. 179)")
                reacoes.append("Magia: Armadura Arcana (Aprimoramento Reação, +1 PM [2 PM total]: +5 Defesa contra o próximo ataque — p. 179)")
            elif "campo de força" in nm_l:
                acoes_padrao.append("Magia: Campo de Força (Padrão, 3 PM: 30 PV Temporários — p. 182)")
                reacoes.append("Magia: Campo de Força (Aprimoramento Reação, +1 PM [4 PM total]: RD 30 contra o próximo dano — p. 182)")
            elif "salto dimensional" in nm_l:
                acoes_padrao.append("Magia: Salto Dimensional (Padrão, 3 PM — p. 205)")
                reacoes.append("Magia: Salto Dimensional (Aprimoramento Reação, +1 PM [4 PM total]: +5 Defesa/Reflexos e salta 1,5m — p. 205)")
            elif "reação" in ex_l or "reacao" in ex_l:
                reacoes.append(f"Magia: {m.nome} (Reação)")
            elif "movimento" in ex_l:
                acoes_movimento.append(f"Magia: {m.nome} (Movimento)")
            elif "completa" in ex_l:
                acoes_completas.append(f"Magia: {m.nome} (Completa)")
            elif "livre" in ex_l:
                acoes_livres.append(f"Magia: {m.nome} (Livre)")
            else:
                acoes_padrao.append(f"Magia: {m.nome} (Padrão)")

        if ficha.classe:
            nc = ficha.classe.nome.lower()
            if nc == "guerreiro":
                esc_e = 4 * (1 + (ficha.nivel - 1) // 4)
                custo_e = 1 + (ficha.nivel - 1) // 4
                acoes_livres.insert(0, f"Ataque Especial ({custo_e} PM: +{esc_e} no Ataque OU +{esc_e} no Dano OU +{esc_e//2} Atq/+{esc_e//2} Dano — p. 65)")
                if ficha.possui_poder("Golpe Pessoal"):
                    acoes_livres.insert(1, f"Golpe Pessoal ({ficha.config_golpe_pessoal} — p. 66)")
                if ficha.possui_chifres():
                    acoes_livres.insert(0, "🐂 Chifres (1 PM ao Agredir: +1 ataque corpo a corpo extra 1d6+FOR — p. 25)")
                if ficha.nivel >= 3:
                    reacoes.insert(0, "Durão (Reação, 3 PM: reduz o dano sofrido à metade — p. 65)")
            elif nc == "bárbaro":
                acoes_livres.insert(0, "Fúria (Livre, 2 PM: +Ataque/+Dano corpo a corpo — p. 40)")
            elif nc == "paladino":
                acoes_livres.insert(0, "Golpe Divino (Ao Agredir, 2 PM: +CAR no Ataque e +1d8 no Dano — p. 81)")
            elif nc == "caçador":
                acoes_movimento.insert(0, "Marca da Presa (Movimento, 1 PM: +1d4 a +1d8 no Dano — p. 49)")
            elif nc == "cavaleiro":
                reacoes.insert(0, "Baluarte (Reação, 1 PM: +Defesa e +Testes de Resistência — p. 56)")
                if ficha.nivel >= 2:
                    acoes_livres.insert(0, "Duelo (Livre, 2 PM: +2 Ataque e +2 Dano contra 1 oponente — p. 56)")
            elif nc == "nobre":
                reacoes.insert(0, "Orgulho (Reação ao fazer teste, 1+ PM: +2 por PM gasto — p. 79)")
        if ficha.raca and ficha.raca.nome.lower() == "kliren":
            reacoes.insert(0, "Engenhosidade (Ao fazer teste de perícia/resistência, 2 PM: soma INT — p. 23)")

        return {
            "resumo_orcamento": resumo_orcamento,
            "acoes_padrao": acoes_padrao or ["Agredir (p. 233)", "Manobra de Combate (p. 234)", "Fintar (p. 234)"],
            "acoes_movimento": acoes_movimento,
            "acoes_completas": acoes_completas,
            "acoes_livres": acoes_livres or ["Falar / Jogar-se no chão / Soltar item (p. 236)"],
            "reacoes": reacoes or ["Testes de Resistência da Ficha (Fortitude, Reflexos, Vontade — p. 233)"],
        }

    @classmethod
    def calcular_resumo_dano_ficha(cls, ficha: FichaPersonagem) -> Dict[str, Any]:
        """
        Retorna um dicionário completo com todas as métricas de dano marcial e mágico
        da ficha para exibição na Primeira Aba e para o cálculo do Score MCTS.
        """
        limite_pm, str_limite_pm = cls.calcular_limite_pm_magia(ficha)
        circ_max = max(1, ficha.circulo_maximo_permitido())
        atr = ficha.atributos_finais
        atrib_chave = "INT"
        if ficha.classe:
            prim = ficha.classe.atributo_principal.split()[0].upper()
            if prim in ("INT", "SAB", "CAR"):
                atrib_chave = prim
        val_atrib_mag = max(0, atr.obter(atrib_chave))

        # 1. Cálculo do Combo Raio Arcano (se possuir o poder Raio Arcano)
        tem_raio = ficha.possui_poder("Raio Arcano")
        tem_elem = ficha.possui_poder("Raio Elemental")
        tem_pod = ficha.possui_poder("Raio Poderoso")
        tem_arc_bat = ficha.possui_poder("Arcano de Batalha")

        dano_medio_raio = 0.0
        desc_raio = "Não possui Raio Arcano."
        if tem_raio:
            faces_raio = 12 if tem_pod else (10 if tem_elem else 8)
            alcance_raio = "Médio" if tem_pod else "Curto"
            elem_str = "Elemental (Ácido/Eletr./Fogo/Frio/Trevas)" if tem_elem else "Essência"
            bonus_r = val_atrib_mag if tem_arc_bat else 0
            dano_medio_raio = circ_max * ((faces_raio + 1) / 2.0) + bonus_r
            sinal_b = f" + {bonus_r} (Arcano de Batalha)" if bonus_r else ""
            desc_raio = (
                f"{circ_max}d{faces_raio}{sinal_b} [{elem_str} | Alcance {alcance_raio} | 0 PM] "
                f"— Dano Médio Sustentado: {dano_medio_raio:.1f}/rodada"
            )

        # 2. Melhor Magia de Dano Explosivo (Burst Damage com Aprimoramentos no Limite de PM + Burst de Magia Acelerada p. 131)
        melhor_magia_info = None
        maior_dano_magia = 0.0
        detalhes_magias: Dict[str, Dict[str, Any]] = {}
        for m in ficha.magias_conhecidas:
            info_m = cls.detalhar_aprimoramento_magia(ficha, m)
            detalhes_magias[m.id_magia] = info_m
            if info_m["dano_medio"] > maior_dano_magia and "cura " not in info_m["formula_final"].lower():
                maior_dano_magia = info_m["dano_medio"]
                melhor_magia_info = (m.nome, info_m)

        # Regra Oficial p. 131: Magia Acelerada (+4 PM, 2º círculo) permite lançar 1 magia como Ação Livre (1x/rodada)
        # além da magia da Ação Padrão, elevando drasticamente o Burst DPR na rodada de abertura!
        if ficha.possui_poder("Magia Acelerada") and limite_pm >= 5 and maior_dano_magia > 0 and melhor_magia_info is not None:
            orc_acel = max(1, limite_pm - 4)
            ganho_acel = round(max(11.0, (orc_acel * 4.5) + (val_atrib_mag if tem_arc_bat else 0)), 1)
            maior_dano_magia = round(maior_dano_magia + ganho_acel, 1)
            nome_m_b, info_m_b = melhor_magia_info
            info_m_copia = dict(info_m_b)
            info_m_copia["dano_medio"] = maior_dano_magia
            info_m_copia["formula_final"] = f"{info_m_b['formula_final']} + ⚡ Magia Acelerada [Ação Livre +4 PM: +{ganho_acel:.1f} dano]"
            melhor_magia_info = (nome_m_b, info_m_copia)

        # 3. Cálculo Exato do Dano Marcial / à Distância (Passos de Dano, Crítico, Estilos e Economia de Ações)
        dano_medio_arma = 0.0
        desc_dano_arma = "Sem arma equipada (Desarmado 1d3)."
        economia_acoes_resumo = cls.calcular_economia_acoes_ficha(ficha)

        if ficha.arma_equipada:
            a = ficha.arma_equipada
            estilo = cls.identificar_estilo_arma(ficha)
            eh_dist = estilo in ("ARQUERIA_DISPARO", "ARREMESSO")
            per_atk = "Pontaria" if eh_dist else "Luta"
            bonus_atk = ficha.bonus_pericias.get(per_atk, 0)
            partes_dano: List[str] = []
            partes_atk: List[str] = [f"{per_atk} {bonus_atk:+d}"]

            # 3.1 Acuidade com Arma: se usa arma leve/ágil (Uma Mão ou Duas Armas) e DES > FOR, substitui FOR por DES no Ataque!
            usa_acuidade = (
                not eh_dist
                and ficha.possui_poder("Acuidade com Arma")
                and estilo in ("UMA_ARMA_ESGRIMA", "DUAS_ARMAS")
                and atr.DES > atr.FOR
            )
            if usa_acuidade:
                diff_des_for = atr.DES - atr.FOR
                bonus_atk += diff_des_for
                partes_atk.append(f"+{diff_des_for} (DES Acuidade no Ataque)")

            # 3.2 Passos de Dano da Arma (Tabela 3-2, p. 142)
            passos_extras = 0
            fontes_passos: List[str] = []
            if ficha.possui_poder("Empunhadura Poderosa"):
                passos_extras += 1
                fontes_passos.append("Empunhadura Poderosa")
                bonus_atk -= 2
                partes_atk.append("-2 (Empunhadura Poderosa)")
            if (ficha.possui_poder("Arma Sagrada") or ficha.possui_poder("Espada Justiceira") or ficha.possui_poder("Espada Solar")) and ficha.deus:
                arma_pref = ficha.deus.arma_preferida.lower()
                if any(w in a.nome.lower() for w in arma_pref.split("/")[0].split()):
                    passos_extras += 1
                    fontes_passos.append(f"Arma Sagrada de {ficha.deus.nome}")
            if ficha.possui_poder("Armamento da Natureza") or any("armamento da natureza" in m.nome.lower() for m in ficha.magias_conhecidas):
                passos_extras += 1
                fontes_passos.append("Armamento da Natureza")

            dado_final_str, qtd_d, faces_d, media_dados_arma = avancar_passos_dano_t20(a.dano_ou_defesa, passos_extras)
            str_passo = f" [{a.dano_ou_defesa} ➔ {dado_final_str}: +{'/'.join(fontes_passos)}]" if passos_extras > 0 else ""

            if ficha.possui_poder("Destruidor") and estilo in ("DUAS_MAOS", "ARMA_LONGA_HASTE"):
                ganho_dest = qtd_d * (2.0 / faces_d) * (((faces_d + 1) / 2.0) - 1.5)
                media_dados_arma += ganho_dest
                partes_dano.append(f"{dado_final_str}{str_passo} (Destruidor rerrola 1-2: média {media_dados_arma:.1f})")
            else:
                partes_dano.append(f"{dado_final_str}{str_passo} (média {media_dados_arma:.1f})")

            # 3.3 Bônus Fixos de Atributo e Estilo por Golpe
            fixo_dano = 0
            dados_extras_media = 0.0
            if not eh_dist:
                if usa_acuidade:
                    fixo_dano += atr.DES
                    partes_dano.append(f"+{atr.DES} (DES Acuidade)")
                else:
                    fixo_dano += atr.FOR
                    partes_dano.append(f"{atr.FOR:+d} (FOR)")
            else:
                if "arco longo" in a.nome.lower() or ficha.possui_poder("Arremesso Potente"):
                    fixo_dano += atr.FOR
                    partes_dano.append(f"{atr.FOR:+d} (FOR Arco Longo/Arremesso)")
                if ficha.possui_poder("Estilo de Disparo") and estilo == "ARQUERIA_DISPARO":
                    fixo_dano += atr.DES
                    partes_dano.append(f"+{atr.DES} (DES Estilo de Disparo)")
                if ficha.possui_poder("Arqueiro") and estilo == "ARQUERIA_DISPARO":
                    ganho_arq = min(ficha.nivel, max(0, atr.SAB))
                    fixo_dano += ganho_arq
                    partes_dano.append(f"+{ganho_arq} (SAB Arqueiro)")

            # Bônus específicos de cada Estilo de Combate (Regras Oficiais do Livro p. 124-129)
            if ficha.possui_poder("Estilo de Duas Mãos") and estilo in ("DUAS_MAOS", "ARMA_LONGA_HASTE"):
                fixo_dano += 5
                partes_dano.append("+5 (Estilo de Duas Mãos)")
            if ficha.possui_poder("Estilo de Arma Longa") and estilo == "ARMA_LONGA_HASTE":
                bonus_atk += 2
                partes_atk.append("+2 (Estilo de Arma Longa)")
            if ficha.possui_poder("Estilo de Uma Arma") and estilo == "UMA_ARMA_ESGRIMA":
                bonus_atk += 2
                partes_atk.append("+2 (Estilo de Uma Arma)")
            if ficha.possui_poder("Ataque Poderoso") and not eh_dist:
                fixo_dano += 5
                bonus_atk -= 2
                partes_dano.append("+5 (Ataque Poderoso)")
                partes_atk.append("-2 (Ataque Poderoso)")
            if ficha.possui_poder("Especialização em Arma"):
                fixo_dano += 2
                partes_dano.append("+2 (Especialização em Arma)")
            if ficha.possui_poder("Valentão") and not eh_dist:
                fixo_dano += 2
                bonus_atk += 2
                partes_dano.append("+2 (Valentão)")
                partes_atk.append("+2 (Valentão)")
            if ficha.possui_poder("Esgrimista") and estilo in ("UMA_ARMA_ESGRIMA", "DUAS_ARMAS"):
                ganho_esg = min(ficha.nivel, max(0, atr.INT))
                if ganho_esg > 0:
                    fixo_dano += ganho_esg
                    partes_dano.append(f"+{ganho_esg} (INT Esgrimista)")
            if ficha.possui_poder("Foco em Arma"):
                bonus_atk += 2
                partes_atk.append("+2 (Foco em Arma)")
            if ficha.possui_poder("Mira Apurada") and eh_dist:
                bonus_atk += 2
                partes_atk.append("+2 (Mira Apurada)")

            # Poderes Concedidos que afetam Ataque e Dano (Armas da Ambição, Sangue de Ferro, Fúria Divina, Espada Solar, Kiai Divino)
            if ficha.possui_poder("Armas da Ambição"):
                bonus_atk += 1
                partes_atk.append("+1 (Armas da Ambição)")
            if ficha.possui_poder("Sangue de Ferro"):
                fixo_dano += 2
                partes_dano.append("+2 (Sangue de Ferro)")
            if ficha.possui_poder("Fúria Divina") and not eh_dist:
                bonus_atk += 2
                fixo_dano += 2
                partes_atk.append("+2 (Fúria Divina)")
                partes_dano.append("+2 (Fúria Divina)")
            if ficha.possui_poder("Espada Solar") and not eh_dist:
                dados_extras_media += 3.5
                partes_dano.append("+1d6 fogo (Espada Solar: +3.5)")

            # Habilidades de Classe (Guerreiro: Ataque Especial p. 65 aplica-se a 1 ataque conforme o modo escolhido, NÃO é passivo em todos os golpes!)
            bonus_atq_especial_1golpe = 0
            bonus_dano_especial_1golpe = 0
            custo_pm_ataque_especial = 0
            desc_ataque_especial = ""
            nv_guerreiro = ficha.nivel_na_classe("Guerreiro")
            nv_barbaro = ficha.nivel_na_classe("Bárbaro")
            nv_cacador = ficha.nivel_na_classe("Caçador")
            nv_paladino = ficha.nivel_na_classe("Paladino")
            nv_ladino = ficha.nivel_na_classe("Ladino")

            if nv_guerreiro >= 1:
                esc_esp = 4 * (1 + (nv_guerreiro - 1) // 4)
                custo_pm_ataque_especial = 1 + (nv_guerreiro - 1) // 4
                modo_ae = (ficha.modo_ataque_especial or "ATAQUE").upper()
                if modo_ae == "ATAQUE":
                    bonus_atq_especial_1golpe = esc_esp
                    bonus_dano_especial_1golpe = 0
                    desc_ataque_especial = f"Ataque Especial (Guerreiro Nv {nv_guerreiro}, {custo_pm_ataque_especial} PM): +{esc_esp} no Ataque (p. 65)"
                elif modo_ae == "DANO":
                    bonus_atq_especial_1golpe = 0
                    bonus_dano_especial_1golpe = esc_esp
                    desc_ataque_especial = f"Ataque Especial (Guerreiro Nv {nv_guerreiro}, {custo_pm_ataque_especial} PM): +{esc_esp} no Dano (p. 65)"
                else:
                    bonus_atq_especial_1golpe = esc_esp // 2
                    bonus_dano_especial_1golpe = esc_esp // 2
                    desc_ataque_especial = f"Ataque Especial (Guerreiro Nv {nv_guerreiro}, {custo_pm_ataque_especial} PM): +{esc_esp//2} Atq e +{esc_esp//2} Dano (p. 65)"
            if nv_barbaro >= 1:
                furia_b = 2 + (nv_barbaro - 1) // 5
                fixo_dano += furia_b
                bonus_atk += furia_b
                partes_dano.append(f"+{furia_b} (Fúria Bárbaro Nv {nv_barbaro})")
                partes_atk.append(f"+{furia_b} (Fúria)")
            if nv_cacador >= 1:
                dado_mp = "1d4" if nv_cacador < 5 else ("1d6" if nv_cacador < 13 else "1d8")
                med_mp = 2.5 if nv_cacador < 5 else (3.5 if nv_cacador < 13 else 4.5)
                dados_extras_media += med_mp
                partes_dano.append(f"+{dado_mp} (Marca da Presa Caçador Nv {nv_cacador}: +{med_mp:.1f})")
            nv_lutador = ficha.nivel_na_classe("Lutador")
            nv_nobre = ficha.nivel_na_classe("Nobre")
            nv_bardo = ficha.nivel_na_classe("Bardo")
            nv_inventor = ficha.nivel_na_classe("Inventor")

            if nv_barbaro >= 2 and ficha.possui_poder("Frenesi"):
                dados_extras_media += max(6.5, (fixo_dano + 6.5) * 0.72)
                partes_dano.append("+Frenesi (Ataque Extra 2 PM)")
            if nv_paladino >= 1:
                gd_dados = 1 + (nv_paladino - 1) // 4
                bonus_atk += max(0, atr.CAR)
                dados_extras_media += gd_dados * 4.5
                partes_atk.append(f"+{max(0, atr.CAR)} (CAR Golpe Divino Paladino Nv {nv_paladino})")
                partes_dano.append(f"+{gd_dados}d8 (Golpe Divino Nv {nv_paladino}: +{gd_dados * 4.5:.1f})")
                if nv_paladino >= 5 or ficha.possui_poder("Julgamento Divino: Vindicação"):
                    bonus_atk += 2
                    fixo_dano += 4
                    partes_dano.append("+4 (Vindicação/Aura)")
            if nv_ladino >= 1:
                d_furt_m = (nv_ladino + 1) // 2
                mult_ass = 2.0 if (nv_ladino >= 5 or ficha.possui_poder("Assassinar")) else 1.0
                dados_extras_media += d_furt_m * 3.5 * mult_ass
                partes_dano.append(f"+{int(d_furt_m * mult_ass)}d6 (Ataque Furtivo{' + Assassinar' if mult_ass > 1 else ''} Ladino Nv {nv_ladino}: +{d_furt_m * 3.5 * mult_ass:.1f})")
                if nv_ladino >= 4 or ficha.possui_poder("Emboscar"):
                    bonus_atk += 2
                    partes_atk.append("+2 (Emboscar/Furtividade)")
            if nv_lutador >= 1:
                # Briga (p. 76): 1d6 -> 1d8 (Nv5) -> 1d10 (Nv9) -> 1d12 (Nv13) -> 2d10 (Nv17) + Golpe Relâmpago (+1 ataque 1 PM) + Trocação (Nv6+)
                med_briga = 3.5 if nv_lutador < 5 else (4.5 if nv_lutador < 9 else (5.5 if nv_lutador < 13 else (6.5 if nv_lutador < 17 else 11.0)))
                atq_extra_lut = 1.0 + (0.65 if nv_lutador >= 6 else 0.0)
                bonus_atk += max(1, (nv_lutador // 4) + 1)
                dados_extras_media += (med_briga + max(2, atr.FOR)) * atq_extra_lut
                partes_atk.append(f"+{max(1, (nv_lutador // 4) + 1)} (Briga/Golpe Relâmpago)")
                partes_dano.append(f"+{((med_briga + max(2, atr.FOR)) * atq_extra_lut):.1f} (Desarmado Briga + Golpe Relâmpago{' + Trocação' if nv_lutador >= 6 else ''})")
            if nv_nobre >= 1:
                # Nobre Suporte & Comandante (p. 78): Orgulho (+CAR*2 em testes), Gritar Ordens (multiplicador de 3 aliados) e Palavras Afiadas
                b_ordens = 1 + (nv_nobre - 1) // 4
                bonus_atk += min(6, max(2, atr.CAR))
                dados_extras_media += (b_ordens * 7.5) + (max(1, atr.CAR) * 2.5)
                partes_atk.append(f"+{min(6, max(2, atr.CAR))} (Orgulho/Presença Nobre)")
                partes_dano.append(f"+{(b_ordens * 7.5 + max(1, atr.CAR) * 2.5):.1f} (Gritar Ordens +{b_ordens} em Grupo + Palavras Afiadas)")
            if nv_bardo >= 1:
                # Bardo (p. 43): Inspiração (+1 a +5 Atq/Dano em grupo) + Esgrima Mágica (CAR) + Prestidigitação (Ação Livre)
                b_insp = 1 + (nv_bardo - 1) // 4
                bonus_atk += b_insp + max(0, atr.CAR // 2)
                fixo_dano += b_insp
                dados_extras_media += (b_insp * 5.0) + (7.0 if nv_bardo >= 6 else 0.0)
                partes_atk.append(f"+{b_insp} (Inspiração Bardo)")
                partes_dano.append(f"+{b_insp} (Inspiração) + {(b_insp * 5.0 + (7.0 if nv_bardo >= 6 else 0.0)):.1f} (Suporte Grupo/Prestidigitação)")
            if nv_inventor >= 1:
                # Inventor (p. 67): Engenhosidade (+INT em testes) + Armeiro/Balística (+INT dano) + Engenhoqueiro
                b_int = max(2, atr.INT)
                bonus_atk += b_int
                fixo_dano += b_int
                dados_extras_media += 4.5 + (3.5 if nv_inventor >= 5 else 0.0)
                partes_atk.append(f"+{b_int} (Engenhosidade INT Inventor)")
                partes_dano.append(f"+{b_int} (Armeiro/Balística INT) + Engenhocas")

            # 3.4 Margem de Ameaça e Multiplicador de Crítico (Livro p. 142 & p. 235)
            margem_crit, mult_crit = extrair_critico_base_arma(a.critico_ou_penalidade)
            fontes_crit: List[str] = []
            if ficha.possui_poder("Ataque Preciso") and estilo == "UMA_ARMA_ESGRIMA":
                margem_crit = max(1, margem_crit - 2)
                mult_crit += 1
                fontes_crit.append("Ataque Preciso (+2 margem/+1 mult)")
            if ficha.possui_poder("En Garde") and estilo == "UMA_ARMA_ESGRIMA":
                margem_crit = max(1, margem_crit - 2)
                fontes_crit.append("En Garde (+2 margem)")
            if ficha.possui_poder("Mira Apurada") and eh_dist:
                margem_crit = max(1, margem_crit - 2)
                fontes_crit.append("Mira Apurada (+2 margem)")
            if ficha.possui_poder("Armas da Ambição"):
                margem_crit = max(1, margem_crit - 1)
                fontes_crit.append("Armas da Ambição (+1 margem)")
            if ficha.possui_poder("Tradição de Lin-Wu") and "katana" in a.nome.lower():
                margem_crit = max(1, margem_crit - 1)
                fontes_crit.append("Tradição de Lin-Wu (+1 margem)")
            if ficha.possui_poder("Crítico Brutal"):
                mult_crit += 1
                fontes_crit.append("Crítico Brutal (+1 mult)")

            chance_ameaca_d20 = (21 - margem_crit) / 20.0
            # Em um acerto, o ganho médio do crítico multiplica APENAS os dados base da arma por (mult_crit - 1)
            ganho_esperado_crit_por_golpe = media_dados_arma * (mult_crit - 1) * chance_ameaca_d20
            dano_normal_golpe = media_dados_arma + fixo_dano + dados_extras_media
            dano_critico_golpe = (media_dados_arma * mult_crit) + fixo_dano + dados_extras_media
            dano_medio_por_golpe = dano_normal_golpe + ganho_esperado_crit_por_golpe

            # 3.5 Quantidade de Ataques e Ataques Secundários (Duas Armas, Disparo Rápido, Ataque com Escudo, Piqueiro)
            num_ataques = 1.0
            detalhes_ataques_extras: List[str] = []
            dano_extra_secundario = 0.0

            if ficha.nivel_na_classe("Guerreiro") >= 6:
                num_ataques += 1.0
                detalhes_ataques_extras.append("Ataque Extra (Guerreiro Nv 6)")

            if ficha.possui_poder("Disparo Rápido") and eh_dist:
                num_ataques += 1.0
                bonus_atk -= 2
                partes_atk.append("-2 (Disparo Rápido: Ação Completa p/ +1 disparo)")
                detalhes_ataques_extras.append("Disparo Rápido (+1 tiro)")

            if estilo == "DUAS_ARMAS" or ficha.possui_poder("Estilo de Duas Armas") or ficha.possui_poder("Ambidestria"):
                if estilo not in ("DUAS_MAOS", "ARMA_E_ESCUDO", "ARQUERIA_DISPARO"):
                    tem_ambidestria = ficha.possui_poder("Ambidestria")
                    if not tem_ambidestria:
                        bonus_atk -= 2
                        partes_atk.append("-2 (Estilo de Duas Armas s/ Ambidestria)")
                    else:
                        partes_atk.append("+0 (Ambidestria zera penalidade de 2 armas)")
                    # Ataque da mão secundária (Espada curta 1d6 = 3.5 ou arma de 1 mão 1d8 = 4.5 com Arma Secundária Grande)
                    med_sec = 4.5 if ficha.possui_poder("Arma Secundária Grande") else 3.5
                    dano_golpe_sec = med_sec + fixo_dano + dados_extras_media + (med_sec * chance_ameaca_d20)
                    dano_extra_secundario += dano_golpe_sec
                    detalhes_ataques_extras.append(f"2ª Arma Mão Inábil (+{dano_golpe_sec:.1f} dano)")

            if ficha.possui_poder("Ataque com Escudo") and ficha.escudo_equipado:
                med_esc = 3.5 if "pesado" in ficha.escudo_equipado.nome.lower() else 2.5
                dano_esc = med_esc + max(0, atr.FOR) + (2 if ficha.possui_poder("Sangue de Ferro") else 0)
                dano_extra_secundario += dano_esc
                detalhes_ataques_extras.append(f"Ataque com Escudo (+{dano_esc:.1f} dano [1d6+FOR])")

            if ficha.possui_poder("Piqueiro") and estilo == "ARMA_LONGA_HASTE":
                dano_piq = dano_medio_por_golpe * 0.65  # Reação frequente quando inimigo avança no alcance
                dano_extra_secundario += dano_piq
                detalhes_ataques_extras.append(f"Reação Piqueiro (+{dano_piq:.1f} dano médio)")

            # 3.6 Habilidade Racial / Concedida de Arma Natural Extra: Chifres (Minotauro p. 25) ou Mordida (Trog p. 31 / Presas Primordiais p. 134)
            info_nat = ficha.obter_info_arma_natural_extra()
            if info_nat and not eh_dist:
                b_furia = (2 + (ficha.nivel - 1) // 5) if (ficha.classe and ficha.classe.nome.lower() == "bárbaro") else 0
                b_fdiv = 2 if ficha.possui_poder("Fúria Divina") else 0
                atq_nat = ficha.bonus_pericias.get("Luta", 0) + (2 if ficha.possui_poder("Valentão") else 0) + b_furia + b_fdiv
                dano_fixo_nat = max(0, atr.FOR) + (2 if ficha.possui_poder("Sangue de Ferro") else 0) + (2 if ficha.possui_poder("Valentão") else 0) + b_furia + b_fdiv
                dano_med_nat = round(info_nat["media_dado_crit"] + dano_fixo_nat, 1)
                dano_extra_secundario += dano_med_nat
                detalhes_ataques_extras.append(
                    f"{info_nat['icone']} Ataque Extra {info_nat['nome_curto']} [1 PM ao Agredir]: Atq {atq_nat:+d}, Dano {info_nat['dado_str']}+{dano_fixo_nat} perfuração (+{dano_med_nat:.1f} méd.)"
                )

            # 3.7 Habilidade Ataque Especial (Guerreiro p. 65 — aplicada a 1 ataque quando gasta PM)
            if ficha.nivel_na_classe("Guerreiro") >= 1:
                ganho_ev_ae = bonus_dano_especial_1golpe + (bonus_atq_especial_1golpe * 0.05 * dano_medio_por_golpe)
                dano_extra_secundario += ganho_ev_ae
                detalhes_ataques_extras.append(
                    f"⚔️ {desc_ataque_especial} (+{ganho_ev_ae:.1f} EV)"
                )

            # 3.8 Otimização Matemática do Poder Golpe Pessoal (Guerreiro 5º nível, Livro p. 66-67)
            if ficha.possui_poder("Golpe Pessoal"):
                media_um_dado_arma = (faces_d + 1) / 2.0
                # Avalia combinações oficiais de efeitos (pp. 66-67) respeitando o limite de PM = ficha.nivel
                candidatos_gp = []
                # Opção A: Crítico-Letal Brutal c/ Lento (Destruidor +2 PM, Letal +2 PM, Brutal +1 PM, Preciso +1 PM, Lento -2 PM = 4 PM líquidos)
                ganho_crit_letal = media_dados_arma * 0.35 + media_um_dado_arma + dano_medio_por_golpe * 0.22
                candidatos_gp.append((
                    ganho_crit_letal + (4.0 if estilo in ("DUAS_MAOS", "ARMA_LONGA_HASTE") else 0.0),
                    min(ficha.nivel, 4),
                    "Destruidor (+1x Crít) + Letal (+2 Margem) + Brutal (+1d) + Preciso (2d20 — escolhe o melhor) + Lento (-2 PM)",
                    f"+1d{faces_d} Brutal + Crítico {max(1, margem_crit-2)}/x{mult_crit+1} + Preciso 2d20"
                ))
                # Opção B: Explosão Elemental, Brutal, Penetrante & Preciso (Ação Padrão, sem Lento: 4 a 5 PM)
                custo_b = 5 if ficha.nivel >= 5 else min(ficha.nivel, 4)
                ganho_elem_b = media_um_dado_arma + 7.0 + (5.0 if custo_b >= 5 else 0.0) + dano_medio_por_golpe * 0.20
                candidatos_gp.append((
                    ganho_elem_b + (3.5 if estilo not in ("UMA_ARMA_ESGRIMA", "ARQUERIA_DISPARO") else 0.0),
                    custo_b,
                    "Brutal (+1d) + Elemental (+2d6 Fogo) + Preciso (2d20 — escolhe o melhor)" + (" + Penetrante (-5 RD)" if custo_b >= 5 else ""),
                    f"+1d{faces_d} Brutal + 2d6 Fogo + Preciso 2d20" + (" + Ignora 5 RD" if custo_b >= 5 else "")
                ))
                # Opção C: Combo Devastador Nv 6+ (Brutal +1, Elemental +2, Letal +2, Destruidor +2, Preciso +1, Lento -2 = 6 PM líquidos; ou Ação Padrão s/ Destruidor = 6 PM)
                if ficha.nivel >= 6:
                    ganho_hiper = media_dados_arma * 0.45 + media_um_dado_arma + 7.0 + dano_medio_por_golpe * 0.25 + 5.0
                    candidatos_gp.append((
                        ganho_hiper,
                        6,
                        "Brutal (+1d) + Elemental (+2d6 Fogo) + Letal (+2 Margem) + Destruidor (+1x Crít) + Preciso (2d20 — escolhe o melhor) + Lento (-2 PM)",
                        f"+1d{faces_d} Brutal + 2d6 Fogo + Crítico {max(1, margem_crit-2)}/x{mult_crit+1} + Preciso 2d20 (8 PM - 2 PM Lento = 6 PM)"
                    ))
                # Opção D: Disparo Teleguiado Elemental (para Arquearia/Arremesso)
                if eh_dist:
                    candidatos_gp.append((
                        ganho_elem_b + 8.0,
                        min(ficha.nivel, 5),
                        "Teleguiado (Ignora Cobertura/Camuflagem) + Elemental (+2d6) + Brutal (+1d) + Preciso (2d20 — escolhe o melhor)",
                        f"Teleguiado + 2d6 Elemental + 1d{faces_d} Brutal + Preciso 2d20"
                    ))
                candidatos_gp.sort(key=lambda x: x[0], reverse=True)
                melhor_gp_ev, custo_gp, cfg_gp_otima, resumo_gp_curto = candidatos_gp[0]
                ficha.config_golpe_pessoal = cfg_gp_otima
                ganho_total_gp = round(melhor_gp_ev, 1)
                dano_extra_secundario += ganho_total_gp
                detalhes_ataques_extras.append(
                    f"☄️ Golpe Pessoal Otimizado [{custo_gp} PM — {cfg_gp_otima}]: {resumo_gp_curto} (+{ganho_total_gp:.1f} EV)"
                )

            # Cálculo Oficial solicitado pelo usuário:
            # 1) Dano Médio Normal = (Dano Máximo + Dano Mínimo) / 2
            # 2) Dano Médio Crítico = (Crítico Máximo + Crítico Mínimo) / 2 (Regra p. 231: multiplica apenas os dados básicos da arma)
            # 3) Dano Médio por Rodada (DPR baseado na quantidade de ataques: num_ataques + ataques extras)
            qtd_dados_extras_min = 0
            max_dados_extras = 0
            if ficha.nivel_na_classe("Caçador") >= 1:
                nv_cac_m = ficha.nivel_na_classe("Caçador")
                qtd_dados_extras_min += 1
                max_dados_extras += (8 if nv_cac_m >= 13 else (6 if nv_cac_m >= 5 else 4))
            if ficha.nivel_na_classe("Ladino") >= 1:
                d_furt = (ficha.nivel_na_classe("Ladino") + 1) // 2
                qtd_dados_extras_min += d_furt
                max_dados_extras += d_furt * 6
            if ficha.nivel_na_classe("Paladino") >= 1:
                qtd_dados_extras_min += 1
                max_dados_extras += 8
            if ficha.possui_poder("Espada Solar") and not eh_dist:
                qtd_dados_extras_min += 1
                max_dados_extras += 6

            dano_min_golpe = int(qtd_d + fixo_dano + qtd_dados_extras_min)
            dano_max_golpe = int((qtd_d * faces_d) + fixo_dano + max_dados_extras)
            dano_medio_arma = round((dano_max_golpe + dano_min_golpe) / 2.0, 1)

            # Dano Crítico Mínimo, Máximo e Médio = (Crít Máx + Crít Mín) / 2
            dano_crit_min = int((qtd_d * mult_crit) + fixo_dano + qtd_dados_extras_min)
            dano_crit_max = int((qtd_d * mult_crit * faces_d) + fixo_dano + max_dados_extras)
            dano_crit_medio = round((dano_crit_max + dano_crit_min) / 2.0, 1)

            # Dano Médio por Golpe Ponderado pela Chance de Crítico e DPR por Rodada (baseado em num_ataques)
            dano_esperado_golpe_crit = round((1.0 - chance_ameaca_d20) * dano_medio_arma + chance_ameaca_d20 * dano_crit_medio, 1)
            dpr_normal_ataques = round(dano_medio_arma * num_ataques, 1)
            dpr_crit_ataques = round(dano_esperado_golpe_crit * num_ataques, 1)
            dpr_potencial_rodada = round(dpr_crit_ataques + dano_extra_secundario, 1)

            str_crit_info = (
                f"Crítico {margem_crit}/x{mult_crit} ({int(chance_ameaca_d20*100)}% no d20: "
                f"Crít Mín {dano_crit_min} | Crít Máx {dano_crit_max} | Crít Médio (Máx+Mín)/2: {dano_crit_medio:.1f})"
            )
            str_extras_atq = f" + [{' + '.join(detalhes_ataques_extras)}]" if detalhes_ataques_extras else ""
            desc_dano_arma = (
                f"{a.nome} [{estilo}] — Ataque {bonus_atk:+d} [Base 0 PM] ({' '.join(partes_atk)}) | "
                f"Dano Normal: {' '.join(partes_dano)} [Mín: {dano_min_golpe} | Máx: {dano_max_golpe} | Méd (Máx+Mín)/2: {dano_medio_arma:.1f}] | "
                f"{str_crit_info} | "
                f"Por Rodada ({int(num_ataques)} atq arma): DPR Normal {dpr_normal_ataques:.1f}/rod | DPR c/ Crít {dpr_crit_ataques:.1f}/rod"
                f"{str_extras_atq} ➔ DPR Total c/ Combos: {dpr_potencial_rodada:.1f}/rodada"
            )

        # 4. Decomposição Auditável (Linha a Linha) do Score MCTS e Fatores de Decisão
        arq = (ficha.relatorio_ia.arquetipo_alvo or "Dano Marcial").lower()
        parcelas_score: List[Tuple[str, str, float]] = []

        if "tanque" in arq or "defesa" in arq:
            pts_pv = round(ficha.pv_maximos * 2.2, 1)
            pts_def = round((ficha.defesa_total - 10) * 14.0, 1)
            pts_fort = round(ficha.bonus_pericias.get("Fortitude", 0) * 5.0, 1)
            pts_vont = round(ficha.bonus_pericias.get("Vontade", 0) * 3.5, 1)
            parcelas_score.append(("Sobrevivência (PV Máximos)", f"{ficha.pv_maximos} PV × peso 2.2", pts_pv))
            parcelas_score.append(("Mitigação & Couraça (Defesa)", f"({ficha.defesa_total} - 10) Def × peso 14.0", pts_def))
            parcelas_score.append(("Resiliência Física (Fortitude)", f"Bônus +{ficha.bonus_pericias.get('Fortitude', 0)} × peso 5.0", pts_fort))
            parcelas_score.append(("Resiliência Mental (Vontade)", f"Bônus +{ficha.bonus_pericias.get('Vontade', 0)} × peso 3.5", pts_vont))
            pts_pod = 0.0
            nomes_p_sin = []
            for p in ficha.todos_os_poderes():
                ef = (p.nome + " " + p.efeito_resumo).lower()
                g = 24.0 if any(k in ef for k in ("defesa", "redução de dano", "rd", "pv", "escudo", "armadura", "resistência", "encouraçado", "inexpugnável", "esquiva", "vitalidade", "torre")) else 6.0
                pts_pod += g
                nomes_p_sin.append(f"{p.nome} (+{g:.0f})")
            parcelas_score.append(("Sinergia Defensiva dos Poderes", ", ".join(nomes_p_sin) or "Nenhum poder", round(pts_pod, 1)))

        elif "arcano" in arq or "conjurador" in arq:
            pts_pm = round(ficha.pm_maximos * 3.0, 1)
            pts_cd = round((ficha.cd_magias - 10) * 18.0, 1)
            pts_atr = round(max(atr.INT, atr.CAR) * 14.0, 1)
            pts_lim = round(limite_pm * 9.5, 1)
            pts_burst = round(maior_dano_magia * 2.8, 1)
            pts_raio = round(dano_medio_raio * 3.2, 1)
            nm_b = melhor_magia_info[0] if melhor_magia_info else "N/A"
            parcelas_score.append(("Dano Explosivo de Magia (Aprimorada)", f"{nm_b}: média {maior_dano_magia:.1f} × peso 2.8", pts_burst))
            parcelas_score.append(("Dano Sustentado 0 PM (Raio Arcano)", f"Média {dano_medio_raio:.1f}/rod × peso 3.2", pts_raio))
            parcelas_score.append(("Teto de Conjuração (Limite PM/Magia)", f"{limite_pm} PM/magia × peso 9.5", pts_lim))
            parcelas_score.append(("Dificuldade de Resistência (CD Magia)", f"({ficha.cd_magias} - 10) CD × peso 18.0", pts_cd))
            parcelas_score.append(("Reserva de Mana (PM Máximos)", f"{ficha.pm_maximos} PM × peso 3.0", pts_pm))
            parcelas_score.append(("Atributo-Chave de Conjuração", f"Mod +{max(atr.INT, atr.CAR)} × peso 14.0", pts_atr))
            pts_pod = 0.0
            nomes_p_sin = []
            for p in ficha.todos_os_poderes():
                nl = p.nome.lower()
                g = 48.0 if nl in ("magia acelerada", "magia ilimitada", "arcano de batalha") else (32.0 if nl in ("fortalecimento arcano", "raio arcano", "raio elemental", "raio poderoso", "poder mágico", "foco em magia", "prestidigitação") else (22.0 if nl in ("vontade de ferro", "bênção do mana", "conhecimento mágico", "magia pungente", "aumento de atributo") else 4.0))
                pts_pod += g
                nomes_p_sin.append(f"{p.nome} (+{g:.0f})")
            parcelas_score.append(("Sinergia Arcana dos Poderes", ", ".join(nomes_p_sin) or "Nenhum poder", round(pts_pod, 1)))

        elif "suporte" in arq or "divino" in arq:
            pts_pm = round(ficha.pm_maximos * 2.6, 1)
            pts_pv = round(ficha.pv_maximos * 1.4, 1)
            pts_def = round((ficha.defesa_total - 10) * 8.0, 1)
            pts_sab = round(atr.SAB * 12.0, 1)
            pts_mag = sum(m.circulo * 15.0 + (12.0 if any(k in m.efeito_e_aprimoramentos.lower() for k in ("cura", "pv", "aliados", "bônus", "condição")) else 0.0) for m in ficha.magias_conhecidas)
            parcelas_score.append(("Reserva de Mana Divina (PM)", f"{ficha.pm_maximos} PM × peso 2.6", pts_pm))
            parcelas_score.append(("Sabedoria & Fé (Atrib. Chave)", f"SAB +{atr.SAB} × peso 12.0", pts_sab))
            parcelas_score.append(("Sustentação na Linha de Frente (PV/Def)", f"{ficha.pv_maximos} PV (×1.4) + Def ({ficha.defesa_total}-10)×8.0", round(pts_pv + pts_def, 1)))
            parcelas_score.append(("Grimório de Cura & Buffs", f"{len(ficha.magias_conhecidas)} magias divinas", round(pts_mag, 1)))
            pts_pod = 0.0
            nomes_p_sin = []
            for p in ficha.todos_os_poderes():
                nl = p.nome.lower()
                ef = (p.nome + " " + p.efeito_resumo).lower()
                g = 46.0 if nl in ("magia acelerada", "prece de combate", "magia ilimitada", "magia natural") else (26.0 if any(k in ef for k in ("cura", "aliado", "pm", "defesa", "orar", "fé", "sagrado", "vontade", "magia", "círculo")) else 6.0)
                pts_pod += g
                nomes_p_sin.append(f"{p.nome} (+{g:.0f})")
            parcelas_score.append(("Sinergia de Suporte dos Poderes", ", ".join(nomes_p_sin) or "Nenhum poder", round(pts_pod, 1)))

        else:
            pts_dpr = round(dano_medio_arma * 4.2, 1)
            melhor_atq = max(ficha.bonus_pericias.get("Luta", 0), ficha.bonus_pericias.get("Pontaria", 0))
            pts_atq = round(melhor_atq * 8.0, 1)
            pts_pv = round(ficha.pv_maximos * 1.5, 1)
            pts_pm = round(ficha.pm_maximos * 1.5, 1)
            pts_def = round((ficha.defesa_total - 10) * 6.0, 1)
            parcelas_score.append(("Dano Médio por Rodada (DPR Arma)", f"{dano_medio_arma:.1f} dano/rod × peso 4.2", pts_dpr))
            parcelas_score.append(("Precisão de Ataque (Luta/Pontaria)", f"Bônus +{melhor_atq} × peso 8.0", pts_atq))
            parcelas_score.append(("Vigor & Fôlego de Combate (PV + PM)", f"{ficha.pv_maximos} PV (×1.5) + {ficha.pm_maximos} PM (×1.5)", round(pts_pv + pts_pm, 1)))
            parcelas_score.append(("Estabilidade Defensiva (Defesa)", f"({ficha.defesa_total} - 10) Def × peso 6.0", pts_def))
            info_nat_aud = ficha.obter_info_arma_natural_extra()
            if info_nat_aud:
                for_aud = max(0, atr.FOR) + (2 if ficha.possui_poder("Sangue de Ferro") else 0) + (2 if ficha.possui_poder("Valentão") else 0)
                d_med_nat_aud = round(info_nat_aud["media_dado_crit"] + for_aud, 1)
                pts_nat = round(d_med_nat_aud * 4.2, 1)
                parcelas_score.append((f"{info_nat_aud['icone']} Ataque Extra: {info_nat_aud['nome_curto']} ({info_nat_aud['pagina']})", f"1 PM ao Agredir ➔ +1 atq ({info_nat_aud['dado_str']}+{for_aud} = +{d_med_nat_aud} méd. × 4.2)", pts_nat))
            if ficha.possui_poder("Golpe Pessoal"):
                parcelas_score.append(("☄️ Poder de Guerreiro: Golpe Pessoal Otimizado (p. 66–67)", ficha.config_golpe_pessoal, 38.0))
            pts_pod = 0.0
            nomes_p_sin = []
            for p in ficha.todos_os_poderes():
                nl = p.nome.lower()
                g = 38.0 if nl == "golpe pessoal" else (28.0 if nl in ("estilo de duas mãos", "ataque poderoso", "destruidor", "ataque pesado", "trespassar", "valentão", "especialização em arma", "foco em arma", "empunhadura poderosa", "aumento de atributo", "estilo de disparo", "arqueiro", "disparo rápido", "disparo preciso", "mira apurada", "sangue de ferro", "armas da ambição", "espada justiceira", "fúria divina", "presas primordiais") else 6.0)
                pts_pod += g
                nomes_p_sin.append(f"{p.nome} (+{g:.0f})")
            parcelas_score.append(("Sinergia Marcial dos Poderes (Classe, Origem & Devoção)", ", ".join(nomes_p_sin) or "Nenhum poder", round(pts_pod, 1)))

        if ficha.validacoes_csp:
            pen_csp = -200.0 * len(ficha.validacoes_csp)
            parcelas_score.append(("Penalidade por Violação CSP", f"{len(ficha.validacoes_csp)} violação(ões) × -200.0", pen_csp))
        else:
            parcelas_score.append(("Consistência de Regras CSP", "0 violações (Pré-requisitos & Proficiências 100% OK)", 0.0))

        return {
            "limite_pm": limite_pm,
            "str_limite_pm": str_limite_pm,
            "dano_medio_raio": round(dano_medio_raio, 1),
            "desc_raio": desc_raio,
            "maior_dano_magia": round(maior_dano_magia, 1),
            "melhor_magia_info": melhor_magia_info,
            "detalhes_magias": detalhes_magias,
            "dano_medio_arma": dano_medio_arma,
            "desc_dano_arma": desc_dano_arma,
            "parcelas_score": parcelas_score,
            "economia_acoes": economia_acoes_resumo,
        }

