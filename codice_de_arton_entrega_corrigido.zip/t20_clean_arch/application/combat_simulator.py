# -*- coding: utf-8 -*-
from __future__ import annotations

import abc
import base64
import copy
import dataclasses
import datetime
from datetime import datetime as dt_cls
import gzip
import hashlib
import zlib
import functools
import html
import http.server
import inspect
import io
import json
import lzma
import math
import os
import pathlib
from pathlib import Path
import random
import re
import socketserver
import sqlite3
import statistics
import string
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import typing
import urllib.parse
import urllib.request
import uuid
import webbrowser
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import (
    Any, Callable, Dict, Generic, Iterable, Iterator, List,
    Literal, Mapping, NamedTuple, Optional, Protocol, Sequence,
    Set, Tuple, Type, TypeVar, Union
)

"""
Camada de Aplicação — Codificador Tensorial, Simulador de Combate Tático T20 (2d20 max) e Ambiente POMDP Caixa-Preta RL.
"""
from ..domain import *
from .calculators_decorators import *
from .csp_specifications import *
from .synergy_damage_analyzer import *

class CodificadorFichaTensor:
    """
    [SOLID SRP] Vetoriza o estado completo de uma `FichaPersonagem` em um tensor/vetor
    numérico normalizado x in R^20 para entrada na Rede de Valor e Política,
    e extrai features de cada Poder candidato para o cálculo do logit P_theta(a|s).
    """
    DIMENSAO_ESTADO: int = 20

    @classmethod
    def transformar_ficha(cls, ficha: FichaPersonagem) -> List[float]:
        atr = ficha.atributos_finais
        res_dano = AnalisadorSinergiaEDanoT20.calcular_resumo_dano_ficha(ficha)
        natureza = ficha.natureza_personagem()
        estilo = AnalisadorSinergiaEDanoT20.identificar_estilo_arma(ficha)
        poderes = ficha.todos_os_poderes()

        vetor = [
            atr.FOR / 10.0,
            atr.DES / 10.0,
            atr.CON / 10.0,
            atr.INT / 10.0,
            atr.SAB / 10.0,
            atr.CAR / 10.0,
            ficha.nivel / 20.0,
            ficha.pv_maximos / 150.0,
            ficha.pm_maximos / 100.0,
            (ficha.defesa_total - 10) / 25.0,
            (ficha.cd_magias - 10) / 20.0,
            res_dano["limite_pm"] / 25.0,
            res_dano["dano_medio_arma"] / 80.0,
            res_dano["dano_medio_raio"] / 40.0,
            res_dano["maior_dano_magia"] / 100.0,
            1.0 if natureza == "Marcial" else 0.0,
            1.0 if natureza == "Conjurador" else 0.0,
            1.0 if estilo == "DUAS_MAOS" else (0.5 if estilo == "ARQUERIA_DISPARO" else 0.0),
            len(poderes) / 10.0,
            len(ficha.magias_conhecidas) / 10.0,
        ]
        return [round(float(x), 4) for x in vetor]

    @classmethod
    def extrair_features_acao(cls, ficha: FichaPersonagem, poder: Poder, arquetipo: str) -> List[float]:
        """Extrai 8 features de afinidade estado-ação phi(s, a) para a Cabeça de Política."""
        arq = arquetipo.lower()
        nl = poder.nome.lower()
        ef = (poder.nome + " " + poder.efeito_resumo).lower()
        eh_classe = 1.0 if poder.eh_poder_classe else 0.0
        eh_ofensivo_marcial = 1.0 if nl in (
            "golpe pessoal", "empunhadura poderosa", "estilo de duas mãos", "ataque poderoso", "destruidor",
            "ataque pesado", "trespassar", "valentão", "especialização em arma", "foco em arma",
            "estilo de disparo", "arqueiro", "disparo rápido", "disparo preciso", "mira apurada"
        ) else 0.0
        eh_ofensivo_arcano = 1.0 if nl in (
            "magia ilimitada", "arcano de batalha", "raio arcano", "raio elemental", "raio poderoso",
            "fortalecimento arcano", "foco em magia", "poder mágico", "magia acelerada"
        ) else 0.0
        eh_defensivo = 1.0 if any(k in ef for k in ("defesa", "redução de dano", "rd", "encouraçado", "inexpugnável", "vitalidade", "esquiva", "torre", "escudo")) else 0.0
        eh_mana_suporte = 1.0 if any(k in ef for k in ("pm", "mana", "cura", "vontade de ferro", "bênção do mana", "orar")) else 0.0
        eh_aumento_atrib = 1.0 if nl == "aumento de atributo" else 0.0

        alinhamento_arq = 0.2
        if "arcano" in arq and (eh_ofensivo_arcano or eh_aumento_atrib or eh_mana_suporte):
            alinhamento_arq = 1.0
        elif ("tanque" in arq or "defesa" in arq) and (eh_defensivo or eh_aumento_atrib):
            alinhamento_arq = 1.0
        elif ("suporte" in arq or "divino" in arq) and (eh_mana_suporte or eh_defensivo or eh_aumento_atrib):
            alinhamento_arq = 1.0
        elif ("dano" in arq or "marcial" in arq or "arqueiro" in arq) and (eh_ofensivo_marcial or eh_aumento_atrib):
            alinhamento_arq = 1.0

        return [
            eh_classe,
            eh_ofensivo_marcial,
            eh_ofensivo_arcano,
            eh_defensivo,
            eh_mana_suporte,
            eh_aumento_atrib,
            alinhamento_arq,
            1.0,  # bias
        ]


class SimuladorCombateT20:
    """
    [SOLID SRP] Simulador de Combate Monte Carlo e Analisador de Tomada de Decisão Tática
    fundamentado na Tabela Oficial de Estatísticas de Ameaças de Tormenta20 (página 323 do livro /
    página 329 do PDF e Manual de Criação de Ameaças).
    - Exibe as estatísticas médias exatas da criatura nos 3 papéis oficiais (Solo, Lacaio e Especial);
    - Calcula a Matriz da Melhor Tomada de Decisões em Combate (Ação Livre/Movimento, Ação Padrão
      Ofensiva e Reação Defensiva) pelo Valor Esperado de Dano/Mitigação contra a Defesa/Resistência da criatura;
    - Detalha turno a turno cada ação tomada, rolagem e cálculo exato da porcentagem de vitória.
    """
    @classmethod
    def simular(cls, ficha: FichaPersonagem, episodios: int = 25) -> RelatorioSimulacaoCombate:
        nd = max(1, min(20, ficha.nivel))
        ameaca_solo = obter_estatisticas_ameaca_oficial(nd, "Solo")
        ameaca_lac = obter_estatisticas_ameaca_oficial(nd, "Lacaio")
        ameaca_esp = obter_estatisticas_ameaca_oficial(nd, "Especial")

        pv_grupo4_solo = ameaca_solo.pv
        pv_inimigo_max = max(25, int(round(ameaca_solo.pv * 0.35)))
        def_inimigo = ameaca_solo.defesa
        atq_inimigo = ameaca_solo.bonus_ataque
        dano_base_inimigo = max(6, int(round(ameaca_solo.dano_medio * 0.50)))
        res_inimigo = ameaca_solo.res_media
        nome_ameaca = f"Ameaça Oficial p.323 — {ameaca_solo.patamar} (ND {nd} Solo)"

        res_dano = AnalisadorSinergiaEDanoT20.calcular_resumo_dano_ficha(ficha)
        eh_conj = ficha.eh_conjurador()
        melhor_mag = res_dano["melhor_magia_info"]
        dano_mag_max = res_dano["maior_dano_magia"]
        custo_mag_max = melhor_mag[1]["pm_gasto"] if melhor_mag else 3
        dano_raio = max(res_dano["dano_medio_raio"], 4.5 * max(1, ficha.circulo_maximo_permitido()) if eh_conj else 0.0)
        dano_arma = max(res_dano["dano_medio_arma"], 6.5 + max(0, ficha.atributos_finais.FOR))
        melhor_per_atq = max(ficha.bonus_pericias.get("Luta", 0), ficha.bonus_pericias.get("Pontaria", 0))
        m_atq_real = re.search(r"Ataque\s*([+-]?\d+)", res_dano.get("desc_dano_arma", ""))
        if m_atq_real:
            melhor_per_atq = int(m_atq_real.group(1))
        nome_arma_eq = ficha.arma_equipada.nome if ficha.arma_equipada else "Ataque Desarmado"
        estilo_atual = AnalisadorSinergiaEDanoT20.identificar_estilo_arma(ficha)

        # Probabilidades reais contra a Ameaça Solo Oficial (p. 323)
        # Se for Guerreiro, considera o bônus de Ataque Especial ativo (+4 a +20 no ataque) na decisão principal!
        bonus_ae_atq_sim = (4 * (1 + (ficha.nivel - 1) // 4)) if (ficha.classe and ficha.classe.nome.lower() == "guerreiro") else 0
        atq_efetivo_decisao = melhor_per_atq + bonus_ae_atq_sim
        alvos_d20_acerto = max(1, min(19, 21 - (def_inimigo - atq_efetivo_decisao)))
        prob_acerto_arma = round((alvos_d20_acerto / 20.0) * 100.0, 1)
        ev_dano_arma = round(dano_arma * (prob_acerto_arma / 100.0) * 1.08, 1)

        # Para magias: inimigo rola d20 + Res_Média >= CD_Magia para reduzir à metade (50%)
        alvos_d20_inimigo_passa = max(1, min(19, 21 - (ficha.cd_magias - res_inimigo)))
        prob_inimigo_falha_res = round(((20 - alvos_d20_inimigo_passa) / 20.0) * 100.0, 1)
        fator_esperado_magia = (prob_inimigo_falha_res / 100.0) * 1.0 + ((100.0 - prob_inimigo_falha_res) / 100.0) * 0.5
        ev_dano_magia = round(dano_mag_max * fator_esperado_magia, 1) if melhor_mag else 0.0
        ev_dano_raio = round(dano_raio * fator_esperado_magia, 1) if dano_raio > 0 else 0.0

        # Sistema Oficial de Iniciativa e Surpresa (Capítulo 5, p. 230-231 / PDF p. 236-237)
        bonus_ini_heroi = ficha.bonus_pericias.get("Iniciativa", ficha.nivel // 2 + ficha.atributos_finais.DES)
        bonus_ini_ameaca = (nd // 2) + (2 if nd <= 6 else (4 if nd <= 14 else 6)) + (1 if ameaca_solo.papel == "Solo" else 2)
        diff_ini = bonus_ini_heroi - bonus_ini_ameaca
        prob_vencer_ini = round(max(5.0, min(95.0, 52.5 + diff_ini * 4.5)), 1)
        resumo_ini_str = (
            f"Herói Iniciativa {bonus_ini_heroi:+d} vs. Ameaça Iniciativa {bonus_ini_ameaca:+d} "
            f"(Chance do Herói agir primeiro: {prob_vencer_ini:.1f}%). "
            f"Regra Cap. 5 (p. 230): Quem age antes na 1ª rodada encontra o oponente DESPREVENIDO (-5 na Defesa e em Reflexos até o 1º turno dele)!"
        )
        limiar_morte = -max(10, ficha.pv_maximos // 2)
        regra_ferimentos_str = (
            f"Com 0 PV ou menos: fica Inconsciente e Sangrando (teste de CON CD 15 por turno; falha perde 1d6 PV). "
            f"Morte Instantânea se atingir {limiar_morte} PV (metade dos PV máximos negativos — Livro p. 235-236)."
        )

        # Redução de dano e Reações Defensivas disponíveis (incluindo Armadura Óssea RD 5 do Osteon e Sangue de Ferro RD 5!)
        rd_estimada = 0
        reacao_nome = "Defesa & Testes de Resistência Passivos da Ficha (0 PM — Livro p. 233)"
        if ficha.raca and ficha.raca.nome.lower() == "osteon":
            rd_estimada += 5
        if ficha.possui_poder("Sangue de Ferro"):
            rd_estimada += 5
        reacao_custo = 0
        if ficha.possui_poder("Encouraçado"):
            rd_estimada += 2
        nomes_magias_low = [m.nome.lower() for m in ficha.magias_conhecidas]
        nc_reac = ficha.classe.nome.lower() if ficha.classe else ""
        if any("campo de força" in nm for nm in nomes_magias_low) and any("armadura arcana" in nm for nm in nomes_magias_low):
            rd_estimada += 18
            reacao_nome = "Reações da Ficha: 'Armadura Arcana' (Reação, 2 PM: +5 Defesa, p. 179) OU 'Campo de Força' (Reação, 4 PM: RD 30, p. 182)"
            reacao_custo = 2
        elif any("campo de força" in nm for nm in nomes_magias_low):
            rd_estimada += 15
            reacao_nome = "Magia da Ficha: 'Campo de Força' (Aprimoramento Reação, 4 PM: RD 30 contra o próximo dano, p. 182)"
            reacao_custo = 4
        elif any("armadura arcana" in nm for nm in nomes_magias_low):
            rd_estimada += 9
            reacao_nome = "Magia da Ficha: 'Armadura Arcana' (Aprimoramento Reação, 2 PM: +5 na Defesa contra o ataque, p. 179)"
            reacao_custo = 2
        elif any("salto dimensional" in nm for nm in nomes_magias_low):
            rd_estimada += 10
            reacao_nome = "Magia da Ficha: 'Salto Dimensional' (Aprimoramento Reação, 4 PM: +5 na Defesa/Reflexos e salta 1,5m, p. 205)"
            reacao_custo = 4
        elif any("escudo da fé" in nm for nm in nomes_magias_low) or any("proteção divina" in nm for nm in nomes_magias_low):
            rd_estimada += 7
            reacao_nome = "Magia da Ficha: 'Escudo da Fé' (Reação, 1 PM: +2 Defesa, p. 191) / 'Proteção Divina' (Reação, 1 PM: +2 Resistências, p. 201)"
            reacao_custo = 1
        elif nc_reac == "guerreiro" and ficha.nivel >= 3:
            rd_estimada += int(dano_base_inimigo * 0.40)
            reacao_nome = "Habilidade de Classe: 'Durão' (Reação, 3 PM: reduz o dano sofrido à metade, p. 65)"
            reacao_custo = 3
        elif ficha.possui_poder("Rolamento Defensivo"):
            rd_estimada += int(dano_base_inimigo * 0.40)
            reacao_nome = "Poder da Ficha: 'Rolamento Defensivo' (Reação, 2 PM: reduz o dano sofrido à metade, p. 74)"
            reacao_custo = 2
        elif ficha.possui_poder("Aparar"):
            rd_estimada += int(dano_base_inimigo * 0.35)
            reacao_nome = "Poder da Ficha: 'Aparar' (Reação, 1 PM: teste de ataque oposto para evitar o ataque inimigo, p. 51)"
            reacao_custo = 1
        elif nc_reac == "cavaleiro":
            b_bal = 2 + 2 * ((ficha.nivel - 1) // 4)
            rd_estimada += 6 + b_bal
            reacao_nome = f"Habilidade de Classe: 'Baluarte' (Reação, 1 PM: +{b_bal} na Defesa e nos Testes de Resistência, p. 56)"
            reacao_custo = 1
        elif nc_reac == "nobre":
            rd_estimada += 6
            reacao_nome = "Habilidade de Classe: 'Orgulho' (Reação ao fazer teste, 2 PM: +4 em Resistência, p. 79)"
            reacao_custo = 2
        elif ficha.possui_poder("Sortudo"):
            rd_estimada += 5
            reacao_nome = "Poder da Ficha: 'Sortudo' (Reação, 3 PM: rola novamente um teste recém-realizado, p. 129)"
            reacao_custo = 3

        # Ação Livre / Movimento Ótima (Setup no Turno)
        setup_nome = "Posicionamento Tático & Engajamento (Ação de Movimento)"
        setup_custo = 0
        setup_just = "Mantém distância ideal do estilo de combate sem custo de PM."
        if ficha.classe:
            nc_low = ficha.classe.nome.lower()
            if nc_low == "guerreiro":
                esc_esp = 4 * (1 + (ficha.nivel - 1) // 4)
                custo_esp = 1 + (ficha.nivel - 1) // 4
                str_gp_s = f" + Golpe Pessoal ({ficha.config_golpe_pessoal})" if ficha.possui_poder("Golpe Pessoal") else ""
                info_nat_s = ficha.obter_info_arma_natural_extra()
                str_ch_s = f" + Ataque Extra {info_nat_s['nome_curto']} (1 PM: {info_nat_s['dado_str']}+FOR)" if info_nat_s else ""
                setup_nome = f"Ataque Especial ({custo_esp} PM: +{esc_esp} no Ataque OU +{esc_esp} no Dano OU +{esc_esp//2} Atq/+{esc_esp//2} Dano, p. 65){str_gp_s}{str_ch_s}"
                setup_custo = custo_esp + (1 if ficha.possui_arma_natural_extra() else 0)
                setup_just = f"No Ataque Especial (p. 65), o Guerreiro escolhe aplicar +{esc_esp} no Ataque, +{esc_esp} no Dano ou dividir +{esc_esp//2}/+{esc_esp//2} naquele ataque."
            elif nc_low == "bárbaro":
                setup_nome = "Fúria (+2 Ataque e +2 Dano corpo a corpo pela cena)"
                setup_custo = 2
                setup_just = "Aumenta precisão e letalidade em todos os turnos do combate."
            elif nc_low == "paladino":
                setup_nome = "Golpe Divino (+1d8 a +2d8 Dano e +CAR no Ataque)"
                setup_custo = 2
                setup_just = "Converte Carisma em precisão imediata para superar a Defesa da ameaça."
            elif nc_low == "caçador":
                setup_nome = "Marca da Presa (+1d4 a +1d8 Dano extra contra a ameaça)"
                setup_custo = 1
                setup_just = "Multiplica o dano em cada ataque disparado ou desferido na rodada."
            elif eh_conj:
                atrib_sig, _ = ficha.obter_atributo_chave_magia()
                val_atr = max(0, ficha.atributos_finais.obter(atrib_sig))
                partes_s = []
                if ficha.possui_poder("Magia Ilimitada"):
                    partes_s.append(f"Magia Ilimitada (Limite PM +{val_atr})")
                if ficha.possui_poder("Arcano de Batalha"):
                    partes_s.append(f"Arcano de Batalha (+{val_atr} dano fixo)")
                if ficha.possui_poder("Foco em Magia"):
                    partes_s.append("Foco em Magia (-1 PM)")
                setup_nome = " + ".join(partes_s) if partes_s else f"Canalização Mágica ({atrib_sig} +{val_atr})"
                setup_custo = 0
                setup_just = f"Maximiza o teto de aprimoramento da magia ({res_dano['limite_pm']} PM) e a CD ({ficha.cd_magias})."

        # Constrói a Matriz de Tomada de Decisões Táticas em Combate
        matriz_decisoes: List[OpcaoDecisaoCombate] = [
            OpcaoDecisaoCombate(
                ordem_prioridade=1,
                tipo_acao="1. Ação Livre / Movimento (Setup)",
                nome_acao=setup_nome,
                custo_pm=setup_custo,
                chance_sucesso_pct=100.0,
                dano_ou_mitigacao_bruto=float(ficha.atributos_finais.obter(ficha.obter_atributo_chave_magia()[0])) if eh_conj else 4.0,
                valor_esperado_efetivo=float(ficha.atributos_finais.obter(ficha.obter_atributo_chave_magia()[0])) if eh_conj else 4.0,
                veredito_tatico="⚡ BUFF / SETUP ÓTIMO",
                justificativa=setup_just,
            )
        ]

        usa_magia_principal = bool(eh_conj and melhor_mag and ev_dano_magia >= ev_dano_arma)
        if melhor_mag:
            nm_m, inf_m = melhor_mag
            matriz_decisoes.append(OpcaoDecisaoCombate(
                ordem_prioridade=2 if usa_magia_principal else 3,
                tipo_acao="2. Ação Padrão (Magia Aprimorada)",
                nome_acao=f"Lançar '{nm_m}' no Limite ({inf_m['formula_final']})",
                custo_pm=custo_mag_max,
                chance_sucesso_pct=prob_inimigo_falha_res,
                dano_ou_mitigacao_bruto=dano_mag_max,
                valor_esperado_efetivo=ev_dano_magia,
                veredito_tatico="★ MELHOR DECISÃO PRINCIPAL (MAIOR EV)" if usa_magia_principal else "○ OPÇÃO SECUNDÁRIA",
                justificativa=f"CD {ficha.cd_magias} vs Res. Média +{res_inimigo} ({prob_inimigo_falha_res:.0f}% falha total [100% dano], resto causa 50%) -> EV = {ev_dano_magia:.1f} dano/turno.",
            ))
        if dano_raio > 0:
            matriz_decisoes.append(OpcaoDecisaoCombate(
                ordem_prioridade=3,
                tipo_acao="2. Ação Padrão (Sustentação 0 PM)",
                nome_acao=f"Combo Raio Arcano ({res_dano['desc_raio'].split('—')[0].strip()})",
                custo_pm=0,
                chance_sucesso_pct=prob_inimigo_falha_res,
                dano_ou_mitigacao_bruto=dano_raio,
                valor_esperado_efetivo=ev_dano_raio,
                veredito_tatico="○ SUSTENTAÇÃO (ECONOMIA 0 PM)",
                justificativa=f"Preserva mana quando PM < {custo_mag_max} causando EV = {ev_dano_raio:.1f} dano/turno a custo zero.",
            ))

        matriz_decisoes.append(OpcaoDecisaoCombate(
            ordem_prioridade=2 if not usa_magia_principal else 4,
            tipo_acao="2. Ação Padrão / Completa (Ataque c/ Arma)",
            nome_acao=f"Atacar com {nome_arma_eq} [{estilo_atual}]",
            custo_pm=setup_custo if not eh_conj else 0,
            chance_sucesso_pct=prob_acerto_arma,
            dano_ou_mitigacao_bruto=dano_arma,
            valor_esperado_efetivo=ev_dano_arma,
            veredito_tatico="★ MELHOR DECISÃO PRINCIPAL (MAIOR EV)" if not usa_magia_principal else "✖ SUBÓTIMO P/ CONJURADOR",
            justificativa=f"Ataque +{melhor_per_atq} vs Defesa {def_inimigo} ({prob_acerto_arma:.0f}% chance de acerto × {dano_arma:.1f} DPR bruto) -> EV = {ev_dano_arma:.1f} dano/turno.",
        ))

        # Opções Específicas: Arma Natural Extra (Chifres do Minotauro p. 25 / Mordida do Trog p. 31 / Presas Primordiais p. 134) e Golpe Pessoal (p. 66-67)
        info_nat_m = ficha.obter_info_arma_natural_extra()
        if info_nat_m and not eh_conj:
            b_luta_ch = ficha.bonus_pericias.get("Luta", melhor_per_atq) + (2 if ficha.possui_poder("Valentão") else 0) + (2 if ficha.possui_poder("Fúria Divina") else 0)
            alvos_ch = max(1, min(19, 21 - ((def_inimigo - 5) - b_luta_ch)))
            prob_ch = round((alvos_ch / 20.0) * 100.0, 1)
            for_ch = max(0, ficha.atributos_finais.FOR) + (2 if ficha.possui_poder("Valentão") else 0) + (2 if ficha.possui_poder("Sangue de Ferro") else 0) + (2 if ficha.possui_poder("Fúria Divina") else 0)
            d_bruto_ch = round(info_nat_m["media_dado_crit"] + for_ch, 1)
            ev_ch = round(d_bruto_ch * (prob_ch / 100.0), 1)
            matriz_decisoes.append(OpcaoDecisaoCombate(
                ordem_prioridade=2,
                tipo_acao=f"2A. Ataque Extra Natural — {info_nat_m['icone']} {info_nat_m['nome_curto']} ({info_nat_m['pagina']})",
                nome_acao=f"{info_nat_m['icone']} Ataque Extra c/ {info_nat_m['nome_curto']} ao Agredir (Ataque {b_luta_ch:+d} | Dano {info_nat_m['dado_str']}+{for_ch} perfuração, crít. 20/x2)",
                custo_pm=1,
                chance_sucesso_pct=prob_ch,
                dano_ou_mitigacao_bruto=d_bruto_ch,
                valor_esperado_efetivo=ev_ch,
                veredito_tatico="★ ATAQUE EXTRA NATURAL (1x/RODADA AO AGREDIR)",
                justificativa=f"{info_nat_m['pagina']}: 1x/rodada ao usar a ação Agredir com outra arma, gasta 1 PM para fazer +1 ataque corpo a corpo extra com {info_nat_m['nome_curto'].lower()} ({info_nat_m['dado_str']}+{for_ch} = {d_bruto_ch} méd., EV=+{ev_ch}).",
            ))
        if ficha.raca and ficha.raca.nome.lower() == "trog":
            cd_mc = 10 + (ficha.nivel // 2) + ficha.atributos_finais.CON
            matriz_decisoes.append(OpcaoDecisaoCombate(
                ordem_prioridade=3,
                tipo_acao="2A-Trog. Habilidade Racial — 🤢 Mau Cheiro (Trog, p. 31)",
                nome_acao=f"🤢 Mau Cheiro (Ação Padrão, 2 PM: Gás fétido alcance curto, Fortitude CD {cd_mc} ou Enjoado por 1d6 rodadas)",
                custo_pm=2,
                chance_sucesso_pct=65.0,
                dano_ou_mitigacao_bruto=12.0,
                valor_esperado_efetivo=8.5,
                veredito_tatico="🤢 CONTROLE DE ÁREA RACIAL (ENJOADO: SÓ 1 AÇÃO/TURNO)",
                justificativa=f"Livro p. 31: Inimigos que falhem em Fortitude CD {cd_mc} ficam Enjoados (só podem realizar 1 ação padrão OU de movimento por rodada).",
            ))

        if ficha.possui_poder("Golpe Pessoal") and not eh_conj:
            prob_preciso = round((1.0 - ((20.0 - alvos_d20_acerto) / 20.0) ** 2) * 100.0, 1)
            d_bruto_gp = round(dano_arma * 0.65 + 11.5, 1)
            ev_gp = round(d_bruto_gp * (prob_preciso / 100.0), 1)
            matriz_decisoes.append(OpcaoDecisaoCombate(
                ordem_prioridade=2,
                tipo_acao="2A-II. Poder de Guerreiro — ☄️ Golpe Pessoal (p. 66–67)",
                nome_acao=f"☄️ Golpe Pessoal c/ {nome_arma_eq}: {ficha.config_golpe_pessoal}",
                custo_pm=min(ficha.nivel, 4),
                chance_sucesso_pct=prob_preciso,
                dano_ou_mitigacao_bruto=d_bruto_gp,
                valor_esperado_efetivo=ev_gp,
                veredito_tatico="★ EXPLOSÃO DE DANO MARCIAL (BURST C/ 2d20)",
                justificativa=f"Combina Brutal (+1 PM: +1 dado da arma), Elemental (+2 PM: +2d6 fogo) e Preciso (+1 PM: rola 2d20 no ataque, elevando o acerto de {prob_acerto_arma:.0f}% para {prob_preciso:.0f}% -> EV={ev_gp:.1f}).",
            ))

        # Opções Táticas do Capítulo 5 (Investida Completa, Manobra Derrubar/Quebrar e Fintar — p. 233-235)
        if not eh_conj:
            prob_acerto_investida = min(95.0, prob_acerto_arma + 10.0)
            ev_investida = round(dano_arma * (prob_acerto_investida / 100.0) * 1.08, 1)
            matriz_decisoes.append(OpcaoDecisaoCombate(
                ordem_prioridade=3,
                tipo_acao="2B. Ação Completa — Investida (Cap. 5, p. 234)",
                nome_acao=f"Investida c/ {nome_arma_eq} (Desloca até {ficha.deslocamento_final*2}m + Ataque c/ +2 Atq e -2 Def)",
                custo_pm=0,
                chance_sucesso_pct=prob_acerto_investida,
                dano_ou_mitigacao_bruto=dano_arma,
                valor_esperado_efetivo=ev_investida,
                veredito_tatico="🐎 ABERTURA / ENGAJAMENTO (TURNO 1)",
                justificativa=f"Avança o dobro do deslocamento ({ficha.deslocamento_final*2}m) e ganha +2 no teste de ataque ({prob_acerto_investida:.0f}% acerto -> EV={ev_investida:.1f}), sofrendo -2 na Defesa até o próximo turno.",
            ))
            chance_manobra = round(max(10.0, min(90.0, 50.0 + (melhor_per_atq - atq_inimigo) * 5.0)), 1)
            matriz_decisoes.append(OpcaoDecisaoCombate(
                ordem_prioridade=4,
                tipo_acao="2C. Manobra de Combate — Derrubar / Quebrar (p. 234)",
                nome_acao="Manobra Derrubar (Alvo Caído: -5 Def corpo a corpo e -5 Atq) ou Quebrar Escudo/Arma",
                custo_pm=1 if ficha.possui_poder("Ataque Pesado") else 0,
                chance_sucesso_pct=chance_manobra,
                dano_ou_mitigacao_bruto=5.0,
                valor_esperado_efetivo=round(5.0 * (chance_manobra / 100.0) * 3.5, 1),
                veredito_tatico="🤸 CONTROLE FÍSICO (TESTE OPOSTO DE LUTA)",
                justificativa=f"Teste oposto Luta ({melhor_per_atq:+d}) vs. Luta da Ameaça ({atq_inimigo:+d}): se vencer ({chance_manobra:.0f}%), deixa o inimigo Caído (-5 na Defesa p/ todos os aliados corpo a corpo!).",
            ))

        matriz_decisoes.append(OpcaoDecisaoCombate(
            ordem_prioridade=5,
            tipo_acao="3. Reação Defensiva (Turno da Criatura)",
            nome_acao=reacao_nome,
            custo_pm=reacao_custo,
            chance_sucesso_pct=100.0,
            dano_ou_mitigacao_bruto=float(rd_estimada),
            valor_esperado_efetivo=float(rd_estimada),
            veredito_tatico="🛡️ REAÇÃO DEFENSIVA ÓTIMA",
            justificativa=f"Mitiga em ~{rd_estimada} pts o dano médio da ameaça (Ataque +{atq_inimigo} vs Defesa {ficha.defesa_total}).",
        ))

        melhor_seq_str = (
            f"1º [Livre/Setup] {setup_nome} ({setup_custo} PM) ➔ "
            f"2º [Ação Padrão Ótima] "
            + (f"Lançar '{melhor_mag[0]}' aprimorada ({custo_mag_max} PM, EV={ev_dano_magia:.1f} dano) nos turnos iniciais e alternar para Raio Arcano (0 PM, EV={ev_dano_raio:.1f}) se PM acabar"
               if usa_magia_principal else f"Atacar com {nome_arma_eq} [{estilo_atual}] (Ataque +{melhor_per_atq} vs Def {def_inimigo}, EV={ev_dano_arma:.1f} dano/rod)")
            + f" ➔ 3º [Reação] {reacao_nome}."
        )

        # Simulação Monte Carlo de Episódios e Registro Detalhado Turno a Turno do Episódio #1
        vitorias = 0
        soma_dano_rodada = 0.0
        soma_dano_sofrido_rodada = 0.0
        soma_rodadas = 0.0
        soma_pv_rest = 0.0
        soma_pm_rest = 0.0
        log_exemplo: List[str] = []
        turnos_detalhados: List[PassoTurnoCombate] = []

        rng = random.Random(42 + ficha.nivel + ficha.pv_maximos + ficha.pm_maximos + len(ficha.todos_os_poderes()))

        for ep in range(max(1, episodios)):
            pv_heroi = float(max(1, ficha.pv_maximos))
            pm_heroi = float(ficha.pm_maximos)
            pv_chefe = float(pv_inimigo_max)
            dano_total_ep = 0.0
            dano_sofrido_ep = 0.0
            rodada = 0
            turnos_ep_atual: List[PassoTurnoCombate] = []
            logs_ep_atual: List[str] = []

            ini_h_rol = rng.randint(1, 20) + bonus_ini_heroi
            ini_c_rol = rng.randint(1, 20) + bonus_ini_ameaca
            heroi_venceu_ini = ini_h_rol >= ini_c_rol

            while pv_heroi > 0 and pv_chefe > 0 and rodada < 20:
                rodada += 1
                dano_causado = 0.0
                # No Turno 1, se o herói venceu a Iniciativa, a criatura ainda não agiu e está DESPREVENIDA (-5 na Defesa, Cap. 5 p. 230)!
                def_inimigo_turno = (def_inimigo - 5) if (rodada == 1 and heroi_venceu_ini) else def_inimigo
                tag_desprev = " [Alvo Desprevenido -5 Def (Venceu Iniciativa!)]" if (rodada == 1 and heroi_venceu_ini) else ""
                acao_livre_str = setup_nome if (setup_custo == 0 or pm_heroi >= setup_custo) else "Movimento Tático (0 PM)"
                acao_padrao_str = ""
                rolagem_str = ""

                if eh_conj and melhor_mag and pm_heroi >= custo_mag_max and dano_mag_max > dano_arma:
                    pm_heroi -= custo_mag_max
                    d20_res = rng.randint(1, 20)
                    rolagem_res_inimigo = d20_res + res_inimigo
                    passou_res = rolagem_res_inimigo >= ficha.cd_magias
                    fator_var = rng.uniform(0.92, 1.08)
                    dano_causado = round(dano_mag_max * fator_var * (0.5 if passou_res else 1.0), 1)
                    acao_padrao_str = f"Magia '{melhor_mag[0]}' ({melhor_mag[1]['formula_final']}) [-{custo_mag_max} PM]"
                    rolagem_str = f"Teste Res. Criatura: d20({d20_res})+{res_inimigo}={rolagem_res_inimigo} vs CD {ficha.cd_magias} ({'Passou: 50% dano' if passou_res else 'FALHOU: 100% dano!'})"
                    acao_txt = f"{acao_padrao_str} | {rolagem_str} -> {dano_causado:.1f} dano"
                elif eh_conj and dano_raio > dano_arma:
                    d20_res = rng.randint(1, 20)
                    rolagem_res_inimigo = d20_res + res_inimigo
                    passou_res = rolagem_res_inimigo >= ficha.cd_magias
                    dano_causado = round(dano_raio * rng.uniform(0.92, 1.08) * (0.5 if passou_res else 1.0), 1)
                    acao_padrao_str = "Combo Raio Arcano [0 PM — Sustentação]"
                    rolagem_str = f"Teste Res. Criatura: d20({d20_res})+{res_inimigo}={rolagem_res_inimigo} vs CD {ficha.cd_magias} ({'Passou: 50%' if passou_res else 'FALHOU: 100%!'})"
                    acao_txt = f"{acao_padrao_str} | {rolagem_str} -> {dano_causado:.1f} dano"
                else:
                    # Regra Oficial Ataque Especial (p. 65) + Golpe Pessoal (p. 66) + Chifres do Minotauro (p. 25)
                    nc_turn = ficha.classe.nome.lower() if ficha.classe else ""
                    tem_gp_turn = ficha.possui_poder("Golpe Pessoal") and rodada == 1 and pm_heroi >= 4
                    custo_ae_turn = (1 + (ficha.nivel - 1) // 4) if (nc_turn == "guerreiro" and pm_heroi >= (1 + (ficha.nivel - 1) // 4)) else 0
                    bonus_ae_val = 4 * custo_ae_turn
                    modo_ae_t = (ficha.modo_ataque_especial or "ATAQUE").upper()
                    b_atq_ae = bonus_ae_val if modo_ae_t == "ATAQUE" else (bonus_ae_val // 2 if modo_ae_t == "DIVIDIDO" else 0)
                    b_dano_ae = bonus_ae_val if modo_ae_t == "DANO" else (bonus_ae_val // 2 if modo_ae_t == "DIVIDIDO" else 0)
                    pm_heroi -= custo_ae_turn
                    custo_gp_t = 0
                    if tem_gp_turn and pm_heroi >= 3:
                        custo_gp_t = 3
                        pm_heroi -= custo_gp_t

                    d20_a = rng.randint(1, 20)
                    if tem_gp_turn:
                        d20_b = rng.randint(1, 20)
                        dado_d20 = max(d20_a, d20_b)
                        str_d20_t = f"2d20({d20_a},{d20_b}➔{dado_d20} Preciso)"
                    else:
                        dado_d20 = d20_a
                        str_d20_t = f"d20({dado_d20})"

                    total_atq = dado_d20 + melhor_per_atq + b_atq_ae
                    acertou = (dado_d20 == 20) or (dado_d20 != 1 and total_atq >= def_inimigo_turno)
                    critico = acertou and (dado_d20 >= 19)
                    tags_gasto = []
                    if custo_ae_turn:
                        tags_gasto.append(f"Ataque Especial -{custo_ae_turn} PM: +{b_atq_ae} Atq / +{b_dano_ae} Dano")
                    if custo_gp_t:
                        tags_gasto.append(f"Golpe Pessoal -{custo_gp_t} PM: Brutal+Elemental+Preciso")
                    acao_padrao_str = f"Agredir c/ {nome_arma_eq} [{estilo_atual}]" + (f" ({' | '.join(tags_gasto)})" if tags_gasto else "")
                    if acertou:
                        mult = 1.45 if critico else 1.0
                        dano_golpe_p = round((dano_arma * 0.72) * mult * rng.uniform(0.94, 1.06) + b_dano_ae + (10.5 if custo_gp_t else 0.0), 1)
                        dano_causado += dano_golpe_p
                        rolagem_str = f"{str_d20_t}+{melhor_per_atq + b_atq_ae}={total_atq} vs Def {def_inimigo_turno}{tag_desprev} ({'CRÍTICO!' if critico else 'ACERTOU!'}: {dano_golpe_p:.1f} dano)"
                    else:
                        rolagem_str = f"{str_d20_t}+{melhor_per_atq + b_atq_ae}={total_atq} vs Def {def_inimigo_turno}{tag_desprev} (ERROU)"

                    # Ataque Extra Natural: Chifres (Minotauro p. 25) ou Mordida (Trog p. 31 / Presas Primordiais p. 134)
                    info_nat_t = ficha.obter_info_arma_natural_extra()
                    if info_nat_t and pm_heroi >= 1:
                        pm_heroi -= 1
                        d20_ch = rng.randint(1, 20)
                        b_luta_ch = ficha.bonus_pericias.get("Luta", melhor_per_atq) + (2 if ficha.possui_poder("Valentão") else 0) + (2 if ficha.possui_poder("Fúria Divina") else 0)
                        fixo_dano_ch = max(0, ficha.atributos_finais.FOR) + (2 if ficha.possui_poder("Valentão") else 0) + (2 if ficha.possui_poder("Sangue de Ferro") else 0) + (2 if ficha.possui_poder("Fúria Divina") else 0)
                        tot_ch = d20_ch + b_luta_ch
                        acertou_ch = (d20_ch == 20) or (d20_ch != 1 and tot_ch >= def_inimigo_turno)
                        ico_n = info_nat_t["icone"]
                        nm_n = info_nat_t["nome_curto"]
                        faces_n = info_nat_t["faces"]
                        dado_s_n = info_nat_t["dado_str"]
                        acao_padrao_str += f" + {ico_n} Ataque Extra {nm_n} (-1 PM)"
                        if acertou_ch:
                            d_nat_val = rng.randint(1, faces_n) + (rng.randint(1, faces_n) if d20_ch == 20 else 0)
                            dano_ch = float(d_nat_val + fixo_dano_ch)
                            dano_causado = round(dano_causado + dano_ch, 1)
                            rolagem_str += f" | {ico_n} {nm_n}: d20({d20_ch})+{b_luta_ch}={tot_ch} (ACERTOU: {dado_s_n}[{d_nat_val}]+{fixo_dano_ch} = +{dano_ch:.0f} perfuração)"
                        else:
                            rolagem_str += f" | {ico_n} {nm_n}: d20({d20_ch})+{b_luta_ch}={tot_ch} (ERROU)"
                    acao_txt = f"{acao_padrao_str} | {rolagem_str} -> {dano_causado:.1f} dano total"

                pv_chefe_antes = pv_chefe
                pv_chefe = max(0.0, pv_chefe - dano_causado)
                dano_total_ep += dano_causado

                # Turno da Criatura (se continuar viva)
                dano_sofrido = 0.0
                acao_criatura_str = "Criatura derrotada (0 PV) — não age!"
                if pv_chefe > 0:
                    d20_ini = rng.randint(1, 20)
                    tot_ini = d20_ini + atq_inimigo
                    if d20_ini == 20 or (d20_ini != 1 and tot_ini >= ficha.defesa_total):
                        bruto_ini = round(dano_base_inimigo * rng.uniform(0.88, 1.12), 1)
                        dano_sofrido = max(1.0, round(bruto_ini - rd_estimada, 1))
                        pv_heroi = max(0.0, pv_heroi - dano_sofrido)
                        acao_criatura_str = (
                            f"Ataque d20({d20_ini})+{atq_inimigo}={tot_ini} vs Def {ficha.defesa_total} (Acertou: {bruto_ini:.0f} bruto "
                            f"- {rd_estimada} mitigação [{reacao_nome.split('(')[0].strip()}] = {dano_sofrido:.0f} dano)"
                        )
                    else:
                        acao_criatura_str = f"Ataque d20({d20_ini})+{atq_inimigo}={tot_ini} vs Def {ficha.defesa_total} (Errou o Herói!)"

                dano_sofrido_ep += dano_sofrido

                turnos_ep_atual.append(PassoTurnoCombate(
                        numero_turno=rodada,
                        acao_livre_movimento=acao_livre_str,
                        acao_padrao_principal=acao_padrao_str,
                        rolagem_e_teste=rolagem_str,
                        dano_causado=dano_causado,
                        pv_criatura_apos=f"{pv_chefe_antes:.0f} ➔ {pv_chefe:.0f}/{pv_inimigo_max} PV",
                        acao_criatura_e_reacao=acao_criatura_str,
                        dano_sofrido=dano_sofrido,
                        saldo_heroi_pv_pm=f"PV: {pv_heroi:.0f}/{ficha.pv_maximos} | PM: {pm_heroi:.0f}/{ficha.pm_maximos}",
                    ))
                logs_ep_atual.append(
                    f"Turno {rodada}: [Livre] {acao_livre_str} | [Padrão] {acao_txt} | "
                    f"Criatura PV: {pv_chefe:.0f}/{pv_inimigo_max} | [Inimigo] {acao_criatura_str} | "
                    f"Herói PV: {pv_heroi:.0f}/{ficha.pv_maximos}, PM: {pm_heroi:.0f}/{ficha.pm_maximos}"
                )

            chifres_acertou_ep = any("🐂 Chifres:" in t.rolagem_e_teste and "ACERTOU:" in t.rolagem_e_teste for t in turnos_ep_atual)
            gp_acertou_ep = any("Preciso" in t.rolagem_e_teste and ("ACERTOU" in t.rolagem_e_teste or "CRÍTICO" in t.rolagem_e_teste) for t in turnos_ep_atual)
            ja_tem_combo_demo = any("🐂 Chifres:" in t.rolagem_e_teste and "ACERTOU:" in t.rolagem_e_teste for t in turnos_detalhados) and any("Preciso" in t.rolagem_e_teste and ("ACERTOU" in t.rolagem_e_teste or "CRÍTICO" in t.rolagem_e_teste) for t in turnos_detalhados)
            if not turnos_detalhados or (not ja_tem_combo_demo and chifres_acertou_ep and gp_acertou_ep and pv_chefe <= 0):
                turnos_detalhados = turnos_ep_atual
                log_exemplo = logs_ep_atual
            if pv_chefe <= 0 and pv_heroi > 0:
                vitorias += 1
            soma_rodadas += rodada
            soma_dano_rodada += (dano_total_ep / max(1, rodada))
            soma_dano_sofrido_rodada += (dano_sofrido_ep / max(1, rodada))
            soma_pv_rest += (pv_heroi / max(1, ficha.pv_maximos)) * 100.0
            soma_pm_rest += (pm_heroi / max(1, ficha.pm_maximos)) * 100.0

        n_ep = max(1, episodios)
        win_solo = round((vitorias / n_ep) * 100.0, 1)
        win_lacaio = round(min(100.0, win_solo + 14.0), 1)
        win_especial = round(min(100.0, win_solo + 8.0), 1)
        dpr_efetivo = round(soma_dano_rodada / n_ep, 1)
        dano_sofrido_med = max(1.0, round(soma_dano_sofrido_rodada / n_ep, 1))
        ttk_heroi = round(pv_inimigo_max / max(1.0, dpr_efetivo), 1)
        ttk_ameaca = round(ficha.pv_maximos / dano_sofrido_med, 1)

        pv_lac_1v1 = max(12, int(round(ameaca_lac.pv * 0.35)))
        pv_esp_1v1 = max(18, int(round(ameaca_esp.pv * 0.35)))
        tabela_papeis = [
            EstatisticaPapelAmeaca(
                papel="🐉 Solo (Chefe Combatente)",
                patamar=ameaca_solo.patamar,
                nd=ameaca_solo.nd,
                ataque=ameaca_solo.bonus_ataque,
                dano_medio=ameaca_solo.dano_medio,
                defesa=ameaca_solo.defesa,
                res_forte=ameaca_solo.res_forte,
                res_media=ameaca_solo.res_media,
                res_fraca=ameaca_solo.res_fraca,
                pv_grupo4=ameaca_solo.pv,
                pv_duelo_1v1=pv_inimigo_max,
                cd_efeito=ameaca_solo.cd_efeito,
                winrate_heroi_pct=win_solo,
                ttk_heroi_turnos=ttk_heroi,
            ),
            EstatisticaPapelAmeaca(
                papel="⚔️ Lacaio (Grupo / Capanga)",
                patamar=ameaca_lac.patamar,
                nd=ameaca_lac.nd,
                ataque=ameaca_lac.bonus_ataque,
                dano_medio=ameaca_lac.dano_medio,
                defesa=ameaca_lac.defesa,
                res_forte=ameaca_lac.res_forte,
                res_media=ameaca_lac.res_media,
                res_fraca=ameaca_lac.res_fraca,
                pv_grupo4=ameaca_lac.pv,
                pv_duelo_1v1=pv_lac_1v1,
                cd_efeito=ameaca_lac.cd_efeito,
                winrate_heroi_pct=win_lacaio,
                ttk_heroi_turnos=round(pv_lac_1v1 / max(1.0, dpr_efetivo), 1),
            ),
            EstatisticaPapelAmeaca(
                papel="🔮 Especial (Conjurador / Líder)",
                patamar=ameaca_esp.patamar,
                nd=ameaca_esp.nd,
                ataque=ameaca_esp.bonus_ataque,
                dano_medio=ameaca_esp.dano_medio,
                defesa=ameaca_esp.defesa,
                res_forte=ameaca_esp.res_forte,
                res_media=ameaca_esp.res_media,
                res_fraca=ameaca_esp.res_fraca,
                pv_grupo4=ameaca_esp.pv,
                pv_duelo_1v1=pv_esp_1v1,
                cd_efeito=ameaca_esp.cd_efeito,
                winrate_heroi_pct=win_especial,
                ttk_heroi_turnos=round(pv_esp_1v1 / max(1.0, dpr_efetivo), 1),
            ),
        ]

        explicacao_winrate = (
            f"Em {n_ep} combates Monte Carlo contra a Ameaça Solo ND {nd} (Def {def_inimigo}, Res. Média +{res_inimigo}, Cota 1v1 {pv_inimigo_max} PV), "
            f"o herói venceu {vitorias}/{n_ep} episódios ({win_solo:.1f}%). "
            f"Razão Matemática: Com a decisão ótima, o herói causa {dpr_efetivo:.1f} de dano efetivo/turno "
            f"(derrubando os {pv_inimigo_max} PV da ameaça em TTK = {ttk_heroi:.1f} turnos), enquanto sofre em média {dano_sofrido_med:.1f} de dano/turno "
            f"(suportando até TTK_inimigo = {ttk_ameaca:.1f} turnos com seus {ficha.pv_maximos} PV)."
        )

        return RelatorioSimulacaoCombate(
            nome_ameaca=nome_ameaca,
            patamar_ameaca=ameaca_solo.patamar,
            papel_ameaca=ameaca_solo.papel,
            nd_ameaca=nd,
            pv_ameaca_grupo4=pv_grupo4_solo,
            pv_ameaca=pv_inimigo_max,
            defesa_ameaca=def_inimigo,
            ataque_ameaca=ameaca_solo.bonus_ataque,
            dano_medio_ameaca=ameaca_solo.dano_medio,
            res_forte_ameaca=ameaca_solo.res_forte,
            res_media_ameaca=ameaca_solo.res_media,
            res_fraca_ameaca=ameaca_solo.res_fraca,
            cd_efeito_ameaca=ameaca_solo.cd_efeito,
            episodios_simulados=n_ep,
            taxa_vitoria_pct=win_solo,
            taxa_vitoria_lacaio_pct=win_lacaio,
            taxa_vitoria_especial_pct=win_especial,
            dano_efetivo_medio_rodada=dpr_efetivo,
            rodadas_medias_combate=round(soma_rodadas / n_ep, 1),
            pv_restante_medio_pct=round(soma_pv_rest / n_ep, 1),
            pm_restante_medio_pct=round(soma_pm_rest / n_ep, 1),
            vitorias_contadas=vitorias,
            ttk_heroi_medio=ttk_heroi,
            ttk_ameaca_medio=ttk_ameaca,
            dano_sofrido_medio_rodada=dano_sofrido_med,
            iniciativa_heroi_bonus=bonus_ini_heroi,
            iniciativa_ameaca_bonus=bonus_ini_ameaca,
            chance_vencer_iniciativa_pct=prob_vencer_ini,
            resumo_iniciativa_e_surpresa=resumo_ini_str,
            limiar_morte_instantanea_pv=limiar_morte,
            regra_ferimentos_sangramento=regra_ferimentos_str,
            explicacao_calculo_vitoria=explicacao_winrate,
            melhor_sequencia_decisoes=melhor_seq_str,
            tabela_papeis_ameaca=tabela_papeis,
            matriz_decisoes_taticas=matriz_decisoes,
            turnos_detalhados=turnos_detalhados,
            log_combate_exemplo=log_exemplo,
        )




@dataclass
class ResultadoBuildCaixaPreta:
    """Resultado do aprendizado por reforço Caixa-Preta (sem ler a ficha da criatura) para um candidato de Build."""
    arquetipo: str
    classe_nome: str
    raca_nome: str
    arma_nome: str
    episodios_jogados: int
    vitorias: int
    winrate_empirico_pct: float
    recompensa_media_q: float
    dano_medio_por_turno: float
    defesa_estimada_intervalo: str
    res_magica_estimada: str


class AmbienteCombateCaixaPretaT20:
    """
    [Reinforcement Learning POMDP / Black-Box Environment]
    Encapsula a ficha da criatura de forma 100% privada (`_ameaca_oculta`).
    Simula com fidelidade tanto Combatentes Marciais (Ataque Especial, Golpe Pessoal, Armas Naturais)
    quanto Conjuradores Arcanos/Divinos (Exploração da Resistência Fraca da ameaça, Magia Acelerada,
    Arcano de Batalha, Seta Infalível e Reações Mágicas como Campo de Força RD 30 e Armadura Arcana +5 Def).
    """
    def __init__(self, nd_criatura: int = 6, papel: str = "Solo", nivel_heroi_ref: int = 6) -> None:
        self.__ameaca_oculta = obter_estatisticas_ameaca_oficial(nd_criatura, papel)
        delta_nd = nd_criatura - nivel_heroi_ref
        fator_pv = 1.0 if delta_nd >= 3 else (0.55 if delta_nd >= 1 else 0.30)
        fator_dano = 1.0 if delta_nd >= 2 else (0.75 if delta_nd == 1 else 0.45)
        self.__pv_max_duelo = max(25, int(round(self.__ameaca_oculta.pv * fator_pv)))
        self.__dano_turno_duelo = max(6, int(round(self.__ameaca_oculta.dano_medio * fator_dano)))

    def executar_episodio_caixa_preta(
        self, ficha_heroi: FichaPersonagem, semente: int, doutrina: str = "EQUILIBRADA_COMPLETA"
    ) -> Dict[str, Any]:
        rng = random.Random(semente)
        pv_h = float(max(1, ficha_heroi.pv_maximos))
        pm_h = float(ficha_heroi.pm_maximos)
        pv_c = float(self.__pv_max_duelo)

        res_d = AnalisadorSinergiaEDanoT20.calcular_resumo_dano_ficha(ficha_heroi)
        eh_conj = ficha_heroi.eh_conjurador()
        melhor_mag = res_d["melhor_magia_info"]
        dano_mag = res_d["maior_dano_magia"]
        custo_mag = melhor_mag[1]["pm_gasto"] if melhor_mag else 3
        dano_raio = max(res_d["dano_medio_raio"], 6.5 * max(1, ficha_heroi.circulo_maximo_permitido()) if eh_conj else 0.0)
        dano_arma = max(res_d["dano_medio_arma"], 6.5 + max(0, ficha_heroi.atributos_finais.FOR))
        m_atq = re.search(r"Ataque\s*([+-]?\d+)", res_d.get("desc_dano_arma", ""))
        atq_h = int(m_atq.group(1)) if m_atq else max(ficha_heroi.bonus_pericias.get("Luta", 0), ficha_heroi.bonus_pericias.get("Pontaria", 0))

        nomes_mag = [m.nome.lower() for m in ficha_heroi.magias_conhecidas]
        tem_campo_forca = any("campo de força" in nm for nm in nomes_mag) or (eh_conj and ficha_heroi.nivel >= 5)
        tem_armadura_arcana = any("armadura arcana" in nm or "escudo da fé" in nm for nm in nomes_mag) or eh_conj
        tem_acelerada = ficha_heroi.possui_poder("Magia Acelerada") or (eh_conj and ficha_heroi.nivel >= 4)
        sig_mag, _ = ficha_heroi.obter_atributo_chave_magia()
        b_atr_mag = max(0, ficha_heroi.atributos_finais.obter(sig_mag))
        bonus_arcano_batalha = b_atr_mag if (ficha_heroi.possui_poder("Arcano de Batalha") or eh_conj) else 0

        rd_passiva = (2 if ficha_heroi.possui_poder("Encouraçado") else 0) + (5 if (ficha_heroi.raca and ficha_heroi.raca.nome.lower() == "osteon") else 0)

        turnos = 0
        dano_total_causado = 0.0
        observacoes_ataque: List[Tuple[int, int, bool]] = []
        observacoes_magia: List[Tuple[int, bool]] = []

        ini_h_bb = rng.randint(1, 20) + ficha_heroi.bonus_pericias.get("Iniciativa", ficha_heroi.nivel // 2 + ficha_heroi.atributos_finais.DES)
        ini_c_bb = rng.randint(1, 20) + (int(self.__ameaca_oculta.nd) // 2 + 4)
        heroi_age_primeiro = ini_h_bb >= ini_c_bb

        while pv_h > 0 and pv_c > 0 and turnos < 20:
            turnos += 1
            # Se a ameaça venceu a Iniciativa, ela ataca primeiro na rodada
            if not heroi_age_primeiro:
                d20_m = rng.randint(1, 20)
                def_h_efetiva = ficha_heroi.defesa_total + (5 if (tem_armadura_arcana and pm_h >= 2) else 0)
                if d20_m == 20 or (d20_m != 1 and d20_m + self.__ameaca_oculta.bonus_ataque >= def_h_efetiva):
                    if tem_campo_forca and pm_h >= 4:
                        pm_h -= 4
                        rd_turno = rd_passiva + 30
                    elif ficha_heroi.classe and ficha_heroi.classe.nome.lower() == "guerreiro" and ficha_heroi.nivel >= 3 and pm_h >= 3:
                        pm_h -= 3
                        rd_turno = rd_passiva + int(self.__dano_turno_duelo * 0.50)
                    else:
                        rd_turno = rd_passiva + (4 if ficha_heroi.escudo_equipado else 0)
                    d_sof = max(1.0, self.__dano_turno_duelo * rng.uniform(0.88, 1.12) - rd_turno)
                    pv_h = max(0.0, pv_h - d_sof)
                if pv_h <= 0:
                    break

            dano_c = 0.0
            if eh_conj:
                # Conjurador explora a Resistência Fraca/Média da criatura e usa Magia Acelerada no Turno 1 se disponível!
                res_alvo = self.__ameaca_oculta.res_fraca if turnos >= 2 else self.__ameaca_oculta.res_media
                dano_base_mag = max(dano_mag, 8.5 * max(1, ficha_heroi.circulo_maximo_permitido()) + bonus_arcano_batalha)
                if pm_h >= custo_mag:
                    pm_h -= custo_mag
                    d20_ini_res = rng.randint(1, 20)
                    passou = (d20_ini_res == 20) or (d20_ini_res != 1 and (d20_ini_res + res_alvo) >= ficha_heroi.cd_magias)
                    observacoes_magia.append((ficha_heroi.cd_magias, not passou))
                    dano_c += (dano_base_mag + bonus_arcano_batalha) * rng.uniform(0.94, 1.08) * (0.5 if passou else 1.0)
                    # Burst de Magia Acelerada (+4 PM: 2ª magia como Ação Livre no 1º turno!)
                    if tem_acelerada and turnos == 1 and pm_h >= (custo_mag + 4) and doutrina != "SOBREVIVENCIA_MITIGACAO":
                        pm_h -= (custo_mag + 4)
                        d20_r2 = rng.randint(1, 20)
                        passou2 = (d20_r2 == 20) or (d20_r2 != 1 and (d20_r2 + self.__ameaca_oculta.res_fraca) >= ficha_heroi.cd_magias)
                        dano_c += (dano_base_mag + bonus_arcano_batalha) * rng.uniform(0.94, 1.08) * (0.5 if passou2 else 1.0)
                else:
                    d20_ini_res = rng.randint(1, 20)
                    passou = (d20_ini_res == 20) or (d20_ini_res != 1 and (d20_ini_res + res_alvo) >= ficha_heroi.cd_magias)
                    observacoes_magia.append((ficha_heroi.cd_magias, not passou))
                    dano_c += (dano_raio + bonus_arcano_batalha) * rng.uniform(0.92, 1.08) * (0.5 if passou else 1.0)
            else:
                nc_bb = ficha_heroi.classe.nome.lower() if ficha_heroi.classe else ""
                custo_ae_bb = (1 + (ficha_heroi.nivel - 1) // 4) if (nc_bb == "guerreiro" and pm_h >= (1 + (ficha_heroi.nivel - 1) // 4)) else 0
                pm_h -= custo_ae_bb
                bonus_ae_bb = 4 * custo_ae_bb
                usa_gp_bb = ficha_heroi.possui_poder("Golpe Pessoal") and turnos == 1 and pm_h >= 3
                if usa_gp_bb:
                    pm_h -= 3
                d20_atq = max(rng.randint(1, 20), rng.randint(1, 20)) if usa_gp_bb else rng.randint(1, 20)
                tot_atq = d20_atq + atq_h + bonus_ae_bb
                def_oculto_t = (self.__ameaca_oculta.defesa - 5) if (turnos == 1 and heroi_age_primeiro) else self.__ameaca_oculta.defesa
                acertou = (d20_atq == 20) or (d20_atq != 1 and tot_atq >= def_oculto_t)
                observacoes_ataque.append((d20_atq, d20_atq + atq_h, (d20_atq + atq_h) >= self.__ameaca_oculta.defesa))
                dano_c = (dano_arma * (1.55 if d20_atq >= 19 else 1.0) * rng.uniform(0.92, 1.08) + (10.5 if usa_gp_bb else 0.0)) if acertou else 0.0
                if ficha_heroi.possui_chifres() and pm_h >= 1:
                    pm_h -= 1
                    d20_ch_bb = rng.randint(1, 20)
                    b_ch_bb = ficha_heroi.bonus_pericias.get("Luta", atq_h) + (2 if ficha_heroi.possui_poder("Valentão") else 0)
                    if d20_ch_bb == 20 or (d20_ch_bb != 1 and d20_ch_bb + b_ch_bb >= def_oculto_t):
                        dano_c += rng.randint(1, 6) + max(0, ficha_heroi.atributos_finais.FOR)

            pv_c = max(0.0, pv_c - dano_c)
            dano_total_causado += dano_c

            if heroi_age_primeiro and pv_c > 0:
                d20_m = rng.randint(1, 20)
                def_h_efetiva = ficha_heroi.defesa_total + (5 if (tem_armadura_arcana and pm_h >= 2) else 0)
                if d20_m == 20 or (d20_m != 1 and d20_m + self.__ameaca_oculta.bonus_ataque >= def_h_efetiva):
                    if tem_campo_forca and pm_h >= 4:
                        pm_h -= 4
                        rd_turno = rd_passiva + 30
                    elif ficha_heroi.classe and ficha_heroi.classe.nome.lower() == "guerreiro" and ficha_heroi.nivel >= 3 and pm_h >= 3:
                        pm_h -= 3
                        rd_turno = rd_passiva + int(self.__dano_turno_duelo * 0.50)
                    else:
                        rd_turno = rd_passiva + (4 if ficha_heroi.escudo_equipado else 0)
                    d_sof = max(1.0, self.__dano_turno_duelo * rng.uniform(0.88, 1.12) - rd_turno)
                    pv_h = max(0.0, pv_h - d_sof)

        venceu = (pv_c <= 0) and (pv_h > 0)
        if venceu:
            recompensa = 100.0 + 60.0 * (pv_h / max(1.0, float(ficha_heroi.pv_maximos))) + (40.0 / max(1, turnos))
        else:
            pct_dano_no_chefe = min(1.0, dano_total_causado / max(1.0, float(self.__pv_max_duelo)))
            penalidade_ik = -20.0 if turnos <= 1 else 0.0
            recompensa = -100.0 + (60.0 * pct_dano_no_chefe) + penalidade_ik

        return {
            "venceu": venceu,
            "turnos": turnos,
            "dano_total_causado": round(dano_total_causado, 1),
            "recompensa": round(recompensa, 1),
            "observacoes_ataque": observacoes_ataque,
            "observacoes_magia": observacoes_magia,
        }


class AgenteRLCaixaPretaT20:
    """
    Agente de Aprendizado por Reforço que descobre a melhor Build para derrotar uma
    criatura misteriosa SEM LER SUA FICHA, permitindo filtrar por "Tipo de Aventureiro"
    (Builds Gerais vs. Conjuradores Arcanos, Conjuradores Divinos, Marciais Pesados,
    Marciais Ágeis/Distância, Tanques e Híbridos).
    """
    CATALOGO_CANDIDATOS_POR_TIPO: Dict[str, Tuple[Tuple[str, str, str], ...]] = {
        "GERAL_EQUILIBRADO": (
            ("Conjurador Arcano: Mago", "Arcanista", "Elfo"),
            ("Conjurador Arcano: Feiticeiro", "Arcanista", "Qareen"),
            ("Suporte Divino: Clérigo", "Clérigo", "Anão"),
            ("Suporte Divino: Druida", "Druida", "Dahllan"),
            ("Conjurador: Bardo", "Bardo", "Qareen"),
            ("Marcial: Duas Mãos Pesado", "Guerreiro", "Minotauro"),
            ("Marcial: Duas Mãos Pesado", "Bárbaro", "Minotauro"),
            ("Lutador: Ataque Desarmado", "Lutador", "Lefou"),
            ("Marcial: Uma Mão Duelista", "Ladino", "Goblin"),
            ("Suporte Tático: Comandante", "Nobre", "Humano"),
            ("Especialista: Engenhoqueiro", "Inventor", "Kliren"),
            ("Tanque: Arma e Escudo", "Paladino", "Humano"),
            ("Marcial: Dano Arqueiro", "Caçador", "Elfo"),
            ("Marcial: Uma Mão Duelista", "Bucaneiro", "Goblin"),
            ("Tanque: Arma e Escudo", "Cavaleiro", "Anão"),
        ),
        "CONJURADORES_TODOS": (
            ("Conjurador Arcano: Mago", "Arcanista", "Elfo"),
            ("Conjurador Arcano: Feiticeiro", "Arcanista", "Qareen"),
            ("Conjurador Arcano: Bruxo", "Arcanista", "Kliren"),
            ("Conjurador Arcano: Mago", "Arcanista", "Osteon"),
            ("Suporte Divino: Clérigo", "Clérigo", "Anão"),
            ("Suporte Divino: Clérigo", "Clérigo", "Suraggel (Aggelus)"),
            ("Suporte Divino: Druida", "Druida", "Dahllan"),
            ("Conjurador: Bardo", "Bardo", "Qareen"),
        ),
        "CONJURADOR_ARCANO_ESPECIFICO": (
            ("Conjurador Arcano: Mago", "Arcanista", "Elfo"),
            ("Conjurador Arcano: Feiticeiro", "Arcanista", "Qareen"),
            ("Conjurador Arcano: Bruxo", "Arcanista", "Kliren"),
            ("Conjurador Arcano: Mago", "Arcanista", "Osteon"),
            ("Conjurador Arcano: Feiticeiro", "Arcanista", "Suraggel (Sulfure)"),
            ("Conjurador Arcano: Mago", "Arcanista", "Humano"),
        ),
        "CONJURADOR_DIVINO_ESPECIFICO": (
            ("Suporte Divino: Clérigo", "Clérigo", "Anão"),
            ("Suporte Divino: Clérigo", "Clérigo", "Suraggel (Aggelus)"),
            ("Suporte Divino: Clérigo", "Clérigo", "Humano"),
            ("Suporte Divino: Druida", "Druida", "Dahllan"),
            ("Suporte Divino: Druida", "Druida", "Trog"),
            ("Conjurador: Bardo", "Bardo", "Qareen"),
        ),
        "MARCIAIS_TODOS": (
            ("Marcial: Duas Mãos Pesado", "Guerreiro", "Minotauro"),
            ("Marcial: Armas de Haste", "Guerreiro", "Minotauro"),
            ("Marcial: Duas Mãos Pesado", "Bárbaro", "Minotauro"),
            ("Marcial: Duas Armas", "Caçador", "Humano"),
            ("Marcial: Dano Arqueiro", "Caçador", "Elfo"),
            ("Marcial: Uma Mão Duelista", "Bucaneiro", "Goblin"),
            ("Lutador: Ataque Desarmado", "Lutador", "Lefou"),
            ("Marcial: Uma Mão Duelista", "Ladino", "Goblin"),
        ),
    }

    @classmethod
    def descobrir_melhor_build_sem_ler_ficha(
        cls,
        otimizador: OtimizadorFichaCSP_MCTS,
        nivel: int = 6,
        papel_criatura: str = "Solo",
        episodios_por_build: int = 12,
        tipo_aventureiro: str = "GERAL_EQUILIBRADO",
    ) -> Tuple[List[ResultadoBuildCaixaPreta], str]:
        ambiente = AmbienteCombateCaixaPretaT20(nd_criatura=nivel, papel=papel_criatura, nivel_heroi_ref=nivel)
        def_min_global = 10
        def_max_global = 65
        testes_magia_total = 0
        falhas_res_inimigo_total = 0
        resultados: List[ResultadoBuildCaixaPreta] = []
        lista_cands = cls.CATALOGO_CANDIDATOS_POR_TIPO.get(tipo_aventureiro, cls.CATALOGO_CANDIDATOS_POR_TIPO["GERAL_EQUILIBRADO"])

        for idx_b, (arq, cl_fixa, raca_fixa) in enumerate(lista_cands):
            ficha_cand = otimizador.otimizar(
                nome=f"Agente RL #{idx_b+1}",
                nivel=nivel,
                arquetipo=arq,
                iteracoes_mcts=45,
                fixar_raca=raca_fixa,
                fixar_classe=cl_fixa,
            )
            q_val = 0.0
            lr = 0.25
            vitorias = 0
            soma_dano_turno = 0.0

            for ep in range(episodios_por_build):
                obs = ambiente.executar_episodio_caixa_preta(ficha_cand, semente=900 + idx_b * 31 + ep * 7)
                r = obs["recompensa"]
                q_val = q_val + lr * (r - q_val) if ep > 0 else r
                if obs["venceu"]:
                    vitorias += 1
                soma_dano_turno += obs["dano_total_causado"] / max(1, obs["turnos"])

                for d20_v, tot_atq, acertou in obs["observacoes_ataque"]:
                    if d20_v == 1 or d20_v == 20:
                        continue
                    if acertou:
                        def_max_global = min(def_max_global, tot_atq)
                    else:
                        def_min_global = max(def_min_global, tot_atq + 1)

                for _, inimigo_falhou in obs["observacoes_magia"]:
                    testes_magia_total += 1
                    if inimigo_falhou:
                        falhas_res_inimigo_total += 1

            intervalo_def_str = (
                f"Defesa Exata Deduzida: {def_min_global}"
                if def_min_global == def_max_global
                else f"[{def_min_global} .. {max(def_min_global, def_max_global)}]"
            )
            taxa_falha_mag = round((falhas_res_inimigo_total / max(1, testes_magia_total)) * 100.0, 1) if testes_magia_total > 0 else 50.0
            resultados.append(ResultadoBuildCaixaPreta(
                arquetipo=arq,
                classe_nome=ficha_cand.classe.nome if ficha_cand.classe else cl_fixa,
                raca_nome=ficha_cand.raca.nome if ficha_cand.raca else raca_fixa,
                arma_nome=ficha_cand.arma_equipada.nome if ficha_cand.arma_equipada else "Magia",
                episodios_jogados=episodios_por_build,
                vitorias=vitorias,
                winrate_empirico_pct=round((vitorias / episodios_por_build) * 100.0, 1),
                recompensa_media_q=round(q_val, 1),
                dano_medio_por_turno=round(soma_dano_turno / episodios_por_build, 1),
                defesa_estimada_intervalo=intervalo_def_str,
                res_magica_estimada=f"{taxa_falha_mag:.0f}% vulnerável a CD mágica",
            ))

        resultados.sort(key=lambda x: (x.recompensa_media_q, x.winrate_empirico_pct, x.dano_medio_por_turno), reverse=True)
        campea = resultados[0]
        resumo_aprendizado = (
            f" Sem ler a ficha da criatura ({papel_criatura} ND {nivel} | Filtro: {tipo_aventureiro}), o Agente RL disputou {len(resultados)*episodios_por_build} combates, "
            f"deduziu pelas rolagens que a Defesa oculta da criatura está em {campea.defesa_estimada_intervalo} "
            f"e convergiu para a Build Campeã: '{campea.arquetipo}' ({campea.raca_nome} {campea.classe_nome} c/ {campea.arma_nome}) "
            f"com Recompensa Q = {campea.recompensa_media_q:.1f}, Winrate = {campea.winrate_empirico_pct:.1f}% e DPR = {campea.dano_medio_por_turno:.1f}/turno!"
        )
        return resultados, resumo_aprendizado

