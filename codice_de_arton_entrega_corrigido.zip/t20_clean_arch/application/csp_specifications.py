# -*- coding: utf-8 -*-
from __future__ import annotations

import abc
import base64
import copy
import dataclasses
import datetime
from datetime import datetime as dt_cls
import gzip
import hashlib
import zlib
import functools
import html
import http.server
import inspect
import io
import json
import lzma
import math
import os
import pathlib
from pathlib import Path
import random
import re
import socketserver
import sqlite3
import statistics
import string
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import typing
import urllib.parse
import urllib.request
import uuid
import webbrowser
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import (
    Any, Callable, Dict, Generic, Iterable, Iterator, List,
    Literal, Mapping, NamedTuple, Optional, Protocol, Sequence,
    Set, Tuple, Type, TypeVar, Union
)

"""
Camada de Aplicação — Especificações CSP (GoF Composite Specification + Interpreter), Template Method e AC-3.
"""
from ..domain import *
from .calculators_decorators import *



# ==============================================================================
# 5. PADRÃO COMPOSITE & TEMPLATE METHOD: MOTOR DE VALIDAÇÃO CSP
# ==============================================================================

class EspecificacaoAtributoMinimo(IEspecificacaoCSP):
    def __init__(self, atributo: str, minimo: int) -> None:
        self.atributo = MAPA_SINONIMOS_ATRIBUTOS.get(atributo.upper(), atributo.upper())
        self.minimo = minimo

    def eh_satisfeita_por(self, ficha: FichaPersonagem) -> Tuple[bool, str]:
        atual = ficha.atributos_finais.obter(self.atributo)
        return atual >= self.minimo, f"Atributo {self.atributo} >= {self.minimo} (atual: {atual})"


class EspecificacaoNivelMinimo(IEspecificacaoCSP):
    def __init__(self, nivel_minimo: int) -> None:
        self.nivel_minimo = nivel_minimo

    def eh_satisfeita_por(self, ficha: FichaPersonagem) -> Tuple[bool, str]:
        return ficha.nivel >= self.nivel_minimo, f"Nível >= {self.nivel_minimo} (atual: {ficha.nivel})"


class EspecificacaoPericiaTreinada(IEspecificacaoCSP):
    def __init__(self, pericia: str) -> None:
        self.pericia = pericia.strip()

    def eh_satisfeita_por(self, ficha: FichaPersonagem) -> Tuple[bool, str]:
        return ficha.possui_pericia_treinada(self.pericia), f"Treinado em {self.pericia}"


class EspecificacaoPoderPossuido(IEspecificacaoCSP):
    def __init__(self, nome_poder: str) -> None:
        self.nome_poder = nome_poder.strip()

    def eh_satisfeita_por(self, ficha: FichaPersonagem) -> Tuple[bool, str]:
        nl = self.nome_poder.lower()
        if "poder da tormenta" in nl or "poderes da tormenta" in nl:
            qtd = sum(1 for p in ficha.todos_os_poderes() if p.categoria_ou_classe.lower() == "tormenta")
            min_tor = 4 if "quatro" in nl else (3 if "três" in nl else 1)
            return qtd >= min_tor, f"Possuir >= {min_tor} poder(es) da Tormenta"
        return ficha.possui_poder(self.nome_poder), f"Pré-requisito '{self.nome_poder}'"


class EspecificacaoDevotoDeus(IEspecificacaoCSP):
    def __init__(self, texto_devoto: str) -> None:
        self.texto_devoto = texto_devoto.strip()

    def eh_satisfeita_por(self, ficha: FichaPersonagem) -> Tuple[bool, str]:
        if not ficha.deus:
            return False, f"Requer {self.texto_devoto}"
        if "qualquer devoto" in self.texto_devoto.lower():
            return True, "Devoto de qualquer divindade"
        ok = ficha.deus.nome.lower() in self.texto_devoto.lower()
        return ok, f"{self.texto_devoto} (atual: {ficha.deus.nome})"


class EspecificacaoCompostaAND(IEspecificacaoCSP):
    def __init__(self, especificacoes: Sequence[IEspecificacaoCSP]) -> None:
        self.especificacoes = list(especificacoes)

    def eh_satisfeita_por(self, ficha: FichaPersonagem) -> Tuple[bool, str]:
        falhas = [msg for esp in self.especificacoes for ok, msg in [esp.eh_satisfeita_por(ficha)] if not ok]
        return (len(falhas) == 0), (" E ".join(falhas) if falhas else "OK")


class EspecificacaoCompostaOR(IEspecificacaoCSP):
    def __init__(self, especificacoes: Sequence[IEspecificacaoCSP]) -> None:
        self.especificacoes = list(especificacoes)

    def eh_satisfeita_por(self, ficha: FichaPersonagem) -> Tuple[bool, str]:
        msgs = []
        for esp in self.especificacoes:
            ok, msg = esp.eh_satisfeita_por(ficha)
            if ok:
                return True, msg
            msgs.append(msg)
        return False, " OU ".join(msgs)


class EspecificacaoFuncaoCustomizada(IEspecificacaoCSP):
    """Especificação CSP baseada em predicado dinâmico para proficiências, magias e habilidades."""
    def __init__(self, avaliador_fn: Any) -> None:
        self.avaliador_fn = avaliador_fn

    def eh_satisfeita_por(self, ficha: FichaPersonagem) -> Tuple[bool, str]:
        return self.avaliador_fn(ficha)


NOMES_PERICIAS_RADICAIS: Tuple[str, ...] = (
    "acrobacia", "adestramento", "atletismo", "atuação", "cavalgar", "conhecimento",
    "cura", "diplomacia", "enganação", "fortitude", "furtividade", "guerra",
    "iniciativa", "intimidação", "intuição", "investigação", "jogatina", "ladinagem",
    "luta", "misticismo", "nobreza", "ofício", "percepção", "pilotagem",
    "pontaria", "reflexos", "religião", "sobrevivência", "vontade"
)


class InterpretadorPreRequisitosCSP:
    """
    Compila 100% das cláusulas de `Pre_Requisitos` do banco de dados Tormenta20
    (incluindo proficiências, perícias curtas, círculos de magia, habilidades de classe e patamares)
    em árvores Composite `IEspecificacaoCSP`.
    """
    _cache: Dict[str, IEspecificacaoCSP] = {}

    @classmethod
    def _eh_nome_pericia(cls, texto: str) -> bool:
        tl = texto.strip().lower()
        if tl.startswith("ofício"):
            return True
        return tl in NOMES_PERICIAS_RADICAIS

    @classmethod
    def compilar(cls, texto_prereq: str) -> IEspecificacaoCSP:
        limpo = (texto_prereq or "").strip()
        if limpo in cls._cache:
            return cls._cache[limpo]
        if not limpo or limpo.lower() in ("nenhum", "-", "n/a"):
            res = EspecificacaoCompostaAND([])
            cls._cache[limpo] = res
            return res

        if "patamar" in limpo.lower():
            # Regra de Aumento de Atributo: máximo 1x por patamar para o mesmo atributo
            def _val_patamar(f: FichaPersonagem) -> Tuple[bool, str]:
                qtd_aum = sum(1 for p in f.todos_os_poderes() if p.nome.lower() == "aumento de atributo")
                lim_pat = f.patamar_atual()
                return qtd_aum <= lim_pat, f"Máx. 1x por patamar (limite atual no nível {f.nivel}: {lim_pat}x)"
            res = EspecificacaoFuncaoCustomizada(_val_patamar)
            cls._cache[limpo] = res
            return res

        partes_and = [p.strip() for p in limpo.split(",") if p.strip()]
        especificacoes_and: List[IEspecificacaoCSP] = []

        for parte in partes_and:
            pl = parte.lower().strip()

            # 1. Devoção divina (incluindo 'Devoto (exceto Lena/Marah)' ou 'Devoto de Thyatis (Clérigo)')
            if pl.startswith("devoto") or pl == "qualquer devoto":
                def _criar_val_dev(txt_d: str) -> Any:
                    tl_d = txt_d.lower()
                    def _fn(f: FichaPersonagem) -> Tuple[bool, str]:
                        if not f.deus:
                            return False, f"Requer devoção ({txt_d})"
                        nd = f.deus.nome.lower()
                        if "exceto lena/marah" in tl_d:
                            return nd not in ("lena", "marah"), f"Devoção incompatível ({f.deus.nome} é pacifista)"
                        if "(" in tl_d and f.classe:
                            m_cl = re.search(r"\(([^)]+)\)", tl_d)
                            if m_cl and m_cl.group(1).strip() != f.classe.nome.lower():
                                return False, f"Exclusivo para classe {m_cl.group(1).title()}"
                        if tl_d in ("devoto", "qualquer devoto"):
                            return True, "Devoto"
                        return nd in tl_d, f"Requer {txt_d} (atual: {f.deus.nome})"
                    return _fn
                especificacoes_and.append(EspecificacaoFuncaoCustomizada(_criar_val_dev(parte)))
                continue

            # 2. Proficiências ("Proficiência com armaduras pesadas", "proficiência com escudos", "Escudo", "Proficiência com a arma")
            if "proficiência" in pl or pl == "escudo":
                def _criar_val_prof(txt_p: str) -> Any:
                    tl_p = txt_p.lower()
                    def _fn(f: FichaPersonagem) -> Tuple[bool, str]:
                        profs = [x.lower() for x in f.obter_proficiencias_ativas()]
                        if "armaduras pesadas" in tl_p:
                            return any("armaduras pesadas" in x for x in profs), "Requer Proficiência com Armaduras Pesadas"
                        if "escudo" in tl_p:
                            return any("escudos" in x for x in profs), "Requer Proficiência com Escudos"
                        if "arma" in tl_p:
                            if not f.arma_equipada:
                                return False, "Requer arma equipada com a qual seja proficiente"
                            return f.tem_proficiencia_item(f.arma_equipada)
                        return True, "OK"
                    return _fn
                especificacoes_and.append(EspecificacaoFuncaoCustomizada(_criar_val_prof(parte)))
                continue

            # 3. Conjuração / Habilidade Magias / Não Conjurador / Dissipar Magia
            if "lançar magias" in pl or "habilidade de classe magias" in pl or "não conjurador" in pl or pl == "dissipar magia":
                def _criar_val_mag(txt_m: str) -> Any:
                    tl_m = txt_m.lower()
                    def _fn(f: FichaPersonagem) -> Tuple[bool, str]:
                        if "não conjurador" in tl_m:
                            return not f.eh_conjurador(), "Exclusivo para personagens não conjuradores"
                        if tl_m == "dissipar magia":
                            tem_dis = any("dissipar magia" in m.nome.lower() for m in f.magias_conhecidas)
                            return tem_dis, "Requer conhecer a magia 'Dissipar Magia'"
                        if "2º círculo" in tl_m or "2o círculo" in tl_m:
                            return f.circulo_maximo_permitido() >= 2, f"Requer capacidade de lançar magias de 2º círculo (atual: {f.circulo_maximo_permitido()}º)"
                        return f.eh_conjurador(), "Requer habilidade de classe Magias / Lançar Magias"
                    return _fn
                especificacoes_and.append(EspecificacaoFuncaoCustomizada(_criar_val_mag(parte)))
                continue

            # 4. Nível mínimo (ex: '6º nível de guerreiro', '12º nível de personagem')
            m_niv = re.search(r"(\d+)[ºo°]?\s*nível(?:\s+de\s+([a-zA-Zçãõáéíóúâêô]+))?|nível\s*(\d+)", pl)
            if m_niv:
                niv = int(m_niv.group(1) or m_niv.group(3))
                classe_esp = (m_niv.group(2) or "").strip().lower()
                def _criar_val_niv(n_req: int, cl_req: str) -> Any:
                    def _fn(f: FichaPersonagem) -> Tuple[bool, str]:
                        if cl_req and cl_req != "personagem":
                            nv_na_cl = f.nivel_na_classe(cl_req)
                            if nv_na_cl <= 0:
                                return False, f"Requer classe {cl_req.title()}"
                            return nv_na_cl >= n_req, f"Requer {n_req}º nível de {cl_req.title()} (atual na classe: {nv_na_cl})"
                        return f.nivel >= n_req, f"Requer {n_req}º nível de personagem (atual: {f.nivel})"
                    return _fn
                especificacoes_and.append(EspecificacaoFuncaoCustomizada(_criar_val_niv(niv, classe_esp)))
                continue

            # 5. Treinado em perícia explícito ("Treinado em Luta", "Treinado em Adestramento ou Diplomacia")
            if "treinado em" in pl or "treinado na perícia" in pl:
                if "treinado na perícia" in pl:
                    especificacoes_and.append(EspecificacaoFuncaoCustomizada(
                        lambda f: (len(f.pericias_treinadas) > 0, "Requer ao menos uma perícia treinada")
                    ))
                    continue
                pericias_str = re.sub(r"(?i)treinado em\s*", "", parte).strip()
                opcoes = [op.strip() for op in re.split(r"\s+ou\s+", pericias_str)]
                if len(opcoes) > 1:
                    especificacoes_and.append(EspecificacaoCompostaOR([EspecificacaoPericiaTreinada(op) for op in opcoes]))
                else:
                    especificacoes_and.append(EspecificacaoPericiaTreinada(opcoes[0]))
                continue

            # 6. Atributo mínimo ("For 1", "Des 2", "Sab 1")
            m_atr = re.match(r"^(for|des|con|int|sab|car)\s+(\d+)$", pl)
            if m_atr:
                especificacoes_and.append(EspecificacaoAtributoMinimo(m_atr.group(1).upper(), int(m_atr.group(2))))
                continue

            # 7. Perícias escritas na forma curta em Poderes_Classe (ex: "Luta", "Iniciativa", "Enganação e Investigação", "Ofício (armeiro)")
            if " e " in pl and all(cls._eh_nome_pericia(sub_p) for sub_p in re.split(r"\s+e\s+", pl)):
                for sub_p in re.split(r"\s+e\s+", parte):
                    especificacoes_and.append(EspecificacaoPericiaTreinada(sub_p.split("(")[0].strip()))
                continue
            if cls._eh_nome_pericia(pl):
                especificacoes_and.append(EspecificacaoPericiaTreinada(parte.split("(")[0].strip()))
                continue

            # 8. Habilidades fixas de classe (ex: 'Forma Selvagem', 'Canalizar Energia', 'Bruxo', 'Feiticeiro', 'Mago', 'Montaria')
            if pl in ("forma selvagem", "canalizar energia", "bruxo", "feiticeiro", "mago", "bruxo ou mago", "montaria", "poder de armadilha", "poder de missa") or pl.startswith("comportamento"):
                def _criar_val_hab_classe(txt_h: str) -> Any:
                    tl_h = txt_h.lower()
                    def _fn(f: FichaPersonagem) -> Tuple[bool, str]:
                        if not f.classe:
                            return False, f"Requer {txt_h}"
                        hab_c = f.classe.habilidades_fixas.lower()
                        nc = f.classe.nome.lower()
                        if tl_h in ("bruxo", "feiticeiro", "mago", "bruxo ou mago"):
                            return nc == "arcanista", f"Requer Caminho do Arcanista ({txt_h})"
                        if tl_h == "forma selvagem":
                            return nc == "druida", "Requer habilidade Forma Selvagem (Druida)"
                        if tl_h == "canalizar energia" or tl_h == "poder de missa":
                            return nc == "clérigo", f"Requer classe Clérigo ({txt_h})"
                        if tl_h == "montaria":
                            return nc in ("cavaleiro", "paladino") or f.possui_poder("Ginete"), "Requer Montaria"
                        if tl_h.startswith("comportamento"):
                            return f.deus is not None, f"Requer seguir {txt_h}"
                        return tl_h in hab_c or f.possui_poder(txt_h), f"Requer {txt_h}"
                    return _fn
                especificacoes_and.append(EspecificacaoFuncaoCustomizada(_criar_val_hab_classe(parte)))
                continue

            # 9. Disjunção ou Conjunção de Poderes Pré-Requisito (ex: "Estilo de Disparo ou Estilo de Arremesso", "Ataque Poderoso")
            if " ou " in pl:
                opcoes_p = [op.strip() for op in re.split(r"\s+ou\s+", parte)]
                especificacoes_and.append(EspecificacaoCompostaOR([EspecificacaoPoderPossuido(op) for op in opcoes_p]))
            else:
                especificacoes_and.append(EspecificacaoPoderPossuido(parte))

        res = EspecificacaoCompostaAND(especificacoes_and)
        cls._cache[limpo] = res
        return res
# ==============================================================================
# 5B. MOTOR DE EXCLUSÃO MÚTUA DE ESTILOS (CSP) E CALCULADORA DE DANO / MAGIAS
# ==============================================================================

GRUPOS_ESTILO_EXCLUSIVOS: Dict[str, Tuple[str, ...]] = {
    "DUAS_MAOS": (
        "destruidor", "estilo de duas mãos", "ataque pesado"
    ),
    "ARMA_LONGA_HASTE": (
        "estilo de arma longa", "piqueiro"
    ),
    "ARQUERIA_DISPARO": (
        "arqueiro", "estilo de disparo", "disparo preciso", "disparo rápido", "mira apurada"
    ),
    "ARREMESSO": (
        "estilo de arremesso", "arremesso potente", "arremesso múltiplo"
    ),
    "DUAS_ARMAS": (
        "estilo de duas armas", "ambidestria", "arma secundária grande"
    ),
    "UMA_ARMA_ESGRIMA": (
        "estilo de uma arma", "ataque preciso", "esgrimista", "acuidade com arma"
    ),
    "ARMA_E_ESCUDO": (
        "estilo de arma e escudo", "ataque com escudo", "bloqueio com escudo", "solidez", "escudeiro"
    ),
}

PODERES_EXCLUSIVOS_CORPO_A_CORPO: Tuple[str, ...] = (
    "destruidor", "estilo de duas mãos", "ataque pesado", "ataque poderoso", "trespassar",
    "valentão", "ambidestria", "estilo de duas armas", "esgrimista", "acuidade com arma",
    "ataque reflexo", "tornado de dor", "golpe de raspão", "estilo de uma arma", "ataque preciso",
    "estilo de arma e escudo", "ataque com escudo", "quebrar aprimorado", "derrubar aprimorado"
)




from .synergy_damage_analyzer import AnalisadorSinergiaEDanoT20

class ValidadorFichaTemplate(ABC):
    def validar_ficha_completa(self, ficha: FichaPersonagem) -> Tuple[bool, List[str]]:
        violacoes: List[str] = []
        violacoes.extend(self._validar_identidade_basica(ficha))
        violacoes.extend(self._validar_compatibilidade_devocao(ficha))
        violacoes.extend(self._validar_pre_requisitos_poderes(ficha))
        violacoes.extend(self._validar_circulo_magias(ficha))
        violacoes.extend(self._validar_limite_carga(ficha))
        ficha.validacoes_csp = violacoes
        return len(violacoes) == 0, violacoes

    @abstractmethod
    def _validar_identidade_basica(self, ficha: FichaPersonagem) -> List[str]: pass
    @abstractmethod
    def _validar_compatibilidade_devocao(self, ficha: FichaPersonagem) -> List[str]: pass
    @abstractmethod
    def _validar_pre_requisitos_poderes(self, ficha: FichaPersonagem) -> List[str]: pass
    @abstractmethod
    def _validar_circulo_magias(self, ficha: FichaPersonagem) -> List[str]: pass
    @abstractmethod
    def _validar_limite_carga(self, ficha: FichaPersonagem) -> List[str]: pass


class MotorValidacaoCSP(ValidadorFichaTemplate):
    @staticmethod
    def deus_permite_raca_classe(deus: Deus, raca: Optional[Raca], classe: Optional[Classe]) -> bool:
        if classe and "paladino" in classe.nome.lower():
            # Regra Oficial Tormenta20 Edição Jogo do Ano (Cap. 1, p. 81): Paladino só pode ser devoto destas 8 divindades!
            return deus.nome.strip().lower() in (
                "azgher", "khalmyr", "lena", "lin-wu", "marah", "tanna-toh", "thyatis", "valkaria"
            )
        if classe and "druida" in classe.nome.lower():
            return deus.nome.strip().lower() in ("allihanna", "megalokk", "oceano")
        if classe and ("clérigo" in classe.nome.lower() or "clerigo" in classe.nome.lower()):
            return True
        permitidos = deus.devotos_permitidos.lower()
        if any(w in permitidos for w in ("quaisquer", "todas", "todos")):
            return True
        radicais = []
        if raca:
            radicais.extend([raca.nome.lower()[:4], raca.nome.lower()[:2] + "õe"])
        if classe:
            radicais.append(classe.nome.lower()[:5])
        return any(rad in permitidos for rad in radicais)

    def _validar_identidade_basica(self, ficha: FichaPersonagem) -> List[str]:
        erros = []
        if not ficha.raca:
            erros.append("[CSP:Dominio] Raça não selecionada.")
        if not ficha.classe:
            erros.append("[CSP:Dominio] Classe não selecionada.")
        if not (1 <= ficha.nivel <= 20):
            erros.append(f"[CSP:Dominio] Nível {ficha.nivel} fora do domínio [1..20].")
        if ficha.raca and ficha.raca.nome.lower() == "golem" and ficha.origem is not None:
            erros.append("[CSP:RacaGolem] Golem possui a habilidade 'Sem Origem' (p. 22) e não pode ter uma Origem comum (recebe Propósito de Criação).")
        # Regra Oficial T20 JdA (p. 27): Osteon possui Memória Póstuma E TAMBÉM escolhe uma Origem normalmente (apenas Golem tem 'Sem Origem').
        return erros

    def _validar_compatibilidade_devocao(self, ficha: FichaPersonagem) -> List[str]:
        if not ficha.deus or not ficha.raca or not ficha.classe:
            return []
        if not self.deus_permite_raca_classe(ficha.deus, ficha.raca, ficha.classe):
            return [
                f"[CSP:Devocao] {ficha.deus.nome} permite apenas ({ficha.deus.devotos_permitidos}), "
                f"incompatível com {ficha.raca.nome} {ficha.classe.nome}."
            ]
        return []

    def _validar_pre_requisitos_poderes(self, ficha: FichaPersonagem) -> List[str]:
        erros = []
        for poder in ficha.todos_os_poderes():
            if poder.eh_poder_classe and ficha.classe:
                classes_possuidas = {c.nome.lower() for c, nv in ficha.obter_classes_e_niveis() if nv >= 1}
                cat_low = poder.categoria_ou_classe.lower()
                if cat_low != "todas" and cat_low not in classes_possuidas:
                    erros.append(f"[CSP:ClassePoder] '{poder.nome}' é exclusivo de {poder.categoria_ou_classe} (classes atuais: {ficha.resumo_classes_multiclasse()}).")
            espec = InterpretadorPreRequisitosCSP.compilar(poder.pre_requisitos)
            ok, motivo = espec.eh_satisfeita_por(ficha)
            if not ok:
                erros.append(f"[CSP:PreRequisito] Poder '{poder.nome}' requer: {motivo}.")
            # Verifica conflito de estilo de combate (ex: Arqueiro vs Destruidor)
            ficha_sem_atual = copy.copy(ficha)
            ficha_sem_atual.poderes_classe = [p for p in ficha.poderes_classe if p != poder]
            ficha_sem_atual.poderes_gerais = [p for p in ficha.poderes_gerais if p != poder]
            ok_est, mot_est = AnalisadorSinergiaEDanoT20.verificar_conflito_estilo_poder(ficha_sem_atual, poder)
            if not ok_est:
                erros.append(f"[CSP:ConflitoEstilo] {mot_est}.")
        return erros

    def _validar_circulo_magias(self, ficha: FichaPersonagem) -> List[str]:
        erros = []
        circ_max = ficha.circulo_maximo_permitido()
        for mag in ficha.magias_conhecidas:
            if mag.circulo > circ_max:
                erros.append(f"[CSP:Magia] '{mag.nome}' ({mag.circulo}º círculo) excede o limite ({circ_max}º círculo).")
        return erros

    def _validar_limite_carga(self, ficha: FichaPersonagem) -> List[str]:
        erros = []
        if ficha.carga_atual > ficha.carga_maxima:
            erros.append(f"[CSP:Carga] Sobrecarga ({ficha.carga_atual:.1f}/{ficha.carga_maxima:.1f} espaços).")
        # Valida proficiências dos itens equipados (Arma, Armadura e Escudo)
        for item_eq in (ficha.arma_equipada, ficha.armadura_equipada, ficha.escudo_equipado):
            if item_eq:
                ok_p, mot_p = ficha.tem_proficiencia_item(item_eq)
                if not ok_p:
                    erros.append(f"[CSP:Proficiencia] Sem proficiência para '{item_eq.nome}': {mot_p}.")
        if ficha.classe and ficha.classe.nome.lower() == "arcanista" and ficha.armadura_equipada:
            if not ficha.possui_poder("Magia Discreta"):
                erros.append(f"[CSP:ArmaduraArcana] Arcanista vestindo '{ficha.armadura_equipada.nome}' sem 'Magia Discreta' sofre falha de conjuração arcana.")
        return erros

