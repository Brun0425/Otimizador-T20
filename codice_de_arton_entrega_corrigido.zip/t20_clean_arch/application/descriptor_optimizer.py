# -*- coding: utf-8 -*-
"""
Motor de Otimização v77 — 100% Intrínseco às Estatísticas do Personagem (ZERO Dados de Inimigo).
Avalia combinações de descritores usando exclusivamente Ataque, Dano Normal, Chance/Dano Crítico (1d20 ou 2d20 max),
CD/Dano/Área de Magias, PV/Defesa/RD/Resistências do herói, Suporte em Grupo e Sustentabilidade de PM.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


@dataclass(frozen=True)
class DescritorHabilidadeT20:
    id_check: str
    nome: str
    tipo_alvo: str = "GERAL"
    acao: str = "PASSIVA"
    custo_pm: int = 0
    atq: float = 0.0
    atq_por_atrib: Optional[str] = None
    dano_fixo: float = 0.0
    dano_por_atrib: Optional[str] = None
    dados_extra_media: float = 0.0
    margem_crit: int = 0
    mult_crit: int = 0
    usa_2d20_melhor: bool = False
    ataques_extra: float = 0.0
    defesa: float = 0.0
    defesa_por_atrib: Optional[str] = None
    rd: float = 0.0
    pv_por_nivel: float = 0.0
    pm_extra: float = 0.0
    cura_media: float = 0.0
    buff_grupo_atq: float = 0.0
    buff_grupo_dano: float = 0.0
    buff_grupo_def: float = 0.0
    cd_magia: float = 0.0
    acao_livre_magia: bool = False
    prereq_checks: Tuple[str, ...] = field(default_factory=tuple)
    condicionalidade: str = "SEMPRE_ATIVO"  # SEMPRE_ATIVO | FREQUENTE | SITUACIONAL | EXTREMAMENTE_CONDICIONAL
    fator_aplicabilidade: float = 1.0
    nicho_condicional: str = ""


class MotorDescritoresNumericosT20:
    """Calcula a força da build usando EXCLUSIVAMENTE as estatísticas do próprio personagem (zero parâmetros de inimigo)."""

    @staticmethod
    def avaliar_combinacao(
        nivel: int,
        atr: Dict[str, int],
        checks: Set[str],
        descritores: List[DescritorHabilidadeT20],
        pv_base: float,
        pm_base: float,
        def_base: float,
        arma_dado_media: float,
        arma_margem_base: int = 20,
        arma_mult_base: int = 2,
        perfil: str = "DPR",
    ) -> Dict[str, float]:
        atq_total = (nivel // 2) + (2 if nivel < 7 else (4 if nivel < 15 else 6)) + max(
            atr.get("FOR", 0),
            atr.get("DES", 0) if ("check_acuidade" in checks or "check_arma_distancia" in checks) else 0,
        )
        dano_fixo = float(atr.get("FOR", 0) if "check_arma_distancia" not in checks else 0)
        dados_extra = 0.0
        margem_crit = arma_margem_base
        mult_crit = arma_mult_base
        ataques_por_rodada = 1.0
        usa_2d20 = False
        def_total = def_base
        rd_total = 0.0
        pv_total = pv_base
        pm_total = pm_base
        cura_rodada = 0.0
        buff_atq_grp = 0.0
        buff_dano_grp = 0.0
        buff_def_grp = 0.0
        cd_bonus = 0.0
        pm_por_rodada = 0.0

        for d in descritores:
            if d.tipo_alvo == "DESARMADO" and "check_arma_desarmada" not in checks:
                continue
            if d.tipo_alvo == "DUAS_MAOS" and "check_arma_duas_maos" not in checks:
                continue
            if d.tipo_alvo == "DISTANCIA" and "check_arma_distancia" not in checks:
                continue
            if d.tipo_alvo == "ESCUDO" and "check_escudo" not in checks:
                continue

            fc = max(0.05, min(1.0, d.fator_aplicabilidade))
            atq_total += d.atq * fc
            if d.atq_por_atrib:
                atq_total += max(0, atr.get(d.atq_por_atrib, 0))
            dano_fixo += d.dano_fixo * fc
            if d.dano_por_atrib:
                dano_fixo += max(0, atr.get(d.dano_por_atrib, 0))
            dados_extra += d.dados_extra_media * fc
            margem_crit = max(12, margem_crit - d.margem_crit)
            mult_crit += d.mult_crit
            if d.usa_2d20_melhor:
                usa_2d20 = True
            ataques_por_rodada += d.ataques_extra
            def_total += d.defesa * fc
            if d.defesa_por_atrib:
                def_total += max(0, atr.get(d.defesa_por_atrib, 0))
            rd_total += d.rd * fc
            pv_total += d.pv_por_nivel * nivel
            pm_total += d.pm_extra
            cura_rodada += d.cura_media
            buff_atq_grp += d.buff_grupo_atq
            buff_dano_grp += d.buff_grupo_dano
            buff_def_grp += d.buff_grupo_def
            cd_bonus += d.cd_magia
            pm_por_rodada += d.custo_pm

        # Sustentabilidade de PM própria em 4 rodadas
        fator_sust = min(1.0, pm_total / max(1.0, pm_por_rodada * 4.0)) if pm_por_rodada > 0 else 1.0

        # Estatísticas intrínsecas de rolagem (1d20 média 10.5 | 2d20 max média 13.825) e chance intrínseca de crítico
        media_dado_d20 = 13.825 if usa_2d20 else 10.5
        rolagem_atq_media = media_dado_d20 + atq_total
        p_crit_1d = max(0.05, min(0.50, (21 - margem_crit) / 20.0))
        p_crit = (1.0 - (1.0 - p_crit_1d) ** 2) if usa_2d20 else p_crit_1d

        dano_normal = max(1.0, arma_dado_media + dano_fixo + dados_extra)
        dano_critico = max(1.0, (arma_dado_media + dano_fixo) * mult_crit + dados_extra)
        dano_medio_por_golpe = (1.0 - p_crit) * dano_normal + p_crit * dano_critico

        # Índice Ofensivo Intrínseco (100% baseado no Ataque, Dano, Crítico, 2d20 e PM do personagem)
        fator_precisao_prop = 1.0 + max(0.0, rolagem_atq_media - 10.5) * 0.032
        dpr_intrinseco = ataques_por_rodada * dano_medio_por_golpe * fator_precisao_prop * (0.65 + 0.35 * fator_sust)

        # Sobrevivência Intrínseca (100% PV, Defesa, RD e Resistências do próprio personagem)
        sobrevivencia_prop = (pv_total * (1.0 + max(0.0, def_total - 10.0) * 0.045) + rd_total * 14.0) / 10.0

        # Valor de Suporte Intrínseco (apenas buffs e curas gerados pelo personagem)
        valor_suporte = (buff_atq_grp * 9.0) + (buff_dano_grp * 7.5) + (buff_def_grp * 6.5) + (cura_rodada * 1.1)

        pesos = {
            "DPR": (2.8, 1.4, 0.8, 1.0),
            "TANQUE": (1.0, 4.8, 1.2, 0.8),
            "SUPORTE": (0.8, 2.4, 3.6, 2.0),
            "MAGIA": (2.2, 1.4, 1.3, 3.2),
        }.get(perfil.upper(), (2.2, 1.8, 1.4, 1.4))

        score = (
            dpr_intrinseco * pesos[0]
            + sobrevivencia_prop * pesos[1]
            + valor_suporte * pesos[2]
            + (pm_total * 0.45 + cd_bonus * 6.5) * pesos[3]
        )
        return {
            "score": round(score, 2),
            "dpr": round(dpr_intrinseco, 2),
            "rolagem_atq_media": round(rolagem_atq_media, 2),
            "sobrevivencia": round(sobrevivencia_prop, 2),
            "suporte": round(valor_suporte, 2),
            "p_crit_pct": round(p_crit * 100.0, 1),
            "fator_pm": round(fator_sust * 100.0, 1),
        }
