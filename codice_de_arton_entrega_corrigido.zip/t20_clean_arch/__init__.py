# -*- coding: utf-8 -*-
"""
Pacote Principal `t20_clean_arch` — Arquitetura Limpa (), SOLID e Padrões GoF
para o Sistema de Criação, Otimização (CSP + MCTS + Deep RL) e Arena Tática de Tormenta20 Edição Jogo do Ano.
"""
from .domain import *
from .infrastructure import *
from .application import *
from .presentation import *

__version__ = "37.0.0-clean-arch"
