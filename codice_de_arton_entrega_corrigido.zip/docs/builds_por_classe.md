# Enciclopédia de Builds Ótimas por Classe e Função — Códice de Arton

**Autores:** Bruno Otávio Passini e João Victor Marquesan (Engenharia da Computação — FHO, IA I 2026)  
**Base de Regras:** Tormenta20 — Edição Jogo do Ano (v1.3) | **Nível de Referência:** Nível 20 (Comparativo Equipamento Comum vs. Superiores + Mágicos)

---

## 1. Auditoria Matemática Completa dos Fatores de Cálculo

Todos os fatores abaixo foram auditados diretamente em `02_monte_carlo_and_sheet_ui.js` (linhas 805–879 e 3262–3340) e `05_turn_arena_engine.js`:

### 1.1 Dano Marcial (`dprMarcial`)
- **Modificador de Ataque (`atqBase`)**: entra tanto na chance de acerto (`pHit`) quanto no multiplicador proporcional de precisão `fatorPrecisaoProp = 1 + max(0, rolagemAtqMedia - 10,5) × 0,032`, considerando `10,5` (1d20) ou `13,825` (2d20 melhor).
- **Dano Base, Fixo e Dados Extras**: `danoNormal = armaDadoMedia + danoFixo + dadosExtra`.
- **Margem de Ameaça e Multiplicador de Crítico**: `pCrit1 = clamp((21 - margemCrit)/20, 0,05, 0,50)` (ou `1 - (1 - pCrit1)²` com 2d20). No crítico padrão (JdA p. 231), multiplica-se `(armaDadoMedia + danoFixo) × multCrit + dadosExtra`; com o encanto **Lancinante** (p. 336), `dadosExtra` também multiplica. O golpe médio é `(1 - pCrit)×danoNormal + pCrit×danoCritico`.
- **Quantidade de Ataques e Recarga**: `atqEfetivosRec × fatorCadencia × fatorRecMov` (armas de fogo/bestas sem *Saque Rápido* reduzem cadência para 50% ou sofrem `0,92×` por gastar Ação de Movimento recarregando; *Disparo Rápido* exige recarga livre).

### 1.2 Sobrevivência e Cálculo Defensivo (`ehpTurnos`)
- **Fórmula exata (linha 860)**:
  `ehpTurnos = (pvTotal × (1 + max(0, defTotal - 10) × 0,045) + rdTotal × pesoRdTatico + somaResHeroi × 2,5) / 10`
- **Defesa (`defTotal`)**: multiplica o valor efetivo de cada PV em `+4,5%` por ponto acima de 10 (respeitando bloqueio de DES, *Insolência*, *Autoconfiança*, *Couraceiro* em Armadura Pesada).
- **Testes de Resistência (`Fortitude + Reflexos + Vontade`)**: somam `somaResHeroi × 2,5` no numerador do EHP (valorizando *Aura Sagrada* do Paladino, *Manto da Resistência*, etc.).
- **Redução de Dano (`rdTotal`)**: peso `14,0` em linha de frente/tanques e `7,7` (`0,55×`) em builds à distância não-tanque (calibração v96).
- **PV (`pvTotal`)**: base multiplicada diretamente pela Defesa efetiva.

### 1.3 Dano de Magias (`dprMagico`)
- **Dano e Aprimoramentos**: calculado por `detalharAprimoramentoMagiaJS` respeitando o teto de PM por turno (`nivel + bonusLimitePm`).
- **CD (`cdBonus`)**: na atual, o bônus de CD (esotéricos *Poderoso*, *Manto do Arquimago*, catalisadores e atributo-chave) calcula a razão real de falha no Teste de Resistência (`multCdRealV100 = (0,5 + 0,5·pFalhaFinal) / (0,5 + 0,5·pFalhaBase)`), refletindo dano cheio na falha vs. metade no sucesso (JdA p. 171).
- **Área (AoE)**: magias de área recebem multiplicador de múltiplos alvos no descritor mágico (`compilarDescritorMagiaEAprimoramentoV73JS`) e prioridade automática na Mesa Online 4vN sempre que houver `≥ 2` inimigos vivos.

### 1.4 Alcance, Movimentação e Custo de Mana (PM)
- **Custo de Mana (PM)**: penaliza builds insustentáveis em janela de 4 rodadas via `fatorPM = min(1, pmTotal / (pmPorRodada × 4))` (`0,65 + 0,35×fatorPM` para marciais e `0,45 + 0,55×fatorPMMagia` para conjuradores), além do limite rígido de PM por turno em combate (`calcularLimitePmTurnoT20JS`).
- **Alcance e Movimentação**: no otimizador de ficha, entram indiretamente via recarga (`fatorCadencia`, `fatorRecMov`), penalidade de armadura leve (`pesoPen = 0,9` para Arqueiros/Ladinos) e peso reduzido de RD à distância (`0,55×`). A simulação física explícita de distância (9 m iniciais, arena de 45 m, *uptime* e *kiting*) ocorre no **Simulador Espacial** e nos **VTTs 2D** (Arena e Mesas Online), onde o deslocamento (6 m vs. 9 m vs. 12 m) determina se o atacante consegue bater sem perder o turno em Investida.

---

## 2. Builds Ótimas por Classe e por Função (Todas as 14 Classes — Nível 20)

### Arcanista *(Melhor Função Geral: DPR Máximo (Dano Bruto) — Score 2398.7)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Kliren / Escravo / Wynna | Ataque desarmado / Sem Armadura / Nenhum | 386.7 → **499.1** | EHP 40.0 · Def 13 · PV 106 · PM 157 | **2398.7** |
| **Tanque / Sobrevivência** | Anão / Escravo / Aharadak | Ataque desarmado / Sem Armadura / Nenhum | 225.0 → **348.8** | EHP 74.6 · Def 13 · PV 168 · PM 154 | **1556.6** |
| **Suporte / Controle** | Kliren / Eremita / Wynna | Ataque desarmado / Sem Armadura / Nenhum | 260.4 → **366.2** | EHP 48.7 · Def 14 · PV 126 · PM 156 | **855.1** |

- **Build Destaque (DPR Máximo (Dano Bruto))**: Atributos `FOR -2, DES 1, CON 3, INT 7, SAB 0, CAR -1` | TRs: Fort `+21`, Refl `+19`, Vont `+16` | Poderes-chave: *Magia Ilimitada, Aumento de Atributo, Especialista em Escola, Fortalecimento Arcano, Arcano de Batalha, Magia Acelerada* | Magias: *Bola de Fogo, Relâmpago, Toque Chocante, Explosão de Chamas, Jato Corrosivo*.
- **Pontos Fortes**: Maior teto de DPR mágico e versatilidade de controle/área (5º círculo); escala fortemente na atual com Esotéricos Superiores/Mágicos, Catalisadores, +CD e +Limite de PM.
- **Pontos Fracos**: PV muito baixo, proibido de usar armaduras (Falha Arcana) e alta dependência de reserva de PM e reações defensivas (*Campo de Força*, *Armadura Arcana*).
- **O que mais influenciou os cálculos**: DPR mágico dominado por `multCdRealV100` (escala de CD no TR), `+Limite PM` convertido em dados extras e `fatorPMMagia` em janela de 4 rodadas.

### Bárbaro *(Melhor Função Geral: Tanque / Sobrevivência — Score 2017.5)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Minotauro / Minerador / Arsenal | Marreta / Couraça / Nenhum | 186.1 → **276.4** | EHP 103.3 · Def 16 · PV 238 · PM 60 | **1467.7** |
| **Tanque / Sobrevivência** | Anão / Escravo / Arsenal | Machado anão / Couraça / Escudo pesado | 141.3 → **231.0** | EHP 116.9 · Def 18 · PV 260 · PM 70 | **2017.5** |
| **Suporte / Controle** | Minotauro / Selvagem / Arsenal | Machado de batalha / Couraça / Escudo pesado | 154.1 → **248.7** | EHP 116.7 · Def 20 · PV 238 · PM 60 | **884.2** |

- **Build Destaque (Tanque / Sobrevivência)**: Atributos `FOR 5, DES -1, CON 5, INT 0, SAB 1, CAR -2` | TRs: Fort `+23`, Refl `+15`, Vont `+19` | Poderes-chave: *Sangue de Ferro, Pele de Ferro, Pele de Aço, Alma de Bronze, Espírito Inquebrável, Estilo de Arma e Escudo*.
- **Pontos Fortes**: Altíssimo dano bruto corpo a corpo com armas de duas mãos (*Fúria*, *Crítico Brutal*), grande reserva de PV e boa Redução de Dano natural.
- **Pontos Fracos**: Defesa estruturalmente menor (sem Armadura Pesada por padrão), *Fúria* impede lançar magias (JdA p. 40) e Vontade vulnerável a controle mental.
- **O que mais influenciou os cálculos**: Multiplicação de `danoMedioPorGolpe` (margem/multiplicador + *Lancinante*) e `pvTotal` + `rdTotal × 14,0` no EHP.

### Bardo *(Melhor Função Geral: DPR Máximo (Dano Bruto) — Score 2345.2)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Qareen / Escravo / Wynna | Ataque desarmado / Couraça / Nenhum | 334.1 → **482.5** | EHP 47.0 · Def 20 · PV 129 · PM 97 | **2345.2** |
| **Tanque / Sobrevivência** | Anão / Escravo / Marah | Ataque desarmado / Couraça / Nenhum | 204.7 → **332.9** | EHP 59.0 · Def 20 · PV 191 · PM 94 | **1351.5** |
| **Suporte / Controle** | Qareen / Eremita / Lena | Ataque desarmado / Couraça / Nenhum | 208.6 → **338.8** | EHP 57.3 · Def 21 · PV 149 · PM 86 | **1347.7** |

- **Build Destaque (DPR Máximo (Dano Bruto))**: Atributos `FOR -1, DES 1, CON 3, INT 1, SAB -2, CAR 7` | TRs: Fort `+21`, Refl `+19`, Vont `+14` | Poderes-chave: *Magia Ilimitada, Aumento de Atributo, Bênção do Mana, Arte Mágica, Magia Acelerada, Teurgista Místico* | Magias: *Bola de Fogo, Relâmpago, Toque Chocante, Explosão de Chamas, Jato Corrosivo*.
- **Pontos Fortes**: Excelente equilíbrio entre buffs coletivos (*Inspiração*), magias arcanas até 4º círculo (3 escolas otimizadas via busca combinatória de 56 trios) e bom DPR mágico com esotéricos.
- **Pontos Fracos**: PV e Defesa moderados; precisa equilibrar ações entre buff de grupo na Rodada 1 e dano/controle.
- **O que mais influenciou os cálculos**: Combinação de `valorSuporte` (*Inspiração* + *Oração*), busca exata de escolas mágicas e `multCdRealV100` + catalisadores.

### Bucaneiro *(Melhor Função Geral: Tanque / Sobrevivência — Score 1025.1)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Goblin / Minerador / Valkaria | Marreta / Couraça / Nenhum | 26.7 → **51.5** | EHP 70.6 · Def 24 · PV 152 · PM 60 | **390.2** |
| **Tanque / Sobrevivência** | Goblin / Escravo / Aharadak | Marreta / Couraça / Nenhum | 22.5 → **45.2** | EHP 63.3 · Def 25 · PV 132 · PM 60 | **1025.1** |
| **Suporte / Controle** | Goblin / Selvagem / Valkaria | Marreta / Couraça / Nenhum | 23.7 → **47.6** | EHP 70.6 · Def 25 · PV 152 · PM 60 | **494.7** |

- **Build Destaque (Tanque / Sobrevivência)**: Atributos `FOR -1, DES 7, CON 2, INT 1, SAB 0, CAR 1` | TRs: Fort `+22`, Refl `+25`, Vont `+16` | Poderes-chave: *Combate Defensivo, Esquiva, Aumento de Atributo, Afinidade com a Tormenta, Lobo Solitário, Reflexos de Combate*.
- **Pontos Fortes**: Forte em mobilidade, margem de ameaça expandida (*Audácia*, *Esgrimista*, *Insolência* em armadura leve) e uso de armas ágeis ou de fogo.
- **Pontos Fracos**: DPR base mais dependente de críticos e itens superiores/mágicos; perde *Insolência* se tentar usar Armadura Pesada.
- **O que mais influenciou os cálculos**: `pCrit` (margem de ameaça ampliada), `fatorPrecisaoProp` e impacto elevado de melhorias/encantos sobre base moderada.

### Caçador *(Melhor Função Geral: Tanque / Sobrevivência — Score 1190.3)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Minotauro / Minerador / Arsenal | Marreta / Couraça / Nenhum | 47.5 → **75.7** | EHP 66.5 · Def 16 · PV 172 · PM 90 | **499.7** |
| **Tanque / Sobrevivência** | Anão / Escravo / Aharadak | Machado anão / Couraça / Escudo pesado | 35.5 → **64.2** | EHP 72.4 · Def 18 · PV 194 · PM 90 | **1190.3** |
| **Suporte / Controle** | Minotauro / Selvagem / Arsenal | Machado de batalha / Couraça / Escudo pesado | 41.9 → **72.5** | EHP 77.3 · Def 20 · PV 172 · PM 90 | **593.3** |

- **Build Destaque (Tanque / Sobrevivência)**: Atributos `FOR 5, DES -1, CON 4, INT 0, SAB 3, CAR -2` | TRs: Fort `+22`, Refl `+15`, Vont `+21` | Poderes-chave: *Estilo de Arma e Escudo, Bloqueio com Escudo, Afinidade com a Tormenta, Vontade de Ferro, Aumento de Atributo, Sentidos Aguçados*.
- **Pontos Fortes**: Alto volume de ataques por rodada (*Marca da Presa*, *Ambidestria* ou *Disparo Rápido*), ótimo alcance e boa consistência contra alvo único.
- **Pontos Fracos**: Menor RD natural e menor utilidade de suporte em grupo; em builds à distância, RD recebe peso tático reduzido (`0,55×`).
- **O que mais influenciou os cálculos**: `atqEfetivosRec × fatorCadencia`, bônus de dados extras por golpe e penalidade de armadura leve (`pesoPen = 0,9`).

### Cavaleiro *(Melhor Função Geral: Tanque / Sobrevivência — Score 1726.0)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Minotauro / Minerador / Lin-Wu | Marreta / Armadura completa / Nenhum | 60.1 → **91.6** | EHP 89.2 · Def 23 · PV 215 · PM 60 | **609.3** |
| **Tanque / Sobrevivência** | Anão / Escravo / Arsenal | Machado anão / Armadura completa / Escudo pesado | 38.5 → **67.8** | EHP 108.1 · Def 26 · PV 237 · PM 70 | **1726.0** |
| **Suporte / Controle** | Minotauro / Selvagem / Thyatis | Machado de batalha / Armadura completa / Escudo pesado | 38.1 → **67.6** | EHP 102.2 · Def 27 · PV 215 · PM 60 | **918.3** |

- **Build Destaque (Tanque / Sobrevivência)**: Atributos `FOR 5, DES -1, CON 5, INT -1, SAB 1, CAR -1` | TRs: Fort `+23`, Refl `+9`, Vont `+13` | Poderes-chave: *Desprezar os Covardes, Especialização em Armadura, Sangue de Ferro, Encouraçado, Estilo de Arma e Escudo, Bloqueio com Escudo*.
- **Pontos Fortes**: Um dos maiores tetos de Defesa e EHP do sistema (*Baluarte*, *Armadura Pesada*, escudo e *Provocação* no VTT 4vN).
- **Pontos Fracos**: Menor DPR bruto entre os marciais puros e penalidade de movimentação/furtividade com *Armadura Completa*.
- **O que mais influenciou os cálculos**: Peso dominante de `wEHP = 15,0` no arquétipo Tanque (`pvTotal × (1 + (Def-10)×0,045) + rdTotal × 14,0`).

### Clérigo *(Melhor Função Geral: Suporte / Controle — Score 2809.0)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Anão / Escravo / Wynna | Ataque desarmado / Armadura completa / Escudo pesado | 291.4 → **426.7** | EHP 81.0 · Def 26 · PV 214 · PM 126 | **2238.5** |
| **Tanque / Sobrevivência** | Anão / Escravo / Arsenal | Ataque desarmado / Armadura completa / Escudo pesado | 283.4 → **418.7** | EHP 87.4 · Def 26 · PV 214 · PM 116 | **2040.8** |
| **Suporte / Controle** | Anão / Eremita / Thyatis | Ataque desarmado / Armadura completa / Escudo pesado | 84.6 → **172.2** | EHP 91.2 · Def 26 · PV 234 · PM 116 | **2809.0** |

- **Build Destaque (Suporte / Controle)**: Atributos `FOR 0, DES -2, CON 5, INT 0, SAB 6, CAR -1` | TRs: Fort `+23`, Refl `+8`, Vont `+24` | Poderes-chave: *Magia Ilimitada, Dom da Imortalidade, Dom da Ressurreição, Prece de Combate, Aumento de Atributo, Vitalidade* | Magias: *Oração, Bênção, Curar Ferimentos, Proteção contra Magia, Consagrar*.
- **Pontos Fortes**: Maior pontuação de Suporte/Sobrevivência do jogo (*Oração*, *Bênção*, *Curar Ferimentos*, proficiência em Armadura Pesada e Escudos + 5º círculo divino).
- **Pontos Fracos**: DPR ofensivo puro menor que Arcanista e marciais dedicados; forte consumo de PM em combates longos.
- **O que mais influenciou os cálculos**: `valorSuporte` (`buffGrpAtq × 9 + buffGrpDano × 7,5 + curaMedia × 1,1`), Defesa com Armadura Pesada e esotéricos/catalisadores de SAB.

### Druida *(Melhor Função Geral: Suporte / Controle — Score 2541.7)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Anão / Escravo / Allihanna | Ataque desarmado / Gibão de peles / Nenhum | 193.2 → **299.3** | EHP 59.3 · Def 15 · PV 194 · PM 94 | **1597.2** |
| **Tanque / Sobrevivência** | Anão / Escravo / Allihanna | Ataque desarmado / Gibão de peles / Nenhum | 191.2 → **299.5** | EHP 71.6 · Def 19 · PV 214 · PM 95 | **1659.7** |
| **Suporte / Controle** | Anão / Eremita / Allihanna | Ataque desarmado / Gibão de peles / Nenhum | 191.2 → **299.5** | EHP 80.9 · Def 19 · PV 234 · PM 95 | **2541.7** |

- **Build Destaque (Suporte / Controle)**: Atributos `FOR 0, DES 1, CON 5, INT 0, SAB 5, CAR -1` | TRs: Fort `+23`, Refl `+13`, Vont `+23` | Poderes-chave: *Magia Ilimitada, Aumento de Atributo, Vontade de Ferro, Vitalidade, Sortudo, Esquiva* | Magias: *Oração, Bênção, Curar Ferimentos, Proteção contra Magia, Consagrar*.
- **Pontos Fortes**: Alta adaptabilidade (Conjurador Divino, Suporte de cura/buff ou Forma Selvagem) com excelente EHP e 3 escolas escolhidas via combinação exata.
- **Pontos Fracos**: Proibido de usar armaduras metálicas (JdA p. 61), limitando Defesa passiva sem magias defensivas.
- **O que mais influenciou os cálculos**: Restrição CSP de metal, busca exata das 56 combinações de escolas e equilíbrio entre `valorSuporte`, `ehpTurnos` e `dprMagico`.

### Guerreiro *(Melhor Função Geral: Tanque / Sobrevivência — Score 1825.9)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Minotauro / Minerador / Lin-Wu | Machado de guerra / Armadura completa / Nenhum | 209.8 → **355.7** | EHP 82.2 · Def 23 · PV 215 · PM 60 | **1784.0** |
| **Tanque / Sobrevivência** | Anão / Escravo / Arsenal | Machado anão / Armadura completa / Escudo pesado | 162.4 → **272.7** | EHP 101.1 · Def 26 · PV 237 · PM 70 | **1825.9** |
| **Suporte / Controle** | Minotauro / Selvagem / Thyatis | Machado de batalha / Armadura completa / Escudo pesado | 162.8 → **274.1** | EHP 95.2 · Def 27 · PV 215 · PM 60 | **1048.5** |

- **Build Destaque (Tanque / Sobrevivência)**: Atributos `FOR 5, DES -1, CON 5, INT 0, SAB 1, CAR -2` | TRs: Fort `+23`, Refl `+9`, Vont `+13` | Poderes-chave: *Especialização em Armadura, Sangue de Ferro, Encouraçado, Estilo de Arma e Escudo, Bloqueio com Escudo, Golpe Pessoal*.
- **Pontos Fortes**: Maior consistência marcial do jogo (*Ataque Especial*, *Ataque Extra*, *Durão* cortando dano pela metade) com versatilidade total (Duas Mãos, Arqueiro ou Tanque).
- **Pontos Fracos**: Consumo acelerado de PM se abusar de *Ataque Especial* e *Durão* sem gestão de mana (`fatorPM`).
- **O que mais influenciou os cálculos**: `atqEfetivosRec` (*Ataque Extra* + *Veloz*), `fatorPrecisaoProp` via *Ataque Especial* e sustentabilidade `fatorPM` em 4 rodadas.

### Inventor *(Melhor Função Geral: Tanque / Sobrevivência — Score 1302.5)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Kliren / Minerador / Thyatis | Tacape / Couraça / Nenhum | 36.3 → **65.3** | EHP 68.1 · Def 24 · PV 149 · PM 80 | **474.7** |
| **Tanque / Sobrevivência** | Anão / Escravo / Aharadak | Machado anão / Couraça / Nenhum | 35.6 → **66.5** | EHP 77.8 · Def 23 · PV 191 · PM 90 | **1302.5** |
| **Suporte / Controle** | Kliren / Selvagem / Thyatis | Tacape / Couraça / Nenhum | 30.6 → **57.1** | EHP 70.6 · Def 23 · PV 149 · PM 80 | **887.1** |

- **Build Destaque (Tanque / Sobrevivência)**: Atributos `FOR 0, DES 1, CON 5, INT 4, SAB 1, CAR 0` | TRs: Fort `+23`, Refl `+13`, Vont `+19` | Poderes-chave: *Combate Defensivo, Esquiva, Couraceiro, Encouraçado, Inexpugnável, Estilo de Uma Arma*.
- **Pontos Fortes**: Altíssima sinergia com INT em ataque/CD/ofícios, acesso a armas de fogo, engenhocas e *Blindagem* (+INT na Defesa mesmo em Armadura Pesada).
- **Pontos Fracos**: Recarga de Mosquete/Pistola exige *Saque Rápido* para manter cadência cheia; PV base mais baixo que marciais puros.
- **O que mais influenciou os cálculos**: Regra de recarga (`calcularRecargaArmaT20JS`), exceção oficial de *Blindagem* em Armadura Pesada e ganho expressivo de itens.

### Ladino *(Melhor Função Geral: Tanque / Sobrevivência — Score 1364.4)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Goblin / Minerador / Lin-Wu | Tacape / Couro batido / Nenhum | 97.7 → **140.1** | EHP 75.2 · Def 21 · PV 129 · PM 80 | **801.2** |
| **Tanque / Sobrevivência** | Goblin / Escravo / Marah | Foice / Couro batido / Nenhum | 222.6 → **339.4** | EHP 66.3 · Def 22 · PV 109 · PM 80 | **1364.4** |
| **Suporte / Controle** | Goblin / Mateiro / Thyatis | Foice / Couro batido / Nenhum | 222.6 → **339.4** | EHP 75.6 · Def 22 · PV 129 · PM 80 | **984.6** |

- **Build Destaque (Tanque / Sobrevivência)**: Atributos `FOR -1, DES 7, CON 2, INT 3, SAB 0, CAR -2` | TRs: Fort `+22`, Refl `+25`, Vont `+16` | Poderes-chave: *Rolamento Defensivo, Estilo de Duas Armas, Assassinar, Esquiva, Combate Defensivo, Aumento de Atributo*.
- **Pontos Fortes**: Explosão massiva de dados extras em um único golpe (*Ataque Furtivo* + *Assassinar*), excelente sinergia com flanqueamento 2D (`+2`) na Mesa Online.
- **Pontos Fracos**: Dependente de condição de flanqueamento/desprevenido; baixa resistência em linha de frente direta.
- **O que mais influenciou os cálculos**: Dados extras de *Ataque Furtivo* em `danoNormal`, alta penalidade de armadura (`pesoPen = 0,9`) favorecendo Armadura Leve.

### Lutador *(Melhor Função Geral: DPR Máximo (Dano Bruto) — Score 2078.1)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Minotauro / Minerador / Arsenal | Ataque desarmado / Sem Armadura / Nenhum | 271.2 → **421.3** | EHP 82.6 · Def 28 · PV 215 · PM 60 | **2078.1** |
| **Tanque / Sobrevivência** | Anão / Capanga / Arsenal | Ataque desarmado / Sem Armadura / Nenhum | 247.2 → **379.1** | EHP 84.0 · Def 25 · PV 237 · PM 70 | **1672.3** |
| **Suporte / Controle** | Minotauro / Selvagem / Thyatis | Ataque desarmado / Sem Armadura / Nenhum | 289.1 → **441.4** | EHP 75.6 · Def 28 · PV 215 · PM 60 | **1055.3** |

- **Build Destaque (DPR Máximo (Dano Bruto))**: Atributos `FOR 7, DES 0, CON 4, INT 0, SAB -1, CAR -2` | TRs: Fort `+22`, Refl `+16`, Vont `+15` | Poderes-chave: *Trocação, Golpe Imprudente, Até Acertar, Aumento de Atributo, Voadora, Lutador de Chão*.
- **Pontos Fortes**: Altíssimo DPR desarmado (*Briga* escalando passos de dano, *Golpe Relâmpago*, *Trocação*) e boa mobilidade natural sem depender de armas.
- **Pontos Fracos**: Proibido de usar armaduras no otimizador para preservar *Casca Grossa* (+CON na Defesa); alcance estritamente corpo a corpo.
- **O que mais influenciou os cálculos**: Número de ataques por rodada, progressão de passo de dano (`aumentarPassoDanoT20JS`) e *Casca Grossa* no EHP.

### Nobre *(Melhor Função Geral: Suporte / Controle — Score 1521.7)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Qareen / Minerador / Lin-Wu | Marreta / Armadura completa / Nenhum | 37.0 → **63.8** | EHP 69.9 · Def 22 · PV 172 · PM 80 | **496.8** |
| **Tanque / Sobrevivência** | Anão / Escravo / Marah | Machado anão / Armadura completa / Escudo pesado | 16.3 → **39.2** | EHP 83.8 · Def 26 · PV 214 · PM 90 | **1451.6** |
| **Suporte / Controle** | Qareen / Selvagem / Lena | Machado de batalha / Armadura completa / Escudo pesado | 14.8 → **37.8** | EHP 82.2 · Def 26 · PV 172 · PM 80 | **1521.7** |

- **Build Destaque (Suporte / Controle)**: Atributos `FOR 0, DES -1, CON 3, INT 1, SAB -1, CAR 6` | TRs: Fort `+21`, Refl `+15`, Vont `+15` | Poderes-chave: *Liderar pelo Exemplo, Inspirar Confiança, Voz Poderosa, Aura Restauradora, Cura Gentil, Comandar* | Magias: *Leque Cromático*.
- **Pontos Fortes**: Excelente suporte tático (*Gritar Ordens*, *Inspirar Confiança*), ótima Defesa via *Autoconfiança* (CAR no lugar de DES em armadura leve) ou Armadura Pesada.
- **Pontos Fracos**: DPR individual modesto sem multiclasse; *Autoconfiança* é bloqueado se equipar Armadura Pesada (regra v95).
- **O que mais influenciou os cálculos**: `valorSuporte`, escolha dinâmica Armadura Pesada vs. Leve + CAR e ganho proporcional de itens sobre base moderada.

### Paladino *(Melhor Função Geral: Tanque / Sobrevivência — Score 1489.4)*

| Função | Raça / Origem / Deus | Arma / Armadura / Escudo | DPR (Comum → Ambos) | EHP / Def / PV / PM | Score (Ambos) |
| :--- | :--- | :--- | ---: | :--- | ---: |
| **DPR Máximo (Dano Bruto)** | Minotauro / Minerador / Lin-Wu | Marreta / Armadura completa / Nenhum | 133.5 → **182.0** | EHP 66.5 · Def 23 · PV 175 · PM 62 | **985.2** |
| **Tanque / Sobrevivência** | Anão / Escravo / Marah | Machado anão / Armadura completa / Escudo pesado | 89.3 → **136.9** | EHP 85.5 · Def 29 · PV 217 · PM 73 | **1489.4** |
| **Suporte / Controle** | Minotauro / Selvagem / Thyatis | Machado de batalha / Armadura completa / Escudo pesado | 103.6 → **156.0** | EHP 85.0 · Def 30 · PV 195 · PM 63 | **1139.4** |

- **Build Destaque (Tanque / Sobrevivência)**: Atributos `FOR 4, DES -1, CON 4, INT 0, SAB 1, CAR 3` | TRs: Fort `+22`, Refl `+9`, Vont `+19` | Poderes-chave: *Encouraçado, Estilo de Arma e Escudo, Bloqueio com Escudo, Aumento de Atributo, Inexpugnável, Aura de Cura*.
- **Pontos Fortes**: Melhor híbrido ofensivo-defensivo (*Golpe Divino*, *Aura Sagrada* somando CAR nos 3 Testes de Resistência, *Égide Sagrada* com escudo mesmo em Armadura Pesada).
- **Pontos Fracos**: Forte dependência de PM para manter *Golpe Divino* + *Aura* + curas em combates prolongados.
- **O que mais influenciou os cálculos**: `somaResHeroi × 2,5` impulsionado pela *Aura Sagrada*, exceção oficial de *Égide Sagrada* em Armadura Pesada e `fatorPM`.

