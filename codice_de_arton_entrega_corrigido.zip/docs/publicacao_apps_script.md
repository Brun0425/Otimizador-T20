# Passo a Passo: Publicar o Aplicativo Tormenta 20 no Google Apps Script (Link Direto no Celular e PC)

Com esta configuração, você passa a ter um **link web direto (`https://script.google.com/macros/s/.../exec`)** que abre o aplicativo completo no navegador do celular e do computador sem precisar baixar arquivos, e **todas as fichas salvas ficam sincronizadas na nuvem** na aba `Fichas_Salvas` da planilha [Tormenta20 - Base de Dados (MCTS & CSP)](https://docs.google.com/spreadsheets/d/1nOPmuca052rr1UcibWIkRMsm48T0KwzRp0zH7qOZTbg/edit).

---

## 1. Abrir o Editor do Google Apps Script vinculado à Planilha
1. Abra a sua planilha oficial: [Tormenta20 - Base de Dados (MCTS & CSP)](https://docs.google.com/spreadsheets/d/1nOPmuca052rr1UcibWIkRMsm48T0KwzRp0zH7qOZTbg/edit).
2. No menu superior da planilha, clique em **Extensões ➔ Apps Script**.
3. O editor será aberto com um arquivo padrão chamado `Código.gs` (ou `Code.gs`).

## 2. Colar o Backend (`Code.gs`)
1. Apague todo o conteúdo padrão do arquivo `Código.gs` no editor.
2. Abra o arquivo **`Code.gs`** enviado aqui (ou na pasta [Projeto_Tormenta20](https://drive.google.com/drive/folders/1gMf1h3GW1UWHNu1Lm-LX6JrVZCOCX4-c)), copie **todo o conteúdo** e cole dentro do `Código.gs` no Apps Script.
3. Clique no ícone de **Salvar projeto (`Ctrl + S`)**.

## 3. Adicionar o Aplicativo HTML (`index.html`)
1. No painel esquerdo do Apps Script (seção **Arquivos**), clique no botão **`+`** e escolha **HTML**.
2. Digite exatamente o nome **`index`** (o editor criará `index.html`).
3. Apague o conteúdo padrão de `index.html`.
4. Abra o arquivo **`app_web/tormenta20_mobile_app.html`** no seu computador (baixando da pasta [Projeto_Tormenta20](https://drive.google.com/drive/folders/1gMf1h3GW1UWHNu1Lm-LX6JrVZCOCX4-c) ou direto aqui pelo chat), copie **todo o código HTML** (`Ctrl + A`, `Ctrl + C`) e cole dentro do arquivo `index.html` no Apps Script (`Ctrl + V`).
5. Salve com **`Ctrl + S`**.

## 4. Publicar como App da Web (Gerar o Link Direto)
1. No canto superior direito do editor do Apps Script, clique no botão azul **Implantar ➔ Nova implantação**.
2. Ao lado de *Selecionar tipo*, clique na engrenagem **⚙️ ➔ App da Web**.
3. Preencha os campos:
   - **Descrição**: `Tormenta 20 Web App atual`
   - **Executar como**: **Eu (`seu email`)** *(fundamental para gravar na sua planilha)*
   - **Quem pode acessar**: **Somente eu** (uso pessoal seguro no seu PC/celular logado na sua conta Google) ou **Qualquer pessoa** (se quiser compartilhar o link com os jogadores da mesa).
4. Clique em **Implantar**.
5. Na primeira vez, o Google pedirá autorização: clique em **Autorizar acesso** ➔ escolha sua conta Google ➔ **Avançado** ➔ **Acessar projeto (não seguro)** ➔ **Permitir**.
6. Copie a **URL do app da Web** (`https://script.google.com/macros/s/.../exec`).

## 5. Como Usar no Celular e Sincronizar Fichas
* Salve esse link nos **Favoritos** ou toque em **"Adicionar à tela inicial"** no Chrome do celular (ele funcionará como um aplicativo instalado!).
* Ao clicar em **💾 Salvar Ficha**, o app grava automaticamente a ficha completa na aba **`Fichas_Salvas`** da sua planilha do Google Sheets.
* Para abrir uma ficha salva no celular ou no computador, clique em **☁️ Fichas Salvas (Nuvem / Local)** na barra da ficha.
