# Documentação Técnica Vínculo Python ↔ HTML, Interface Visual, Fórmulas, Variáveis e Métodos de Decisão

**Projeto:** Códice de Arton — Otimizador Combinatório e Simulador RL para Tormenta20 (Edição Jogo do Ano v1.3)  
**Autores:** Bruno Otávio Passini e João Victor Marquesan  
**Disciplina:** Inteligência Artificial I — Engenharia da Computação (FHO, 2026)  
**Referências Oficiais:** [Tormenta20: Livro Básico — Edição Jogo do Ano](https://pt.scribd.com/document/887763149/T20-Livro-Basico-Jogo-Do-Ano) | [Poderes Concedidos T20](https://tormenta-collab.fandom.com/pt-br/wiki/Poderes_Concedidos)

---

## 1. Vínculo entre o Código Python e o Código HTML/JavaScript

O sistema opera em uma **arquitetura híbrida de geração estática + execução dual (Servidor Python Local ou 100% Offline no Navegador)**:

1. **Banco de Dados e Entrada (`tormenta20_character_system.py`, `sqlite_repositories.py`, `seed_data.py`)**:
   - Inicializa o banco SQLite (`tormenta20.db`) a partir da semente comprimida em LZMA+Base64 (`seed_data.py`), carregando 14 classes, 18 raças, 35 origens, 20 divindades, 443 poderes, 192 magias, 339 itens e 65 ameaças oficiais do Capítulo 7.
2. **Empacotamento dos 5 Módulos JS (`spa_bundler.py`)**:
   - `carregar_spa_js_engine_template()` concatena em ordem determinística os 5 arquivos de `t20_clean_arch/frontend_spa/`:
     1. `01_core_rules_and_treasure.js`: regras base, Armadura Pesada, resolvedor de acúmulo de fontes (p. 226), esotéricos superiores/mágicos e catalisadores alquímicos.
     2. `02_monte_carlo_and_sheet_ui.js`: motor CSP + MCTS (UCT), avaliação numérica de DPR/EHP/Suporte/Score, otimizador de 10 pontos de atributo, busca de escolas mágicas e matriz de 4 camadas.
     3. `03_deep_rl_and_tree_ui.js`: árvore de decisão SVG, fronteira de Pareto e importância marginal de poderes.
     4. `04_hd2d_sprites_and_audio.js`: renderização SVG dos tokens VTT em escala oficial (`1×1` até Colossal `6×6`) e câmera auto-expansível (`26×14`).
     5. `05_turn_arena_engine.js`: combate em turnos, limite rígido de PM por turno, **RL Caixa-Preta 1v1 (Arena)**, **RL Cooperativo 4vN (Mesas Online)** e painel inline dinâmico de passivas.
3. **Injeção de Dados e Compilação (`web_facade.py` + `styles_css.py`)**:
   - `Tormenta20Facade.pagina_web_completa()` serializa o catálogo completo do SQLite em JSON e o injeta em `__CATALOGO_JSON_INLINE__` dentro do bundle JS, somado ao CSS editorial (`gerar_css_web()`) e ao HTML das 8 abas, exportando o arquivo único **`tormenta20_mobile_app.html`**.
4. **Execução Dual**:
   - **Com Python rodando (`python3 tormenta20_character_system.py`)**: o servidor HTTP recebe rotas `POST` (`/salvar`, `/otimizar`, `/gerar_manual`) e persiste fichas no SQLite (`tormenta20.db`).
   - **100% Offline (abrindo o `.html` no navegador/celular)**: `submeterFormularioHibrido()` intercepta o envio, executa todo o motor CSP + MCTS + RL localmente no navegador usando `__CATALOGO_JSON_INLINE__` e salva no `localStorage`.

---

## 2. Mapeamento das 8 Abas da Interface Visual

1. **Ficha (`tab-ficha`)**: atributos, PV, PM, Defesa, Fortitude/Reflexos/Vontade, poderes, magias, equipamentos e comparativo das 4 camadas de itens (*Comum*, *Superior*, *Mágico*, *Ambos*).
2. **Arena (`tab-arena`)**: combate 1v1 em turnos no palco 2D/VTT, 65 ameaças oficiais, **Treinador RL Caixa-Preta (POMDP)**, ações em 5 categorias e **painel inline dinâmico de passivas** otimizado para celular.
3. **Mesas (`tab-mesa-online`)**: VTT cooperativo **4vN** com escala real (`1×1` a `6×6`), câmera auto-expansível (`26×14`), card sempre aberto de **RL Cooperativo de Grupo (Pódio Top 3)**, passivas inline e ferramentas recolhíveis do Mestre (encontros múltiplos, calculadora de ND e montarias).
4. **Análise (`tab-arvore`)**: diagrama SVG da árvore MCTS, fronteira de Pareto multi-estilo e importância marginal de cada poder (`ΔDPR`, `ΔEHP`, `ΔSuporte`).
5. **Otimizador (`tab-ia`)**: configuração de busca CSP + MCTS (classe, raça, origem, deus, nível 1–20, arquétipo e `Iterações MCTS`).
6. **Editor (`tab-manual`)**: edição manual completa, fichas salvas no banco e Bestiário Oficial (65 ameaças).
7. **Assistente (`tab-chat`)**: consultas rápidas de regras, explicação de Score e comandos sobre a ficha.
8. **Movimento (`tab-movimento`)**: simulador espacial (arena 45 m, início 9 m, *uptime* e *kiting*) + **Matriz Combinatória das 4 Camadas** e calculadora sob demanda das `3.704.400` bases.

---

## 3. Detalhamento Completo dos Algoritmos, Fórmulas, Variáveis e Métodos de Decisão

### 3.1 Fase 1 — CSP com Consistência de Arco (AC-3) e Acúmulo de Fontes

O CSP modela a construção legal como uma tripla $(X, D, C)$:
- **$X$ (Variáveis de decisão)**: Raça, Origem, Classe, Divindade, Atributos (10 pts), Armadura, Arma/Escudo, Poderes por nível, Magias e Arsenal.
- **$D$ (Domínios)**: opções disponíveis no catálogo oficial de Tormenta20 JdA v1.3.
- **$C$ (Restrições rígidas)**: pré-requisitos de nível/atributo/poder, restrições de devoção, proficiências, proibição de armadura metálica no Druida (p. 61), bloqueio de armadura no Arcanista/Lutador, bloqueio de DES e poderes incompatíveis em Armadura Pesada (*Insolência*, *Autoconfiança*, *Couraceiro*, *Casca Grossa*, *Braços Calejados*; exceções *Blindagem* e *Égide Sagrada*) e não-empilhamento por fonte (p. 226).

**Regra do Resolvedor de Acúmulo (`resolverAcumuloFontesT20JS` / `resolver_acumulo_fontes_t20`)**:
$$\text{BônusTotal} = \sum_{h \in \text{Habilidades Distintas}} \max(v_h) + \max(\text{Itens}) + \max(\text{Magias}) + \max(\text{Parceiros}) + \max(\text{Ambiente})$$

| Variável | Significado | Comportamento na Regra (JdA p. 226) |
| :--- | :--- | :--- |
| `h` / `v_h` | Cada habilidade ou poder distinto e seu valor numérico | Habilidades **diferentes** acumulam entre si; duplicatas da **mesma** habilidade mantêm apenas o maior valor. |
| `Itens`, `Magias`, `Parceiros`, `Ambiente` | Listas de bônus oriundos de cada uma dessas 4 fontes | Bônus da **mesma fonte** nunca somam — prevalece apenas o maior (`Math.max`). |

---

### 3.2 Métodos de Decisão Base da Ficha (Armadura, Arma/Escudo, Atributos e Escolas)

#### A) Decisão entre Armadura Leve e Armadura Pesada (`buscarMelhorEquipamentoDinamicoV80JS`)
Após o filtro CSP (proficiência, restrição de classe e teto de preço por nível: T$ 300 nv 1–3, T$ 1.500 nv 4–6, T$ 10.000 nv 7+), cada armadura legal recebe:
$$\text{Score}_{\text{arm}} = \text{Def}_{\text{ef}} - (\text{Pen} \times w_{\text{pen}})$$

| Variável | No Código | Significado e Regra |
| :--- | :--- | :--- |
| $\text{Def}_{\text{ef}}$ | `defEf` | Se **Armadura Pesada**: apenas `defB` (Destreza = `0`). Se **Armadura Leve**: `defB + max(0, DES)`. |
| $\text{Pen}$ | `pen` | Penalidade de armadura em valor absoluto (ex.: `5` na Armadura Completa, `1` no Couro Batido). |
| $w_{\text{pen}}$ | `pesoPen` | Peso tático da penalidade: `0,9` para Ladino ou arquétipo Arqueiro; `0,25` para as demais classes. |

*Decisão resultante*: classes com proficiência pesada e DES baixa/média escolhem **Armadura Pesada**; classes com DES alta ou foco em furtividade/arqueirismo escolhem **Armadura Leve** automaticamente.

#### B) Decisão de Arma, Escudo e Estilo de Combate
O algoritmo monta o produto cartesiano de **todas as armas proficientes** (incluindo arma preferida da divindade e *Ataque Desarmado*) com `[Sem Escudo, todos os escudos proficientes]` (armas de 2 mãos e distância recebem apenas `[Sem Escudo]`). Se `DES > FOR`, simula *Acuidade com Arma*; para Lutador, ativa *Briga*. Cada par é avaliado por `avaliarBuildNumericaDescritoresV72JS`, e o par de maior `Score` define as tags (`check_arma_duas_maos`, `check_arma_distancia`, `check_escudo`, `check_arma_agil`) que guiam o MCTS na escolha dos poderes de estilo.

#### C) Otimização de 10 Pontos de Atributo e Escolas de Magia
- **Atributos (`otimizarDistribuicao10PontosJdAV83JS`)**: respeita a tabela de compra de pontos do livro (`-1 → -1 pt`, `0 → 0`, `1 → 1`, `2 → 2`, `3 → 4`, `4 → 7`), testando distribuições especializadas (evitando diluir FOR e DES ao mesmo tempo) e escolhendo a de maior `Score`.
- **Escolas de Magia (Bardo e Druida)**: realiza busca combinatória exata sobre todas as $\binom{8}{3} = 56$ combinações de 3 escolas, escolhendo o trio que maximiza o arquétipo desejado (ex.: *Evocação + Conjuração + Transmutação* para dano/buff ou *Abjuração + Ilusão + Encantamento* para defesa/controle).

---

### 3.3 Fase 2 — MCTS com Política UCT e Iterações MCTS

$$\text{UCT}(s, a) = \frac{Q(s, a)}{N(s, a)} + c \sqrt{\frac{\ln N(s)}{N(s, a)}}$$

| Variável | No Código | Significado | Papel na Decisão |
| :--- | :--- | :--- | :--- |
| $s$ | Nó atual da ficha | Estado parcial da build (nível e poderes já escolhidos) | Define o conjunto de poderes legais restantes pelo CSP. |
| $a$ | Poder / ramo candidato | Próxima decisão (poder de classe, poder geral ou combo) | Ação avaliada para expansão da árvore. |
| $Q(s, a)$ | Valor acumulado / `scoreAtual` | Soma das recompensas (Score) obtidas passando por $(s, a)$ | Termo de **explotação**: favorece ramos comprovadamente fortes. |
| $N(s, a)$ | `visNo` | Número de visitas ao ramo $(s, a)$ | Reduz a incerteza conforme o ramo é mais testado. |
| $N(s)$ | `iteracoes` (`20` a `500`, padrão `120`) | Total de visitas no nó pai / orçamento de iterações MCTS | No Python (`mcts_rl_optimizer.py`), define os ciclos reais do loop; no JS offline, define o orçamento de visitas e o índice UCT da árvore SVG (com *lookahead* de combos desbloqueados). |
| $c$ | `1.414` ($\sqrt{2}$) | Constante de exploração UCT | Equilibra testar poderes pouco visitados vs. refinar os melhores. |

---

### 3.4 Cálculo de DPR Marcial (`dprMarcial` — `02_monte_carlo_and_sheet_ui.js`, L815–836)

$$\text{rolagemAtqMedia} = \text{mediaD20} + \text{atqBase}$$
$$\text{fatorPrecisaoProp} = 1 + \max(0,\ \text{rolagemAtqMedia} - 10{,}5) \times 0{,}032$$
$$p_{\text{crit},1} = \text{clamp}\!\left(\frac{21 - \text{margemCrit}}{20},\ 0{,}05,\ 0{,}50\right), \quad p_{\text{crit}} = \begin{cases} 1 - (1 - p_{\text{crit},1})^2 & \text{se } 2\text{d}20 \\ p_{\text{crit},1} & \text{se } 1\text{d}20 \end{cases}$$
$$\text{danoNormal} = \text{armaDadoMedia} + \text{danoFixo} + \text{dadosExtra}$$
$$\text{danoCritico} = \begin{cases} (\text{armaDadoMedia} + \text{danoFixo} + \text{dadosExtra}) \times \text{multCrit} & \text{se Lancinante} \\ (\text{armaDadoMedia} + \text{danoFixo}) \times \text{multCrit} + \text{dadosExtra} & \text{padrão (JdA p. 231)} \end{cases}$$
$$\text{danoMedioPorGolpe} = (1 - p_{\text{crit}})\cdot\text{danoNormal} + p_{\text{crit}}\cdot\text{danoCritico}$$
$$\text{fatorPM} = \min\!\left(1{,}0,\ \frac{\text{pmTotal}}{\max(1,\ \text{pmPorRodada} \times 4)}\right)$$
$$\text{dprMarcial} = (\text{atqEfetivosRec} \times \text{fatorCadencia}) \times \text{danoMedioPorGolpe} \times \text{fatorPrecisaoProp} \times \text{fatorRecMov} \times (0{,}65 + 0{,}35 \cdot \text{fatorPM})$$

| Variável | Significado | Como influencia o cálculo |
| :--- | :--- | :--- |
| `mediaD20` | Valor esperado da rolagem de ataque: `10,5` (1d20) ou `13,825` (melhor de 2d20, ex.: *Concentração de Combate*) | Eleva diretamente precisão e chance de crítico. |
| `atqBase` | Bônus total de ataque (atributo + metade do nível + treinamento + poderes + melhorias/encantos) | Cada ponto acima da média base (`10,5`) soma `+3,2%` em `fatorPrecisaoProp`. |
| `margemCrit` / `multCrit` | Margem de ameaça (ex.: `20`, `19`, `18`, dobrada por *Ameaçadora*) e multiplicador (`×2`, `×3`, `×4`) | Define `pCrit` e o salto de dano no crítico (`danoCritico`). |
| `armaDadoMedia` | Média do dado base da arma (já escalado por passos de dano em `aumentarPassoDanoT20JS`) | Multiplica no crítico; base principal para armas pesadas e *Briga*. |
| `danoFixo` / `dadosExtra` | Bônus fixos (FOR/DES, *Especialização*, *Cruel*) e dados extras (*Ataque Furtivo*, *Golpe Divino*, *Flamejante*) | `dadosExtra` só multiplica no crítico com o encanto **Lancinante** (JdA p. 336). |
| `atqEfetivosRec` | Ataques por rodada (*Ataque Extra*, *Ambidestria*, *Velocidade*, *Veloz*) | *Disparo Rápido* é removido automaticamente se a arma não tiver recarga livre. |
| `fatorCadencia` / `fatorRecMov` | Cadência real de recarga (`1,0` normal, `0,5` se recarga Padrão sem *Saque Rápido*; `0,92` se recarga gasta Ação de Movimento) | Penaliza armas de fogo/bestas sem suporte de recarga. |
| `fatorPM` | Razão de sustentabilidade de mana em janela de **4 rodadas** | Se o combo queima PM rápido demais, pode cortar até `35%` do DPR marcial. |

---

### 3.5 Cálculo de DPR Mágico (`dprMagico`) e Economia de Ações (`dprEfetivo`, L839–853)

$$p_{\text{falha}}(\text{CD}) = \text{clamp}\!\left(\frac{\text{CD} - \text{trMedioNd} - 1}{20},\ 0{,}05,\ 0{,}95\right), \quad M(\text{CD}) = 0{,}5 + 0{,}5 \cdot p_{\text{falha}}(\text{CD})$$
$$\text{multCdReal} = \frac{M(\text{cdBase} + \text{cdBonus})}{M(\text{cdBase})}$$
$$\text{dprMagico} = (\text{dprMagBase} \times \text{multCdReal} + \text{danoMagiaExtra}) \times (0{,}45 + 0{,}55 \cdot \text{fatorPMMagia})$$
$$\text{dprEfetivo} = \begin{cases} \max(\text{dprMarcial}, \text{dprMagico}) + 0{,}40\cdot\min(\text{dprMarcial}, \text{dprMagico}) & \text{se Ação Livre (Magia Acelerada / Prestidigitação)} \\ \max(\text{dprMarcial}, \text{dprMagico}) & \text{caso contrário (1 Ação Padrão)} \end{cases}$$

| Variável | Significado | Como influencia o cálculo |
| :--- | :--- | :--- |
| `melhorDprMagiaReal` | Maior DPR entre as magias do grimório: `danoMedio × fatorCDProp × alvosConsiderados` | Captura a melhor magia ofensiva aprimorada até o teto de PM por turno (`nivel + bonusLimitePm`). |
| `alvosConsiderados` | Multiplicador de **Área (AoE)**: `1,5` para magias de área (*Bola de Fogo*, *Relâmpago*, *Tempestade*) e `1,0` para alvo único | Valoriza magias em área sem inflar artificialmente o dano contra chefe único. |
| `cdBase` / `cdBonus` | CD base (`10 + ⌊nv/2⌋ + AtribChave`) e bônus de CD (esotéricos *Poderoso*, *Manto do Arquimago*, catalisadores e poderes) | Aumenta `pFalha`, elevando `M(CD)` (dano cheio na falha vs. metade no sucesso, JdA p. 171). |
| `trMedioNd` | Resistência de referência do ND (`round(2 + nv × 0,85)`) | Calibra o ganho marginal realista de cada `+1` em CD. |
| `danoMagiaExtra` | Soma de dados extras de esotéricos (*Energético*, *Evocador*), catalisadores (*Essência Abissal*, *Líquen Lilás*) e aprimoramentos de `+Limite PM` / `-PM` | Faz conjuradores escalarem realisticamente entre Comum, Superior, Mágico e Ambos na atual. |
| `fatorFalhaArcanaNaoConj` | `0,35` se não-conjurador com Defesa `≥ 14` tentar lançar magia arcana; `1,0` caso contrário | Impede builds marciais pesadas de abusarem de magias arcanas sem *Magia Discreta*. |
| `fatorPMMagia` | Sustentabilidade de PM da magia em 4 rodadas (`min(1, pmTotal / (melhorPmBurst × 4))`) | Pesa `55%` no DPR mágico — conjurador sem reserva de PM perde eficiência. |

---

### 3.6 Cálculo Defensivo (`ehpTurnos`), Suporte (`valorSuporte`) e Decisão da Melhor Build (`scoreTotal`, L856–878)

$$\text{ehpTurnos} = \frac{\text{pvTotal} \cdot \bigl(1 + 0{,}045 \cdot \max(0,\ \text{defTotal} - 10)\bigr) + \text{rdTotal} \cdot \text{pesoRdTatico} + \text{somaResHeroi} \cdot 2{,}5}{10}$$
$$\text{valorSuporte} = 9{,}0\cdot\text{buffGrpAtq} + 7{,}5\cdot\text{buffGrpDano} + 6{,}5\cdot\text{buffGrpDef} + 1{,}1\cdot\text{curaMedia}$$
$$\text{scoreTotal} = \text{dprEfetivo}\cdot w_{\text{DPR}} + \text{ehpTurnos}\cdot w_{\text{EHP}} + \text{valorSuporte}\cdot w_{\text{Sup}} + (0{,}45\cdot\text{pmTotal} + 6{,}5\cdot\text{cdBonus})\cdot w_{\text{Mag}}$$

| Variável | Significado | Valor / Peso |
| :--- | :--- | :--- |
| `pvTotal` | Pontos de Vida máximos da ficha | Base da sobrevivência, multiplicada pela Defesa efetiva. |
| `defTotal` | Defesa total legal (respeitando bloqueio de DES em Armadura Pesada) | Cada ponto acima de `10` aumenta o valor efetivo dos PV em `+4,5%`. |
| `rdTotal` / `pesoRdTatico` | Redução de Dano passiva/ativa e seu peso tático | `14,0` em linha de frente/tanques; `7,7` (`0,55×`) em builds à distância não-tanque. |
| `somaResHeroi` | Soma de `Fortitude + Reflexos + Vontade` | Cada ponto nos TRs contribui com `+2,5` no numerador do EHP (valoriza *Aura Sagrada*). |
| `buffGrpAtq/Dano/Def`, `curaMedia` | Bônus médios de grupo (*Oração*, *Bênção*, *Inspiração*) e cura média por turno | Compoem `valorSuporte`, decisivo para Clérigo, Druida, Bardo e Nobre. |
| $w_{\text{DPR}}, w_{\text{EHP}}, w_{\text{Sup}}, w_{\text{Mag}}$ | Pesos do arquétipo selecionado (iguais para todas as 14 classes) | **DPR**: `4,5 / 2,0 / 0,25 / 0,35` · **Tanque**: `1,0 / 15,0 / 0,6 / 0,4` · **Suporte**: `0,8 / 5,0 / 4,5 / 1,2` · **Controle**: `2,8 / 3,0 / 0,8 / 3,2` · **Equilibrado**: `2,8 / 5,5 / 1,4 / 1,0`. |

**Como a Melhor Build é decidida**: entre todas as fichas candidatas geradas (respeitando filtros fixos ou competindo entre todas as classes/raças/origens/deuses), vence a build com **maior `scoreTotal`** para o arquétipo escolhido. *Alcance e Movimentação* entram indiretamente via recarga/penalidade na ficha e são validados fisicamente em seguida no **Simulador Espacial** (arena 45 m, início 9 m) e nos **VTTs 2D**.

---

### 3.7 Recompensa $Q$ e Aprendizado por Reforço na Arena 1v1 (`treinarAgenteRLCaixaPretaArenaJS`)

Na Arena 1v1, o agente atua em regime **POMDP Caixa-Preta**: ele **não lê a Defesa da criatura** — mantém um intervalo de crença `[defMin .. defMax]` atualizado a cada ataque d20 (se `rolagem` acertou, `defMax = min(defMax, rolagem)`; se errou, `defMin = max(defMin, rolagem + 1)`).

**Atualização Incremental de Valor $Q$**:
$$Q_t \leftarrow Q_{t-1} + \alpha \cdot (R_t - Q_{t-1}), \quad \alpha = 0{,}25$$

**Função de Recompensa Episódica $R_t$**:
- **Em caso de Vitória**:
  $$R_t = 100 + w_{\text{PV}}\cdot\left(\frac{\text{PV}_{\text{rest}}}{\text{PV}_{\max}}\right) + \frac{w_T}{\text{turnos}}$$
- **Em caso de Derrota**:
  $$R_t = -100 + 60\cdot\min\!\left(1,\ \frac{\text{Dano}_{\text{ep}}}{\text{PV}_C}\right) - 20\cdot\mathbb{1}[\text{turnos} \le 1]$$

| Variável | Significado | Papel no Aprendizado |
| :--- | :--- | :--- |
| $Q_t$ | Estimativa de qualidade da build candidata após o episódio $t$ | Rankeia as builds testadas contra aquela ameaça específica; a de maior $Q$ vira a **Build Campeã**. |
| $\alpha = 0{,}25$ | Taxa de aprendizado (média móvel exponencial) | Suaviza a variância estocástica do dado d20 mantendo adaptação rápida. |
| $R_t$ | Recompensa escalar ao final do combate simulado | Diferencia vitórias limpas e rápidas de vitórias por um fio ou derrotas instantâneas. |
| $w_{\text{PV}} \in \{60, 85\}$ e $w_T \in \{40, 65\}$ | Pesos adaptados à doutrina (Sobrevivência prioriza $w_{\text{PV}}=85$; Velocidade/DPR prioriza $w_T=65$) | Direciona o agente a escolher builds coerentes com o objetivo tático. |
| $\text{PV}_{\text{rest}}/\text{PV}_{\max}$ e `turnos` | Fração de vida restante do herói e duração do combate em rodadas | Recompensa sobrevivência e eficiência (abate em menos turnos). |
| $\text{Dano}_{\text{ep}}/\text{PV}_C$ e $\mathbb{1}[\text{turnos}\le 1]$ | Fração de PV removida da ameaça e indicador de derrota em 1 turno | Evita "recompensa esparsa" (dá gradiente parcial em derrotas) e pune builds frágeis que caem no 1º turno. |

**Política de Decisão por Turno (sob teto rígido de PM = `nivel + bonusLimitePm`)**:
1. **Setup/Buff**: ativa habilidades preparatórias de maior ganho enquanto houver PM legal no turno.
2. **Ação Padrão de maior EV**: calcula o valor esperado de acerto usando o ponto médio de `[defMin .. defMax]` e executa a melhor ação ofensiva.
3. **Reação Defensiva**: no turno da ameaça, aciona automaticamente *Campo de Força* (RD 30), *Armadura Arcana* (+5 Def), *Durão* (reduz dano à metade) ou bloqueio de Escudo.

---

### 3.8 RL Cooperativo Multiagente nas Mesas Online 4vN (`treinarMelhorGrupoRLMesaOnlineJS`)

Para encontros em grupo contra múltiplas ameaças (NDs mistos e flanqueamento 2D), o motor executa **Avaliação Monte Carlo Cooperativa** de **85 episódios** (até **12 rodadas** cada) por composição candidata de 4 heróis, sob uma **política cooperativa hierárquica de 4 estágios**:

1. **Estágio 1 — Buff Coletivo (Rodada 1)**: Suporte aplica *Oração* ou *Inspiração* (até `+5`/`-5` coletivo).
2. **Estágio 2 — Cura de Emergência**: se qualquer aliado cair abaixo de **`42%` dos PV**, o curandeiro prioriza cura (`14 + 2×nv` PV) antes de atacar.
3. **Estágio 3 — Magia em Área (AoE)**: se houver **`≥ 2` inimigos vivos**, conjuradores priorizam dano em área.
4. **Estágio 4 — Foco de Fogo & Flanqueamento**: atacantes concentram dano no mesmo alvo com `2d20`, `+2` de Flanqueamento 2D e *Ataque Furtivo*, enquanto o Tanque absorve o foco das ameaças.

**Score de Eleição do Pódio Top 3 Grupos**:
$$\text{Score}_{\text{RL}} = 2{,}2\cdot\text{WinRate}\% + 0{,}8\cdot\overline{\text{DPR}}_{\text{grupo}} + 15\cdot\overline{\text{Vivos}} - 4\cdot\overline{\text{Rodadas}}$$

| Variável | Significado | Peso e Justificativa |
| :--- | :--- | :--- |
| $\text{WinRate}\%$ | Taxa percentual de vitórias nos 85 episódios (`0` a `100`) | Peso `2,2` (fator dominante — vencer consistentemente o encontro). |
| $\overline{\text{DPR}}_{\text{grupo}}$ | Dano médio somado dos 4 heróis por rodada | Peso `0,8` (premia poder de fogo cooperativo). |
| $\overline{\text{Vivos}}$ | Média de heróis de pé ao final da vitória (`0` a `4`) | Peso `15,0` (penaliza composições "suicidas" em que metade do grupo cai). |
| $\overline{\text{Rodadas}}$ | Duração média do encontro (até `12`) | Peso `-4,0` (premia resolução rápida e economia de recursos). |
