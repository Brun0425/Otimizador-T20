-- ==============================================================================
-- ESQUEMA RELACIONAL POSTGRESQL / SUPABASE — PROJETO TORMENTA 20 (v41)
-- ==============================================================================
-- Script de migração para banco de dados SQL em nuvem (PostgreSQL 15+ / Supabase / Neon),
-- espelhando a estrutura da Clean Architecture (`t20_clean_arch/infrastructure/`).

CREATE TABLE IF NOT EXISTS racas (
    id_raca TEXT PRIMARY KEY,
    nome TEXT NOT NULL UNIQUE,
    tamanho TEXT NOT NULL DEFAULT 'Médio',
    deslocamento_m INTEGER NOT NULL DEFAULT 9,
    mod_for INTEGER NOT NULL DEFAULT 0,
    mod_des INTEGER NOT NULL DEFAULT 0,
    mod_con INTEGER NOT NULL DEFAULT 0,
    mod_int INTEGER NOT NULL DEFAULT 0,
    mod_sab INTEGER NOT NULL DEFAULT 0,
    mod_car INTEGER NOT NULL DEFAULT 0,
    mod_livre TEXT,
    habilidades_raca TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS classes (
    id_classe TEXT PRIMARY KEY,
    nome TEXT NOT NULL UNIQUE,
    pv_inicial INTEGER NOT NULL,
    pv_por_nivel INTEGER NOT NULL,
    pm_por_nivel INTEGER NOT NULL,
    atributo_principal TEXT NOT NULL,
    qtd_pericias_iniciais INTEGER NOT NULL,
    pericias_fixas TEXT,
    proficiencias TEXT,
    habilidades_fixas TEXT
);

CREATE TABLE IF NOT EXISTS origens (
    id_origem TEXT PRIMARY KEY,
    nome TEXT NOT NULL UNIQUE,
    pericias_disponiveis TEXT,
    poderes_disponiveis TEXT,
    poder_unico TEXT,
    efeito_poder_unico TEXT
);

CREATE TABLE IF NOT EXISTS deuses (
    id_deus TEXT PRIMARY KEY,
    nome TEXT NOT NULL UNIQUE,
    titulo TEXT,
    energia TEXT,
    arma_preferida TEXT,
    devotos_permitidos TEXT,
    obrigacoes_restricoes TEXT,
    poderes_concedidos TEXT
);

CREATE TABLE IF NOT EXISTS poderes (
    id_poder TEXT PRIMARY KEY,
    categoria_ou_classe TEXT NOT NULL,
    nome TEXT NOT NULL,
    pre_requisitos TEXT,
    custo_pm TEXT,
    acao TEXT,
    efeito_resumo TEXT,
    eh_poder_classe BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS itens (
    id_item TEXT PRIMARY KEY,
    categoria TEXT NOT NULL,
    subcategoria TEXT,
    nome TEXT NOT NULL,
    preco TEXT,
    dano_ou_defesa TEXT,
    critico_ou_penalidade TEXT,
    alcance TEXT,
    espacos NUMERIC(6,2) NOT NULL DEFAULT 1,
    efeito_propriedades TEXT
);

CREATE TABLE IF NOT EXISTS magias (
    id_magia TEXT PRIMARY KEY,
    circulo INTEGER NOT NULL CHECK (circulo BETWEEN 1 AND 5),
    tipo TEXT NOT NULL,
    escola TEXT NOT NULL,
    nome TEXT NOT NULL,
    execucao TEXT,
    alcance TEXT,
    alvo_area TEXT,
    duracao TEXT,
    resistencia TEXT,
    efeito_e_aprimoramentos TEXT
);

CREATE TABLE IF NOT EXISTS personagens (
    id_personagem BIGSERIAL PRIMARY KEY,
    uuid_externo TEXT UNIQUE,
    nome TEXT NOT NULL,
    jogador TEXT NOT NULL DEFAULT 'Jogador',
    nivel INTEGER NOT NULL CHECK (nivel BETWEEN 1 AND 20),
    id_raca TEXT REFERENCES racas(id_raca),
    id_classe TEXT REFERENCES classes(id_classe),
    classes_niveis TEXT NOT NULL DEFAULT 'Guerreiro 1',
    id_origem TEXT REFERENCES origens(id_origem),
    id_deus TEXT REFERENCES deuses(id_deus),
    pv_maximos INTEGER NOT NULL,
    pm_maximos INTEGER NOT NULL,
    defesa_total INTEGER NOT NULL,
    pontuacao_mcts NUMERIC(10,2) NOT NULL DEFAULT 0,
    ficha_json JSONB NOT NULL,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS personagem_escolhas (
    id BIGSERIAL PRIMARY KEY,
    id_personagem BIGINT NOT NULL REFERENCES personagens(id_personagem) ON DELETE CASCADE,
    tipo_escolha TEXT NOT NULL,
    codigo_referencia TEXT NOT NULL,
    nome_referencia TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS historico_combates_rl (
    id BIGSERIAL PRIMARY KEY,
    id_personagem BIGINT REFERENCES personagens(id_personagem) ON DELETE SET NULL,
    criatura_nome TEXT NOT NULL,
    nd_criatura TEXT NOT NULL,
    venceu BOOLEAN NOT NULL,
    turnos INTEGER NOT NULL,
    dano_causado NUMERIC(10,2) NOT NULL DEFAULT 0,
    recompensa_q NUMERIC(10,2) NOT NULL DEFAULT 0,
    registrado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para consultas rápidas por jogador, nível, score e busca JSONB
CREATE INDEX IF NOT EXISTS idx_personagens_nome ON personagens (nome);
CREATE INDEX IF NOT EXISTS idx_personagens_jogador ON personagens (jogador);
CREATE INDEX IF NOT EXISTS idx_personagens_nivel_score ON personagens (nivel, pontuacao_mcts DESC);
CREATE INDEX IF NOT EXISTS idx_personagens_json_gin ON personagens USING GIN (ficha_json);
CREATE INDEX IF NOT EXISTS idx_escolhas_personagem ON personagem_escolhas (id_personagem);

-- =============================================================================
-- 4. TABELAS DE MESAS ONLINE MULTIPLAYER (CO-OP & MESTRE EM TEMPO REAL - v43)
-- =============================================================================
CREATE TABLE IF NOT EXISTS mesas_online (
    id_mesa BIGSERIAL PRIMARY KEY,
    codigo_sala VARCHAR(32) NOT NULL UNIQUE,
    nome_mesa VARCHAR(160) NOT NULL,
    mestre_nome VARCHAR(120) NOT NULL DEFAULT 'Mestre',
    id_ameaca_ativa VARCHAR(64) NOT NULL DEFAULT 't20_cap7_012',
    rodada_atual INTEGER NOT NULL DEFAULT 1,
    turno_indice INTEGER NOT NULL DEFAULT 0,
    estado_json JSONB NOT NULL,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mesa_participantes (
    id_participante BIGSERIAL PRIMARY KEY,
    codigo_sala VARCHAR(32) NOT NULL REFERENCES mesas_online(codigo_sala) ON DELETE CASCADE,
    id_heroi VARCHAR(64) NOT NULL,
    nome_heroi VARCHAR(120) NOT NULL,
    jogador_nome VARCHAR(120) NOT NULL,
    papel_grupo VARCHAR(64) NOT NULL DEFAULT 'Combatente',
    pv_atual INTEGER NOT NULL DEFAULT 20,
    pv_max INTEGER NOT NULL DEFAULT 20,
    pm_atual INTEGER NOT NULL DEFAULT 10,
    pm_max INTEGER NOT NULL DEFAULT 10,
    iniciativa_rolada INTEGER NOT NULL DEFAULT 10,
    ficha_resumo_json JSONB NOT NULL,
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(codigo_sala, id_heroi)
);

CREATE TABLE IF NOT EXISTS mesa_eventos_log (
    id_evento BIGSERIAL PRIMARY KEY,
    codigo_sala VARCHAR(32) NOT NULL REFERENCES mesas_online(codigo_sala) ON DELETE CASCADE,
    autor VARCHAR(120) NOT NULL,
    tipo_evento VARCHAR(32) NOT NULL DEFAULT 'ACAO',
    mensagem TEXT NOT NULL,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pg_mesas_codigo ON mesas_online(codigo_sala);
CREATE INDEX IF NOT EXISTS idx_pg_mesas_estado_gin ON mesas_online USING GIN (estado_json);
CREATE INDEX IF NOT EXISTS idx_pg_participantes_sala ON mesa_participantes(codigo_sala);
CREATE INDEX IF NOT EXISTS idx_pg_eventos_sala ON mesa_eventos_log(codigo_sala, id_evento DESC);

